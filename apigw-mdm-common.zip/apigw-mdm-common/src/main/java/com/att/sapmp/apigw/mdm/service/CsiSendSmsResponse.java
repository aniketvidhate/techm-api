package com.att.sapmp.apigw.mdm.service;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.mdm.exception.ApigwException;

@Component
public class CsiSendSmsResponse {

	private Logger log = LoggerFactory.getLogger(CsiSendSmsResponse.class);

	public void handleSendSms(Exchange exchange) throws ApigwException {
		 String csiResposeBody = (String) exchange.getIn().getBody();
		 log.info("Respose from CsiSendSmsResponse: \n"+csiResposeBody);

	}
}
