package com.att.sapmp.apigw.mdm.service;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.mdm.exception.ApigwException;
import com.att.sapmp.apigw.mdm.util.CommonDefs;

@Component
public class UpdateSubsriberProfileResponse {

	private Logger log = LoggerFactory.getLogger(CsiSendSmsResponse.class);
	
	public void updateSubProfileResponse(Exchange exchange) throws ApigwException {
		 String csiResposeBody = (String) exchange.getIn().getBody();
		 log.info("Response from updateSubProfileResponse \n"+csiResposeBody);
		/*		
		 XmlMapper xmlMapper = new XmlMapper();
		 Map<String,Object> hmCsiResponse=null;
		 try {
			 hmCsiResponse = xmlMapper.readValue(csiResposeBody, HashMap.class);
		
		 } catch (IOException ioe) {
			log.debug("Exception occurred while parsing post request: " + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		Map<String,Object> hmBody = (HashMap<String,Object>) hmCsiResponse.get("Body");
		Map<String,Object> updateSubsProfileRes = (HashMap<String,Object>) hmBody.get("UpdateSubscriberProfileResponse");
	    Map<String,Object> response = (HashMap<String,Object>) updateSubsProfileRes.get("Response");
		JSONObject jsonRespone=new JSONObject(response);
		exchange.getIn().setBody(jsonRespone);
		log.info("Recieved the Response ::"+jsonRespone);		
		log.info("End of updateSubProfileResponse");*/
		exchange.getOut().setHeader("description","success");
		exchange.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
	}
}
