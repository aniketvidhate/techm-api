package com.att.sapmp.apigw.mdm.service;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


@Component
public class CsiManageDeviceProfileResponse {
	
	private Logger log = LoggerFactory.getLogger(CsiManageDeviceProfileResponse.class);
	
	public final void handleCdfResponse(Exchange e) throws Exception {
		
		String respBody = e.getIn().getBody(String.class);
		log.info("Received response in handleCdfUpdateResponse method="+respBody);
		e.getOut().setHeader("CamelHttpResponseCode", "202");
		
		
	}

}
