package com.att.sapmp.apigw.mdm.model;

import org.springframework.stereotype.Component;

@Component
public class SMSResponse {

	private String deliveryKey;
	private String faultCode;
	private String faultMessage;
	private Boolean status;
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public String getDeliveryKey() {
		return deliveryKey;
	}
	public void setDeliveryKey(String deliveryKey) {
		this.deliveryKey = deliveryKey;
	}
	public String getFaultCode() {
		return faultCode;
	}
	public void setFaultCode(String faultCode) {
		this.faultCode = faultCode;
	}
	public String getFaultMessage() {
		return faultMessage;
	}
	public void setFaultMessage(String faultMessage) {
		this.faultMessage = faultMessage;
	}
	
	
}
