package com.att.sapmp.apigw.mdm.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.mdm.exception.ApigwException;
import com.att.sapmp.apigw.mdm.exception.CErrorDefs;
import com.att.sapmp.apigw.mdm.util.CommonDefs;
import com.att.sapmp.apigw.mdm.util.CommonUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;


@Component
public class CsiInquireDeviceDetailsProcessor {

	private Logger log = LoggerFactory.getLogger(CsiInquireDeviceDetailsProcessor.class);
	
	
	@Value("${csi.user}")
	private String userName;
	
	@Value("${csi.password}")
	private String userPassword;
	
	@Value("${csi.version}")
	private String version;
	
	@Value("${csi.messageId}")
	private String messageId;
	
	@Value("${csi.sequenceNumber}")
	private String sequenceNumber;
	
	@Value("${csi.totalInSequence}")
	private String totalInSequence;
	

	public final void execute(Exchange e) throws ApigwException {

		log.info("Start execute CsiInquireDeviceDetailsProcessor");
		e.getIn().setHeaders(e.getIn().getHeaders());
		
		
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		ObjectMapper objectMapper = new ObjectMapper();

		HashMap<String, Object> hmCsiInquireDeviceDetails = null;
		try {
			hmCsiInquireDeviceDetails = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
		} catch (IOException e1) {
			log.info("Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);

		}  
		e.setProperty(CommonDefs.ACTION_TYPE, e.getProperty(CommonDefs.ACTION_TYPE));
		hmCsiInquireDeviceDetails.put(CommonDefs.VERSION_NO, version);
		hmCsiInquireDeviceDetails.put(CommonDefs.MESSAGE_ID, messageId);
		hmCsiInquireDeviceDetails.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
		hmCsiInquireDeviceDetails.put(CommonDefs.USER_NAME, userName);
		hmCsiInquireDeviceDetails.put(CommonDefs.USER_PASSWORD, userPassword);
		hmCsiInquireDeviceDetails.put(CommonDefs.TOTAL_IN_SEQUENCE, totalInSequence);
		hmCsiInquireDeviceDetails.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
		
		VelocityContext velocityContext = new VelocityContext(hmCsiInquireDeviceDetails);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		log.info("End execute CsiInquireDeviceDetailsProcessor");
		
	}

	public final void handleCsiInquireDeviceDetailResponse(Exchange e) throws ApigwException, JsonParseException, JsonMappingException, IOException {
		
		
		String csiResposeBody = (String) e.getIn().getBody();
		log.info("Response From handleCsiInquireDeviceDetailResponse body:: \n"+csiResposeBody);
				
		 XmlMapper xmlMapper = new XmlMapper();
		 Map<String,Object> hmCsiResponse=null;
		 try {
			 hmCsiResponse = xmlMapper.readValue(csiResposeBody, HashMap.class);
		
		 } catch (IOException ioe) {
			log.debug("Exception occurred while parsing post request: " + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		Map<String,Object> hmBody = (HashMap<String,Object>) hmCsiResponse.get("Body");
		
		if (hmBody != null && !(hmBody.isEmpty())) {
			Map<String, Object> inquireDetailsResponse = (HashMap<String, Object>) hmBody.get("InquireEnterpriseDeviceDeploymentDetailsResponse");
			if (inquireDetailsResponse != null && !(inquireDetailsResponse.isEmpty())) {
				Map<String, Object> deviceDetailList = (HashMap<String, Object>) inquireDetailsResponse.get("DeviceDetailList");
				Map<String, Object> device_details_APNstatus = (HashMap<String, Object>) deviceDetailList.get("apnStatus");
				e.getIn().setHeader(CommonDefs.DEVICE_DETAILS_APNSTATUS, device_details_APNstatus);
				log.info("Getting the response of  device_details_APNstatus ::" + device_details_APNstatus);

				Map deviceNetCtrl = (HashMap<String, Object>) ((HashMap<String, Object>) deviceDetailList.get("ProfileType")).get("networkControlNewDeviceFlag");
				e.getIn().setHeader("deviceNetCtrl", deviceNetCtrl);

				String actionType = (String) e.getProperty(CommonDefs.ACTION_TYPE);
				e.getIn().setHeader(CommonDefs.ACTION_TYPE, actionType);
				e.getIn().setHeader("actType", actionType);

			}
		}
		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		log.info("End of handleCsiInquireDeviceDetailResponse");

	}

}