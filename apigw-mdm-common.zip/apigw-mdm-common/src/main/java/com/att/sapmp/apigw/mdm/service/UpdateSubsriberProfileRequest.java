package com.att.sapmp.apigw.mdm.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.mdm.exception.ApigwException;
import com.att.sapmp.apigw.mdm.util.CommonDefs;
import com.att.sapmp.apigw.mdm.util.CommonUtil;

@Component
public class UpdateSubsriberProfileRequest {
	
	private Logger log = LoggerFactory.getLogger(UpdateSubsriberProfileRequest.class);
	

	@Value("${csi.user}")
	private String userName;
	
	@Value("${csi.password}")
	private String userPassword;
	
	@Value("${csi.updateSub.version}")
	private String version;
	
	@Value("${csi.messageId}")
	private String messageId;
	
	@Value("${csi.sequenceNumber}")
	private String sequenceNumber;
	
	@Value("${csi.totalInSequence}")
	private String totalInSequence;
	
	@Value("${csi.infrastructureVersion}")
	private String infrastructureVersion;
	
	@Value("${csi.location}")
	private String location;
	
	@Value("${csi.code}")
	private String code;
	
	@Value("${csi.originatorId}")
	private String originatorId;
	
	@Value("${csi.salesRepresentative}")
	private String salesRepresentative;
	
	@Value("${csi.subscriberNumber}")
	private String subscriberNumber;
	
	@Value("${csi.conversationId}")
	private String conversationId;
	
	@Value("${csi.updateSub.enroll.action}")
	private String updateSubEnrollAction;
	
	@Value("${csi.updateSub.denroll.action}")
	private String updateSubDenrollAction;	
	
	
	
	public final void execute(Exchange e) throws ApigwException {

		log.info("Start of UpdateSubsriberProfileRequest method ::");
		Map<String, Object> hmSubProfile = new HashMap();
		    hmSubProfile.put(CommonDefs.VERSION_NO, version);
			hmSubProfile.put(CommonDefs.MESSAGE_ID, messageId);
			hmSubProfile.put(CommonDefs.ORIGINATOR_ID, originatorId);
			hmSubProfile.put(CommonDefs.CONVERSATION_ID, conversationId);
			hmSubProfile.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
			hmSubProfile.put(CommonDefs.USER_NAME, userName);
			hmSubProfile.put(CommonDefs.USER_PASSWORD,userPassword);
			hmSubProfile.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
			hmSubProfile.put(CommonDefs.TOTAL_IN_SEQUENCE,totalInSequence);
			hmSubProfile.put(CommonDefs.CODE, code);
			hmSubProfile.put(CommonDefs.LOCATION, location);
			hmSubProfile.put(CommonDefs.SALES_REPRESENTATIVE, salesRepresentative);
			hmSubProfile.put(CommonDefs.SUBSCRIBER_NUMBER, subscriberNumber);
			hmSubProfile.put(CommonDefs.ACTION, updateSubDenrollAction);
			hmSubProfile.put(CommonDefs.EFFECTIVE_DATE, CommonUtil.getGMTDatAsString());
			hmSubProfile.put(CommonDefs.EXPIRATION_DATE,CommonUtil.getGMTDatAsString());
			
		VelocityContext velocityContext = new VelocityContext(hmSubProfile);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		

	}
	
	
	public final void executeAddSoc(Exchange e) throws ApigwException {

		log.info("Start of UpdateSubsriberProfileRequest method ::");
		Map<String, Object> hmSubProfile = new HashMap();
		    hmSubProfile.put(CommonDefs.VERSION_NO, version);
			hmSubProfile.put(CommonDefs.MESSAGE_ID, messageId);
			hmSubProfile.put(CommonDefs.ORIGINATOR_ID, originatorId);
			hmSubProfile.put(CommonDefs.CONVERSATION_ID, conversationId);
			hmSubProfile.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
			hmSubProfile.put(CommonDefs.USER_NAME, userName);
			hmSubProfile.put(CommonDefs.USER_PASSWORD,userPassword);
			hmSubProfile.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
			hmSubProfile.put(CommonDefs.TOTAL_IN_SEQUENCE,totalInSequence);
			hmSubProfile.put(CommonDefs.CODE, code);
			hmSubProfile.put(CommonDefs.LOCATION, location);
			hmSubProfile.put(CommonDefs.SALES_REPRESENTATIVE, salesRepresentative);
			hmSubProfile.put(CommonDefs.SUBSCRIBER_NUMBER, subscriberNumber);
			hmSubProfile.put(CommonDefs.ACTION, updateSubEnrollAction);
			hmSubProfile.put(CommonDefs.EFFECTIVE_DATE, CommonUtil.getGMTDatAsString());
			hmSubProfile.put(CommonDefs.EXPIRATION_DATE,CommonUtil.getGMTDatAsString());
			
		VelocityContext velocityContext = new VelocityContext(hmSubProfile);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		

	}	
}
