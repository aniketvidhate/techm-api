package com.att.sapmp.apigw.mdm.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.att.sapmp.apigw.mdm.exception.ApigwException;
import com.att.sapmp.apigw.mdm.exception.CErrorDefs;
import com.att.sapmp.apigw.mdm.util.CommonUtil;
import com.att.sapmp.apigw.mdm.util.MdmPropertiesUtil;

public class InquireMdmPartner {
	
	@Autowired
	CommonUtil commonUtil;
	
	@Autowired
	MdmPropertiesUtil mdmProp;

	/**
	 * This method get the MDM URL from property file.
	 * 
	 * @param productCode
	 * @param prop
	 * @return String URL
	 * @throws ApigwException
	 */
	public String getMDMUrl(String productCode, String prop) throws ApigwException {
		String stURL = null;
			if (productCode == null || productCode.isEmpty() || prop == null || prop.isEmpty()) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "input param  is null in input");
			}

			boolean isProductCodeValid = commonUtil.isProductCodeValid(productCode);
			if (isProductCodeValid) {
				stURL = mdmProp.getProperty(productCode.toLowerCase() + "." + prop.toLowerCase());
			}else{
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "Invalid Product Code");
			}
		return stURL;
	}

}
