package com.att.sapmp.apigw.mdm.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

public class MdmPropertiesUtil extends PropertyPlaceholderConfigurer {

	private static Map<String, String> properties = new HashMap<String, String>();

	@Override
	protected void loadProperties(final Properties props) throws IOException {
		super.loadProperties(props);
		for (final Object key : props.keySet()) {
			properties.put((String) key, props.getProperty((String) key));
		}
	}

	public String getProperty(final String propKey) {
		String propValue = null;
		if (!StringUtils.isEmpty(propKey)) {
			propValue = properties.get(propKey.toLowerCase());
		}
		return propValue;
	}

}
