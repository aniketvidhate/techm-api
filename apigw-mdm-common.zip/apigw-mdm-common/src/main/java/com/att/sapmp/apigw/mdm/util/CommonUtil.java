package com.att.sapmp.apigw.mdm.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class CommonUtil {

	public static final String DATEFORMAT = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'";
	
	public static final String DATEFORMAT_EFFECTIVE = "yyyy-MM-dd'Z'";
	
	@Autowired
	MdmPropertiesUtil mdmProp;

	public boolean isProductCodeValid(String inProductCode) {
		boolean bValid = false;
		String stProduct = mdmProp.getProperty("product.code");
		if (stProduct != null) {
			List<String> alList = Arrays.asList(stProduct.split("\\|"));
			if (inProductCode != null && alList.contains(inProductCode.toLowerCase())) {
				bValid = true;
			}
		}
		return bValid;

	}

	public List<String> getAsArrayList(String inValue) {
		List<String> alResponse = new ArrayList<String>();
		if (!StringUtils.isEmpty(inValue)) {
			alResponse.add(inValue);
		}
		return alResponse;

	}

	public static String getGMTdatetimeAsString() {
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}
	public static String getGMTDatAsString() {
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT_EFFECTIVE);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}
	

}
