package com.att.sapmp.apigw.mdm.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.mdm.exception.ApigwException;
import com.att.sapmp.apigw.mdm.exception.CErrorDefs;
import com.att.sapmp.apigw.mdm.util.CommonDefs;
import com.att.sapmp.apigw.mdm.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CsiManageDeviceDetailsProcessor {

	private Logger log = LoggerFactory.getLogger(CsiManageDeviceDetailsProcessor.class);
	
	@Value("${csi.user}")
	private String userName;
	
	@Value("${csi.password}")
	private String userPassword;
	
	@Value("${csi.version}")
	private String version;
	
	@Value("${csi.messageId}")
	private String messageId;
	
	@Value("${csi.infrastructureVersion}")
	private String infrastructureVersion;
	
	@Value("${csi.applicationName}")
	private String applicationName;
	
	@Value("${csi.routingRegionOverride}")
	private String routingRegionOverride;
	
	@Value("${csi.sequenceNumber}")
	private String sequenceNumber;
	
	@Value("${csi.totalInSequence}")
	private String totalInSequence;
	
	public final void execute(Exchange e) throws ApigwException {
		
		e.getIn().setHeaders(e.getIn().getHeaders());
		
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		// create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// convert json string to object
		HashMap<String, Object> hmCsiManageDeviceDetails = null;
		try {
			hmCsiManageDeviceDetails = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
		} catch (IOException e1) {
			log.info("Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);

		}
		hmCsiManageDeviceDetails.put(CommonDefs.INFRASTRUCTURE_VERSION, infrastructureVersion);
		
		hmCsiManageDeviceDetails.put(CommonDefs.APPLICATION_NAME, applicationName);
		hmCsiManageDeviceDetails.put(CommonDefs.VERSION_NO, version);
		hmCsiManageDeviceDetails.put(CommonDefs.MESSAGE_ID, messageId);
		hmCsiManageDeviceDetails.put(CommonDefs.ROUTING_REGION_OVERRIDE, routingRegionOverride);
		hmCsiManageDeviceDetails.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
		hmCsiManageDeviceDetails.put(CommonDefs.USER_NAME, userName);
		hmCsiManageDeviceDetails.put(CommonDefs.USER_PASSWORD, userPassword);
		hmCsiManageDeviceDetails.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
		hmCsiManageDeviceDetails.put(CommonDefs.TOTAL_IN_SEQUENCE, totalInSequence);
		
		VelocityContext velocityContext = new VelocityContext(hmCsiManageDeviceDetails);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		
	}

	public final void handleCsiManageDeviceDetailResponse(Exchange e) throws ApigwException {
		

		String body = (String) e.getIn().getBody(String.class);
		log.info("Response from handleCsiManageDeviceDetailResponse \n"+body);
		
		e.getIn().setHeaders(e.getIn().getHeaders());

		e.getIn().setHeader(CommonDefs.TRACKING_ID, e.getProperty(CommonDefs.TRACKING_ID));
		e.getIn().setHeader(CommonDefs.EMM_PRODUCT_CODE, e.getProperty(CommonDefs.EMM_PRODUCT_CODE));
		e.getIn().setHeader(CommonDefs.AUTHORIZATION, e.getProperty(CommonDefs.AUTHORIZATION));
		e.getIn().setHeader(CommonDefs.ACCOUNT_PASS_PHRASE, e.getProperty(CommonDefs.ACCOUNT_PASS_PHRASE));

		Map<String, String> bodyMap = new HashMap<String, String>();
		bodyMap.put(CommonDefs.DEVICE_ID, String.valueOf(e.getProperty(CommonDefs.DEVICE_ID)));
		bodyMap.put(CommonDefs.IMEI, String.valueOf(e.getProperty(CommonDefs.IMEI)));
		bodyMap.put(CommonDefs.ACTION_TYPE, String.valueOf(e.getProperty(CommonDefs.ACTION_TYPE)));

		VelocityContext velocityContext = new VelocityContext(bodyMap);

		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);

		e.getIn().setBody(e.getIn().getBody());
		e.getOut().setHeader("CamelHttpResponseCode", "202");

		log.info("End handleCsiManageDeviceDetailResponse");

	}

	
}