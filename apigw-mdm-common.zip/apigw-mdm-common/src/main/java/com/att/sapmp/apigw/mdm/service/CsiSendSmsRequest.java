package com.att.sapmp.apigw.mdm.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.mdm.exception.ApigwException;
import com.att.sapmp.apigw.mdm.util.CommonDefs;
import com.att.sapmp.apigw.mdm.util.CommonUtil;



@Component
public class CsiSendSmsRequest {

	private Logger log = LoggerFactory.getLogger(CsiSendSmsRequest.class);

	@Value("${csi.user}")
	private String userName;
	
	@Value("${csi.password}")
	private String userPassword;
	
	@Value("${csi.updateSub.version}")
	private String version;
	
	@Value("${csi.messageId}")
	private String messageId;
	
	@Value("${csi.sequenceNumber}")
	private String sequenceNumber;
	
	@Value("${csi.totalInSequence}")
	private String totalInSequence;
	
	@Value("${csi.sourceAddress}")
	private String sourceAddress;

			
	public final void executeSendSms(Exchange e) throws ApigwException {

		String ctn=(String)e.getProperty(CommonDefs.CTN);
	    String messageBody=(String) e.getProperty(CommonDefs.SMSPARAMETERS);
	    String email=(String) e.getProperty(CommonDefs.EMAIL);
	   
        String smsMessageDetailsArray[] = getSmsMessageDetailsArray(messageBody);
        String smsUrl= getSmsUrl(smsMessageDetailsArray);
        String smsCorpID= getSmsCorpID(smsMessageDetailsArray);
        String smsPassCode= getSmsPassCode(smsMessageDetailsArray);
	    Map<String,Object> hmSendSms=new HashMap();

		   hmSendSms.put(CommonDefs.USER, userName);
		   hmSendSms.put(CommonDefs.USER_PASSWORD, userPassword);
		   hmSendSms.put(CommonDefs.VERSION_NO, version);
		   hmSendSms.put(CommonDefs.MESSAGE_ID, messageId);
		   hmSendSms.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
		   hmSendSms.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
		   hmSendSms.put(CommonDefs.TOTAL_IN_SEQUENCE,totalInSequence);
		   hmSendSms.put(CommonDefs.DESTINATION_ADDRESS, ctn);
		   hmSendSms.put(CommonDefs.SOURCE_ADDRESS, sourceAddress);
		   hmSendSms.put(CommonDefs.EMAIL, email);
		   hmSendSms.put(CommonDefs.SMS_URL, smsUrl);
		   hmSendSms.put(CommonDefs.SMS_CORP_ID, smsCorpID);
		   hmSendSms.put(CommonDefs.SMS_PASS_CODE, smsPassCode);
		VelocityContext velocityContext = new VelocityContext(hmSendSms);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	private String[] getSmsMessageDetailsArray(String messageBody) {
	    String removeOpenCurly=messageBody.replace("{", "");
        String removeCloseCurly=removeOpenCurly.replace("}", "");
        String smsMessageDetailsArray[]=removeCloseCurly.split(",");
		return smsMessageDetailsArray;
	}

	private String getSmsUrl(String[] smsMessageDetailsArray){
        String smsUrl = "";
        for(String itr:smsMessageDetailsArray){
        	if(itr.contains(CommonDefs.ENROLL_DEVICE_RESP_SMS_URL)){
        		smsUrl = itr.substring(itr.indexOf("=")+1, itr.length());
        	}
        }		
		return smsUrl;
	}
	
	private String getSmsCorpID(String[] smsMessageDetailsArray){
        String smsCorpID = "";
        for(String itr:smsMessageDetailsArray){
        	if(itr.contains(CommonDefs.ENROLL_DEVICE_RESP_SMS_CORP_ID)){
        		smsCorpID = itr.substring(itr.indexOf("=")+1, itr.length());
        	}
        }		
		return smsCorpID;
	}
	
	private String getSmsPassCode(String[] smsMessageDetailsArray){
        String smsPassCode = "";
        for(String itr:smsMessageDetailsArray){
        	if(itr.contains(CommonDefs.ENROLL_DEVICE_RESP_SMS_PASS_CODE)){
        		smsPassCode = itr.substring(itr.indexOf("=")+1, itr.length());
        	}
        }		
		return smsPassCode;
	}
}
