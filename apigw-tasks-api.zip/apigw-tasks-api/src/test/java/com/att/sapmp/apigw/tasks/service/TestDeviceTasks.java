package com.att.sapmp.apigw.tasks.service;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

public class TestDeviceTasks extends TestBase{

	
	@Value("${test.deviceId}")
	private String deviceId;
	
	@Value("${test.imei}")
	private String imei;	
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;		
	
	@Value("${test.enroll.device.task.basePath}")
	protected String basePath;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
        requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", deviceId);
        requestJson = requestJson.replaceAll("\\$\\{imei\\}", imei);
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
	}
	
	@Override
	protected String getBasePath() {
		return basePath;
	}

	
	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceDeEnrollmentIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
		headers.set("authorization", "Basic 123");
		//basePath="/devices/delete";
		headers.set("jobId","1234569901");
		headers.set("jobType","enrollDeviceTask");
		headers.set("jobInterval","0");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}
	
	@Test
	public void testGivenDeviceTasksWhenTaskServiceIsRestartedThenPreviouslyCreatedTasksSurviesRestart() {
		headers.set("jobId","1234568801");
		headers.set("jobType","enrollDeviceTask");
		headers.set("jobInterval","2");
		executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}
	
	@Test
	public void testGivenDeviceTasksWhenTaskIsPrimedToExecuteAndTargetServiceIsAvailableThenTargetServiceIsInvoked() {
		headers.set("jobId","1234567700");
		headers.set("jobType","enrollDeviceTask");
		headers.set("jobInterval","0");
		executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}

	//@Test
	////Deferred to 1710 Release QC #256958
	public void testGivenDeviceTasksWhenTaskIsPrimedToExecuteAndTargetServiceIsUnAvailableThenTargetServiceIsNotInvokedAndRetriedAfterConfiguredInterval() {
		headers.set("jobId","1234566601");
		headers.set("jobType","enrollDeviceTask");
		headers.set("jobInterval","0");
		executePost();
		//assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}	
	
	//@Test
	//Deferred to 1710 Release QC #256958
	public void testGivenDeviceTasksWhenTasksArePendingThenPendingTasksDetailsArePrintedInTheLogsPeriodically() {
		headers.set("jobId","1234565500");
		headers.set("jobType","enrollDeviceTask");
		headers.set("jobInterval","0");
		executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}
	
	@Test
	public void testGivenDeviceTasksWhenTargetTaskIsInvokedThenCorrespondingTrackingIdOfTheParentTaskIsPropagated() {
		headers.set("jobId","1234564401");
		headers.set("jobType","enrollDeviceTask");
		headers.set("jobInterval","0");
		executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}

}