package com.att.sapmp.apigw.tasks.model;

import org.springframework.stereotype.Component;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class Task {

	@JsonProperty
		  private String deviceId;
	@ApiModelProperty(value = "deviceId", example = "78140021")
		  public String getDeviceId() { return this.deviceId; }

		  public void setDeviceId(String deviceId) { this.deviceId = deviceId; }
		  @JsonProperty
		  private String imei;
		  @ApiModelProperty(value = "imei", example = "12348991")
		  public String getImei() { return this.imei; }

		  public void setImei(String imei) { this.imei = imei; }
		

}
