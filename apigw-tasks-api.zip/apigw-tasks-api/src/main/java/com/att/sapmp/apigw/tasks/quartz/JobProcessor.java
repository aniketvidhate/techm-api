package com.att.sapmp.apigw.tasks.quartz;

import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.quartz.JobDetail;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.tasks.service.TaskInitService;
import com.att.sapmp.apigw.tasks.exception.ApigwException;
import com.att.sapmp.apigw.tasks.exception.CErrorDefs;

@Component
public class JobProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(JobProcessor.class);

	public void execute(JobDetail jobDetail) throws ApigwException {
		String jobType= jobDetail.getJobDataMap().getString("jobType");
		String jobPayload = jobDetail.getJobDataMap().getString("jobPayload");
		Map<String , Object> hmHeaders = jobDetail.getJobDataMap().getWrappedMap();
		hmHeaders.remove("jobPayload");
		
		log.info("Processing Job with jobPayload :: " + jobPayload +" and headers::"+hmHeaders);
		
		invokeRoutes(jobType , jobPayload , hmHeaders);
	}

	private void invokeRoutes(String jobType , String body , Map<String, Object> hmHeaders) throws ApigwException {
		CamelContext camelctx = null;
		try {
			camelctx = TaskInitService.getCamelContext();
			ProducerTemplate template = camelctx.createProducerTemplate();
			template.requestBodyAndHeaders("direct:"+jobType, body, hmHeaders);
		} catch (Exception ex) {
			log.error("Caught Exception with error message::" + ex.getMessage(), ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);

		}

	}
}
