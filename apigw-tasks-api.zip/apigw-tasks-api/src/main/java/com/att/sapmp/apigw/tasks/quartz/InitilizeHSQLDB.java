package com.att.sapmp.apigw.tasks.quartz;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;

@Component
public class InitilizeHSQLDB {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InitilizeHSQLDB.class);
	private Connection con = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	
	@Value("${hsqldb.url}")
	private String hsqldburl;
	
	@Value("${hsqldb.userid}")
	private String userid;

	@Value("${hsqldb.password}")
	private String password;
	
	@Value("${hsqldb.sql}")
	private String hsqldbsql;


	/**
	 * @param args
	 * @throws SQLException
	 * @throws FileNotFoundException
	 * 
	 */
	public void initilize() throws Exception {

		try {
			Class.forName("org.hsqldb.jdbc.JDBCDriver");
			con = DriverManager.getConnection(hsqldburl, userid, password);

			log.info("Initializing the HSQLDB");
			stmt = con.createStatement();
			rs = stmt.executeQuery("SELECT * FROM QRTZ_TRIGGERS");
			while (rs.next()) {
				log.info("Tables are already present");
			}
		} catch (Exception ex) {
			String errorMessage = ex.getMessage();
			log.error("Caught Exception with error message::"+errorMessage, ex);
			if (errorMessage != null && errorMessage.contains("object not found")) {
				log.info("Got Exception while Initializing HSQLDB. Creating new Tables::");
				File initialFile = new File(hsqldbsql);
				InputStream targetStream = new FileInputStream(initialFile);
				importSQL(con, targetStream);
				log.info("Tables are created successfully");
			}
		} finally {

			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (con != null)
				con.close();
		}
	}

	public static void importSQL(Connection conn, InputStream in) throws SQLException {
		Scanner scn = new Scanner(in);
		scn.useDelimiter("(;(\r)?\n)|(--\n)");
		Statement st = null;
		try {
			st = conn.createStatement();
			while (scn.hasNext()) {
				String line = scn.next();
				if (line.startsWith("/*!") && line.endsWith("*/")) {
					int i = line.indexOf(' ');
					line = line.substring(i + 1, line.length() - " */".length());
				}

				if (line.trim().length() > 0) {
					st.execute(line);
				}
			}
		} finally {
			if (st != null)
				st.close();
			
			if(scn != null)
				scn.close();
		}
	}
}
