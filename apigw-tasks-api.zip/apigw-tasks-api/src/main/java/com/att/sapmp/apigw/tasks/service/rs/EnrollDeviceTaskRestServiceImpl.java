package com.att.sapmp.apigw.tasks.service.rs;


import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.tasks.model.Task;

@AjscService
public class EnrollDeviceTaskRestServiceImpl implements EnrollDeviceTaskRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(EnrollDeviceTaskRestServiceImpl.class);
	
	/*@Autowired
	InitializationService is;*/
	

	public EnrollDeviceTaskRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@POST 
	public void enrollTask(@HeaderParam(value = "jobId") String jobId,@HeaderParam(value = "jobType") String jobType,@HeaderParam(value = "jobInterval") String jobInterval,@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@RequestBody Task task)
 {	
		log.info("Received request in EnrollDeviceTaskRestServiceImpl API");
		
	}

}
