package com.att.sapmp.apigw.tasks.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class Device {

	Map<Object, Object> devices;

	public Map<Object, Object> getDevices() {
		return devices;
	}

	public void setDevices(Map<Object, Object> devices) {
		this.devices = devices;

	}
}
