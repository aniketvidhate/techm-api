package com.att.sapmp.apigw.tasks.service;

import org.apache.camel.CamelContext;
import org.quartz.Scheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.tasks.exception.ApigwException;
import com.att.sapmp.apigw.tasks.exception.CErrorDefs;
import com.att.sapmp.apigw.tasks.quartz.InitilizeHSQLDB;
import com.att.sapmp.apigw.tasks.quartz.SchedulerManager;
import com.att.sapmp.apigw.tasks.util.CommonUtil;

@Component
public class TaskInitService {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(TaskInitService.class);

	private static CamelContext camelContext;

	private static ApplicationContext appContext;
	
	private static boolean isInitialized = false;
	
	@Autowired
	private InitilizeHSQLDB ihdb;

	private TaskInitService() {

	}
	
	private void init() throws Exception {
		if (!isInitialized()) {
			ihdb.initilize();
			setInitialized(true);
		}
	}


	private static void initContext() throws ApigwException {
		try {
			appContext = new ClassPathXmlApplicationContext("/routes/tasksRoute.xml");
			CamelContext camelctx = (CamelContext) appContext.getBean("camel-task");
			setCamelContext(camelctx);
		} catch (Exception ex) {
			log.error("Caught Exception with error message::" + ex.getMessage(), ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}

	public static CamelContext getCamelContext() throws ApigwException {
		if (camelContext == null) {
			synchronized (TaskInitService.class) {
				if (camelContext == null) {
					initContext();
				}
			}
		}
		return camelContext;
	}

	public static void setCamelContext(CamelContext ctx) {
		camelContext = ctx;
	}

	private static void destroy() throws ApigwException {
		if (appContext != null) {
			Scheduler scheduler = SchedulerManager.getScheduler();
			CommonUtil.getSheculedJobs(scheduler);
			((ClassPathXmlApplicationContext) appContext).stop();
		}
	}
	

	public static boolean isInitialized() {
		return isInitialized;
	}

	public static void setInitialized(boolean isInitialized) {
		TaskInitService.isInitialized = isInitialized;
	}
}
