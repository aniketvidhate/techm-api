package com.att.sapmp.apigw.tasks.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;


import com.att.sapmp.apigw.tasks.model.Task;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = " APIGW Task")
@Produces({ MediaType.APPLICATION_JSON })
public interface EnrollDeviceTaskRestService {

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/enrollTask")
	@ApiOperation(
			value = "APIGW TASK",
			notes = " Its utilized to schedule tasks as per the configured interval to provide timer functionality."
			+"Once configured interval elapsed, scheduled task will be triggered and complete the processing for enrollment. "
			
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void enrollTask(@HeaderParam(value = "jobId") String jobId,@HeaderParam(value = "jobType") String jobType,@HeaderParam(value = "jobInterval") String jobInterval,@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@RequestBody Task task);

	
	
}