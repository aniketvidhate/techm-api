package com.att.sapmp.apigw.tasks.quartz;

import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;


@Component
public class EnrollJob implements Job {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(EnrollJob.class);

	@Override
	public void execute(JobExecutionContext jobContext) throws JobExecutionException {	
		
		try {
			log.info("EnrollDeviceJob start: " + jobContext.getFireTime());
			
			JobDetail jobDetail = jobContext.getJobDetail();
			
			JobProcessor jobProcess = new JobProcessor();
			jobProcess.execute(jobDetail);
			
			log.info("EnrollJob end with key : " + jobDetail.getKey());
			
		} catch (Exception ex) {
			log.error("Caught Exception with error message::" + ex.getMessage() , ex);
			//throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}		
	}
}
