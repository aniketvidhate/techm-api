package com.att.sapmp.apigw.tasks.quartz;
import static org.quartz.DateBuilder.futureDate;

import org.quartz.DateBuilder.IntervalUnit;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.stereotype.Component;

@Component
public class EnrollTrigger {
		
	public static Trigger getEnrollDeiveTrigger(String triggerName, String triggerGroup, Integer timeInterval) {

		Trigger trigger = null;
		trigger = TriggerBuilder.newTrigger()
				.withIdentity(triggerName, triggerGroup)
				.startAt(futureDate(timeInterval, IntervalUnit.MINUTE))			
				.build();
		return trigger;
	}

}


