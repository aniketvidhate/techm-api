package com.att.sapmp.apigw.tasks.util;

public class CommonDefs {

	public static final String BILLING_ID = "billingId";
	public static final String ACCOUNT_PASS_PHRASE = "AccountPassPhrase";
	public static final String USER_NAME = "userName";
	public static final String PASSWORD = "password";
	public static final String AUTH_TOKEN = "authToken";
	public static final String EXPIRATION_TIME = "expirationTime";

	public static final String PARTNER_ACCOUNT = "partnerAccount";
	public static final String[] NON_ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductcode",
			"accountpassphrase" };
	public static final String[] ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductCode" };

	public static final String SEARCH_CRITERIA = "searchcriteria";
	public static final String EMM_ACCOUNT_ID = "emmAccountId";
	public static final String TENANT_ACCOUNT_ID = "tenantAccountId";
	public static final String DEVICE_LIST = "deviceList";
	public static final String DEVICE_IDS = "deviceIds";
	public static final String DEVICE_ID = "deviceId";
	public static final String POLICY_NAME = "policyName";
	public static final String POLICY_DETAILS = "policyDetails";

	public static final String SPACE_EXPR = "\\s+";
	public static final String BLANK_CHAR = "%20";

	public static final int MAX_NO_OF_DEVICES = 100;

	public static final String IBM_URL = "IBMUrl";
	public static final String[] WIPE_DEVICE_MANDATORY_FIELDS = { "emmAccountId", "wipeType" };

	// Constants for Accounts APIs
	public static final String ACCOUNT = "account";
	public static final String ACCOUNTS = "accounts";
	public static final String ACCOUNT_STATUS = "accountStatus";

	public static final String CAMEL_HTTP_RESPONSE_CODE = "CamelHttpResponseCode";
	public static final String CAMEL_HTTP_URL = "CamelHttpUrl";
	public static final String EMM_PRODUCT_CODE = "emmproductcode";
	public static final String TRACKING_ID = "trackingid";
	public static final String DEENROLL_ORCH_URL = "deenroll.device.url";
	public static final String DEENROLL_IBMURL = "IBMUrl_DE_ENROLL";
	public static final String DEVICE = "device";
	public static final String DEVICES = "devices";
	public static final String[] DEVICE_DEENROLL_MANDATORY_FIELDS = { CommonDefs.EMM_ACCOUNT_ID,
			CommonDefs.DEVICE_IDS };

	// Added for Lock Device MDM API
	public static final String MASS_360_DEVICE_ID = "maas360DeviceID";
	public static final String ACTION_STATUS = "actionStatus";
	public static final String ZERO = "0";
	public static final String IBM_LOCK_DEVICE_FINAL_URL = "IBMlockDeviceFinalURL";
	public static final String RESPONSE_ACCEPT_CODE = "202";
	public static final String EMAIL = "email";
	public static final String DOMAIN = "domain";
	public static final String DATE = "Date";

	public static final String IBM_CREATE_USER_URL = "IBMCreateUserUrl";
	public static final String STATUS = "status";
	public static final String RESPONSE_CREATED_CODE = "201";

	// Added for Enroll Device MDM API
	public static final String ENROLLMENTS = "enrollments";
	public static final String ENROLLMENT = "enrollment";
	public static final String ENROLLMENT_LIST = "enrollmentList";
	public static final String IBM_ENROLL_DEVICE_URL = "IBMEnrollDeviceUrl";
	public static final String USER = "user";
	public static final String FIRST_NAME = "firstName";
	public static final String LAST_NAME = "lastName";
	public static final String EMAIL_ADDRESS = "emailAddress";
	public static final String EMAIL_USER = "emailUser";
	public static final String EMAIL_ADMIN = "emailAdmin";
	public static final String EMAIL_OTHER = "emailOther";
	public static final String SEND_SMS_USER = "sendSMSUser";
	public static final String NO = "No";
	public static final String URL = "url";
	public static final String CORPORATE_IDENTIFIER = "corporateIdentifier";
	public static final String ENROLLMENTID = "enrollmentId";
	public static final String PASSCODE = "passcode";
	public static final String QR_CODE_URL = "qrCodeURL";
	public static final String ENTER_MANDATORY_FIELDS = "Please provide mandatory fields";

	// Added for Compliance-apn orchestration services
	public static final String MDM_NOTIFICATION = "mdmNotification";
	public static final String EVENT_TYPE = "eventType";
	public static final String DEVICE_EVENT_LIST = "deviceEventList";
	public static final String DEVICE_EVENT = "deviceEvent";
	public static final String MDM_NOTIFICATION_RESPONSE = "mdmNotificationResponse";
	public static final String DEVICE_COMPLAINT_EVENT = "deviceComplianceEvent";
	public static final String DEVICE_STATE_CHANGE_EVENT = "deviceStateChangeEvent";
	public static final String POLICY_COMPLAINCE_STATUS = "policyComplianceStatus";
	public static final String OOC_REASON = "oocReason";
	public static final String COMPLAINCE_STATUS = "ComplianceStatus";
	public static final String EVENT_SUB_TYPE = "eventSubType";
	public static final String DEVICE_STATUS = "deviceStatus";
	public static final String DEVICE_SUB_TYPE = "deviceSubStatus";
	public static final String SYNC_DEVICE = "syncDevice";
	public static final String ACTIVE = "ACTIVE";
	public static final String INACTIVE = "INACTIVE";
	public static final String ENROLLED = "ENROLLED";
	public static final String ENROLLMENT_SUCCESS = "EnrollmentSuccess";
	public static final String ENROLLMENT_SUCCESS_CDF = "ENROLLMENT_SUCCESS";
	public static final String DEENROLLMENT_SUCCESS = "DeEnrollmentSuccess";
	public static final String DEENROLLMENT_SUCCESS_CDF = "DEENROLLMENT_SUCCESS";
	public static final String PROFILE_ID = "profileId";
	public static final String ACTION_TYPE = "actionType";
	public static final String INSTALL_APP = "InstallApp";
	public static final String REMOVE_APN = "RemoveAPN";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String INSTALL_APP_URL = "INSTALL_APP_URL";
	public static final String APPLY_REMOVE_APN_URL = "APPLY_REMOVE_APN_URL";
	public static final String EMM_DEVICE_ID = "emmDeviceId";
	public static final String IMEI_ESN = "imeiEsn";
	public static final String IN_COMPLIANCE = "IN_COMPLIANCE";

	// Constants for History API
	public static final String ACT_EXECUTION_TIME_FROM = "actionExecutionTimeFrom";
	public static final String ACT_EXECUTION_TIME_TO = "actionExecutionTimeTo";
	public static final String ACT_STATUS_RESPONSE = "actionStatusResponses";
	public static final String ACT_STATUS_RESP = "actionStatusResponse";
	public static final String[] Action_History_Mandatory_Param = { "actionExecutionTimeFrom", "actionExecutionTimeTo",
			"emmAccountId", "deviceId" };
	// Constants for DeleteApp API
	public static final String APLICATIONS = "applications";
	public static final String APLICATION = "application";
	public static final String APP_ID = "appId";
	public static final String APP_TYPE = "appType";
	public static final String DESCRIPTION = "description";
	public static final String APP_LIST = "appList";
	public static final String[] Delete_App_Mandatory_Param = { "appId", "appType", "emmAccountId" };

	public static final String TARGET_DEVICES = "targetDevices";
	public static final String SEND_NOTIFICATION = "sendNotification";
	public static final String SEND_EMAIL = "sendEmail";
	public static final String INSTANT_INSTALL = "instantInstall";

	public static final String PRODUCT_CODE = "productCode";
	public static final String EMMP_PRODUCT_CODE = "EMMProductCode";
	public static final String ORIGIONAL_BODY = "origionalBody";
	public static final String ERROR_CODE_STR = "errorCode";
	public static final String MESSAGE = "message";
	public static final String AUTHORIZATION = "Authorization";

	// Added for Enrollment Device
	public static final String PLATFORM = "platform";
	public static final String DEVICE_JSON = "device";
	public static final String PROFILE_JSON = "profile";
	public static final String SECURITY_POLOCY_CODE = "securityPolicyCode";
	public static final String PASSCODE_POLOCY_CODE = "passcodePolicyCode";
	public static final String UNDERSCORE = "_";
	public static final String SPACE = " ";
	public static final String POLICYSET = "policySet";
	public static final String BAN = "ban";
	public static final String FAN = "fan";
	public static final String CTN = "ctn";
	public static final String FULLNAME = "fullname";

	// Added for createUser
	public static final String[] CREATE_USER_MANDATORY_FIELDS = { CommonDefs.CTN, CommonDefs.EMAIL, CommonDefs.DOMAIN };

	public static final String ID = "id";
	public static final String IMEI = "imei";
	public static final String GROUP_ID = "groupId";
	public static final String GROUP_NAME = "groupName";
	public static final String PROFILE_NAME = "profileName";
	public static final String NETWORK_CONTROL = "networkControl";
	public static final String PASSCODE_POLICY_CODE = "passcodePolicyCode";
	public static final String SECURITY_PASS_CODE = "securityPolicyCode";
	public static final String FAN_NAME = "fanName";
	public static final String EMAIL_ADDRESS_AMLL_CASE = "emailaddress";
	public static final String GROUP_JSON = "group";
	public static final String LINEID = "lineId";

	// Added for manageAPN
	public static final String RESPONSE_SUCCESS_CODE = "200";
	public static final String INQUIRE_PROFILE_URL = "inquireProfileUrl";
	public static final String INQUIRE_ADDP_DEVICE_URL = "inquireADDPDeviceUrl";
	public static final String MANAGE_APN_URL = "manageAPNUrl";
	public static final String UPDATE_CDF_URL = "updateCdfUrl";
	public static final String MANAGE_APN = "manageAPN";
	public static final String ACTION_TYPE_APPLY = "Apply";
	public static final String ACTION_TYPE_REMOVE = "Remove";
	public static final String DEVICE_DETAILS_APNSTATUS = "device_details_APNstatus";
	public static final String APNSTATUS = "apnStatus";
	public static final String SUCCESS_CODE = "Success";

	// Added for JSON transformation
	public static final String JSON_DEVICE_ID_KEY = "deviceId";
	public static final String JSON_DEVICE_IMEI_KEY = "deviceImei";
	public static final String JSON_DEVICE_PLATFORM_KEY = "devicePlatform";
	public static final String JSON_USER_FIRSTNAME_KEY = "userFirstName";
	public static final String JSON_USER_LASTNAME_KEY = "userLastName";
	public static final String JSON_USER_CTN_KEY = "userCtn";
	public static final String JSON_USER_EMAIL_KEY = "userEmail";
	public static final String JSON_USER_DOMAIN_KEY = "userDomain";
	public static final String JSON_USER_BAN_KEY = "userBan";
	public static final String JSON_GROUPD_GROUPID_KEY = "groupGroupId";
	public static final String JSON_GROUP_GROUPNAME_KEY = "groupGroupName";
	public static final String JSON_PROFILE_PROFILEID_KEY = "profileProfileId";
	public static final String JSON_PROFILE_PROFILENAME_KEY = "profileProfileName";
	public static final String JSON_PROFILE_NETWORKCONTROL_KEY = "profileNetworkControl";
	public static final String JSON_PROFILE_PASSCODEPOLICYCODE_KEY = "profilePasscodePolicyCode";
	public static final String JSON_PROFILE_SECURITYPOLICYCODE_KEY = "profileSecurityPolicyCode";
	public static final String NULL_KEY = "NULL_KEY";
	public static final String[] ENROLL_DEVICE_ORCH_MANDATORY_FIELDS = { "emmAccountId", "liabilityType", "lineId",
			"id", "imei", "platform", "ban", "ctn", "email", "domain", "groupId", "groupName", "profileId",
			"profileName", "networkControl", "passcodePolicyCode", "securityPolicyCode" };
	public static final String LIABILITY_TYPE = "liabilityType";

	// Added for Apple sign/upload certs
	public static final String REQUEST_PATH_BILLINGID = "billingId";
	public static final String GROUP_ACCOUNTS = "accounts";
	public static final String UPLOADCERTS_REQUEST_PAYLOAD_APPLEMDMCERTFILE = "appleMdmCertfile";
	public static final String UPLOADCERTS_REQUEST_PAYLOAD_CERTIFICATEPHRASE = "certificatePhrase";
	public static final String[] UPLOADCERTS_MANDATORY_FIELDS = { UPLOADCERTS_REQUEST_PAYLOAD_APPLEMDMCERTFILE,
			UPLOADCERTS_REQUEST_PAYLOAD_CERTIFICATEPHRASE };
	public static final String SIGNCERTS_REQUEST_PAYLOAD_UNSIGNEDCSR = "unsignedCSR";
	public static final String[] SIGNCERTS_MANDATORY_FIELDS = { SIGNCERTS_REQUEST_PAYLOAD_UNSIGNEDCSR };

	// Added for the CSI integration - Manage ADDP Device Details
	public static final String INFRASTRUCTURE_VERSION = "infrastructureVersion";
	public static final String APPLICATION_NAME = "applicationName";
	public static final String VERSION = "version";
	public static final String MESSAGE_ID = "messageId";
	public static final String ROUTING_REGION_OVERRIDE = "routingRegionOverride";
	public static final String DATE_TIMESTAMP = "dateTimeStamp";
	public static final String USER_PASSWORD = "userPassword";
	public static final String SEQUENCE_NUMBER = "sequenceNumber";
	public static final String TOTAL_IN_SEQUENCE = "totalInSequence";
	public static final String MODE = "mode";
	public static final String ENROLLMENT_STATUS = "enrollmentStatus";
	public static final String ACTIVITY_TYPE = "activityType";
	public static final String ACTIVITY_CATEGORY = "activityCategory";
	public static final String ACTIVITY_DETAILS = "activityDetails";
	public static final String SOURCE = "source";
	public static final String ACTIVITY_DATE = "activityDate";
	public static final String ENROLLMENT_SUB_STATUS = "enrollmentSubStatus";
	public static final String DEENROLLMENT_INITIATED = "DEENROLLMENT_INITIATED";
	public static final String DEENROLLMENT_FAILED = "DEENROLLMENT_FAILED";
	public static final String MDM_DEENROLLMENT_PENDING = "MDM_DEENROLLMENT_PENDING";
	public static final String MDM_DEENROLLMENT_FAILED = "MDM_DEENROLLMENT_FAILED";
	public static final int ZERO_INT = 0;
	public static final int ONE_INT = 1;
	public static final String ONE = "1";
	public static final String ENROLLMENT_FAILED = "ENROLLMENT_FAILED";
	public static final String CREATE_DEVICE_USER_FAILED = "CREATE_DEVICEUSER_FAILED";
	public static final String ENROLLMENT_INITIATED = "ENROLLMENT_INITIATED";
	public static final String MDM_ACTIVATION_PENDING = "MDM_ACTIVATION_PENDING";
	public static final String ENROLL_DEVICE_FAILED = "ENROLL_DEVICE_FAILED";

	// Added for the CSI integration - Inquire ADDP Device Detail
	public static final String CUSTOMER_TELEPHONE_NUMBER = "customerTelephoneNumber";

	// Added for the CSI integration - sendSms
	public static final String DESTINATION_ADDRESS = "destinationAddress";
	public static final String SOURCE_ADDRESS = "sourceAddress";
	public static final String SHORT_MESSAGE = "shortMessage";
	public static final String SMSPARAMETERS = "smsParameters";

	public static final String RESPONSE_SUCCESS_MSG = "SUCCESS";

}
