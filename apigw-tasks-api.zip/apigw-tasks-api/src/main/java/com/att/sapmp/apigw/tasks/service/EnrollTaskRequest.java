package com.att.sapmp.apigw.tasks.service;

import java.util.Arrays;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.tasks.exception.ApigwException;
import com.att.sapmp.apigw.tasks.exception.CErrorDefs;
import com.att.sapmp.apigw.tasks.quartz.EnrollJob;
import com.att.sapmp.apigw.tasks.quartz.EnrollTrigger;
import com.att.sapmp.apigw.tasks.quartz.SchedulerManager;
import com.att.sapmp.apigw.tasks.util.CommonDefs;
import com.att.sapmp.apigw.tasks.util.CommonUtil;

@Component
public class EnrollTaskRequest {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(EnrollTaskRequest.class);
	
	@Value("${valid.tasks}")
	private String validTasks;
	
	@Value("${valid.headers}")
	private String validHeaders;
	
	public final void process(Exchange e) throws ApigwException {

		try {
			
			boolean bValidTask = false;
			
			String postReq = (String) (e.getIn().getBody());
			if (StringUtils.isEmpty(postReq)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CErrorDefs.ERROR_CODE_1002_DESCRIPTION);
			}
			
			log.info("Received request in process method with payload::"+postReq);
			
			JobDataMap jobMap = new JobDataMap();
			
			if (validHeaders != null) {
				List<String> alHeaderList = Arrays.asList(validHeaders.split("\\|"));
				if (alHeaderList != null && !alHeaderList.isEmpty()) {
					for (String header : alHeaderList){
						String inputHeaderVal = (String) (e.getIn().getHeader(header));
						if(StringUtils.isEmpty(inputHeaderVal)){
							throw new ApigwException(CErrorDefs.ERROR_CODE_1001, header+" is missing in input Headers");
						}
						
						jobMap.put(header, inputHeaderVal);
					}
				}
			}
			
			
			//Check if input jobType is valid.
			String jobId = (String) (e.getIn().getHeader("jobId"));
			String timeInterval = (String) (e.getIn().getHeader("jobInterval"));
			String jobType = (String) (e.getIn().getHeader("jobType"));

			if (validTasks != null) {
				List<String> alTaskList = Arrays.asList(validTasks.split("\\|"));
				if (alTaskList.contains(jobType)) {
					bValidTask = true;
				}
			}
			
			if(!bValidTask){
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "Input jobType is not valid");
			}
			
			jobMap.put("jobPayload", e.getIn().getBody());
			
			JobDetail enrollJob = JobBuilder.newJob(EnrollJob.class)
					.withIdentity(jobId, jobType)
					.usingJobData(jobMap)
					.build();

	         Trigger enrollTrigger = EnrollTrigger.getEnrollDeiveTrigger(jobId, jobType, Integer.parseInt(timeInterval));
	        

	        Scheduler scheduler = SchedulerManager.getScheduler();
			scheduler.scheduleJob(enrollJob, enrollTrigger);
			
			// Log all the Scheduled job details
			CommonUtil.getSheculedJobs(scheduler);
			
			
		} catch (ApigwException iaex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_400);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, iaex.getErrorMsg());
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, iaex.getErrorCode());
			log.error("Caught ApigwException with error message::"+iaex.getErrorMsg(), iaex);
			throw new ApigwException(iaex.getErrorCode(), iaex.getErrorMsg());
		
		
		}catch (Exception ex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_500);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, CErrorDefs.SYSTEM_ERROR);
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_5001);
			log.error("Caught Exception with error message::"+ex.getMessage(), ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}


	

}