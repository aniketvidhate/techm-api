package com.att.sapmp.apigw.tasks.quartz;

import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.tasks.exception.ApigwException;
import com.att.sapmp.apigw.tasks.exception.CErrorDefs;
import com.att.sapmp.apigw.tasks.util.CommonUtil;

@Component
public class SchedulerManager {

	private static Scheduler stdScheduler;
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(SchedulerManager.class);

	public static Scheduler getScheduler() throws ApigwException {
		if (stdScheduler == null) {
			try {
				stdScheduler = StdSchedulerFactory.getDefaultScheduler();				
				stdScheduler.start();
			} catch (SchedulerException se) {
				log.error("Exception in getScheduler method with error message::"+se.getMessage(), se);
				throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
			}
		}
		return stdScheduler;
	}

	public static void startScheduler() throws ApigwException {
		try {
			if (stdScheduler != null && !stdScheduler.isStarted()) {
				stdScheduler.start();
			}
		} catch (SchedulerException se) {
			log.error("Caught Exception with error message::"+se.getMessage(), se);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}
	
	public static void stopScheduler() throws ApigwException {
		try {
			if (stdScheduler != null && !stdScheduler.isShutdown()) {
				stdScheduler.shutdown(); //Wait till the jobs are completed.
			}
		} catch (SchedulerException se) {
			log.error("Caught Exception with error message::"+se.getMessage(), se);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}	
}
