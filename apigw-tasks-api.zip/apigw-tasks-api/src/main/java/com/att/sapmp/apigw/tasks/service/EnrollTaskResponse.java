package com.att.sapmp.apigw.tasks.service;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.tasks.exception.ApigwException;
import com.att.sapmp.apigw.tasks.util.CommonDefs;

@Component
public class EnrollTaskResponse {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(EnrollTaskResponse.class);
	

	public final void handleEnrollTaskResponse(Exchange e) throws ApigwException {	
		log.info("In handleEnrollTaskResponse method after scheduling task");
		e.getOut().setHeader("CamelHttpResponseCode", "202");
		//e.getOut().setBody(null);
		}
	
	public final void processTaskResponse(Exchange e) throws ApigwException {
		String responseBody = e.getIn().getBody(String.class);
		String stResponseCode =  String.valueOf(e.getIn().getHeader("CamelHttpResponseCode"));
		log.info("Received response in processTaskResponse method with HttpResponseCode ::" + stResponseCode
				+ " :: responseBody::" + responseBody + " :: trackingId::"
				+ e.getIn().getHeader(CommonDefs.TRACKING_ID));
	}
}
