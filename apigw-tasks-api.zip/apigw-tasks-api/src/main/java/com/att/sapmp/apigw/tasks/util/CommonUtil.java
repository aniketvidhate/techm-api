package com.att.sapmp.apigw.tasks.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.impl.matchers.GroupMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.tasks.exception.ApigwException;
import com.att.sapmp.apigw.tasks.exception.CErrorDefs;

@Component
public class CommonUtil {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CommonUtil.class);

	public static final String DATEFORMAT = "yyyy-MM-dd'T'hh:mm:ss.'000Z'";
	@Autowired
	private Environment env;

	@Value("${product.code}")
	private String stProduct;

	public boolean isProductCodeValid(String inProductCode) {
		boolean bValid = false;
		// String stProduct = null;
		if (stProduct != null) {
			List<String> alList = Arrays.asList(stProduct.split("\\|"));
			if (inProductCode != null && alList.contains(inProductCode.toLowerCase())) {
				bValid = true;
			}
		}
		return bValid;

	}

	public List<String> getAsArrayList(String inValue) {
		List<String> alResponse = new ArrayList<String>();
		if (!StringUtils.isEmpty(inValue)) {
			alResponse.add(inValue);
		}
		return alResponse;

	}

	public static String getGMTdatetimeAsString() {
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}

	public String getProperty(final String propKey) {
		String propValue = null;
		if (!StringUtils.isEmpty(propKey)) {
			propValue = env.getProperty(propKey.toLowerCase());
		}
		return propValue;
	}
	
	public static void getSheculedJobs(Scheduler scheduler) throws ApigwException {
		try {
			for (String groupName : scheduler.getJobGroupNames()) {
				Set<JobKey> jobSet = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName));
				log.info("Logging Scheduled Job Details for groupName = " + groupName + " :: Total Scheduled Jobs = "
						+ jobSet.size());
				for (JobKey jobKey : jobSet) {
					String jobName = jobKey.getName();
					String jobGroup = jobKey.getGroup();
					// get job's trigger
					List<Trigger> triggers = (List<Trigger>) scheduler.getTriggersOfJob(jobKey);
					Date nextFireTime = triggers.get(0).getNextFireTime();
					log.info("[jobName] : " + jobName + " [groupName] : " + jobGroup + " [scheduledTime] : "
							+ nextFireTime);
				}
			}
		} catch (Exception ex) {
			log.error("Caught Exception in getSheculedJobs method with error message::", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);

		}

	}

}
