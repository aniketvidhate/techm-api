package com.att.sapmp.apigw.accounts.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class AppleCert {
	
	@JsonProperty
	  private String unsignedCSR;
	@ApiModelProperty(value = "unsignedCSR", example = "ASDGHKLSHSJALSH")
	  public String getUnsignedCSR() { return this.unsignedCSR; }

	  public void setUnsignedCSR(String unsignedCSR) { this.unsignedCSR = unsignedCSR; }
	}

