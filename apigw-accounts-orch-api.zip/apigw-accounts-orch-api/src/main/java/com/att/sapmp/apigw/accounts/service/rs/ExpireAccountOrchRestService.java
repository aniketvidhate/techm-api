package com.att.sapmp.apigw.accounts.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Expire an Account")
@Produces({ MediaType.APPLICATION_JSON })
public interface ExpireAccountOrchRestService {

	@DELETE
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/accounts/{emmAccountId}")
	@ApiOperation(
			value = "Supports expiring an account which also expires all the devices under the account.",
					
			notes = "This operation will set the status of account to expire."
					+ "This operation will de-enroll all the devices under the account and expiring the account. "
					
			
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void expireAccount(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@PathParam("emmAccountId") String emmAccountId);
	
}