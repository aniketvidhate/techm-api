package com.att.sapmp.apigw.accounts.service;

import org.apache.camel.Exchange;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.util.CommonDefs;


public class AppleCertResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(AppleCertResponseProcessor.class);

	public final void handleResponse(Exchange e) throws ApigwException {
		String respBody = e.getIn().getBody(String.class);
		log.info("Received response in handleResponse method with HttpResponseCode:: "+e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		e.getOut().setHeaders(e.getIn().getHeaders());
		e.getOut().setBody(respBody);
	}
}
