package com.att.sapmp.apigw.accounts.service;

import java.net.URLEncoder;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author pg238s
 *
 */
@Component
public class InquireAccountRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InquireAccountRequestProcessor.class);

	public final void execute(Exchange e) throws ApigwException {

		String searchcriteria = (String) (e.getIn().getHeader(CommonDefs.SEARCH_CRITERIA));

		log.info("Received searchcriteria in InquireAccountRequestProcessor.execute() method:: " + searchcriteria);

		if (searchcriteria == null || searchcriteria.isEmpty()) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "searchcriteria  is null in input");
		}

		// create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// convert json string to object
		HashMap<String, Object> hmSearch = null;
		try {
			hmSearch = objectMapper.readValue(searchcriteria, HashMap.class);

			if (hmSearch != null && !hmSearch.isEmpty()) {
				String emmAccountId = (String) hmSearch.get(CommonDefs.EMM_ACCOUNT_ID);
				String accountName = (String) hmSearch.get(CommonDefs.ACCOUNT_NAME);
				String productCode = (String) hmSearch.get(CommonDefs.PRODUCT_CODE);

				if (StringUtils.isEmpty(emmAccountId) && StringUtils.isEmpty(accountName)
						&& StringUtils.isEmpty(productCode)) {
					throw new ApigwException(CErrorDefs.ERROR_CODE_1001,
							"One of emmAccountId or accountName or productCode is required in input.");
				}

				if (!StringUtils.isEmpty(accountName)) {
					accountName = URLEncoder.encode(accountName, "UTF-8");
					hmSearch.put(CommonDefs.ACCOUNT_NAME, accountName);
				}
				
				JSONObject searchJson = new JSONObject(hmSearch);
				e.getIn().setHeader(CommonDefs.SEARCH_CRITERIA , searchJson);
			}
		} catch (Exception ex) {
			log.debug("Exception occurred while processing InquireAccount request: " + ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
	}

}