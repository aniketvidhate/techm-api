package com.att.sapmp.apigw.accounts.service.rs;


import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.model.CreateAccount;

@AjscService
public class CreateaTenantAccountOrchRestServiceImpl implements CreateaTenantAccountOrchRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateaTenantAccountOrchRestServiceImpl.class);
	

	public CreateaTenantAccountOrchRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@POST 
	public void createTenantAccount(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@RequestBody  CreateAccount createAccount) {	
		log.info("Received request in CreateaTenantAccountRestServiceImpl API");
		
	}

}
