package com.att.sapmp.apigw.accounts.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.util.CommonDefs;
import com.att.sapmp.apigw.accounts.util.CommonUtil;

@Component
public class CsiManageDeviceProfileResponse {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CsiManageDeviceProfileResponse.class);
	
	@Autowired
	private CommonUtil commonUtil;

	public final void handleCdfResponse(Exchange e) throws ApigwException {

		String respBody = e.getIn().getBody(String.class);
		log.info("Received HTTPResponseCode in handleCdfUpdateResponse method=" + e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));	
		String stHttpResponseCode = null;
		if (e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) != null) {
			stHttpResponseCode = String.valueOf(e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		}
		
		//log.info("Received response in handleCdfUpdateResponse method=" + respBody);
		commonUtil.logXML("Received response in handleCdfUpdateResponse method", respBody);

		String cdfUpdate = "SUCCESS";
		if (stHttpResponseCode != null && !stHttpResponseCode.equalsIgnoreCase(CommonDefs.RESPONSE_SUCCESS_CODE)) {
			cdfUpdate = "FAILURE";
		}

		String responseHeader = (String) e.getProperty(CommonDefs.RESPONSE_HEADER);
		if (responseHeader != null && !responseHeader.isEmpty()) {
			e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, responseHeader);
		}

		Object oResponse = e.getProperty(CommonDefs.RESPONSE_BODY);
		if (oResponse != null && oResponse instanceof HashMap) {
			HashMap<String, Object> hmResponse = (HashMap<String, Object>) oResponse;
			if (hmResponse != null && !hmResponse.isEmpty()) {
				hmResponse.put(CommonDefs.KEY_ACCOUNT_PASS_PHRASE, e.getProperty(CommonDefs.ACCOUNT_PASS_PHRASE));
				hmResponse.put(CommonDefs.ACCOUNT_STATUS, e.getProperty(CommonDefs.ACCOUNT_STATUS));
				hmResponse.put(CommonDefs.KEY_CDF_UPDATE, cdfUpdate);
				JSONObject jsonAccount = new JSONObject();
				jsonAccount.put(CommonDefs.ACCOUNT, hmResponse);
				e.getIn().setBody(jsonAccount);
			}
		}

	}

}
