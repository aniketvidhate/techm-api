package com.att.sapmp.apigw.accounts.service;

import org.apache.camel.Exchange;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.cxf.common.util.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.oce.voltage.api.VoltageEfpeFormatType;
import com.att.oce.voltage.api.VoltageHelper;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.util.CommonDefs;

/**
 * @author av0041
 *
 */
@Component
public class CreateTenantAccountRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateTenantAccountRequestProcessor.class);

	@Value("${tenant.account.email}")
	private String tenantEmail;

	@Value("${voltage.enabled}")
	private String voltageEnabled;

	public final void execute(Exchange e) throws ApigwException {

		String postReq = (String) (e.getIn().getBody());
		log.info("Input request to CreateTenantAccountOrchRequest=" + postReq);
		if (StringUtils.isEmpty(postReq)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CErrorDefs.ERROR_CODE_1002_DESCRIPTION);
		}
		postReq = injectHashPassword(postReq, e);

		// setting tenantAccountId
		JSONObject postReqJSON = new JSONObject(postReq);
		String fan = (String) postReqJSON.get(CommonDefs.FAN);
		String productCode = (String) e.getIn().getHeader(CommonDefs.EMM_PRODUCT_CODE);
		e.setProperty(CommonDefs.TENANT_ACCOUNT_ID, fan.trim() + productCode.trim());
		e.getIn().setBody(postReq);
	}

	/**
	 * Modifies post request to add the hashed password
	 * 
	 * @param postReq
	 * @throws ApigwException
	 */
	private String injectHashPassword(String postReq, Exchange e) throws ApigwException {
		String postReqFinal = "";
		JSONObject postReqJSON = new JSONObject(postReq);
		// Check if input has a required params
		validateJSON(postReqJSON, CommonDefs.CREATE_ACCOUNT_REQUIRED_PARAMS);
		String fan = (String) postReqJSON.get(CommonDefs.FAN);
		String email = (String) postReqJSON.get(CommonDefs.EMAIL);

		if (email == null || !email.equalsIgnoreCase(tenantEmail)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1002, "Input Email not matched with configured value");
		}

		try {
			String hashtext = passwordAlgorithm(fan);

			if (voltageEnabled != null && voltageEnabled.equalsIgnoreCase(CommonDefs.Y)) {
				// Encrypt password to Voltage Encrypted value to store in CDF
				VoltageHelper volHelper = commonUtil.getVoltageHelper();
				String voltagePassPhrase = volHelper.encrypt(hashtext, VoltageEfpeFormatType.valueOf("B64_GENERIC"));
				log.info("Voltage Call Initiated. Received Encrypted Password");
				e.setProperty(CommonDefs.ACCOUNT_PASS_PHRASE, voltagePassPhrase);
			} else {
				e.setProperty(CommonDefs.ACCOUNT_PASS_PHRASE, fan);
			}
			postReqJSON.put("password", hashtext);
			postReqFinal = postReqJSON.toString();
			return postReqFinal;
		} catch (Exception ex) {
			log.error("Error occured while injectHashPassword method", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}

	private String passwordAlgorithm(String fan) throws ApigwException {
		try {
			String hashtext = null;
			/*
			 * MessageDigest m = MessageDigest.getInstance("MD5"); m.reset();
			 * m.update(fan.getBytes()); byte[] digest = m.digest(); BigInteger
			 * bigInt = new BigInteger(1, digest); hashtext =
			 * bigInt.toString(36);
			 */
			hashtext = RandomStringUtils.randomAlphanumeric(15);
			return hashtext;
		} catch (Exception ex) {
			log.error("Error occured while generating passsword", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}

	}

}