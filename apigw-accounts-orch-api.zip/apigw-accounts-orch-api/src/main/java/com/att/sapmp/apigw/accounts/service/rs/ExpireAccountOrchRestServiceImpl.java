package com.att.sapmp.apigw.accounts.service.rs;


import javax.ws.rs.DELETE;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;

@AjscService
public class ExpireAccountOrchRestServiceImpl implements ExpireAccountOrchRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ExpireAccountOrchRestServiceImpl.class);
	

	public ExpireAccountOrchRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@DELETE 
	@Path("/accounts/{emmAccountId}")
	public void expireAccount(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@PathParam("emmAccountId") String emmAccountId) {	
		log.info("Received request in ExpireAccountRestServiceImpl API. billingId="+emmAccountId);
		
	}

}
