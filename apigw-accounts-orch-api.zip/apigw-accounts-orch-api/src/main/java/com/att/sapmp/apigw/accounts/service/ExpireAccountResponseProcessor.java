package com.att.sapmp.apigw.accounts.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.model.Devices;
import com.att.sapmp.apigw.accounts.util.CommonDefs;
import com.att.sapmp.apigw.accounts.exception.ApigwException;

/**
 * @author pg238s
 *
 */
@Component
public class ExpireAccountResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ExpireAccountResponseProcessor.class);

	public final void handleInquireDeviceResponse(Exchange e) throws ApigwException {

		Devices oDev = (Devices) e.getIn().getBody();

		Object oDevices = oDev.getDevices().get(CommonDefs.DEVICE);

		HashMap<String, Object> hmDevicesResponse = new HashMap<>();
		ArrayList<String> alDevice = new ArrayList<>();
		if (oDevices instanceof ArrayList) {
			ArrayList<HashMap> alDevicesList = (ArrayList<HashMap>) oDevices;
			for (HashMap<String, Object> hmDevice : alDevicesList) {
				String stDeviceId = (String) hmDevice.get(CommonDefs.DEVICE_ID);
				if (stDeviceId != null && !stDeviceId.isEmpty()) {
					alDevice.add(stDeviceId);
				}
			}

			hmDevicesResponse.put(CommonDefs.DEVICE, alDevice);
		} else if (oDevices instanceof HashMap) {
			HashMap<String, Object> hmDevice = (HashMap<String, Object>) oDevices;
			String stDeviceId = (String) hmDevice.get(CommonDefs.DEVICE_ID);
			if (stDeviceId != null && !stDeviceId.isEmpty()) {
				alDevice.add(stDeviceId);
			}
		}

		if (!alDevice.isEmpty()) {

			JSONObject jsonDeenroll = new JSONObject();
			jsonDeenroll.put(CommonDefs.EMM_ACCOUNT_ID, e.getProperty(CommonDefs.EMM_ACCOUNT_ID));
			jsonDeenroll.put(CommonDefs.DEVICE_IDS, alDevice);

			e.getIn().setBody(jsonDeenroll);
			e.getIn().setHeader("deviceDeEnrollRequired", CommonDefs.Y);
		}else{
			e.getIn().setHeader("deviceDeEnrollRequired", CommonDefs.N);
		}

		log.info("Response from InquireDevices API " + alDevice);

	}

	public final void handleExpireAccountResponse(Exchange e) throws ApigwException {

		String respBody = e.getIn().getBody(String.class);
		log.info("Received response in handleExpireAccountResponse method:: " + respBody);
		String stHttpResponseCode = null;
		if (e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) != null) {
			stHttpResponseCode = String.valueOf(e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
			log.info("Received CamelHttpResponseCode in handleExpireAccountResponse method = " + stHttpResponseCode);
		}
		
		e.setProperty(CommonDefs.ACCOUNT_STATUS, CommonDefs.INACTIVE);

		e.getOut().setHeaders(e.getIn().getHeaders());
		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, stHttpResponseCode);
		e.setProperty(CommonDefs.RESPONSE_HEADER, stHttpResponseCode);

	}

	public final void handleDeenrollDeviceResponse(Exchange e) throws ApigwException {

		String respBody = e.getIn().getBody(String.class);
		log.info("Received Response in handleDeenrollDeviceResponse. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + respBody);

	}
	
	public final void processAsyncResponse(Exchange e) throws ApigwException {
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		e.getIn().setBody("");
		log.info("Response in ExpireAccountResponseProcessor processAsyncResponse method. ResponseCode ::"
				+ CommonDefs.RESPONSE_ACCEPT_CODE);

	}

}
