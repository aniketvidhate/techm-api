package com.att.sapmp.apigw.accounts.model;

import java.util.Map;

public class EncryptResponse {

	private Map<Object, Object> oceVoltageResponse;

	public Map<Object, Object> getOceVoltageResponse() {
		return oceVoltageResponse;
	}

	public void setOceVoltageResponse(Map<Object, Object> oceVoltageResponse) {
		this.oceVoltageResponse = oceVoltageResponse;
	}

}
