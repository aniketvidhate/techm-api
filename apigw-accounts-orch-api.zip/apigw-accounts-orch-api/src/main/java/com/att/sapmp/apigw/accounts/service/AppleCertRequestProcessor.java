
package com.att.sapmp.apigw.accounts.service;
import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.service.BaseProcessor;



@Component
public class AppleCertRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(AppleCertRequestProcessor.class);


	public final void execute(Exchange e) throws ApigwException {
		log.info("Invoking execute method");
	}
	
}