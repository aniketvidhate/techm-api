package com.att.sapmp.apigw.accounts.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "fan", "accountName", "email", "productCode" })
@ApiModel(value = "CreateAccount", description = "CreateAccount - input payload")
public class CreateAccount {
	@JsonProperty
	private String fan;

	@ApiModelProperty(value = "fan", example = "123456789")

	public String getFan() {
		return this.fan;
	}

	public void setFan(String fan) {
		this.fan = fan;
	}

	@JsonProperty
	private String accountName;

	@ApiModelProperty(value = "accountName", example = "ATTCRU")

	public String getAccountName() {
		return this.accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@JsonProperty
	private String email;

	@ApiModelProperty(value = "email", example = "att-buscons-admn@list.att.com")

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@JsonProperty
	private String productCode;

	@ApiModelProperty(value = "productCode", example = "IBMMass360Trial121334")

	public String getProductCode() {
		return this.productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

}
