package com.att.sapmp.apigw.accounts.common;

import com.att.eelf.i18n.EELFResolvableErrorEnum;
import com.att.eelf.i18n.EELFResourceManager;

public enum LogMessages implements EELFResolvableErrorEnum {

	ACCOUNT_START;

	static {

		EELFResourceManager.loadMessageBundle("logmessages");

	}

}
