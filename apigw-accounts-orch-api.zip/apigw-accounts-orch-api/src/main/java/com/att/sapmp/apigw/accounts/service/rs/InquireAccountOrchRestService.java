package com.att.sapmp.apigw.accounts.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Inquire Account")
@Produces({ MediaType.APPLICATION_JSON })
public interface InquireAccountOrchRestService {

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/accounts")
	@ApiOperation(
			value = "Returns Accounts based on input searchCriteria by calling MDM API.",
			notes = "This operation will return customer accounts directly under a Partner Billing account."
			+ "Only customer accounts directly under this account are listed." 
			+"emmAccountId or fan is conditionally required for account lookup."
			
 

	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void getAccounts(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode, @DefaultValue("{\"emmAccountId\":\"231232\",\"accountName\":\"ABCorp\",\"productCode\":\"IBMMass360Trial121334\",\"pageSize\":\"50\",\"pageNumber\":\"1\"}")@QueryParam("searchcriteria") String searchcriteria );
	
}