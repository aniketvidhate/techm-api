package com.att.sapmp.apigw.accounts.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class Accounts {

	private Map<Object, Object> accounts;

	public Map<Object, Object> getAccounts() {
		return accounts;
	}

	public void setAccounts(Map<Object, Object> accounts) {
		this.accounts = accounts;

	}

}
