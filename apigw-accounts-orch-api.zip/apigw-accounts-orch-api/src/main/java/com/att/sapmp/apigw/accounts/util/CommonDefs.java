package com.att.sapmp.apigw.accounts.util;

public class CommonDefs {

	public static final String BILLING_ID = "billingId";
	public static final String ACCOUNT_PASS_PHRASE = "AccountPassPhrase";
	public static final String KEY_ACCOUNT_PASS_PHRASE = "accountPassPhrase";
	public static final String USER_NAME = "userName";
	public static final String PARTNER_ACCOUNT = "partnerAccount";
	public static final String[] NON_ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductcode",
			"accountpassphrase" };
	public static final String[] ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductCode" };

	public static final String SEARCH_CRITERIA = "searchcriteria";
	public static final String EMM_ACCOUNT_ID = "emmAccountId";
	public static final String ACCOUNT_NAME = "accountName";
	public static final String TENANT_ACCOUNT_ID = "tenantAccountId";
	public static final String DEVICE_LIST = "deviceList";
	public static final String DEVICE_IDS = "deviceIds";
	public static final String DEVICE_ID = "deviceId";

	// Constants for Accounts APIs
	public static final String ACCOUNT = "account";
	public static final String ACCOUNTS = "accounts";
	public static final String ACCOUNT_STATUS = "accountStatus";
	public static final String CAMEL_HTTP_RESPONSE_CODE = "CamelHttpResponseCode";
	public static final String CAMEL_HTTP_URL = "CamelHttpUrl";
	public static final String CAMEL_HTTP_PATH = "CamelHttpPath";
	public static final String EMM_PRODUCT_CODE = "emmproductcode";
	public static final String TRACKING_ID = "trackingid";
	public static final String DEVICE = "device";

	public static final String EMAIL = "email";
	public static final String RESPONSE_ACCEPT_CODE = "202";
	public static final String IBM_CREATE_USER_URL = "IBMCreateUserUrl";
	public static final String STATUS = "status";
	public static final String RESPONSE_CREATED_CODE = "201";

	public static final String USER = "user";
	public static final String REMOVE_FAILED = "REMOVE_FAILED";
	public static final String DEVICE_STATUS = "deviceStatus";
	public static final String ACTIVE = "ACTIVE";
	public static final String INACTIVE = "INACTIVE";

	public static final String Y = "Y";
	public static final String N = "N";

	public static final String PRODUCT_CODE = "productCode";
	public static final String EMMP_PRODUCT_CODE = "EMMProductCode";
	public static final String ERROR_CODE_STR = "errorCode";
	public static final String MESSAGE = "message";
	public static final String AUTHORIZATION = "Authorization";
	public static final String DESCRIPTION = "description";

	public static final String RESPONSE_SUCCESS_CODE = "200";
	public static final String SUCCESS_CODE = "Success";

	public static final String FAN = "fan";

	public static final String[] CREATE_ACCOUNT_REQUIRED_PARAMS = { "fan", "accountName", "email" };
	public static final String INFRASTRUCTURE_VERSION = "infrastructureVersion";
	public static final String APPLICATION_NAME = "applicationName";
	public static final String CSI_VERSION = "csiversion";
	public static final String MESSAGE_ID = "messageId";
	public static final String ROUTING_REGION_OVERRIDE = "routingRegionOverride";
	public static final String DATE_TIMESTAMP = "dateTimeStamp";
	public static final String SEQUENCE_NUMBER = "sequenceNumber";
	public static final String TOTAL_IN_SEQUENCE = "totalInSequence";
	public static final String MODE = "mode";

	public static final String RESPONSE_SUCCESS_MSG = "SUCCESS";
	public static final String MODE_UPDATE = "U";
	public static final String MODE_DELETE = "D";
	public static final String RESPONSE_BODY = "responseBody";
	public static final String RESPONSE_HEADER = "responseHeader";
	public static final String QUERY_PARAM = "QueryParam";
	public static final String KEY_CDF_UPDATE = "cdfUpdate";

	public static final String VERSION = "version";
	public static final String VERSION_NO = "versionNo";

}
