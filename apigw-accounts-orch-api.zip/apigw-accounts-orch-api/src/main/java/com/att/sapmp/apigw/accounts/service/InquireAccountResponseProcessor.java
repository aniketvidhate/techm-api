package com.att.sapmp.apigw.accounts.service;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.util.CommonDefs;


/**
 * @author pg238s
 *
 */
@Component
public class InquireAccountResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InquireAccountResponseProcessor.class);

	public final void handleResponse(Exchange e) throws ApigwException {
		log.info("Received response in handleResponse method " + e.getIn().getBody());
		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
		e.getOut().setBody(e.getIn().getBody());

	}

	}
