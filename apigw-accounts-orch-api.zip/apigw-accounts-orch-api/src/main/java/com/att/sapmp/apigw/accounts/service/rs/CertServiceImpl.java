
package com.att.sapmp.apigw.accounts.service.rs;


import javax.ws.rs.HeaderParam;
import javax.ws.rs.PathParam;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.model.AppleCert;
import com.att.sapmp.apigw.accounts.model.UploadCert;


@AjscService
public class CertServiceImpl implements CertRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CertServiceImpl.class);
	
	public CertServiceImpl() {
		// needed for autowiring
	}


	@Override
	public void uploadCert(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@PathParam("emmAccountId") String emmAccountId,@RequestBody UploadCert uploadCert) {
		log.info("Received request in CertServiceImpl.uploadCert API.");
		
	}

	@Override
	public void signCert(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@PathParam("emmAccountId") String emmAccountId,@RequestBody AppleCert applecert) {
		log.info("Received request in CertServiceImpl.signCert API.");
		
	}
}
