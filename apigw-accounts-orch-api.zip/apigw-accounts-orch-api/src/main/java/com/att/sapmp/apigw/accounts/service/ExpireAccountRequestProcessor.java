package com.att.sapmp.apigw.accounts.service;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.service.BaseProcessor;
import com.att.sapmp.apigw.accounts.util.CommonDefs;

/**
 * @author pg238s
 *
 */

@Component
public class ExpireAccountRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ExpireAccountRequestProcessor.class);

	public final void execute(Exchange e) throws ApigwException {

		log.info("Invoking execute method in ExpireAccountRequestProcessor");

		String stBillingId = null;

		if (e.getIn().getHeader(CommonDefs.CAMEL_HTTP_PATH) != null) {
			stBillingId = ((String) e.getIn().getHeader(CommonDefs.CAMEL_HTTP_PATH)).substring(1);
			e.setProperty("expirePath", e.getIn().getHeader(CommonDefs.CAMEL_HTTP_PATH));
		}
		log.info("Received BillingId in ExpireAccountRequestProcessor ::" + stBillingId);

		if (stBillingId == null || stBillingId.isEmpty()) {

			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "billingId  is null in input");
		}

		JSONObject jsonRequest = new JSONObject();
		jsonRequest.put(CommonDefs.EMM_ACCOUNT_ID, stBillingId);
		jsonRequest.put(CommonDefs.DEVICE_STATUS, "Active");
		
		e.setProperty(CommonDefs.RESPONSE_HEADER , CommonDefs.RESPONSE_ACCEPT_CODE);

		e.setProperty(CommonDefs.QUERY_PARAM, "searchcriteria=" + jsonRequest.toString());
		e.setProperty(CommonDefs.EMM_ACCOUNT_ID, stBillingId);
		e.setProperty(CommonDefs.ACCOUNT_STATUS, CommonDefs.REMOVE_FAILED);
		e.setProperty(CommonDefs.MODE, CommonDefs.MODE_UPDATE);

	}

}