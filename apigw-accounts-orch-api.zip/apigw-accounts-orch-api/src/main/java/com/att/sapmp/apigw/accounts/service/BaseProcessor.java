package com.att.sapmp.apigw.accounts.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.util.CommonDefs;
import com.att.sapmp.apigw.accounts.util.CommonUtil;

/**
 * This abstract class is used to provide the common functionality to all sub
 * classes. headers and json payload validation is done by BaseProcessor. sub
 * classes need to extend the BaseProcessor class and provide implementation for
 * abstract methods.
 * 
 * 
 */

@Component
public abstract class BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(BaseProcessor.class);

	@Autowired
	CommonUtil commonUtil;

	public void process(Exchange e) throws ApigwException {

		try {

			// validate productCode from header
			String productCode = (String) e.getIn().getHeader(CommonDefs.EMM_PRODUCT_CODE);
			boolean isProductCodeValid = commonUtil.isProductCodeValid(productCode);

			if (!isProductCodeValid) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "Invalid Product Code");
			}

			String[] requiredHeaders = CommonDefs.NON_ACCOUNT_HEADERS;
			String partnerAccount = (String) e.getIn().getHeader(CommonDefs.PARTNER_ACCOUNT);
			if (partnerAccount != null && "Y".equalsIgnoreCase(partnerAccount)) {
				requiredHeaders = CommonDefs.ACCOUNT_HEADERS;
			}
			validateMap(e.getIn().getHeaders(), requiredHeaders);
			execute(e);

		} catch (ApigwException iaex) {
			e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_400);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, iaex.getErrorMsg());
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, iaex.getErrorCode());
			log.error("Caught ApigwException with error message::", iaex);
			throw new ApigwException(iaex.getErrorCode(), iaex.getErrorMsg());
		} catch (Exception ex) {
			e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_500);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, CErrorDefs.SYSTEM_ERROR);
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_5001);
			log.error("Caught Exception with error message::", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}

	}

	protected void validateMap(Map<String, Object> map, String[] requiredParamList) throws ApigwException {
		for (String requiredParam : requiredParamList) {
			if (!map.containsKey(requiredParam)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002,
						requiredParam + " is a required parameter in the request header.");
			}
			if (map.get(requiredParam) instanceof List) {
				List<String> paramVal = (ArrayList<String>) map.get(requiredParam);
				for (String paramList : paramVal) {
					if (StringUtils.isEmpty(paramList)) {
						throw new ApigwException(CErrorDefs.ERROR_CODE_1002,
								requiredParam + " needs to be populated in the request header.");
					}
				}
			} else {
				String paramValue = (String) map.get(requiredParam);
				if (StringUtils.isEmpty(paramValue)) {
					throw new ApigwException(CErrorDefs.ERROR_CODE_1002,
							requiredParam + " needs to be populated in the request header.");
				}
			}

		}
	}

	public abstract void execute(Exchange e) throws ApigwException;

	protected void validateJSON(JSONObject postReqJSON, String[] requiredParamList) throws ApigwException {

		for (String requiredParam : requiredParamList) {
			if (!postReqJSON.has(requiredParam)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002,
						requiredParam + " is a required parameter in the input.");
			}
			String paramValue = (String) postReqJSON.get(requiredParam);
			if (StringUtils.isEmpty(paramValue)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002,
						requiredParam + " needs to be populated in the input.");
			}

		}
	}
}
