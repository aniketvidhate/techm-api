package com.att.sapmp.apigw.accounts.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author av0041
 *
 */
@Component
public class CreateTenantAccountResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateTenantAccountResponseProcessor.class);

	public final void handleResponse(Exchange e) throws ApigwException {

		try {
		String response = (String) (e.getIn().getBody());
		log.info("Response from CreateTenantAccount API " + response);
		String stHttpResponseCode = null;
		if (e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) != null) {
			stHttpResponseCode = String.valueOf(e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
			log.info("Received CamelHttpResponseCode in handleResponse method = " + stHttpResponseCode);
		} 

		
		if (stHttpResponseCode != null && "201".equalsIgnoreCase(stHttpResponseCode)) {
			ObjectMapper objectMapper = new ObjectMapper();
			Map<String, Object> hmCreateTenantAccnt = objectMapper.readValue(response, HashMap.class);

			if (hmCreateTenantAccnt != null && !hmCreateTenantAccnt.isEmpty()) {
				HashMap<String, Object> hmAccount = (HashMap<String, Object>) hmCreateTenantAccnt.get(CommonDefs.ACCOUNT);
				if (hmAccount != null && !hmAccount.isEmpty()) {
					String emmAccountId = String.valueOf(hmAccount.get(CommonDefs.EMM_ACCOUNT_ID));
					e.setProperty(CommonDefs.EMM_ACCOUNT_ID, emmAccountId);
					e.setProperty(CommonDefs.ACCOUNT_STATUS, CommonDefs.ACTIVE);
					e.setProperty(CommonDefs.MODE, CommonDefs.MODE_UPDATE);
					e.setProperty(CommonDefs.RESPONSE_BODY , hmAccount);

				}

			}
		}
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, stHttpResponseCode);
		e.setProperty(CommonDefs.RESPONSE_HEADER , stHttpResponseCode);
		
		} catch (Exception ex) {
			log.error("Exception occured during handleResponse method", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}

	}
}
