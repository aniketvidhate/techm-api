package com.att.sapmp.apigw.accounts.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.sapmp.apigw.accounts.model.CreateAccount;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Create Tenant Account")
@Produces({ MediaType.APPLICATION_JSON })
public interface CreateaTenantAccountOrchRestService {

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/accounts/createaccount")
	@ApiOperation(
			value = "Supports customer enrollment provisioning request to setup up customer with default profile.",
			notes = "Creates a consumer account in MDM system.  By default, FAN name will be assigned as an account name."
			+"Multiple admin accounts can be created for a corporate account and each account created in MDM will be linked to a FAN by establishing an association at the time of account creation."
		
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 201, message = "Created"),
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void createTenantAccount(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@ApiParam(value = "Create Account Request Object", required = true) @RequestBody CreateAccount createAccount);
	
}