package com.att.sapmp.apigw.accounts.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.sapmp.apigw.accounts.model.AppleCert;
import com.att.sapmp.apigw.accounts.model.UploadCert;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Apple Certificate Management")

@Consumes(MediaType.MULTIPART_FORM_DATA)
@Produces({ MediaType.APPLICATION_JSON })
public interface CertRestService {

	@POST
	@Path("/accounts/{emmAccountId}/uploadcerts")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Supports signing apple certificate for iOS devices",
			notes = "CSR creation should follow the MDM guidelines"
					+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
					+ "All failures would be logged for reporting purpose. "			
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void uploadCert(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@PathParam("emmAccountId") String emmAccountId,@RequestBody UploadCert uploadCert);

	@POST
	@Path("/accounts/{emmAccountId}/signcerts")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Supports uploading apple certificate for iOS devices",
			notes = "CSR creation should follow the MDM guidelines"
					+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
					+ "All failures would be logged for reporting purpose. "
			
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void signCert(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@PathParam("emmAccountId") String emmAccountId,@RequestBody AppleCert applecert);
	
	





}