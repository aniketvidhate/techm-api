package com.att.sapmp.apigw.accounts.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.util.CommonDefs;
import com.att.sapmp.apigw.accounts.util.CommonUtil;

@Component
public class CsiManageDeviceProfileRequest {
	
	@Value("${csi.user}")
	private String userName;
	
	@Value("${csi.password}")
	private String userPassword;
	
	@Value("${csi.version}")
	private String version;
	
	public final void prepareCdfRequest(Exchange e) throws ApigwException {
		HashMap<String, Object> hmCdfUpdate = new HashMap<>();
		hmCdfUpdate.put(CommonDefs.USER, userName);
		hmCdfUpdate.put("userPassword", userPassword);
		hmCdfUpdate.put(CommonDefs.CSI_VERSION, version);
		hmCdfUpdate.put(CommonDefs.EMM_ACCOUNT_ID, e.getProperty(CommonDefs.EMM_ACCOUNT_ID));
		hmCdfUpdate.put(CommonDefs.TENANT_ACCOUNT_ID, e.getProperty(CommonDefs.TENANT_ACCOUNT_ID));
		hmCdfUpdate.put(CommonDefs.MODE, e.getProperty(CommonDefs.MODE));
		hmCdfUpdate.put(CommonDefs.ACCOUNT_STATUS, e.getProperty(CommonDefs.ACCOUNT_STATUS));
		hmCdfUpdate.put(CommonDefs.EMM_PRODUCT_CODE, e.getIn().getHeader(CommonDefs.EMM_PRODUCT_CODE));
		hmCdfUpdate.put(CommonDefs.ACCOUNT_PASS_PHRASE, e.getProperty(CommonDefs.ACCOUNT_PASS_PHRASE));
		hmCdfUpdate.put(CommonDefs.MESSAGE_ID, e.getIn().getHeader(CommonDefs.TRACKING_ID));
		hmCdfUpdate.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
		
		VelocityContext velocityContext = new VelocityContext(hmCdfUpdate);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		
	}

}
