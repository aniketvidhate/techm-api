package com.att.sapmp.apigw.accounts.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.util.CommonDefs;
import com.att.sapmp.apigw.accounts.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CSIProcessor {
	
	@Value("${csi.user}")
	private String userName;

	@Value("${csi.password}")
	private String userPassword;

	@Value("${csi.version}")
	private String version;

	
	private Logger log = LoggerFactory.getLogger(CSIProcessor.class);	
	

	public final void inquireDevice(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		log.info("request in execute method:" + postReqJSON);
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> inquireDeviceDetailsRequestMap = null;
		try {
			inquireDeviceDetailsRequestMap = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
		} catch (IOException ioe) {
			log.error("Exception occurred while parsing request json." + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		populateCSIHeader(inquireDeviceDetailsRequestMap);
		//inquireDeviceDetailsRequestMap.put(CommonDefs.DEVICE_LOG_ACTIVITY_FLAG, Boolean.valueOf(deviceLogActivityFlag));
		VelocityContext velocityContext = new VelocityContext(inquireDeviceDetailsRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}
	
	public final void inquireAccount(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		log.info("request in execute method:" + postReqJSON);
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> inquireAccountRequestMap = null;
		try {
			inquireAccountRequestMap = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
		} catch (IOException ioe) {
			log.error("Exception occurred while parsing request json." + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		populateCSIHeader(inquireAccountRequestMap);
		VelocityContext velocityContext = new VelocityContext(inquireAccountRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}
	
	public final void createDevice(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		Map<String, Object> updateDeviceDetailsRequestMap = new HashMap<>();
		updateDeviceDetailsRequestMap.put(CommonDefs.MODE, "C");
		/*updateDeviceDetailsRequestMap.put(CommonDefs.IMEI, imei);
		updateDeviceDetailsRequestMap.put(CommonDefs.CTN, ctn);
		updateDeviceDetailsRequestMap.put(CommonDefs.FAN, fan);
		updateDeviceDetailsRequestMap.put(CommonDefs.BAN, ban);
		updateDeviceDetailsRequestMap.put(CommonDefs.PROFILE_ID, profileId);
		updateDeviceDetailsRequestMap.put("platform", platform);*/
		populateCSIHeader(updateDeviceDetailsRequestMap);
		VelocityContext velocityContext = new VelocityContext(updateDeviceDetailsRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}
	
	public final void deleteDevice(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		Map<String, Object> updateDeviceDetailsRequestMap = new HashMap<>();
		updateDeviceDetailsRequestMap.put(CommonDefs.MODE, "D");
		//updateDeviceDetailsRequestMap.put(CommonDefs.IMEI, imei);
		populateCSIHeader(updateDeviceDetailsRequestMap);
		VelocityContext velocityContext = new VelocityContext(updateDeviceDetailsRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}
	
	

	public void populateCSIHeader(Map<String, Object> requestMap) {
		//requestMap.put(CommonDefs.INFRASTRUCTURE_VERSION, infrastructureVersion);
		//requestMap.put(CommonDefs.APPLICATION_NAME, applicationName);
		requestMap.put(CommonDefs.VERSION_NO, version);
		//requestMap.put(CommonDefs.MESSAGE_ID, messageId);
		requestMap.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
		requestMap.put(CommonDefs.USER_NAME, userName);
		requestMap.put("userPassword", userPassword);
		//requestMap.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
		//requestMap.put(CommonDefs.TOTAL_IN_SEQUENCE, totalInSequence);
		//requestMap.put(CommonDefs.TIME_TO_LIVE, timeToLive);
	}	

}
