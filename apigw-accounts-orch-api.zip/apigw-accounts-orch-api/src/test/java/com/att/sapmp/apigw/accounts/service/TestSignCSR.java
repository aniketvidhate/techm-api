package com.att.sapmp.apigw.accounts.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.att.sapmp.apigw.accounts.service.TestBase;

public class TestSignCSR extends TestBase{
	
	@Value("${test.ibm.signcsr.basePath}")
	protected String basePath;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
	}

	@Override
	protected String getBasePath() {
		return basePath;
	}	

	
	@Test
	public void testGivenSignCSRWhenValidCertIsUploadedThenResponseContainsSignedCSR() {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("signedCSR")));
	}

	@Test
	public void testGivenSignCSRWhenInValidCertIsUploadedThenSignCSRFails() {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("Last unit does not have enough valid bits")));
	}
	
	@Test
	public void testGivenAuthTokenIsInvalidWhenSignCSRIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());		
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenSignCSRIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("signedCSR")));
	}



}
