package com.att.sapmp.apigw.accounts.service;

import static org.junit.Assert.assertEquals;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.Application;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.runners.MethodSorters;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
@TestPropertySource(locations = "classpath:application-test.properties")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AccountsIntegrationTest {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(AccountsIntegrationTest.class);

	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	@Autowired
	private TestRestTemplate template;

	HttpHeaders headers = null;
	static String fan = null;
	static String emmAccountId = null;

	@Before
	public void setUp() throws Exception {

		headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
		headers.set("trackingid", String.valueOf(new Date().getTime()));
		headers.set("emmproductcode", "IBMMASS");
		headers.set("accountpassphrase", "1497030662187");
		fan="1497030662187";

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateAccount() throws Exception {
		
		//fan = String.valueOf(new Date().getTime());
		String body = "{\"fan\": \""+fan+"\",\"accountName\": \"ATTCRU\",\"email\": \"account-admin@att.com\",\"productCode\": \"IBMMass360Trial121334\",\"password\":\""+fan+"\"}";

		HttpEntity<String> entity = new HttpEntity<String>(body, headers);
		ResponseEntity<String> response = template.exchange("/accounts/createaccount", HttpMethod.POST, entity,
				String.class);
		
		String responseBody = response.getBody();

		log.info("Response:" + responseBody);
		
		if (response.getStatusCode().equals(HttpStatus.CREATED)) {
			ObjectMapper objectMapper = new ObjectMapper();
			Map<String, Object> hmCreateTenantAccnt = objectMapper.readValue(responseBody, HashMap.class);

			if (hmCreateTenantAccnt != null && !hmCreateTenantAccnt.isEmpty()) {
				HashMap<String, Object> hmAccount = (HashMap<String, Object>) hmCreateTenantAccnt.get("account");
				if (hmAccount != null && !hmAccount.isEmpty()) {
					emmAccountId = String.valueOf(hmAccount.get("emmAccountId"));

				}

			}
		}
		
		//assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testInquireAccount() throws Exception {

		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		String queryParam = "{\"accountName\":\""+fan+"\"}";
		ResponseEntity<String> response = template.exchange("/accounts?searchcriteria={queryParam}", HttpMethod.GET,
				entity, String.class, queryParam);

		log.info("Response:" + response.getBody());
		//assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testExpireAccount() throws Exception {
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		ResponseEntity<String> response = template.exchange("/accounts/"+30061052, HttpMethod.DELETE, entity,
				String.class);

		log.info("Response:" + response.getBody());
		//assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}
}
