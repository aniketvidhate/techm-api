package com.att.sapmp.apigw.accounts.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;


public class TestUploadAppleSignedCSR extends TestBase{
	
	@Value("${test.ibm.uploadAppleCSR.basePath}")
	protected String basePath;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {	
	
	}

	@Override
	protected String getBasePath() {
		return basePath;
	}	
	
	
	
	@Test
	public void testGivenAppleSignedCSRWhenCertificatePasswordIsValidThenUploadCertificateSucceedsAndResponseContainsCertTopicAndExpirationDate() {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("Success")));
		assertThat(responseBody, allOf(containsString("Apple MDM Certificate has been uploaded successfully.")));
		assertThat(responseBody, allOf(containsString("certExpiryDate")));
		assertThat(responseBody, allOf(containsString("certTopic")));
	
	}

	@Test
	public void testGivenAppleSignedCSRWhenCertificatePasswordIsInValidThenUploadCertificateFails() {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("Failure")));
		assertThat(responseBody, allOf(containsString("Invalid Apple MDM Certificate : error.cert.ip.pwd")));
	
	}
	
	@Test
	public void testGivenAppleSignedCSRIsCorruptedWhenUploadCertificateIsAttemptedThenUploadCertificateFails() {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("Failure")));	
	}	
	
	@Test
	public void testGivenAuthTokenIsInvalidWhenUploadCertIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	
	}

	@Test
	public void testGivenAuthTokenIsValidWhenUploadCertIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("Success")));
		assertThat(responseBody, allOf(containsString("Apple MDM Certificate has been uploaded successfully.")));	
	}

}
