package com.att.sapmp.apigw.accounts.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.apache.commons.lang.math.RandomUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

public class TestCreateAccount extends TestBase{
		
	@Value("${test.fan}")
	private String fan;
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.orch.create.account.basePath}")
	protected String createBasePath;
	
	@Value("${test.accountNamePrefix}")
	private String accountNamePrefix;
	
	@Value("${test.partner.billing.id}")
	protected String partnerBillingId;	
	
	@Value("${test.orch.inquire.account.basePath}")
	protected String inquireBasePath;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
		int accountSuffix = RandomUtils.nextInt(1000);
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{fan\\}", fan);	
        requestJson = requestJson.replaceAll("\\$\\{accountName\\}", accountNamePrefix + String.valueOf(accountSuffix));	
	}
	
	@Override
	protected String getBasePath() {
		return createBasePath;
	}
	
	@Test
	public void testGivenCreateAccountIsCalledWhenRequiredFieldsAreMissingInHeaderThenTransactionFailsAndReturnInvalidRequestError() {
		headers.remove("trackingid");
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("E1002"), containsString("description")));		
	}	

	@Test
	public void testGivenAuthTokenIsInvalidWhenCreateAccountIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}
	
	@Test
	public void testGivenCreateNewAccountIsCalledWhenFanIsNotPassedThenAccountIsNotCreatedAndReturnInvalidRequestError() {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("E1002"), containsString("description")));
		
	}

	@Test
	public void testGivenCreateNewAccountIsCalledWhenAccountNameIsNotPassedThenAccountIsNotCreatedAndReturnInvalidRequestError() {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenCreateNewAccountIsCalledWhenEmailIsNotPassedThenAccountIsNotCreatedAndReturnInvalidRequestError() {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("E1002"), containsString("description")));		
	}

	@Test
	public void testGivenCreateNewAccountIsCalledWhenAccountIsCreatedSuccessfullyThenAccountIsCreatedAndAccountStatusIs_ACTIVE() {
		executePost();
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("accountStatus")));
	}

	@Test
	public void testGivenAccountIsCreatedSuccessfullyThenResponseContainsEmmAccountIdAndAccountNameAndEncryptedPassPhraseAndAccountStatusAndCdfUpdateStatus() {
		executePost();
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("emmAccountId"),containsString("accountName"),containsString("accountPassPhrase"),containsString("accountStatus"), containsString("cdfUpdate")));			
	}

	@Test
	public void testGivenAccountIsCreatedSuccessfullyWhenAccountNameFollowedNamingRulesThenAccountNameInResponseIsEqualToPartnerBillingIdAndEmmProductIdAndAccountName() {
		executePost();
		assertEquals(HttpStatus.CREATED, response.getStatusCode());		
		JSONObject jsonObject = new JSONObject(requestJson);
		String accountNameRequest = (String)jsonObject.get("accountName");
		executeGet(inquireBasePath);
		JSONObject postResJSON = new JSONObject(responseBody);
		JSONObject accounts = (JSONObject)postResJSON.get("accounts");
		JSONArray account = accounts.getJSONArray("account");
		JSONObject firstElement = account.getJSONObject(0);
		String accountNameResponse = (String)firstElement.get("accountName");
		String constructedAccountName = partnerBillingId + headers.get("emmproductcode") + accountNameRequest;
		assertEquals(constructedAccountName, accountNameResponse);
	}

	@Test
	public void testGivenAccountIsCreatedSuccessfullyWhenPasswordEncryptionAndCdfUpdateIsSuccessThenEmmAccountIdAndStatusAndAccountPassphraseIsNotNullInCdf() {
		executePost();
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("emmAccountId"),containsString("accountName"),containsString("accountPassPhrase"),containsString("accountStatus"), containsString("cdfUpdate")));
		JSONObject jsonObject = new JSONObject(responseBody);
		String newEmmAccountId = String.valueOf(((JSONObject)jsonObject.get("account")).get("emmAccountId"));
		executePost(csiInquireAccountBasePath,"{\"emmAccountId\":\""+newEmmAccountId+"\"}");
		assertThat(responseBody, allOf(containsString("<accountStatus>ACTIVE</accountStatus>"),containsString("<emmAccountId>"+newEmmAccountId+"</emmAccountId>"),containsString("<accountPassphrase>"+fan+"</accountPassphrase>")));
	}

	//@Test
	//Manually decrypt the accountprassphrase
	public void testGivenAccountIsCreatedWhenVoltagePasswordEncryptionIsSuccessThenAccountPassphraseCanBeDecrypted() {
	}
	
}
