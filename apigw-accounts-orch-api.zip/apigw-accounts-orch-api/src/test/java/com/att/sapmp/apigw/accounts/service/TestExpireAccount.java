package com.att.sapmp.apigw.accounts.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.apache.commons.lang.math.RandomUtils;
import org.json.JSONObject;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.att.sapmp.apigw.accounts.exception.ApigwException;


public class TestExpireAccount extends TestBase{

	
	@Value("${test.fan}")
	private String fan;
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.accountNamePrefix}")
	private String accountNamePrefix;
	
	protected String getBasePath() {
		return expireAccountBasePath;
	}
	
	@Override
	protected void replaceTokensInRequest() throws ApigwException {
			int accountSuffix = RandomUtils.nextInt(1000);
	        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
	        requestJson = requestJson.replaceAll("\\$\\{fan\\}", fan);	
	        requestJson = requestJson.replaceAll("\\$\\{accountName\\}", accountNamePrefix + String.valueOf(accountSuffix));	
		}
	@Test
	public void testGivenExpireAccountWhenRequiredFieldsInHeaderAreNotPassedThenReturnInvalidRequestError() {
		headers.remove("accountpassphrase");
		executeDelete();			
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenExpireAccountWhenEmmAccountIdIsNotPassedThenReturnInvalidRequestError() {
		executeDeleteWithoutEmmAccountId();			
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenExpireAccountWhenAccountHasNoActiveDevicesThenSkipDeEnrollDeviceCallAndExpireAccount() {
		executePost(createAccountBasePath);
		JSONObject jsonObject = new JSONObject(responseBody);
		headers.set("accountpassphrase", String.valueOf(((JSONObject)jsonObject.get("account")).get("accountPassPhrase")));
		executeDelete(expireAccountBasePath,String.valueOf(((JSONObject)jsonObject.get("account")).get("emmAccountId")));
		String inquireResponse = executeGetInquireAccount();
		assertThat(inquireResponse, containsString("InActive"));
		
	}

	@Test
	public void testGivenExpireAccountWhenAccountHasActiveDevicesThenDeEnrollActiveDevicesAndExpireAccount() {
		executePost(createAccountBasePath);
		JSONObject jsonObject = new JSONObject(responseBody);
		headers.set("accountpassphrase", String.valueOf(((JSONObject)jsonObject.get("account")).get("accountPassPhrase")));
		executeDelete(expireAccountBasePath,String.valueOf(((JSONObject)jsonObject.get("account")).get("emmAccountId")));
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		assertEquals(responseBody,null);	
	}

	@Test
	public void testGivenExpireAccountWhenAccountHasActiveAndInActiveDevicesThenDeEnrollOnlyActiveDevicesAndExpireAccount() {
		executePost(createAccountBasePath);
		JSONObject jsonObject = new JSONObject(responseBody);
		executeDelete(expireAccountBasePath,String.valueOf(((JSONObject)jsonObject.get("account")).get("emmAccountId")));
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		assertEquals(responseBody,null);
	}

	@Test
	public void testGivenExpireAccountWhenExpireAccountFailsThenAccountStatusIs_REMOVE_FAILED() {
		executeDelete(expireAccountBasePath,"231232");
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenExpireAccountWhenExpireAccountIsSuccessThenAccountHasNoActiveDevicesAndStatusIs_INACTIVE() {
		executePost(createAccountBasePath);
		JSONObject jsonObject = new JSONObject(responseBody);
		headers.set("accountpassphrase", String.valueOf(((JSONObject)jsonObject.get("account")).get("accountPassPhrase")));
		executeDelete(expireAccountBasePath,String.valueOf(((JSONObject)jsonObject.get("account")).get("emmAccountId")));
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		assertEquals(true,response.toString().contains("INACTIVE"));
	}

	@Test
	public void testGivenExpireAccountNotExistsWhenExpireAccountIsInvokedThenExpireAccountTrasactionFails() {
		executeDelete(expireAccountBasePath,"231232");
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("E1002"), containsString("description")));
	}
	//Needs to be manually tested 
	//@Test
	public void testGivenAccountDetailIsMissingInCdfAndAccountExistsInMdmWhenExpireAccountIsInvokedThenAccountIsExpiredAndAccountStatusUpdateFails() {
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenExpireAccountIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenExpireAccountIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() {
		executePost(createAccountBasePath);
		JSONObject jsonObject = new JSONObject(responseBody);
		headers.set("accountpassphrase", String.valueOf(((JSONObject)jsonObject.get("account")).get("accountPassPhrase")));
		executeDelete(expireAccountBasePath,String.valueOf(((JSONObject)jsonObject.get("account")).get("emmAccountId")));
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		assertEquals(responseBody,null);	
	}
}
