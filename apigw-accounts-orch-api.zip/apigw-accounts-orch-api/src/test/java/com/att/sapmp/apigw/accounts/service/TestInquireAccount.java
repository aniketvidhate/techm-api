package com.att.sapmp.apigw.accounts.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.apache.commons.lang.math.RandomUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

public class TestInquireAccount extends TestBase {
	
	@Value("${test.fan}")
	private String fan;
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.accountNamePrefix}")
	private String accountNamePrefix;
	
	//@Value("${ibm.partner.billing.id}")
	//protected String partnerBillingId;
	
	@Value("${test.orch.inquire.account.basePath}")
	protected String inquireBasePath;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
		int accountSuffix = RandomUtils.nextInt(1000);
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{fan\\}", fan);	
        requestJson = requestJson.replaceAll("\\$\\{accountName\\}", accountNamePrefix + String.valueOf(accountSuffix));	
	}

	@Override
	protected String getBasePath() {
		return inquireBasePath;
	}
	
	@Test
	public void testGivenInquireAccountWhenRequiredFieldsAreNotPassedThenReturnInvalidRequestError() {
		executeGet();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testGivenInquireAccountExistsWhenSearchCriteriaContainsEmmAccountIdThenMatchingAccountDetailsIsReturned() {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		
	}
	
	@Test
	public void testGivenInquireAccountsExistWhenSearchCriteriaContainsEmmProductCodeThenAllAccountsWithMatchingEmmProductCodeIsReturned() {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireAccountsExistWhenSearchCriteriaContainsPartialAccountNameThenAllAccountsWithMatchingAccountNameIsReturned() {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireAccountWhenSearchCriteriaHasPageSizeAndPageNumberThenReponseConfinesToPageSizeAndPageNumberValues() {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("pageSize"),containsString("pageNumber")));
	}	

	@Test
	public void testGivenInquireAccountWhenAuthTokenIsInvalidThenTransactionFailsAndReturnUserUnauthorizedError() {
		headers.set("authorization", "Basic 123");
		executeGet();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenInquireAccountWhenAuthTokenIsValidThenTransactionSucceedsAndReturnAccountDetails() {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireAccountWhenSearchCriteriaReturnsMultipleAccountDetailsThenResponseContainsPaginationDetails() {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("pageSize"),containsString("pageNumber")));
	}

}
