package com.att.sapmp.apigw.devices.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

public class TestDeviceEnrollment extends TestBase{
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.fan}")
	private String fan;
	
	@Value("${test.id}")
	private String id;
	
	@Value("${test.imei}")
	private String imei;	
	
	@Value("${test.ibm.enroll.basePath}")
	protected String basePath;
			
	protected void replaceTokensInRequest() throws Exception {
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{fan\\}", fan);
        requestJson = requestJson.replaceAll("\\$\\{id\\}", id);
        requestJson = requestJson.replaceAll("\\$\\{imei\\}", imei);
	}
	
	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceEnrollmentIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception {
		headers.set("authorization", "Basic 123");
		executePost();		
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenEnrollmentRequestWhenEmmAccountIdIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception {
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenFANIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEmailIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentsElementIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentElementIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentLineIdIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentDeviceIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentDeviceIdIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentDeviceImeiIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentDevicePlatformIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentUserIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	//@Test
	//Deferred to 1710 Release QC #256954
	public void testGivenEnrollmentRequestWhenEnrollmentUserFirstNameIsMissingThenTransactionFailsAndReturnInvalidRequestError(){
	}

	//@Test
	//Deferred to 1710 Release QC #256954
	public void testGivenEnrollmentRequestWhenEnrollmentUserLastNameIsMissingThenTransactionFailsAndReturnInvalidRequestError(){
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentUserBanIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentUserCtnIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentUserEmailIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentUserDomainIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentProfileIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentProfileProfileIdIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentProfileNetworkControlIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentProfilePasscodePolicyCodeIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentProfileSecurityPolicyCodeIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentProfilePasscodePolicyCodeIsInvalidThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenEnrollmentProfileSecurityPolicyCodeIsInvalidThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenEnrollmentRequestWhenAnyRequiredElementIsMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test 
	public void testGivenEnrollmentRequestWhenRequiredFieldsAreMissingInHeaderThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		headers.remove("accountpassphrase");
		executePost();			
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));	
	}
	
	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenNoApiCallMadeInLast60MinutesForGivenEmmAccountIdThenNewlyObtainedAuthTokenIsUsedForAuthentication() {
	}

	//@Test 
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenApiCallsMadeInLast60MinutesForEmmAccountIdThenExistingAuthTokenIsUsedForAuthentication() {
	}

	@Test 
	//Needs to be manually tested as it is not feasible to fail the addUser IBM call in a testcase
	public void testGivenEnrollmentRequestWhenAddUserFailsThenDeviceEnrollmentFailsAndDeviceStatusIs_ENROLLMENT_FAILED_and_CREATE_DEVICEUSER_FAILED_and_InsertDeviceActivityLog() {
		/*executePost(csiCreateDeviceBasePath);	
		executePost();		
		executePost(csiInquireDeviceBasePath,"{\"imei\":\""+imei+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentStatus>ENROLLMENT_FAILED</enrollmentStatus>")));
		assertThat(responseBody, containsString("<enrollmentSubStatus>CREATE_DEVICEUSER_FAILED</enrollmentSubStatus>"));
		assertThat(responseBody, containsString("<man:activityType>ENROLL</man:activityType>"));		    
		executePost(csiDeleteDeviceBasePath);*/
	}

	@Test 
	//Needs to be manually tested as it is not feasible to fail the Device Enrollment in a testcase
	public void testGivenEnrollmentRequestWhenEnrollDeviceFailsThenDeviceEnrollmentFailsAndDeviceStatusIs_ENROLLMENT_FAILED_and_ENROLL_DEVICE_FAILED_and_InsertDeviceActivityLog() {
		/*executePost(csiCreateDeviceBasePath);	
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"imei\":\""+imei+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentStatus>ENROLLMENT_FAILED</enrollmentStatus>")));
		assertThat(responseBody, containsString("<enrollmentSubStatus>ENROLL_DEVICE_FAILED</enrollmentSubStatus>"));
		assertThat(responseBody, containsString("<man:activityType>ENROLL</man:activityType>"));		    
		executePost(csiDeleteDeviceBasePath);*/
	}

	@Test	//Needs to be manually tested as it is not feasible to fail the Send Enrollment Sms in a testcase
	public void testGivenEnrollmentRequestWhenSendEnrollmentSmsFailsThenDeviceEnrollmentFailsAndDeviceStatusIs_ENROLLMENT_FAILED_and_SEND_ENROLLMENT_SMS_FAILED_and_InsertDeviceActivityLog() {
		/*executePost(csiCreateDeviceBasePath);	
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"imei\":\""+imei+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentStatus>ENROLLMENT_FAILED</enrollmentStatus>")));
		assertThat(responseBody, containsString("<enrollmentSubStatus>SEND_ENROLLMENT_SMS_FAILED</enrollmentSubStatus>"));
		assertThat(responseBody, containsString("<man:activityType>ENROLL</man:activityType>"));		    
		executePost(csiDeleteDeviceBasePath);*/
	}

	//@Test 
	//Needs to be manually tested as it is not feasible to fail the tracking sock in a testcase
	public void testGivenEnrollmentRequestWhenAddTrackingSocFailsThenDeviceEnrollmentFailsAndDeviceStatusIs_ENROLLMENT_INITIATED_and_ADD_TRACKING_SOC_FAILED_and_InsertDeviceActivityLog() {
		executePost(csiCreateDeviceBasePath);	
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"imei\":\""+imei+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentStatus>ENROLLMENT_INITIATED</enrollmentStatus>")));
		assertThat(responseBody, containsString("<enrollmentSubStatus>ADD_TRACKING_SOC_FAILED</enrollmentSubStatus>"));
		assertThat(responseBody, containsString("<man:activityType>ENROLL</man:activityType>"));		    
		executePost(csiDeleteDeviceBasePath);
	}

	@Test 	//Needs to be manually tested for the success scenario
	public void testGivenEnrollmentRequestWhenDeviceEnrollmentSucceedsThenDeviceStatusIs_ENROLLMENT_INITIATED_and_MDM_ACTIVATION_PENDING_and_InsertDeviceActivityLog() {
		/*executePost(csiCreateDeviceBasePath);	
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"imei\":\""+imei+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentStatus>ENROLLMENT_INITIATED</enrollmentStatus>")));
		assertThat(responseBody, containsString("<enrollmentSubStatus>MDM_ACTIVATION_PENDING</enrollmentSubStatus>"));
		assertThat(responseBody, containsString("<man:activityType>ENROLL</man:activityType>"));		    
		executePost(csiDeleteDeviceBasePath);*/		
	}

	//@Test
	//Invalid test case as it is not feasible to test user received Enrollment URL and Passcode in SMS
	public void testGivenEnrollmentRequestWhenDeviceEnrollmentSucceedsThenDeviceUserReceivesEnrollmentUrlAndPasscodeInSms() {
	}

	//@Test
	//Needs to be manually tested as it is not feasible to test user received Enrollment URL and Passcode in SMS
	public void testGivenEnrollmentRequestWhenDeviceEnrollmentSucceedsThenTrackingSocIsAddedToUserAccountInBillingSystem() {
	}

	@Test
	//Needs to be manually tested as it is not feasible to check Enroll Device Task is created
	public void testGivenEnrollmentRequestWhenDeviceEnrollmentSucceedsThenEnrollDeviceTaskIsCreated() {
		/*executePost(csiCreateDeviceBasePath);	
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"imei\":\""+imei+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentStatus>ENROLLMENT_INITIATED</enrollmentStatus>")));
		assertThat(responseBody, containsString("<enrollmentSubStatus>MDM_ACTIVATION_PENDING</enrollmentSubStatus>"));
		//assertThat(responseBody, containsString("<man:activityType>ENROLL</man:activityType>"));		    
		executePost(csiDeleteDeviceBasePath);*/	
	}
	
	@Test
	public void testGivenEnrollDeviceTaskWhenRequiredFieldsAreMissingThenEnrollDeviceTaskFailsAndReturnInvalidRequestError() throws Exception {
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));	
	}	
}