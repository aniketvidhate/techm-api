package com.att.sapmp.apigw.devices.service;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

public class TestDeviceEnrollmentTask extends TestBase {
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.fan}")
	private String fan;
	
	@Value("${test.ibm.enroll.basePath}")
	protected String basePath;
			
	protected void replaceTokensInRequest() throws Exception {
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{fan\\}", fan);
	}
	
	protected String getBasePath() {
		return basePath;
	}
	
	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceTasksIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception {
		headers.set("authorization", "Basic 123");
		executePost();		
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}
	
	@Test
	public void testGivenEnrollDeviceTaskWhenRequestIsMissingRequiredElementsThenTransactionFailsAndReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf( containsString("E1002"), containsString("errorCode"), containsString("description")));
	}
	
	//@Test
	//Deferred to 1710 Release QC #256954
	public void testGivenEnrollDeviceTaskWhenInquireDeviceDetailsFailsThenTaskWillBeReTriedAfterConfiguredInterval() {
	} 
	
	//@Test 
	//Needs to be manually tested
	public void testGivenEnrollDeviceTaskWhenDeviceDetailsIsFetechedFromCdfAndDeviceIsUnderMDMControlThenStopTheProcess() {
	}
	
	//@Test 
	//Needs to be manually tested
	public void testGivenEnrollDeviceTaskWhenDeviceDetailsIsFetechedFromCdfAndDeviceIsNotUnderMDMControlThenInvokeApplyApn() {
	}	
}