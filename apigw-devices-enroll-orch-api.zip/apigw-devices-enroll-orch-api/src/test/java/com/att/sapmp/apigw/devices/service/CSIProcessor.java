package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CSIProcessor {
	
	@Value("${csi.user}")
	private String userName;

	@Value("${csi.password}")
	private String userPassword;

	@Value("${csi.version}")
	private String version;

	@Value("${csi.messageId}")
	private String messageId;

	@Value("${csi.sequenceNumber}")
	private String sequenceNumber;

	@Value("${csi.totalInSequence}")
	private String totalInSequence;

	@Value("${csi.timeToLive}")
	private String timeToLive;

	@Value("${csi.applicationName}")
	private String applicationName;

	@Value("${csi.infrastructureVersion}")
	private String infrastructureVersion;
	
	private Logger log = LoggerFactory.getLogger(CSIProcessor.class);

	@Value("${csi.inquire.device.detail.deviceLogActivityFlag}")
	private String deviceLogActivityFlag;
	
	@Value("${test.csi.create.device.imei}")
	private String imei;
	
	@Value("${test.csi.create.device.ctn}")
	private String ctn;
	
	@Value("${test.csi.create.device.fan}")
	private String fan;
	
	@Value("${test.csi.create.device.ban}")
	private String ban;
	
	@Value("${test.csi.create.device.platform}")
	private String platform;
	
	@Value("${test.csi.create.device.profileId}")
	private String profileId;
	
	

	public final void inquireDevice(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		log.info("request in execute method:" + postReqJSON);
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> inquireDeviceDetailsRequestMap = null;
		try {
			inquireDeviceDetailsRequestMap = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
		} catch (IOException ioe) {
			log.error("Exception occurred while parsing request json." + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		populateCSIHeader(inquireDeviceDetailsRequestMap);
		inquireDeviceDetailsRequestMap.put(CommonDefs.DEVICE_LOG_ACTIVITY_FLAG, Boolean.valueOf(deviceLogActivityFlag));
		VelocityContext velocityContext = new VelocityContext(inquireDeviceDetailsRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}
	
	public final void inquireAccount(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		log.info("request in execute method:" + postReqJSON);
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> inquireAccountRequestMap = null;
		try {
			inquireAccountRequestMap = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
		} catch (IOException ioe) {
			log.error("Exception occurred while parsing request json." + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		populateCSIHeader(inquireAccountRequestMap);
		VelocityContext velocityContext = new VelocityContext(inquireAccountRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}
	
	public final void createDevice(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		Map<String, Object> updateDeviceDetailsRequestMap = new HashMap<>();
		updateDeviceDetailsRequestMap.put(CommonDefs.MODE, "C");
		updateDeviceDetailsRequestMap.put(CommonDefs.IMEI, imei);
		updateDeviceDetailsRequestMap.put(CommonDefs.CTN, ctn);
		updateDeviceDetailsRequestMap.put(CommonDefs.FAN, fan);
		updateDeviceDetailsRequestMap.put(CommonDefs.BAN, ban);
		updateDeviceDetailsRequestMap.put(CommonDefs.PROFILE_ID, profileId);
		updateDeviceDetailsRequestMap.put("platform", platform);
		populateCSIHeader(updateDeviceDetailsRequestMap);
		VelocityContext velocityContext = new VelocityContext(updateDeviceDetailsRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}
	
	public final void deleteDevice(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		Map<String, Object> updateDeviceDetailsRequestMap = new HashMap<>();
		updateDeviceDetailsRequestMap.put(CommonDefs.MODE, "D");
		updateDeviceDetailsRequestMap.put(CommonDefs.IMEI, imei);
		populateCSIHeader(updateDeviceDetailsRequestMap);
		VelocityContext velocityContext = new VelocityContext(updateDeviceDetailsRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}
	
	

	public void populateCSIHeader(Map<String, Object> requestMap) {
		requestMap.put(CommonDefs.INFRASTRUCTURE_VERSION, infrastructureVersion);
		requestMap.put(CommonDefs.APPLICATION_NAME, applicationName);
		requestMap.put(CommonDefs.VERSION_NO, version);
		requestMap.put(CommonDefs.MESSAGE_ID, messageId);
		requestMap.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
		requestMap.put(CommonDefs.USER_NAME, userName);
		requestMap.put("userPassword", userPassword);
		requestMap.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
		requestMap.put(CommonDefs.TOTAL_IN_SEQUENCE, totalInSequence);
		requestMap.put(CommonDefs.TIME_TO_LIVE, timeToLive);
	}	

}
