package com.att.sapmp.apigw.devices.service;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.Application;
import com.att.sapmp.apigw.devices.service.TestConfiguration;




@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
@TestPropertySource(locations = "classpath:application-test.properties")
public class EnrollDeviceIntegrationTest {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(EnrollDeviceIntegrationTest.class);
	
	HttpHeaders headers = new HttpHeaders();
	
	static{
		SystemPropertiesLoader.addSystemProperties(); 
	}
	
	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	   @Autowired
	    private TestRestTemplate template;
	   
	@Before
	public void setUp() throws Exception {
		
		headers.set("Content-Type", "application/json");
		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
		headers.set("accountpassphrase", "5001234");
		headers.set("trackingid",String.valueOf(new Date().getTime()));		
		headers.set("trackingid", "12345");
		headers.set("emmproductcode", "IBMMASS");				
	}

	@After
	public void tearDown() throws Exception {
		
		
	}
	
	@Test
	public void testEnrollWithMissingGroupId() throws Exception {
		
		String requestJson = "{\n\"emmAccountId\": \"30059025\",\n\"fan\":\"fan12345\",\n\"email\": \"4699099424@txt.att.com\",\n\"liabilityType\" : \"BAU\",\n\"enrollments\": {\n\"enrollment\": [{\n\"lineId\": \"xnxn-9898-fghg-ghgh\",\n\"device\": {\n\"id\": \"ApplC39KVZU7FH19\",\n\"imei\": \"123\",\n\"platform\": \"iOS\"\n},\n\"user\": {\n\n\"lastName\": \"Vidhate\",\n\"ctn\": \"9224970888\",\n\"email\": \"av00419874@att.com\",\n\"domain\": \"att.com\",\n\"ban\":\"321312312\"\n},\n\"group\": {\n\n\"groupName\": \"Executives\"\n},\n\"profile\": {\n\"profileId\": \"P001\",\n\"profileName\": \"DefaultProfile\",\n\"networkControl\": \"true\",\n\"passcodePolicyCode\": \"PN\",\n\"securityPolicyCode\": \"SB\",\n\"applications\": {\n\"application\": [{\n\"appId\": \"App1\",\n\"appType\": \"1\",\n\"emailNotification\": \"Yes\",\n\"sendNotification\": \"No\"\n},\n{\n\"appId\": \"App2\",\n\"appType\": \"1\",\n\"emailNotification\": \"No\",\n\"sendNotification\": \"No\"\n}]\n}\n}\n}]\n}}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/devices/enrolldevice", HttpMethod.POST, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
		//assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	
	}
	
	
	@Test
	public void testEnrollWithInvalidpasscodePolicyCodeValue() throws Exception {
		
		String requestJson = "{\n\t\"emmAccountId\": \"30059025\",\n\t\"fan\": \"fan12345\",\n\t\"email\": \"4699099424@txt.att.com\",\n\t\"liabilityType\": \"BAU\",\n\t\"enrollments\": {\n\t\t\"enrollment\": [{\n\t\t\t\"lineId\": \"xnxn-9898-fghg-ghgh\",\n\t\t\t\"device\": {\n\t\t\t\t\"id\": \"ApplC39KVZU7FH19\",\n\t\t\t\t\"imei\": \"123\",\n\t\t\t\t\"platform\": \"iOS\"\n\t\t\t},\n\t\t\t\"user\": {\n\t\t\t\t\"firstName\": \"Aniket\",\n\t\t\t\t\"lastName\": \"Vidhate\",\n\t\t\t\t\"ctn\": \"9224970888\",\n\t\t\t\t\"email\": \"av00419874@att.com\",\n\t\t\t\t\"domain\": \"att.com\",\n\t\t\t\t\"ban\": \"321312312\"\n\t\t\t},\n\t\t\t\"group\": {\n\t\t\t\t\"groupId\": \"G001\",\n\t\t\t\t\"groupName\": \"Executives\"\n\t\t\t},\n\t\t\t\"profile\": {\n\t\t\t\t\"profileId\": \"P001\",\n\t\t\t\t\"profileName\": \"DefaultProfile\",\n\t\t\t\t\"networkControl\": \"true\",\n\t\t\t\t\"passcodePolicyCode\": \"JUNK\",\n\t\t\t\t\"securityPolicyCode\": \"SB\",\n\t\t\t\t\"applications\": {\n\t\t\t\t\t\"application\": [{\n\t\t\t\t\t\t\"appId\": \"App1\",\n\t\t\t\t\t\t\"appType\": \"1\",\n\t\t\t\t\t\t\"emailNotification\": \"Yes\",\n\t\t\t\t\t\t\"sendNotification\": \"No\"\n\t\t\t\t\t},\n\t\t\t\t\t{\n\t\t\t\t\t\t\"appId\": \"App2\",\n\t\t\t\t\t\t\"appType\": \"1\",\n\t\t\t\t\t\t\"emailNotification\": \"No\",\n\t\t\t\t\t\t\"sendNotification\": \"No\"\n\t\t\t\t\t}]\n\t\t\t\t}\n\t\t\t}\n\t\t}]\n\t}\n}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/devices/enrolldevice", HttpMethod.POST, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	
	}	
	
	
	@Test
	public void testEnrollWithInvalidSecurityPolicyCodeValue() throws Exception {
		
		String requestJson = "{\n\t\"emmAccountId\": \"30059025\",\n\t\"fan\": \"5001234\",\n\t\"email\": \"4699099424@txt.att.com\",\n\t\"liabilityType\": \"BAU\",\n\t\"enrollments\": {\n\t\t\"enrollment\": [{\n\t\t\t\"lineId\": \"xnxn-9898-fghg-ghgh\",\n\t\t\t\"device\": {\n\t\t\t\t\"id\": \"ApplC39KVZU7FH19\",\n\t\t\t\t\"imei\": \"123\",\n\t\t\t\t\"platform\": \"iOS\"\n\t\t\t},\n\t\t\t\"user\": {\n\t\t\t\t\"firstName\": \"Aniket\",\n\t\t\t\t\"lastName\": \"Vidhate\",\n\t\t\t\t\"ctn\": \"9224970888\",\n\t\t\t\t\"email\": \"av00419874@att.com\",\n\t\t\t\t\"domain\": \"att.com\",\n\t\t\t\t\"ban\": \"321312312\"\n\t\t\t},\n\t\t\t\"group\": {\n\t\t\t\t\"groupId\": \"G001\",\n\t\t\t\t\"groupName\": \"Executives\"\n\t\t\t},\n\t\t\t\"profile\": {\n\t\t\t\t\"profileId\": \"P001\",\n\t\t\t\t\"profileName\": \"DefaultProfile\",\n\t\t\t\t\"networkControl\": \"true\",\n\t\t\t\t\"passcodePolicyCode\": \"PN\",\n\t\t\t\t\"securityPolicyCode\": \"JUNK\",\n\t\t\t\t\"applications\": {\n\t\t\t\t\t\"application\": [{\n\t\t\t\t\t\t\"appId\": \"App1\",\n\t\t\t\t\t\t\"appType\": \"1\",\n\t\t\t\t\t\t\"emailNotification\": \"Yes\",\n\t\t\t\t\t\t\"sendNotification\": \"No\"\n\t\t\t\t\t},\n\t\t\t\t\t{\n\t\t\t\t\t\t\"appId\": \"App2\",\n\t\t\t\t\t\t\"appType\": \"1\",\n\t\t\t\t\t\t\"emailNotification\": \"No\",\n\t\t\t\t\t\t\"sendNotification\": \"No\"\n\t\t\t\t\t}]\n\t\t\t\t}\n\t\t\t}\n\t\t}]\n\t}\n}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/devices/enrolldevice", HttpMethod.POST, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	
	}
	
	
	@Test
	public void testEnrollWithInvalidPlatformValue() throws Exception {
		
		String requestJson = "{\n\t\"emmAccountId\": \"30059025\",\n\t\"fan\": \"5001234\",\n\t\"email\": \"4699099424@txt.att.com\",\n\t\"liabilityType\": \"BAU\",\n\t\"enrollments\": {\n\t\t\"enrollment\": [{\n\t\t\t\"lineId\": \"xnxn-9898-fghg-ghgh\",\n\t\t\t\"device\": {\n\t\t\t\t\"id\": \"ApplC39KVZU7FH19\",\n\t\t\t\t\"imei\": \"123\",\n\t\t\t\t\"platform\": \"iOS\"\n\t\t\t},\n\t\t\t\"user\": {\n\t\t\t\t\"firstName\": \"Aniket\",\n\t\t\t\t\"lastName\": \"Vidhate\",\n\t\t\t\t\"ctn\": \"9224970888\",\n\t\t\t\t\"email\": \"av00419874@att.com\",\n\t\t\t\t\"domain\": \"att.com\",\n\t\t\t\t\"ban\": \"321312312\"\n\t\t\t},\n\t\t\t\"group\": {\n\t\t\t\t\"groupId\": \"G001\",\n\t\t\t\t\"groupName\": \"Executives\"\n\t\t\t},\n\t\t\t\"profile\": {\n\t\t\t\t\"profileId\": \"P001\",\n\t\t\t\t\"profileName\": \"DefaultProfile\",\n\t\t\t\t\"networkControl\": \"true\",\n\t\t\t\t\"passcodePolicyCode\": \"PN\",\n\t\t\t\t\"securityPolicyCode\": \"JUNK\",\n\t\t\t\t\"applications\": {\n\t\t\t\t\t\"application\": [{\n\t\t\t\t\t\t\"appId\": \"App1\",\n\t\t\t\t\t\t\"appType\": \"1\",\n\t\t\t\t\t\t\"emailNotification\": \"Yes\",\n\t\t\t\t\t\t\"sendNotification\": \"No\"\n\t\t\t\t\t},\n\t\t\t\t\t{\n\t\t\t\t\t\t\"appId\": \"App2\",\n\t\t\t\t\t\t\"appType\": \"1\",\n\t\t\t\t\t\t\"emailNotification\": \"No\",\n\t\t\t\t\t\t\"sendNotification\": \"No\"\n\t\t\t\t\t}]\n\t\t\t\t}\n\t\t\t}\n\t\t}]\n\t}\n}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/devices/enrolldevice", HttpMethod.POST, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	
	}	
	

	@Test
	public void testEnrollWithCorrectInput() throws Exception {
		
		String requestJson = "{\r\n\"emmAccountId\": \"30059025\",\r\n\"fan\":\"fan12345\",\r\n\"email\": \"4699099424@txt.att.com\",\r\n\"liabilityType\" : \"BAU\",\r\n\"enrollments\": {\r\n\"enrollment\": [{\r\n\"lineId\": \"xnxn-9898-fghg-ghgh\",\r\n\"device\": {\r\n\"id\": \"ApplC39KVZU7FH19\",\r\n\"imei\": \"123\",\r\n\"platform\": \"iOS\"\r\n},\r\n\"user\": {\r\n\"firstName\": \"Aniket\",\r\n\"lastName\": \"Vidhate\",\r\n\"ctn\": \"9224970888\",\r\n\"email\": \"av00419874@att.com\",\r\n\"domain\": \"att.com\",\r\n\"ban\":\"321312312\"\r\n},\r\n\"group\": {\r\n\"groupId\": \"G001\",\r\n\"groupName\": \"Executives\"\r\n},\r\n\"profile\": {\r\n\"profileId\": \"P001\",\r\n\"profileName\": \"DefaultProfile\",\r\n\"networkControl\": \"true\",\r\n\"passcodePolicyCode\": \"PN\",\r\n\"securityPolicyCode\": \"SB\",\r\n\"applications\": {\r\n\"application\": [{\r\n\"appId\": \"App1\",\r\n\"appType\": \"1\",\r\n\"emailNotification\": \"Yes\",\r\n\"sendNotification\": \"No\"\r\n},\r\n{\r\n\"appId\": \"App2\",\r\n\"appType\": \"1\",\r\n\"emailNotification\": \"No\",\r\n\"sendNotification\": \"No\"\r\n}]\r\n}\r\n}\r\n}]\r\n}}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/devices/enrolldevice", HttpMethod.POST, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
		//assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	
	}
	
	
	@Test
	public void testEnrollWithCorrectInputMissingNonMandatoryGroupObject() throws Exception {
		
		String requestJson = "{\n\"emmAccountId\": \"30059025\",\n\"fan\":\"fan12345\",\n\"email\": \"4699099424@txt.att.com\",\n\"liabilityType\" : \"BAU\",\n\"enrollments\": {\n\"enrollment\": [{\n\"lineId\": \"xnxn-9898-fghg-ghgh\",\n\"device\": {\n\"id\": \"ApplC39KVZU7FH19\",\n\"imei\": \"123\",\n\"platform\": \"iOS\"\n},\n\"user\": {\n\n\"lastName\": \"Vidhate\",\n\"ctn\": \"9224970888\",\n\"email\": \"av00419874@att.com\",\n\"domain\": \"att.com\",\n\"ban\":\"321312312\"\n},\n\n\"profile\": {\n\"profileId\": \"P001\",\n\"profileName\": \"DefaultProfile\",\n\"networkControl\": \"true\",\n\"passcodePolicyCode\": \"PN\",\n\"securityPolicyCode\": \"SB\",\n\"applications\": {\n\"application\": [{\n\"appId\": \"App1\",\n\"appType\": \"1\",\n\"emailNotification\": \"Yes\",\n\"sendNotification\": \"No\"\n},\n{\n\"appId\": \"App2\",\n\"appType\": \"1\",\n\"emailNotification\": \"No\",\n\"sendNotification\": \"No\"\n}]\n}\n}\n}]\n}}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/devices/enrolldevice", HttpMethod.POST, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
		//assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	
	}
		
	
	@Test
	public void testEnrollWithMultipleEnrollmentCorrectInput() throws Exception {
		
		String requestJson = "{\r\n\"emmAccountId\": \"30059025\",\r\n\"fan\": \"5001234\",\r\n\"liabilityType\":\"CRU\",\r\n\"email\": \"4699099424@txt.att.com\",\r\n\"enrollments\": {\r\n\"enrollment\": [{\r\n\"lineId\": \"xnxn-9898-fghg-ghgh\",\r\n\"device\": {\r\n\"id\": \"ApplC39KVZU7FH19\",\r\n\"imei\": \"123\",\r\n\"platform\": \"iOS\"\r\n},\r\n\"user\": {\r\n\"firstName\": \"Aniket\",\r\n\"lastName\": \"Vidhate\",\r\n\"ctn\": \"9224970889\",\r\n\"email\": \"av00419874@att.com\",\r\n\"domain\": \"att.com\",\r\n\"ban\":\"321312312\"\r\n},\r\n\"group\": {\r\n\"groupId\": \"G001\",\r\n\"groupName\": \"Executives\"\r\n},\r\n\"profile\": {\r\n\"profileId\": \"P001\",\r\n\"profileName\": \"DefaultProfile\",\r\n\"networkControl\": \"true\",\r\n\"passcodePolicyCode\": \"PN\",\r\n\"securityPolicyCode\": \"SB\",\r\n\"applications\": {\r\n\"application\": [{\r\n\"appId\": \"App1\",\r\n\"appType\": \"1\",\r\n\"emailNotification\": \"Yes\",\r\n\"sendNotification\": \"No\"\r\n},\r\n{\r\n\"appId\": \"App2\",\r\n\"appType\": \"1\",\r\n\"emailNotification\": \"No\",\r\n\"sendNotification\": \"No\"\r\n}]\r\n}\r\n}\r\n},\r\n{\r\n\"lineId\": \"xnxn-9898-fghg-ghgh\",\r\n\"device\": {\r\n\"id\": \"ApplC39KVZU7FH19\",\r\n\"imei\": \"123\",\r\n\"platform\": \"iOS\"\r\n},\r\n\"user\": {\r\n\"firstName\": \"Aniket\",\r\n\"lastName\": \"Vidhate\",\r\n\"ctn\": \"9224970888\",\r\n\"email\": \"av00419874@att.com\",\r\n\"domain\": \"att.com\",\r\n\"ban\":\"321312312\"\r\n},\r\n\"group\": {\r\n\"groupId\": \"G001\",\r\n\"groupName\": \"Executives\"\r\n},\r\n\"profile\": {\r\n\"profileId\": \"P001\",\r\n\"profileName\": \"DefaultProfile\",\r\n\"networkControl\": \"true\",\r\n\"passcodePolicyCode\": \"PN\",\r\n\"securityPolicyCode\": \"SB\",\r\n\"applications\": {\r\n\"application\": [{\r\n\"appId\": \"App1\",\r\n\"appType\": \"1\",\r\n\"emailNotification\": \"Yes\",\r\n\"sendNotification\": \"No\"\r\n},\r\n\r\n{\r\n\"appId\": \"App2\",\r\n\"appType\": \"1\",\r\n\"emailNotification\": \"No\",\r\n\"sendNotification\": \"No\"\r\n}]\r\n}\r\n}\r\n}]}}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/devices/enrolldevice", HttpMethod.POST, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
		//assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	
	}
	
	

	
}
