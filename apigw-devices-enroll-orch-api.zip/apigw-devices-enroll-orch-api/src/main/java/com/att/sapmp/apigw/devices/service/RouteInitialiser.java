package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

public class RouteInitialiser extends BaseProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(RouteInitialiser.class);

	@Override
	public void execute(Exchange e) throws ApigwException {
		String postReq = (String) (e.getIn().getBody());
		log.info("Enroll Orch payload request = " + postReq);

		if (StringUtils.isEmpty(postReq)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "User Account request  is null in input");
		}
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> enrollDeviceMap = null;
		try {
			enrollDeviceMap = objectMapper.readValue(postReq, HashMap.class);
		} catch (IOException e1) {
			log.error("Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		List<Map<String, Object>> enrollmentList = null;
		if (enrollDeviceMap != null && !enrollDeviceMap.isEmpty()) {
			validateJSON(new JSONObject(enrollDeviceMap), CommonDefs.ENROLL_DEVICE_COMMON_MANDATORY_FIELDS);
			Map<String, Object> enrollmentsMap = (Map<String, Object>) enrollDeviceMap.get(CommonDefs.ENROLLMENTS);
			if (enrollmentsMap == null || enrollmentsMap.isEmpty()) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CErrorDefs.ERROR_ENROLL_REQUEST_INVALID);
			} else {
				enrollmentList = (List<Map<String, Object>>) enrollmentsMap.get(CommonDefs.ENROLLMENT);
				if (enrollmentList == null || enrollmentList.isEmpty()) {
					throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CErrorDefs.ERROR_ENROLL_REQUEST_INVALID);
				} else {
					validateJSONArray(new JSONArray(enrollmentList), CommonDefs.ENROLL_ORCH_JSON_MANDATORY_FIELDS);
				}
			}
		} else {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_ENROLL_REQUEST_INVALID);
		}
		for (Map<String, Object> hmEnrollRequest : enrollmentList) {
			validateSecurityPasscodePlatform(hmEnrollRequest);
			validateRequest(hmEnrollRequest, e);
		}
		e.getIn().setHeader(CommonDefs.ENROLLMENT_LIST, enrollmentList);
		e.setProperty(CommonDefs.ORIGIONAL_BODY, enrollDeviceMap);
		e.setProperty(CommonDefs.EMM_ACCOUNT_ID, enrollDeviceMap.get(CommonDefs.EMM_ACCOUNT_ID));
		e.setProperty(CommonDefs.FAN, enrollDeviceMap.get(CommonDefs.FAN));
	}

	public final void split(Exchange e) throws ApigwException {
		try {
			Map<String, Object> hmEnrollRequest = (Map<String, Object>) e.getIn().getBody();
			e.setProperty(CommonDefs.ENROLLMENT, hmEnrollRequest);
		} catch (Exception ex) {
			log.error("Error while processing multiple Enrolment request....", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}

	public final void validateRequest(Map<String, Object> hmImput, Exchange e) throws ApigwException {
		validateJSONReq(new JSONObject(hmImput), CommonDefs.ENROLL_DEVICE_ORCH_MANDATORY_FIELDS, e);
	}

	private void validateSecurityPasscodePlatform(Map<String, Object> enrollMap) throws ApigwException {
		Map<String, Object> profileMap = (Map<String, Object>) enrollMap.get(CommonDefs.PROFILE_JSON);
		Map<String, Object> deviceMap = (Map<String, Object>) enrollMap.get(CommonDefs.DEVICE_JSON);
		String passcodePolicyCode = String.valueOf(profileMap.get(CommonDefs.PASSCODE_POLOCY_CODE));
		String securityPolicyCode = String.valueOf(profileMap.get(CommonDefs.SECURITY_POLOCY_CODE));
		String platform = String.valueOf(deviceMap.get(CommonDefs.PLATFORM));
		if (!CommonDefs.PASSCODE_POLICY_CODE_VALUES.contains(passcodePolicyCode)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "passcodePolicyCode request is not valid");
		}
		if (!CommonDefs.SECURITY_POLICY_CODE_VALUES.contains(securityPolicyCode)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "securityPolicyCode request is not valid");
		}
		if (!CommonDefs.PLATFORM_CODE_VALUES.contains(platform)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "platform request is not valid");
		}
	}
}
