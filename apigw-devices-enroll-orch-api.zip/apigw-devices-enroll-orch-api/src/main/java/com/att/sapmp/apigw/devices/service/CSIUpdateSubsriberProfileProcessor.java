package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;

@Component
public class CSIUpdateSubsriberProfileProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CSIUpdateSubsriberProfileProcessor.class);
	@Value("${csi.location}")
	private String location;
	@Value("${csi.offer.code}")
	private String code;
	@Value("${csi.originatorId}")
	private String originatorId;
	@Value("${csi.salesRepresentative}")
	private String salesRepresentative;
	@Value("${csi.dealer.code}")
	private String dealerCode;
	@Value("${csi.updateSub.enroll.action}")
	private String updateSubEnrollAction;
	@Value("${csi.updateSub.version}")
	private String csiVersion;
	@Autowired
	CommonUtil commonUtil;

	public final void executeAddSoc(Exchange e) throws ApigwException {
		String trackingId = String.valueOf(e.getProperty(CommonDefs.TRACKING_ID));
		HashMap<String, Object> subProfileMap = new HashMap<>();
		commonUtil.populateCSIHeader(subProfileMap);
		subProfileMap.put(CommonDefs.VERSION_NO, csiVersion);
		subProfileMap.put(CommonDefs.MESSAGE_ID, trackingId);
		subProfileMap.put(CommonDefs.ORIGINATOR_ID, originatorId);
		subProfileMap.put(CommonDefs.OFFERING_CODE, code);
		subProfileMap.put(CommonDefs.LOCATION, location);
		subProfileMap.put(CommonDefs.SALES_REPRESENTATIVE, salesRepresentative);
		subProfileMap.put(CommonDefs.DEALER_CODE, dealerCode);
		subProfileMap.put(CommonDefs.SUBSCRIBER_NUMBER, e.getProperty(CommonDefs.CTN));
		subProfileMap.put(CommonDefs.ACTION, updateSubEnrollAction);
		subProfileMap.put(CommonDefs.EFFECTIVE_DATE, CommonUtil.getGMTDatAsString());
		subProfileMap.put(CommonDefs.EXPIRATION_DATE, CommonUtil.getGMTDatAsString());
		VelocityContext velocityContext = new VelocityContext(subProfileMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	public void updateSubProfileSuccessResponse(Exchange exchange) throws ApigwException {
		String csiResposeBody = exchange.getIn().getBody(String.class);
		log.info("Received Response in updateSubProfileSuccessResponse method. ResponseCode ::"
				+ exchange.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		commonUtil.logXML("Received response in updateSubProfileSuccessResponse method", csiResposeBody);
		exchange.setProperty(CommonDefs.PROCESS_ENROLLMENT, CommonDefs.Y);
		exchange.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.ENROLLMENT_INITIATED);
		exchange.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.MDM_ACTIVATION_PENDING);
	}

	public void updateSubProfileErrorResponse(Exchange exchange) throws ApigwException {
		String csiResposeBody = exchange.getIn().getBody(String.class);
		log.info("Received Response in updateSubProfileErrorResponse method. ResponseCode ::"
				+ exchange.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		commonUtil.logXML("Received response in updateSubProfileErrorResponse method", csiResposeBody);
		exchange.setProperty(CommonDefs.PROCESS_ENROLLMENT, CommonDefs.N);
		exchange.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.ENROLLMENT_INITIATED);
		exchange.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.ADD_TRACKING_SOC_FAILED);
	}
}
