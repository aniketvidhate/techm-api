package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;

/**
 * @author av0041
 *
 */
@Component
public class CreateUserProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateUserProcessor.class);
	@Autowired
	CommonUtil commonUtil;

	@SuppressWarnings("unchecked")
	public final void execute(Exchange e) throws ApigwException {
		String emmAccountId = null;
		HashMap<String, Object> enrollDeviceMap = (HashMap<String, Object>) e.getIn().getBody();
		log.info("Execution started for CreateUserProcessor Request Payload = " + enrollDeviceMap);
		Map<String, Object> userMap;
		String fan;
		if (enrollDeviceMap != null && !enrollDeviceMap.isEmpty()) {
			fan = (String) e.getProperty(CommonDefs.FAN);
			emmAccountId = (String) e.getProperty(CommonDefs.EMM_ACCOUNT_ID);
			if (StringUtils.isEmpty(emmAccountId)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "emmAccountId is empty");
			}
			emmAccountId = emmAccountId.trim();
			userMap = (Map<String, Object>) enrollDeviceMap.get(CommonDefs.USER);
			if (userMap.isEmpty()) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
			}
			HashMap<String, Object> hmDevice = (HashMap<String, Object>) enrollDeviceMap.get(CommonDefs.DEVICE);
			if (hmDevice != null && !hmDevice.isEmpty()) {
				String deviceId = (String) hmDevice.get(CommonDefs.ID);
				e.setProperty(CommonDefs.ID, deviceId);
			}
		} else {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		String productCode = (String) (e.getIn().getHeader(CommonDefs.EMMP_PRODUCT_CODE));
		String createUserUrl = commonUtil.getProperty(productCode + "." + CommonDefs.CREATE_USER_URL);
		if (StringUtils.isEmpty(createUserUrl)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001,
					"Unable to Search MDM Partner with input Product Code");
		}
		createUserUrl = createUserUrl + "/" + fan + "_" + userMap.get(CommonDefs.CTN);
		e.setProperty(CommonDefs.EMAIL, userMap.get(CommonDefs.EMAIL));
		e.getIn().setHeader(CommonDefs.MDM_CREATE_USER_URL, createUserUrl);
		e.getIn().setHeader(CommonDefs.BILLING_ID, emmAccountId);
		VelocityContext velocityContext = new VelocityContext(userMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	@SuppressWarnings("unchecked")
	public final void handleCreateUserSuccessResponse(Exchange e) throws ApigwException {
		String responseBody = e.getIn().getBody(String.class);
		log.info("Received response in handleCreateUserSuccessResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + responseBody);
		e.setProperty(CommonDefs.PROCESS_ENROLLMENT, CommonDefs.Y);
	}

	public final void handleCreateUserErrorResponse(Exchange e) throws ApigwException {
		String responseBody = e.getIn().getBody(String.class);
		log.info("Received response in handleCreateUserErrorResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + responseBody);
		e.setProperty(CommonDefs.PROCESS_ENROLLMENT, CommonDefs.N);
		e.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.ENROLLMENT_FAILED);
		e.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.CREATE_DEVICE_USER_FAILED);
	}
}