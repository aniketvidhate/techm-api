package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;

@Component
public class CSISendSmsProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CSISendSmsProcessor.class);
	@Value("${csi.sourceAddress}")
	private String sourceAddress;
	@Value("${csi.sendsms.version}")
	private String csiVersion;
	@Autowired
	CommonUtil commonUtil;

	public final void executeSendSms(Exchange e) throws ApigwException {
		String ctn = (String) e.getProperty(CommonDefs.CTN);
		String messageBody = (String) e.getProperty(CommonDefs.SMSPARAMETERS);
		JSONObject jsonResponse = new JSONObject(messageBody);
		String email = (String) e.getProperty(CommonDefs.EMAIL);
		String trackingId = String.valueOf(e.getProperty("trackingId"));
		String smsUrl = (String) jsonResponse.get(CommonDefs.ENROLL_DEVICE_RESP_SMS_URL);
		Integer smsCorpID = (Integer) jsonResponse.get(CommonDefs.ENROLL_DEVICE_RESP_SMS_CORP_ID);
		String smsPassCode = (String) jsonResponse.get(CommonDefs.ENROLL_DEVICE_RESP_SMS_PASS_CODE);
		HashMap<String, Object> sendSmsMap = new HashMap<>();
		commonUtil.populateCSIHeader(sendSmsMap);
		sendSmsMap.put(CommonDefs.VERSION_NO, csiVersion);
		sendSmsMap.put(CommonDefs.MESSAGE_ID, trackingId);
		sendSmsMap.put(CommonDefs.DESTINATION_ADDRESS, ctn);
		sendSmsMap.put(CommonDefs.SOURCE_ADDRESS, sourceAddress);
		sendSmsMap.put(CommonDefs.EMAIL, email);
		sendSmsMap.put(CommonDefs.SMS_URL, smsUrl);
		sendSmsMap.put(CommonDefs.SMS_CORP_ID, smsCorpID);
		sendSmsMap.put(CommonDefs.SMS_PASS_CODE, smsPassCode);
		VelocityContext velocityContext = new VelocityContext(sendSmsMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	public void handleSuccessResponse(Exchange exchange) throws ApigwException {
		String csiResposeBody = exchange.getIn().getBody(String.class);
		log.info("Response in CSISendSMS handleSuccessResponse method. ResponseCode ::"
				+ exchange.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		commonUtil.logXML("Received response in handleSuccessResponse method", csiResposeBody);
		exchange.setProperty(CommonDefs.PROCESS_ENROLLMENT, CommonDefs.Y);
	}

	public void handleErrorResponse(Exchange exchange) throws ApigwException {
		String csiResposeBody = exchange.getIn().getBody(String.class);
		log.info("Response in CSISendSMS handleErrorResponse method. ResponseCode ::"
				+ exchange.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		commonUtil.logXML("Received response in handleErrorResponse method", csiResposeBody);
		exchange.setProperty(CommonDefs.PROCESS_ENROLLMENT, CommonDefs.N);
		exchange.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.ENROLLMENT_FAILED);
		exchange.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.SEND_ENROLLMENT_SMS_FAILED);
	}
}
