package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;

@Component
public class CSIManageEnterpriseDeviceDeploymentDetailsProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CSIManageEnterpriseDeviceDeploymentDetailsProcessor.class);
	@Autowired
	CommonUtil commonUtil;

	@SuppressWarnings("unchecked")
	public final void execute(Exchange e) throws ApigwException {
		String trackingId = String.valueOf(e.getProperty(CommonDefs.TRACKING_ID));
		HashMap<String, Object> csiManageDeviceDetailsMap = new HashMap<>();
		commonUtil.populateCSIHeader(csiManageDeviceDetailsMap);
		csiManageDeviceDetailsMap.put(CommonDefs.MESSAGE_ID, trackingId);
		csiManageDeviceDetailsMap.put(CommonDefs.DEVICE_ID, e.getProperty(CommonDefs.ID));
		csiManageDeviceDetailsMap.put(CommonDefs.MODE, CommonDefs.U);
		csiManageDeviceDetailsMap.put(CommonDefs.IMEI, e.getProperty(CommonDefs.IMEI));
		String enrollmentStatus = (String) e.getProperty(CommonDefs.ENROLLMENT_STATUS);
		String enrollmentSubStatus = (String) e.getProperty(CommonDefs.ENROLLMENT_SUB_STATUS);
		csiManageDeviceDetailsMap.put(CommonDefs.ENROLLMENT_STATUS, enrollmentStatus);
		csiManageDeviceDetailsMap.put(CommonDefs.ENROLLMENT_SUB_STATUS, enrollmentSubStatus);
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityType.toString(), CommonDefs.ACTIVITY_TYPE_ENROLL);
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityCategory.toString(), CommonDefs.ACTIVITY_CATEGORY_ENROLLMENT);
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityDetails.toString(), enrollmentSubStatus);
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.source.toString(), CommonDefs.SOURCE_SAPMP);
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityDate.toString(), CommonUtil.getGMTdatetimeAsString());
		VelocityContext velocityContext = new VelocityContext(csiManageDeviceDetailsMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	public final void handleCsiManageDeviceDetailResponse(Exchange e) throws ApigwException {
		String body = e.getIn().getBody(String.class);
		log.info("Received Response in handleCsiManageDeviceDetailResponse. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		commonUtil.logXML("Received response in handleCsiManageDeviceDetailResponse method", body);
	}
}