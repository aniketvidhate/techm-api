package com.att.sapmp.apigw.devices.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;

/**
 * @author vn212m
 *
 */
@Component
public class DeviceEnrollmentProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceEnrollmentProcessor.class);
	@Autowired
	CommonUtil commonUtil;

	public final void process(Exchange e) throws ApigwException {
		String deviceId = null;
		String imei = null;
		String ctn = null;
		HashMap<String, Object> enrollDevicesMap = (HashMap<String, Object>) e.getProperty(CommonDefs.ORIGIONAL_BODY);
		HashMap<String, Object> enrollDeviceMap = (HashMap<String, Object>) e.getProperty(CommonDefs.ENROLLMENT);
		Map<String, Object> enrollmentMap = new HashMap<>();
		if (enrollDevicesMap == null || enrollDevicesMap.isEmpty() || enrollDeviceMap == null
				|| enrollDeviceMap.isEmpty()) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "Enroll Device request  is null in input");
		}
		List<Map<String, Object>> enrollmentList = new ArrayList<>();
		enrollmentList.add(enrollDeviceMap);
		enrollmentMap.put(CommonDefs.ENROLLMENT, enrollmentList);
		enrollDevicesMap.put(CommonDefs.ENROLLMENTS, enrollmentMap);
		HashMap<String, Object> hmDevice = (HashMap<String, Object>) enrollDeviceMap.get(CommonDefs.DEVICE);
		if (hmDevice != null && !hmDevice.isEmpty()) {
			deviceId = (String) hmDevice.get(CommonDefs.ID);
			imei = (String) hmDevice.get(CommonDefs.IMEI);
		}
		HashMap<String, Object> hmUser = (HashMap<String, Object>) enrollDeviceMap.get(CommonDefs.USER);
		if (hmUser != null && !hmUser.isEmpty()) {
			ctn = (String) hmUser.get(CommonDefs.CTN);
		}
		e.setProperty(CommonDefs.CTN, ctn);
		e.setProperty(CommonDefs.IMEI, imei);
		e.setProperty(CommonDefs.ID, deviceId);
		e.getIn().setBody(new JSONObject(enrollDevicesMap).toString());
	}

	public final void handleEnrollDeviceSuccessResponse(Exchange e) throws ApigwException {
		String responseBody = e.getIn().getBody(String.class);
		log.info("Response in DeviceEnrollmentProcessor handleEnrollDeviceSuccessResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + responseBody);
		e.setProperty(CommonDefs.PROCESS_ENROLLMENT, CommonDefs.Y);
		e.setProperty(CommonDefs.SMSPARAMETERS, responseBody);
	}

	public final void handleEnrollDeviceErrorResponse(Exchange e) throws ApigwException {
		String responseBody = e.getIn().getBody(String.class);
		log.info("Response in DeviceEnrollmentProcessor handleEnrollDeviceErrorResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + responseBody);
		e.setProperty(CommonDefs.PROCESS_ENROLLMENT, CommonDefs.N);
		e.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.ENROLLMENT_FAILED);
		e.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.ENROLL_DEVICE_FAILED);
	}

	public final void handleEnrollDeviceTask(Exchange e) throws Exception {
		Map<String, Object> enrollTaskMap = new HashMap<>();
		enrollTaskMap.put(CommonDefs.IMEI, e.getProperty(CommonDefs.IMEI));
		enrollTaskMap.put(CommonDefs.DEVICE_ID, e.getProperty(CommonDefs.ID));
		VelocityContext velocityContext = new VelocityContext(enrollTaskMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		log.info("Request in DeviceEnrollmentProcessor handleEnrollDeviceTask method.Payload ::" + enrollTaskMap);
	}

	public final void handleEnrollTaskResponse(Exchange e) throws Exception {
		log.info("Response in DeviceEnrollmentProcessor handleEnrollTaskResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
	}

	public final void processAsyncResponse(Exchange e) throws ApigwException {
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		e.getIn().setBody("");
		log.info("Response in DeviceEnrollmentProcessor processAsyncResponse method. ResponseCode ::"+CommonDefs.RESPONSE_ACCEPT_CODE);

	}
}