package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

@Component
public class CSIInquireEnterpriseDeviceDeploymentDetailsProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CSIInquireEnterpriseDeviceDeploymentDetailsProcessor.class);
	@Autowired
	CommonUtil commonUtil;

	public final void execute(Exchange e) throws ApigwException {
		e.getIn().setHeaders(e.getIn().getHeaders());
		HashMap<String, Object> csiInquireDeviceDetailsMap = new HashMap<String, Object>();
		commonUtil.populateCSIHeader(csiInquireDeviceDetailsMap);
		csiInquireDeviceDetailsMap.put(CommonDefs.MESSAGE_ID, String.valueOf(e.getProperty(CommonDefs.TRACKING_ID)));
		csiInquireDeviceDetailsMap.put(CommonDefs.IMEI, e.getProperty(CommonDefs.IMEI));
		csiInquireDeviceDetailsMap.put(CommonDefs.DEVICE_ID, e.getProperty(CommonDefs.DEVICE_ID));
		VelocityContext velocityContext = new VelocityContext(csiInquireDeviceDetailsMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	public final void handleCsiInquireDeviceDetailResponse(Exchange e)
			throws ApigwException {
		String csiResposeBody = (String) e.getIn().getBody();
		log.info("Received Response in handleCsiInquireDeviceDetailResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		
		commonUtil.logXML("Received response in handleCsiInquireDeviceDetailResponse method", csiResposeBody);
		
		XmlMapper xmlMapper = new XmlMapper();
		Map<String, Object> csiResponseMap = null;
		try {
			csiResponseMap = xmlMapper.readValue(csiResposeBody, HashMap.class);
		} catch (Exception ioe) {
			log.error("Exception occurred while parsing post request: " + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		Map<String, Object> bodyMap = (HashMap<String, Object>) csiResponseMap.get(CommonDefs.BODY);
		if (bodyMap != null && !(bodyMap.isEmpty())) {
			Map<String, Object> inquireDetailsResponse = (HashMap<String, Object>) bodyMap
					.get(CommonDefs.IEDDD_RESPONSE);
			if (inquireDetailsResponse != null && !(inquireDetailsResponse.isEmpty())) {
				Map<String, Object> deviceDetailList = (HashMap<String, Object>) inquireDetailsResponse
						.get(CommonDefs.DEVICE_DETAIL_LIST);
				if (deviceDetailList != null && !(deviceDetailList.isEmpty())) {
					String deviceDetailsEnrollmentStatus = (String) deviceDetailList
							.get(CommonDefs.ENROLLMENT_STATUS);
					log.info("Getting the response of Enrollment Status ::" + deviceDetailsEnrollmentStatus);
					String emmDeviceId = (String) deviceDetailList.get(CommonDefs.EMM_DEVICE_ID);
					if ((deviceDetailsEnrollmentStatus != null
							&& deviceDetailsEnrollmentStatus.equalsIgnoreCase(CommonDefs.ENROLLMENT_SUCCESS))
							&& (emmDeviceId != null && !emmDeviceId.isEmpty())) {
						log.info("Enrollment Successful. No need to apply APN");
					} else {
						e.getIn().setHeader(CommonDefs.APPLY_APN, CommonDefs.YES);
					}
				}
			}
		}
		log.info("End of handleCsiInquireDeviceDetailResponse");
	}
}