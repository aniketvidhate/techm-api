package com.att.sapmp.apigw.devices.util;

import java.util.Arrays;
import java.util.List;

public class CommonDefs {
	public static final String BILLING_ID = "billingId";
	public static final String ACCOUNT_PASS_PHRASE = "AccountPassPhrase";
	public static final String USER_NAME = "userName";
	public static final String PARTNER_ACCOUNT = "partnerAccount";
	public static final String[] NON_ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductcode",
			"accountpassphrase" };
	public static final String[] ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductCode" };
	public static final String EMM_ACCOUNT_ID = "emmAccountId";
	public static final String DEVICE_ID = "deviceId";
	public static final String CAMEL_HTTP_RESPONSE_CODE = "CamelHttpResponseCode";
	public static final String EMM_PRODUCT_CODE = "emmproductcode";
	public static final String TRACKING_ID = "trackingid";
	public static final String DEVICE = "device";
	public static final String DEVICES = "devices";
	// Added for Lock Device MDM API
	public static final String ZERO = "0";
	public static final String RESPONSE_ACCEPT_CODE = "202";
	public static final String EMAIL = "email";
	public static final String DOMAIN = "domain";
	public static final String DATE = "Date";
	public static final String STATUS = "status";
	public static final String RESPONSE_CREATED_CODE = "201";
	// Added for Enroll Device MDM API
	public static final String ENROLLMENTS = "enrollments";
	public static final String ENROLLMENT = "enrollment";
	public static final String ENROLLMENT_LIST = "enrollmentList";
	public static final String USER = "user";
	public static final String FIRST_NAME = "firstName";
	public static final String LAST_NAME = "lastName";
	public static final String NO = "No";
	public static final String URL = "url";
	public static final String ENROLLMENT_SUCCESS = "ENROLLMENT_SUCCESS";
	public static final String PROFILE_ID = "profileId";
	public static final String ACTION_TYPE = "actionType";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String EMM_DEVICE_ID = "emmDeviceId";
	public static final String DESCRIPTION = "description";
	public static final String PRODUCT_CODE = "productCode";
	public static final String EMMP_PRODUCT_CODE = "EMMProductCode";
	public static final String ORIGIONAL_BODY = "origionalBody";
	public static final String MESSAGE = "message";
	public static final String AUTHORIZATION = "Authorization";
	// Added for Enrollment Device
	public static final String PLATFORM = "platform";
	public static final String DEVICE_JSON = "device";
	public static final String PROFILE_JSON = "profile";
	public static final String APPLICATIONS_JSON = "applications";
	public static final String SECURITY_POLOCY_CODE = "securityPolicyCode";
	public static final String PASSCODE_POLOCY_CODE = "passcodePolicyCode";
	public static final String UNDERSCORE = "_";
	public static final String SPACE = " ";
	public static final String POLICYSET = "policySet";
	public static final String BAN = "ban";
	public static final String FAN = "fan";
	public static final String CTN = "ctn";
	public static final String FULLNAME = "fullname";
	// Added for createUser
	public static final String[] CREATE_USER_MANDATORY_FIELDS = { CommonDefs.CTN, CommonDefs.EMAIL, CommonDefs.DOMAIN };
	public static final String ID = "id";
	public static final String IMEI = "imei";
	public static final String GROUP_ID = "groupId";
	public static final String GROUP_NAME = "groupName";
	public static final String PROFILE_NAME = "profileName";
	public static final String NETWORK_CONTROL = "networkControl";
	public static final String PASSCODE_POLICY_CODE = "passcodePolicyCode";
	public static final String SECURITY_PASS_CODE = "securityPolicyCode";
	public static final String FAN_NAME = "fanName";
	public static final String EMAIL_ADDRESS_AMLL_CASE = "emailaddress";
	public static final String GROUP_JSON = "group";
	public static final String LINEID = "lineId";
	public static final String DEVICE_DETAILS_APNSTATUS = "device_details_APNstatus";
	public static final String APNSTATUS = "apnStatus";
	// Added for JSON transformation
	public static final String JSON_DEVICE_ID_KEY = "deviceId";
	public static final String JSON_DEVICE_IMEI_KEY = "deviceImei";
	public static final String JSON_DEVICE_PLATFORM_KEY = "devicePlatform";
	public static final String JSON_USER_FIRSTNAME_KEY = "userFirstName";
	public static final String JSON_USER_LASTNAME_KEY = "userLastName";
	public static final String JSON_USER_CTN_KEY = "userCtn";
	public static final String JSON_USER_EMAIL_KEY = "userEmail";
	public static final String JSON_USER_DOMAIN_KEY = "userDomain";
	public static final String JSON_USER_BAN_KEY = "userBan";
	public static final String JSON_GROUPD_GROUPID_KEY = "groupGroupId";
	public static final String JSON_GROUP_GROUPNAME_KEY = "groupGroupName";
	public static final String JSON_PROFILE_PROFILEID_KEY = "profileProfileId";
	public static final String JSON_PROFILE_PROFILENAME_KEY = "profileProfileName";
	public static final String JSON_PROFILE_NETWORKCONTROL_KEY = "profileNetworkControl";
	public static final String JSON_PROFILE_PASSCODEPOLICYCODE_KEY = "profilePasscodePolicyCode";
	public static final String JSON_PROFILE_SECURITYPOLICYCODE_KEY = "profileSecurityPolicyCode";
	public static final String NULL_KEY = "NULL_KEY";
	public static final String[] ENROLL_DEVICE_ORCH_MANDATORY_FIELDS = { "lineId", "id", "imei", "platform", "ban", "ctn", "email", "domain", "profileId",
			"profileName", "networkControl", "passcodePolicyCode", "securityPolicyCode" };
	public static final String LIABILITY_TYPE = "liabilityType";
	// Added for the CSI integration - Manage ADDP Device Details
	public static final String INFRASTRUCTURE_VERSION = "infrastructureVersion";
	public static final String APPLICATION_NAME = "applicationName";
	public static final String VERSION = "version";
	public static final String VERSION_NO = "versionNo";
	public static final String MESSAGE_ID = "messageId";
	public static final String ROUTING_REGION_OVERRIDE = "routingRegionOverride";
	public static final String DATE_TIMESTAMP = "dateTimeStamp";
	public static final String SEQUENCE_NUMBER = "sequenceNumber";
	public static final String TOTAL_IN_SEQUENCE = "totalInSequence";
	public static final String MODE = "mode";
	public static final String ENROLLMENT_STATUS = "enrollmentStatus";
	public static final String ACTIVITY_CATEGORY_ENROLLMENT = "ENROLLMENT";
	public static final String ACTIVITY_TYPE_DEENROLL = "DEENROLL";
	public static final String ACTIVITY_TYPE_ENROLL = "ENROLL";
	public static final String ACTIVITY_DATE_ENROLL = "SAPMP-GW";
	public static final String ENROLLMENT_SUB_STATUS = "enrollmentSubStatus";
	public static final String ENROLLMENT_FAILED = "ENROLLMENT_FAILED";
	public static final String CREATE_DEVICE_USER_FAILED = "CREATE_DEVICEUSER_FAILED";
	public static final String ENROLLMENT_INITIATED = "ENROLLMENT_INITIATED";
	public static final String MDM_ACTIVATION_PENDING = "MDM_ACTIVATION_PENDING";
	public static final String ENROLL_DEVICE_FAILED = "ENROLL_DEVICE_FAILED";
	public static final String SMS_URL = "smsUrl";
	public static final String SMS_CORP_ID = "smsCorpID";
	public static final String SMS_PASS_CODE = "smsPassCode";
	public static final String ENROLL_DEVICE_RESP_SMS_URL = "url";
	public static final String ENROLL_DEVICE_RESP_SMS_CORP_ID = "corporateIdentifier";
	public static final String ENROLL_DEVICE_RESP_SMS_PASS_CODE = "passcode";
	public static final String BODY = "Body";
	public static final String IEDDD_RESPONSE = "InquireEnterpriseDeviceDeploymentDetailsResponse";
	public static final String DEVICE_DETAIL_LIST = "DeviceDetailList";
	public static final String APPLY_APN = "ApplyApn";
	public static final String YES = "Yes";
	// Added for the CSI integration - sendSms
	public static final String DESTINATION_ADDRESS = "destinationAddress";
	public static final String SOURCE_ADDRESS = "sourceAddress";
	public static final String SHORT_MESSAGE = "shortMessage";
	public static final String SMSPARAMETERS = "smsParameters";
	public static final String CODE = "code";
	public static final String OFFERING_CODE = "offeringCode";
	public static final String LOCATION = "location";
	public static final String ORIGINATOR_ID = "originatorId";
	public static final String CONVERSATION_ID = "conversationId";
	public static final String SALES_REPRESENTATIVE = "salesRepresentative";
	public static final String DEALER_CODE = "dealerCode";
	public static final String SUBSCRIBER_NUMBER = "subscriberNumber";
	public static final String EFFECTIVE_DATE = "effectiveDate";
	public static final String EXPIRATION_DATE = "expirationDate";
	// Added for the CSI integration - updateSubscriberProfile
	public static final String ACTION = "action";
	public static final List<String> PASSCODE_POLICY_CODE_VALUES = Arrays.asList("PN", "PB", "PS");
	public static final List<String> SECURITY_POLICY_CODE_VALUES = Arrays.asList("SB", "SE");
	public static final List<String> PLATFORM_CODE_VALUES = Arrays.asList("iOS", "Android", "Windows");
	public static final String CREATE_DEVICE_USER_ERROR = "CREATE_DEVICE_USER_ERROR";
	public static final String ERROR_RESPONSE_CODE = "ERROR_RESPONSE_CODE";
	public static final String MDM_CREATE_USER_URL = "MDM_CREATE_USER_URL";
	public static final String CREATE_USER_URL = "create.user.url";
	public static final String U = "U";	
	public static final String CREATE_DEVICE_USER_SUCESSFULL = "CREATE_DEVICE_USER_SUCESSFULL";
	public static final String ENROLL_DEVICE_ERROR = "ENROLL_DEVICE_ERROR";
	public static final String ENROLL_DEVICE_SUCESSFULL = "ENROLL_DEVICE_SUCESSFULL";
	public static final String ENROLL_DEVICE_URL = "enroll.device.url";
	public static final String ENROLLDEVICE_URL = "enrollDeviceUrl";
	public static final String RESPONSE_OK_CODE = "200";
	public static final String SEND_SMS_SUCESSFULL = "SEND_SMS_SUCESSFULL";
	public static final String SEND_SMS_ERROR = "SEND_SMS_ERROR";
	public static final String SEND_ENROLLMENT_SMS_FAILED = "SEND_ENROLLMENT_SMS_FAILED";
	public static final String UPDATE_SUBSCRIBER_PROFILE_SUCESSFULL = "UPDATE_SUBSCRIBER_PROFILE_SUCESSFULL";
	public static final String UPDATE_SUBSCRIBER_PROFILE_ERROR = "UPDATE_SUBSCRIBER_PROFILE_ERROR";
	public static final String ADD_TRACKING_SOC_FAILED = "ADD_TRACKING_SOC_FAILED";
	public static final String CREATE_DEVICE_ACTIVITY_LOG_FAILED = "Create User Failed";
	public static final String SOURCE_SAPMP = "SAPMP-GW";
	public static final String ENROLL_DEVICE_ACTIVITY_LOG_FAILED = "Enroll Device Failed";
	public static final String SEND_SMS_ACTIVITY_LOG_FAILED = "Send SMS Failed";
	public static final String ADD_TRACKINGSOC_ACTIVITY_LOG_FAILED = "Add Tracking SOC Failed";
	public static final String ENROLLMENT_ACTIVITY_LOG_SUCESSFULL = "Enrollment Device Done Successfully";
	public static final String[] ENROLL_ORCH_JSON_MANDATORY_FIELDS = { CommonDefs.DEVICE_JSON, CommonDefs.USER, CommonDefs.PROFILE_JSON};
	public static final String[] ENROLL_DEVICE_COMMON_MANDATORY_FIELDS = { "emmAccountId", "fan", "email" };
	public static final String PROCESS_ENROLLMENT = "processEnrollment";
	public static final String TIME_TO_LIVE="timeToLive";
	public static final String DEVICE_LOG_ACTIVITY_FLAG = "deviceLogActivityFlag";
	public static final String GMT = "GMT";
	
	// Device activity log Constants
	public enum CSI_ACTIVITY_LOG {
		activityCategory, activityType, activityDetails, source, activityDate
	};
}