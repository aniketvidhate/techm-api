package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EnrollDeviceTaskProcessor extends BaseProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(EnrollDeviceTaskProcessor.class);

	public final void execute(Exchange e) throws ApigwException {
		String requestBody = (String) (e.getIn().getBody());
		if (StringUtils.isEmpty(requestBody)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CErrorDefs.ERROR_CODE_1002_DESCRIPTION);
		}
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> enrollDeviceTaskMap = null;
		try {
			enrollDeviceTaskMap = objectMapper.readValue(requestBody, HashMap.class);
		} catch (IOException ex) {
			log.error("Exception occurred while parsing EnrollDeviceTask request: " + ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		e.setProperty(CommonDefs.IMEI, enrollDeviceTaskMap.get(CommonDefs.IMEI));
		e.setProperty(CommonDefs.DEVICE_ID, enrollDeviceTaskMap.get(CommonDefs.DEVICE_ID));
		e.setProperty(CommonDefs.TRACKING_ID, e.getIn().getHeader(CommonDefs.TRACKING_ID));
	}

	public final void handleAPNResponse(Exchange e) throws Exception {
		String responseBody = e.getIn().getBody(String.class);
		log.info("Response in EnrollDeviceTaskProcessor handleAPNResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + responseBody);
	}
}
