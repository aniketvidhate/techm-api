package com.att.sapmp.apigw.devices.exception;

import java.util.HashMap;
import java.util.Map;

public class CErrorDefs {

	public static final Map<String, Object> ERROR_MAP = new HashMap<String, Object>();

	static {
		ERROR_MAP.put("200", "Ok");
		ERROR_MAP.put("202", "Accepted");
		ERROR_MAP.put("204", "No Content");
		ERROR_MAP.put("500", "Internal Server Error");
		ERROR_MAP.put("400", "Bad Request");
		ERROR_MAP.put("401", "Unauthorized");
		ERROR_MAP.put("403", "Forbidden");
		ERROR_MAP.put("404", "Not Found");
	}

	public static final String ERROR_CODE = "errorCode";
	public static final String ERROR_MESSAGE = "errorMessage";
	public static final String DESCRIPTION = "description";

	public static final String ERROR_CODE_400 = "400";
	public static final String ERROR_CODE_403 = "403";
	public static final String ERROR_CODE_404 = "404";
	public static final String ERROR_CODE_500 = "500";

	public static final String ERROR_MSG_401 = "Unauthorized";
	public static final String ERROR_MSG_400 = "Bad Request";
	public static final String ERROR_MSG_403 = "Forbidden";
	public static final String ERROR_MSG_500 = "Internal Server Error";
	public static final String SYSTEM_ERROR = "System Error";

	public static final String ERROR_CODE_1001 = "E1001";
	public static final String ERROR_CODE_1001_DESCRIPTION = "Invalid request parameters.";
	public static final String ERROR_CODE_1002 = "E1002";
	public static final String ERROR_CODE_1002_DESCRIPTION = "Required fields missing in Input.";

	public static final String ERROR_CODE_4001 = "E4001";
	public static final String ERROR_CODE_4001_DESCRIPTION = "Unable to perform MDM Operation.";
	public static final String ERROR_CODE_4002 = "E4002";
	public static final String ERROR_CODE_4002_DESCRIPTION = "Unable to create EMM tenant account.";

	public static final String ERROR_CODE_5001 = "E5001";
	public static final String ERROR_CODE_5002 = "E5002";
	public static final String ERROR_CODE_5002_DESCRIPTION = "Unable to parse the response.";

	public static final String ERROR_MSG_INVALID_DATA = "Input request contains invalid data";
	public static final String ERROR_ENROLL_DEVICE = "Cannot enroll the device";
	
	public static final String ERROR_ENROLL_REQUEST_INVALID = "Enrollment Request is not valid";

}
