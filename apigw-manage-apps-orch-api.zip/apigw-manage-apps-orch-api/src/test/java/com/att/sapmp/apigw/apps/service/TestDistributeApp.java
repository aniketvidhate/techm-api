package com.att.sapmp.apigw.apps.service;

import org.junit.Test;

public class TestDistributeApp {
	@Test
	public void testGivenDistributeAppWhenRequiredFieldsAreMissingThenDistributeAppsFailsReturnInvalidRequestError() {
	}

	@Test
	public void testGivenDistributeAppWhenRequestContainsAppIdAppTypeAndDeviceIdThenSkipAppLookupAndDistributeApp() {
	}

	@Test
	public void testGivenDistributeAppWhenRequestNotContainsAppsThenLookupAppsDetailsAndDistributeApp() {
	}

	@Test
	public void testGivenDistributeAppWhenRequestContainsInvalidAppsThenDistributeAppFailsAndDeviceSubStatusIsDistributeAppFailed() {
	}

	@Test
	public void testGivenDistributeAppWhenRequestContainsValidAppsThenDistributeAppSucceedsAndDeviceSubStatusIsDistributeAppSuccess() {
	}

	@Test
	public void testGivenDistributeAppWhenInstallAppIsInvokedThenDeviceSubstatusAndActivityLogIsUpdated() {
	}

	@Test
	public void testGivenDistributeAppWhenMultipleAppsAreDistributedThenMultipleAppsAreDistributedToOneOrMultipleDevices() {
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenDistributeAppIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
	}

	@Test
	public void testGivenAuthTokenIsValidWhenDistributeAppIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() {
	}
}
