package com.att.sapmp.apigw.apps.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.apache.commons.lang3.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.apps.Application;
import com.att.sapmp.apigw.apps.service.TestConfiguration;




@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
public class InstallAppTest {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InstallAppTest.class);
	
	HttpHeaders headers = new HttpHeaders();
	
	static{
		SystemPropertiesLoader.addSystemProperties(); 
	}
	
	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	   @Autowired
	    private TestRestTemplate template;
	   
	@Before
	public void setUp() throws Exception {
		
		headers.set("Content-Type", "application/json");
		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
		headers.set("accountpassphrase", "57544555");
		headers.set("trackingid", "12345");
		headers.set("emmproductcode", "IBMMASS");				
	}

	@After
	public void tearDown() throws Exception {
		
		
	}

		
	
	
	@Test
	public void testCompainceInput() throws Exception {
		
		String requestJson = "{\r\n\r\n\"emmAccountId\": \"30061269\",\r\n\"deviceId\":\"Q77000000000000224\"\r\n\r\n}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/apps/distributeapps", HttpMethod.POST, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		
		if(!StringUtils.isEmpty(responseBody) && responseBody.contains("Failure") ) {
			fail("Failure occurred due to incorrect input parameters");
			
		}		
			
		}		
	
	
		
	@Test
public void InstallAppInput() throws Exception {
		
		String requestJson = "{\r\n\r\n\"emmAccountId\": \"30061269\",\r\n\r\n\r\n\"applications\": {\r\n\"application\": [\r\n{\r\n\"appId\": \"com.att.tv\",\r\n\"appType\": \"3\",\r\n\"deviceId\":\"Android9cc05b11e0d6e7f4\"\r\n}\r\n\r\n]\r\n\r\n\r\n\r\n}\r\n}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/apps/distributeapps", HttpMethod.POST, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
	    assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		
		if(!StringUtils.isEmpty(responseBody) && responseBody.contains("Failure") ) {
			fail("Failure occurred due to incorrect input parameters");
			
		}		
		
	}
	
	
	
	}
		