package com.att.sapmp.apigw.apps.service;

import org.junit.Test;

public class TestDeleteApp {

	@Test
	public void testGivenDeleteAppWhenAppIdAppTypeAreValidThenDeleteAppSucceeds() {
	}

	@Test
	public void testGivenDeleteAppWhenAppIdAppTypeAreInValidThenDeleteAppFails() {
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenDeleteAppIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
	}

	@Test
	public void testGivenAuthTokenIsValidWhenDeleteAppIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() {
	}

}
