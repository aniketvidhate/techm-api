package com.att.sapmp.apigw.apps.service;

import java.util.ArrayList;
import java.util.HashMap;
import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.apps.exception.ApigwException;
import com.att.sapmp.apigw.apps.exception.CErrorDefs;
import com.att.sapmp.apigw.apps.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class InstallAppRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InstallAppRequestProcessor.class);

	public final void execute(Exchange e) throws ApigwException {

		String trackingid = (String) (e.getIn().getHeader(CommonDefs.TRACKING_ID));
		String EMMProductCode = (String) (e.getIn().getHeader(CommonDefs.EMM_PRODUCT_CODE));
		String stBillingId = null;
		String stDeviceId = null;
		String stEmmDeviceId = null;

		String body = (String) (e.getIn().getBody());
		if (StringUtils.isEmpty(body)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}

		ObjectMapper objectMapper = new ObjectMapper();

		HashMap<String, Object> hmAppRequest;
		try {
			hmAppRequest = objectMapper.readValue(body, HashMap.class);
		} catch (Exception ex) {
			log.debug("Exception occurred while parsing post request: " + ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		
		
		ArrayList<HashMap<String, Object>> alApplication = null;
		if (hmAppRequest != null && !hmAppRequest.isEmpty()) {
			stBillingId = (String) hmAppRequest.get(CommonDefs.EMM_ACCOUNT_ID);
			stDeviceId = (String) hmAppRequest.get(CommonDefs.DEVICE_ID);
			HashMap<String, Object> hmApplications = (HashMap) hmAppRequest.get(CommonDefs.APLICATIONS);
			if (hmApplications != null && !hmApplications.isEmpty()) {
				alApplication = (ArrayList) hmApplications.get(CommonDefs.APLICATION);
				if (alApplication != null && !alApplication.isEmpty()) {
					e.getIn().setHeader("callInquireDevice", "N");
					for (HashMap<String, Object> hmApp : alApplication) {
						
						stEmmDeviceId = (String) hmApp.get(CommonDefs.DEVICE_ID);
				
						
											
						}
					
					
				}
			}

		}

		if (alApplication == null || alApplication.isEmpty()) {
			
			JSONObject jsonbody = new JSONObject();
			jsonbody.put(CommonDefs.DEVICE_ID, stDeviceId);
			e.getIn().setBody(jsonbody);
		}
		e.getIn().setHeader(CommonDefs.BILLING_ID, stBillingId);
		e.getIn().setHeader(CommonDefs.EMM_PRODUCT_CODE, EMMProductCode);
		e.getIn().setHeader(CommonDefs.TRACKING_ID, trackingid);
		e.setProperty(CommonDefs.DEVICE_ID, stDeviceId);
		e.setProperty(CommonDefs.EMM_DEVICE_ID, stEmmDeviceId);
	}
}
