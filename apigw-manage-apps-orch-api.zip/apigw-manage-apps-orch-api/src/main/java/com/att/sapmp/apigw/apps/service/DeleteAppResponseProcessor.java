package com.att.sapmp.apigw.apps.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.json.JSONObject;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.apps.util.CommonDefs;



public class DeleteAppResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeleteAppResponseProcessor.class);

	public final void handleResponse(Exchange e) throws Exception {


		
		String respBody = (String) e.getIn().getBody();;
		
		log.info("Received response in handleResponse method :: "+ respBody);
		
		
		
	}
}
