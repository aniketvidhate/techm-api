package com.att.sapmp.apigw.apps.service.rs;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.apps.model.App;

import io.swagger.annotations.ApiParam;



@AjscService
public class MdmInstallAppsRestServiceImpl implements MdmInstallAppsRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(MdmInstallAppsRestServiceImpl.class);
	
	
	public MdmInstallAppsRestServiceImpl() {
		// needed for autowiring
	}


	@Override
	public void installApp(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@ApiParam(value = " Request Object", required = true)@RequestBody App app) {
		log.info("Received request in distributeRestServiceImpl API");
		
	}
	
	
		
		
		
	}
	

		
	


