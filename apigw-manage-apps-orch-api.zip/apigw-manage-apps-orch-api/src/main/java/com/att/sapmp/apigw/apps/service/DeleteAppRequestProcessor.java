
package com.att.sapmp.apigw.apps.service;
import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.apps.exception.ApigwException;



@Component
public class DeleteAppRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeleteAppRequestProcessor.class);

	

	public final void execute(Exchange e) throws ApigwException {
	log.info("Invoking execute method");
	
	
		}

	
	
	
}