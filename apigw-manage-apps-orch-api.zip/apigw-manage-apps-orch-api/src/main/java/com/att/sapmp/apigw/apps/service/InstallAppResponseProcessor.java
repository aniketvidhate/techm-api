package com.att.sapmp.apigw.apps.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXB;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.apps.exception.ApigwException;
import com.att.sapmp.apigw.apps.exception.CErrorDefs;

import com.att.sapmp.apigw.apps.util.CommonDefs;
import com.att.sapmp.apigw.apps.util.CommonUtil;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;


//import org.codehaus.jackson.map.ObjectMapper;
//import com.fasterxml.jackson.xml.XmlMapper;

import javax.xml.bind.*;
import javax.xml.parsers.*;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


@Component
public class InstallAppResponseProcessor {

    private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InstallAppResponseProcessor.class);


    public final void handleDistributeAppResponse(Exchange e) throws Exception {

        String respBody = e.getIn().getBody(String.class);
        log.info("Received response in handledistributeResponse method:: " + respBody);
        String emmDeviceId = (String) e.getProperty(CommonDefs.EMM_DEVICE_ID);
        String DeviceId = (String) e.getProperty(CommonDefs.DEVICE_ID);
        String imei = (String) e.getProperty(CommonDefs.IMEI);
        log.info("imei", imei);
        JSONObject body = new JSONObject();

        body.put(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
        body.put(CommonDefs.DEVICE_ID, DeviceId);
        body.put(CommonDefs.IMEI, imei);
        body.put(CommonDefs.ENROLLMENT_SUB_STATUS,CommonDefs.DISTRIBUTE_APP_SUCCESS);

        // Inserting the Device Logs
        body.put(CommonDefs.ACTIVITY_TYPE, CommonDefs.INSTALL_APP_SUCCESS);
        body.put(CommonDefs.ACTIVITY_CATEGORY, CommonDefs.INSTALL_APP);
        body.put(CommonDefs.ACTIVITY_DETAILS, CommonDefs.INSTALL_SUCCESS_DEATILS);
        body.put(CommonDefs.SOURCE, CommonDefs.SOURCE_INSTALL);
       
        body.put(CommonDefs.ACTIVITY_DATE, CommonUtil.getGMTdatetimeAsString());

        e.getIn().setBody(body);

    }

    public final void handleProfileResponse(Exchange e) throws Exception {
       
        String body = (String) e.getIn().getBody();

        log.info("Start handleCsiInquireDeviceDetailResponse body => " + body);

                
        Document doc =null;
		DocumentBuilder builder=null;
		try {
			builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		} catch (ParserConfigurationException pcex) {
			log.info("Exception  while parsing ::" + pcex.getMessage() + " and  :: " + pcex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5002, CErrorDefs.ERROR_CODE_5002_DESCRIPTION);
		}
		InputSource src = new InputSource();
		src.setCharacterStream(new StringReader(body));
		try {
			doc = builder.parse(src);
		} catch (SAXException sax) {
			log.info("Exception occurred while parsing ::" + sax.getMessage() + " and :: " + sax);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5002, CErrorDefs.ERROR_CODE_5002_DESCRIPTION);
		} catch (IOException ioex) {
			log.info("Exception occurred while parsing ::" + ioex.getMessage() + " and  :: " + ioex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5002, CErrorDefs.ERROR_CODE_5002_DESCRIPTION);
		}
		
		ArrayList < HashMap > alApplicationlist = new ArrayList < > ();
		
		String imeiValue = doc.getElementsByTagName(CommonDefs.IMEI).item(0).getTextContent();
		log.info("imeiValue: "+ imeiValue);
		e.setProperty(CommonDefs.IMEI, imeiValue);
		
		if(body.contains(CommonDefs.PROFILE_LIST)){
			
			for( int i =0; i< (doc.getElementsByTagName(CommonDefs.PROFILE_LIST)).getLength(); i++){
				
				HashMap ProfileApplicationListHashMap = new HashMap();
				for( int j =0; j< (doc.getElementsByTagName(CommonDefs.PROFILE_LIST).item(i).getChildNodes()).getLength(); j++){
					
					String elementName = (doc.getElementsByTagName(CommonDefs.PROFILE_LIST).item(i).getChildNodes().item(j)).getNodeName();
					String elementValue = doc.getElementsByTagName(CommonDefs.PROFILE_LIST).item(i).getChildNodes().item(j).getTextContent();
					log.info("elementName: "+ elementName + " elementValue: "+elementValue );
					ProfileApplicationListHashMap.put(elementName, elementValue);
				}
				alApplicationlist.add(ProfileApplicationListHashMap);
				}	
			
					
		log.info("Printing application list: : "+alApplicationlist);
        
		HashMap<String, Object> hmAppResponse = new HashMap<>();
		ArrayList<HashMap<String, Object>> alApp = new ArrayList<>();
		HashMap<String, Object> hmSingleApp = null;
		Map < String, Object > hmResponseParam = InitializationService.getResponseparammap();
			for (HashMap<String, Object> hmApp : alApplicationlist) {
				Iterator<String> itResponse = hmResponseParam.keySet().iterator();
				hmSingleApp = new HashMap<>();
				while (itResponse.hasNext()) {
					String stKey =  itResponse.next();
					if (hmApp.containsKey(stKey)) {
						hmSingleApp.put((String) hmResponseParam.get(stKey), hmApp.get(stKey));
					}
				}

				alApp.add(hmSingleApp);

			}

			hmAppResponse.put(CommonDefs.APLICATION, alApp);
		
		
        JSONObject jsonbody = new JSONObject();
        String emmAccountId = (String) e.getIn().getHeader(CommonDefs.BILLING_ID);
        jsonbody.put(CommonDefs.EMM_ACCOUNT_ID, emmAccountId);
        jsonbody.put(CommonDefs.APLICATIONS, hmAppResponse);
        log.info("Printing json body: "+jsonbody);
        e.getIn().setBody(jsonbody.toString());
		
		}
    }

    public final void handleCdfUpdateFailedResponse(Exchange e) throws Exception {

        
        log.info("Received response in handleCdfUpdateFailedResponse method:: " );
        String imei = (String) e.getProperty(CommonDefs.IMEI);

        String emmDeviceId = (String) e.getProperty(CommonDefs.EMM_DEVICE_ID);
        String DeviceId = (String) e.getProperty(CommonDefs.DEVICE_ID);

        JSONObject body = new JSONObject();

        

        body.put(CommonDefs.IMEI, imei);
        body.put(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
        body.put(CommonDefs.DEVICE_ID, DeviceId);
        body.put(CommonDefs.ENROLLMENT_SUB_STATUS,CommonDefs.DISTRIBUTE_APP_FAILED);
       
        // Inserting the Device Logs
        body.put(CommonDefs.ACTIVITY_TYPE, CommonDefs.INSTALL_APP_FAILED);
        body.put(CommonDefs.ACTIVITY_CATEGORY, CommonDefs.INSTALL_APP);
        body.put(CommonDefs.ACTIVITY_DETAILS, CommonDefs.INSTALL_FAILED_DEATILS);
        body.put(CommonDefs.SOURCE, CommonDefs.SOURCE_INSTALL);
        body.put(CommonDefs.ACTIVITY_DATE, CommonUtil.getGMTdatetimeAsString());



        e.getIn().setBody(body);

    }

}