package com.att.sapmp.apigw.apps.service;

import java.util.HashMap;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import io.swagger.annotations.ApiModel;



@Component
public class InitializationService {

	@Value("${IBM_RequestTransformParam}")
	private String requestTrasformParam;
	
	@Value("${IBM_ResponseTransformParam}")
	private String responseTrasformParam;

	
	
	private String billingId;

	private static final HashMap<String, Object> requestParamMap = new HashMap<>();
	private static final HashMap<String, Object> resposeParamMap = new HashMap<>();

	/**
	 * 
	 * This method read the properties from application.properties and parse it.
	 */

	
		private void init() {

			if (requestTrasformParam != null && !requestTrasformParam.isEmpty()) {

				String[] responsePairs = requestTrasformParam.split(",");
				for (String pair : responsePairs) {
					String[] kv = pair.split("=");
					requestParamMap.put(kv[0], kv[1]);
				}

				String[] requestPairs = responseTrasformParam.split(",");
				for (String pair : requestPairs) {
					String[] kv = pair.split("=");
					resposeParamMap.put(kv[0], kv[1]);
				}
			}
		}
	
		public static HashMap<String, Object> getResponseparammap() {
			return resposeParamMap;
		}
	public static HashMap<String, Object> getRequestparammap() {
		return requestParamMap;
	}
	
	public String getBillingId() {
		return billingId;
	}

	public void setBillingId(String billingId) {
		this.billingId = billingId;
	}

}