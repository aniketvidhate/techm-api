package com.att.sapmp.apigw.apps.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.apps.exception.ApigwException;
import com.att.sapmp.apigw.apps.exception.CErrorDefs;
import com.att.sapmp.apigw.apps.util.CommonDefs;
import com.att.sapmp.apigw.apps.util.CommonUtil;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;


@Component
public class CsiInquireDeviceDetailsProcessor {

	private Logger log = LoggerFactory.getLogger(CsiInquireDeviceDetailsProcessor.class);
	
	
	@Value("${csi.user}")
	private String userName;
	
	@Value("${csi.password}")
	private String userPassword;
	
	@Value("${csi.version}")
	private String version;
	
	@Value("${csi.messageId}")
	private String messageId;
	
	@Value("${csi.sequenceNumber}")
	private String sequenceNumber;
	
	@Value("${csi.totalInSequence}")
	private String totalInSequence;
	

	public final void execute(Exchange e) throws ApigwException {

		log.info("Start execute CsiInquireDeviceDetailsProcessor");
		e.getIn().setHeaders(e.getIn().getHeaders());
		
		
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		ObjectMapper objectMapper = new ObjectMapper();

		HashMap<String, Object> hmCsiInquireDeviceDetails = null;
		try {
			hmCsiInquireDeviceDetails = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
		} catch (IOException e1) {
			log.info("Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);

		}  
		e.setProperty(CommonDefs.ACTION_TYPE, e.getProperty(CommonDefs.ACTION_TYPE));
		hmCsiInquireDeviceDetails.put(CommonDefs.VERSION_NO, version);
		hmCsiInquireDeviceDetails.put(CommonDefs.MESSAGE_ID, messageId);
		hmCsiInquireDeviceDetails.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
		hmCsiInquireDeviceDetails.put(CommonDefs.USER_NAME, userName);
		hmCsiInquireDeviceDetails.put(CommonDefs.USER_PASSWORD, userPassword);
		hmCsiInquireDeviceDetails.put(CommonDefs.TOTAL_IN_SEQUENCE, totalInSequence);
		hmCsiInquireDeviceDetails.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
		
		VelocityContext velocityContext = new VelocityContext(hmCsiInquireDeviceDetails);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		log.info("End execute CsiInquireDeviceDetailsProcessor");
		
	}

	public final void handleCsiInquireDeviceDetailResponse(Exchange e) throws ApigwException {
		
		
		String csiResposeBody = (String) e.getIn().getBody();
		log.info("Response From handleCsiInquireDeviceDetailResponse body:: \n"+csiResposeBody);
				
		
		log.info("End of handleCsiInquireDeviceDetailResponse");

	}

}