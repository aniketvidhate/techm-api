package com.att.sapmp.apigw.compliance.service;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.nsa.mr.client.MRBatchingPublisher;
import com.att.nsa.mr.client.MRClientFactory;
import com.att.nsa.mr.client.MRPublisher.message;
import com.att.sapmp.apigw.compliance.exception.CErrorDefs;
import com.att.sapmp.apigw.compliance.util.CommonDefs;

@Component
public class NotificationProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(NotificationProcessor.class);

	@Value("${dme2.compliance.producerPropertiesPath}")
	private String complianceProducerPropertiesPath;		
	
	@Value("${dme2.apn.producerPropertiesPath}")
	private String apnProducerPropertiesPath;		
	
	public final void publishCompliance(Exchange e) throws Exception {
		publish(e, complianceProducerPropertiesPath);
		
	}
	public final void publishApn(Exchange e) throws Exception {
		publish(e, apnProducerPropertiesPath);
	}
	
	public final void publish(Exchange e, String propertiesPath) throws Exception {
		String notification = e.getIn().getBody(String.class);		
		JSONObject notificationJson = new JSONObject(notification);
		final MRBatchingPublisher apnNotificationPublisher = MRClientFactory.createBatchingPublisher (propertiesPath);	
		apnNotificationPublisher.send (notificationJson.toString());
		log.info("message to be posted to dmaap topic :\n" + notificationJson.toString());
		// ...
		// close the publisher to make sure everything's sent before exiting. The batching
		// publisher interface allows the app to get the set of unsent messages. It could
		// write them to disk, for example, to try to send them later.
		final List<message> stuckMessage = apnNotificationPublisher.close(20,TimeUnit.SECONDS );
		if (stuckMessage.size() > 0)
		{
			log.error( stuckMessage.size() + " messages unsent" );
			e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_500);

		}
		else
		{
			log.info ( "Clean exit; all messages sent." );
			e.getIn().setBody("{\"message\":\"Clean exit; all messages sent.\"");
			e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
		}			
	}
}
