package com.att.sapmp.apigw.compliance.service;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONObject;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;

import com.att.sapmp.apigw.compliance.util.CommonDefs;
import com.att.sapmp.apigw.compliance.util.CommonUtil;

public class TestDeviceComplianceEvents extends TestBase{
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.emmDeviceId}")
	private String emmDeviceId;	
	
	@Value("${test.imeiEsn}")
	private String imeiEsn;		
	
	@Value("${test.compliance.url}")
	protected String basePath;	
			
	protected void replaceTokensInRequest() throws Exception {
		
		JSONObject jsonObject = new JSONObject(requestJson);
		String jsonString = jsonObject.toString();
		requestJson = jsonString;
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{emmDeviceId\\}", emmDeviceId);
        requestJson = requestJson.replaceAll("\\$\\{imeiEsn\\}", imeiEsn);
	}
	
	protected String getBasePath() {
		return basePath;
	}	

	@Test
	public void testGivenDeviceComplianceEventsWhenEventTypeIsEmptyOrNotEqualToDeviceStateComplianceEventThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.EVENT_TYPE + " needs to be populated in the input."));		
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenTransactionIdIsMissingThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.MDM_NOTIFICATION_TRANSACTION_ID + " needs to be populated in the input."));		

	}

	@Test
	public void testGivenDeviceComplianceEventsWhenTimeStampIsMissingThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.TIMESTAMP + " needs to be populated in the input."));		
		
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenOrgIdIsEmptyOrOrgIdNotMatchesWithMdmProviderNameThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.ORGID + " needs to be populated in the input."));				
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenMdmProviderNameIsEmptyOrInvalidThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.MDM_PROVIDER_NAME + " needs to be populated in the input."));						
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceEventListIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.DEVICE_EVENT_LIST + " needs to be populated in the input."));								
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceEventListEmmAccountIDIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.EMM_ACCOUNT_ID + " needs to be populated in the input."));										
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceEventListEventSubTypeIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.EVENT_SUB_TYPE + " needs to be populated in the input."));												
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceEventListEmmDeviceIdIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.EMM_DEVICE_ID + " needs to be populated in the input."));												

	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceEventListImeiEsnNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.IMEI_ESN + " needs to be populated in the input."));												
				
	}

	//@Test
	//Invalid testcase as for syncCompliance deviceStatus is not checked.
	public void testGivenDeviceComplianceEventsWhenDeviceEventListDeviceStatusIsNullOrEmptyThenLogCriticalErrors() {
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceEventListPolicyComplianceIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.POLICY_COMPLAINCE_STATUS + " needs to be populated in the input."));												
		
	}
	
	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceEventListOocReasonIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.OOC_REASON + " needs to be populated in the input."));														
	}	
	
	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceEventListContainsMultipleEventsThenExecuteValidationForAllEventsAndLogCriticalErrorsIfAny() {
		executePost();
		assertThat(responseBody, allOf(containsString(CommonDefs.OOC_REASON + " needs to be populated in the input."), containsString(CommonDefs.POLICY_COMPLAINCE_STATUS + " needs to be populated in the input.")));	
	}	

	@Test
	public void testGivenEventTypeIsSyncComplianceWhenPolicyComplianceStatusIs_OUT_OF_COMPLIANCE_ThenDeviceComplianceStatusInCdfIsOUT_OF_COMPLIANCE() {
		executePost(csiCreateDeviceBasePath);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<complianceStatus>OUT_OF_COMPLIANCE</complianceStatus>"));
		executePost(csiDeleteDeviceBasePath);
	}

	@Test
	public void testGivenEventTypeIsSyncComplianceWhenPolicyComplianceStatusIs_IN_COMPLIANCE_ThenDeviceComplianceStatusInCdfIsIN_COMPLIANCE() {
		executePost(csiCreateDeviceBasePath);
		executePost();
		String inquireResponse = executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		executePost(csiDeleteDeviceBasePath);		
		assertThat(inquireResponse, containsString("<complianceStatus>IN_COMPLIANCE</complianceStatus>"));		
	}

	@Test
	public void testGivenEventTypeIsSyncComplianceWhenOocReasonIsNotNullThenComplianceReasonInCdfIsEqualToOocReason() {
		executePost(csiCreateDeviceBasePath);

		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<complianceStatusReason>Rooted Android Device</complianceStatusReason>"));		
		executePost(csiDeleteDeviceBasePath);		
		
	}	
	
	@Test
	public void testWhenSyncComplianceIsReceivedThenInsertDeviceActivityLog() {
		executePost(csiCreateDeviceBasePath);
		
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<activityType>NON_COMPLIANCE</activityType>"));		
		executePost(csiDeleteDeviceBasePath);		
		
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogContainsActivityCategoryAs_COMPLIANCE_SYNCOMPLIANCE() {
		executePost(csiCreateDeviceBasePath);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<activityCategory>COMPLIANCE_SYNCOMPLIANCE</activityCategory>"));			
		executePost(csiDeleteDeviceBasePath);		

	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogContainsActivityTypeAsCompliant() {
		executePost(csiCreateDeviceBasePath);		
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<activityType>COMPLIANCE</activityType>"));	
		executePost(csiDeleteDeviceBasePath);		
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogContainsSourceAs_SAPMPGW() {
		executePost(csiCreateDeviceBasePath);				
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<source>SAPMP-GW</source>"));
		executePost(csiDeleteDeviceBasePath);		
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogContainsActivityDateAs_SysDate() {
		executePost(csiCreateDeviceBasePath);						
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		String timeStamp = CommonUtil.getGMTdatetimeAsString();		
		assertThat(responseBody, containsString("<activityDate>" + timeStamp.substring(0, 13)));	
		executePost(csiDeleteDeviceBasePath);		
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceActivityDetailsContains_DeviceId_PolicyComplianceStatus_OOCReason() {
		executePost(csiCreateDeviceBasePath);								
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("policyComplianceStatus=OUT_OF_COMPLIANCE"), containsString("oocReason=Rooted Android Device")));	
		executePost(csiDeleteDeviceBasePath);
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenPolicyComplianceStatusIsOutOfComplianceThenInvokeApplyApnWithRequiredFields() {
		executePost(csiCreateDeviceBasePath);										
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<activityType>APPLY_APN</activityType>"));
		executePost(csiDeleteDeviceBasePath);		
	}

	@Test
	public void testGivenDeviceComplianceEventsWhenPolicyComplianceStatusIsInComplianceThenInvokeRemoveApnWithRequiredFields() {
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_YES);
		executePost(csiCreateDeviceBasePath);				
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);	
		executePost();
		String inquireResponse = executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		executePost(csiDeleteDeviceBasePath);		
		assertThat(inquireResponse, containsString("<activityType>REMOVE_APN</activityType>"));
	}
	
	//@Test 
	//invalid testcase, the Dmaap topic would be using AAF username and password instead of authToken for DME2
	public void testGivenAuthTokenAndConnectivityIsInvalidWhenConsumingMessageFromDMaaPTopicThenAuthenticationErrorIsReceived() {
	}
	
	//@Test
	//invalid testcase, the Dmaap topic would be using AAF username and password instead of authToken for DME2
	public void testGivenAuthTokenAndConnectivityDetailsIsValidWhenConsummingMessageFromDMaaPTopicThenMessageIsConsumedSuccessfully() {
	}	
	
	//@Test
	//Needs to be manually tested as it is not feasible to wait for the configured interval in the testcase 
	public void testGivenConfgiuredIntervalBetweenMessagePollingWhenConsummingMessageFromDMaaPTopicThenMessagesConsumptionIntervalIsAsConfigured() {
	}
	
	//@Test
	//Invalid testcase as it is not possible to turnoff the message polling
	public void testGivenDeviceComplianceEventWhenMessagePollingIsTurnedOffThenNoDeviceActionOrComplianceMessagesIsConsumed() {
	}	
	
	//@Test
	//Needs to be manually tested as it is not possible to configure multiple consumes in the testcase
	public void testGivenDeviceComplianceEventWhenMultipleConsumesAreRunningThenAnyMessageIsConsumedOnlyOnce() {
		
	}
	
}
