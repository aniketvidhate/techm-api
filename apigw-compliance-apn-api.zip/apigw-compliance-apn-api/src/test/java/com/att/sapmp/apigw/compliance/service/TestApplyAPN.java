package com.att.sapmp.apigw.compliance.service;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.CoreMatchers.allOf;

import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.sapmp.apigw.compliance.exception.CErrorDefs;
import com.att.sapmp.apigw.compliance.util.CommonDefs;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
public class TestApplyAPN extends TestBase {

	@Value("${test.manage.apn.basepath}")
	protected String basePath;
	
	@Value("${test.emmDeviceId}")
	private String emmDeviceId;	
	
	@Value("${test.csi.create.device.imei}")
	private String imei;	
	
	@Value("${test.apn.publish.url}")
	protected String apnPublishUrl;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmDeviceId\\}", emmDeviceId);
		requestJson = requestJson.replaceAll("\\$\\{imei\\}", imei);
	}

	@Override
	protected String getBasePath() {
		return basePath;
	}	
	
	@Override
	public void setUp() throws Exception {
		super.setUp();
		headers.set("Content-Type", "application/json");
		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
		headers.set("trackingid",String.valueOf(new Date().getTime()));		
	}

	@Test
	public void testGivenApplyApnWhenActionTypeIsMissingInRequestThenReturnInvalidRequestError() {
		
		executePost();
		assertThat(responseBody, allOf(containsString(CErrorDefs.ERROR_CODE_1002),containsString(CommonDefs.ACTION_TYPE + " is a required parameter in the input")));				
	}
	
	@Test
	public void testGivenApplyApnWhenActionTypeIsNotEqualToApplyThenReturnInvalidRequestError() {
		executePost();
		assertThat(responseBody, allOf(containsString(CErrorDefs.ERROR_CODE_1001),containsString(CommonDefs.ACTION_TYPE + " needs to be populated with correct value.")));				

	}
	
	@Test
	public void testGivenApplyApnWhenCtnIsMissingInRequestThenReturnInvalidRequestError() {
		headers.add(CommonDefs.CTN, "");
		headers.add(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
		executePost(csiCreateDeviceBasePath);
		headers.remove(CommonDefs.CTN);
		executePost();
		String applyAPNResponse = responseBody;
		executePost(csiDeleteDeviceBasePath);
		assertThat(applyAPNResponse, allOf(containsString(CErrorDefs.ERROR_CODE_1002),containsString(CErrorDefs.ERROR_CODE_1002_DESCRIPTION)));				
	}
	
	@Test
	public void testGivenApplyApnWhenDeviceIdAndEmmDeviceIdIsMissingInRequestThenReturnInvalidRequestError() {
		executePost();
		assertThat(responseBody, allOf(containsString(CErrorDefs.ERROR_CODE_1002),containsString(CErrorDefs.ERROR_CODE_1002_DESCRIPTION)));				
	}
	
	@Test
	public void testGivenApplyApnWhenActionTypeIsApplyAndDeviceApnStatusIsYesThenStopTheProcess() {
		
		//We need to create the device record with apnStatus as Yes
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_YES);
		executePost(csiCreateDeviceBasePath);
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);					
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"imei\":\""+imei+"\"}");
		assertThat(responseBody, containsString("<apnStatus>Yes</apnStatus>"));
		executePost(csiDeleteDeviceBasePath);			
	}
	
	@Test
	public void testGivenApplyApnWhenActionTypeIsApplyAndDeviceApnStatusIsNoAndDeviceIsNotEligibleForApplyApnThenStopTheProcess() {
		//We need to create the device record with apnStatus as No
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_NO);
		headers.add(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
		headers.add("createDeviceNetworkControl","false");
		executePost(csiCreateDeviceBasePath);
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);
		headers.add("createDeviceNetworkControl",null);
		headers.add(CommonDefs.EMM_DEVICE_ID, null);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"imei\":\""+imei+"\"}");
		assertThat(responseBody, containsString("<apnStatus>No</apnStatus>"));
		executePost(csiDeleteDeviceBasePath);		
		
	}
	
	//@Test
	//Manual
	//Since the publish apn will not fail in normal circumstances, update the application-test.properties dme2.apn.publish.timeout to 0 milliseconds so that the message is unsent
	//Note: remember to undo the changes to application-test.properties dme2.apn.publish.timeout after successfully executing this testcase manually.
	public void testGivenApplyApnWhenDeviceIsApnEligibleAndApplyApnIsFailureThenInsertActivityLog() throws Exception {
		//We need to create the device record with apnStatus as No
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_NO);
		executePost(csiCreateDeviceBasePath);
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);	
		requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", generatedCDFDeviceId);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<activityType>APPLY_APN_FAILURE</activityType>")));
		executePost(csiDeleteDeviceBasePath);
	}
	
	@Test
	public void testGivenApplyApnWhenDeviceIsApnEligibleAndApplyApnIsSuccessThenUpdateApnStatusAsYesAndInsertActivityLog() throws Exception {
		//We need to create the device record with apnStatus as No
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_NO);
		executePost(csiCreateDeviceBasePath);
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);	
		requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", generatedCDFDeviceId);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<apnStatus>Yes</apnStatus>"),containsString("<activityType>APPLY_APN</activityType>")));
		executePost(csiDeleteDeviceBasePath);		
	}	
	
	//@Test
	public void testGivenAuthTokenIsInvalidWhenApplyApnIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
		headers.set("authorization", "Basic 123");
		executePost();		
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenApplyApnIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception{
		//We need to create the device record with apnStatus as No
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_NO);
		executePost(csiCreateDeviceBasePath);
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);	
		requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", generatedCDFDeviceId);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<apnStatus>Yes</apnStatus>"),containsString("<activityType>APPLY_APN</activityType>")));
		executePost(csiDeleteDeviceBasePath);	
	}
	
	@Test
	public void testSimulateApnEvent() {
		executePost(apnPublishUrl);			
	}	

	//TODO Write test cases for the values getting inserted into the device activity log
}
