package com.att.sapmp.apigw.compliance.service;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.JSONObject;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;

import com.att.sapmp.apigw.compliance.util.CommonDefs;
import com.att.sapmp.apigw.compliance.util.CommonUtil;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

public class TestDeviceActionEvents extends TestBase {
	
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.emmDeviceId}")
	private String emmDeviceId;	
	
	@Value("${test.imeiEsn}")
	private String imeiEsn;		
	
	@Value("${test.compliance.publish.url}")
	protected String compliancePublishUrl;
	
	@Value("${test.compliance.url}")
	protected String basePath;
	
				
	protected void replaceTokensInRequest() throws Exception {
		
		JSONObject jsonObject = new JSONObject(requestJson);
		String jsonString = jsonObject.toString();
		requestJson = jsonString;
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{emmDeviceId\\}", emmDeviceId);
        requestJson = requestJson.replaceAll("\\$\\{imeiEsn\\}", imeiEsn);
	}
	
	protected String getBasePath() {
		return basePath;
	}		

	@Test
	public void testGivenDeviceActionEventsWhenEventTypeIsEmptyOrNotEqualToDeviceStateChangeEventThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.EVENT_TYPE + " needs to be populated in the input."));				
	}

	@Test
	public void testGivenDeviceActionEventsWhenTransactionIdIsMissingThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.MDM_NOTIFICATION_TRANSACTION_ID + " needs to be populated in the input."));				
	}

	@Test
	public void testGivenDeviceActionEventsWhenTimeStampIsMissingThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.TIMESTAMP + " needs to be populated in the input."));				
	}

	@Test
	public void testGivenDeviceActionEventsWhenOrgIdIsEmptyOrOrgIdNotMatchesWithMdmProviderNameThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.ORGID + " needs to be populated in the input."));				
	}

	@Test
	public void testGivenDeviceActionEventsWhenMdmProviderNameIsEmptyOrInvalidThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.MDM_PROVIDER_NAME + " needs to be populated in the input."));				
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceEventListIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.DEVICE_EVENT_LIST + " needs to be populated in the input."));			
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceEventListEmmAccountIDIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.EMM_ACCOUNT_ID + " needs to be populated in the input."));			
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceEventListEventSubTypeIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.EVENT_SUB_TYPE + " needs to be populated in the input."));		
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceEventListEmmDeviceIdIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.EMM_DEVICE_ID + " needs to be populated in the input."));		
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceEventListImeiEsnNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.IMEI_ESN + " needs to be populated in the input."));				
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceEventListDeviceStatusIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.MDM_DEVICE_STATUS + " needs to be populated in the input."));				
	}

	@Test
	//Manual testcase,
	public void testGivenDeviceActionEventsWhenDeviceEventListDeviceStatusIsNeitherActiveNotInActiveThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.MDM_DEVICE_STATUS + " needs to be populated with correct value."));				
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceEventListDeviceSubStatusIsNullOrEmptyThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.MDM_DEVICE_SUB_STATUS + " needs to be populated in the input."));				
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceEventListDeviceSubStatusValueIsInvalidThenLogCriticalErrors() {
		executePost();
		assertThat(responseBody, containsString(CommonDefs.MDM_DEVICE_SUB_STATUS + " needs to be populated with correct value."));				
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceEventListContainsMultipleEventsThenExecuteValidationForAllEventsAndLogCriticalErrorsIfAny() {	
		executePost();
		assertThat(responseBody, allOf(containsString(CommonDefs.MDM_DEVICE_SUB_STATUS + " needs to be populated in the input."),containsString(CommonDefs.MDM_DEVICE_STATUS + " needs to be populated in the input.")));

	}
	
	@Test
	public void testWhenEventTypeIsSyncDeviceAndDeviceStatusIsActiveAndMdmManagedStatusIsEnrolledThenUpdateStatusAs_ENROLLMENT_SUCCESS_ACTIVE_DEVICE() {
		executePost(csiCreateDeviceBasePath);		
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<enrollmentStatus>ENROLLMENT_SUCCESS</enrollmentStatus>"));
		//The below assert cannot be tested as it will be immediately overwritten by InstallApp status
		//assertThat(responseBody, allOf(containsString("<enrollmentSubStatus>ACTIVE_DEVICE</enrollmentSubStatus>")));
		executePost(csiDeleteDeviceBasePath);

	}

	@Test
	public void testWhenEventTypeIsSyncDeviceAndDeviceStatusIsInActiveAndMdmManagedStatusIsInActiveThenUpdateStatusAs_DEENROLLMENT_SUCCESS_INACTIVE_DEVICE() {
		executePost(csiCreateDeviceBasePath);		
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentStatus>DEENROLLMENT_SUCCESS</enrollmentStatus>"),containsString("<enrollmentSubStatus>INACTIVE_DEVICE</enrollmentSubStatus>")));
		executePost(csiDeleteDeviceBasePath);
	}

	@Test
	public void testWhenDeviceStatusIsUpdatedThenInsertDeviceActivityLog() {
		executePost(csiCreateDeviceBasePath);				
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<activityType>DEENROLL</activityType>"),containsString("<activityCategory>COMPLIANCE_SYNCDEVICE</activityCategory>")));
		executePost(csiDeleteDeviceBasePath);				
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogContainsActivityCategoryAsCOMPLIANCE_SYSNDEVICE() {
		executePost(csiCreateDeviceBasePath);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<activityCategory>COMPLIANCE_SYNCDEVICE</activityCategory>"));		
		executePost(csiDeleteDeviceBasePath);				

	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogContainsActivityTypeAs_ENROLL() {
		executePost(csiCreateDeviceBasePath);				
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<activityType>ENROLL</activityType>"));
		executePost(csiDeleteDeviceBasePath);
	}
	
	@Test
	public void testGivenDeviceActionEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogContainsActivityTypeAs_DEENROLL() {
		executePost(csiCreateDeviceBasePath);				
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<activityType>DEENROLL</activityType>"));
		executePost(csiDeleteDeviceBasePath);
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogContainsSourceAs_SAMPGW() {
		executePost(csiCreateDeviceBasePath);				
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, containsString("<source>SAPMP-GW</source>"));		
		executePost(csiDeleteDeviceBasePath);
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogContainsActivityDateAs_SysDate() {
		executePost(csiCreateDeviceBasePath);				
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		String timeStamp = CommonUtil.getGMTdatetimeAsString();		
		assertThat(responseBody, containsString("<activityDate>" + timeStamp.substring(0, 13)));
		executePost(csiDeleteDeviceBasePath);
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceActivityLogIsInsertedSuccessfullyThenDeviceLogActivityDetailsContains_DeviceId_DeviceStatus_DeviceSubStatus() {
		executePost(csiCreateDeviceBasePath);				
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("deviceStatus=ACTIVE"),containsString("deviceSubStatus=ENROLLED")));	
		executePost(csiDeleteDeviceBasePath);
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceStatusNotActiveAndNotInActiveThenUpdateOnlyDeviceSubStatusAndInsertDeviceActivityLog() {
		executePost(csiCreateDeviceBasePath);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentSubStatus>ADMIN_REMOVED_MDM</enrollmentSubStatus>"),containsString("<activityType>DEENROLL</activityType>")));
		executePost(csiDeleteDeviceBasePath);		
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceSubStatusIs_CONTROL_REMOVED_ThenDeviceSubStatusIs_ADMIN_REMOVED_MDM() {
		executePost(csiCreateDeviceBasePath);				
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentSubStatus>ADMIN_REMOVED_MDM</enrollmentSubStatus>")));	
		executePost(csiDeleteDeviceBasePath);		
	}

	@Test
	public void testGivenDeviceActionEventsWhenDeviceSubStatusIs_USER_REMOVED_CONTROL_ThenDeviceStubStatusIs_USER_REMOVED_MDM() {
		executePost(csiCreateDeviceBasePath);		
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentSubStatus>USER_REMOVED_MDM</enrollmentSubStatus>")));		
		executePost(csiDeleteDeviceBasePath);		
	}

	@Test
	public void testGivenDeviceActionEventsWhenEventNotifiesSuccessfullEnrollmentThenInvokeInstallAppsAndRemoveAPN() {
		//We need to create the device record with apnStatus as Yes
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_YES);
		executePost(csiCreateDeviceBasePath);
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);					
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"emmDeviceId\":\""+emmDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<enrollmentStatus>ENROLLMENT_SUCCESS</enrollmentStatus>"),containsString("<apnStatus>No</apnStatus>"),containsString("<enrollmentSubStatus>DISTRIBUTE_APP")));
		executePost(csiDeleteDeviceBasePath);				
	}
	
	
	//@Test
	//To test a manual publish for compliance
	public void testSimulateComplianceEvent() throws InterruptedException {
		executePost(compliancePublishUrl);			
	}	
	
	
	//@Test 
	//invalid testcase, the Dmaap topic would be using AAF username and password instead of authToken for DME2
	public void testGivenAuthTokenAndConnectivityIsInvalidWhenConsummingMessageFromDMaaPTopicThenAuthenticationErrorIsReceived() {
	}
	
	//@Test 
	//invalid testcase, the Dmaap topic would be using AAF username and password instead of authToken for DME2
	public void testGivenAuthTokenAndConnectivityDetailsIsValidWhenConsummingMessageFromDMaaPTopicThenMessageIsConsumedSuccessfully() {
	}	
	
	//@Test
	//Needs to be manually tested as it is not feasible to wait for the configured interval in the testcase 
	public void testGivenConfgiuredIntervalBetweenMessagePollingWhenConsummingMessageFromDMaaPTopicThenMessagesConsumptionIntervalIsAsConfigured() {
	}
	
	//@Test
	//Invalid testcase as it is not possible to turnoff the message polling
	public void testGivenDeviceActionEventWhenMessagePollingIsTurnedOffThenNoDeviceActionOrComplianceMessagesIsConsumed() {
	}	
	
	//@Test
	//Needs to be manually tested as it is not possible to configure multiple consumes in the testcase
	public void testGivenDeviceActionEventWhenMultipleConsumesAreRunningThenAnyMessageIsConsumedOnlyOnce() {
	}
		
}
