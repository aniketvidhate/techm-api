//package com.att.sapmp.apigw.compliance.service;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.fail;
//
//import org.apache.camel.ProducerTemplate;
//import org.apache.commons.lang3.StringUtils;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
//import org.springframework.boot.test.web.client.TestRestTemplate;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringRunner;
//import com.att.ajsc.common.utility.SystemPropertiesLoader;
//import com.att.ajsc.logging.AjscEelfManager;
//import com.att.eelf.configuration.EELFLogger;
//import com.att.sapmp.apigw.compliance.service.TestConfiguration;
//
//
//@RunWith(SpringRunner.class)
//@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
//@ContextConfiguration(classes = { com.att.sapmp.apigw.compliance.Application.class, TestConfiguration.class })
//public class ComplainceApnTest {
//	
//	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ComplainceApnTest.class);
//	
//	static {
//		SystemPropertiesLoader.addSystemProperties();
//	}
//	
//        
//	   @Autowired
//	    private TestRestTemplate template;
//        
//    
//    @Test
//    public void testComplainceApnInput() throws Exception{	
//    	
//
//    	
//		HttpHeaders headers = new HttpHeaders();
//		headers.set("Content-Type", "application/json");
//		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
//		headers.set("trackingid", "1234895");
//		headers.set("emmproductcode", "IBMMASS");
//		
//		String body =  "{\r\n\t\"mdmNotification\": \r\n{ \r\n      \"eventType\":\"deviceComplianceEvent\", \r\n      \"timestamp\":\"2017-04-27T10:16:37.560Z\", \r\n      \"transactionid\":\"41165235228\", \r\n      \"mdmProviderName\":\"IBMMaaS360\", \r\n            \"deviceEventList\":{ \r\n         \"deviceEvent\":[ \r\n            { \r\n               \"emmAccountId\":\"30052663\", \r\n               \"eventSubType\":\"syncCompliance\", \r\n               \"eventTimestamp\":\"2017-04-27T19:35:27\", \r\n               \"emmDeviceId\":\"Androidce0ef417b3d3c663\", \r\n               \"emmDeviceName\":\"coudevice-SAMSUNG-SM-G900A\", \r\n               \"ownership\":\"Not Defined\", \r\n               \"deviceUserName\":\"coudevice\", \r\n               \"platformName\":\"Android\", \r\n               \"deviceType\":\"Smartphone\", \r\n               \"osName\":\"Android 5.0 (LRX21T)\", \r\n               \"imeiEsn\":\"3534110623432423\", \r\n               \"installedDate\":\"2017-04-21T20:04:38\", \r\n               \"lastReportedDate\":\"2017-04-23T16:24:57\", \r\n               \"deviceStatus\":\"ACTIVE\", \r\n               \"deviceSubStatus\":\"ENROLLED\", \r\n               \"udid\":\"Androidce0ef417b3d3c662\", \r\n               \"wifiMacAddress\":\"3c:ab:8e:5f:4a:5f\", \r\n               \"policyComplianceStatus\":\" IN_COMPLIANCE\", \r\n               \"oocReason\":null, \r\n               \"selectiveWipeStatus\":\"N/A\", \r\n               \"jailbreakStatus\":\"No\" \r\n            }, \r\n            { \r\n               \"emmAccountId\":\"30052665\", \r\n               \"eventSubType\":\"syncCompliance\", \r\n               \"eventTimestamp\":\"2017-04-27T19:35:27\", \r\n               \"emmDeviceId\":\"Androidce0ef417b3d3c655\", \r\n               \"emmDeviceName\":\"coudevice1-SAMSUNG-SM-G900A\", \r\n               \"ownership\":\"Not Defined\", \r\n               \"deviceUserName\":\"coudevice\", \r\n               \"platformName\":\"Android\", \r\n               \"deviceType\":\"Smartphone\", \r\n               \"osName\":\"Android 5.0 (LRX21T)\", \r\n               \"imeiEsn\":\"353411062343223432\", \r\n               \"installedDate\":\"2017-04-21T20:04:38\", \r\n               \"lastReportedDate\":\"2017-04-23T16:24:57\", \r\n               \"deviceStatus\":\" ACTIVE\", \r\n               \"deviceSubStatus\":\"ENROLLED\", \r\n               \"udid\":\"Androidce0ef417b3d3c662\", \r\n               \"wifiMacAddress\":\"3c:ab:8e:5f:4a:5f\", \r\n               \"policyComplianceStatus\":\" IN_COMPLIANCE\", \r\n               \"oocReason\":null, \r\n               \"selectiveWipeStatus\":\"N/A\", \r\n               \"jailbreakStatus\":\"No\" \r\n            } \r\n         ] \r\n      } \r\n }\r\n}";
//
//		 HttpEntity<String> entity = new HttpEntity<String>(body, headers);
//	     ResponseEntity<String> response = template.exchange("http://olsd004.wnsnet.attws.com:3904/events/com.att.mdmgw.mdmComplianceNotification-v1", HttpMethod.POST, entity, String.class);
//	     Thread.sleep(12000);
//		log.info("Response:" + response.getBody());
//		assertEquals(HttpStatus.OK, response.getStatusCode());	
//		
//    }
//   @Test
//    public void testComplainceInput() throws Exception{	
//    	
//	   HttpHeaders headers = new HttpHeaders();
//		headers.set("Content-Type", "application/json");
//		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
//		headers.set("trackingid", "1234895");
//		headers.set("emmproductcode", "IBMMASS");
//    	String body =  "{\r\n\t\"mdmNotification\": \r\n{ \r\n      \"eventType\":\"deviceStateChangeEvent\", \r\n      \"timestamp\":\"2017-04-27T10:16:37.560Z\", \r\n      \"transactionid\":\"4115235273012350234\", \r\n      \"mdmProviderName\":\"IBMMaaS360\", \r\n            \"deviceEventList\":{ \r\n         \"deviceEvent\":[ \r\n            { \r\n               \"emmAccountId\":\"30052663\", \r\n               \"eventSubType\":\"syncDevice\", \r\n               \"eventTimestamp\":\"2017-04-27T19:35:27\", \r\n               \"emmDeviceId\":\"Androidce0ef417b3d3c662\", \r\n               \"emmDeviceName\":\"coudevice-SAMSUNG-SM-G900A\", \r\n               \"ownership\":\"Not Defined\", \r\n               \"deviceUserName\":\"coudevice\", \r\n               \"platformName\":\"Android\", \r\n               \"deviceType\":\"Smartphone\", \r\n               \"osName\":\"Android 5.0 (LRX21T)\", \r\n               \"imeiEsn\":\"3534110623432423\", \r\n               \"installedDate\":\"2017-04-21T20:04:38\", \r\n               \"lastReportedDate\":\"2017-04-23T16:24:57\", \r\n               \"deviceStatus\":\"ACTIVE\", \r\n               \"deviceSubStatus\":\"ENROLLED\", \r\n               \"udid\":\"Androidce0ef417b3d3c662\", \r\n               \"wifiMacAddress\":\"3c:ab:8e:5f:4a:5f\", \r\n               \"policyComplianceStatus\":\" IN_COMPLIANCE\", \r\n               \"oocReason\":null, \r\n               \"selectiveWipeStatus\":\"N/A\", \r\n               \"jailbreakStatus\":\"No\" \r\n            }, \r\n            { \r\n               \"emmAccountId\":\"30052665\", \r\n               \"eventSubType\":\"syncCompliance\", \r\n               \"eventTimestamp\":\"2017-04-27T19:35:27\", \r\n               \"emmDeviceId\":\"Androidce0ef417b3d3c654\", \r\n               \"emmDeviceName\":\"coudevice1-SAMSUNG-SM-G900A\", \r\n               \"ownership\":\"Not Defined\", \r\n               \"deviceUserName\":\"coudevice\", \r\n               \"platformName\":\"Android\", \r\n               \"deviceType\":\"Smartphone\", \r\n               \"osName\":\"Android 5.0 (LRX21T)\", \r\n               \"imeiEsn\":\"353411062343223432\", \r\n               \"installedDate\":\"2017-04-21T20:04:38\", \r\n               \"lastReportedDate\":\"2017-04-23T16:24:57\", \r\n               \"deviceStatus\":\" ACTIVE\", \r\n               \"deviceSubStatus\":\"ENROLLED\", \r\n               \"udid\":\"Androidce0ef417b3d3c662\", \r\n               \"wifiMacAddress\":\"3c:ab:8e:5f:4a:5f\", \r\n               \"policyComplianceStatus\":\" IN_COMPLIANCE\", \r\n               \"oocReason\":null, \r\n               \"selectiveWipeStatus\":\"N/A\", \r\n               \"jailbreakStatus\":\"No\" \r\n            } \r\n         ] \r\n      } \r\n }\r\n}";
//    	 HttpEntity<String> entity = new HttpEntity<String>(body, headers);
//	     ResponseEntity<String> response = template.exchange("http://olsd004.wnsnet.attws.com:3904/events/com.att.mdmgw.mdmComplianceNotification-v1", HttpMethod.POST, entity, String.class);
//	     Thread.sleep(12000);
//		log.info("Response:" + response.getBody());
//		assertEquals(HttpStatus.OK, response.getStatusCode());	
//		
//    }
//    
//	@Before
//	public void setUp() throws Exception {
//		
//	}
//
//	@After
//	public void tearDown() throws Exception {
//	}
//
//}