package com.att.sapmp.apigw.compliance.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.att.sapmp.apigw.compliance.exception.CErrorDefs;
import com.att.sapmp.apigw.compliance.util.CommonDefs;

public class TestRemoveAPN extends TestBase {
	
	@Value("${test.manage.apn.basepath}")
	protected String basePath;
	
	@Value("${test.emmDeviceId}")
	private String emmDeviceId;	
	
	@Value("${test.csi.create.device.imei}")
	private String imei;	
	
	
	@Override
	public void setUp() throws Exception {
		super.setUp();
		headers.set("Content-Type", "application/json");
		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
		headers.set("trackingid",String.valueOf(new Date().getTime()));		
	}
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmDeviceId\\}", emmDeviceId);
		requestJson = requestJson.replaceAll("\\$\\{imei\\}", imei);
	}

	@Override
	protected String getBasePath() {
		return basePath;
	}	
	@Test
	public void testGivenRemoveApnWhenActionTypeIsMissingInRequestThenReturnInvalidRequestError() {
		executePost();
		assertThat(responseBody, allOf(containsString(CErrorDefs.ERROR_CODE_1002),containsString(CommonDefs.ACTION_TYPE + " is a required parameter in the input")));				

	}

	@Test
	public void testGivenRemoveApnWhenActionTypeIsNotEqualToRemoveThenReturnInvalidRequestError() {
		executePost();
		assertThat(responseBody, allOf(containsString(CErrorDefs.ERROR_CODE_1001),containsString(CommonDefs.ACTION_TYPE + " needs to be populated with correct value.")));				

	}

	@Test
	public void testGivenRemoveApnWhenCtnIsMissingInRequestThenReturnInvalidRequestError() {
		headers.add(CommonDefs.CTN, "");
		headers.add(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
		executePost(csiCreateDeviceBasePath);
		headers.remove(CommonDefs.CTN);
		executePost();
		String applyAPNResponse = responseBody;
		executePost(csiDeleteDeviceBasePath);
		assertThat(applyAPNResponse, allOf(containsString(CErrorDefs.ERROR_CODE_1002),containsString(CErrorDefs.ERROR_CODE_1002_DESCRIPTION)));
	}

	@Test
	public void testGivenRemoveApnWhenDeviceIdAndEmmDeviceIdIsMissingInRequestThenReturnInvalidRequestError() {
		executePost();
		assertThat(responseBody, allOf(containsString(CErrorDefs.ERROR_CODE_1002),containsString(CErrorDefs.ERROR_CODE_1002_DESCRIPTION)));	
	}

	@Test
	public void testGivenRemoveApnWhenActionTypeIsRemoveAndDeviceApnStatusIsNoThenStopTheProcess() throws Exception{
		//We need to create the device record with apnStatus as No
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_NO);
		executePost(csiCreateDeviceBasePath);
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);	
		requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", generatedCDFDeviceId);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<apnStatus>No</apnStatus>")));
		executePost(csiDeleteDeviceBasePath);
	}

	@Test
	public void testGivenRemoveApnWhenActionTypeIsRemoveAndDeviceApnStatusIsYesThenRemoveApnIsSuccess() throws Exception{
		//We need to create the device record with apnStatus as Yes
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_YES);
		executePost(csiCreateDeviceBasePath);
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);	
		requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", generatedCDFDeviceId);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<apnStatus>No</apnStatus>"),containsString("<activityType>REMOVE_APN</activityType>")));
		executePost(csiDeleteDeviceBasePath);		
	}

	//@Test
	//Manual
	//Since the publish apn will not fail in normal circumstances, update the application-test.properties dme2.apn.publish.timeout to 0 milliseconds so that the message is unsent
	//Note: remember to undo the changes to application-test.properties dme2.apn.publish.timeout after successfully executing this testcase manually.
	public void testGivenRemoveApnWhenRemoveApnIsFailureThenSkipApnStatusUpdateAndInsertActivityLog() throws Exception {
		//We need to create the device record with apnStatus as Yes
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_YES);
		executePost(csiCreateDeviceBasePath);
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);	
		requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", generatedCDFDeviceId);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<activityType>REMOVE_APN_FAILURE</activityType>")));
		executePost(csiDeleteDeviceBasePath);		
	}

	@Test
	public void testGivenRemoveApnWhenRemoveApnIsSuccessThenUpdateApnStatusAsNoAndInsertActivityLog() throws Exception{
		//We need to create the device record with apnStatus as Yes
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_YES);
		executePost(csiCreateDeviceBasePath);
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);	
		requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", generatedCDFDeviceId);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<apnStatus>No</apnStatus>"),containsString("<activityType>REMOVE_APN</activityType>")));
		executePost(csiDeleteDeviceBasePath);
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenRemoveApnIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
		headers.set("authorization", "Basic 123");
		executePost();		
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenRemoveApnIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception{
		//We need to create the device record with apnStatus as Yes
		headers.add(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_YES);
		executePost(csiCreateDeviceBasePath);
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		//After creation of the device record remove the header added to avoid interference with testcase execution
		headers.add(CommonDefs.APNSTATUS, null);	
		requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", generatedCDFDeviceId);
		executePost();
		executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		assertThat(responseBody, allOf(containsString("<apnStatus>No</apnStatus>"),containsString("<activityType>REMOVE_APN</activityType>")));
		executePost(csiDeleteDeviceBasePath);
	}
	
	//TODO Write test cases for the values getting inserted into the device activity log

}
