package com.att.sapmp.apigw.compliance.service.rs;

import javax.ws.rs.HeaderParam;

import org.apache.cxf.jaxrs.ext.multipart.Attachment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.compliance.model.ApplyApn;

@AjscService
public class ManageAPNServiceImpl implements ManageAPNRestService {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ManageAPNServiceImpl.class);

	public ManageAPNServiceImpl() {
		// needed for autowiring
	}

	@Override
	public void manageAPN(@HeaderParam(value = "Authorization") String authorization, @HeaderParam(value = "TrackingId") String trackingId, @HeaderParam(value = "EMMProductCode") String productCode,
			@HeaderParam(value = "AccountPassPhrase") String accountpassphrase, @RequestBody ApplyApn applyApn) {
	}
}
