package com.att.sapmp.apigw.compliance;

import javax.servlet.Filter;
import javax.servlet.ServletException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.att.cadi.PropAccess;
import com.att.cadi.filter.CadiFilter;

@Configuration
public class WebConfiguration {

	@Value("${cadi.properties}")
	private String cadiPropFile;
	
	@Bean
	public PropAccess propAccess() {

		StringBuilder sbPath = new StringBuilder();

		sbPath.append("cadi_prop_files=");
		sbPath.append(cadiPropFile);
		PropAccess access = new PropAccess(new String[] { sbPath.toString() });
		return access;
	}

	@Bean(name = "cadiFilter")
	public Filter cadiFilter() throws ServletException {
		return new CadiFilter(true, propAccess());
	}

	@Bean
	public FilterRegistrationBean cadiFilterRegistration() throws ServletException {

		FilterRegistrationBean registration = new FilterRegistrationBean();
		registration.setFilter(cadiFilter());
		registration.addUrlPatterns("/*");
		registration.setName("cadiFilter");
		registration.setOrder(0);
		return registration;

	}

	public String getCadiPropFile() {
		return cadiPropFile;
	}

	public void setCadiPropFile(String cadiPropFile) {
		this.cadiPropFile = cadiPropFile;
	}
}