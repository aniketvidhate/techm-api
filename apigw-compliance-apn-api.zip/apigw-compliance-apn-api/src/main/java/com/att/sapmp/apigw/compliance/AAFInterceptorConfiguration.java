package com.att.sapmp.apigw.compliance;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.att.ajsc.aaf.interceptors.AAFCamelPreInterceptor;

@Configuration
public class AAFInterceptorConfiguration {

    @Bean
    public AAFCamelPreInterceptor aafCamelPreInterceptor() {
        return new AAFCamelPreInterceptor();
    }

}

