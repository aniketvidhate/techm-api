package com.att.sapmp.apigw.compliance.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.compliance.exception.ApigwException;
import com.att.sapmp.apigw.compliance.exception.CErrorDefs;
import com.att.sapmp.apigw.compliance.util.CommonDefs;
import com.att.sapmp.apigw.compliance.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CSIManageEnterpriseDeviceDeploymentDetailsProcessor {

	private Logger log = LoggerFactory.getLogger(CSIManageEnterpriseDeviceDeploymentDetailsProcessor.class);

	@Autowired
	CommonUtil commonUtil;

	public final void execute(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> updateDeviceDetailsRequestMap = null;
		try {
			updateDeviceDetailsRequestMap = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
		} catch (IOException ioe) {
			log.info("Exception occurred while parsing post request: ", ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);

		}
		commonUtil.populateCSIHeader(updateDeviceDetailsRequestMap);

		VelocityContext velocityContext = new VelocityContext(updateDeviceDetailsRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);

	}

	public final void handleResponse(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		String body = e.getIn().getBody(String.class);
		//log.info("Response received in handleResponse: \n" + body);
		commonUtil.logXML("Received response in handleResponse method", body);
		Map<String, String> bodyMap = new HashMap<String, String>();
		bodyMap.put(CommonDefs.DEVICE_ID, (String) headers.get(CommonDefs.DEVICE_ID));
		bodyMap.put(CommonDefs.EMM_DEVICE_ID, (String) headers.get(CommonDefs.EMM_DEVICE_ID));
		bodyMap.put(CommonDefs.IMEI, (String) headers.get(CommonDefs.IMEI));
		bodyMap.put(CommonDefs.ACTION_TYPE, (String) headers.get(CommonDefs.ACTION_TYPE));
		VelocityContext velocityContext = new VelocityContext(bodyMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

}