package com.att.sapmp.apigw.compliance.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class ApplyApn {
	@JsonProperty
	private String actionType;

	@ApiModelProperty(value = "actionType", example = "apply")
	public String getActionType() {
		return this.actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	@JsonProperty
	private String imei;

	@ApiModelProperty(value = "imei", example = "355617081117244")
	public String getImei() {
		return this.imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	@JsonProperty
	private String deviceId;

	@ApiModelProperty(value = "deviceId", example = "Q44000000000001088")
	public String getDeviceId() {
		return this.deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

}
