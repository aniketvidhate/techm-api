package com.att.sapmp.apigw.compliance.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.nsa.mr.client.MRBatchingPublisher;
import com.att.nsa.mr.client.MRClientFactory;
import com.att.nsa.mr.client.MRPublisher.message;
import com.att.sapmp.apigw.compliance.exception.ApigwException;
import com.att.sapmp.apigw.compliance.exception.CErrorDefs;
import com.att.sapmp.apigw.compliance.util.CommonDefs;

public class PublishAPNProcessor {
	@Value("${manageApn.applicationId}")
	private String applicationId;
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(PublishAPNProcessor.class);

	@Value("${dme2.apn.producerPropertiesPath}")
	private String producerPropertiesPath;

	@Value("${dme2.apn.publish.timeout}")
	private String apnPublishTimeout;

	public final void execute(Exchange e,  @Headers Map<String, Object> headers) throws Exception {
		String apnNotification = e.getIn().getBody(String.class);
		JSONObject apnNotificationJson = new JSONObject(apnNotification);
		headers.put(CommonDefs.MANAGE_APN_POSTED_MESSAGE, apnNotificationJson);
		final MRBatchingPublisher apnNotificationPublisher = MRClientFactory.createBatchingPublisher(producerPropertiesPath);
		log.info("message posted to dmaap topic :\n" + apnNotificationJson.toString());
		apnNotificationPublisher.send(apnNotificationJson.toString());
		
		// ...
		// close the publisher to make sure everything's sent before exiting.
		// The batching
		// publisher interface allows the app to get the set of unsent messages.
		// It could
		// write them to disk, for example, to try to send them later.
		final List<message> stuck = apnNotificationPublisher.close(Long.valueOf(apnPublishTimeout), TimeUnit.MILLISECONDS);
		if (stuck.size() > 0) {
			log.error(stuck.size() + " messages unsent");
			e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_500);

		} else {
			log.info("Clean exit; all messages sent.");
			e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
		}

	}

	public final void constructRequest(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		String actionType = (String) headers.get(CommonDefs.ACTION_TYPE);
		String imei = (String) headers.get(CommonDefs.IMEI);
		String trackingId = (String) headers.get(CommonDefs.TRACKING_ID);
		Map<String, Object> apnRequestMap = new HashMap<>();

		apnRequestMap.put(CommonDefs.APPLICATION_ID, applicationId);
		apnRequestMap.put(CommonDefs.TRACKING_ID, trackingId);
		apnRequestMap.put(CommonDefs.CTN, (String) headers.get(CommonDefs.CTN));
		apnRequestMap.put(CommonDefs.FAN, (String) headers.get(CommonDefs.FAN));
		apnRequestMap.put(CommonDefs.BAN, (String) headers.get(CommonDefs.BAN));
		apnRequestMap.put(CommonDefs.IMEI, imei);
		apnRequestMap.put(CommonDefs.APN_RESTRICTION, actionType);

		VelocityContext velocityContext = new VelocityContext(apnRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		headers.put(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
	}

	public final void handleResponse(Exchange e, @Headers Map<String, Object> headers) throws Exception {
		log.info("Recived response from Apply/Remove APN Endpoints ::SUCCESS");
		JSONObject body = new JSONObject();
		body.put(CommonDefs.MANAGE_APN, CommonDefs.SUCCESS_CODE);
		e.getIn().setBody(body);
		headers.put(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);

	}

}
