package com.att.sapmp.apigw.compliance.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.compliance.exception.ApigwException;
import com.att.sapmp.apigw.compliance.exception.CErrorDefs;
import com.att.sapmp.apigw.compliance.util.CommonDefs;
import com.att.sapmp.apigw.compliance.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

@Component
public class CSIInquireEnterpriseDeviceDeploymentDetailsProcessor {

	private Logger log = LoggerFactory.getLogger(CSIInquireEnterpriseDeviceDeploymentDetailsProcessor.class);
	@Autowired
	CommonUtil commonUtil;

	@Value("${csi.inquire.device.detail.deviceLogActivityFlag}")
	private String deviceLogActivityFlag;

	public final void execute(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		log.info("request in execute method:" + postReqJSON);
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> inquireDeviceDetailsRequestMap = null;
		try {
			inquireDeviceDetailsRequestMap = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
		} catch (IOException ioe) {
			log.error("Exception occurred while parsing request json." + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		commonUtil.populateCSIHeader(inquireDeviceDetailsRequestMap);
		inquireDeviceDetailsRequestMap.put(CommonDefs.DEVICE_LOG_ACTIVITY_FLAG, Boolean.valueOf(deviceLogActivityFlag));
		VelocityContext velocityContext = new VelocityContext(inquireDeviceDetailsRequestMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	public final void handleResponse(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		try {
			String csiResposeBody = (String) e.getIn().getBody();
			//log.info("Response received in handleResponse method body:\n" + csiResposeBody);
			commonUtil.logXML("Received response in handleResponse method", csiResposeBody);
			XmlMapper xmlMapper = new XmlMapper();
			Map<String, Object> csiResponseMap = null;
			try {
				csiResponseMap = xmlMapper.readValue(csiResposeBody, HashMap.class);

			} catch (IOException ioe) {
				log.info("Exception occurred while parsing post request: " + ioe);
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
			}
			Map<String, Object> responseBodyMap = (HashMap<String, Object>) csiResponseMap.get(CommonDefs.BODY);
			if (responseBodyMap != null && !(responseBodyMap.isEmpty())) {
				Map<String, Object> cdfDeviceDetailsMap = (HashMap<String, Object>) responseBodyMap.get(CommonDefs.IEDDD_RESPONSE);
				if (cdfDeviceDetailsMap != null && !(cdfDeviceDetailsMap.isEmpty())) {
					Map<String, Object> deviceDetailList = (HashMap<String, Object>) cdfDeviceDetailsMap.get(CommonDefs.DEVICE_DETAIL_LIST);

					if (deviceDetailList != null && !(deviceDetailList.isEmpty())) {
						String deviceApnStatus = (String) deviceDetailList.get(CommonDefs.APNSTATUS);
						log.info("deviceApnStatus in CDF:" + deviceApnStatus);
						if (CommonDefs.DEVICE_APN_STATUS_YES.equalsIgnoreCase(deviceApnStatus)) {
							headers.put(CommonDefs.DEVICE_APN_STATUS, CommonDefs.DEVICE_APN_STATUS_YES);
						} else {
							headers.put(CommonDefs.DEVICE_APN_STATUS, CommonDefs.DEVICE_APN_STATUS_NO);
						}
						String fan = (String) deviceDetailList.get(CommonDefs.FAN);
						String ban = (String) deviceDetailList.get(CommonDefs.BAN);
						String ctn = (String) deviceDetailList.get(CommonDefs.CUSTOMER_TELEPHONE_NUMBER);
						if (StringUtils.isEmpty(ctn)) {
							throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CErrorDefs.ERROR_CODE_1002_DESCRIPTION);
						}
						headers.put(CommonDefs.FAN, fan);
						headers.put(CommonDefs.BAN, ban);
						headers.put(CommonDefs.CTN, ctn);
						headers.put(CommonDefs.EXISTING_DEVICE_NETWORK_CONTROL, false);
						if (deviceDetailList.get(CommonDefs.DEVICE_DETAIL_PROFILE_TYPE) != null) {
							String networkControlExistingDeviceFlag = (String) ((HashMap<String, Object>) deviceDetailList.get(CommonDefs.DEVICE_DETAIL_PROFILE_TYPE)).get(CommonDefs.DEVICE_DETAIL_PROFILE_TYPE_NETWORK_CONTROL_EXISTING_FLAG);
							log.info("networkControlExistingDeviceFlag in CDF:" + networkControlExistingDeviceFlag);
							if (Boolean.valueOf(networkControlExistingDeviceFlag)) {
								headers.put(CommonDefs.EXISTING_DEVICE_NETWORK_CONTROL, true);
							}
						}
					}

				}
			}
			headers.put(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
		} catch (ApigwException iaex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_400);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, iaex.getErrorMsg());
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, iaex.getErrorCode());
			log.error("Caught ApigwException with error message::", iaex);
			throw new ApigwException(iaex.getErrorCode(), iaex.getErrorMsg());
		} catch (Exception ex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_500);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, CErrorDefs.SYSTEM_ERROR);
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_5001);
			log.error("Caught Exception with error message::", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}

	}

}