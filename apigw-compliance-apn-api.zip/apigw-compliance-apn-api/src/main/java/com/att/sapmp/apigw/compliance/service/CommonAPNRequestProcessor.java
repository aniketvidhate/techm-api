package com.att.sapmp.apigw.compliance.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.compliance.exception.ApigwException;
import com.att.sapmp.apigw.compliance.exception.CErrorDefs;
import com.att.sapmp.apigw.compliance.util.CommonDefs;
import com.att.sapmp.apigw.compliance.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
/**
 * This class is responsible for handling the request for apply/remove APN from
 * both compliance and enroll task events
 *
 */
public class CommonAPNRequestProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CommonAPNRequestProcessor.class);

	@Autowired
	CommonUtil commonUtil;

	@Value("${manageApn.applicationId}")
	private String applicationId;

	public final void execute(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {

		try {
			JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
			ObjectMapper objectMapper = new ObjectMapper();

			HashMap<String, Object> manageApnMap = null;
			try {
				manageApnMap = objectMapper.readValue(postReqJSON.toString(), HashMap.class);
			} catch (IOException e1) {
				log.error("Exception occurred while parsing post request: " + e1);
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
			}
			log.info("In execute method request for manageAPN: " + manageApnMap);
			commonUtil.validateMap(headers, CommonDefs.MANAGE_APN_HEADERS);
			commonUtil.validateMap(manageApnMap, CommonDefs.MANAGE_APN_MANDATORY_FIELDS);
			String actionType = (String) manageApnMap.get(CommonDefs.ACTION_TYPE);
			if(!CommonDefs.ACTION_TYPE_APPLY.equalsIgnoreCase(actionType) && !CommonDefs.ACTION_TYPE_REMOVE.equalsIgnoreCase(actionType)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.ACTION_TYPE + " needs to be populated with correct value.");
			}
			String imei = (String) manageApnMap.get(CommonDefs.IMEI);
			String emmDeviceId = (String) manageApnMap.get(CommonDefs.EMM_DEVICE_ID);
			String deviceId = (String) manageApnMap.get(CommonDefs.DEVICE_ID);
			// Either the emmDeviceId or the deviceId should be populated in the
			// request
			if (StringUtils.isEmpty(emmDeviceId) && StringUtils.isEmpty(deviceId)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CErrorDefs.ERROR_CODE_1002_DESCRIPTION);
			}
			VelocityContext velocityContext = new VelocityContext(manageApnMap);
			headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
			headers.put(CommonDefs.ACTION_TYPE, actionType);
			headers.put(CommonDefs.IMEI, imei);
			headers.put(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
			headers.put(CommonDefs.DEVICE_ID, deviceId);
		}

		catch (ApigwException iaex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_400);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, iaex.getErrorMsg());
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, iaex.getErrorCode());
			log.error("Caught ApigwException with error message::", iaex);
			throw new ApigwException(iaex.getErrorCode(), iaex.getErrorMsg());
		} catch (Exception ex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_500);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, CErrorDefs.SYSTEM_ERROR);
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_5001);
			log.error("Caught Exception with error message::", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}

	public final void toggleAPNStatusInCDF(Exchange e, @Headers Map<String, Object> headers) throws Exception {

		String apnStatus = (String) headers.get(CommonDefs.DEVICE_APN_STATUS);
		String trackingId = (String) headers.get(CommonDefs.TRACKING_ID);
		String publishApnStatus = (String)headers.get(CommonDefs.PUBLISH_APN_STATUS);
		Map<String, String> updateDeviceDetailsMap = new HashMap<>();

		updateDeviceDetailsMap.put(CommonDefs.MODE, CommonDefs.MODE_UPDATE);
		updateDeviceDetailsMap.put(CommonDefs.IMEI, (String) (headers.get(CommonDefs.IMEI)));
		updateDeviceDetailsMap.put(CommonDefs.EMM_DEVICE_ID, (String) (headers.get(CommonDefs.EMM_DEVICE_ID)));
		updateDeviceDetailsMap.put(CommonDefs.DEVICE_ID, (String) (headers.get(CommonDefs.DEVICE_ID)));
		JSONObject apnNotificationJson = (JSONObject)headers.get(CommonDefs.MANAGE_APN_POSTED_MESSAGE);
		
		if (!StringUtils.isEmpty(publishApnStatus) && CommonDefs.SUCCESS_CODE.equalsIgnoreCase(publishApnStatus)) {
			if (apnStatus.equals(CommonDefs.DEVICE_APN_STATUS_NO)) {
				// Since previously APNStatus was No/Null in CDF and APN
				// restriction
				// was successfully applied hence update the apnStatus in CDF as
				// Yes
				updateDeviceDetailsMap.put(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_YES);
				updateDeviceActivityLog(updateDeviceDetailsMap, trackingId, apnNotificationJson, CommonDefs.ACTIVITY_TYPE.APPLY_APN, CommonDefs.ACTIVITY_CATEGORY.APN, CommonDefs.ACTIVITY_DETAILS_NOTES_APPLY_APN);
			} else if (apnStatus.equals(CommonDefs.DEVICE_APN_STATUS_YES)) {
				// Since previously APNStatus was Yes in CDF and APN restriction
				// was
				// successfully removed hence update the apnStatus in CDF as No
				updateDeviceDetailsMap.put(CommonDefs.APNSTATUS, CommonDefs.DEVICE_APN_STATUS_NO);
				updateDeviceActivityLog(updateDeviceDetailsMap, trackingId, apnNotificationJson, CommonDefs.ACTIVITY_TYPE.REMOVE_APN, CommonDefs.ACTIVITY_CATEGORY.APN, CommonDefs.ACTIVITY_DETAILS_NOTES_REMOVE_APN);
			}
		}
		//If the message failed while posting to IRS, update the activity log in CDF
		else {
			if (apnStatus.equals(CommonDefs.DEVICE_APN_STATUS_NO)) {
				updateDeviceActivityLog(updateDeviceDetailsMap, trackingId, apnNotificationJson, CommonDefs.ACTIVITY_TYPE.APPLY_APN_FAILURE, CommonDefs.ACTIVITY_CATEGORY.APN, CommonDefs.ACTIVITY_DETAILS_NOTES_APPLY_APN_FAILURE);
			} else if (apnStatus.equals(CommonDefs.DEVICE_APN_STATUS_YES)) {
				updateDeviceActivityLog(updateDeviceDetailsMap, trackingId, apnNotificationJson, CommonDefs.ACTIVITY_TYPE.REMOVE_APN_FAILURE, CommonDefs.ACTIVITY_CATEGORY.APN, CommonDefs.ACTIVITY_DETAILS_NOTES_REMOVE_APN_FAILURE);
			}

		}
		JSONObject requestbody = new JSONObject(updateDeviceDetailsMap);
		e.getIn().setBody(requestbody);
		headers.put(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
	}

	private void updateDeviceActivityLog(Map<String, String> updateDeviceDetailsMap, String trackingId, JSONObject apnNotificationJson,Enum activityType, Enum activityCategory, String activityDetails) {		
		Map<String, Object> activityMap = new HashMap<>();
		activityMap.put(CommonDefs.ACTIVITY_DETAILS_NOTES, activityDetails);
		activityMap.put(CommonDefs.ACTIVITY_DETAILS_MDM_TRANSACTION_ID, trackingId);
		activityMap.put(CommonDefs.ACTIVITY_DETAILS_MANAGE_APN_MESSAGE, apnNotificationJson);

		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityCategory.toString(), activityCategory.toString());
		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityType.toString(), activityType.toString());
		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityDetails.toString(), StringEscapeUtils.escapeXml(activityMap.toString()));
		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.source.toString(), CommonDefs.SOURCE_SAPMP_GW);
		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityDate.toString(), CommonUtil.getGMTdatetimeAsString());
	}

}
