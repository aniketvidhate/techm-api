package com.att.sapmp.apigw.compliance.util;

public class CommonDefs {

	public static final String BILLING_ID = "billingId";
	public static final String ACCOUNT_PASS_PHRASE = "AccountPassPhrase";
	public static final String USER_NAME = "userName";
	public static final String PASSWORD = "password";
	public static final String EMM_ACCOUNT_ID = "emmAccountId";
	public static final String DEVICE_ID = "deviceId";
	public static final String CAMEL_HTTP_RESPONSE_CODE = "CamelHttpResponseCode";
	public static final String CAMEL_HTTP_URL = "CamelHttpUrl";
	public static final String EMM_PRODUCT_CODE = "emmproductcode";
	public static final String TRACKING_ID = "TrackingId";
	public static final String MANAGE_APN_POSTED_MESSAGE = "manageApnPostedMessage";
	public static final String[] MANAGE_APN_MANDATORY_FIELDS = { CommonDefs.IMEI, CommonDefs.ACTION_TYPE };
	public static final String[] MDM_NOTIFICATION_MANDATORY_FIELDS = {CommonDefs.EVENT_TYPE,CommonDefs.TIMESTAMP,CommonDefs.MDM_NOTIFICATION_TRANSACTION_ID, CommonDefs.ORGID, CommonDefs.MDM_PROVIDER_NAME};
	public static final String[] MDM_DEVICE_EVENT_MANDATORY_FIELDS = {CommonDefs.EMM_ACCOUNT_ID,CommonDefs.EVENT_SUB_TYPE,CommonDefs.EMM_DEVICE_ID, CommonDefs.IMEI_ESN};
	public static final String[] MDM_DEVICE_EVENT_SYNC_COMPLIANCE_MANDATORY_FIELDS = {CommonDefs.POLICY_COMPLAINCE_STATUS};
	public static final String[] MDM_DEVICE_EVENT_SYNC_COMPLIANCE_OUT_OF_COMPLIANCE_MANDATORY_FIELDS = {CommonDefs.POLICY_COMPLAINCE_STATUS, CommonDefs.OOC_REASON};
	public static final String[] MDM_DEVICE_EVENT_SYNC_DEVICE_STATE_MANDATORY_FIELDS = {CommonDefs.MDM_DEVICE_STATUS, CommonDefs.MDM_DEVICE_SUB_STATUS};



	public static final String PARTNER_ACCOUNT = "partnerAccount";
	public static final String[] MANAGE_APN_HEADERS = { "authorization", "trackingid" };
	public static final String[] ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductCode" };

	public static final String DESCRIPTION = "description";
	public static final String PRODUCT_CODE = "productCode";
	public static final String EMMP_PRODUCT_CODE = "EMMProductCode";
	public static final String ORIGIONAL_BODY = "origionalBody";
	public static final String ERROR_CODE_STR = "errorCode";
	public static final String MESSAGE = "message";
	public static final String AUTHORIZATION = "Authorization";

	public static final String APPLICATION_ID = "applicationId";
	public static final String BAN = "ban";
	public static final String FAN = "fan";
	public static final String CTN = "ctn";
	public static final String IMEI = "imei";
	public static final String CUSTOMER_TELEPHONE_NUMBER = "customerTelephoneNumber";
	public static final String RESPONSE_SUCCESS_CODE = "200";
	public static final String RESPONSE_ACCEPT_CODE = "202";
	public static final String MANAGE_APN = "manageAPN";
	public static final String ACTION_TYPE_APPLY = "apply";
	public static final String ACTION_TYPE_REMOVE = "remove";
	public static final String ACTION_TYPE_NO_ACTION = "noAction";
	public static final String APNSTATUS = "apnStatus";
	public static final String PUBLISH_APN_STATUS = "publishApnStatus";
	public static final String SUCCESS_CODE = "Success";
	public static final String BODY = "Body";

	public static final String DEVICE_DETAIL_LIST = "DeviceDetailList";
	public static final String DEVICE_DETAIL_PROFILE_TYPE = "ProfileType";
	public static final String DEVICE_DETAIL_PROFILE_TYPE_NETWORK_CONTROL_EXISTING_FLAG = "networkControlExistingDeviceFlag";
	public static final String IEDDD_RESPONSE = "InquireEnterpriseDeviceDeploymentDetailsResponse";
	public static final String IEDDP_RESPONSE = "InquireEnterpriseDeviceDeploymentProfileResponse";
	public static final String DEVICE_DEPLOYMENT_PROFILE = "DeviceDeploymentProfile";
	public static final String ADDPT_TENANT_ACCOUNT_DETAILS = "ADDPTenantAccountDetails";
	public static final String ACCOUNT_PASS_PHRASE_IEDDP = "accountPassphrase";
	public static final String EMM_PRODUCT_CODE_IEDDP = "emmProductCode";
	public static final String EXISTING_DEVICE_NETWORK_CONTROL = "existingDeviceNetworkControl";
	public static final String APN_RESTRICTION = "apnRestriction";

	public static final String INFRASTRUCTURE_VERSION = "infrastructureVersion";
	public static final String APPLICATION_NAME = "applicationName";
	public static final String VERSION = "version";
	public static final String VERSION_NO = "versionNo";
	public static final String MESSAGE_ID = "messageId";
	public static final String ROUTING_REGION_OVERRIDE = "routingRegionOverride";
	public static final String DATE_TIMESTAMP = "dateTimeStamp";
	public static final String USER_PASSWORD = "userPassword";
	public static final String SEQUENCE_NUMBER = "sequenceNumber";
	public static final String TOTAL_IN_SEQUENCE = "totalInSequence";
	public static final String TIME_TO_LIVE = "timeToLive";
	public static final String DEVICE_LOG_ACTIVITY_FLAG = "deviceLogActivityFlag";
	public static final String UNIQUE_TRANSACTION_ID = "uniqueTransactionId";
	public static final String MODE = "mode";
	public static final String RESPONSE_SUCCESS_MSG = "SUCCESS";
	public static final String MODE_UPDATE = "U";
	public static final String MODE_DELETE = "D";
	public static final String RESPONSE_BODY = "responseBody";
	public static final String RESPONSE_HEADER = "responseHeader";
	public static final String QUERY_PARAM = "QueryParam";

	// Added for Compliance-apn orchestration services
	public static final String MDM_NOTIFICATION = "mdmNotification";
	public static final String MDM_NOTIFICATION_TRANSACTION_ID = "transactionId";
	public static final String MDM_NOTIFICATION_LIST = "mdmNotificationList";
	public static final String EVENT_TYPE = "eventType";
	public static final String DEVICE_EVENT_LIST = "deviceEventList";
	public static final String DEVICE_EVENT = "deviceEvent";
	public static final String MDM_NOTIFICATION_RESPONSE = "mdmNotificationResponse";
	public static final String DEVICE_COMPLAINT_EVENT = "deviceComplianceEvent";
	public static final String TIMESTAMP="timestamp";
	public static final String ORGID="orgId";
	public static final String MDM_PROVIDER_NAME="mdmProviderName";
	public static final String DEVICE_STATE_CHANGE_EVENT = "deviceStateChangeEvent";
	public static final String POLICY_COMPLAINCE_STATUS = "policyComplianceStatus";
	public static final String OOC_REASON = "oocReason";
	public static final String COMPLIANCE_STATUS_REASON = "complianceStatusReason";
	public static final String COMPLIANCE_STATUS_REASON_EMPTY = " ";

	public static final String COMPLAINCE_STATUS = "complianceStatus";
	public static final String EVENT_SUB_TYPE = "eventSubType";
	public static final String MDM_DEVICE_STATUS = "deviceStatus";
	public static final String MDM_DEVICE_SUB_STATUS = "deviceSubStatus";
	public static final String EVENT_SUB_TYPE_SYNC_DEVICE_STATE = "syncDeviceState";
	public static final String EVENT_SUB_TYPE_SYNC_COMPLIANCE = "syncCompliance";

	// public static final String ENROLLED = "ENROLLED";
	public static final String ENROLLMENT_SUCCESS = "EnrollmentSuccess";
	public static final String DEENROLLMENT_SUCCESS = "DeEnrollmentSuccess";
	public static final String PROFILE_ID = "profileId";
	public static final String ACTION_TYPE = "actionType";
	public static final String INSTALL_APP = "InstallApp";
	public static final String REMOVE_APN = "RemoveAPN";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String EMM_DEVICE_ID = "emmDeviceId";
	public static final String IMEI_ESN = "imeiEsn";
	public static final String IN_COMPLIANCE = "IN_COMPLIANCE";
	public static final String OUT_OF_COMPLIANCE = "OUT_OF_COMPLIANCE";

	// Device Logs Constants
	public enum CSI_ACTIVITY_LOG {
		activityCategory, activityType, activityDetails, source, activityDate
	};

	public static final String ACTIVITY_DETAILS_NOTES = "notes";
	public static final String ACTIVITY_DETAILS_MDM_TRANSACTION_ID = "mdmTransactionId";
	public static final String ACTIVITY_DETAILS_DEVICE_EVENT = "deviceEvent";
	public static final String ACTIVITY_DETAILS_MANAGE_APN_MESSAGE = "manageApnMessage";
	public static final String ENROLLMENT_STATUS = "enrollmentStatus";
	public static final String ENROLLMENT_SUB_STATUS = "enrollmentSubStatus";
	public static final String SOURCE_SAPMP_GW = "SAPMP-GW";

	public enum ACTIVITY_CATEGORY {
		COMPLIANCE_SYNCDEVICE, COMPLIANCE_SYNCOMPLIANCE, APN
	};

	public enum ACTIVITY_TYPE {
		ENROLL, DEENROLL, COMPLIANCE, NON_COMPLIANCE, APPLY_APN, REMOVE_APN, OTHER, APPLY_APN_FAILURE, REMOVE_APN_FAILURE
	};

	public enum STATUS_ENROLLMENT {
		ENROLLMENT_SUCCESS, DEENROLLMENT_SUCCESS
	};

	public enum SUB_STATUS {
		ACTIVE_DEVICE, INACTIVE_DEVICE, ADMIN_REMOVED_MDM, PENDING_CONTROL_REMOVAL, USER_REMOVED_MDM
	};

	public enum DEVICE_STATUS {
		ACTIVE, INACTIVE
	};

	public enum DEVICE_SUB_STATUS {
		ENROLLED, INACTIVE, CONTROL_REMOVED, PENDING_CONTROL_REMOVAL, USER_REMOVED_CONTROL
	};

	/** START :COMPLIANCE_SYNCDEVICE activity details notes **/
	public static final String ACTIVITY_DETAILS_NOTES_ENROLLMENT_SUCCESS_EVENT = "device enrollment has been completed successfully";
	public static final String ACTIVITY_DETAILS_NOTES_DEENROLLMENT_SUCCESS_EVENT = "device de-enrollment has been completed successfully";
	public static final String ACTIVITY_DETAILS_NOTES_ADMIN_REMOVED_MDM_SUCCESS_EVENT = "MDM control has been removed successfully by Admin";
	public static final String ACTIVITY_DETAILS_NOTES_PENDING_CONTROL_REMOVAL_SUCCESS_EVENT = "MDM control has been removed successfully by Admin, but device is not reachable";
	public static final String ACTIVITY_DETAILS_NOTES_USER_REMOVED_MDM_SUCCESS_EVENT = "MDM control has been removed successfully by user";
	public static final String ACTIVITY_DETAILS_NOTES_SYNC_DEVICE_OTHER = "Other syncDeviceState event";
	/** END :COMPLIANCE_SYNCDEVICE activity details notes **/

	/**
	 * START :ACTIVITY_CATEGORY_COMPLIANCE_SYNCOMPLIANCE activity details notes
	 **/
	public static final String ACTIVITY_DETAILS_NOTES_NON_COMPLIANCE = "device is out of compliance";
	public static final String ACTIVITY_DETAILS_NOTES_COMPLIANCE = "device is back into compliance";
	public static final String ACTIVITY_DETAILS_NOTES_SYNC_COMPLIANCE_OTHER = "other syncCompliance event";
	/**
	 * END :ACTIVITY_CATEGORY_COMPLIANCE_SYNCOMPLIANCE activity details notes
	 **/

	/** START :APN Apply/Remove APN Constants **/
	public static final String DEVICE_APN_STATUS = "deviceApnStatus";
	public static final String DEVICE_APN_STATUS_YES = "Yes";
	public static final String ACTIVITY_DETAILS_NOTES_APPLY_APN = "Posted ApplyAPN request to IRS";
	public static final String ACTIVITY_DETAILS_NOTES_APPLY_APN_FAILURE = "Failed posting ApplyAPN request to IRS";
	public static final String DEVICE_APN_STATUS_NO = "No";
	public static final String ACTIVITY_DETAILS_NOTES_REMOVE_APN = "Posted RemoveAPN request to IRS";
	public static final String ACTIVITY_DETAILS_NOTES_REMOVE_APN_FAILURE = "Failed posting RemoveAPN request to IRS";
	/** END :ACTIVITY_CATEGORY_APN Event Handling Constants **/

}
