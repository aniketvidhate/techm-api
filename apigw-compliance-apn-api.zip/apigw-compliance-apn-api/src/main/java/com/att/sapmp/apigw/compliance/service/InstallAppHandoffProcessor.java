package com.att.sapmp.apigw.compliance.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.compliance.exception.ApigwException;
import com.att.sapmp.apigw.compliance.util.CommonDefs;

@Component
public class InstallAppHandoffProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InstallAppHandoffProcessor.class);

	public final void execute(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		String billingId = (String) (headers.get(CommonDefs.EMM_ACCOUNT_ID));
		String emmDeviceId = (String) (headers.get(CommonDefs.EMM_DEVICE_ID));

		Map<String, String> installAppHandoffMap = new HashMap<>();
		installAppHandoffMap.put(CommonDefs.EMM_ACCOUNT_ID, billingId);
		installAppHandoffMap.put(CommonDefs.EMM_DEVICE_ID, emmDeviceId);

		VelocityContext velocityContext = new VelocityContext(installAppHandoffMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	public final void handleResponse(Exchange e) throws ApigwException {

		log.info("handleResponse: Invocation to installApp completed");

	}
}