package com.att.sapmp.apigw.compliance.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.compliance.exception.ApigwException;
import com.att.sapmp.apigw.compliance.util.CommonDefs;

public class APNHandoffProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(APNHandoffProcessor.class);

	public final void execute(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		Map<String, String> apnHandoffMap = new HashMap<>();
		apnHandoffMap.put(CommonDefs.EMM_DEVICE_ID, (String) headers.get(CommonDefs.EMM_DEVICE_ID));
		apnHandoffMap.put(CommonDefs.IMEI, (String) headers.get(CommonDefs.IMEI));
		apnHandoffMap.put(CommonDefs.ACTION_TYPE, (String) headers.get(CommonDefs.ACTION_TYPE));
		VelocityContext velocityContext = new VelocityContext(apnHandoffMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	public final void handleResponse(Exchange e) throws ApigwException {
		log.info("handleResponse: handoff to APN completed");

	}

}
