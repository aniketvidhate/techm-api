package com.att.sapmp.apigw.compliance.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.nsa.mr.client.MRClientFactory;
import com.att.nsa.mr.client.MRConsumer;
import com.att.sapmp.apigw.compliance.exception.ApigwException;
import com.att.sapmp.apigw.compliance.exception.CErrorDefs;
import com.att.sapmp.apigw.compliance.util.CommonDefs;
import com.att.sapmp.apigw.compliance.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author av0041
 *
 */
@Component
public class ComplianceNotificationProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ComplianceNotificationProcessor.class);

	@Value("${dme2.compliance.consumerPropertiesPath}")
	private String consumerPropertiesPath;

	@Autowired
	CommonUtil commonUtil;

	public final void execute(Exchange e, @Headers Map<String, Object> headers) throws Exception {

		final MRConsumer mdmNotificationConsumer = MRClientFactory.createConsumer(consumerPropertiesPath);
		List<String> mdmNotificationList = new ArrayList<>();
		for (String mdmNotification : mdmNotificationConsumer.fetch()) {
			mdmNotificationList.add(mdmNotification);
		}
		headers.put(CommonDefs.MDM_NOTIFICATION_LIST, mdmNotificationList);
	}

	public final void processEachMdmNotification(Exchange e, @Headers Map<String, Object> headers) throws Exception {
		String mdmNotification = (String) e.getIn().getBody();
		log.info("mdmNotification in processEachMdmNotification method:\n" + mdmNotification);
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> complianceMap = objectMapper.readValue(mdmNotification, HashMap.class);

		if (complianceMap != null && !complianceMap.isEmpty()) {
			Map<String, Object> mdmNotificationMap = (Map<String, Object>) complianceMap.get(CommonDefs.MDM_NOTIFICATION);
			commonUtil.validateMap(mdmNotificationMap, CommonDefs.MDM_NOTIFICATION_MANDATORY_FIELDS);
			Map<String, Object> deviceEventListMap = (Map<String, Object>) mdmNotificationMap.get(CommonDefs.DEVICE_EVENT_LIST);
			if(deviceEventListMap == null || deviceEventListMap.isEmpty()) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CommonDefs.DEVICE_EVENT_LIST + " needs to be populated in the input.");
			}
			List<Object> deviceEventList = (List<Object>) deviceEventListMap.get(CommonDefs.DEVICE_EVENT);
			headers.put(CommonDefs.DEVICE_EVENT_LIST, deviceEventList);
			String transactionId = String.valueOf(mdmNotificationMap.get(CommonDefs.MDM_NOTIFICATION_TRANSACTION_ID));
			headers.put(CommonDefs.TRACKING_ID, transactionId);
		}
	}

	public final void processEachDeviceEvent(Exchange e, @Headers Map<String, Object> headers) throws Exception {

		log.info("DeviceEvent received in processEachDeviceEvent method:\n" + e.getIn().getBody());
		String trackingId = (String) headers.get(CommonDefs.TRACKING_ID);

		Map<String, Object> deviceEventMap = (Map<String, Object>) e.getIn().getBody();
		commonUtil.validateMap(deviceEventMap, CommonDefs.MDM_DEVICE_EVENT_MANDATORY_FIELDS);
		String eventSubType = String.valueOf(deviceEventMap.get(CommonDefs.EVENT_SUB_TYPE));
		String billingId = String.valueOf(deviceEventMap.get(CommonDefs.EMM_ACCOUNT_ID));
		String emmDeviceId = String.valueOf(deviceEventMap.get(CommonDefs.EMM_DEVICE_ID));
		String imei = String.valueOf(deviceEventMap.get(CommonDefs.IMEI_ESN));
		String policyComplianceStatus = String.valueOf(deviceEventMap.get(CommonDefs.POLICY_COMPLAINCE_STATUS));
		String complianceStatusReason = String.valueOf(deviceEventMap.get(CommonDefs.OOC_REASON));
		String actionType = CommonDefs.ACTION_TYPE_NO_ACTION;
		Map<String, String> updateDeviceDetailsMap = new HashMap<String, String>();
		updateDeviceDetailsMap.put(CommonDefs.MODE, CommonDefs.MODE_UPDATE);
		updateDeviceDetailsMap.put(CommonDefs.IMEI, imei);
		updateDeviceDetailsMap.put(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
		headers.put(CommonDefs.INSTALL_APP, CommonDefs.N);
		if (CommonDefs.EVENT_SUB_TYPE_SYNC_COMPLIANCE.equals(eventSubType)) {
			commonUtil.validateMap(deviceEventMap, CommonDefs.MDM_DEVICE_EVENT_SYNC_COMPLIANCE_MANDATORY_FIELDS);
			if (CommonDefs.IN_COMPLIANCE.equals(policyComplianceStatus)) {
				actionType = CommonDefs.ACTION_TYPE_REMOVE;
				updateDeviceDetailsMap.put(CommonDefs.COMPLIANCE_STATUS_REASON, CommonDefs.COMPLIANCE_STATUS_REASON_EMPTY);
				updateDeviceDetailsMap.put(CommonDefs.COMPLAINCE_STATUS, CommonDefs.IN_COMPLIANCE);
				updateDeviceActivityLog(updateDeviceDetailsMap, deviceEventMap, trackingId, CommonDefs.ACTIVITY_TYPE.COMPLIANCE, CommonDefs.ACTIVITY_CATEGORY.COMPLIANCE_SYNCOMPLIANCE, CommonDefs.ACTIVITY_DETAILS_NOTES_COMPLIANCE);
			} else if (CommonDefs.OUT_OF_COMPLIANCE.equals(policyComplianceStatus)) {
				commonUtil.validateMap(deviceEventMap, CommonDefs.MDM_DEVICE_EVENT_SYNC_COMPLIANCE_OUT_OF_COMPLIANCE_MANDATORY_FIELDS);				
				actionType = CommonDefs.ACTION_TYPE_APPLY;
				updateDeviceDetailsMap.put(CommonDefs.COMPLIANCE_STATUS_REASON, complianceStatusReason);
				updateDeviceDetailsMap.put(CommonDefs.COMPLAINCE_STATUS, CommonDefs.OUT_OF_COMPLIANCE);
				updateDeviceActivityLog(updateDeviceDetailsMap, deviceEventMap, trackingId, CommonDefs.ACTIVITY_TYPE.NON_COMPLIANCE, CommonDefs.ACTIVITY_CATEGORY.COMPLIANCE_SYNCOMPLIANCE, CommonDefs.ACTIVITY_DETAILS_NOTES_NON_COMPLIANCE);
			} else {
				updateDeviceActivityLog(updateDeviceDetailsMap, deviceEventMap, trackingId, CommonDefs.ACTIVITY_TYPE.OTHER, CommonDefs.ACTIVITY_CATEGORY.COMPLIANCE_SYNCOMPLIANCE, CommonDefs.ACTIVITY_DETAILS_NOTES_SYNC_COMPLIANCE_OTHER);
			}
		} else if (CommonDefs.EVENT_SUB_TYPE_SYNC_DEVICE_STATE.equals(eventSubType)) {
			commonUtil.validateMap(deviceEventMap, CommonDefs.MDM_DEVICE_EVENT_SYNC_DEVICE_STATE_MANDATORY_FIELDS);
			String deviceStatus = String.valueOf(deviceEventMap.get(CommonDefs.MDM_DEVICE_STATUS));
			if( !EnumUtils.isValidEnum(CommonDefs.DEVICE_STATUS.class,deviceStatus)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.MDM_DEVICE_STATUS + " needs to be populated with correct value.");
			}			
			String deviceSubStatus = String.valueOf(deviceEventMap.get(CommonDefs.MDM_DEVICE_SUB_STATUS));
			if( !EnumUtils.isValidEnum(CommonDefs.DEVICE_SUB_STATUS.class,deviceSubStatus)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.MDM_DEVICE_SUB_STATUS + " needs to be populated with correct value.");
			}				
			if (CommonDefs.DEVICE_STATUS.ACTIVE.toString().equals(deviceStatus) && CommonDefs.DEVICE_SUB_STATUS.ENROLLED.toString().equals(deviceSubStatus)) {
				updateDeviceRecord(updateDeviceDetailsMap, CommonDefs.STATUS_ENROLLMENT.ENROLLMENT_SUCCESS, CommonDefs.SUB_STATUS.ACTIVE_DEVICE);
				updateDeviceActivityLog(updateDeviceDetailsMap, deviceEventMap, trackingId, CommonDefs.ACTIVITY_TYPE.ENROLL, CommonDefs.ACTIVITY_CATEGORY.COMPLIANCE_SYNCDEVICE, CommonDefs.ACTIVITY_DETAILS_NOTES_ENROLLMENT_SUCCESS_EVENT);
				headers.put(CommonDefs.INSTALL_APP, CommonDefs.Y);
				headers.put(CommonDefs.EMM_ACCOUNT_ID, billingId);
				actionType = CommonDefs.ACTION_TYPE_REMOVE;
			} else if (CommonDefs.DEVICE_STATUS.INACTIVE.toString().equals(deviceStatus) && CommonDefs.DEVICE_SUB_STATUS.INACTIVE.toString().equals(deviceSubStatus)) {
				actionType = CommonDefs.ACTION_TYPE_REMOVE;
				updateDeviceRecord(updateDeviceDetailsMap, CommonDefs.STATUS_ENROLLMENT.DEENROLLMENT_SUCCESS, CommonDefs.SUB_STATUS.INACTIVE_DEVICE);
				updateDeviceActivityLog(updateDeviceDetailsMap, deviceEventMap, trackingId, CommonDefs.ACTIVITY_TYPE.DEENROLL, CommonDefs.ACTIVITY_CATEGORY.COMPLIANCE_SYNCDEVICE, CommonDefs.ACTIVITY_DETAILS_NOTES_DEENROLLMENT_SUCCESS_EVENT);
			} else if (CommonDefs.DEVICE_STATUS.INACTIVE.toString().equals(deviceStatus) && CommonDefs.DEVICE_SUB_STATUS.CONTROL_REMOVED.toString().equals(deviceSubStatus)) {
				updateDeviceRecord(updateDeviceDetailsMap, CommonDefs.STATUS_ENROLLMENT.DEENROLLMENT_SUCCESS, CommonDefs.SUB_STATUS.ADMIN_REMOVED_MDM);
				updateDeviceActivityLog(updateDeviceDetailsMap, deviceEventMap, trackingId, CommonDefs.ACTIVITY_TYPE.DEENROLL, CommonDefs.ACTIVITY_CATEGORY.COMPLIANCE_SYNCDEVICE, CommonDefs.ACTIVITY_DETAILS_NOTES_ADMIN_REMOVED_MDM_SUCCESS_EVENT);
			} else if (CommonDefs.DEVICE_SUB_STATUS.PENDING_CONTROL_REMOVAL.toString().equals(deviceSubStatus)) {
				updateDeviceRecord(updateDeviceDetailsMap, null, CommonDefs.SUB_STATUS.PENDING_CONTROL_REMOVAL);
				updateDeviceActivityLog(updateDeviceDetailsMap, deviceEventMap, trackingId, CommonDefs.ACTIVITY_TYPE.DEENROLL, CommonDefs.ACTIVITY_CATEGORY.COMPLIANCE_SYNCDEVICE,
						CommonDefs.ACTIVITY_DETAILS_NOTES_PENDING_CONTROL_REMOVAL_SUCCESS_EVENT);
			} else if (CommonDefs.DEVICE_SUB_STATUS.USER_REMOVED_CONTROL.toString().equals(deviceSubStatus)) {
				updateDeviceRecord(updateDeviceDetailsMap, null, CommonDefs.SUB_STATUS.USER_REMOVED_MDM);
				updateDeviceActivityLog(updateDeviceDetailsMap, deviceEventMap, trackingId, CommonDefs.ACTIVITY_TYPE.OTHER, CommonDefs.ACTIVITY_CATEGORY.COMPLIANCE_SYNCDEVICE, CommonDefs.ACTIVITY_DETAILS_NOTES_USER_REMOVED_MDM_SUCCESS_EVENT);
			} else {
				updateDeviceActivityLog(updateDeviceDetailsMap, deviceEventMap, trackingId, CommonDefs.ACTIVITY_TYPE.OTHER, CommonDefs.ACTIVITY_CATEGORY.COMPLIANCE_SYNCDEVICE, CommonDefs.ACTIVITY_DETAILS_NOTES_SYNC_DEVICE_OTHER);

			}
		}
		// Setting up values to call apply remove apn api
		headers.put(CommonDefs.EMM_ACCOUNT_ID, billingId);
		headers.put(CommonDefs.IMEI, imei);
		headers.put(CommonDefs.ACTION_TYPE, actionType);
		headers.put(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
		headers.put(CommonDefs.EVENT_SUB_TYPE, eventSubType);

		JSONObject requestbody = new JSONObject(updateDeviceDetailsMap);
		e.getIn().setBody(requestbody);
	}

	private void updateDeviceRecord(Map<String, String> updateDeviceDetailsMap, Enum status, Enum subStatus) {
		if (status != null) {
			updateDeviceDetailsMap.put(CommonDefs.ENROLLMENT_STATUS, status.toString());
		}
		updateDeviceDetailsMap.put(CommonDefs.ENROLLMENT_SUB_STATUS, subStatus.toString());
	}

	private void updateDeviceActivityLog(Map<String, String> updateDeviceDetailsMap, Map<String, Object> map, String trackingId, Enum activityType, Enum activityCategory, String activityDetails) {
		Map<String, Object> activityMap = new HashMap<>();
		activityMap.put(CommonDefs.ACTIVITY_DETAILS_NOTES, activityDetails);
		activityMap.put(CommonDefs.ACTIVITY_DETAILS_MDM_TRANSACTION_ID, trackingId);
		activityMap.put(CommonDefs.ACTIVITY_DETAILS_DEVICE_EVENT, map);

		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityCategory.toString(), activityCategory.toString());
		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityType.toString(), activityType.toString());
		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityDetails.toString(), StringEscapeUtils.escapeXml(activityMap.toString()));
		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.source.toString(), CommonDefs.SOURCE_SAPMP_GW);
		updateDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityDate.toString(), CommonUtil.getGMTdatetimeAsString());
	}
}