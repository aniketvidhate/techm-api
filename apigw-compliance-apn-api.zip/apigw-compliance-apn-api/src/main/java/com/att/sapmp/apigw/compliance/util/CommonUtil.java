package com.att.sapmp.apigw.compliance.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.compliance.exception.ApigwException;
import com.att.sapmp.apigw.compliance.exception.CErrorDefs;

/**
 * This Class is used by APIGW application to provide utility methods.
 * 
 * @author PG238S
 *
 */

@Component
public class CommonUtil {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CommonUtil.class);

	public static final String DATEFORMAT = "yyyy-MM-dd'T'hh:mm:ss.'000Z'";
	@Autowired
	private Environment env;

	@Value("${product.code}")
	private String stProduct;

	@Value("${csi.user}")
	private String userName;

	@Value("${csi.password}")
	private String userPassword;

	@Value("${csi.version}")
	private String version;

	@Value("${csi.messageId}")
	private String messageId;

	@Value("${csi.sequenceNumber}")
	private String sequenceNumber;

	@Value("${csi.totalInSequence}")
	private String totalInSequence;

	@Value("${csi.timeToLive}")
	private String timeToLive;

	@Value("${csi.applicationName}")
	private String applicationName;

	@Value("${csi.infrastructureVersion}")
	private String infrastructureVersion;
	
	@Value("${log.masking.field}")
	private String logMaskingFields;

	/**
	 * Validate if input productCode is valid or not return corresponding
	 * boolean value.
	 *
	 * @param String
	 *            productCode.
	 * @return boolean value.
	 */
	public boolean isProductCodeValid(String inProductCode) {
		boolean bValid = false;
		// String stProduct = null;
		if (stProduct != null) {
			List<String> alList = Arrays.asList(stProduct.split("\\|"));
			if (inProductCode != null && alList.contains(inProductCode.toLowerCase())) {
				bValid = true;
			}
		}
		return bValid;

	}

	public List<String> getAsArrayList(String inValue) {
		List<String> alResponse = new ArrayList<>();
		if (!StringUtils.isEmpty(inValue)) {
			alResponse.add(inValue);
		}
		return alResponse;

	}

	public static String getGMTdatetimeAsString() {
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}

	public String getProperty(final String propKey) {
		String propValue = null;
		if (!StringUtils.isEmpty(propKey)) {
			propValue = env.getProperty(propKey.toLowerCase());
		}
		return propValue;
	}

	public void validateMap(Map<String, Object> map, String[] requiredParamList) throws ApigwException {
		for (String requiredParam : requiredParamList) {
			if (!map.containsKey(requiredParam)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, requiredParam + " is a required parameter in the input.");
			}
			if (map.get(requiredParam) instanceof List) {
				List<String> paramVal = (ArrayList<String>) map.get(requiredParam);
				for (String paramList : paramVal) {
					if (StringUtils.isEmpty(paramList)) {
						throw new ApigwException(CErrorDefs.ERROR_CODE_1002, requiredParam + " needs to be populated in the input.");
					}
				}
			} else {
				String paramValue = (String) map.get(requiredParam);
				if (StringUtils.isEmpty(paramValue)) {
					throw new ApigwException(CErrorDefs.ERROR_CODE_1002, requiredParam + " needs to be populated in the input.");
				}
			}

		}
	}

	public void validateJSON(JSONObject postReqJSON, String[] requiredParamList) throws ApigwException {
		for (String requiredParam : requiredParamList) {
			if (!postReqJSON.has(requiredParam)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, requiredParam + " is a required parameter in the input.");
			}
			String paramValue = (String) postReqJSON.get(requiredParam);
			if (StringUtils.isEmpty(paramValue)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, requiredParam + " needs to be populated in the input.");
			}

		}
	}

	public void populateCSIHeader(Map<String, Object> requestMap) {
		requestMap.put(CommonDefs.INFRASTRUCTURE_VERSION, infrastructureVersion);
		requestMap.put(CommonDefs.APPLICATION_NAME, applicationName);
		requestMap.put(CommonDefs.VERSION_NO, version);
		requestMap.put(CommonDefs.MESSAGE_ID, messageId);
		requestMap.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
		requestMap.put(CommonDefs.USER_NAME, userName);
		requestMap.put(CommonDefs.USER_PASSWORD, userPassword);
		requestMap.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
		requestMap.put(CommonDefs.TOTAL_IN_SEQUENCE, totalInSequence);
		requestMap.put(CommonDefs.TIME_TO_LIVE, timeToLive);
	}
	
	public void logXML(String description, String logMessage) {
		log.info(description + ":" + maskingPayload("XML", logMessage));
	}
	
	private String maskingPayload(String logType, String payload) {
		if (logMaskingFields != null && logMaskingFields.length() > 0) {
			String[] maskingArray = logMaskingFields.split(",");
			for (String field : maskingArray) {
				field = field.trim();
				if (payload.contains(field)) {
					int fieldIndex = payload.indexOf(field) + field.length();
					String fieldValue = "";
					if (logType.equalsIgnoreCase("XML")) {
						int endIndex = payload.indexOf("<", fieldIndex);
						fieldValue = payload.substring(fieldIndex + 1, endIndex);
					} else if (logType.equalsIgnoreCase("JSON")) {
						int endIndex = payload.indexOf(",", fieldIndex);
						if (endIndex > 0) {
							fieldValue = payload.substring(fieldIndex, endIndex);
						} else {
							fieldValue = payload.substring(fieldIndex, payload.indexOf("}"));
						}
						fieldValue = fieldValue.replaceAll("\"", "").replaceAll(":", "").trim();
					}
					payload = payload.replace(fieldValue, "********");
				}
			}
		}
		return payload;
	}

}
