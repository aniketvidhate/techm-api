package com.att.sapmp.apigw.compliance.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Headers;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.compliance.exception.ApigwException;
import com.att.sapmp.apigw.compliance.exception.CErrorDefs;
import com.att.sapmp.apigw.compliance.util.CommonDefs;
import com.att.sapmp.apigw.compliance.util.CommonUtil;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

@Component
public class CSIInquireEnterpriseDeviceDeploymentProfileProcessor {

	private Logger log = LoggerFactory.getLogger(CSIInquireEnterpriseDeviceDeploymentProfileProcessor.class);

	@Autowired
	CommonUtil commonUtil;

	public final void execute(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		HashMap<String, Object> inquireAccountRequstMap = new HashMap<>();
		inquireAccountRequstMap.put(CommonDefs.EMM_ACCOUNT_ID, (String) headers.get(CommonDefs.EMM_ACCOUNT_ID));
		commonUtil.populateCSIHeader(inquireAccountRequstMap);
		VelocityContext velocityContext = new VelocityContext(inquireAccountRequstMap);
		headers.put(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	public final void handleResponse(Exchange e, @Headers Map<String, Object> headers) throws ApigwException {
		String csiResposeBody = (String) e.getIn().getBody();
		//log.info("Response received in handleResponse:\n" + csiResposeBody);
		commonUtil.logXML("Received response in handleResponse method", csiResposeBody);

		XmlMapper xmlMapper = new XmlMapper();
		Map<String, Object> csiResponseMap = null;
		try {
			csiResponseMap = xmlMapper.readValue(csiResposeBody, HashMap.class);

		} catch (IOException ioe) {
			log.debug("Exception occurred while parsing post request: " + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		Map<String, Object> responseBodyMap = (HashMap<String, Object>) csiResponseMap.get(CommonDefs.BODY);

		if (responseBodyMap != null && !(responseBodyMap.isEmpty())) {
			Map<String, Object> inquireEnterpriseDetailsResponseMap = (HashMap<String, Object>) responseBodyMap.get(CommonDefs.IEDDP_RESPONSE);
			if (inquireEnterpriseDetailsResponseMap != null && !(inquireEnterpriseDetailsResponseMap.isEmpty())) {
				Map<String, Object> deviceDeploymentProfileMap = (HashMap<String, Object>) inquireEnterpriseDetailsResponseMap.get(CommonDefs.DEVICE_DEPLOYMENT_PROFILE);

				if (deviceDeploymentProfileMap != null && !(deviceDeploymentProfileMap.isEmpty())) {

					Map<String, Object> addpAccountDetailsMap = (HashMap<String, Object>) deviceDeploymentProfileMap.get(CommonDefs.ADDPT_TENANT_ACCOUNT_DETAILS);

					if (addpAccountDetailsMap != null && !(addpAccountDetailsMap.isEmpty())) {
						String accountPassphrase = (String) addpAccountDetailsMap.get(CommonDefs.ACCOUNT_PASS_PHRASE_IEDDP);
						String emmProductCode = (String) addpAccountDetailsMap.get(CommonDefs.EMM_PRODUCT_CODE_IEDDP);
						headers.put(CommonDefs.ACCOUNT_PASS_PHRASE, accountPassphrase);
						headers.put(CommonDefs.EMM_PRODUCT_CODE, emmProductCode);
					}

				}
			}
			headers.put(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
		}
	}
}