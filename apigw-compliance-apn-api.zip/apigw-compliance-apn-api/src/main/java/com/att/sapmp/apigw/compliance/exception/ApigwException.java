package com.att.sapmp.apigw.compliance.exception;


/**
 * This Class is used by APIGW application to return the checked exception.
 * Application specific errorCode and errorMsg can be set and returned to caller
 * application.
 * 
 * @author PG238S
 *
 */
public class ApigwException extends Exception {

	private String errorMsg;
	private String errorCode;
		
	public ApigwException() {
		super();
	}

	public ApigwException(String msg) {
		super(msg);
	}


	public ApigwException(String msg, Exception exp) {
		super(msg, exp);
	}

	

	public ApigwException(String errorCode, String errorMsg) {
		super(errorMsg);
		this.errorMsg = errorMsg;
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}


	public String getErrorMsg() {
		return errorMsg;
	}

}
