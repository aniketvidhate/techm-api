package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;

@Component
public class CSIManageEnterpriseDeviceDeploymentProfileProcessor {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CSIManageEnterpriseDeviceDeploymentProfileProcessor.class);
	

	@Autowired
	private CommonUtil commonUtil;	
	
	
	public final void prepareCdfRequest(Exchange e) throws ApigwException {
		
		String deEnrollmentCompleted = (String) e.getProperty(CommonDefs.DEENROLLMENT_COMPLETED);
		String deEnrollmentRequired = (String) e.getProperty(CommonDefs.DEVICE_DEENROLL_REQUIRED);
		
		HashMap<String, Object> cdfUpdateMap = new HashMap<>();
		commonUtil.populateCSIHeader(cdfUpdateMap);
		cdfUpdateMap.put(CommonDefs.TENANT_ACCOUNT_ID, e.getProperty(CommonDefs.TENANT_ACCOUNT_ID));		
		if ((deEnrollmentRequired == null || deEnrollmentRequired.equalsIgnoreCase(CommonDefs.Y))
				&& (deEnrollmentCompleted == null || !deEnrollmentCompleted.equalsIgnoreCase(CommonDefs.Y))) {
			cdfUpdateMap.put(CommonDefs.ACCOUNT_STATUS, CommonDefs.REMOVE_FAILED);
		}else{
			cdfUpdateMap.put(CommonDefs.ACCOUNT_STATUS, CommonDefs.INACTIVE);
		}

		cdfUpdateMap.put(CommonDefs.MESSAGE_ID, e.getIn().getHeader(CommonDefs.TRACKING_ID));
		
		VelocityContext velocityContext = new VelocityContext(cdfUpdateMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		
	}
	
	public final void handleCdfResponse(Exchange e) throws ApigwException {	
		String respBody = e.getIn().getBody(String.class);
		log.info("Received Response in handleCdfResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));	
		commonUtil.logXML("Received response in handleCdfResponse method", respBody);
		
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		
	}

}
