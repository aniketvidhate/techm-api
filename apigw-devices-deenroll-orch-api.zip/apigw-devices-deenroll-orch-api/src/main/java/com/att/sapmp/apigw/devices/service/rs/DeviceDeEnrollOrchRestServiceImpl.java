package com.att.sapmp.apigw.devices.service.rs;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.model.DeEnrollDevice;

import io.swagger.annotations.ApiParam;

public class DeviceDeEnrollOrchRestServiceImpl implements DeviceDeEnrollOrchRestService {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceDeEnrollOrchRestServiceImpl.class);
	
	public DeviceDeEnrollOrchRestServiceImpl() {
		// needed for autowiring
	}

	@POST
	@Override
	public void deEnrolledDevices(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@ApiParam(value = "De-Enroll Device Request Object", required = true) @RequestBody DeEnrollDevice enrollDevice){
		
		log.info("Received request in DeviceDeEnrollmentRestService API.");

	}

}
