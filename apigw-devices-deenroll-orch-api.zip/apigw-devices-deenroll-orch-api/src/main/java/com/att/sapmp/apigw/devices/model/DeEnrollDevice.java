package com.att.sapmp.apigw.devices.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@ApiModel(value = "DeEnrollDevice", description = " input payload")
public  class DeEnrollDevice {
	
	private String emmAccountId;
    private String[] deviceIds;
    
	public DeEnrollDevice(@JsonProperty("emmAccountId") String emmAccountId, @JsonProperty("deviceIds") String[] deviceIds){
        this.emmAccountId = emmAccountId;
        this.deviceIds = deviceIds;
    }
	
    public void setEmmAccountId(String emmAccountId) {
		this.emmAccountId = emmAccountId;
	}


	public void setDeviceIds(String[] deviceIds) {
		this.deviceIds = deviceIds.clone() ;
	}

    @ApiModelProperty(value = "EmmAccountId", example = "30058930")
    public String getEmmAccountId() {
		return emmAccountId;
	}

    @ApiModelProperty(value = "deviceIds")
	public String[] getDeviceIds() {
		return deviceIds.clone();
	}

}