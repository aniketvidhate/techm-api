package com.att.sapmp.apigw.devices.service;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.util.CommonDefs;

public class JoinReplyAggregationStrategy implements AggregationStrategy {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(JoinReplyAggregationStrategy.class);
	
	@Override
    public Exchange aggregate(Exchange exchange1, Exchange exchange2) {
        if (exchange1 == null) {
            return exchange2;
        } else {
            String body1 = exchange1.getIn().getBody(String.class);
            String body2 = exchange2.getIn().getBody(String.class);      
            String merged = (body1 == null) ? body2 : body1 + " " + body2;
            if(merged != null && !merged.trim().isEmpty()){
            	log.info("Consolidated response after split processing = " + merged);	
            }
            exchange1.getIn().setBody("");
            exchange1.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
            return exchange1;
        }
    }

}
