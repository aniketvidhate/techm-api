package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;

@Component
public class CSIManageEnterpriseDeviceDeploymentDetailsProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CSIManageEnterpriseDeviceDeploymentDetailsProcessor.class);
	
	@Autowired
	private CommonUtil commonUtil;	
	
	
	public final void execute(Exchange e) throws ApigwException {
				
		HashMap<String, Object> csiManageDeviceDetailsMap = new HashMap<>();

		csiManageDeviceDetailsMap.put(CommonDefs.MESSAGE_ID, String.valueOf(e.getProperty(CommonDefs.TRACKING_ID)));
		commonUtil.populateCSIHeader(csiManageDeviceDetailsMap);
		
		csiManageDeviceDetailsMap.put(CommonDefs.EMM_DEVICE_ID, e.getProperty(CommonDefs.EMM_DEVICE_ID));
		
		csiManageDeviceDetailsMap.put(CommonDefs.ENROLLMENT_STATUS, e.getProperty(CommonDefs.ENROLLMENT_STATUS));
		csiManageDeviceDetailsMap.put(CommonDefs.ENROLLMENT_SUB_STATUS, e.getProperty(CommonDefs.ENROLLMENT_SUB_STATUS));
		
		// Inserting the Device Logs
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityType.toString(), CommonDefs.ACTIVITY_TYPE_DEENROLL);
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityCategory.toString(), CommonDefs.ACTIVITY_CATEGORY_ENROLLMENT);
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityDetails.toString(),e.getProperty(CommonDefs.ENROLLMENT_SUB_STATUS));
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.source.toString(), CommonDefs.SAPMP_GW);
		csiManageDeviceDetailsMap.put(CommonDefs.CSI_ACTIVITY_LOG.activityDate.toString(), CommonUtil.getGMTdatetimeAsString());
			
		VelocityContext velocityContext = new VelocityContext(csiManageDeviceDetailsMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		
	}

	public final void handleCsiManageDeviceDetailResponse(Exchange e) throws ApigwException {
		String body = e.getIn().getBody(String.class);	
		log.info("Received Response in handleCsiManageDeviceDetailResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		
		commonUtil.logXML("Received response in handleCsiManageDeviceDetailResponse method", body);
		
		Map<String, String> bodyMap = new HashMap<>();
		bodyMap.put(CommonDefs.DEVICE_ID, String.valueOf(e.getProperty(CommonDefs.DEVICE_ID)));
		bodyMap.put(CommonDefs.IMEI, String.valueOf(e.getProperty(CommonDefs.IMEI)));

		VelocityContext velocityContext = new VelocityContext(bodyMap);

		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		e.getIn().setBody("");

		log.info("End handleCsiManageDeviceDetailResponse");

	}

	
}