package com.att.sapmp.apigw.devices.util;

public class CommonDefs {

	private CommonDefs() {
		super();
	}

	public static final String BILLING_ID = "billingId";
	public static final String ACCOUNT_PASS_PHRASE = "AccountPassPhrase";
	public static final String USER_NAME = "userName";
	public static final String PARTNER_ACCOUNT = "partnerAccount";
	public static final String[] NON_ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductcode",
			"accountpassphrase" };
	public static final String[] ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductCode" };

	public static final String SEARCH_CRITERIA = "searchcriteria";
	public static final String EMM_ACCOUNT_ID = "emmAccountId";
	public static final String DEVICE_LIST = "deviceList";
	public static final String DEVICE_IDS = "deviceIds";
	public static final String DEVICE_ID = "deviceId";

	public static final String SPACE_EXPR = "\\s+";
	public static final String BLANK_CHAR = "%20";

	public static final int MAX_NO_OF_DEVICES = 100;
	public static final String ACCOUNT = "account";
	public static final String ACCOUNTS = "accounts";
	public static final String ACCOUNT_STATUS = "accountStatus";

	public static final String CAMEL_HTTP_RESPONSE_CODE = "CamelHttpResponseCode";
	public static final String CAMEL_HTTP_URL = "CamelHttpUrl";
	public static final String EMM_PRODUCT_CODE = "emmproductcode";
	public static final String TRACKING_ID = "trackingid";
	public static final String DEENROLL_ORCH_URL = "deenroll.device.url";
	public static final String DEENROLL_IBMURL = "IBMUrl_DE_ENROLL";
	public static final String DEVICE = "device";
	public static final String DEVICES = "devices";
	public static final String[] DEVICE_DEENROLL_MANDATORY_FIELDS = { CommonDefs.EMM_ACCOUNT_ID,
			CommonDefs.DEVICE_IDS };
	public static final String RESPONSE_ACCEPT_CODE = "202";

	public static final String MASS_360_DEVICE_ID = "maas360DeviceID";
	public static final String ACTION_STATUS = "actionStatus";
	public static final String ZERO = "0";

	public static final String INACTIVE = "INACTIVE";
	public static final String DEENROLLMENT_SUCCESS = "DeEnrollmentSuccess";
	public static final String DEENROLLMENT_SUCCESS_CDF = "DEENROLLMENT_SUCCESS";
	public static final String PROFILE_ID = "profileId";
	public static final String Y = "Y";
	public static final String N = "N";
	public static final String EMM_DEVICE_ID = "emmDeviceId";

	public static final String DESCRIPTION = "description";

	public static final String PRODUCT_CODE = "productCode";
	public static final String EMMP_PRODUCT_CODE = "EMMProductCode";
	public static final String ERROR_CODE_STR = "errorCode";
	public static final String MESSAGE = "message";
	public static final String AUTHORIZATION = "Authorization";

	public static final String IMEI = "imei";
	public static final String BAN = "ban";
	public static final String FAN = "fan";
	public static final String CTN = "ctn";

	// Added for manageAPN
	public static final String RESPONSE_SUCCESS_CODE = "200";
	public static final String MANAGE_APN_URL = "manageAPNUrl";
	public static final String MANAGE_APN = "manageAPN";
	public static final String ACTION_TYPE_APPLY = "Apply";
	public static final String ACTION_TYPE_REMOVE = "Remove";
	public static final String DEVICE_APN_STATUS = "deviceApnStatus";
	public static final String APNSTATUS = "apnStatus";
	public static final String SUCCESS_CODE = "Success";
	public static final String SUCCESS_CODE_YES = "Yes";

	// Added for the CSI integration - Manage ADDP Device Details
	public static final String INFRASTRUCTURE_VERSION = "infrastructureVersion";
	public static final String APPLICATION_NAME = "applicationName";
	public static final String VERSION = "version";
	public static final String VERSION_NO = "versionNo";
	public static final String MESSAGE_ID = "messageId";
	public static final String DATE_TIMESTAMP = "dateTimeStamp";
	public static final String SEQUENCE_NUMBER = "sequenceNumber";
	public static final String TOTAL_IN_SEQUENCE = "totalInSequence";
	public static final String MODE = "mode";
	public static final String ENROLLMENT_STATUS = "enrollmentStatus";
	public static final String ACTIVITY_CATEGORY_ENROLLMENT = "ENROLLMENT";
	public static final String ACTIVITY_TYPE_DEENROLL = "DEENROLL";
	public static final String SAPMP_GW = "SAPMP-GW";
	public static final String ENROLLMENT_SUB_STATUS = "enrollmentSubStatus";
	public static final String DEENROLLMENT_INITIATED = "DEENROLLMENT_INITIATED";
	public static final String DEENROLLMENT_FAILED = "DEENROLLMENT_FAILED";
	public static final String DEENROLLMENT_COMPLETED = "deenrollCompleted";
	public static final String MDM_DEENROLLMENT_PENDING = "MDM_DEENROLLMENT_PENDING";
	public static final String MDM_DEENROLLMENT_FAILED = "MDM_DEENROLLMENT_FAILED";
	public static final String ONE = "1";
	public static final String MDM_DEACTIVATION_PENDING = "MDM_DEACTIVATION_PENDING";
	public static final String REMOVE_TRACKING_SOC_FAILED = "REMOVE_TRACKING_SOC_FAILED";

	// Added for the CSI integration - Inquire ADDP Device Detail
	public static final String CUSTOMER_TELEPHONE_NUMBER = "customerTelephoneNumber";

	// Added for the CSI integration - updateSubscriberProfile
	public static final String CODE = "code";
	public static final String OFFERING_CODE = "offeringCode";
	public static final String LOCATION = "location";
	public static final String ORIGINATOR_ID = "originatorId";
	public static final String CONVERSATION_ID = "conversationId";
	public static final String SALES_REPRESENTATIVE = "salesRepresentative";
	public static final String SUBSCRIBER_NUMBER = "subscriberNumber";
	public static final String EFFECTIVE_DATE = "effectiveDate";
	public static final String EXPIRATION_DATE = "expirationDate";
	public static final String TIME_TO_LIVE = "timeToLive";
	public static final String ACTION = "action";

	public static final String QUERY_PARAM = "QueryParam";
	public static final String REMOVE_FAILED = "REMOVE_FAILED";
	public static final String PARTIAL_DEVICE_NAME = "partialDeviceName";
	public static final String CSI_VERSION = "csiversion";
	public static final String TENANT_ACCOUNT_ID = "tenantAccountId";

	public static final String CAMEL_HTTP_PATH = "CamelHttpPath";
	public static final String BODY = "Body";
	public static final String ACT_TYPE = "actType";
	public static final String DEVICE_DETAIL_LIST = "DeviceDetailList";
	public static final String IEDDD_RESPONSE = "InquireEnterpriseDeviceDeploymentDetailsResponse";
	public static final String DEVICE_NET_CTRL = "deviceNetCtrl";
	public static final String APPLICATION_ID = "applicationId";
	public static final String APN_RESTRICTION = "apnRestriction";
	public static final String BACKWARD_SLASH = "/";
	public static final String DEALER_CODE = "dealerCode";
	public static final String DEVICE_LOG_ACTIVITY_FLAG = "deviceLogActivityFlag";
	public static final String INVALID_PRODUCT_CODE_MESSAGE = "Unable to Search MDM Partner with input Product Code";
	public static final String INVALID_INPUT_PAYLOAD = "Input payload  is null in input";
	public static final String MAX_NO_DEVICE_SUPPORTED = "Maximum deviceIds supported: ";
	public static final String DEVICE_ID_NULL_INPUT = "deviceId is null in input";
	public static final String ACTION_RESPONSE = "actionResponse";
	public static final String INVALID_FAN = "Fan is null in input url";
	public static final String INVALID_REQUEST_BODY = "De-Enroll Device By Fan Request is null in input";
	public static final String DEVICE_DEENROLL_REQUIRED = "deviceDeEnrollRequired";
	public static final String DEENROLLMENT_BY_FAN = "deenrollByFan";
	public static final String SEARCHCRITERIA = "searchcriteria=";

	// Device activity log Constants
	public enum CSI_ACTIVITY_LOG {
		activityCategory, activityType, activityDetails, source, activityDate
	};
	
}
