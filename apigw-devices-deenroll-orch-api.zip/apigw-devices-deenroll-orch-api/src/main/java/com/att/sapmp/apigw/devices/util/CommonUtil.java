package com.att.sapmp.apigw.devices.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.ajsc.interceptors.LoggingCamelPreInterceptor;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.ajsc.logging.json.AuditLogRecord;
import com.att.eelf.configuration.EELFLogger;


@Component
public class CommonUtil {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CommonUtil.class);

	public static final String DATEFORMAT = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'";
	
	public static final String DATEFORMAT_EFFECTIVE = "yyyy-MM-dd'Z'";
	
	@Autowired
	private Environment env;
	
	@Value("${csi.user}")
	private String userName;

	@Value("${csi.password}")
	private String userPassword;

	@Value("${csi.version}")
	private String version;

	@Value("${csi.sequenceNumber}")
	private String sequenceNumber;

	@Value("${csi.totalInSequence}")
	private String totalInSequence;
	
	@Value("${csi.timeToLive}")
	private String timeToLive;	
	
	@Value("${csi.applicationName}")
	private String applicationName;	
	
	@Value("${csi.infrastructureVersion}")
	private String infrastructureVersion;	
	
	@Value("${csi.mode}")
	private String mode;

	
	@Value("${product.code}")
	private String stProduct;
	
	@Value("${log.masking.field}")
	private String logMaskingFields;
	

	public boolean isProductCodeValid(String inProductCode) {
		boolean bValid = false;
		
		if (stProduct != null) {
			List<String> alList = Arrays.asList(stProduct.split("\\|"));
			if (inProductCode != null && alList.contains(inProductCode.toLowerCase())) {
				bValid = true;
			}
		}
		return bValid;

	}

	public List<String> getAsArrayList(String inValue) {
		List<String> alResponse = new ArrayList<String>();
		if (!StringUtils.isEmpty(inValue)) {
			alResponse.add(inValue);
		}
		return alResponse;

	}

	public static String getGMTdatetimeAsString() {
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}
	public static String getGMTDatAsString() {
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT_EFFECTIVE);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}
	
	public String getProperty(final String propKey) {
		String propValue = null;
		if (!StringUtils.isEmpty(propKey)) {
			propValue = env.getProperty(propKey.toLowerCase());
		}
		return propValue;
	}
	
	public void populateCSIHeader(HashMap<String, Object> requestMap) {
		requestMap.put(CommonDefs.INFRASTRUCTURE_VERSION, infrastructureVersion);
		requestMap.put(CommonDefs.APPLICATION_NAME, applicationName);
		requestMap.put(CommonDefs.VERSION_NO, version);
		requestMap.put(CommonDefs.DATE_TIMESTAMP, CommonUtil.getGMTdatetimeAsString());
		requestMap.put(CommonDefs.USER_NAME, userName);
		//updated for sonar violation to use password key directly
		requestMap.put("userPassword", userPassword);
		requestMap.put(CommonDefs.SEQUENCE_NUMBER, sequenceNumber);
		requestMap.put(CommonDefs.TOTAL_IN_SEQUENCE, totalInSequence);
		requestMap.put(CommonDefs.TIME_TO_LIVE, timeToLive);
		requestMap.put(CommonDefs.MODE, mode);
	}	
	
	public void logXML(String description, String logMessage) {
		log.info(description + ":" + maskingPayload("XML", logMessage));
	}
	
	private String maskingPayload(String logType, String payload) {
		if (logMaskingFields != null && logMaskingFields.length() > 0) {
			String[] maskingArray = logMaskingFields.split(",");
			for (String field : maskingArray) {
				field = field.trim();
				if (payload.contains(field)) {
					int fieldIndex = payload.indexOf(field) + field.length();
					String fieldValue = "";
					if (logType.equalsIgnoreCase("XML")) {
						int endIndex = payload.indexOf("<", fieldIndex);
						fieldValue = payload.substring(fieldIndex + 1, endIndex);
					} else if (logType.equalsIgnoreCase("JSON")) {
						int endIndex = payload.indexOf(",", fieldIndex);
						if (endIndex > 0) {
							fieldValue = payload.substring(fieldIndex, endIndex);
						} else {
							fieldValue = payload.substring(fieldIndex, payload.indexOf("}"));
						}
						fieldValue = fieldValue.replaceAll("\"", "").replaceAll(":", "").trim();
					}
					payload = payload.replace(fieldValue, "********");
				}
			}
		}
		return payload;
	}
	
	public void auditLog(Exchange exchange, String key){
		String body = exchange.getIn().getBody(String.class);
		AuditLogRecord auditRecord = (AuditLogRecord) exchange.getProperty(LoggingCamelPreInterceptor.AUDIT_LOG);
		if (body != null && !body.isEmpty()) {
			auditRecord.getAdditionalProperties().put(key, body);
		}	
	}

}
