package com.att.sapmp.apigw.devices.common;

import com.att.eelf.i18n.EELFResolvableErrorEnum;
import com.att.eelf.i18n.EELFResourceManager;

public enum LogMessages implements EELFResolvableErrorEnum {

	DEENROLL_START;

	static {

		EELFResourceManager.loadMessageBundle("logmessages");

	}

}
