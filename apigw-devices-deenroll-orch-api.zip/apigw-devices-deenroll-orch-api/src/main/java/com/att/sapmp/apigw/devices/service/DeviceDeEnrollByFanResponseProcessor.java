package com.att.sapmp.apigw.devices.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.model.Devices;
import com.att.sapmp.apigw.devices.util.CommonDefs;

/**
 * @author av0041
 *
 */
@Component
public class DeviceDeEnrollByFanResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceDeEnrollByFanResponseProcessor.class);

	public final void handleInquireDeviceResponse(Exchange e) throws ApigwException {
		Devices devicesBody = (Devices) e.getIn().getBody();
		Object devicesResponse = devicesBody.getDevices().get(CommonDefs.DEVICE);

		ArrayList<String> deviceList = new ArrayList<>();
		if (devicesResponse instanceof ArrayList) {
			ArrayList<HashMap> devicesResponseList = (ArrayList<HashMap>) devicesResponse;
			for (HashMap<String, Object> deviceMap : devicesResponseList) {
				String deviceId = String.valueOf(deviceMap.get(CommonDefs.DEVICE_ID));
				deviceList.add(deviceId);

			}
		} else if (devicesResponse instanceof HashMap) {
			HashMap<String, Object> deviceMap = (HashMap<String, Object>) devicesResponse;
			String deviceId = String.valueOf(deviceMap.get(CommonDefs.DEVICE_ID));
			deviceList.add(deviceId);
		}
		
		log.info("Received Response in DeviceDeEnrollByFanResponseProcessor ::"+deviceList);
		
		if (!deviceList.isEmpty()) {
		JSONObject devicesJSON = new JSONObject();
		devicesJSON.put(CommonDefs.EMM_ACCOUNT_ID, String.valueOf(e.getProperty(CommonDefs.EMM_ACCOUNT_ID)));
		devicesJSON.put(CommonDefs.DEVICE_IDS, deviceList);
		e.getIn().setBody(devicesJSON);
		e.getIn().setHeader(CommonDefs.DEVICE_DEENROLL_REQUIRED, CommonDefs.Y);
		e.setProperty(CommonDefs.DEVICE_DEENROLL_REQUIRED, CommonDefs.Y);
		log.info("DeviceDeEnrollByFanResponseProcessor Setting deviceDeEnrollRequired ="+CommonDefs.Y);
		}else {
			e.setProperty(CommonDefs.DEVICE_DEENROLL_REQUIRED, CommonDefs.N);
			log.info("DeviceDeEnrollByFanResponseProcessor :: No Devices found for DeEnrollment");
		}

	}
	
	public final void processAsyncResponse(Exchange e) throws ApigwException {
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		e.getIn().setBody("");
		log.info("Returning response from DeviceDeEnrollByFanResponseProcessor.processAsyncResponse method::"+CommonDefs.RESPONSE_ACCEPT_CODE);

	}

}
