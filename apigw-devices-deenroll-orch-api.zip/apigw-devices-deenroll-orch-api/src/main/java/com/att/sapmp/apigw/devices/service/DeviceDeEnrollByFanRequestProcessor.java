package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author av0041
 *
 */
@Component
public class DeviceDeEnrollByFanRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceDeEnrollByFanRequestProcessor.class);

	public final void execute(Exchange e) throws ApigwException {

		String postReqUrl = (String) e.getIn().getHeader(CommonDefs.CAMEL_HTTP_URL);

		String[] urlArr = postReqUrl.split("/");
		String fan = urlArr[urlArr.length - 2];

		if (StringUtils.isEmpty(fan)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.INVALID_FAN);
		}

		String postReq = (String) (e.getIn().getBody());
		log.info("Payload for DeviceDeEnrollByFanRequestProcessor :: " + postReq);

		if (StringUtils.isEmpty(postReq)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.INVALID_REQUEST_BODY);
		}

		// create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// convert json string to object
		HashMap<String, Object> deEnrollDeviceMap = null;

		try {
			deEnrollDeviceMap = objectMapper.readValue(postReq, HashMap.class);
		} catch (IOException e1) {
			log.info("Exception occurred in DeviceDeEnrollByFanRequestProcessor while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);

		}

		e.setProperty(CommonDefs.FAN, fan);
		e.setProperty(CommonDefs.DEENROLLMENT_BY_FAN, CommonDefs.Y);
		e.setProperty(CommonDefs.EMM_ACCOUNT_ID, String.valueOf(deEnrollDeviceMap.get(CommonDefs.EMM_ACCOUNT_ID)));
		e.setProperty(CommonDefs.TENANT_ACCOUNT_ID, fan + e.getIn().getHeader(CommonDefs.EMMP_PRODUCT_CODE));

		JSONObject jsonRequest = new JSONObject();
		jsonRequest.put(CommonDefs.EMM_ACCOUNT_ID, String.valueOf(deEnrollDeviceMap.get(CommonDefs.EMM_ACCOUNT_ID)));
		jsonRequest.put(CommonDefs.PARTIAL_DEVICE_NAME, fan);

		e.getIn().setHeader(CommonDefs.QUERY_PARAM, CommonDefs.SEARCHCRITERIA + jsonRequest.toString());
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_PATH, CommonDefs.BACKWARD_SLASH);
		log.info("DeviceDeEnrollByFanRequestProcessor searchcriteria for InquireDevice :: " + jsonRequest.toString());

	}

}