package com.att.sapmp.apigw.devices.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.sapmp.apigw.devices.model.DeEnrollByFan;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "De-enroll Device by FAN")
@Produces({ MediaType.APPLICATION_JSON })
public interface DeviceDeEnrollByFanRestService {

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{fan}/deenroll")
	@ApiOperation(
			value = "This operation will mark the device as inactive or De-Enrolled",
			notes = "This operation will de-enroll all the devices under a fan by marking it as inactive." 
                +	"Devices should be active under the requested fan and emmAccountId. "
			
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void ByFan(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid, @PathParam("fan") String fan, @ApiParam(value = "De-Enroll Device Request Object", required = true) @RequestBody DeEnrollByFan deEnrollByFan );
	
}
