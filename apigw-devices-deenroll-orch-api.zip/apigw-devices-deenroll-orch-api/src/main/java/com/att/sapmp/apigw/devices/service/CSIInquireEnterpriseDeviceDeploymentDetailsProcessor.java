package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

@Component
public class CSIInquireEnterpriseDeviceDeploymentDetailsProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CSIInquireEnterpriseDeviceDeploymentDetailsProcessor.class);

	@Autowired
	private CommonUtil commonUtil;

	public final void execute(Exchange e) throws ApigwException {
		HashMap<String, Object> csiInquireDeviceDetailsMap = new HashMap<>();
		csiInquireDeviceDetailsMap.put(CommonDefs.MESSAGE_ID, String.valueOf(e.getProperty(CommonDefs.TRACKING_ID)));
		csiInquireDeviceDetailsMap.put(CommonDefs.EMM_DEVICE_ID, e.getProperty(CommonDefs.EMM_DEVICE_ID));

		commonUtil.populateCSIHeader(csiInquireDeviceDetailsMap);

		VelocityContext velocityContext = new VelocityContext(csiInquireDeviceDetailsMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);

	}

	public final void handleCsiInquireDeviceDetailResponse(Exchange e) throws ApigwException {

		String stHttpResponseCode = null;
		if (e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) != null) {
			stHttpResponseCode = String.valueOf(e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		}

		log.info("Received CamelHttpResponseCode in handleCsiInquireDeviceDetailResponse method = "
				+ stHttpResponseCode);

		String csiResposeBody = (String) e.getIn().getBody();
		//log.info("Response From handleCsiInquireDeviceDetailResponse body::" + csiResposeBody);
		commonUtil.logXML("Received response in handleCsiInquireDeviceDetailResponse method", csiResposeBody);

		XmlMapper xmlMapper = new XmlMapper();
		Map<String, Object> csiResponseMap = null;
		try {
			csiResponseMap = xmlMapper.readValue(csiResposeBody, HashMap.class);

		} catch (IOException ioe) {
			log.debug("Exception occurred while parsing post request: " + ioe);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		Map<String, Object> responseBodyMap = (HashMap<String, Object>) csiResponseMap.get(CommonDefs.BODY);

		if (responseBodyMap != null && !(responseBodyMap.isEmpty())) {
			Map<String, Object> inquireDetailsResponseMap = (HashMap<String, Object>) responseBodyMap
					.get(CommonDefs.IEDDD_RESPONSE);
			if (inquireDetailsResponseMap != null && !(inquireDetailsResponseMap.isEmpty())) {
				Map<String, Object> deviceDetailList = (HashMap<String, Object>) inquireDetailsResponseMap
						.get(CommonDefs.DEVICE_DETAIL_LIST);

				if (deviceDetailList != null && !(deviceDetailList.isEmpty())) {
					String deviceApnStatus = (String) deviceDetailList.get(CommonDefs.APNSTATUS);
					String subscriberNumber = (String) deviceDetailList.get(CommonDefs.CUSTOMER_TELEPHONE_NUMBER);
					String imei = (String) deviceDetailList.get(CommonDefs.IMEI);
					e.setProperty(CommonDefs.SUBSCRIBER_NUMBER, subscriberNumber);
					e.setProperty(CommonDefs.DEVICE_APN_STATUS, deviceApnStatus);
					e.setProperty(CommonDefs.IMEI, imei);
					log.info("Received response in handleCsiInquireDeviceDetailResponse method. APN_STATUS="
							+ deviceApnStatus + " and CTN=" + subscriberNumber);
				}

			}
		}

		if (stHttpResponseCode == null || !stHttpResponseCode.equalsIgnoreCase(CommonDefs.RESPONSE_SUCCESS_CODE)) {
			e.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.DEENROLLMENT_INITIATED);
			e.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.REMOVE_TRACKING_SOC_FAILED);
			e.setProperty(CommonDefs.DEENROLLMENT_COMPLETED, CommonDefs.N);
		}
		log.debug("End of handleCsiInquireDeviceDetailResponse");

	}
}