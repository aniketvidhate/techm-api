package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.att.sapmp.apigw.devices.util.CommonUtil;

@Component
public class CSIUpdateSubsriberProfileProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CSIUpdateSubsriberProfileProcessor.class);


	@Value("${csi.updateSub.version}")
	private String version;

	@Value("${csi.location}")
	private String location;

	@Value("${csi.offer.code}")
	private String code;

	@Value("${csi.originatorId}")
	private String originatorId;

	@Value("${csi.salesRepresentative}")
	private String salesRepresentative;

	@Value("${csi.updateSub.denroll.action}")
	private String updateSubDenrollAction;

	@Value("${csi.dealer.code}")
	private String dealerCode;
	
	@Autowired
	CommonUtil commonUtil;	

	public final void execute(Exchange e) throws ApigwException {

		HashMap<String, Object> subProfileMap = new HashMap<>();
		commonUtil.populateCSIHeader(subProfileMap);
		subProfileMap.put(CommonDefs.VERSION_NO, version);
		subProfileMap.put(CommonDefs.MESSAGE_ID, String.valueOf(e.getProperty(CommonDefs.TRACKING_ID)));
		subProfileMap.put(CommonDefs.ORIGINATOR_ID, originatorId);
		subProfileMap.put(CommonDefs.CONVERSATION_ID, String.valueOf(e.getProperty(CommonDefs.TRACKING_ID)));
		subProfileMap.put(CommonDefs.OFFERING_CODE, code);
		subProfileMap.put(CommonDefs.LOCATION, location);
		subProfileMap.put(CommonDefs.SALES_REPRESENTATIVE, salesRepresentative);
		subProfileMap.put(CommonDefs.DEALER_CODE, dealerCode);
		subProfileMap.put(CommonDefs.SUBSCRIBER_NUMBER, e.getProperty(CommonDefs.SUBSCRIBER_NUMBER));
		subProfileMap.put(CommonDefs.ACTION, updateSubDenrollAction);
		subProfileMap.put(CommonDefs.EFFECTIVE_DATE, CommonUtil.getGMTDatAsString());
		subProfileMap.put(CommonDefs.EXPIRATION_DATE, CommonUtil.getGMTDatAsString());

		VelocityContext velocityContext = new VelocityContext(subProfileMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);

	}
	
	public void updateSubProfileResponse(Exchange exchange) throws ApigwException {

		String stHttpResponseCode = null;
		if (exchange.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) != null) {
			stHttpResponseCode = String.valueOf(exchange.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		}

		log.info("Received CamelHttpResponseCode in updateSubProfileResponse method = " + stHttpResponseCode);

		String csiResposeBody = (String) exchange.getIn().getBody();
		//log.info("Response from CSIUpdateSubsriberProfile call ::" + csiResposeBody);
		commonUtil.logXML("Received response in updateSubProfileResponse method", csiResposeBody);

		exchange.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.DEENROLLMENT_INITIATED);
		if (stHttpResponseCode == null || !stHttpResponseCode.equalsIgnoreCase(CommonDefs.RESPONSE_SUCCESS_CODE)) {
			exchange.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.REMOVE_TRACKING_SOC_FAILED);
			exchange.setProperty(CommonDefs.DEENROLLMENT_COMPLETED, CommonDefs.N);
		} else {
			exchange.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.MDM_DEACTIVATION_PENDING);
			exchange.setProperty(CommonDefs.DEENROLLMENT_COMPLETED, CommonDefs.Y);
		}
	}
}
