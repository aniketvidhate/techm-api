package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author AD574A
 *
 */
@Component
public class DeviceDeEnrollOrchResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceDeEnrollOrchResponseProcessor.class);

	public final void processAsyncResponse(Exchange e) throws ApigwException {
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		e.getIn().setBody("");
		log.info("Returning response from DeviceDeEnrollOrchResponseProcessor.processAsyncResponse method::"
				+ CommonDefs.RESPONSE_ACCEPT_CODE);

	}

	public final void handleResponse(Exchange e) throws ApigwException {

		String stBody = e.getIn().getBody(String.class);

		log.info("Received Response in DeviceDeEnrollOrchResponseProcessor.handleResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + stBody);

		JSONObject deEnrollRespJSON = new JSONObject(stBody);

		// create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// convert json string to object
		Map<String, Object> deEnrollDeviceDetailsMap = null;
		try {
			deEnrollDeviceDetailsMap = objectMapper.readValue(deEnrollRespJSON.toString(), HashMap.class);
		} catch (IOException e1) {
			log.debug("Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);

		}
		if (deEnrollDeviceDetailsMap != null && deEnrollDeviceDetailsMap.containsKey(CommonDefs.ACTION_RESPONSE)) {

			String emmDeviceId = "";

			Map<String, Object> deEnrollDeviceResponseMap = (HashMap<String, Object>) deEnrollDeviceDetailsMap
					.get(CommonDefs.ACTION_RESPONSE);

			emmDeviceId = String.valueOf(deEnrollDeviceResponseMap.get(CommonDefs.MASS_360_DEVICE_ID));

			e.setProperty(CommonDefs.DEVICE_ID, emmDeviceId);

			if (CommonDefs.ZERO.equals(deEnrollDeviceResponseMap.get(CommonDefs.ACTION_STATUS).toString())) {
				e.setProperty(CommonDefs.DEENROLLMENT_COMPLETED, CommonDefs.Y);

			} else if (CommonDefs.ONE.equals(deEnrollDeviceResponseMap.get(CommonDefs.ACTION_STATUS).toString())) {
				e.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.DEENROLLMENT_FAILED);
				e.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.MDM_DEENROLLMENT_FAILED);
				e.setProperty(CommonDefs.DEENROLLMENT_COMPLETED, CommonDefs.N);
			}
		} else {
			e.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.DEENROLLMENT_FAILED);
			e.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.MDM_DEENROLLMENT_FAILED);
			e.setProperty(CommonDefs.DEENROLLMENT_COMPLETED, CommonDefs.N);
		}

	}

	public final void handleErrorResponse(Exchange e) throws ApigwException {
		String stBody = e.getIn().getBody(String.class);
		log.info("Received Response in DeviceDeEnrollOrchResponseProcessor.handleErrorResponse method. ResponseCode ::"
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + stBody);

		e.setProperty(CommonDefs.ENROLLMENT_STATUS, CommonDefs.DEENROLLMENT_FAILED);
		e.setProperty(CommonDefs.ENROLLMENT_SUB_STATUS, CommonDefs.MDM_DEENROLLMENT_FAILED);
		e.setProperty(CommonDefs.DEENROLLMENT_COMPLETED, CommonDefs.N);
	}

	public final void applyRemoveAPNResponse(Exchange e) throws ApigwException {
		String stBody = e.getIn().getBody(String.class);
		log.info(
				"Received Response in DeviceDeEnrollOrchResponseProcessor.applyRemoveAPNResponse method. ResponseCode ::"
						+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + stBody);
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
	}

}
