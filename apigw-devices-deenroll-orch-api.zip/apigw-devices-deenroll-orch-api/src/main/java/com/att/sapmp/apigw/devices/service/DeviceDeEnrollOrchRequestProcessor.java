package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.cxf.common.util.StringUtils;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author AD574A
 *
 */
@Component
public class DeviceDeEnrollOrchRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceDeEnrollOrchRequestProcessor.class);

	@Value("${csi.timeToLive}")
	private String timeToLive;

	@Value("${max.no.deviceId}")
	private String maxNumberofDeviceIds;

	public final void execute(Exchange e) throws ApigwException {

		String productCode = (String) (e.getIn().getHeader(CommonDefs.EMM_PRODUCT_CODE));
		String trackingid = (String) (e.getIn().getHeader(CommonDefs.TRACKING_ID));
		String deEnrollDeviceUrl = commonUtil.getProperty(productCode + "." + CommonDefs.DEENROLL_ORCH_URL);
		if (StringUtils.isEmpty(deEnrollDeviceUrl)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001,CommonDefs.INVALID_PRODUCT_CODE_MESSAGE);
		}
		String messageBody = e.getIn().getBody(String.class);
		if (StringUtils.isEmpty(messageBody)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CommonDefs.INVALID_INPUT_PAYLOAD);
		}
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> deEnrollDeviceMap;
		try {
			deEnrollDeviceMap = objectMapper.readValue(messageBody, HashMap.class);
			log.info("Request Payload in DeviceDeEnrollOrchRequestProcessor:: " + deEnrollDeviceMap);
		} catch (IOException ioex) {
			log.info("Exception occurred in DeviceDeEnrollOrchRequestProcessor while parsing Body ::" + ioex.getMessage() + " and Exception :: " + ioex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		validateMap(deEnrollDeviceMap, CommonDefs.DEVICE_DEENROLL_MANDATORY_FIELDS);

		List<String> deviceIdsList = (List<String>) deEnrollDeviceMap.get(CommonDefs.DEVICE_IDS);
		if (deviceIdsList.size() > Integer.parseInt(maxNumberofDeviceIds)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1002,CommonDefs.MAX_NO_DEVICE_SUPPORTED + maxNumberofDeviceIds);
		}

		e.getIn().setHeader(CommonDefs.DEENROLL_IBMURL, deEnrollDeviceUrl);
		e.getIn().setHeader(CommonDefs.DEVICE_LIST, deviceIdsList);
		e.setProperty(CommonDefs.EMM_PRODUCT_CODE, productCode);
		e.setProperty(CommonDefs.EMM_ACCOUNT_ID, deEnrollDeviceMap.get(CommonDefs.EMM_ACCOUNT_ID));
		e.setProperty(CommonDefs.TRACKING_ID, trackingid);
		e.setProperty(CommonDefs.AUTHORIZATION, (String) (e.getIn().getHeader(CommonDefs.AUTHORIZATION)));
		e.setProperty(CommonDefs.ACCOUNT_PASS_PHRASE, (String) (e.getIn().getHeader(CommonDefs.ACCOUNT_PASS_PHRASE)));

	}

	public final void applyRemoveAPNRequest(Exchange e) throws ApigwException {
		Map<String, Object> manageApnMap = new HashMap<>();
		manageApnMap.put(CommonDefs.EMM_DEVICE_ID, e.getProperty(CommonDefs.EMM_DEVICE_ID));
		manageApnMap.put(CommonDefs.IMEI, e.getProperty(CommonDefs.IMEI));

		VelocityContext velocityContext = new VelocityContext(manageApnMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);

	}

	public final void split(Exchange e) throws ApigwException {

		String strDeviceId = (String) e.getIn().getBody();
		if (StringUtils.isEmpty(strDeviceId)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001,CommonDefs.DEVICE_ID_NULL_INPUT);
		}
		e.setProperty(CommonDefs.EMM_DEVICE_ID, strDeviceId);
		JSONObject jsonBody = new JSONObject();
		jsonBody.put(CommonDefs.EMM_ACCOUNT_ID, e.getProperty(CommonDefs.EMM_ACCOUNT_ID));
		List<String> alDevice = new ArrayList<>();
		alDevice.add(strDeviceId);
		jsonBody.put(CommonDefs.DEVICE_IDS, alDevice);
		log.info("Processing in DeviceDeEnrollOrchRequestProcessor using split ::" + jsonBody);
		e.getIn().setBody(jsonBody);

	}

}
