package com.att.sapmp.apigw.devices.service;



import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.common.camel.AjscRouteBuilder;

@Component
public class TestRoute extends RouteBuilder {
	@Autowired
	private AjscRouteBuilder ajscRoute;	
	@Value("${test.csi.inquire.device.detail.url}")
	private String inquireDeviceDetailUrl;
	
	@Value("${test.csi.inquire.account.detail.url}")
	private String inquireAccountDetailUrl;
	
	@Value("${csi.manage.device.detail.url}")
	private String manageDeviceDetailUrl;

	@Override
	public void configure() throws Exception {
		ajscRoute.initialize(this);
		ajscRoute.setRoute(from("servlet:/test/csi/inquiredevice")
				.to("bean:CSIProcessor?method=inquireDevice")
				.setHeader(Exchange.HTTP_URI, simple(inquireDeviceDetailUrl))
				.to("velocity:testvm/csiInquireEnterpriseDeviceDeploymentDetailsRequest.vm")
				.setBody(body())
				.to("http4://headeruri?throwExceptionOnFailure=false"));
		
		ajscRoute.setRoute(from("servlet:/test/csi/createdevice")
				.to("bean:CSIProcessor?method=createDevice")
				.setHeader(Exchange.HTTP_URI, simple(manageDeviceDetailUrl))
				.to("velocity:testvm/csiManageEnterpriseDeviceDeploymentDetailsRequest.vm")
				.setBody(body())
				.to("http4://headeruri?throwExceptionOnFailure=false"));
		
		ajscRoute.setRoute(from("servlet:/test/csi/deletedevice")
				.to("bean:CSIProcessor?method=deleteDevice")
				.setHeader(Exchange.HTTP_URI, simple(manageDeviceDetailUrl))
				.to("velocity:testvm/csiManageEnterpriseDeviceDeploymentDetailsRequest.vm")
				.setBody(body())
				.to("http4://headeruri?throwExceptionOnFailure=false"));
		
		ajscRoute.setRoute(from("servlet:/test/csi/inquireaccount")
				.to("bean:CSIProcessor?method=inquireAccount")
				.setHeader(Exchange.HTTP_URI, simple(inquireAccountDetailUrl))
				.to("velocity:testvm/csiInquireEnterpriseDeviceDeploymentProfileRequest.vm")
				.setBody(body())
				.to("http4://headeruri?throwExceptionOnFailure=false"));
		
		ajscRoute.setRoute(from("servlet:/test/compliance/publish")
				.to("bean:notificationProcessor?method=publish"));
		ajscRoute.setRoute(from("servlet:/test/notification")
				.convertBodyTo(String.class)
				.to("bean:complianceNotificationProcessor?method=processEachMdmNotification")
				.to("direct:complianceAction"));

	}


}
