package com.att.sapmp.apigw.devices.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.att.sapmp.apigw.devices.util.CommonDefs;


public class TestDeviceDeEnrollment extends TestBase {

	@Value("${test.emmAccountId}")
	private String emmAccountId;

	@Value("${test.emmDeviceId}")
	private String emmDeviceId;
	
	@Value("${test.ibm.deenroll.basePath}")
	protected String basePath;
	
	@Value("${test.csi.create.device.imei}")
	protected String imei;

	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
		requestJson = requestJson.replaceAll("\\$\\{emmDeviceId\\}", emmDeviceId);
	}

	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceDeEnrollmentIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError()
			throws Exception {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenDeEnrollmentRequestWhenEmmAccountIdIsMissingThenTransactionFailsAndReturnInvalidRequestError()
			throws Exception {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody,
				anyOf(containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDeEnrollmentRequestWhenDeviceIdsIsMissingThenTransactionFailsAndReturnInvalidRequestError()
			throws Exception {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody,
				anyOf(containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDeEnrollmentRequestWhenRequiredFieldsAreMissingInHeaderThenTransactionFailsAndReturnInvalidRequestError()
			throws Exception {
		headers.set("accountpassphrase", "");
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody,
				anyOf(containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDeEnrollmentRequestWhenNumberOfDevicesToDeEnrollIsGreaterThanConfiguredValueThenTransactionFailsAndReturnInvalidRequestError()
			throws Exception {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody,
				anyOf(containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDeEnrollmentRequestWhenDeviceIdIsInValidThenDeEnrollmentFails() throws Exception {
		//Add the emmDeviceId for the de-enrollment CDF record to be created
		headers.add(CommonDefs.EMM_DEVICE_ID, "sfsdfsdf");
		executePost(csiCreateDeviceBasePath);	
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		executePost();		
		String inquireResponse = executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		executePost(csiDeleteDeviceBasePath);
		assertThat(inquireResponse, allOf(containsString("<enrollmentStatus>DEENROLLMENT_FAILED</enrollmentStatus>")));
	}

	@Test
	public void testGivenDeEnrollmentRequestWhenDeviceIdIsValidThenDeEnrollmentSucceeds() throws Exception {
		executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}

	@Test
	public void testGivenDeEnrollmentRequestWhenDeviceDeEnrollmentFailsThenDeviceStatusIs_DEENROLLMENT_FAILED_And_MDM_DEENROLLMENT_FAILED_And_DeviceActivityLogIsInserted()
			throws Exception {
		//Add the emmDeviceId for the de-enrollment CDF record to be created
		headers.add(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
		executePost(csiCreateDeviceBasePath);	
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		executePost();		
		String inquireResponse = executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		executePost(csiDeleteDeviceBasePath);		
		assertThat(inquireResponse, allOf(containsString("<enrollmentStatus>DEENROLLMENT_FAILED</enrollmentStatus>")));
		assertThat(inquireResponse, containsString("<enrollmentSubStatus>MDM_DEENROLLMENT_FAILED</enrollmentSubStatus>"));
		assertThat(inquireResponse, containsString("<activityType>DEENROLL</activityType>"));		    
	}

	@Test // This test case needs to be tested Manually.
	public void testGivenDeEnrollmentRequestWhenDeviceDeEnrollmentIsSuccessAndRemoveTrackingSocFailsThenDeviceStatusIs_DEENROLLMENT_FAILED_And_REMOVE_TRACKING_SOC_FAILED_And_DeviceActivityLogIsInserted()
			throws Exception {
		//Add the emmDeviceId for the de-enrollment CDF record to be created
		/*headers.add(CommonDefs.EMM_DEVICE_ID, emmDeviceId);
		executePost(csiCreateDeviceBasePath);	
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		executePost();		
		String inquireResponse = executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		executePost(csiDeleteDeviceBasePath);
		assertThat(inquireResponse, allOf(containsString("<enrollmentStatus>DEENROLLMENT_FAILED</enrollmentStatus>")));
		assertThat(inquireResponse, containsString("<enrollmentSubStatus>REMOVE_TRACKING_SOC_FAILED</enrollmentSubStatus>"));
		assertThat(inquireResponse, containsString("<activityType>DEENROLL</activityType>"));*/		    
	}

	@Test // This test case needs to be tested Manually.
	public void testGivenDeEnrollmentRequestWhenDeviceDeEnrollmentIsSuccessAndRemoveTrackingSocSuccessThenDeviceStatusIs_DEENROLLMENT_INITIATED_And_MDM_DEACTIVATION_PENDING_And_DeviceActivityLogIsInserted()
			throws Exception {
		//Add the emmDeviceId for the de-enrollment CDF record to be created
		/*headers.add(CommonDefs.EMM_DEVICE_ID, emmDeviceId);		
		executePost(csiCreateDeviceBasePath);	
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		executePost();		
		String inquireResponse = executePost(csiInquireDeviceBasePath,"{\"deviceId\":\""+generatedCDFDeviceId+"\"}");
		executePost(csiDeleteDeviceBasePath);		
		assertThat(inquireResponse, allOf(containsString("<enrollmentStatus>DEENROLLMENT_INITIATED</enrollmentStatus>")));
		assertThat(inquireResponse, containsString("<enrollmentSubStatus>MDM_DEACTIVATION_PENDING</enrollmentSubStatus>"));
		assertThat(inquireResponse, containsString("<activityType>DEENROLL</activityType>"));*/		    
	}

	@Test
	public void testGivenDeEnrollmentRequestWhenDeviceDeEnrollmentIsSuccessAndDeviceHasActiveApnThenRemoveApnIsRequested()
			throws Exception {
		executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}

	@Test
	public void testGivenDeEnrollmentRequestWhenRequestContainsMultipleDevicesThenDeEnrollmentIsExecutedForAllDevices()
			throws Exception {
		executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}

	@After
	public void tearDown() throws Exception {

	}
}