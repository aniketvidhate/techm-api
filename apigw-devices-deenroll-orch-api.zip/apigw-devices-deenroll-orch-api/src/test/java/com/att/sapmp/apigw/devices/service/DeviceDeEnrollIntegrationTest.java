package com.att.sapmp.apigw.devices.service;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.Application;




@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
@TestPropertySource(locations = "classpath:application-test.properties")
public class DeviceDeEnrollIntegrationTest {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceDeEnrollIntegrationTest.class);
	
	HttpHeaders headers = new HttpHeaders();
	
	static{
		SystemPropertiesLoader.addSystemProperties(); 
	}
	
	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	   @Autowired
	    private TestRestTemplate template;
	   
	@Before
	public void setUp() throws Exception {
		
		headers.set("Content-Type", "application/json");
		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
		headers.set("accountpassphrase", "5001234");
		Date d = new Date();
		long millisec = d.getTime();
		headers.set("trackingid",String.valueOf(millisec));
		headers.set("emmproductcode", "IBMMASS");				
	}

	@After
	public void tearDown() throws Exception {
		
		
	}

	@Test
	public void testDeEnrollWithCorrectInput() throws Exception {
		
		String requestJson = "{\r\n\"emmAccountId\": \"30059025\",\r\n\"deviceIds\":[\"ApplC39KVZU7FH19\"]\r\n}";
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    ResponseEntity<String> response = template.exchange("/devices/deenroll", HttpMethod.DELETE, entity,String.class);
	    String responseBody = response.getBody();
	    log.info("Response:" + responseBody);
		//assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	
	}	
}
