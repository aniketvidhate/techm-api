package com.att.sapmp.apigw.devices.service;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import  com.att.sapmp.apigw.devices.Application;
import com.att.sapmp.apigw.devices.util.CommonDefs;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
@TestPropertySource(locations = "classpath:application-test.properties")
public class DeviceDeEnrollOrchRequestProcessorTest {
	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	@Autowired
	private ProducerTemplate producerTemplate;

	private List<String> deviceIds = new ArrayList();

	private String billingId = "30058930";

	@Test
	public void testRequestProcessor() throws Exception {

		deviceIds.add("ApplC39KVZU7FH19");
		 JSONObject jsonObj = new JSONObject();
		 jsonObj.put("emmAccountId",billingId);
		 jsonObj.put("deviceIds",deviceIds);
		Exchange exchange = ExchangeBuilder.anExchange(producerTemplate.getCamelContext())
				.withBody(jsonObj)
				.withHeader("Accept", "application/json")
				  .withHeader(Exchange.CONTENT_TYPE, "application/json")
				  .withHeader("Authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==")
				  .withHeader(Exchange.HTTP_URL, "http://localhost:8080/sapmp/v1/ibm/devices/deenroll")
				  .withHeader("EMMProductCode", "ibmmass")
				  .withHeader("AccountPassPhrase", "1234567890")
				  .withHeader("trackingid", "Z1234567890")
				  .build();

		producerTemplate.send("direct:DeenrollRequestRoute", exchange);

/*		assertEquals(exchange.getOut().getHeader(CommonDefs.DEENROLL_IBMURL),
				"http://zld01119.vci.att.com:8286/sapmp/v1/ibm/devices/deenroll");*/
		/*assertEquals(exchange.getOut().getHeader(CommonDefs.EMM_PRODUCT_CODE), "ibmmass");*/
/*		assertEquals(exchange.getOut().getHeader(CommonDefs.TRACKING_ID), "Z1234567890");*/

	}

}
	


