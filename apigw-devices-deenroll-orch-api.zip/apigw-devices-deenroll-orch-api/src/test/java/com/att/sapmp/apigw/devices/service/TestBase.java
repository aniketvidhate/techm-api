package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.Application;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:application-test.properties")
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
public abstract class TestBase {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(TestBase.class);
	@Autowired
	private TestRestTemplate template;		
	@Rule 
	public TestName name = new TestName();	
	
	HttpHeaders headers = new HttpHeaders();
	static JSONObject testFixtureJson;
	String requestJson = new String();
	String responseBody = new String();
	ResponseEntity<String> response;
	
	@Value("${test.csi.inquire.device.basepath}")
	protected String csiInquireDeviceBasePath;	
	
	@Value("${test.csi.inquire.account.basepath}")
	protected String csiInquireAccountBasePath;	
	
	@Value("${test.csi.create.device.basepath}")
	protected String csiCreateDeviceBasePath;	
	
	@Value("${test.csi.delete.device.basepath}")
	protected String csiDeleteDeviceBasePath;
	
	@Value("${test.authorization}")
	protected String authorization;
	
	@Value("${test.accountpassphrase}")
	protected String accountpassphrase;
	
	@Value("${test.emmproductcode}")
	protected String emmproductcode;
	
	protected abstract void replaceTokensInRequest() throws Exception;
	protected abstract String getBasePath();		
	
	@BeforeClass
	public static void loadTestFixture() throws Exception {
		DefaultResourceLoader resourceLoader = new DefaultResourceLoader();
		String testFixtureStr = IOUtils.toString(resourceLoader.getResource("classpath:"+ "testfixture.json").getInputStream());
		testFixtureJson = new JSONObject(testFixtureStr); 
	}
	
	@Before
	public void setUp() throws Exception {
		SystemPropertiesLoader.addSystemProperties(); 
		headers = new HttpHeaders();
		requestJson = new String();
		responseBody = new String();		
		headers.set("Content-Type", "application/json");
		headers.set("authorization", authorization);
		headers.set("accountpassphrase", accountpassphrase);
		headers.set("trackingid",String.valueOf(new Date().getTime()));		
		headers.set("emmproductcode", emmproductcode);	
		readRequest();
	}
	
	protected void readRequest() throws Exception {
		//Add the test payload json to test/resources/testfixture.json with the payload key as the testmethod name 
        requestJson =  testFixtureJson.getJSONObject((name.getMethodName())).toString();
        replaceTokensInRequest();
	}		

	protected String executePost() {
		return executePost(getBasePath());
	}
	
	protected String executePost(String path) {
		return executePost(path,requestJson);
	}
	
	protected String executePost(String path, String requestJson) {
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
	    response = template.exchange(path, HttpMethod.POST, entity,String.class);
	    responseBody = response.getBody();
	    log.info("Response:" + responseBody);
	    return responseBody;
	}
	
	protected void executeGet(String path) {
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
	    response = template.exchange(path, HttpMethod.GET, entity,String.class,requestJson);
	    responseBody = response.getBody();
	    log.info("Response:" + responseBody);
	}
	
	protected String getGeneratedCDFDeviceId() throws IOException, JsonParseException, JsonMappingException {
		XmlMapper xmlMapper = new XmlMapper();
		Map<String, Object> csiResponseMap = xmlMapper.readValue(responseBody, HashMap.class);
		Map<String, Object> responseBodyMap = (HashMap<String, Object>) csiResponseMap.get("Body");
		Map<String, Object> manageEnterpriseDeviceDeploymentProfileResponse = (HashMap<String, Object>)responseBodyMap.get("ManageEnterpriseDeviceDeploymentDetailsResponse");
		Map deviceDetailsMap = (HashMap) manageEnterpriseDeviceDeploymentProfileResponse.get("DeviceDetails");
		String cdfDeviceId = (String)deviceDetailsMap.get("deviceId");
		return cdfDeviceId;
	}	

	protected void executeGet() {
		executeGet(getBasePath());
	}	
	
	@After
	public void tearDown() throws Exception {	
	}	
}
