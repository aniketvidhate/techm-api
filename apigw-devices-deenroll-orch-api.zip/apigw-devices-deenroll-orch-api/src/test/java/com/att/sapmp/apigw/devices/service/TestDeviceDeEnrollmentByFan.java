package com.att.sapmp.apigw.devices.service;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;

public class TestDeviceDeEnrollmentByFan extends TestBase {

	@Value("${test.emmAccountId}")
	private String emmAccountId;

	@Value("${test.ibm.deenroll.by.fan.basePath}")
	protected String basePath;

	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
	}

	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenFanHasActiveDeviceAndDeviceDeEnrollmentIsAttemptedThenDevicesAreDeEnrolledAndAccountStatusInCdfIsINACTIVE()
			throws Exception {
		// first Need data where we need FAN for which device status is Active
		// DeEnrollmentIsAttemptedThenDevicesAreDeEnrolledAndAccountStatusInCdfIsINACTIVE
		// Secondly this is successful scenario of De-enrollment, so it needs to
		// be Manual.
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenFanHasActiveDeviceAndDeviceDeEnrollmentIsAttemptedAndFailsThenAccountStatusInCdfIsREMOVE_FAILED()
			throws Exception {
		// This test case needs a ACTIVE DEVICE, so it needs to be Manual.

		/*
		 * executePost(csiCreateDeviceBasePath); String generatedCDFDeviceId =
		 * getGeneratedCDFDeviceId(); executePost(); String inquireResponse =
		 * executePost(csiInquireAccountBasePath,"{\"emmAccountId\":\""+
		 * emmAccountId+"\"}"); executePost(csiDeleteDeviceBasePath);
		 * assertThat(inquireResponse,
		 * containsString("<accountStatus>REMOVE_FAILED</accountStatus>"));
		 */
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenDeEnrollmentIsSuccessThenDeviceStatusInCdfIs_DEENROLLMENT_INITIATED_MDM_DEACTIVATION_PENDING()
			throws Exception {
		// DDeviceDeEnrollmentWhenDeEnrollmentIsSuccess
		// This is successful scenario of De-enrollment, so it needs to be
		// Manual.
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenDeEnrollmentIsSuccessThenDeviceStatusInCdfIs_DEENROLLMENT_FAILED_MDM_DEENROLLMENT_FAILED()
			throws Exception {
		// DDeviceDeEnrollmentWhenDeEnrollmentIsSuccess
		// This is successful scenario of De-enrollment, so it needs to be
		// Manual.
		// Secondly
		// DeviceStatusInCdfIs_DEENROLLMENT_FAILED_MDM_DEENROLLMENT_FAILED which
		// is INVALID
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenDeEnrollmentIsSuccessThenTrackingSocIsRemovedSuccessfully()
			throws Exception {
		// This is successful scenario of De-enrollment, so it needs to be
		// Manual.
		// WhenDeEnrollmentIsSuccessThenTrackingSocIsRemovedSuccessfully
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenTrackingSocRemovalFailsThenDeviceActivityLogIsUpdated()
			throws Exception {
		// This is successful scenario of De-enrollment, so it needs to be
		// Manual.
		// As per flow diagram, we are not updating Activity logs when
		// TrackingSocRemovalFails.
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenDeEnrollmentIsSuccessAndDeviceIsApnRestrictedThenDeviceApnIsRemoved()
			throws Exception {
		// This is successful scenario of De-enrollment, so it needs to be
		// Manual.
		// DeviceDeEnrollmentWhenDeEnrollmentIsSuccessAndDeviceIsApnRestrictedThenDeviceApnIsRemoved
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenDeEnrollmentIsSuccessAndDeviceIsNotApnRestrictedThenDeviceApnRemovalIsSkipped()
			throws Exception {
		// This is successful scenario of De-enrollment, so it needs to be
		// Manual.
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenNoActiveDevicePresentInAccountThenDeviceDeEnrollmentIsSkippedAndAccountStatusInCdfIsINACTIVE()
			throws Exception {
		executePost(csiCreateDeviceBasePath);
		String generatedCDFDeviceId = getGeneratedCDFDeviceId();
		executePost();
		String inquireResponse = executePost(csiInquireAccountBasePath, "{\"emmAccountId\":\"" + emmAccountId + "\"}");
		executePost(csiDeleteDeviceBasePath);
		assertThat(inquireResponse, containsString("<accountStatus>INACTIVE</accountStatus>"));
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenSearchingForActiveDeviceFailsThenAccountStatusInCdfIsREMOVE_FAILED()
			throws Exception {
		// This test case needs a ACTIVE DEVICE, so it needs to be Manual.

		/*
		 * executePost(csiCreateDeviceBasePath); String generatedCDFDeviceId =
		 * getGeneratedCDFDeviceId(); executePost(); String inquireResponse =
		 * executePost(csiInquireDeviceBasePath,"{\"emmAccountId\":\""+
		 * emmAccountId+"\"}"); executePost(csiDeleteDeviceBasePath);
		 * assertThat(inquireResponse,
		 * containsString("<accountStatus>REMOVE_FAILED</accountStatus>"));
		 */
	}

	@After
	public void tearDown() throws Exception {

	}
}