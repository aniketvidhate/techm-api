package com.att.sapmp.apigw.devices.service;

import static org.junit.Assert.assertEquals;

import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.ExchangeBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.sapmp.apigw.devices.Application;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
@TestPropertySource(locations = "classpath:application-test.properties")
public class DeviceDeEnrollOrchResponseProcessorTest {
	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	@Autowired
	private ProducerTemplate producerTemplate;

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void handleResponseTest() throws Exception {
		String jsonBody = "Testing";
		Exchange exchange = ExchangeBuilder.anExchange(producerTemplate.getCamelContext()).withBody(jsonBody).build();
		producerTemplate.send("direct:DeenrollResponsetRoute", exchange);
		assertEquals(exchange.getOut().getHeader(Exchange.HTTP_RESPONSE_CODE), null);

	}

	@Test
	public void handleCdfUpdateResponseTest() throws Exception {
		String jsonBody = "Testing";
		Exchange exchange = ExchangeBuilder.anExchange(producerTemplate.getCamelContext()).withBody(jsonBody).build();
		producerTemplate.send("direct:DeenrollResponsetRoute", exchange);
		assertEquals(exchange.getOut().getHeader(Exchange.HTTP_RESPONSE_CODE), null);
	}

	@Test
	public void updateSubscriberResponseTest() throws Exception {
		String jsonBody = "Testing";
		Exchange exchange = ExchangeBuilder.anExchange(producerTemplate.getCamelContext()).withBody(jsonBody).build();
		producerTemplate.send("direct:DeenrollResponsetRoute", exchange);
		assertEquals(exchange.getOut().getHeader(Exchange.HTTP_RESPONSE_CODE), null);
	}

	@Test
	public void inquireCDFResponseTest() throws Exception {
		String jsonBody = "Testing";
		Exchange exchange = ExchangeBuilder.anExchange(producerTemplate.getCamelContext()).withBody(jsonBody).build();
		producerTemplate.send("direct:DeenrollResponsetRoute", exchange);
		assertEquals(exchange.getOut().getHeader(Exchange.HTTP_RESPONSE_CODE), null);
	}
}
