package com.att.sapmp.apigw.devicemanagement.service;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestLockDevice extends TestBase {
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.ibm.lock.device.basePath}")
	protected String basePath;
	
	@Value("${test.ibm.inquire.device.basePath}")
	protected String basePathInquireDevice;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
	}
	
	@Override
	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenLockDeviceReqeustWhenAuthorizationTokenIsInvalidThenReturnUserUnauthorizedErrorAndHttpStatusCode_401() throws Exception{
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}
	
	@Test
	public void testGivenLockDeviceRequestWhenEmmAccountIdIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenLockDeviceRequestWhenDeviceIdIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception{
		basePath = "/devices/lockdevice";
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testGivenLockDeviceRequestWhenRequestIsValidThenReturnSuccessResponseAndHttpStatusCode202() throws Exception{
		// Success scenario - needs to be tested manually when we have device to execute Lock device action.
		/*executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());*/
	}

	@Test
	public void testGivenLockDeviceRequestWhenRequestIsInValidThenTransactionFailsAndHttpStatusCode400() throws Exception{
		/*basePath = basePathInquireDevice; executeGet(); basePath = "/devices/ABCDEFGHIJK/lockdevice"; */
		headers.set("emmproductcode", "");
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1001"), containsString("Invalid Product Code")));
	}

	@Test
	public void testGivenLockDeviceRequestWhenUnExpectedErrorOccursThenResponseContainsErrorMessageAndHttpStatusCode_500() throws Exception{	
		// Need to test Manually - in application.properties file set to apigw.device.base.url=http://localhost:5050 i.e. wrong port
		/*executePost();		
	    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());*/
	}

	@Test
	public void testGivenLockDeviceWhenRequiredFieldsAreMissingInHeaderThenReturnInvalidRequestError() throws Exception{
		headers.set("authorization", "");
		headers.set("accountpassphrase", "");
		headers.set("emmproductcode", "");
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}	
}
