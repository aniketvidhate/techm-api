package com.att.sapmp.apigw.devicemanagement.service;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestWipeDevice extends TestBase{
	
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;

	@Value("${test.wipeType}")
	private String wipeType;

	@Value("${test.ibm.wipe.device.basePath}")
	protected String basePath;

	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
		requestJson = requestJson.replaceAll("\\$\\{wipeType\\}", wipeType);
	}

	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceWipeIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError()throws Exception {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());		
	}

	@Test
	// Need to test Manually - Success scenario
	public void testGivenAuthTokenIsvalidWhenDeviceWipeIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception{
		/*executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());*/	
	}

	@Test
	public void testGivenWipeDeviceRequestWhenEmmAccountIdIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception{
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testGivenWipeDeviceRequestWhenDeviceIdIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception{
		basePath = "/devices/wipedevice";
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testGivenWipeDeviceRequestWhenWipeTypeIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
	
	@Test
	public void testGivenWipeDeviceRequestWhenAuthorizationTokenIsInvalidThenReturnUserUnauthorizedErrorAndHttpStatusCode401() throws Exception{
		headers.set("authorization", "Basic 123");
		executeGet();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}	

	@Test
	// Need to test Manually - Success scenario
	public void testGivenWipeDeviceRequestWhenRequestIsValidThenReturnSuccessResponseAndHttpStatusCode202() throws Exception{
		/*executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());*/
	}

	@Test
	// Need to test Manually -
	public void testGivenWipeDeviceRequestWhenFullWipeIsRequestedThenDeviceWipedResetToFactorySettings() throws Exception{
		/*executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());*/
	}

	@Test
	// Need to test Manually - Success scenario
	public void testGivenWipeDeviceReqeustWhenSelectiveWipeIsRequestedThenDeviceIsSelectivelyWipedAndMdmControlIsRemovedFromTheDevice() throws Exception{
		/*executePost();
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());*/
	}

	@Test
	public void testGivenWipeDeviceRequestWhenUnExpectedErrorOccursThenResponseContainsErrorMessageAndHttpStatusCode500() throws Exception{
		// Need to test Manually - in application.properties file set to apigw.device.base.url=http://localhost:5050 i.e. wrong port
		/*executeGet();		
	    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());*/
	    
	}

	@Test
	public void testGivenWipeDeviceWhenRequiredFieldsAreMissingInHeaderThenReturnInvalidRequestError() throws Exception{
		headers.set("authorization", "");
		headers.set("accountpassphrase", "");
		headers.set("emmproductcode", "");
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());	
	}
}
