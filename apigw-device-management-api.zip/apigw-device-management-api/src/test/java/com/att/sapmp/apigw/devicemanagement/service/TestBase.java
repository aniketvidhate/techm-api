package com.att.sapmp.apigw.devicemanagement.service;

import java.util.Date;

import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devicemanagement.Application;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:application-test.properties")
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
public abstract class TestBase {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(TestBase.class);
	@Autowired
	private TestRestTemplate template;
	@Rule
	public TestName name = new TestName();

	HttpHeaders headers = new HttpHeaders();
	static JSONObject testFixtureJson;
	String requestJson = new String();
	String responseBody = new String();
	ResponseEntity<String> response;
	
	@Value("${test.authorization}")
	protected String authorization;
	@Value("${test.accountpassphrase}")
	protected String accountpassphrase;
	@Value("${test.emmproductcode}")
	protected String emmproductcode;	

	protected abstract void replaceTokensInRequest() throws Exception;

	protected abstract String getBasePath();

	@BeforeClass
	public static void loadTestFixture() throws Exception {
		DefaultResourceLoader resourceLoader = new DefaultResourceLoader();
		String testFixtureStr = IOUtils
				.toString(resourceLoader.getResource("classpath:" + "testfixture.json").getInputStream());
		testFixtureJson = new JSONObject(testFixtureStr);
	}

	@Before
	public void setUp() throws Exception {
		SystemPropertiesLoader.addSystemProperties();
		headers = new HttpHeaders();
		requestJson = new String();
		responseBody = new String();
		headers.set("Content-Type", "application/json");
		headers.set("authorization", authorization);
		headers.set("accountpassphrase", accountpassphrase);
		headers.set("trackingid", String.valueOf(new Date().getTime()));
		headers.set("emmproductcode", emmproductcode);
		readRequest();
	}

	protected void readRequest() throws Exception {
		// Add the test payload json to test/resources/testfixture.json with the
		// payload key as the testmethod name
		requestJson = testFixtureJson.getJSONObject((name.getMethodName())).toString();
		replaceTokensInRequest();
	}

	protected void executePost() {
		executePost(getBasePath());
	}

	protected void executePost(String path) {
		HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
		response = template.exchange(path, HttpMethod.POST, entity, String.class);
		responseBody = response.getBody();
		log.info("Response:" + responseBody);
	}

	protected void executeGet(String path) {
		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		response = template.exchange(path, HttpMethod.GET, entity, String.class, requestJson);
		responseBody = response.getBody();
		log.info("Response:" + responseBody);
	}

	protected void executeGet() {
		executeGet(getBasePath());
	}

	@After
	public void tearDown() throws Exception {
	}
}
