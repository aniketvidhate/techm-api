package com.att.sapmp.apigw.devicemanagement.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestInquireDeviceActionHistory extends TestBase {
	
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.actionExecutionTimeTo}")
	private String actionExecutionTimeTo;
	
	@Value("${test.deviceId}")
	private String deviceId;		
	
	@Value("${test.actionExecutionTimeFrom}")
	protected String actionExecutionTimeFrom;	
	
	@Value("${test.ibm.inquire.device.actionHistory.basePath}")
	protected String basePath;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
        requestJson = requestJson.replaceAll("\\$\\{actionExecutionTimeTo\\}", actionExecutionTimeTo);    
        requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", deviceId);   
        requestJson = requestJson.replaceAll("\\$\\{actionExecutionTimeFrom\\}", actionExecutionTimeFrom);  
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
	}
	
	@Override
	protected String getBasePath() {
		return basePath;
	}
	
	@Test
	public void testGivenInquireDeviceActionHistoryWhenDeviceIdIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception{
		executeGet();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenInquireDeviceActionHistoryWhenEmmAccountIdIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception{
		executeGet();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenInquireDeviceActionHistoryWhenActionExecutionTimeFromIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception{
		executeGet();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenInquireDeviceActionHistoryWhenActionExecutionTimeToIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception{
		executeGet();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenInquireDeviceActionHistoryWhenInquireHistoryRequestIsSuccessThenResponseContainsDeviceActionHistoryAndHttpStatusCode_200() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testGivenInquireDeviceActionHistoryWhenAuthorizationTokenIsInvalidThenReturnUserUnauthorizedErrorAndHttpStatusCode_401() throws Exception{
		headers.set("authorization", "Basic 123");
		executeGet();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenInquireDeviceActionHistoryWhenUnExpectedErrorOccursThenResponseContainsErrorMessageAndHttpStatusCode_500() throws Exception{
		headers.set("accountpassphrase", "23232");
		executeGet();
	    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireDeviceActionHistoryWhenRequestContainsInvalidDeviceIdAndValidEmmAccountIdThenTransactionReturnsAllActionHistoryForInputEmmAccountId() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody, containsString("actionHistory"));
	    assertThat(responseBody, containsString("actionStatusResponse"));
	}	
	
	@Test
	public void testGivenInquireDeviceActionHistoryWhenRequestContainsValidDeviceIdAndValidEmmAccountIdThenTransactionReturnsActionHistoryForThatDeviceIdOnlyForInputEmmAccountId() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody, containsString("actionHistory"));
	    assertThat(responseBody, containsString("actionStatusResponse"));
	    assertThat(responseBody, containsString(emmAccountId));
	    assertThat(responseBody, containsString(deviceId));
	}	

	@Test
	public void testGiveDeviceIsAlreadyEnrolledWhenDeviceActionHistoryIsRequestedThenResponseContainsRequiredFields() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody, allOf(containsString("actionStatusResponse")));
	    
	}

	@Test
	public void testGivenDeviceIsAlreadyEnrolledWhenNoActionAvailableForTheDateRangeThenResponeContainsNoData() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody, allOf(containsString(":{}")));
	    assertThat(responseBody, allOf(containsString("")));
	    
	}
	
	@Test
	public void testGivenInquireDeviceActionHistoryWhenRequiredFieldsAreMissingInHeaderThenReturnInvalidRequestError() throws Exception{
		
		headers.set("authorization", "");
		headers.set("accountpassphrase", "");
		headers.set("emmproductcode", "");
		executeGet();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}	
}
