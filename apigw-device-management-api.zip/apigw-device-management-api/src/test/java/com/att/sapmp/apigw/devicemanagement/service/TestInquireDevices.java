package com.att.sapmp.apigw.devicemanagement.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestInquireDevices extends TestBase {
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.deviceId}")
	private String deviceId;	
	
	@Value("${test.imei}")
	private String imei;	
	
	@Value("${test.platformName}")
	private String platformName;	
	
	@Value("${test.ibm.inquire.device.basePath}")
	protected String basePath;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", deviceId);
        requestJson = requestJson.replaceAll("\\$\\{imei\\}", imei);
        requestJson = requestJson.replaceAll("\\$\\{platformName\\}", platformName);
	}
	
	@Override
	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenInquireDeviceWhenEmmAccountIdIsMissingThenReturnInvalidRequestErrorAndHttpStatusCode400() throws Exception{
		executeGet();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

	}

	@Test
	public void testGivenInquireDeviceWhenRequestedDeviceStatusIsActiveThenResponseContainsOnlyActiveDevicesAndHttpStatusCode200() throws Exception{
		/*executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody, allOf(containsString("Active")));*/ 
	    // Manually Tested - TO DO - need data for which we have deviceStatus as Active 
	}
	
	@Test
	public void testGivenInquireDeviceWhenRequestedDeviceStatusIsInActiveThenResponseContainsOnlyInActiveDevicesAndHttpStatusCode200() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody, allOf(containsString("Inactive")));
	}
	
	@Test
	public void testGivenInquireDeviceWhenSearchContainsPlatformThenResponseContainsSpecificPlatformDevicesAndHttpStatusCode200() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());	   
	    assertThat(responseBody, allOf(containsString(platformName)));	    
	}	
	
	@Test
	public void testGivenInquireDeviceWhenSearchContainsDeviceIdThenResponseContainsRequestedDeviceDetailsWithAppsInstalledAndHttpStatusCode200() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());	   
	    assertThat(responseBody, allOf(containsString(deviceId)));
	}	
	
	@Test
	public void testGivenInquireDeviceWhenSearchContainsImeiThenResponseContainsRequestedDeviceDetailsAndHttpStatusCode200() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody, allOf(containsString(imei)));	   
	}	
	
	
	@Test
	public void testGivenInquireDeviceWhenSearchContainsPageSizeThenResponseReturnsRequestedPageSize() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireDeviceWhenSearchContainsPageNumberThenResponseReturnsRequestedPageNumber() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireDeviceWhenDeviceDetailsAreReturnedThenResponseContainsDeviceIdDeviceNameEmailDeviceStatusPlatformImei() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody, allOf(containsString("deviceId")));
	    assertThat(responseBody, allOf(containsString("deviceName")));
	    assertThat(responseBody, allOf(containsString("email")));
	    assertThat(responseBody, allOf(containsString("deviceStatus")));
	    assertThat(responseBody, allOf(containsString("platformName")));
	    assertThat(responseBody, allOf(containsString("imei")));	    
	    
	}	
	

	@Test
	public void testGivenInquireDeviceWhenAuthorizationTokenIsInvalidThenReturnUserUnauthorizedErrorAndHttpStatusCode_401() throws Exception{
		headers.set("authorization", "Basic 123");
		executeGet();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenInquireDeviceWhenUnExpectedErrorOccursThenResponseContainsErrorMessageAndHttpStatusCode_500() throws Exception{
		headers.set("accountpassphrase", "23232");
		executeGet();		
	    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}

	@Test
	public void testGivenInquireDeviceWhenRequestContainsInvalidDeviceIdThenResponseContainsNoDeviceDetails() throws Exception{		
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());	    
	    assertThat(responseBody, allOf(containsString("")));

	}

	@Test
	public void testGivenInquireDeviceWhenRequiredFieldsAreMissingInHeaderThenReturnInvalidRequestError() throws Exception{
		headers.set("authorization", "");
		headers.set("accountpassphrase", "");
		headers.set("emmproductcode", "");
		executeGet();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
}
