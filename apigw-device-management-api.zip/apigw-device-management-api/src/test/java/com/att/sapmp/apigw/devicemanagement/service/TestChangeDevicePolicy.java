package com.att.sapmp.apigw.devicemanagement.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.att.sapmp.apigw.devicemanagement.service.TestBase;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestChangeDevicePolicy extends TestBase{
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.platform}")
	private String platform;
	
	@Value("${test.passcodePolicyCode}")
	private String passcodePolicyCode;		
	
	@Value("${test.securityPolicyCode}")
	protected String securityPolicyCode;	
	
	@Value("${test.ibm.change.policy.basePath}")
	protected String basePath;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
        requestJson = requestJson.replaceAll("\\$\\{platform\\}", platform);    
        requestJson = requestJson.replaceAll("\\$\\{passcodePolicyCode\\}", passcodePolicyCode);   
        requestJson = requestJson.replaceAll("\\$\\{securityPolicyCode\\}", securityPolicyCode);  
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
	}
	
	@Override
	protected String getBasePath() {
		return basePath;
	}
	
	
	@Test
	public void testGivenChangePolicyRequestWhenDeviceIdIsMissingInRequestThenReturnInvalidRequestError() {
		basePath= "/devices/changepolicy";
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	
	}
    
	@Test
	public void testGivenChangePolicyRequestWhenEmmAccountIdIsMissingInRequestThenReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenChangePolicyRequestWhenPlatformIsMissingInRequestThenReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenChangePolicyRequestWhenPasscodePolicyCodeIsMissingInRequestThenReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));		
	}

	@Test
	public void testGivenChangePolicyRequestWhenSecurityPolicyCodeIsMissingInRequestThenReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenPasscodePolicyCodeWhenPolicyCodeValueNotIn_PN_PB_PS_ThenThenReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenSecurityPolicyCodeWhenSecurityCodeValueNotIn_SE_SB_ThenThenReturnInvalidRequestError() throws Exception{
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenValidChangePolicyWhenChangePolicyRequestIsSuccessThenResponseContainsHttpStatusCode_202() throws Exception{
		
		executePost();		
	    assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	    //TO  DO - response is coming null, incomplete
	}

	@Test
	public void testGivenChangePolicyWhenChangePolicyRequestIsInvalidThenResponseContainsHttpStatusCode_400() throws Exception{		
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("error"), containsString("message")));
	}

	@Test
	public void testGivenChangePolicyWhenAuthorizationTokenIsInvalidThenReturnUserUnauthorizedErrorAndHttpStatusCode_401() throws Exception{
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenChangePolicyWhenUnExpectedErrorOccursThenResponseContainsErrorMessageAndHttpStatusCode_500() throws Exception{
		// Need to test Manually - in application.properties file set to apigw.device.base.url=http://localhost:5050 i.e. wrong port
		/*executePost();		
	    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());*/		
	}

	//@Test
	//Needs to be manually tested 
	public void testGivenValidChangePolicyWhenChangePolicyRequestIsSuccessThenDeviceActivityLogContainsTransactionDetails() throws Exception{
		executePost();		
	    assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());	    
	}

	@Test
	public void testGivenChangePolicyRequestWhenRequestContainsInvalidDeviceIdOrPolicyCodeThenTransactionFailsResponseContainsErrorMessage() {
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("E1001"), containsString("description")));
	}

	
	@Test
	public void testGivenChangePolicyRequestWhenRequiredFieldsAreMissingInHeaderThenReturnInvalidRequestError() throws Exception{
		headers.set("authorization", "");
		headers.set("accountpassphrase", "");
		headers.set("emmproductcode", "");
		executePost();		
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
}
