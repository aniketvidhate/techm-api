package com.att.sapmp.apigw.devicemanagement.service.rs;


import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;

@AjscService
public class InquireDevicesRestServiceImpl implements InquireDevicesRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InquireDevicesRestServiceImpl.class);

	public InquireDevicesRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@GET 
	public void getDevices(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid, @DefaultValue("{\"emmAccountId\":\"30058930\"}")@QueryParam("searchcriteria") String searchcriteria){
		log.info("Received request in InquireDevices API. searchcriteria="+searchcriteria);
	}

}
