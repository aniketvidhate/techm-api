package com.att.sapmp.apigw.devicemanagement.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)

@ApiModel(value = "ChangePolicy", description = "ChangePolicy - input payload")
public class ChangePolicy {

	  @JsonProperty
	  private String emmAccountId;
	  @JsonProperty
	  private String platform;
	  @JsonProperty
	  private String passcodePolicyCode;
	  @JsonProperty
	  private String securityPolicyCode;
	  @ApiModelProperty(value = "emmAccountId", example = "30058930")
	  public String getEmmAccountId() { return this.emmAccountId; }

	  public void setEmmAccountId(String emmAccountId) { this.emmAccountId = emmAccountId; }

	public String getPlatform() {
		return platform;
	}
	@ApiModelProperty(value = "platform", example = "Android")
	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getPasscodePolicyCode() {
		return passcodePolicyCode;
	}
	@ApiModelProperty(value = "passcodePolicyCode", example = "PB")
	public void setPasscodePolicyCode(String passcodePolicyCode) {
		this.passcodePolicyCode = passcodePolicyCode;
	}

	public String getSecurityPolicyCode() {
		return securityPolicyCode;
	}
	@ApiModelProperty(value = "securityPolicyCode", example = "SB")
	public void setSecurityPolicyCode(String securityPolicyCode) {
		this.securityPolicyCode = securityPolicyCode;
	}
	 
	 
	

}
