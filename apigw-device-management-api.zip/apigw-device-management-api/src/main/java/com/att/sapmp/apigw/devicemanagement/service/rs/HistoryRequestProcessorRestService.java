package com.att.sapmp.apigw.devicemanagement.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Inquire Device Action History")

@Produces({ MediaType.APPLICATION_JSON })
public interface HistoryRequestProcessorRestService {

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/history")
	@ApiOperation(value = "Supports searching device action history for a single device.",
	notes =  "Get the activities and actions performed related to single device under a tenant account id."
	)

	
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ok"),
			@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
			@ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Server error") })
	
	public void getHistory(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@DefaultValue("{\"emmAccountId\":\"30058930\",\"deviceId\": \"Android8975435a538e6db6\",\"actionExecutionTimeFrom\":\"2015-11-30T05:52:53\",\"actionExecutionTimeTo\":\"2017-10-09T05:52:53\"}")@QueryParam("searchcriteria") String searchcriteria);


}
