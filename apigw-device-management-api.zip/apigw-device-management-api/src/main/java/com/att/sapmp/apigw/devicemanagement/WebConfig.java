package com.att.sapmp.apigw.devicemanagement;

import java.io.IOException;
import java.util.Properties;

import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.apache.velocity.runtime.RuntimeConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ui.velocity.VelocityEngineFactory;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.velocity.VelocityLayoutViewResolver;

@Configuration
public class WebConfig {

	@Bean
	public WebMvcConfigurerAdapter forwardToIndex() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addViewControllers(ViewControllerRegistry registry) {
				registry.addViewController("/swagger").setViewName("redirect:/mvc/swagger/index.html");
			}
		};
	}
	
	
	/* Velocity Engine configuration */
	
	

	@Value("${spring.velocity.prefix}")
	private String vtplPrefix;
	
	
	@Bean
	public VelocityEngine getVelocityEngine() throws VelocityException, IOException {

		VelocityEngineFactory factory = new VelocityEngineFactory();
		Properties props = new Properties();
		props.put(RuntimeConstants.RESOURCE_LOADER, "classpath");
		props.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
		factory.setVelocityProperties(props);
		return factory.createVelocityEngine();
	}


	@Bean
	public ViewResolver viewResolver() {
		 final VelocityLayoutViewResolver velocitybean = new VelocityLayoutViewResolver();
		velocitybean.setCache(true);
		velocitybean.setPrefix(vtplPrefix);
		velocitybean.setSuffix(".vm");
		velocitybean.setOrder(1);
		return velocitybean;
	}

}

