package com.att.sapmp.apigw.devicemanagement.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONException;
import org.json.JSONObject;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devicemanagement.exception.ApigwException;
import com.att.sapmp.apigw.devicemanagement.exception.CErrorDefs;
import com.att.sapmp.apigw.devicemanagement.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DeviceManagementResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceManagementResponseProcessor.class);

	public final void handleResponse(Exchange e) throws ApigwException {

		String respBody = e.getIn().getBody(String.class);
		e.getOut().setHeaders(e.getIn().getHeaders());
		log.info("Received response in DeviceManagementResponseProcessor handleResponse method with HttpResponseCode:: "
				+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) + " :: Body::" + respBody);
		e.getOut().setBody(respBody);
		JSONObject responseObejectJSON = new JSONObject();
		try {
			responseObejectJSON = new JSONObject(respBody);
		} catch (JSONException jsex) {
			log.error("DeviceManagementResponseProcessor Exception occurred while parsing response: "
					+ jsex.getMessage());
		}
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> deResponseDetailsMap = null;
		try {
			deResponseDetailsMap = objectMapper.readValue(responseObejectJSON.toString(), HashMap.class);
		} catch (IOException e1) {
			log.error("Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		getDeviceActivity(e, deResponseDetailsMap);

	}

	private void getDeviceActivity(Exchange e, Map<String, Object> hmDeResponseDetails) {
		String deviceAction = "";
		String reqUrl = (String) e.getIn().getHeader(CommonDefs.CAMEL_HTTP_URI);
		String[] urlArr = reqUrl.split(CommonDefs.FORWARD_SLASH);
		e.getOut().setHeader(CommonDefs.DEVICE_ID, urlArr[urlArr.length - 2]);
		String requestAction = urlArr[urlArr.length - 1];
		deviceAction = getDeviceAction(e,requestAction);
		if (hmDeResponseDetails != null && !(hmDeResponseDetails.isEmpty())) {
			e.setProperty(CommonDefs.DESCRIPTION,deviceAction + CommonDefs.HYPEN_SEPARATOR + String.valueOf(hmDeResponseDetails.get(CommonDefs.DESCRIPTION)));
		} else {
			e.setProperty(CommonDefs.DESCRIPTION, deviceAction + CommonDefs.HYPEN_SEPARATOR + CommonDefs.ACTIVITY_DETAILS_ERROR);
		}
	}

	private String getDeviceAction(Exchange e, String requestAction) {
		 String deviceAction="";
		if (requestAction.equalsIgnoreCase(CommonDefs.LOCK_REQUEST_ACTION)) {
			deviceAction = CommonDefs.ACTION_LOCK_DEVICE;
			e.getOut().setHeader(CommonDefs.DEVICE_ACTIVITY_TYPE, CommonDefs.ACTIVITY_TYPE_LOCK_DEVICE);
		} else if (requestAction.equalsIgnoreCase(CommonDefs.WIPE_REQUEST_ACTION)) {
			if (String.valueOf(e.getIn().getHeader(CommonDefs.WIPE_TYPE)).equals(CommonDefs.ONE)) {
				deviceAction = CommonDefs.ACTION_SELECTIVE_WIPE_DEVICE;
			} else {
				deviceAction = CommonDefs.ACTION_FULL_WIPE_DEVICE;
			}
			e.getOut().setHeader(CommonDefs.DEVICE_ACTIVITY_TYPE, CommonDefs.ACTIVITY_TYPE_WIPE_DEVICE);
		} else if (requestAction.equalsIgnoreCase(CommonDefs.CHANGE_POLICY_REQUEST_ACTION)) {
			deviceAction = CommonDefs.ACTION_CHANGE_DEVICE_POLICY;
			e.getOut().setHeader(CommonDefs.DEVICE_ACTIVITY_TYPE, CommonDefs.ACTIVITY_TYPE_CHANGE_DEVICE_POLICY);

		}
		return deviceAction;
	}

}
