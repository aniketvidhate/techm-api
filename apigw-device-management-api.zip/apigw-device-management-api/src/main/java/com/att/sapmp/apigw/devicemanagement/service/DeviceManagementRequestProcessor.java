
package com.att.sapmp.apigw.devicemanagement.service;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devicemanagement.exception.ApigwException;

@Component
public class DeviceManagementRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceManagementRequestProcessor.class);

	public final void execute(Exchange e) throws ApigwException {
		String reqBody = e.getIn().getBody(String.class);
		log.info("Received request in DeviceManagementRequestProcessor :: " + reqBody);
	}
}