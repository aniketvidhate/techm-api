package com.att.sapmp.apigw.devicemanagement.service.rs;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devicemanagement.model.LockDevice;

import io.swagger.annotations.ApiParam;

public class LockDeviceRestServiceImp implements LockDeviceRestService {
	/*
	 * @Autowired InitializationService is;
	 */

	public LockDeviceRestServiceImp() {
		// needed for autowiring
	}

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(LockDeviceRestServiceImp.class);

	@Override
	@POST
	public void lockDevice(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@PathParam("deviceId") String deviceId , @ApiParam(value = "Lock Device Request Object", required = true) @RequestBody LockDevice lockDevice) {

		log.info("Received request for Locking Device API. deviceId=" + deviceId);

	}

}
