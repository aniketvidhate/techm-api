package com.att.sapmp.apigw.devicemanagement.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devicemanagement.exception.ApigwException;
import com.att.sapmp.apigw.devicemanagement.util.CommonDefs;
import com.att.sapmp.apigw.devicemanagement.util.CommonUtil;

@Component
public class CsiManageDeviceDetailsProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CsiManageDeviceDetailsProcessor.class);
	@Autowired
	CommonUtil commonUtil;
	public final void execute(Exchange e) throws ApigwException {
		e.getOut().setHeaders(e.getIn().getHeaders());
		HashMap<String, Object> csiManageDeviceDetailsMap = new HashMap<>();
		csiManageDeviceDetailsMap.put(CommonDefs.MESSAGE_ID, String.valueOf(e.getProperty(CommonDefs.TRACKING_ID)));
		commonUtil.populateCSIHeader(csiManageDeviceDetailsMap);
		csiManageDeviceDetailsMap.put(CommonDefs.EMM_DEVICE_ID,
				String.valueOf(e.getIn().getHeader(CommonDefs.DEVICE_ID)));
		csiManageDeviceDetailsMap.put(CommonDefs.ACTIVITY_TYPE,
				String.valueOf(e.getIn().getHeader(CommonDefs.DEVICE_ACTIVITY_TYPE)));
		csiManageDeviceDetailsMap.put(CommonDefs.ACTIVITY_CATEGORY, CommonDefs.ACTIVITY_CATEGORY_DEVICE_MANAGEMENT);
		csiManageDeviceDetailsMap.put(CommonDefs.ACTIVITY_DETAILS, e.getProperty(CommonDefs.DESCRIPTION));
		csiManageDeviceDetailsMap.put(CommonDefs.SOURCE, CommonDefs.SAPMP_GW);
		csiManageDeviceDetailsMap.put(CommonDefs.ACTIVITY_DATE, CommonUtil.getGMTdatetimeAsString());
		VelocityContext velocityContext = new VelocityContext(csiManageDeviceDetailsMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	public final void handleCsiManageDeviceDetailResponse(Exchange e) throws ApigwException {
		String body = e.getIn().getBody(String.class);
		log.info(
				"CsiManageDeviceDetailsProcessor received ResponseCode in handleCsiManageDeviceDetailResponse method ::"
						+ e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		
		commonUtil.logXML("Received response in handleCsiManageDeviceDetailResponse method", body);
		
		Map<String, String> bodyMap = new HashMap<>();
		bodyMap.put(CommonDefs.DEVICE_ID, String.valueOf(e.getProperty(CommonDefs.DEVICE_ID)));
		bodyMap.put(CommonDefs.IMEI, String.valueOf(e.getProperty(CommonDefs.IMEI)));
		VelocityContext velocityContext = new VelocityContext(bodyMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		e.getIn().setBody("");
	}

}