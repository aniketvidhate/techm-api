package com.att.sapmp.apigw.devicemanagement.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "emmAccountId", "wipeType"})
@ApiModel(value = "Wipedevice", description = "WipeDevice - input payload")
public class WipeDevice {

	  @JsonProperty
	  private String emmAccountId;
	  @ApiModelProperty(value = "emmAccountId", example = "30058930")
	  public String getEmmAccountId() { return this.emmAccountId; }

	  public void setEmmAccountId(String emmAccountId) { this.emmAccountId = emmAccountId; }
	  @JsonProperty
	  private String wipeType;
	  @ApiModelProperty(value = "wipeType", example = "0")
	  public String getWipeType() { return this.wipeType; }

	  public void setWipeType(String wipeType) { this.wipeType = wipeType; }
	

}
