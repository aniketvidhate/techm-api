package com.att.sapmp.apigw.devicemanagement.service.rs;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devicemanagement.model.ChangePolicy;

import io.swagger.annotations.ApiParam;

@AjscService
public class ChangeDevicePoliciesRestServiceImp implements ChangeDevicePoliciesRestService {

	public ChangeDevicePoliciesRestServiceImp() {
		// needed for autowiring
	}

	@Autowired
	ChangeDevicePoliciesRestService is;
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ChangeDevicePoliciesRestServiceImp.class);

	@POST
	@Override

	public void changeDevicePolicies(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@PathParam("deviceId") String deviceId , @ApiParam(value = "Change Devive Policy Request Object", required = true) @RequestBody ChangePolicy changePolicy) {
		log.info("Received request in MdmAuthToken API. deviceId=" + deviceId);

	}

}
