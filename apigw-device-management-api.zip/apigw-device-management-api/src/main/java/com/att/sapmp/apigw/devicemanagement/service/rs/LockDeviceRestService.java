package com.att.sapmp.apigw.devicemanagement.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.sapmp.apigw.devicemanagement.model.LockDevice;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Lock Device")
@Produces({ MediaType.APPLICATION_JSON })
public interface LockDeviceRestService {

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{deviceId}/lock")
	@ApiOperation(
			value = "Supports locking the device.",
			notes = "This operation will lock the device and can be executed on an iOS, Android or Windows phone."
					
			
	)

	@ApiResponses(
			value = {
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 204, message = "No Content"),
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void lockDevice(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@PathParam("deviceId") String deviceId , @ApiParam(value = "Lock Device Request Object", required = true) @RequestBody LockDevice lockDevice);
	
	
}
