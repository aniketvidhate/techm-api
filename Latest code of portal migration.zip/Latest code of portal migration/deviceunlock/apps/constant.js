/**
 * @Author 		:- Aniket Vidhate (av0041)   
 * Date			:- 12-7-2015
 * File name 	:- constant.js
 */

url = {


		/*//staging
	imageCaptchaImage : "/apis/deviceunlock/unlockCaptcha/image",
    audioCaptchaImage : "/apis/deviceunlock/unlockCaptcha/sound",
    unlockStepPostURL : "/apis/deviceunlock/OCEUnlockOrder/orderFlow",
    unlockStatusURL   : "/apis/deviceunlock/UnlockOrder/unlockOrderStatus",
    emailSecureDomain : "/apis/deviceunlock/UnlockUtility/Verify/ValidateEmail",
    OCEverifyEmail    : "/apis/deviceunlock/OCEUnlockOrder/Verify/VerifyEmail"

//Nulufer
    imageCaptchaImage : "http://135.198.154.218:8181/apis/deviceunlock/unlockCaptcha/image",
    audioCaptchaImage : "http://135.198.154.218:8181/apis/deviceunlock/unlockCaptcha/sound", 
    unlockStepPostURL : "http://135.198.154.218:8181/apis/deviceunlock/OCEUnlockOrder/orderFlow",
    unlockStatusURL   : "http://135.198.154.218:8181/apis/deviceunlock/UnlockOrder/unlockOrderStatus",
    emailSecureDomain : "http://135.198.154.218:8181/apis/deviceunlock/UnlockUtility/Verify/ValidateEmail",
    OCEverifyEmail    : "http://135.198.154.218:8181/apis/deviceunlock/OCEUnlockOrder/Verify/VerifyEmail",
    resendEmailURL    :	"http://135.198.154.218:8181/apis/deviceunlock/UnlockOrder/unlockOrderSendEmailNotification"
*/
	imageCaptchaImage : "http://10.13.69.85:8181/apis/deviceunlock/unlockCaptcha/image",
    audioCaptchaImage : "http://10.13.69.85:8181/apis/deviceunlock/unlockCaptcha/sound",
    unlockStepPostURL : "http://10.13.69.85:8181/apis/deviceunlock/OCEUnlockOrder/orderFlow",
    unlockStatusURL   : "http://10.13.69.85:8181/apis/deviceunlock/UnlockOrder/unlockOrderStatus",
    emailSecureDomain : "http://10.13.69.85:8181/apis/deviceunlock/UnlockUtility/Verify/ValidateEmail",
    OCEverifyEmail    : "http://10.13.69.85:8181/apis/deviceunlock/OCEEmailVerification/Verify/VerifyEmail"	
    	
}

