

   var browserCookie = $.cookie('browserid');
   if(!browserCookie) {
      var date = new Date();
      var browserUniqueId = "SCQ" + date.setTime(date.getTime() + 1);
      try {
         $.cookie.raw=true;
         $.cookie('browserid', browserUniqueId, {
            expires: 365,
            domain: '.att.com',
            path: '/'
         });
      } catch (e) {
         if (window.console){
            console.log("error in creating default browserid cookie: " + e.message);
         }
      }
   }
   
