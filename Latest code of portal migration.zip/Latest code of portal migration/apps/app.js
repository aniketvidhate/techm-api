/**
 * @Author 		:- Aniket Vidhate (av0041)   
 * Date			:- 12-7-2015
 * File name 	:- app.js
 */

var unlockPortal = angular.module('unlockPortal',['ngRoute', 'ngCookies', 'ngSanitize','ui.bootstrap']);



unlockPortal.config(function($routeProvider){
    $routeProvider.
	when('/',{
        templateUrl:'/deviceunlock/html/nextsteplinks.html',
        controller:'reqController'
    }).
    when('/unlockstep1',{
        templateUrl:'/deviceunlock/html/attunlockStep1FormComponent.html',
        controller:'step1Ctrl'
    }).
    when('/unlockstep2',{
        templateUrl: '/deviceunlock/html/attunlockStep2FormComponent.html',
        controller:'step2Ctrl'
    }).
    when('/unlockstep3',{
        templateUrl: '/deviceunlock/html/attunlockStep3FormComponent.html',
        controller:'step3Ctrl'
    }).
    when('/nonattunlock',{
        templateUrl: '/deviceunlock/html/nonATTSubmitComponent.html',
        controller:'nonAttCtrl'
    }).
    when('/thankyou',{
        templateUrl: '/deviceunlock/html/thankyouComponent.html',
        controller:'thankYouCtrl' 
    }).
    when('/error',{
        templateUrl: '/deviceunlock/html/systemerror.html',
        controller:'errorCtrl' 
    }).
    when('/status',{
        templateUrl: '/deviceunlock/html/status.html',
        controller:'statusCtrl' 
    }).
    when('/statusresponse',{
        templateUrl:'/deviceunlock/html/requeststatus.html',
        controller:'statusResponseCtrl' 
    }).
    when('/email',{
        templateUrl:'/deviceunlock/html/emailVerify.html',
        controller:'emailController' 
    }).
    when('/emailconfirmationsuccess',{
        templateUrl:'/deviceunlock/html/emailconfirmationsuccess.html',
        controller:'emailSuccessController' 
    }).
    when('/emaillinkexpired',{
        templateUrl:'/deviceunlock/html/emaillinkexpired.html',
        controller:'emailLinkExpiredController' 
    }).
    /*otherwise({
    redirectTo:'/unlock'
    });*/
    otherwise({
        redirectTo:'/'
    });


});


unlockPortal.run(function($rootScope, $route, $location,$window) {
	window.scrollTo(0,0);
    $rootScope.$on('$locationChangeStart', function(ev, next, current) {
        //Setting page name value form edd doc
        var wtPN = "";
        if ($location.path().indexOf('/') == '0') {
            wtPN = "Consumer Device Unlock Portal Pg";
        }
        if ($location.path().indexOf('/unlockstep1') == '0') {
            wtPN = "Device Unlock Portal Information step 1 Pg";
        }
        if ($location.path().indexOf('/unlockstep2') == '0') {
            wtPN = "Device Unlock Portal Information step 2 Pg";
        }
        if ($location.path().indexOf('/unlockstep3') == '0') {
            wtPN = "Device Unlock Portal Information step 3 Pg";
        }
        if ($location.path().indexOf('/nonattunlock') == '0') {
            wtPN = "Device Unlock Portal Information non att submit Pg";
        }
		 if ($location.path().indexOf('/thankyou') == '0') {
            wtPN = "Device Unlock Portal Thank You Pg";
        }
        if ($location.path().indexOf('/error') == '0') {
            wtPN = "Device Unlock Portal error Pg";
        }
        if ($location.path().indexOf('/status') == '0') {
            wtPN = "Device Unlock Portal status Pg";
        }
		if ($location.path().indexOf('/statusresponse') == '0') {
            wtPN = "Device Unlock Portal status response Pg";
        }
		 if ($location.path().indexOf('/email') == '0') {
            wtPN = "Device Unlock Portal email Pg";
        }
        if ($location.path().indexOf('/emailconfirmationsuccess') == '0') {
            wtPN = "Device Unlock Portal email confirmation success Pg";
        }
        if ($location.path().indexOf('/emaillinkexpired') == '0') {
            wtPN = "Device Unlock Portal email link expired Pg";
        }

        //Calling web trends function at page load
        webtrendsPageHitCapture(wtPN, current);


        //checking url on location change start
        if ($location.path().indexOf('/unlockstep1') == '0' || $location.path().indexOf('/unlockstep2') == '0'
           	|| $location.path().indexOf('/unlockstep3') == '0' || $location.path().indexOf('/nonattunlock') == '0'
           	|| $location.path().indexOf('/thankyou') == '0' || $location.path().indexOf('/error') == '0') {

            //checking cookies while accesing unlock request page
            if ((sessionStorage.getItem("hasReadTerms") == 'yes' && sessionStorage.getItem("agreeCheckedBox") == 'yes')||(sessionStorage.getItem("errorPage") == 'yes')) {
                //user can access unlock request page
                //console.log("tearm & condition checked");
            } else {
                //redirecting user to portal entry page
        	//	$window.location.href = '/deviceunlock/#/';
            }

        } 
    });
});


