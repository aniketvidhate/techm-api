/**
 * @Author 		:- Aniket Vidhate (av0041)   
 * Date			:- 12-7-2015
 * File name 	:- services.js
 */

unlockPortal.factory('services', function($http) {

    var respAPI = {};

   respAPI.postService = function(url, dataJson) {
		return $http({
            method: 'POST',
            url: url,
            data: dataJson
        });
    }




    //code for status
    respAPI.getStatus = function(url){
		//console.log("url in service => ",url);
        return $http.get(url);
    };



    /*
	//To check the ATT wireless no. for fraud activity
    respAPI.FraudulentCheckService = function(attWirelessNo) {
		console.log("attWirelessNo ** ==>"+attWirelessNo);
        return $http.get('/etc/demo/FraudulentCustomer.json');
    }

	//To check the IMEI no. for exists in the list
	respAPI.IMEICheckService = function(imeiReq) {
		console.log("imeiReq ** ==>"+imeiReq);
      return $http.get('/etc/demo/IMEILookup.json', imeiReq);
      /* var a= $http({
            method: 'POST',
            url: 'D:\project\IRU_Unlock_V\V2\IRU_Unlock_Portal\IRU_Unlock_Portal\data\IMEILookup.json',
            data: { imeiReq:imeiReq }

        });
        alert("hello"+a.IMEI);
        return a;*/

    /*}

    //To get the captcha image
    respAPI.captchaGetService = function() {
      return $http.get('http://10.5.74.73:8181/apis/deviceunlock/unlockCaptcha/image/1');
    }
*/


	return respAPI;
  });

unlockPortal.factory('tooltipUtility',function(){
    var tooltip = {};
    
    tooltip.show = function(obj){
        if(window.innerWidth<=767){
           // on mobile
            $(obj.target).closest('.form-group').find('.help_tip').css({display:'block'});
         }else{
             if( $(obj.target).attr('id') == "nonAttImg"){
                $(obj.target).closest('.form-group').find('.help_tip').css({display:'block',position : 'fixed',top : $(obj.target).offset().top - 111 + 'px', left : $(obj.target).offset().left - 100  + 'px'});
             }else{
               $(obj.target).closest('.form-group').find('.help_tip').css({display:'block',position : 'fixed',top : $(obj.target).offset().top - $(obj.target).closest('.form-group').find('.help_tip').height() - 32 + 'px', left : $(obj.target).offset().left - 100  + 'px'});
            }
            

         } 
        
    }
    tooltip.hide = function(obj){       
       $(obj.target).closest('.form-group').find('.help_tip').css({display:'none'});
    }
return tooltip;
});