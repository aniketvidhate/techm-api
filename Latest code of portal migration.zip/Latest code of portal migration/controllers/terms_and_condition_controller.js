/**
 * @Author 		:- Aniket Vidhate (av0041)   
 * Date			:- 16-8-2015
 * File name 	:- terms_and_condition_controller.js
 */

//Unlock TermsandCondition Controller - S
unlockPortal.controller('termsandcondition', ['$scope', '$rootScope', '$http', 'services', '$sce', '$window', '$location', function($scope, $rootScope, $http, services, $sce, $window, $location){

	//console.log("in terms and condition controller");
    $("#firstBorder, #commonNoteArea, #allRequired").removeClass("divShow").addClass("divHide");
    $scope.isVaild = false;
	$rootScope.isReadAndAgreeTermsAndCondition = false;

    $scope.checkCondition = function()
	{
        //console.log('checked terms and condition checkbox');
        //console.log("agreeCheckBox"+$scope.agreeCheckBox);
        if($scope.agreeCheckBox === true){
            $scope.isVaild = true;
        }else{
            $scope.isVaild = false;
            $rootScope.isReadAndAgreeTermsAndCondition = false;
        }
    }



    $scope.agreeTermsAndConditon = function()
	{
        if($scope.agreeCheckBox === true && $scope.isVaild === true){
			$rootScope.isReadAndAgreeTermsAndCondition = true;
            $location.path('unlockstep1').replace();
			window.scrollTo(0, 0);
        }
         //console.log('agreeTermsAndConditon');

    }

}]);
//Unlock TermsandCondition Controller - E