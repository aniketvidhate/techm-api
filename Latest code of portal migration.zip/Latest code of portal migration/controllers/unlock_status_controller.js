/**
 * @Author 		:- Reema Rao (rr512r) / Aniket Vidhate (av0041)
 * Date			:- 12-7-2015
 * File name 	:- unlock_status_controller.js
 */

//Unlock status Controller - S
unlockPortal.controller('statusCtrl', ['$scope', '$rootScope', '$http','services','tooltipUtility', '$sce','$location', function($scope, $rootScope, $http, services,tooltipUtility, $sce, $location){
    //console.log("in status controller");
    $("#firstBorder, #commonNoteArea, #checkStatus, #checkStatusBar, #newOrderSeparator, #newOrder, #headercru").removeClass("divShow").addClass("divHide");
	angular.element("#IRUCRUHeader, #headeriru").show();
    $("#statuscommonNoteArea").addClass("divShow");
    angular.element("#pageheader").css('display','none');	//hide Device unlock header when showing status page header

	
	$scope.getEnglishContent = function(){
		var statEntryURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json";
		services.getStatus(statEntryURL)
		.success(function(jsonData) {
			$rootScope.data = jsonData.unlockPortalLabelAndErrorObj[0];
		});	
	}
	
	if($rootScope.data == undefined)
	{
		$scope.getEnglishContent();
	}

    //variable intialization for OCE
    $rootScope.unlockStatusURL = url.unlockStatusURL;
    $rootScope.isOG = false;
    $rootScope.unlockCodeView = false;
    $rootScope.tmflag = false;
    $rootScope.isunlockCode = false;

   	$scope.statusFlag = true;

    $scope.apiError = false;
    $rootScope.commonError = false;
    
    $rootScope.statusResponse = {
        "orderStatus": "",
        "orderNumber": "",
        "imei": "",
        "orderSubmissionDate": "",
        "unlockcode": "",
        "unlockinstruction": ""
    };
    $scope.reqNoAlphanumeric = false;

    $scope.reqNoReqErr = false;
    $scope.isVaild = false;
    var isValidImei = false;
    var isValidReqNo = false;

   //variable intialization for OG
    $scope.leadMessage;
    $scope.sysMessage;
    $scope.trailMessage;
    $scope.keySpecs; 

	//IE
    if (isIE () == 8) {
        $rootScope.ie8 = true;
    }


    //check validation for IMEI no and Request no - S
    $scope.onFocusImei = function(){
        //console.log("onFocusImei function called");
        $scope.imeiErrorMsg = "";
        $scope.imeiError = false;
        $scope.imeiReqErr = false;
        $scope.imeiLengthErr = false;
    };

    
    $scope.getImei = function(){
        //console.log("getImei function called"+$scope.imei);        
        if($scope.imei == undefined || $scope.imei == "" || $scope.imei.length < 15){
            validationImeiNo();
            isValidImei = false;
        }else{
            isValidImei = true;
        }
        isAllValid();
        //console.log("$scope.isValidImei : ",isValidImei);
    };

    
    $scope.onFocusReqNo = function(){
       // console.log("onFocusReqNo function called");
        $scope.reqNoReqErr = false;
    };

	$scope.showTooltip = function(obj){
		   tooltipUtility.show(obj);
	 }
	$scope.hideTooltip = function(obj){
	  tooltipUtility.hide(obj);
	}
    
    
    $scope.getReqNo = function(){       
        //console.log("getReqNo function called"+$scope.requestNumber);       
        if($scope.requestNumber == undefined || $scope.requestNumber == ""){
			$scope.reqNoReqErr = true;
            isValidReqNo = false;
        }
        else{
			if($scope.requestNumber.length>3){
                isValidReqNo = true;
            }
            else{
                $scope.reqNoReqErr = true;
                isValidReqNo = false;
            }
        }
        isAllValid();
        //console.log("$scope.isValidReqNo : ",isValidReqNo);
    };

    $scope.validImeiNo = function(keyEvent){
        if($scope.imei != undefined || $scope.imei != ""){
            if($scope.imei.length < 15){
				isValidImei = false;
            }
            else{
				isValidImei = true;
            }
        }
        isAllValid();
    };

    $scope.validReqNo = function(keyEvent){
        if($scope.requestNumber == undefined || $scope.requestNumber == ""){
			isValidReqNo = false
        }
        else{
			if($scope.requestNumber.length>3){
                isValidReqNo = true;
            }
            else{
                isValidReqNo = false;
            }
        }
        isAllValid();
        //console.log("$scope.isValidReqNo : ",isValidReqNo);
    };

    
    isAllValid = function(){
        if(isValidImei && isValidReqNo){
            $scope.isVaild = true;
        }
        else{
            $scope.isVaild = false;
        }
    };

	function validationImeiNo(){
        //console.log("validationimeiNo function called => ");
		if($scope.imei == undefined || $scope.imei == ""){
			$scope.imeiReqErr = true;
		}else if($scope.imei.length < 15){
			$scope.imeiLengthErr = true;
         }
	};


    //check validation for IMEI no and Request no - E

    
    // Base64 decoding OG - S
    var Base64 = {
        
        _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
        
        encode: function(input) {
            var output = "";
            var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
            var i = 0;
            
            input = Base64._utf8_encode(input);
            
            while (i < input.length) {
                
                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);
                
                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;
                
                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }
                
                output = output + this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
                
            }
            
            return output;
        },
        
        
        decode: function(input) {
            var output = "";
            var chr1, chr2, chr3;
            var enc1, enc2, enc3, enc4;
            var i = 0;
            
            input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
            
            while (i < input.length) {
                
                enc1 = this._keyStr.indexOf(input.charAt(i++));
                enc2 = this._keyStr.indexOf(input.charAt(i++));
                enc3 = this._keyStr.indexOf(input.charAt(i++));
                enc4 = this._keyStr.indexOf(input.charAt(i++));
                
                chr1 = (enc1 << 2) | (enc2 >> 4);
                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                chr3 = ((enc3 & 3) << 6) | enc4;
                
                output = output + String.fromCharCode(chr1);
                
                if (enc3 != 64) {
                    output = output + String.fromCharCode(chr2);
                }
                if (enc4 != 64) {
                    output = output + String.fromCharCode(chr3);
                }
                
            }
            
            output = Base64._utf8_decode(output);
            
            return output;
        },
        
        _utf8_encode: function(string) {
            string = string.replace(/\r\n/g, "\n");
            var utftext = "";
            
            for (var n = 0; n < string.length; n++) {
                
                var c = string.charCodeAt(n);
                
                if (c < 128) {
                    utftext += String.fromCharCode(c);
                } else if ((c > 127) && (c < 2048)) {
                    utftext += String.fromCharCode((c >> 6) | 192);
                    utftext += String.fromCharCode((c & 63) | 128);
                } else {
                    utftext += String.fromCharCode((c >> 12) | 224);
                    utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
            }
            
            return utftext;
        },
        
        _utf8_decode: function(utftext) {
            var string = "";
            var i = 0;
            var c = c1 = c2 = 0;
            
            while (i < utftext.length) {
                
                c = utftext.charCodeAt(i);
                
                if (c < 128) {
                    string += String.fromCharCode(c);
                    i++;
                } else if ((c > 191) && (c < 224)) {
                    c2 = utftext.charCodeAt(i + 1);
                    string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                    i += 2;
                } else {
                    c2 = utftext.charCodeAt(i + 1);
                    c3 = utftext.charCodeAt(i + 2);
                    string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                    i += 3;
                }
            }
            
            return string;
        }
        
    }

    // Base64 decoding OG - E


    
	//request status submit - S
    $scope.requestStatus = function(){  
        //console.log("request status function called => ");
        //console.log("$scope.imei  ==> ",$scope.imei);

        var url= ""; 
        
        if($scope.imei == undefined || $scope.imei == ""){
            validationImeiNo();
        }
        else{
           // console.log("in requestStatus() => ");
            openLoader();

            var startReqNo = $scope.requestNumber.substring(0,3);
            
            //console.log("$scope.imei  ==> ",$scope.imei);
            
            if($scope.imei !== "" && $scope.imei !== undefined)
            {
                //post url part
                if ($scope.isVaild) {

                    //OCE OrderNumber Status
                    if(startReqNo == "CUL" || startReqNo == "NUL"){


                        requestJson = {
                            "unlockOrderStatusRequest": {
                                "orderDetail": {
                                    "orderNumber": $scope.requestNumber,
                                    "imei": $scope.imei
                                }
                            }
                        };
                       
                        services.postService($rootScope.unlockStatusURL,requestJson)  
                        .success(function(responseData){
                            
							$rootScope.statusPageResp = responseData;
                            $rootScope.isOCE = true;
                            $scope.errorsArray = [];
                            $scope.statusFlag = false;
                            $rootScope.tmflag = false;
                            $rootScope.isunlockCode = false;
                            $rootScope.systemMessage = undefined;

                            // In case of success response and no validation errors 
                            if(responseData.oceUnlockOrderStatusDO.validationErrors === undefined){

								/*status based on unlock status - S*/
                                if(responseData.oceUnlockOrderStatusDO.unlockStatus == "SYS_RECEIVED"){
									//console.log("unlock status - SYS_RECEIVED");
									$rootScope.statusResponse.orderStatus = "RECEIVED";
                                }
                                else if((responseData.oceUnlockOrderStatusDO.unlockStatus == "SYS_PROCESSING")||(responseData.oceUnlockOrderStatusDO.unlockStatus == "IN_QUEUE")){
									//console.log("unlock status - IN_PROGRESS");
									$rootScope.statusResponse.orderStatus = "In Progress";
                                }
                                else if(responseData.oceUnlockOrderStatusDO.unlockStatus == "PENDING"){
									//console.log("unlock status - PENDING");
									$rootScope.statusResponse.orderStatus = "Pending";
                                }
                                else if(responseData.oceUnlockOrderStatusDO.unlockStatus == "DENIED"){
									//console.log("unlock status - DENIED");
									$rootScope.statusResponse.orderStatus = "Denied";
                                }
                                else if(responseData.oceUnlockOrderStatusDO.unlockStatus == "APPROVED"){
									//console.log("unlock status - APPROVED");
									$rootScope.statusResponse.orderStatus = "Approved";
                                }
                                /*status based on line status - E*/


								//alert(decodeURIComponent("\\nfgdrgfdgfdgd\\rf"));

                                //$rootScope.statusResponse.orderStatus = orderStatus;
                                $rootScope.statusResponse.orderNumber = responseData.oceUnlockOrderStatusDO.orderNumber;
                                $rootScope.statusResponse.imei = $scope.imei;
                                $rootScope.statusResponse.orderSubmissionDate = responseData.oceUnlockOrderStatusDO.orderSubmissionDate;
                                var unlockInstructionStr = responseData.oceUnlockOrderStatusDO.unlockinstruction;

                                if(unlockInstructionStr !== undefined && unlockInstructionStr !== ""){
                                    unlockInstructionStr = decodeURIComponent(unlockInstructionStr);
                                    unlockInstructionStr=unlockInstructionStr.replace(/\\n/g,"\n");
                                    unlockInstructionStr=unlockInstructionStr.replace(/\\r/g,"\r");
                                    unlockInstructionStr=unlockInstructionStr.replace(/\\\"/g,"\"");
                                    $rootScope.statusResponse.unlockinstruction=unlockInstructionStr;
                                }
                                //alert($rootScope.statusResponse.unlockinstruction);


								/*new status and substatuses - S*/
                                if(responseData.oceUnlockOrderStatusDO.unlockStatus == "APPROVED"){
                                    if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "TORCH_APPLE_COMPLETED"){
										//console.log("apple completed status");
                                        $rootScope.leadingMessage = "approved.complete";                                        
										$rootScope.systemMessage = undefined;
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "COMPLETED"){
										//console.log("completed status");
										$rootScope.isunlockCode = true;
                                        if(responseData.oceUnlockOrderStatusDO.unlockCode != undefined){
                                            if(responseData.oceUnlockOrderStatusDO.unlockCode.charAt(0) === 'A'){
                                                $rootScope.statusResponse.unlockcode = responseData.oceUnlockOrderStatusDO.unlockCode.substr(1,responseData.oceUnlockOrderStatusDO.unlockCode.length);
                                            }
                                            else{
                                                $rootScope.statusResponse.unlockcode = responseData.oceUnlockOrderStatusDO.unlockCode;
                                            }
                                         }
                                        else{
											$rootScope.statusResponse.unlockcode = "";
                                        }
                                        //$rootScope.statusResponse.unlockcode = responseData.oceUnlockOrderStatusDO.unlockCode;
                                        $rootScope.leadingMessage = "approved.complete";                                        
										$rootScope.systemMessage = undefined;
                                        $rootScope.trailingMessage = undefined;
                                    }
                                }
                                else if(responseData.oceUnlockOrderStatusDO.unlockStatus == "DENIED"){
                                    if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "GOPHONE_COMMITMENT_6_MONTHS"){
										//console.log("Go phone commitment 6 months status");
                                        $rootScope.leadingMessage = undefined;
                                        $rootScope.systemMessage = "denied.gophone";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "IMEI_ACTIVE_OTHER"){
										//console.log("imei active other status");
                                        $rootScope.leadingMessage = undefined;
                                        $rootScope.systemMessage = "denied.imeiactive";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "EMAIL_CONFIRMATION_FAILED"){
										//console.log("email confirmation failed status");
                                        $rootScope.leadingMessage = undefined;                                        
										$rootScope.systemMessage = "denied.emailconfimfailed";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "ATT_NEXT_SERVICE_COMMITMENT_NOT_MET"){
										//console.log("policy validation failed status");
                                        $rootScope.leadingMessage = undefined;                                       
										$rootScope.systemMessage = "denied.attnextservice";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "SUBSIDY_SERVICE_COMMITMENT_NOT_MET"){
										//console.log("policy validation failed status");
                                        $rootScope.leadingMessage = undefined;                                        
										$rootScope.systemMessage = "denied.subsidyservice";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "POLICY_VALIDATION_FAILED"){
										//console.log("policy validation failed status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.policyvalidation";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "NON_ATT_IMEI"){
										//console.log("non att imei status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.nonattimei";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "NON_SUPPORTED_DEVICE"){
										//console.log("non supported device status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.nonsupported";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "UNABLE_TO_VERIFY"){
										//console.log("unable to verify status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.unabletoverify";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "PAST_DUE"){
										//console.log("past due status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.pastdue";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "MILITARY_DOCS_VERIFICATION_FAILED"){
										//console.log("military docs status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.militarydoc";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if((responseData.oceUnlockOrderStatusDO.unlockSubStatus == "FRAUD_SUBSCRIBER") || (responseData.oceUnlockOrderStatusDO.unlockSubStatus == "FRAUD_VELOCITY") || (responseData.oceUnlockOrderStatusDO.unlockSubStatus == "CTN_FRAUD_DATA") || (responseData.oceUnlockOrderStatusDO.unlockSubStatus == "EMAIL_FRAUD_DATA") || (responseData.oceUnlockOrderStatusDO.unlockSubStatus == "EMAIL_DOMAIN_FRAUD_DATA") || (responseData.oceUnlockOrderStatusDO.unlockSubStatus == "IMEI_FRAUD_DATA") || (responseData.oceUnlockOrderStatusDO.unlockSubStatus == "IPADDRESS_THRESHOLD_REACHED") || (responseData.oceUnlockOrderStatusDO.unlockSubStatus == "IMEI_THRESHOLD_REACHED") || (responseData.oceUnlockOrderStatusDO.unlockSubStatus == "BROWSERID_THRESHOLD_REACHED") || (responseData.oceUnlockOrderStatusDO.unlockSubStatus == "CTN_THRESHOLD_REACHED") ||(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "EMAIL_THRESHOLD_REACHED")){
										//console.log("fraud data status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.fraud";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "IN_BRE_PERIOD"){
										//console.log("bre period iru status");
                                        var accType = responseData.oceUnlockOrderStatusDO.accountType;
                                        $rootScope.leadingMessage = undefined; 
                                        if(accType === 'CRU'){
											$rootScope.systemMessage = "denied.breperiodcru";
                                        }
                                        else{
                                            $rootScope.systemMessage = "denied.breperiodiru";
                                        }
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "DATA_NOT_FOUND"){
										//console.log("data not found status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.datanotfound";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "LOST_STOLEN"){
										//console.log("lost stolen status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.loststolen";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "ACCOUNT_ACTIVE_60_DAYS"){
										//console.log("lost stolen status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.accountactive";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "COU_DEVICE"){
										//console.log("lost stolen status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "denied.coudevice";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                }
                                else if(responseData.oceUnlockOrderStatusDO.unlockStatus == "IN_QUEUE" || responseData.oceUnlockOrderStatusDO.unlockStatus == "SYS_PROCESSING"){
									//console.log("in queue and system processing status");
                                    $rootScope.leadingMessage = undefined;                                    
                                    $rootScope.systemMessage = "inqueue.progress";
                                    $rootScope.trailingMessage = undefined;
                                }
                                else if(responseData.oceUnlockOrderStatusDO.unlockStatus == "PENDING"){
									if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "EMAIL_CONFIRMATION"){
										//console.log("pending email confirmation status");
										$rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "pending.emailconfirm";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                    else if(responseData.oceUnlockOrderStatusDO.unlockSubStatus == "MILITARY_PROOF_DOCUMENTS" || responseData.oceUnlockOrderStatusDO.unlockSubStatus == "MILITARY_PROOF_DOCS"){
										//console.log("pending military docs status");
                                        $rootScope.leadingMessage = undefined;                                        
                                        $rootScope.systemMessage = "pending.militarydoc";
                                        $rootScope.trailingMessage = undefined;
                                    }
                                }else{//Default condition is for any unidentified status is received from backend then show the status as it is and default inprogress message
									$rootScope.statusResponse.orderStatus = responseData.oceUnlockOrderStatusDO.orderStatus;
                                    $rootScope.leadingMessage = undefined;                                    
                                    $rootScope.systemMessage = "inqueue.progress";
                                    $rootScope.trailingMessage = undefined;
                                }

                                /*new status and substatuses - E*/

                                $scope.apiError = false;
                                $rootScope.commonError = false;

                                //console.log("$rootScope.statusResponse : ",$rootScope.statusResponse);

                                $location.path('statusresponse').replace();
                                
                            }
							//In case of success response and validation errors 
                            else if(responseData.oceUnlockOrderStatusDO.validationErrors !== undefined || responseData.oceUnlockOrderStatusDO.validationErrors !== ""){

                                $scope.apiError = false;
                                $rootScope.commonError = true;

                                //console.log("responseData.oceUnlockOrderStatusDO.validationErrors : ",responseData.oceUnlockOrderStatusDO.validationErrors);

                                var validationErrors = responseData.oceUnlockOrderStatusDO.validationErrors;

                                  $.each(validationErrors, function(key,value){
									  angular.element("#commonNoteArea, #firstBorder").show();
									  if(window.innerWidth < 1024)
									  {
										  angular.element("#firstPageHeader").hide();
									  }
									  else{
										  angular.element("#firstPageHeader").show();
									  }
                                	  $rootScope.error = $rootScope.data[value.errorCode];
                                      $scope.imei = "";
                                      $scope.requestNumber = "";
                                      $scope.isVaild = false;
                                      isValidImei = false;
                                      isValidReqNo = false;
                                  });
                                closeLoader();

                            }
							//In case of no response 
                            else{
                                //console.log("Error Description : ",responseData.oceUnlockOrderStatusDO.validationErrors);
                                sessionStorage.setItem('errorPage','yes');
                                closeLoader();
								$location.path('error').replace();
                            }
                           // closeLoader();
                        }).error(function(data){
                            //console.log("api error");
                            closeLoader();
                            $rootScope.commonError = false; 
                            isValidImei = false;

//                            $scope.errorsArray = [];
//                            $scope.errorsArray.push("ULP_0000");
                            $rootScope.error = $rootScope.data.ULP_0000;
                            sessionStorage.setItem('errorPage','yes');
							$location.path('/error'); /*fix for jira PROD-14477*/
                        });
                    }
                    
					//OG OrderNumber Status
                    else{

                        initialJson = {
                            "unlockOrderStatusRequest": {
                                "orderDetail": {
                                    "orderNumber": $scope.requestNumber,
                                    "imei": $scope.imei
                                }
                            }
                        };
                        
                        //CALLING WEBTRENDS
                        
                        var dcsuri = "";
                        var wtStatusFlag = '1';
                        var wtStatusCode = '0';
                        var wtEvent = 'myATT_DeviceUnlock_StatusCheck_SUB';

                        //$http.get("/etc/demo/OGstatus_json.json")
                        services.postService($rootScope.unlockStatusURL,initialJson)
                        .success(function(responsedata) {


                            $rootScope.isOCE = false;

                            // server side validation passed
                            if (responsedata.unlockOrderStatusResponse.serviceStatus.code == 0 && responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode == "") {

									$rootScope.tmflag = true;

                                if (typeof(responsedata.unlockOrderStatusResponse.view) != "undefined") {
                                    if ((typeof(responsedata.unlockOrderStatusResponse.view.targetView) != "undefined")) {
                                        
                                        
                                        
                                        // In case of success response and when unlock code is empty. It handles the following status responses: denied,cancelled,inprogress,Request Completed for Iphone
                                        
                                        $scope.keySpecs = responsedata.unlockOrderStatusResponse.view.specification.key;
                                        
                                        
                                        for (i = 0; i < $scope.keySpecs.length; i++) {
                                            if ($scope.keySpecs[i].id == "leadingMessage") {
                                                $scope.leadMessage = $scope.keySpecs[i].text;
                                            }
                                            if ($scope.keySpecs[i].id == "systemMessage") {
                                                $scope.sysMessage = $scope.keySpecs[i].text;
                                            }
                                            if ($scope.keySpecs[i].id == "trailingMessage") {
                                                $scope.trailMessage = $scope.keySpecs[i].text;
                                            }
                                        }


                                        //test code start
                                        $rootScope.statusResponse.orderStatus = responsedata.unlockOrderStatusResponse.view.header;
                                        $rootScope.statusResponse.orderNumber = responsedata.unlockOrderStatusResponse.unlockOrderDetail.orderNumber;
                                        $rootScope.statusResponse.imei = responsedata.unlockOrderStatusResponse.unlockOrderDetail.imei;
                                        $rootScope.statusResponse.orderSubmissionDate = responsedata.unlockOrderStatusResponse.unlockOrderDetail.activityLog.orderSubmitted;
                                        $rootScope.leadingMessage = $scope.leadMessage;
                                       	$rootScope.systemMessage = $scope.sysMessage;
                                        $rootScope.trailingMessage = $scope.trailMessage;

                                        if($rootScope.systemMessage == ""){
											$rootScope.systemMessage = undefined;
                                        }
                                        

                                        //Variables passed to statusController For Complete Status 
                                        $rootScope.instructionMessage = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockDetail.instruction;
                                       // console.log("instructions : ",$rootScope.instructionMessage);
                                        $rootScope.targetView = responsedata.unlockOrderStatusResponse.view.targetView;

                                        wtStatusFlag = '1';
                                        wtStatusCode = '0';
                                        wtEvent = 'myATT_DeviceUnlock_StatusCheck_SUB';

                                        $location.path('statusresponse').replace();
                                        

                                    } else {
										sessionStorage.setItem('errorPage','yes');
                                        closeLoader();
                                        $location.path('error').replace();
                                    }
                                    
                                } else {
									sessionStorage.setItem('errorPage','yes');
                                    closeLoader();
                                    $location.path('error').replace();
                                }
                                
                            } else if (responsedata.unlockOrderStatusResponse.serviceStatus.code == 0 && responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode != "") {						

                                //In case of success response and when unlock code is not empty. It handles the Request Completed status for Smartphones

                                $rootScope.tmflag = false;

                                if (typeof(responsedata.unlockOrderStatusResponse.view) != "undefined") {
                                    if ((typeof(responsedata.unlockOrderStatusResponse.view.targetView) != "undefined")) {
                                        
                                        $scope.keySpecs = responsedata.unlockOrderStatusResponse.view.specification.key;
                                        
                                        for (i = 0; i < $scope.keySpecs.length; i++) {
                                            if ($scope.keySpecs[i].id == "leadingMessage") {
                                                $scope.leadMessage = $scope.keySpecs[i].text;
                                            }
                                            if ($scope.keySpecs[i].id == "systemMessage") {
                                                $scope.sysMessage = $scope.keySpecs[i].text;
                                            }
                                            if ($scope.keySpecs[i].id == "trailingMessage") {
                                                $scope.trailMessage = $scope.keySpecs[i].text;
                                            }
                                        }

                                        
                                        //test code start
                                        $rootScope.statusResponse.orderStatus = responsedata.unlockOrderStatusResponse.view.header;
                                        $rootScope.statusResponse.orderNumber = responsedata.unlockOrderStatusResponse.unlockOrderDetail.orderNumber;
                                        $rootScope.statusResponse.imei = responsedata.unlockOrderStatusResponse.unlockOrderDetail.imei;
                                        $rootScope.statusResponse.orderSubmissionDate = responsedata.unlockOrderStatusResponse.unlockOrderDetail.activityLog.orderSubmitted;
                                        $rootScope.leadingMessage = $scope.leadMessage;
                                        $rootScope.systemMessage = $scope.sysMessage;
                                        $rootScope.trailingMessage = $scope.trailMessage;

                                        $rootScope.unlockCodeView = true;
                                        // Decoding unlockCode (API sends in the Base64 encoded version as a resolution to defect #10189
                                        if (typeof responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode != "number") {
                                            $rootScope.unlockCode = Base64.decode(responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode);
                                        } else {
                                            $rootScope.unlockCode = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode;
                                        }
                                        
                                        //console.log("$rootScope.unlockCode : ",$rootScope.unlockCode);
                                        
                                        //Variables passed to statusController For Complete Status
                                        $rootScope.instructionMessage = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockDetail.instruction;
                                        $rootScope.targetView = responsedata.unlockOrderStatusResponse.view.targetView;
                                        
                                        
                                        //variables passed to webtrend action event
                                        dcsuri = '/' + $rootScope.targetView;
                                        wtStatusFlag = '1';
                                        wtStatusCode = '0';
                                        wtEvent = 'myATT_DeviceUnlock_StatusCheck_SUB';
                                        

										$location.path('statusresponse').replace();
                                        
                                    } else {
										sessionStorage.setItem('errorPage','yes');
                                        closeLoader();
                                       	$location.path('error').replace();
                                    }
                                    
                                } else {
                                   sessionStorage.setItem('errorPage','yes');
                                    closeLoader();
                                   $location.path('error').replace();
                                    
                                }

                            } else if (responsedata.unlockOrderStatusResponse.serviceStatus.code == 1) {
                                //In Case of Partial failure response from API

                                $rootScope.tmflag = false;

                                $scope.error = responsedata.unlockOrderStatusResponse.errorDetail.errorDescription;

                                //variables passed to webtrend action event
                                dcsuri = '/';
                                wtStatusFlag = '0';
                                wtStatusCode = responsedata.unlockOrderStatusResponse.errorDetail.errorCode;
                                wtEvent = 'myATT_DeviceUnlock_Error_SUB';

                                $rootScope.commonError = true;
                                $scope.imei = "";
                                $scope.requestNumber = "";
                                $scope.isVaild = false;
                                isValidImei = false;
                                isValidReqNo = false;
                                $scope.errorsArray = [];

                                var validationErrors = responsedata.unlockOrderStatusResponse.errorDetail;
								//console.log("****==== "+validationErrors.errorCode);
//								$scope.errorsArray.push(validationErrors.errorCode);
                                $rootScope.error = $rootScope.data[value.errorCode];
                                closeLoader();


                            } else if (responsedata.unlockOrderStatusResponse.serviceStatus.code == 2) {
                                //In case of Failure response from API

                                $rootScope.tmflag = false;

                                $scope.error = responsedata.unlockOrderStatusResponse.errorDetail.errorDescription;
                                //console.log("error : ",$scope.error);

                                //variables passed to webtrend action event
                                dcsuri = '/';
                                wtStatusFlag = '0';
                                wtStatusCode = responsedata.unlockOrderStatusResponse.errorDetail.errorCode;
                                wtEvent = 'myATT_DeviceUnlock_Error_SUB';

                                sessionStorage.setItem('errorPage','yes');
                                closeLoader();
								$location.path('/error').replace();
    
                            } else {
                                //  fails to retrive json data(display status based on error)

                                //variables passed to webtrend action event
                                dcsuri = '/';
                                wtStatusFlag = '0';
                                wtStatusCode = '1';
                                wtEvent = 'myATT_DeviceUnlock_Error_SUB';

                                sessionStorage.setItem('errorPage','yes');
                                closeLoader();
								$location.path('error').replace();  
                            }
                            //action event ---For Web Trends **
                            //dcsMultiTrack('DCS.dcssip', 'www.att.com', 'DCS.dcsref', window.location.href, 'DCS.dcsuri', dcsuri, 'DCS.dcsua', navigator.userAgent, 'browserid', navigator.appCodeName, 'DCSext.wtPN', 'Device Unlock Portal Status Entry Pg', 'DCSext.wtEvent', wtEvent, 'DCSext.wtSuccessFlag', wtStatusFlag, 'DCSext.wtStatusCode', wtStatusCode, 'DCSext.wtNoHit', '1', 'DCSext.wtIMEI', $scope.imei);

                            //closeLoader();
                    })
    
                    .error(function(responsedata) {
                        closeLoader();

                        $rootScope.tmflag = false;

                        sessionStorage.setItem('errorPage','yes');
						$location.path('/error').replace();
                    });
                 }

              }

            }

        } 
    };


    $scope.reaquestStatus_back = function()
	{
		//console.log("request status back button called => ");
		$location.path("#/");
	}


}]);


unlockPortal.filter('html', ['$sce', function ($sce) { 
    return function (text) {
        return $sce.trustAsHtml(text);
    };    
}]);


unlockPortal.controller('statusResponseCtrl', ['$scope', '$rootScope', '$http','services', '$sce','$location', function($scope, $rootScope, $http, services, $sce, $location){
	angular.element("#firstPageHeader").hide();
	angular.element("#IRUCRUHeader").hide();
//	$scope.getEnglishContent = function(){
//		var jsonURL = "/json/en/unlock_portal_label_and_error.json";
//		services.getStatus(jsonURL)
//		.success(function(jsonData) {
//			$scope.data = jsonData.unlockPortalLabelAndErrorObj[0];
//		});
//	}
//	
//	$scope.getEnglishContent();

	if (typeof(Storage) != "undefined" && $rootScope.statusResponse == undefined) {
        sessionStorage.setItem("hasReadTerms", "no");
        sessionStorage.setItem("agreeCheckedBox", "no");
        sessionStorage.setItem("errorPage","no");
		$location.path("#/unlock");
    }
    closeLoader();
}]);