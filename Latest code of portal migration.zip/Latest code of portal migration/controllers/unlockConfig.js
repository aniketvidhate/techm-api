/**
  * @Author 		:- Aniket Vidhate (av0041) /   
  * Date			:- 12-7-2015
  * File name 		:- unlockConfig.js
  */

/* Global Environment Variables for FCC Unlock Project */

var baseTemplateUrl = '';
//var baseApiUrl = 'http://10.13.67.43:8181/cxf/att';
//var baseApiUrl = 'http://localhost:8080/unlock/';
//var baseApiUrl = '/apps/att/unlock/components/clientlibs/';
//var baseApiUrl = '//ecomtest31.bodc.att.com:8110/apis/deviceunlock/';
var baseApiUrl ="/apis/deviceunlock/";
/* dict.json URL */
//var dictJsonUrl = 'http://tst31.stage.att.com/salescms/libs/cq/i18n/dict.en.json';
//var dictJsonUrl = '/apps/att/unlock/components/clientlibs/dict.en.json';
var dictJsonUrl = '/salescms/libs/cq/i18n/dict.en.json';

/* Template URLs for all modules */
var unlockTemplateUrl = {
    portalEntryPage : baseTemplateUrl + 'termsandconditions.html',
    unlockRequestContent : baseTemplateUrl + 'requestinfo.html',
    unlockRequestThankYou : baseTemplateUrl + 'thankyou.html',

    deviceUnlockStatusContent : baseTemplateUrl + 'statusinfo.html',
    requestInProgress : baseTemplateUrl + 'statusresultinprogress.html',
    requestDenied : baseTemplateUrl + 'statusresultdenied.html',
    requestCancelled : baseTemplateUrl + 'statusresultcancelled.html',
    requestCompleted : baseTemplateUrl + 'statusresult.html',
    iRequestCompleted : baseTemplateUrl + 'statusresultiphone.html',

	defaultEmail : baseTemplateUrl + 'defaultemail.html',
    emailThankYou : baseTemplateUrl + 'thankyouemail.html',
    emailCancelled : baseTemplateUrl + 'emailcancelled.html',
    emailLinkExpired : baseTemplateUrl + 'emaillinkexpired.html',

	paymentContent : baseTemplateUrl + 'paymentinfo.html',
    paymentThankyou : baseTemplateUrl + 'paymentconfirmation.html',
    paymentCancelled : baseTemplateUrl + 'paymentcancelled.html',
    paymentLinkExpired : baseTemplateUrl + 'paymentlinkexpired.html',


    systemError : baseTemplateUrl + 'systemerror.html'

}

/* API URLs for all modules */

var unlockApiUrl = {
    unlockOrder : baseApiUrl + 'UnlockOrder/unlockOrder',
	//unlockOrder : baseApiUrl + 'portalentry/unlockOrderSuccessResponse.json',
    //unlockOrderSuccessResponse.json
    //unlockOrderErrorResponse.json
    //unlockOrderSysErrorResponse.json

	imei :  baseApiUrl + 'UnlockUtility/lookupimei',
	//imei : baseApiUrl + 'portalentry/lookUpImeiSuccessResponse.json',
    //lookUpImeiSuccessResponse.json"	  //Success
    //lookUpImeiErrorResponse.json"	  //Partial Failure
    //lookUpImeiSysErrorResponse.json"   //Failure

    emailValidation : baseApiUrl + 'UnlockUtility/Verify/ValidateEmail',
	//emailValidation : baseApiUrl + 'portalentry/emailValidationSuccessResponse.json',
    // emailValidationSuccessResponse  -- success json
    // emailValidationErrorResponse  -- error json file

    imageCaptchaUrl : baseApiUrl + 'unlockCaptcha/image',
	//imageCaptchaUrl : '/apps/att/unlock/components/clientlibs/' + 'portalentry/imageCaptchaUrlSuccessResponse.json',
    //imageCaptchaUrlSuccessResponse  -- success json
    //imageCaptchaUrlErrorResponse  -- error json file

    audioCaptchaUrl : baseApiUrl + 'unlockCaptcha/sound',
	//audioCaptchaUrl : '/apps/att/unlock/components/clientlibs/' + 'portalentry/audioCaptchaUrlSuccessResponse.json',
    //audioCaptchaUrlSuccessResponse  -- success json
    //audioCaptchaUrlErrorResponse  -- error json file

    resendEmail : baseApiUrl + 'UnlockUtility/resendEmail',
	//resendEmail : baseApiUrl + '/orderstatus/emailAPI.json',

    orderStatus : baseApiUrl + 'UnlockOrder/unlockOrderStatus',
	//orderStatus : baseApiUrl + '/orderstatus/unlockOrderStatusCompleted.json',
    //unlockOrderStatusCompleted.json
	//unlockstatuscompletediphone.json" //completed status for iphone
    //unlockOrderStatusCompleted_2.json" //failure
    //cancel_ACCOUNT_ACTIVE_60_DAYS.json"
	//cancel_ATT_NEXT_SERVICE_COMMITMENT.json"
	//unlockstatus_inprogress.json"    //In Progrss

	verifyEmail : baseApiUrl + 'UnlockUtility/Verify/VerifyEmail',
    //verifyEmail : '/apps/att/unlock/components/clientlibs/' + 'email/emailVerification.json',
    //emailVerification.json
    //emailCancelled.json
    //emailLinkExpired.json
	//systemError.json

    //oceVerifyEmail : baseApiUrl + 'OCEUnlockOrder/Verify/VerifyEmail',
    oceVerifyEmail : 'http://135.198.154.218:8181/apis/deviceunlock/OCEUnlockOrder/Verify/VerifyEmail',

    verifyPaymentDetail : baseApiUrl + 'UnlockUtility/Payment/VerifyPayment',
    //unlockVerifyPaymentDetailResponse_0.json
    //unlockVerifyPaymentDetailResponse_0_1.json
    //unlockVerifyPaymentDetailResponse_1.json
    //unlockVerifyPaymentDetailResponse_2.json

    paymentProcess : baseApiUrl + 'UnlockUtility/Payment/Payment',
    //unlockPaymentProcessResponse_0.JSON
    //unlockPaymentProcessResponse_1.json
    //unlockPaymentProcessResponse_2.json

    calculateTax : baseApiUrl + 'UnlockUtility/Tax',
    //CalculateTaxResponse_0
    //CalculateTaxResponse_1
    //CalculateTaxResponse_2

	//sitecheck : baseApiUrl + "OCEUnlockOrder/redirectOCEWorkFlow" 
    //sitecheck : "http://135.198.154.218:8181/apis/deviceunlock/OCEUnlockOrder/redirectOCEWorkFlow"  //Nulufer
	sitecheck : "https://tst04.stage.att.com/apis/deviceunlock/OCEUnlockOrder/redirectOCEWorkFlow"  //Nulufer

}