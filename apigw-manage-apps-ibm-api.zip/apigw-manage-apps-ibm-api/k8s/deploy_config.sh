#!/bin/bash
SCRIPT_DIR=`dirname "${BASH_SOURCE[0]}"`
SCRIPT_DIR=$(cd $SCRIPT_DIR;pwd)

APP_NAME="${APP_NAME:-oppv-widget}"
TARGET_ENV="${TARGET_ENV:-DEV}"
USE_ROOT_NAMESPCE="${USE_ROOT_NAMESPCE:-false}"
GITHUB_NON_PROD="codecloud.web.att.com/scm/st_oce2/config-non-prod.git"
GITHUB_PROD="codecloud.web.att.com/scm/st_sapmpps1/sapmp_prod_config_mservice.git"
CONFIG_APP_NS="com.att.sapmp"


function log {
	echo "[$(date +"%F %T")] $*"
}

log "================================================================"
log "Application     : ${APP_NAME}"
log "K8S Environment : ${TARGET_ENV}"
log "GITHUB_PROD     : ${GITHUB_PROD}"
log "GITHUB_NON_PROD : ${GITHUB_NON_PROD}"
log "================================================================"

TARGET_ENV=`echo $TARGET_ENV| tr '[:upper:]' '[:lower:]'`


if [ "$TARGET_ENV" = "prod"  ]
then
	GITHUB_CONFIG_URL="${GITHUB_PROD}"
else
	GITHUB_CONFIG_URL="${GITHUB_NON_PROD}"
fi
		

if [ "$USE_ROOT_NAMESPCE" = "true" ]
then
    CONFIG_APP_NS="${CONFIG_APP_NS}"
else
	CONFIG_APP_NS="${CONFIG_APP_NS}.${TARGET_ENV}"
fi


log "================================================================"
log "CONFIG_APP_NS      : ${CONFIG_APP_NS}"
log "GITHUB_CONFIG_URL  : ${GITHUB_CONFIG_URL}"
log "================================================================"


# # Deploy only Configmaps
 curl_data='{
      "nodegroup": "",
      "appnamespace": "'${CONFIG_APP_NS}'",
       "playbookyaml": "deploy.yml",
       "githubpath": "'${GITHUB_CONFIG_URL}'",
       "playbookdir":"'${APP_NAME}'",
       "envvarList":[ "--skip-tags=deploy"],
       "ansibleuser": "ml5174@csp.att.com",
       "inventoryfilepath": "inventory/'${TARGET_ENV}'/hosts"
  }'

echo $curl_data
 
echo $curl_data > /tmp/ansibledata$$.json

ANSIBLE_RES=$(curl --verbose -s -H "Authorization: Basic bTc5MjA0QHN3bS5hdHQuY29tOnN3bTc5MjA0" -H "Accept: application/json" -H "Content-Type: application/json" -X POST  'http://ansibleservice.it.att.com:9095/swm/ansible/applyEffectiveConfig' -d @/tmp/ansibledata$$.json)

log "Response from Ansible API : "

echo ${ANSIBLE_RES} 

log "================================================================"
log " Success - ${APP_NAME} configmap Successfully deployed!"
log "================================================================"
