package com.att.sapmp.apigw.apps.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.apps.exception.CErrorDefs;
import com.att.sapmp.apigw.apps.model.ActionResponse;
import com.att.sapmp.apigw.apps.util.CommonDefs;

@Component
public class DeleteAppResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeleteAppResponseProcessor.class);

	public final void handleResponse(Exchange e) throws Exception {

		ActionResponse actionRes = (ActionResponse) e.getIn().getBody();
		HashMap<Object, Object> hmResponse = (HashMap<Object, Object>) actionRes.getActionResponse();
		log.info("Response from DeleteApp API " + hmResponse);
		String description = (String) hmResponse.get(CommonDefs.DESCRIPTION);
		String stStatusCode = String.valueOf(e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		if ("Success".equals((String) actionRes.getActionResponse().get("status"))) {
			e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CErrorDefs.RESPONSE_ACCEPT_CODE);
		} else {
			JSONObject deleteAppResp = new JSONObject();
			deleteAppResp.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4001);
			deleteAppResp.put(CommonDefs.DESCRIPTION, description);
			e.getOut().setBody(deleteAppResp);
			e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, stStatusCode);
		}

	}

}
