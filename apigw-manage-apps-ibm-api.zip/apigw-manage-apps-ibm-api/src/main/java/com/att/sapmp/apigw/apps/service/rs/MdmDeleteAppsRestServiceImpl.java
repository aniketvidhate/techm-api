package com.att.sapmp.apigw.apps.service.rs;

import java.lang.reflect.Field;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;


@AjscService
public class MdmDeleteAppsRestServiceImpl implements MdmDeleteAppsRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(MdmDeleteAppsRestServiceImpl.class);
	
	@Autowired
	com.att.sapmp.apigw.apps.service.InitializationService is;

	public MdmDeleteAppsRestServiceImpl() {
		// needed for autowiring
	}
	@Override
	@POST 
	 	public void deleteApp(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@RequestBody com.att.sapmp.apigw.apps.model.App app) {	
		log.info("Received request in deleteappRestServiceImpl API");
		
		
		
	}
		
	}
	

		
	


