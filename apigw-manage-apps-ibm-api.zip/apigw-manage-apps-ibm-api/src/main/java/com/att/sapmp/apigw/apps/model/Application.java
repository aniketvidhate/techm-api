package com.att.sapmp.apigw.apps.model;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModelProperty;



public class Application {

	@ApiModelProperty(value = "appId", example = "com.att.eptt")
	private String appId;
	
	  public String getAppId() { return this.appId; }

	  public void setAppId(String appId) { this.appId = appId; }
	  @ApiModelProperty(value = "deviceId", example = "Android9cc05b11e0d6e7f4")

	  private String deviceId;

	  public String getDeviceId() { return this.deviceId; }

	  public void setDeviceId(String deviceId) { this.deviceId = deviceId; }
	  @ApiModelProperty(value = "appVersion", example = "2")

	  private String appVersion;

	  public String getAppVersion() { return this.appVersion; }

	  public void setAppVersion(String appVersion) { this.appVersion = appVersion; }
	  @ApiModelProperty(value = "appType", example = "3")

	  private String appType;

	  public String getAppType() { return this.appType; }

	  public void setAppType(String appType) { this.appType = appType; }
}
