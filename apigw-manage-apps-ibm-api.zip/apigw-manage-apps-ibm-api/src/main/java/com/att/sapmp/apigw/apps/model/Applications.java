package com.att.sapmp.apigw.apps.model;

import java.util.HashMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


public class Applications {
	private ArrayList<Application> application;

	  public ArrayList<Application> getApplication() { return this.application; }

	  public void setApplication(ArrayList<Application> application) { this.application = application; }

		
}
