package com.att.sapmp.apigw.apps.util;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.oce.voltage.api.VoltageHelper;
import com.att.sapmp.apigw.apps.exception.ApigwException;
import com.att.sapmp.apigw.apps.exception.CErrorDefs;


@Component
public class CommonUtil {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CommonUtil.class);
	public static final String DATEFORMAT = "yyyy-MM-dd'T'hh:mm:ss.'000Z'";
	private VoltageHelper volHelper = null;
	
	@Value("${voltage.config}")
	private String voltageConfig;
	
	@Value("${product.code}")
	private String stProduct;

	@Value("${log.masking.field}")
	private String logMaskingFields;
	
	public boolean isProductCodeValid(String inProductCode) {
		boolean bValid = false;
		//String stProduct = null;
		if (stProduct != null) {
			List<String> alList = Arrays.asList(stProduct.split("\\|"));
			if (inProductCode != null && alList.contains(inProductCode.toLowerCase())) {
				bValid = true;
			}
		}
		return bValid;

	}

	public List<String> getAsArrayList(String inValue) {
		List<String> alResponse = new ArrayList<String>();
		if (!StringUtils.isEmpty(inValue)) {
			alResponse.add(inValue);
		}
		return alResponse;

	}

	public static String getGMTdatetimeAsString() {
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}
	
	public VoltageHelper getVoltageHelper() throws ApigwException {
		if (volHelper == null) {
			initialize();
		}
		return volHelper;
	}
	
	private void initialize() throws ApigwException {
		try (FileInputStream in = new FileInputStream(voltageConfig)) {
			Properties props = new Properties();
			props.load(in);
			this.volHelper = VoltageHelper.getInstance(props);
		} catch (Exception ex) {
			log.error("Error occured while initializing the voltage", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}

	public void logJSON(String description, String logMessage) {
		log.info(description + ":" + maskingPayload("JSON" , logMessage));
	}
	
	public void logMAP(String description, String logMessage) {
		log.info(description + ":" + maskingPayload("MAP" , logMessage));
	}
	
	public void logHTTPQuery(String description, String logMessage) {
		log.info(description + ":" + maskingPayload("HTTPQuery" , logMessage));
	}
	
	private String maskingPayload(String logType, String payload) {
		if (logMaskingFields != null && logMaskingFields.length() > 0) {
			String[] maskingArray = logMaskingFields.split(",");
			for (String field : maskingArray) {
				field = field.trim();
				if (payload.contains(field)) {
					int fieldIndex = payload.indexOf(field) + field.length();
					String fieldValue = "";
					if (logType.equalsIgnoreCase("XML")) {
						int endIndex = payload.indexOf("<", fieldIndex);
						fieldValue = payload.substring(fieldIndex + 1, endIndex);
					} else if (logType.equalsIgnoreCase("JSON")) {
						int endIndex = payload.indexOf(",", fieldIndex);
						if (endIndex > 0) {
							fieldValue = payload.substring(fieldIndex, endIndex);
						} else {
							fieldValue = payload.substring(fieldIndex , payload.indexOf("}"));
						}
						fieldValue = fieldValue.replaceAll("\"", "").replaceAll(":", "").trim();
					}else if (logType.equalsIgnoreCase("MAP")) {
						int endIndex = payload.indexOf(",", fieldIndex);
						fieldValue = payload.substring(fieldIndex+1, endIndex);
					}else if (logType.equalsIgnoreCase("HTTPQuery")) {
						int endIndex = payload.indexOf("&", fieldIndex);
						fieldValue = payload.substring(fieldIndex+1, endIndex);
					}
					payload = payload.replace(fieldValue, "********");
				}
			}
		}
		return payload;
	}
}
