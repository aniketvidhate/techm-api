package com.att.sapmp.apigw.apps.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "emmAccountId", "Applications" })
@ApiModel(value = "App", description = "manage app - input payload")
public class App {
	
	@JsonProperty
	private String emmAccountId;
	@ApiModelProperty(value = "EmmAccountId", example = "30061269")
	  public String getEmmAccountId() { return this.emmAccountId; }

	  public void setEmmAccountId(String emmAccountId) { this.emmAccountId = emmAccountId; }
	  @JsonProperty
	  private Applications applications;

	  public Applications getApplications() { return this.applications; }

	  public void setApplications(Applications applications) { this.applications = applications; }


}
