package com.att.sapmp.apigw.apps.util;

import java.util.Map;


public class AuthResponse {
	
	Map<Object, Object> authResponse;
	
	public Map<Object, Object> getAuthResponse() {
		return authResponse;
	}

	public void setAuthResponse(Map<Object, Object> authResponse) {
		this.authResponse = authResponse;
	}

}
