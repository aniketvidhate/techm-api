package com.att.sapmp.apigw.apps.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.apps.exception.ApigwException;
import com.att.sapmp.apigw.apps.exception.CErrorDefs;
import com.att.sapmp.apigw.apps.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

@SuppressWarnings("unchecked")
@Component
public class DistributeAppRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DistributeAppRequestProcessor.class);
	@Value("${ibm.distribute.app.url}")
	private String distributeAppUrl;
	@Value("${ibm.send.email}")
	private String sendEmail;

	@Value("${ibm.target.devices}")
	private String targetDevices;

	@Value("${ibm.send.notification}")
	private String sendNotification;

	@Value("${ibm_instant.install}")
	private String instantInstall;
	@Autowired
	InitializationService is;

	public final void execute(Exchange e) throws ApigwException {

		String stIMBDistributeAppUrlFinal = "";
		StringBuilder stIBMDistributeAppUrlBase = new StringBuilder(distributeAppUrl);

		HashMap<String, Object> hmRequestList = InitializationService.getRequestparammap();

		String body = (String) (e.getIn().getBody());

		log.info("body " + body);

		if (StringUtils.isEmpty(body)) {

			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "body  is null in input");

		}

		// create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// convert json string to object
		HashMap<String, Object> hmSearch = null;
		try {
			hmSearch = objectMapper.readValue(body, HashMap.class);
		} catch (Exception e1) {

			log.debug("Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}

		ArrayList<HashMap<String, Object>> alApplication = null;

		if (hmSearch == null || hmSearch.isEmpty()) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1002, "Please provide mandatory fields");
		} else {

			String stBillingId = (String) hmSearch.get(CommonDefs.EMM_ACCOUNT_ID);

			HashMap hmApplications = (HashMap) hmSearch.get(CommonDefs.APLICATIONS);

			alApplication = (ArrayList) hmApplications.get(CommonDefs.APLICATION);

			JSONObject postReqJSON = new JSONObject(hmSearch);
			validateJSONReq(postReqJSON, CommonDefs.Delete_App_Mandatory_Param);

			stIBMDistributeAppUrlBase.append("/" + stBillingId);

			stIMBDistributeAppUrlFinal = stIBMDistributeAppUrlBase.toString();

			if (hmRequestList != null && !hmRequestList.isEmpty()) {
				hmRequestList.put(CommonDefs.BILLING_ID, stBillingId);
				hmRequestList.put(CommonDefs.APP_LIST, alApplication);
				hmRequestList.put(CommonDefs.IBM_URL, stIMBDistributeAppUrlFinal);
			}

			log.info("Setting Header IBMUrl=" + stIMBDistributeAppUrlFinal);
			e.getOut().setHeaders(hmRequestList);
		}

	}

	public final void split(Exchange e) throws ApigwException {

		try {

			log.info("split with body=" + e.getIn().getBody());

			HashMap<String, Object> hmVelocityContext = (HashMap) e.getIn().getBody();
			hmVelocityContext.put(CommonDefs.TARGET_DEVICES, targetDevices);
			hmVelocityContext.put(CommonDefs.SEND_NOTIFICATION, sendNotification);
			hmVelocityContext.put(CommonDefs.SEND_EMAIL, sendEmail);
			hmVelocityContext.put(CommonDefs.INSTANT_INSTALL, instantInstall);
			VelocityContext velocityContext = new VelocityContext(hmVelocityContext);
			e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		} catch (Exception ex) {
			log.debug("Exception occurred while parsing post request: " + ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}

	}

}