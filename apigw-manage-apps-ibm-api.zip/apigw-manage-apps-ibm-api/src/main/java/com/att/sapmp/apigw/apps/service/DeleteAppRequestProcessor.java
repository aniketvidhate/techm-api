package com.att.sapmp.apigw.apps.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.apps.exception.ApigwException;
import com.att.sapmp.apigw.apps.exception.CErrorDefs;
import com.att.sapmp.apigw.apps.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

@SuppressWarnings("unchecked")
@Component
public class DeleteAppRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeleteAppRequestProcessor.class);
	@Value("${ibm.delete.app.url}")
	private String deleteAppUrl;

	@Autowired
	InitializationService is;

	public final void execute(Exchange e) throws ApigwException {

		String stIBMDeleteAppUrlFinal = "";
		StringBuilder stIBMDeleteAppUrlBase = new StringBuilder(deleteAppUrl);
		HashMap<String, Object> hmRequestList = InitializationService.getRequestparammap();
		String stBillingId = "";
		String emmProductCode = (String) (e.getIn().getHeader(CommonDefs.EMMP_PRODUCT_CODE));
		String body = (String) (e.getIn().getBody());
		log.info("headers::::" + e.getIn().getHeaders());

		if (StringUtils.isEmpty(body)) {

			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "body  is null in input");

		}

		ObjectMapper objectMapper = new ObjectMapper();

		// convert json string to object
		HashMap<String, Object> hmSearch = null;
		try {
			hmSearch = objectMapper.readValue(body, HashMap.class);
		} catch (Exception e1) {

			log.error("Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		if (hmSearch == null || hmSearch.isEmpty()) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CErrorDefs.ERROR_CODE_1002_DESCRIPTION);
		} else {

			log.info("hmSearch::::" + hmSearch);

			stBillingId = (String) hmSearch.get(CommonDefs.EMM_ACCOUNT_ID);

			HashMap hmApplications = (HashMap) hmSearch.get(CommonDefs.APLICATIONS);

			log.info("hmApplications::::" + hmApplications);

			ArrayList<HashMap<String, Object>> alApplication = (ArrayList) hmApplications.get(CommonDefs.APLICATION);
			log.info("alApplication::::" + alApplication);
			JSONObject postReqJSON = new JSONObject(hmSearch);
			validateJSONReq(postReqJSON, CommonDefs.Delete_App_Mandatory_Param);

			stIBMDeleteAppUrlBase.append("/" + stBillingId);

			stIBMDeleteAppUrlFinal = stIBMDeleteAppUrlBase.toString();

			if (hmRequestList != null && !hmRequestList.isEmpty()) {
				hmRequestList.put(CommonDefs.BILLING_ID, stBillingId);
				hmRequestList.put(CommonDefs.APP_LIST, alApplication);
				hmRequestList.put(CommonDefs.IBM_URL, stIBMDeleteAppUrlFinal);
				hmRequestList.put(CommonDefs.EMMP_PRODUCT_CODE, emmProductCode);
			}

			log.info("Setting Header IBMUrl=" + stIBMDeleteAppUrlFinal);
			e.getOut().setHeaders(hmRequestList);
			log.info("out headers::::" + e.getOut().getHeaders());
		}

	}

	public final void split(Exchange e) throws ApigwException {

		try {

			log.info("split with body=" + e.getIn().getBody());
			HashMap<String, Object> hmVelocityContext = (HashMap) e.getIn().getBody();
			VelocityContext velocityContext = new VelocityContext(hmVelocityContext);
			e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		} catch (Exception ex) {
			log.error("Exception occurred while parsing post request: " + ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}

	}

}