package com.att.sapmp.apigw.certs.util;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.certs.util.AuthResponse;
import com.att.sapmp.apigw.certs.util.CommonDefs;

/**
 * @author pg238s
 *
 */
@Component
public class ResponseMdmProcessor {

	@Autowired
	InitializationMdmService initService;
	
	@Value("${token.expiration.time}")
	private String configExpirationTime;

	//private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ResponseMdmProcessor.class);

	public final void handleResponse(Exchange e) throws Exception {

		
		String stBillingId = (String) e.getIn().getHeader("billingId");

		AuthResponse authRes = (AuthResponse) e.getIn().getBody();
		

		String authToken = (String) authRes.getAuthResponse().get(CommonDefs.AUTH_TOKEN);
		Integer errorCode = (Integer) authRes.getAuthResponse().get("errorCode");
		
		HashMap<String, Object> hmAuthRes = new HashMap<String, Object>();
		hmAuthRes.put(CommonDefs.AUTH_TOKEN, authToken);
		hmAuthRes.put("errorCode", errorCode);

		if (authToken == null || authToken.isEmpty()) {
			String errorDesc = (String) authRes.getAuthResponse().get("errorDesc");
			if (errorDesc != null && !errorDesc.isEmpty()) {
				hmAuthRes.put("errorDesc", errorDesc);
			}

		} else {
			e.getOut().setHeader(CommonDefs.AUTH_TOKEN, authToken);
			HashMap<String, Object> hmAuthMap = new HashMap<String, Object>();

			Date expirationDate = getExpirationTime();

			hmAuthMap.put("billingID", stBillingId);
			hmAuthMap.put(CommonDefs.AUTH_TOKEN, authToken);
			hmAuthMap.put("expirationTime", expirationDate);

			HashMap<String, Object> hmBillingIdAuthMap = new HashMap<String, Object>();
			hmBillingIdAuthMap.put(stBillingId, hmAuthMap);
			initService.setAuthtokenmap(hmBillingIdAuthMap);
		}

		JSONObject jsonAuthToken = new JSONObject();
		jsonAuthToken.put("authResponse", hmAuthRes);

		// log.info("Response from MDMAuthToken API " + jsonAuthToken);
		e.getOut().setBody(jsonAuthToken);

	}


	private Date getExpirationTime() {
		Date expirationDate = null;
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MINUTE, Integer.parseInt(configExpirationTime));

		expirationDate = cal.getTime();
		return expirationDate;
	}

}
