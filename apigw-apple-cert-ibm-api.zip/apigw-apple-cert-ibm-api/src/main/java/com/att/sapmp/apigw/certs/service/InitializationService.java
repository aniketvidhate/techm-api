package com.att.sapmp.apigw.certs.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.swagger.annotations.ApiModel;

/**
 * @author pg238s
 *
 */
@ApiModel(value = "InitializationService", description = "InitializationService to load the properties")
@Component
public class InitializationService {

	@Value("${ibm.upload.apple.cert.response.transform.param}")
	private String responseParam;

	@Value("${ibm.upload.apple.cert.request.transform.param}")
	private String requestParam;
	
	
	@Value("${ibm.sign.apple.cert.request.transform.param}")
	private String requestSignCertParam;	
	

	private static final Map<String, String> responseParamMap = new HashMap<String, String>();

	private static final Map<String, String> requestParamMap = new HashMap<String, String>();
	
	private static final Map<String, String> requestSignCertParamMap = new HashMap<String, String>();


	/**
	 * 
	 * @param e
	 *            This method read the properties from application.properties
	 *            and parse it.
	 */

	private void init() {
		if (responseParam != null && !responseParam.isEmpty()) {
			String[] responsePair = responseParam.split(",");
			for (String pair : responsePair) {
				String[] kv = pair.split("=");
				responseParamMap.put(kv[0], kv[1]);
			}
		}

		if (requestParam != null && !requestParam.isEmpty()) {
			String[] requestPair = requestParam.split(",");
			for (String pair : requestPair) {
				String[] kv = pair.split("=");
				requestParamMap.put(kv[0], kv[1]);
			}
		}
		
		if (requestSignCertParam != null && !requestSignCertParam.isEmpty()) {
			String[] requestPair = requestSignCertParam.split(",");
			for (String pair : requestPair) {
				String[] kv = pair.split("=");
				requestSignCertParamMap.put(kv[0], kv[1]);
			}
		}		

	}

	public static Map<String, String> getResponseparammap() {
		return responseParamMap;
	}

	public static Map<String, String> getRequestparammap() {
		return requestParamMap;
	}
	
	
	public static Map<String, String> getRequestSignCertParamMap() {
		return requestSignCertParamMap;
	}
	
}