package com.att.sapmp.apigw.certs.exception;

public class ApigwException extends Exception {

	String errorMsg;
	String errorCode;
		
	public ApigwException() {
		super();
	}

	public ApigwException(String msg) {
		super(msg);
	}

	public ApigwException(String msg, Exception exp) {
		super(msg, exp);
	}

	public ApigwException(String errorCode, String errorMsg) {
		super(errorMsg);
		this.errorMsg = errorMsg;
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

}
