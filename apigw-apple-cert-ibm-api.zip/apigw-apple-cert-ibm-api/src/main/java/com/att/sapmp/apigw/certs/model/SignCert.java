package com.att.sapmp.apigw.certs.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class SignCert {
	
	String signedCSR;

	public String getSignedCSR() {
		return signedCSR;
	}

	public void setSignedCSR(String signedCSR) {
		this.signedCSR = signedCSR;
	}
	

}
