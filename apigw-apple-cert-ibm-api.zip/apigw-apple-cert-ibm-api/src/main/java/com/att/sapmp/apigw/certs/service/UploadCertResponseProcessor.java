package com.att.sapmp.apigw.certs.service;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;

import io.swagger.annotations.ApiModel;

/**
 * @author pg238s
 *
 */
@ApiModel(value = "ResponseProcessor", description = "ResponseProcessor for parsing the response from camel route")
@Component
public class UploadCertResponseProcessor {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(UploadCertResponseProcessor.class);
	
	public final void handleUploadResponse(Exchange e) throws Exception {
		log.info("within handleUploadResponse");
		e.getOut().setBody(e.getIn().getBody());
	}
}
