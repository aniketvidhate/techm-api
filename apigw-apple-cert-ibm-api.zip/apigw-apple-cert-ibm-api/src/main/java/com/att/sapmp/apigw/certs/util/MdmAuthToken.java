package com.att.sapmp.apigw.certs.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.oce.voltage.api.VoltageEfpeFormatType;
import com.att.oce.voltage.api.VoltageHelper;
import com.att.sapmp.apigw.certs.exception.ApigwException;
import com.att.sapmp.apigw.certs.exception.CErrorDefs;
import com.att.sapmp.apigw.certs.util.CommonDefs;

@Component
public class MdmAuthToken {

	@Value("${ibm.auth.token.url}")
	private String authTokenUrl;
	
	@Value("${use.proxy}")
	private String useProxy;
	
	@Value("${ibm.customer.prefix}")
	private String customerUser;
	
	@Value("${voltage.enabled}")
	private String voltageEnabled;
	
	@Autowired
	CamelContext ctx;
	
	@Autowired
	CommonUtil commonUtil;
	
	private Logger log = LoggerFactory.getLogger(MdmAuthToken.class);

	public void getAuthToken(Exchange e) throws ApigwException {
		Map<String, Object> hmHeader = null;
		Object body = null;
		String finalauthTokenUrl = null;
		boolean bCallToMDM = false;
		VelocityContext velocityContext = null;
		try {

			String stBillingId = (String) e.getIn().getHeader(CommonDefs.BILLING_ID);
			String stAccountPassword = (String) e.getIn().getHeader(CommonDefs.ACCOUNT_PASS_PHRASE);
			finalauthTokenUrl = authTokenUrl + "/" + stBillingId;

			hmHeader = e.getIn().getHeaders();
			
			hmHeader.put("use.proxy", useProxy);
			
			body = e.getIn().getBody();
			
			HashMap<String , Object> hmVelocityParam = new HashMap<String , Object>();
			hmVelocityParam.put(CommonDefs.BILLING_ID, stBillingId);
						
			HashMap<String, Object> hmPropAuthParam = (HashMap<String, Object>) InitializationMdmService.getPropAuthParamMap();
			if(hmPropAuthParam != null && !hmPropAuthParam.isEmpty()){
				hmVelocityParam.putAll(hmPropAuthParam);
			}
			
			if (stAccountPassword != null && !stAccountPassword.isEmpty()) {
				hmVelocityParam.put(CommonDefs.USER_NAME, stBillingId + "_" + customerUser);
				if (voltageEnabled != null && voltageEnabled.equalsIgnoreCase(CommonDefs.Y)) {
					// Decrypt Voltage Encrypted Passphrase
					VoltageHelper volHelper = commonUtil.getVoltageHelper();
					String decryptedPassPhrase = volHelper.decrypt(stAccountPassword, VoltageEfpeFormatType.valueOf("B64_GENERIC"));
					hmVelocityParam.put(CommonDefs.PASSWORD, decryptedPassPhrase);
				} else {
					hmVelocityParam.put(CommonDefs.PASSWORD, stAccountPassword);
				}
			}
			
			velocityContext = (VelocityContext) e.getIn().getHeader(VelocityConstants.VELOCITY_CONTEXT);
					
			String stAuthToken = getAuthTokenFromCache(stBillingId);
			if (stAuthToken == null || stAuthToken.isEmpty()) {
				bCallToMDM = true;
				VelocityContext authVelocityContext = new VelocityContext(hmVelocityParam);
				e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, authVelocityContext);
				e.getIn().setHeader("IBMAuthURL", finalauthTokenUrl);
				log.info("Calling  mdmAuthToken endpoint to generate auth token");
				ProducerTemplate template = ctx.createProducerTemplate();
				template.requestBodyAndHeaders("direct:mdmAuthToken", body, hmHeader);
				stAuthToken = getAuthTokenFromCache(stBillingId);

			}
			hmHeader.put(CommonDefs.AUTH_TOKEN, stAuthToken);
			e.getOut().setHeaders(hmHeader);
			if (bCallToMDM && velocityContext != null) {
				e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
			}
			
			if(body != null){
			e.getOut().setBody(body);
			}

		} catch (Exception ex) {
			log.error("Caught Exception with error message::" + ex.getMessage() , ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		} 

	}

	private String getAuthTokenFromCache(String billingId) {
		String authToken = null;

		HashMap<String, Object> hmAuthMap = (HashMap<String, Object>) InitializationMdmService.getAuthtokenmap();
		HashMap<String, Object> hmBillingIdAuthMap = (HashMap<String, Object>) hmAuthMap.get(billingId);
		if (hmBillingIdAuthMap != null && !hmBillingIdAuthMap.isEmpty()) {
			Date curentDate = new Date();
			Date expirationDate = (Date) hmBillingIdAuthMap.get(CommonDefs.EXPIRATION_TIME);
			if (expirationDate != null && curentDate.before(expirationDate)) {
				authToken = (String) hmBillingIdAuthMap.get(CommonDefs.AUTH_TOKEN);
			}

		}

		return authToken;

	}

}
