package com.att.sapmp.apigw.certs.service;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.camel.Exchange;
import org.apache.commons.io.IOUtils;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;

import io.swagger.annotations.ApiModel;

/**
 * @author pg238s
 *
 */
@ApiModel(value = "ResponseProcessor", description = "ResponseProcessor for parsing the response from camel route")
@Component
public class SignCertResponseProcessor {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(SignCertResponseProcessor.class);

	public final void handleResponse(Exchange e) throws Exception {
		
		log.info("within handleResponse");
		JSONObject jsonSignCert = new JSONObject();
		InputStream inputStream = (InputStream) e.getIn().getBody();
		String result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
		jsonSignCert.put("signedCSR", result);
		e.getOut().setBody(jsonSignCert);

	}
}
