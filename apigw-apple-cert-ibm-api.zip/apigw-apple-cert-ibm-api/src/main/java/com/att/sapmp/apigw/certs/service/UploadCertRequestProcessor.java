package com.att.sapmp.apigw.certs.service;

import java.util.Base64;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.certs.exception.ApigwException;
import com.att.sapmp.apigw.certs.service.BaseProcessor;
import com.att.sapmp.apigw.certs.util.CommonDefs;

import io.swagger.annotations.ApiModel;


@ApiModel(value = "CertRequestProcessor", description = "RequestProcessor for incoming request from camel route")
@Component
public class UploadCertRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(UploadCertRequestProcessor.class);

	@Value("${ibm.upload.apple.cert.url}")
	private String uploadAppleCertUrl;
	
	public final void execute(Exchange e) throws ApigwException {
		
		log.info("within execute");
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		validateJSON(postReqJSON, CommonDefs.UPLOADCERTS_MANDATORY_FIELDS);		
		
		Map<String, String> requestListMap = InitializationService.getRequestparammap();
		String certPasswordFormLabelName = requestListMap.get(CommonDefs.UPLOADCERTS_REQUEST_PAYLOAD_CERTIFICATEPHRASE);
		String appleMDMCertFileFormLabelName = requestListMap.get(CommonDefs.UPLOADCERTS_REQUEST_PAYLOAD_APPLEMDMCERTFILE);		
	
		String certPassword = (String)postReqJSON.get(CommonDefs.UPLOADCERTS_REQUEST_PAYLOAD_CERTIFICATEPHRASE);
		String encodedAPNSCertificate = (String)postReqJSON.get(CommonDefs.UPLOADCERTS_REQUEST_PAYLOAD_APPLEMDMCERTFILE);
		StringBuilder uploadAppleCertBase = new StringBuilder(uploadAppleCertUrl);

		String billingId = getBillingId(e);
		uploadAppleCertBase.append("/"+billingId);
		byte[] decodedAPNSCertificate = Base64.getDecoder().decode(encodedAPNSCertificate);
		Message outMsg = e.getOut();
		outMsg.setHeader("IBMUrl", uploadAppleCertBase);
		outMsg.setHeader(CommonDefs.REQUEST_PATH_BILLINGID, billingId);
		MultipartEntityBuilder entity = MultipartEntityBuilder.create();
		entity.addBinaryBody(appleMDMCertFileFormLabelName, decodedAPNSCertificate);
		entity.addTextBody(certPasswordFormLabelName, certPassword);				
		outMsg.setBody(entity.build());
		
	}
	
	private String getBillingId(Exchange e) {
		String postReqUrl = (String) e.getIn().getHeader(Exchange.HTTP_URI);
		int last = postReqUrl.lastIndexOf('/');
		int begin = postReqUrl.lastIndexOf(CommonDefs.GROUP_ACCOUNTS);
		return postReqUrl.substring(begin + 9, last);
	}

}