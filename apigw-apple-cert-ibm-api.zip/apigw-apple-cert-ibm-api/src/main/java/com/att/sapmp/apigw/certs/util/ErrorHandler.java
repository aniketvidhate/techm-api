package com.att.sapmp.apigw.certs.util;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.certs.exception.CErrorDefs;

@Component
public class ErrorHandler {

	private Logger log = LoggerFactory.getLogger(ErrorHandler.class);

	public final void handleError(Exchange e, Exception ex) {

		String stBody = e.getIn().getBody(String.class);

		String stHttpResponseCode;

		if (e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE) != null) {
			stHttpResponseCode = String.valueOf(e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
			log.error("Received CamelHttpResponseCode in handleError method = " + stHttpResponseCode);
		} else {
			stHttpResponseCode = CErrorDefs.ERROR_CODE_500;
		}

		String stDescription = (String) e.getIn().getHeader(CommonDefs.DESCRIPTION);
		String stErrorCode = (String) e.getIn().getHeader(CErrorDefs.ERROR_CODE);

		if (ex != null) {

			log.error("Error occured:", ex);
		}
		// If httpErrorCode is 500 check if there is any MDM specific error that
		// is thrown
		if (ex instanceof org.apache.camel.component.http4.HttpOperationFailedException
				&& CErrorDefs.ERROR_CODE_500.equals(stHttpResponseCode)) {
			org.apache.camel.component.http4.HttpOperationFailedException httpException = (org.apache.camel.component.http4.HttpOperationFailedException) ex;
			stHttpResponseCode = String.valueOf(httpException.getStatusCode());
			stDescription = httpException.getResponseBody();
		}

		JSONObject jsonError = new JSONObject();
		if (stErrorCode != null && !stErrorCode.isEmpty()) {
			jsonError.put(CErrorDefs.ERROR_CODE, stErrorCode);
		} else {
			jsonError.put(CErrorDefs.ERROR_CODE, "E5001");
		}
		if (stDescription != null && !stDescription.isEmpty()) {
			jsonError.put(CommonDefs.DESCRIPTION, stDescription);
			log.error("Received error in handleError method with errorCode=" + stErrorCode + " and description::"
					+ stDescription);
		} else {
			jsonError.put(CommonDefs.DESCRIPTION, (String) CErrorDefs.ERROR_MAP.get(stHttpResponseCode));
			log.error("Received error in handleError method with errorCode=" + stErrorCode + " and details::" + stBody);
		}

		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, stHttpResponseCode);
		e.getOut().setBody(jsonError);

	}
}
