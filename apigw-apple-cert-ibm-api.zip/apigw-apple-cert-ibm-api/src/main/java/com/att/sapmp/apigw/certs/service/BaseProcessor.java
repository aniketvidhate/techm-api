package com.att.sapmp.apigw.certs.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.certs.exception.ApigwException;
import com.att.sapmp.apigw.certs.exception.CErrorDefs;
import com.att.sapmp.apigw.certs.util.CommonDefs;
import com.att.sapmp.apigw.certs.util.CommonUtil;


@Component
public abstract class BaseProcessor {
	
	
	private Logger log = LoggerFactory.getLogger(BaseProcessor.class);
	
	@Autowired
	CommonUtil commonUtil;
	
	public  void process(Exchange e) throws ApigwException {
		
		try {
			
			// validate productCode from header
			String productCode = (String)e.getIn().getHeader(CommonDefs.EMM_PRODUCT_CODE);		
			boolean isProductCodeValid = commonUtil.isProductCodeValid(productCode);
			
			if (!isProductCodeValid) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "Invalid Product Code");
			}
			
			
			String [] requiredHeaders = CommonDefs.NON_ACCOUNT_HEADERS;
			String partnerAccount = (String)e.getIn().getHeader(CommonDefs.PARTNER_ACCOUNT);
			if(partnerAccount != null && "Y".equalsIgnoreCase(partnerAccount)) {
				requiredHeaders = CommonDefs.ACCOUNT_HEADERS;			
			} 
			validateMap(e.getIn().getHeaders(), requiredHeaders);
			execute(e);
			
		}catch (ApigwException iaex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_400);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, iaex.getErrorMsg());
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, iaex.getErrorCode());
			log.error("Caught ApigwException with error message::", iaex);
			throw new ApigwException(iaex.getErrorCode(), iaex.getErrorMsg());
		} 
		catch (Exception ex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_500);
			e.getIn().setHeader(CommonDefs.DESCRIPTION, CErrorDefs.SYSTEM_ERROR);
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_5001);
			log.error("Caught Exception with error message::", ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
		
		
	}
	
	protected void validateMap(Map<String, Object> map, String[] requiredParamList) throws ApigwException {
		for (String requiredParam : requiredParamList) {
			if (!map.containsKey(requiredParam)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002,
						requiredParam + " is a required parameter in the request header.");
			}
			if (map.get(requiredParam) instanceof List) {
				List<String> paramVal = (ArrayList<String>) map.get(requiredParam);
				for (String paramList : paramVal) {
					if (StringUtils.isEmpty(paramList)) {
						throw new ApigwException(CErrorDefs.ERROR_CODE_1002,
								requiredParam + " needs to be populated in the request header.");
					}
				}
			} else {
				String paramValue = (String) map.get(requiredParam);
				if (StringUtils.isEmpty(paramValue)) {
					throw new ApigwException(CErrorDefs.ERROR_CODE_1002,
							requiredParam + " needs to be populated in the request header.");
				}
			}

		}
	}

	public abstract void execute(Exchange e) throws ApigwException;

	protected void validateJSON(JSONObject postReqJSON, String[] requiredParamList) throws ApigwException {
		
		for(String requiredParam : requiredParamList) {
			if(!postReqJSON.has(requiredParam)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002,  requiredParam + " is a required parameter in the input.");
			}
			String paramValue = (String)postReqJSON.get(requiredParam);
			if(StringUtils.isEmpty(paramValue)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, requiredParam + " needs to be populated in the input.");
			}
			
		}
	}
	
	protected boolean validateJSONReq(Object postReqJSON, String[] arrRequiredKeys) throws ApigwException {
		Map<String, String> lstAvailableKeys = new HashMap();
		List<String> lstRequiredKeys = Arrays.asList(arrRequiredKeys);
		validateJSON(postReqJSON, lstAvailableKeys);
		List<String> availableJsonKeys = new ArrayList<String>(lstAvailableKeys.keySet());
		for(String requiredKey : lstRequiredKeys) {
			if(!availableJsonKeys.contains(requiredKey)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002,  requiredKey + " is a required parameter in the input.");
			}
			if(StringUtils.isEmpty(lstAvailableKeys.get(requiredKey))) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, requiredKey + " needs to be populated in the input.");
			}
		}
		return true;
	}

	private void validateJSON(Object postReqJSON, Map<String, String> lstAvailableKeys) throws ApigwException {

		if (postReqJSON instanceof JSONArray) {
			JSONArray postReqJsonArray = (JSONArray) postReqJSON;
			for (int i = 0; i < postReqJsonArray.length(); i++) {
				Object jsonArrayVal =  postReqJsonArray.get(i);
				if(jsonArrayVal instanceof String) {
					lstAvailableKeys.put(CommonDefs.NULL_KEY, (String) jsonArrayVal);
				} else {
					Set<String> set = ((JSONObject) jsonArrayVal).keySet();
					log.debug("within loop i = " + i);
					validateJsonObject(postReqJsonArray.get(i), lstAvailableKeys, set);
				}
			}
		} else if (postReqJSON instanceof JSONObject) {
			Set<String> set = ((JSONObject) postReqJSON).keySet();
			validateJsonObject(postReqJSON, lstAvailableKeys, set);
		}
	}
	
	private void validateJsonObject(Object postReqJSON, Map<String, String> lstAvailableKeys, Set<String> set) throws ApigwException {
		Object jsonValue = null;
		if (!(postReqJSON instanceof JSONObject)) {
			log.info("jsonValue is not JSONObject");
			validateJSON(jsonValue, lstAvailableKeys);
		}
		for (String key : set) {
			jsonValue = ((JSONObject) postReqJSON).get(key);
			log.debug(key + "  -  " + jsonValue);
			if (!(jsonValue instanceof String)) {
				log.info("jsonValue is not String");
				validateJSON(jsonValue, lstAvailableKeys);
				if(lstAvailableKeys.containsKey(CommonDefs.NULL_KEY)) {
					lstAvailableKeys.put(key, lstAvailableKeys.remove(CommonDefs.NULL_KEY));
				}
			} else {
				lstAvailableKeys.put(key, (String) jsonValue);
			}
		}
	}
}
