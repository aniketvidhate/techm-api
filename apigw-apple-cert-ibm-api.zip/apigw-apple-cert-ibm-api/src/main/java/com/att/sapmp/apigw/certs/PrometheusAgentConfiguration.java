package com.att.sapmp.apigw.certs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.att.ajsc.introscope.interceptors.IntroscopeCamelPostInterceptor;
import com.att.ajsc.introscope.interceptors.IntroscopeCamelPreInterceptor;

@Configuration
public class PrometheusAgentConfiguration {


	@Bean
	public IntroscopeCamelPreInterceptor preInterceptor() {
		return new IntroscopeCamelPreInterceptor();
	}

	@Bean
	public IntroscopeCamelPostInterceptor postInterceptor() {
		return new IntroscopeCamelPostInterceptor();
	}

}