package com.att.sapmp.apigw.certs.service;

import java.util.Base64;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.certs.exception.ApigwException;
import com.att.sapmp.apigw.certs.exception.CErrorDefs;
import com.att.sapmp.apigw.certs.service.BaseProcessor;
import com.att.sapmp.apigw.certs.util.CommonDefs;

import io.swagger.annotations.ApiModel;


@ApiModel(value = "CertRequestProcessor", description = "RequestProcessor for incoming request from camel route")
@Component
public class SignCertRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(SignCertRequestProcessor.class);
	@Value("${ibm.sign.csr.url}")
	private String signCSRUrl;

	
	public final void execute(Exchange e) throws ApigwException {		
		log.info("within execute");
		try{
		JSONObject postReqJSON = new JSONObject(e.getIn().getBody(String.class));
		validateJSON(postReqJSON, CommonDefs.SIGNCERTS_MANDATORY_FIELDS);		
		
		Map<String, String> requestListMap = InitializationService.getRequestSignCertParamMap();
		String unsignedCSRFileFormLabelName = requestListMap.get(CommonDefs.SIGNCERTS_REQUEST_PAYLOAD_UNSIGNEDCSR);		
		String encodedUnsignedCSR = (String)postReqJSON.get(CommonDefs.SIGNCERTS_REQUEST_PAYLOAD_UNSIGNEDCSR);
		StringBuilder signCSRBase = new StringBuilder(signCSRUrl);

		String billingId = getBillingId(e);
		signCSRBase.append("/"+billingId);
		
		byte[] decodedUnsignedCSR = Base64.getDecoder().decode(encodedUnsignedCSR);
		Message outMsg = e.getOut();
		outMsg.setHeader("IBMUrl", signCSRBase);
		outMsg.setHeader(CommonDefs.REQUEST_PATH_BILLINGID, billingId);
		MultipartEntityBuilder entity = MultipartEntityBuilder.create();
		entity.addBinaryBody(unsignedCSRFileFormLabelName, decodedUnsignedCSR);
		outMsg.setBody(entity.build());	
		}catch  (Exception ex){
			throw new ApigwException(CErrorDefs.ERROR_CODE_5002, ex.getMessage());
		}
	}
	
	private String getBillingId(Exchange e) {
		String postReqUrl = (String) e.getIn().getHeader(Exchange.HTTP_URI);
		int last = postReqUrl.lastIndexOf('/');
		int begin = postReqUrl.lastIndexOf(CommonDefs.GROUP_ACCOUNTS);
		return postReqUrl.substring(begin + 9, last);
	}	
	
}