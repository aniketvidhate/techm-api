package com.att.sapmp.apigw.certs.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class CertUploadResponse {
	
	Map<Object, Object> actionResponse;

	public Map<Object, Object> getActionResponse() {
		return actionResponse;
	}

	public void setActionResponse(Map<Object, Object> actionResponse) {
		this.actionResponse = actionResponse;
	}
	
	
	
	

}
