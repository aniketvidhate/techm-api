package com.att.oce.service.queue.vo.sub;

public class OCEOrderTaskInfo {

}
