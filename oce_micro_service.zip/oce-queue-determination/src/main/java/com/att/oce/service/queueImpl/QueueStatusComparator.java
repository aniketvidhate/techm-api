/**
 * 
 */
package com.att.oce.service.queueImpl;

import java.util.Comparator;
import java.util.List;

/**
 * @author JK00423295
 *
 */
public class QueueStatusComparator implements Comparator<String> {

	private final List<String> queueStatuses;
	private final int queueStatusSize;
	public QueueStatusComparator(List<String> queueStatuses) {
		this.queueStatuses = queueStatuses;
		this.queueStatusSize = queueStatuses.size();
	}
	
	@Override
	public int compare(String o1, String o2) {
		Integer i1 = queueStatuses.indexOf(o1);
		Integer i2 = queueStatuses.indexOf(o2);
		i1 = (i1 == -1) ? queueStatusSize : i1;
		i2 = (i2 == -1) ? queueStatusSize : i2;
		return i1.compareTo(i2);
	}
}
