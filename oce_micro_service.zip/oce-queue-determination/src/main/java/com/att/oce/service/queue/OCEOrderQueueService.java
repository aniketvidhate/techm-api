/**
 * 
 */
package com.att.oce.service.queue;

import com.att.oce.service.queue.vo.OCEQueueDeterminationRequest;
import com.att.oce.service.queueImpl.QueueDetails;

/**
 * @author JK00423295
 *
 */
public interface OCEOrderQueueService {
	
	abstract public QueueDetails determineQueue(OCEQueueDeterminationRequest request);
}
