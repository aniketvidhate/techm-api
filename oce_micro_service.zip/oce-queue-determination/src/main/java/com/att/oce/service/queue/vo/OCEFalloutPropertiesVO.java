package com.att.oce.service.queue.vo;

/**
 * The Class OCEFalloutPropertiesVO.
 *
 * @author AV00419874
 */


public class OCEFalloutPropertiesVO {

	/** The order id. */
	private String orderId;
	
	/** The line combo. */
	private String lineCombo;
	
	/** The program. */
	private String program;
	
	/** The line action. */
	private String lineAction;

	/**
	 * Instantiates a new OCE action type.
	 */
	public OCEFalloutPropertiesVO(){
		
	}
	
	/**
	 * Gets the order id.
	 *
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}
	
	/**
	 * Sets the order id.
	 *
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
	/**
	 * Gets the line combo.
	 *
	 * @return the lineCombo
	 */
	public String getLineCombo() {
		return lineCombo;
	}
	
	/**
	 * Sets the line combo.
	 *
	 * @param lineCombo the lineCombo to set
	 */
	public void setLineCombo(String lineCombo) {
		this.lineCombo = lineCombo;
	}
	
	/**
	 * Gets the program.
	 *
	 * @return the program
	 */
	public String getProgram() {
		return program;
	}
	
	/**
	 * Sets the program.
	 *
	 * @param program the program to set
	 */
	public void setProgram(String program) {
		this.program = program;
	}
	
	/**
	 * Gets the line action.
	 *
	 * @return the lineAction
	 */
	public String getLineAction() {
		return lineAction;
	}
	
	/**
	 * Sets the line action.
	 *
	 * @param lineAction the lineAction to set
	 */
	public void setLineAction(String lineAction) {
		this.lineAction = lineAction;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEFalloutProperties [orderId=" + orderId + ", lineCombo="
				+ lineCombo + ", program=" + program + ", lineAction="
				+ lineAction + "]";
	}

}
