package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEQueueLineSubstatus.java - hibernate Annotated Class for OCE_QUEUE_LINESUBSTATUS table
 */

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEQueueLineSubstatus.
 */
@Entity
@Table(name="OCE_QUEUE_LINESUBSTATUS")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEQueueLineSubstatus")
public class OCEQueueLineSubstatus {

	/** The id. */
	@Id
	@Column(name="ID")
	private String id;
	
	/** The sequence. */
	@Column(name="SEQUENCE")
	private int sequence;
	
	/** The sub status id. */
	@Column(name="SUBSTATUS_ID")
	private String subStatusId;
	
	
	/**
	 * Instantiates a new OCE queue line substatus.
	 */
	public OCEQueueLineSubstatus(){
		
	}


	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public int getSequence() {
		return sequence;
	}


	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}


	/**
	 * Gets the sub status id.
	 *
	 * @return the subStatusId
	 */
	public String getSubStatusId() {
		return subStatusId;
	}


	/**
	 * Sets the sub status id.
	 *
	 * @param subStatusId the subStatusId to set
	 */
	public void setSubStatusId(String subStatusId) {
		this.subStatusId = subStatusId;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueueLineSubstatus [id=" + id + ", sequence=" + sequence
				+ ", subStatusId=" + subStatusId + "]";
	}

	
}
