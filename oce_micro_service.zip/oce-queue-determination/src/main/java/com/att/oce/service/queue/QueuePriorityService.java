package com.att.oce.service.queue;

import java.util.List;
import java.util.Map;

import com.att.oce.oce.namespaces.types._private.ocedatamodel.Order;
import com.att.oce.service.queue.vo.OCEActualScheduleTypeVO;
import com.att.oce.service.queue.vo.OCEFalloutPropertiesVO;
import com.att.oce.service.queue.vo.OCEOrderSchedulingInfoVO;
import com.att.oce.service.queue.vo.OCEQueuePriorityCriteriaVO;
import com.att.oce.service.queue.vo.OCEQueuePriorityDataVO;
import com.att.oce.service.queue.vo.OCEQueuePriorityRefVO;
import com.att.oce.service.queue.vo.OCESchedulingInfoListVO;
import com.att.oce.service.queue.vo.sub.OCEOrderInfo;

public interface QueuePriorityService {

	public List<OCEQueuePriorityRefVO> getQueuePrirityDetailsVO(String queueId);
	
	public List<OCEQueuePriorityDataVO> getQueuePriorityDataVO(List<OCEQueuePriorityRefVO> queuePriorityRefVOs);
	
	public List<OCEQueuePriorityCriteriaVO> getQueuePriorityCriteriaVO(List<OCEQueuePriorityDataVO> queuePriorityDateVOs);
	
	public String determineQueuePriority(OCEOrderInfo oceOrderInfo, List<OCEQueuePriorityDataVO> queuePriorityDataVO,List<OCEQueuePriorityCriteriaVO> getQueuePriorityCriteriaVO);
	
	public Map<String, List<String>> getPriorityCriteriaListMap(List<String> criteriaList, OCEOrderInfo oceOrderInfo); 
	
}
