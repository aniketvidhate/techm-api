package com.att.oce.service.queue.vo;

/**
 * The Class OCELineSubstatusVO.
 *
 * @author AV00419874
 */

public class OCELineSubstatusVO {

	/** The id. */
	private String id;
	
	/** The line sub status. */
	private String lineSubStatus;
	
	/** The product category. */
	private String productCategory;
	
	/** The status. */
	private String status;
	
	/** The queue sub type. */
	private String queueSubType;
	
	/** The is bulk. */
	private int isBulk;
	
	/** The is connected car. */
	private int isConnectedCAR;
	
	/** The manual intervention. */
	private int manualIntervention;


	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Gets the line sub status.
	 *
	 * @return the lineSubStatus
	 */
	public String getLineSubStatus() {
		return lineSubStatus;
	}

	/**
	 * Sets the line sub status.
	 *
	 * @param lineSubStatus the lineSubStatus to set
	 */
	public void setLineSubStatus(String lineSubStatus) {
		this.lineSubStatus = lineSubStatus;
	}

	/**
	 * Gets the product category.
	 *
	 * @return the productCategory
	 */
	public String getProductCategory() {
		return productCategory;
	}

	/**
	 * Sets the product category.
	 *
	 * @param productCategory the productCategory to set
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Gets the checks if is bulk.
	 *
	 * @return the isBulk
	 */
	public int getIsBulk() {
		return isBulk;
	}

	/**
	 * Sets the checks if is bulk.
	 *
	 * @param isBulk the isBulk to set
	 */
	public void setIsBulk(int isBulk) {
		this.isBulk = isBulk;
	}

	/**
	 * Gets the checks if is connected car.
	 *
	 * @return the isConnectedCAR
	 */
	public int getIsConnectedCAR() {
		return isConnectedCAR;
	}

	/**
	 * Sets the checks if is connected car.
	 *
	 * @param isConnectedCAR the isConnectedCAR to set
	 */
	public void setIsConnectedCAR(int isConnectedCAR) {
		this.isConnectedCAR = isConnectedCAR;
	}

	/**
	 * Gets the manual intervention.
	 *
	 * @return the manualIntervention
	 */
	public int getManualIntervention() {
		return manualIntervention;
	}

	/**
	 * Sets the manual intervention.
	 *
	 * @param manualIntervention the manualIntervention to set
	 */
	public void setManualIntervention(int manualIntervention) {
		this.manualIntervention = manualIntervention;
	}

	/**
	 * Gets the queue sub type.
	 *
	 * @return the queueSubType
	 */
	public String getQueueSubType() {
		return queueSubType;
	}

	/**
	 * Sets the queue sub type.
	 *
	 * @param queueSubType the queueSubType to set
	 */
	public void setQueueSubType(String queueSubType) {
		this.queueSubType = queueSubType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCELineSubstatusVO [id=" + id + ", lineSubStatus=" + lineSubStatus
				+ ", productCategory=" + productCategory + ", status=" + status
				+ ", queueSubType=" + queueSubType + ", isBulk=" + isBulk
				+ ", isConnectedCAR=" + isConnectedCAR + ", manualIntervention="
				+ manualIntervention + "]";
	}




}
