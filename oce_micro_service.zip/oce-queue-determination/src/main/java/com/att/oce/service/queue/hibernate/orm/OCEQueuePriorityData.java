package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEQueuePriorityData.java - hibernate Annotated Class for OCE_QUEUE_PRIORITY_DATA table
 */

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEQueuePriorityData.
 */
@Entity
@Table(name="OCE_QUEUE_PRIORITY_DATA")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEQueuePriorityData")
public class OCEQueuePriorityData {

	/** The queue priority criteria id. */
	@Id
	@Column(name="QUEUE_PRIORITY_CRITERIA_ID")
	private String queuePriorityCriteriaId;
	
	/** The criteria data. */
	@Column(name="CRITERIA_DATA")
	private String criteriaData;
	
	/** The criteria value. */
	@Column(name="CRITERIA_VALUE")
	private String criteriaValue;
	
	/** The criteria ranking. */
	@Column(name="CRITERIA_RANKING")
	private int criteriaRanking;
	
	
	/**
	 * Instantiates a new OCE queue priority data.
	 */
	public OCEQueuePriorityData(){
		
	}


	/**
	 * Gets the queue priority criteria id.
	 *
	 * @return the queuePriorityCriteriaId
	 */
	public String getQueuePriorityCriteriaId() {
		return queuePriorityCriteriaId;
	}


	/**
	 * Sets the queue priority criteria id.
	 *
	 * @param queuePriorityCriteriaId the queuePriorityCriteriaId to set
	 */
	public void setQueuePriorityCriteriaId(String queuePriorityCriteriaId) {
		this.queuePriorityCriteriaId = queuePriorityCriteriaId;
	}


	/**
	 * Gets the criteria data.
	 *
	 * @return the criteriaData
	 */
	public String getCriteriaData() {
		return criteriaData;
	}


	/**
	 * Sets the criteria data.
	 *
	 * @param criteriaData the criteriaData to set
	 */
	public void setCriteriaData(String criteriaData) {
		this.criteriaData = criteriaData;
	}


	/**
	 * Gets the criteria value.
	 *
	 * @return the criteriaValue
	 */
	public String getCriteriaValue() {
		return criteriaValue;
	}


	/**
	 * Sets the criteria value.
	 *
	 * @param criteriaValue the criteriaValue to set
	 */
	public void setCriteriaValue(String criteriaValue) {
		this.criteriaValue = criteriaValue;
	}


	/**
	 * Gets the criteria ranking.
	 *
	 * @return the criteriaRanking
	 */
	public int getCriteriaRanking() {
		return criteriaRanking;
	}


	/**
	 * Sets the criteria ranking.
	 *
	 * @param criteriaRanking the criteriaRanking to set
	 */
	public void setCriteriaRanking(int criteriaRanking) {
		this.criteriaRanking = criteriaRanking;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueuePriorityData [queuePriorityCriteriaId="
				+ queuePriorityCriteriaId + ", criteriaData=" + criteriaData
				+ ", criteriaValue=" + criteriaValue + ", criteriaRanking="
				+ criteriaRanking + "]";
	}

}
