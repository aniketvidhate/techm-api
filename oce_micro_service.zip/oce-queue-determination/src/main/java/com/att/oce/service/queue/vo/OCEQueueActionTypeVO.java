package com.att.oce.service.queue.vo;


/**
 * The Class OCEQueueActionTypeVO.
 *
 * @author AV00419874
 */

public class OCEQueueActionTypeVO {

	/** The id. */
	private String id;
	
	/** The sequence. */
	private int sequence;
	
	/** The action type id. */
	private String actionTypeId;
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public int getSequence() {
		return sequence;
	}
	
	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	
	/**
	 * Gets the action type id.
	 *
	 * @return the actionTypeId
	 */
	public String getActionTypeId() {
		return actionTypeId;
	}
	
	/**
	 * Sets the action type id.
	 *
	 * @param actionTypeId the actionTypeId to set
	 */
	public void setActionTypeId(String actionTypeId) {
		this.actionTypeId = actionTypeId;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueueActionTypeVO [id=" + id + ", sequence=" + sequence
				+ ", actionTypeId=" + actionTypeId + "]";
	}


}
