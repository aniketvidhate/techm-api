package com.att.oce.service.queue.hibernate.orm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**@author av00419874
 * The Class OCEQueueDetails.
 */
@Entity
@Table(name = "OCE_QUEUE_DETAILS")
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="OCEQueueDetails")
public class OCEQueueDetails {

	/** The m task id. */
	@Id
	@Column(name = "task_id")
	private String mTaskId;

	/** The m line Queue ID. */
	@Column(name = "QUEUE_ID")
	private String mQueue_id;
	
	/** The m line combos. */
	@Column(name = "Linecombos")
	private String mLineCombos;
	
	/** The m line action. */
	@Column(name = "Line_action")
	private String mLineAction;
	
	/** The m program. */
	@Column(name = "Program_name")
	private String mProgram;
	
	/** The m queue type. */
	@Column(name = "Queue_type")
	private String mQueueType;
	
	
	/** The m queue sub type. */
	@Column(name = "Queue_SUB_type")
	private String mQueueSubType;
	
	/** The m queue category. */
	@Column(name = "queue_category")
	private String mQueueCategory;
	
	/** The m line count. */
	@Column(name = "line_count")
	private String mLineCount;
	
	/** The m Rep Comments. */
	@Column(name = "REP_COMMENTS")
	private String mRepComments;
	
	/**
	 * Gets the task id.
	 *
	 * @return the task id
	 */
	public String getTaskId() {
		return mTaskId;
	}

	/**
	 * Sets the task id.
	 *
	 * @param mTaskId the new task id
	 */
	public void setTaskId(String mTaskId) {
		this.mTaskId = mTaskId;
	}

	/**
	 * Gets the queue category.
	 *
	 * @return the queue category
	 */
	public String getQueueCategory() {
		return mQueueCategory;
	}

	/**
	 * Sets the queue category.
	 *
	 * @param mQueueCategory the new queue category
	 */
	public void setQueueCategory(String mQueueCategory) {
		this.mQueueCategory = mQueueCategory;
	}

	/**
	 * Gets the line count.
	 *
	 * @return the line count
	 */
	public String getLineCount() {
		return mLineCount;
	}

	/**
	 * Sets the line count.
	 *
	 * @param mLineCount the new line count
	 */
	public void setLineCount(String mLineCount) {
		this.mLineCount = mLineCount;
	}

	/**
	 * Gets the line combos.
	 *
	 * @return the line combos
	 */
	public String getLineCombos() {
		return mQueue_id;
	}

	/**
	 * Sets the line combos.
	 *
	 * @param mLineCombos the new line combos
	 */
	public void setLineCombos(String mLineCombos) {
		this.mQueue_id = mLineCombos;
	}

	/**
	 * Gets the line action.
	 *
	 * @return the line action
	 */
	public String getLineAction() {
		return mLineAction;
	}

	/**
	 * Sets the line action.
	 *
	 * @param mLineAction the new line action
	 */
	public void setLineAction(String mLineAction) {
		this.mLineAction = mLineAction;
	}

	/**
	 * Gets the program.
	 *
	 * @return the program
	 */
	public String getProgram() {
		return mProgram;
	}

	/**
	 * Sets the program.
	 *
	 * @param mProgram the new program
	 */
	public void setProgram(String mProgram) {
		this.mProgram = mProgram;
	}

	/**
	 * Gets the queue type.
	 *
	 * @return the queue type
	 */
	public String getQueueType() {
		return mQueueType;
	}

	/**
	 * Sets the queue type.
	 *
	 * @param mQueueType the new queue type
	 */
	public void setQueueType(String mQueueType) {
		this.mQueueType = mQueueType;
	}

	/**
	 * @return the mQueue_id
	 */
	public String getQueue_id() {
		return mQueue_id;
	}

	/**
	 * @param pQueue_id the mQueue_id to set
	 */
	public void setQueue_id(String pQueue_id) {
		this.mQueue_id = pQueue_id;
	}

	/**
	 * @return the mQueueSubType
	 */
	public String getQueueSubType() {
		return mQueueSubType;
	}

	/**
	 * @param pQueueSubType the mQueueSubType to set
	 */
	public void setQueueSubType(String pQueueSubType) {
		this.mQueueSubType = pQueueSubType;
	}

	/**
	 * @return the mRepComments
	 */
	public String getRepComments() {
		return mRepComments;
	}

	/**
	 * @param pRepComments the mRepComments to set
	 */
	public void setRepComments(String pRepComments) {
		this.mRepComments = pRepComments;
	}
	

}
