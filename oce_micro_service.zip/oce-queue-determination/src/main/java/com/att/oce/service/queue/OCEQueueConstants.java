/**
 * 
 */
package com.att.oce.service.queue;

import org.springframework.stereotype.Component;

/**
 * @author JK00423295
 *
 */
@Component
public final class OCEQueueConstants {
	
	public static final String QUEUE_CTGRY_DEFAULT = "NA";
	public static final String CDE_HS_CHANNEL = "CDE-HS";
	public static final String PROGRAM_UNIFICATION_ONLY ="UNIFICATION ONLY";
	public static final String QUEUE_CTGRY_REGULAR = "REGULAR";
	public static String[] QUEUE_STATUSES = {"IN_QUEUE","FOLLOWUP_REQUIRED","SHIPPED", "ACTIVATED", "PENDING", "CANCELED"};
	public static String[] NON_UNIFY_WIRELESS_PROGRAM = {"UNIFY","CHANGE","NO_CHANGE"};
	public static String[] WIRELESS_PROGRAM_CHANNEL = {"DE-MOBILITY","CRU-MOBILITY"};
	public static String DATE_FORMAT = "dd-MMM-yy HH:mm:ss:SSS";
	public static String DEFAULT_QUEUE_NAME = "UNDEFINED";
	public static String QUEUE_SUB_TYPE_OUTBOUND = "OUTBOUND";
	
	public static String PROGRAM_NDD = "NDDD";
	public static String NACK_QUEUE_TYPE = "NACK TRIAGE";
	
	public static String ID = "id";
	public static String ORDER_ID_PROP_VALUE = "orderId";
	public static String FULFILLMENT_METHOD = "FULFILLMENT_METHOD";
	public static String PREORDER = "PREORDER";
	public static String FAN = "FAN";
	public static String CONTRACT_TYPE = "CONTRACT_TYPE";
	public static String PRODUCT_SKU = "PRODUCT_SKU";
	public static String UDL = "UDL";
	public static String CRU_MOBILITY_CHANNEL = "CRU-MOBILITY"; 
	public static String SOR = "SOR";
	public static String PRE_ORDER = "PREORDER";
	public static String IN_QUEUE = "IN_QUEUE";
	public static String WIRELESS = "WIRELESS";
	public static String NEW = "NEW";
}
