package com.att.oce.service.queue.vo;

/**
 * The Class OCEOrderB2BVO.
 *
 * @author AV00419874
 */


public class OCEOrderB2BVO {

	/** The order id. */
	private String orderId;
	
	/** The sequence. */
	private String sequence;
	
	/** The b2b id. */
	private String b2bId;
	
	/**
	 * Instantiates a new OCE order b2 bvo.
	 */
	public OCEOrderB2BVO(){
		
	}

	/**
	 * Gets the order id.
	 *
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * Sets the order id.
	 *
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public String getSequence() {
		return sequence;
	}

	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	/**
	 * Gets the b2b id.
	 *
	 * @return the b2bId
	 */
	public String getB2bId() {
		return b2bId;
	}

	/**
	 * Sets the b2b id.
	 *
	 * @param b2bId the b2bId to set
	 */
	public void setB2bId(String b2bId) {
		this.b2bId = b2bId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEOrderB2B [orderId=" + orderId + ", sequence=" + sequence
				+ ", b2bId=" + b2bId + "]";
	}


}
