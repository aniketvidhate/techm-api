package com.att.oce.service.queue.vo;


/**
 * The Class OCEQueuePriorityCriteriaVO.
 *
 * @author AV00419874
 */

public class OCEQueuePriorityCriteriaVO {

	/** The priority criteria name. */
	private String priorityCriteriaName;
	
	/** The priority criteria xpath. */
	private String priorityCriteriaXpath;
	
	/** The priority criteria rerpopath. */
	private String priorityCriteriaRerpopath;
	
	
	/**
	 * Instantiates a new OCE queue priority criteria vo.
	 */
	public OCEQueuePriorityCriteriaVO(){
		
	}

	
	/**
	 * Gets the priority criteria name.
	 *
	 * @return the priority criteria name
	 */
	public String getPriorityCriteriaName() {
		return priorityCriteriaName;
	}

	/**
	 * Sets the priority criteria name.
	 *
	 * @param priorityCriteriaName the new priority criteria name
	 */
	public void setPriorityCriteriaName(String priorityCriteriaName) {
		this.priorityCriteriaName = priorityCriteriaName;
	}

	/**
	 * Gets the priority criteria xpath.
	 *
	 * @return the priority criteria xpath
	 */
	public String getPriorityCriteriaXpath() {
		return priorityCriteriaXpath;
	}

	/**
	 * Sets the priority criteria xpath.
	 *
	 * @param priorityCriteriaXpath the new priority criteria xpath
	 */
	public void setPriorityCriteriaXpath(String priorityCriteriaXpath) {
		this.priorityCriteriaXpath = priorityCriteriaXpath;
	}

	/**
	 * Gets the priority criteria rerpopath.
	 *
	 * @return the priority criteria rerpopath
	 */
	public String getPriorityCriteriaRerpopath() {
		return priorityCriteriaRerpopath;
	}

	/**
	 * Sets the priority criteria rerpopath.
	 *
	 * @param priorityCriteriaRerpopath the new priority criteria rerpopath
	 */
	public void setPriorityCriteriaRerpopath(String priorityCriteriaRerpopath) {
		this.priorityCriteriaRerpopath = priorityCriteriaRerpopath;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueuePriorityCriteriaVO [priorityCriteriaName="
				+ priorityCriteriaName + ", priorityCriteriaXpath="
				+ priorityCriteriaXpath + ", priorityCriteriaRerpopath="
				+ priorityCriteriaRerpopath + "]";
	}
	

}
