package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEQueuePriorityRef.java - hibernate Annotated Class 
 * for OCE_QUEUE_PRIORITY_REF table
 */

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEQueuePriorityRef.
 */
@Entity
@Table(name="OCE_QUEUE_PRIORITY_REF")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEQueuePriorityRef")
public class OCEQueuePriorityRef {

	/** The oce queue priority ref_ pk. */
	@EmbeddedId
	private OCEQueuePriorityRef_PK oceQueuePriorityRef_PK;
	
	/** The queue priority criteria id. */
	@Column(name="QUEUE_PRIORITY_CRITERIA_ID")
	private String queuePriorityCriteriaId;
	
	/**
	 * Instantiates a new OCE queue priority ref.
	 */
	public OCEQueuePriorityRef(){
		
	}

	/**
	 * Gets the oce queue priority ref_ pk.
	 *
	 * @return the oceQueuePriorityRef_PK
	 */
	public OCEQueuePriorityRef_PK getOceQueuePriorityRef_PK() {
		return oceQueuePriorityRef_PK;
	}

	/**
	 * Sets the oce queue priority ref_ pk.
	 *
	 * @param oceQueuePriorityRef_PK the oceQueuePriorityRef_PK to set
	 */
	public void setOceQueuePriorityRef_PK(
			OCEQueuePriorityRef_PK oceQueuePriorityRef_PK) {
		this.oceQueuePriorityRef_PK = oceQueuePriorityRef_PK;
	}

	/**
	 * Gets the queue priority criteria id.
	 *
	 * @return the queuePriorityCriteriaId
	 */
	public String getQueuePriorityCriteriaId() {
		return queuePriorityCriteriaId;
	}

	/**
	 * Sets the queue priority criteria id.
	 *
	 * @param queuePriorityCriteriaId the queuePriorityCriteriaId to set
	 */
	public void setQueuePriorityCriteriaId(String queuePriorityCriteriaId) {
		this.queuePriorityCriteriaId = queuePriorityCriteriaId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueuePriorityRef [oceQueuePriorityRef_PK="
				+ oceQueuePriorityRef_PK + ", queuePriorityCriteriaId="
				+ queuePriorityCriteriaId + "]";
	}

}
