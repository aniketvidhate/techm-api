package com.att.oce.service.queue.vo;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroup;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroupCharacteristics;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtLoSGCharacteristics;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtLoSGStatus;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtOrderSource;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.GroupList;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.Order;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StLoSGType;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StProductCategory;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StRequestType;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtOrderTask;
import com.att.oce.service.queue.OCEQueueConstants;
import com.att.oce.service.queue.vo.sub.OCEOrderInfo;
import com.att.oce.service.queue.vo.sub.OCEOrderTaskInfo;
import com.att.oce.service.queueImpl.QueueDetails;
import com.att.ooce.core.ProcessOrderRequest;

/**
 * The Class OCEQueueDeterminationRequest.
 */
public class OCEQueueDeterminationRequest {
	private Logger logger = LoggerFactory.getLogger(OCEQueueDeterminationRequest.class);
	
	public OCEQueueDeterminationRequest(){
		
	}
	/**
	 * 
	 * @param request
	 * @param processOrderRequest
	 */
	public OCEQueueDeterminationRequest(ProcessOrderRequest processOrderRequest) {

		logger.info("Hello OCE");

		OCEOrderInfo oceOrderInfo = new OCEOrderInfo();
		Order order = processOrderRequest.getOrder();
		List<CtOrderTask> orderTasklist = processOrderRequest.getOrderTasks().getOrderTask();
		
		
		CtOrderSource ctOrderSource = processOrderRequest.getOrder().getOrderSource();
		boolean nonUnifyWireless = true;
		StRequestType stRequestType = order.getRequestType();
		String requestType = null;
		if (null != stRequestType) {
			requestType = stRequestType.value();
			if(order.getOrderSource().getChannel().equalsIgnoreCase(OCEQueueConstants.CRU_MOBILITY_CHANNEL)
					&& null == requestType) {
				requestType = OCEQueueConstants.SOR;
			}
		}
		String requestId = null;
		if (null != order.getRequestId()) {
			requestId = order.getRequestId().getValue();
		}
		if (null != processOrderRequest.getOrder().getB2Bs() 
				&& null != processOrderRequest.getOrder().getB2Bs().getB2B()) {
			oceOrderInfo.setCtB2BList(processOrderRequest.getOrder().getB2Bs().getB2B());
		}
		oceOrderInfo.setCtOrderSource(ctOrderSource);
		oceOrderInfo.setGroupList(processOrderRequest.getOrder().getGroups());
		oceOrderInfo.setOceOrderNumber(order.getOCEOrderNumber());
		oceOrderInfo.setRequestId(requestId);
		oceOrderInfo.setRequestType(requestType);
		oceOrderInfo.setNonUnifyWireless(nonUnifyWireless);
		oceOrderInfo.setOrderTasklist(orderTasklist);
		oceOrderInfo.setProgramName(order.getProgramName());
		oceOrderInfo.setCtSchedulingInfoList(order.getSchedulingInfos());
		this.order = oceOrderInfo;
		//request.setOrder(oceOrderInfo);
	
	}
	/** The order. */
	private OCEOrderInfo order; 
	
	/** The order tasklist. */
	private List<OCEOrderTaskInfo> orderTasklist; 
	
	/** The non unify wireless. */
	private boolean nonUnifyWireless;
	
	/**
	 * Gets the order.
	 *
	 * @return the order
	 */
	public OCEOrderInfo getOrder() {
		return order;
	}
	
	/**
	 * Gets the order tasklist.
	 *
	 * @return the orderTasklist
	 */
	public List<OCEOrderTaskInfo> getOrderTasklist() {
		return orderTasklist;
	}
	
	/**
	 * Checks if is non unify wireless.
	 *
	 * @return the nonUnifyWireless
	 */
	public boolean isNonUnifyWireless() {
		return nonUnifyWireless;
	}
	
	/**
	 * Sets the order.
	 *
	 * @param order the order to set
	 */
	public void setOrder(OCEOrderInfo order) {
		this.order = order;
	}
	
	/**
	 * Sets the order tasklist.
	 *
	 * @param orderTasklist the orderTasklist to set
	 */
	public void setOrderTasklist(List<OCEOrderTaskInfo> orderTasklist) {
		this.orderTasklist = orderTasklist;
	}
	
	/**
	 * Sets the non unify wireless.
	 *
	 * @param nonUnifyWireless the nonUnifyWireless to set
	 */
	public void setNonUnifyWireless(boolean nonUnifyWireless) {
		this.nonUnifyWireless = nonUnifyWireless;
	}
}
