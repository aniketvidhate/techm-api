package com.att.oce.service.queueImpl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtActualSchedule;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtSchedulingInfo;
import com.att.oce.service.DateUtil;
import com.att.oce.service.queue.OCEQueueConstants;
import com.att.oce.service.queue.QueueCategoryService;
import com.att.oce.service.queue.QueuePriorityService;
import com.att.oce.service.queue.vo.OCEActualScheduleTypeVO;
import com.att.oce.service.queue.vo.OCEOrderSchedulingInfoVO;
import com.att.oce.service.queue.vo.OCEQueueDeterminationRequest;
import com.att.oce.service.queue.vo.OCESchedulingInfoListVO;
import com.att.oce.service.task.Exception.OCEException;

@Component
public class QueueCategoryServiceImpl implements QueueCategoryService{
	
	private Logger logger = LoggerFactory.getLogger(QueueCategoryServiceImpl.class);

	@Autowired
	OCEQueueConstants queueConstants;
	@Autowired
	QueuePriorityService queuePriorityService;
	/* (non-Javadoc)
	 * @see com.att.oce.service.queue.QueueCategoryService#getQueueCatagory(java.lang.String, com.att.oce.oce.namespaces.types._private.ocedatamodel.Order, java.util.List, java.lang.String, java.util.List, boolean)
	 */
	@Override
	public String getQueueCatagory(String queueType, OCEQueueDeterminationRequest request, boolean nonUnifyWireless) {
		String queueCategory = queueConstants.QUEUE_CTGRY_DEFAULT;
		boolean nextDayApptmnt = false;  
		if(OCEQueueConstants.CDE_HS_CHANNEL.equalsIgnoreCase(request.getOrder().getCtOrderSource().getChannel())) {
				try {
					nextDayApptmnt = isAppointmentForNextDay(request);
				} catch (OCEException e) {
					if (logger.isErrorEnabled()) {
						logger.error(e.getMessage());
					}
				}
			String programName = request.getOrder().getProgramName();
			if(OCEQueueConstants.PROGRAM_UNIFICATION_ONLY.equalsIgnoreCase(programName)) {
				queueCategory = queueConstants.QUEUE_CTGRY_REGULAR;
			} else if(nextDayApptmnt) {
				queueCategory = OCEQueueConstants.PROGRAM_NDD; //TODO: to make it configurable property.
			} else if(OCEQueueConstants.NACK_QUEUE_TYPE.equalsIgnoreCase(queueType)) { //TODO: to make it configurable property.
				queueCategory = OCEQueueConstants.NACK_QUEUE_TYPE; 
			} else {
				queueCategory = queueConstants.QUEUE_CTGRY_REGULAR;
			}
		}
		return queueCategory;
	}

	/**
	 * The method checks for next day appointment from order repo
	 * @param orderRepo
	 * @param schedulingInfoRefIds
	 * @return
	 * @throws OCEOrderException
	 */
	public boolean isAppointmentForNextDay(OCEQueueDeterminationRequest request) throws OCEException {
		String conversationId = "";
		
		String orderId = request.getOrder().getOceOrderNumber();//orderRepoItem.getRepositoryId();
		if(null != request.getOrder().getRequestId()){
			conversationId = request.getOrder().getRequestId();
		}
		if (logger.isDebugEnabled()) {
			logger.debug(conversationId, orderId, "Entered isAppointmentForNextDay(Order Payload, List<String>)");
		}

		boolean nextDayAppointment = false;
		if (null != request.getOrder().getCtSchedulingInfoList()
				&& null != request.getOrder().getCtSchedulingInfoList().getSchedulingInfo()) {
			List<CtSchedulingInfo> schedulingInfos = request.getOrder().getCtSchedulingInfoList().getSchedulingInfo();
			if (null != schedulingInfos) {
				for (CtSchedulingInfo schedulingRepoItem : schedulingInfos) {
					CtActualSchedule ctActualSchedule = null;
					if (null != schedulingRepoItem) {
						ctActualSchedule = schedulingRepoItem.getConfirmedSchedule();
					}
					if(null != ctActualSchedule) {
						Date actualAppointmentDate = null;
						Date currentDate = DateUtil.getCurrentTimeAsGMT();
						long diff = 0l, diffDays=0l;
						if (null != ctActualSchedule.getSelectedAppointmentDate()) {
							actualAppointmentDate = DateUtil.stringDateToDate(ctActualSchedule.getSelectedAppointmentDate());
						}
						if (null != actualAppointmentDate) {
							diff = DateUtil.getDayDiff(actualAppointmentDate, currentDate);
						}
						diffDays = diff / (24 * 60 * 60 * 1000);
						if (logger.isDebugEnabled()) {
							logger.debug(conversationId, orderId, "Difference in date : "+diffDays);
						}
						if(diffDays == 1) {
							nextDayAppointment=true;
							break;

						}

					}
				}
			}
		} 
		if (logger.isDebugEnabled()) {
			logger.debug(conversationId, orderId, "Leaving isAppointmentForNextDay(OCEOrderImpl, List<String>)");
		}
		return nextDayAppointment;
	}

}
