package com.att.oce.service.queue.vo;

/**
 * @author AV00419874
 */

import java.util.Date;

/**
 * The Class OCEQueueMasterVO.
 */
public class OCEQueueMasterVO {

	/** The id. */
	private String id;
	
	/** The queue type. */
	private String queueType;
	
	/** The queue description. */
	private String queueDescription;
	
	/** The priority. */
	private Integer priority;
	
	/** The line combo flag. */
	private String lineComboFlag;
	
	/** The enterprise type. */
	private String enterpriseType;
	
	/** The user roles. */
	private String userRoles;
	
	/** The release lock. */
	private Integer releaseLock;
	
	/** The vacant alert. */
	private Integer vacantAlert;
	
	/** The vacant alert email. */
	private String vacantAlertEmail;
	
	/** The fallouts threshold. */
	private Integer falloutsThreshold;
	
	/** The no_ order alert. */
	private Integer no_OrderAlert;
	
	/** The creation date. */
	private Date creationDate;
	
	/** The last modied date. */
	private Date lastModiedDate;
	
	/** The threshold count. */
	private Integer thresholdCount;
	
	/** The queue limit alert email. */
	private String queueLimitAlertEmail;
	
	/** The effective from date. */
	private Date effectiveFromDate;
	
	/** The effective till date. */
	private Date effectiveTillDate;
	
	/** The sku. */
	private String sku;
	
	/** The is order level queue. */
	private Integer isOrderLevelQueue;
	
	/** The channel. */
	private String channel;
	
	/** The callback preference. */
	private String callbackPreference;
	
	/** The active. */
	private String active;
	
	/** The rep commnets. */
	private String repCommnets;
	
	/** The queue info. */
	private String queueInfo;
	
	/** The escalation type. */
	private String escalationType;
	
	/** The escalation priority. */
	private String escalationPriority;
	
	/** The giga ind. */
	private String gigaInd;
	
	/** The queue group. */
	private String queueGroup;
	
	/** The request type. */
	private String requestType;
	
	/** The last modified by. */
	private String lastModifiedBy;
	
	/** The last_ modified_ by. */
	private String last_Modified_By;

	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Gets the queue type.
	 *
	 * @return the queueType
	 */
	public String getQueueType() {
		return queueType;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Sets the queue type.
	 *
	 * @param queueType the queueType to set
	 */
	public void setQueueType(String queueType) {
		if(queueType != null){
			this.queueType = queueType;
		}else{
			this.queueType = "";
		}
	}
	
	
	/**
	 * Gets the queue description.
	 *
	 * @return the queueDescription
	 */
	public String getQueueDescription() {
		return queueDescription;
	}
	
	
	/**
	 * Sets the queue description.
	 *
	 * @param queueDescription the new queue description
	 */
	public void setQueueDescription(String queueDescription) {
		if(queueDescription != null){
			this.queueDescription = queueDescription;
		}else{
			this.queueDescription = "";
		}
	}
	
	
	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public Integer getPriority() {
		return priority;
	}
	
	
	/**
	 * Sets the priority.
	 *
	 * @param priority the new priority
	 */
	public void setPriority(Integer priority) {
		if (priority != null) {
			this.priority = priority.intValue();
		}
		else{
			this.priority = -1;
		}
	}
 	
	
	/**
	 * Gets the line combo flag.
	 *
	 * @return the line combo flag
	 */
	public String getLineComboFlag() {
		return lineComboFlag;
	}
	
	
	/**
	 * Sets the line combo flag.
	 *
	 * @param lineComboFlag the new line combo flag
	 */
	public void setLineComboFlag(String lineComboFlag) {
		if(lineComboFlag != null){
			this.lineComboFlag = lineComboFlag;
		}else{
			this.lineComboFlag = "";
		}
	}
	
	
	/**
	 * Gets the enterprise type.
	 *
	 * @return the enterprise type
	 */
	public String getEnterpriseType() {
		return enterpriseType;
	}
	
	
	/**
	 * Sets the enterprise type.
	 *
	 * @param enterpriseType the new enterprise type
	 */
	public void setEnterpriseType(String enterpriseType) {
		if(enterpriseType != null){
			this.enterpriseType = enterpriseType;
		}else{
			this.enterpriseType = "";
		}
	}
	
	
	/**
	 * Gets the user roles.
	 *
	 * @return the user roles
	 */
	public String getUserRoles() {
		return userRoles;
	}
	
	
	/**
	 * Sets the user roles.
	 *
	 * @param userRoles the new user roles
	 */
	public void setUserRoles(String userRoles) {
		if(userRoles != null){
			this.userRoles = userRoles;
		}else{
			this.userRoles = "";
		}
	}
	
	
	/**
	 * Gets the release lock.
	 *
	 * @return the release lock
	 */
	public Integer getReleaseLock() {
		return releaseLock;
	}
	
	
	/**
	 * Sets the release lock.
	 *
	 * @param releaseLock the new release lock
	 */
	public void setReleaseLock(Integer releaseLock) {

		if (releaseLock != null) {
			this.releaseLock = releaseLock.intValue();
		}
		else{
			this.releaseLock = -1;
		}
	}
	
	
	/**
	 * Gets the vacant alert.
	 *
	 * @return the vacant alert
	 */
	public Integer getVacantAlert() {
		return vacantAlert;
	}
	
	
	/**
	 * Sets the vacant alert.
	 *
	 * @param vacantAlert the new vacant alert
	 */
	public void setVacantAlert(Integer vacantAlert) {
		if (vacantAlert != null) {
			this.vacantAlert = vacantAlert.intValue();
		}
		else{
			this.vacantAlert = -1;
		}
	}
	
	
	/**
	 * Gets the vacant alert email.
	 *
	 * @return the vacant alert email
	 */
	public String getVacantAlertEmail() {
		return vacantAlertEmail;
	}
	
	
	/**
	 * Sets the vacant alert email.
	 *
	 * @param vacantAlertEmail the new vacant alert email
	 */
	public void setVacantAlertEmail(String vacantAlertEmail) {
		if(vacantAlertEmail != null){
			this.vacantAlertEmail = vacantAlertEmail;
		}else{
			this.vacantAlertEmail = "";
		}
	}
	
	
	/**
	 * Gets the fallouts threshold.
	 *
	 * @return the fallouts threshold
	 */
	public Integer getFalloutsThreshold() {
		return falloutsThreshold;
	}
	
	
	/**
	 * Sets the fallouts threshold.
	 *
	 * @param falloutsThreshold the new fallouts threshold
	 */
	public void setFalloutsThreshold(Integer falloutsThreshold) {
		if (falloutsThreshold != null) {
			this.falloutsThreshold = falloutsThreshold.intValue();
		}
		else{
			this.falloutsThreshold = -1;
		}
	}
	
	
	/**
	 * Gets the no_ order alert.
	 *
	 * @return the no_ order alert
	 */
	public Integer getNo_OrderAlert() {
		return no_OrderAlert;
	}
	
	
	/**
	 * Sets the no_ order alert.
	 *
	 * @param no_OrderAlert the new no_ order alert
	 */
	public void setNo_OrderAlert(Integer no_OrderAlert) {
		if (no_OrderAlert != null) {
			this.no_OrderAlert = no_OrderAlert.intValue();
		}
		else{
			this.no_OrderAlert = -1;
		}
	}
	
	
	/**
	 * Gets the creation date.
	 *
	 * @return the creation date
	 */
	public Date getCreationDate() {
		return creationDate;
	}
	
	
	/**
	 * Sets the creation date.
	 *
	 * @param creationDate the new creation date
	 */
	public void setCreationDate(Date creationDate) {
		if(creationDate != null){
			this.creationDate = creationDate;
		}else{
			this.creationDate = new Date();
		}
	}
	
	
	/**
	 * Gets the last modied date.
	 *
	 * @return the last modied date
	 */
	public Date getLastModiedDate() {
		return lastModiedDate;
	}
	
	
	/**
	 * Sets the last modied date.
	 *
	 * @param lastModiedDate the new last modied date
	 */
	public void setLastModiedDate(Date lastModiedDate) {
		if(lastModiedDate != null){
			this.lastModiedDate = lastModiedDate;
		}else{
			this.lastModiedDate = new Date();
		}
	}
	
	
	/**
	 * Gets the threshold count.
	 *
	 * @return the threshold count
	 */
	public Integer getThresholdCount() {
		return thresholdCount;
	}
	
	
	/**
	 * Sets the threshold count.
	 *
	 * @param thresholdCount the new threshold count
	 */
	public void setThresholdCount(Integer thresholdCount) {
		if (thresholdCount != null) {
			this.thresholdCount = thresholdCount.intValue();
		}
		else{
			this.thresholdCount = -1;
		}
	}
	
	
	/**
	 * Gets the queue limit alert email.
	 *
	 * @return the queue limit alert email
	 */
	public String getQueueLimitAlertEmail() {
		return queueLimitAlertEmail;
	}
	
	
	/**
	 * Sets the queue limit alert email.
	 *
	 * @param queueLimitAlertEmail the new queue limit alert email
	 */
	public void setQueueLimitAlertEmail(String queueLimitAlertEmail) {
		if(queueLimitAlertEmail != null){
			this.queueLimitAlertEmail = queueLimitAlertEmail;
		}else{
			this.queueLimitAlertEmail = "";
		}
	}
	
	
	/**
	 * Gets the effective from date.
	 *
	 * @return the effective from date
	 */
	public Date getEffectiveFromDate() {
		return effectiveFromDate;
	}
	
	
	/**
	 * Sets the effective from date.
	 *
	 * @param effectiveFromDate the new effective from date
	 */
	public void setEffectiveFromDate(Date effectiveFromDate) {
		if(effectiveFromDate != null){
			this.effectiveFromDate = effectiveFromDate;
		}else{
			this.effectiveFromDate = new Date();
		}
	}
	
	
	/**
	 * Gets the effective till date.
	 *
	 * @return the effective till date
	 */
	public Date getEffectiveTillDate() {
		return effectiveTillDate;
	}
	
	
	/**
	 * Sets the effective till date.
	 *
	 * @param effectiveTillDate the new effective till date
	 */
	public void setEffectiveTillDate(Date effectiveTillDate) {
		if(effectiveTillDate != null){
			this.effectiveTillDate = effectiveTillDate;
		}else{
			this.effectiveTillDate = new Date();
		}
	}
	
	
	/**
	 * Gets the sku.
	 *
	 * @return the sku
	 */
	public String getSku() {
		return sku;
	}
	
	
	/**
	 * Sets the sku.
	 *
	 * @param sku the new sku
	 */
	public void setSku(String sku) {
		if(sku != null){
			this.sku = sku;
		}else{
			this.sku = "";
		}
	}
	
	
	/**
	 * Gets the checks if is order level queue.
	 *
	 * @return the checks if is order level queue
	 */
	public Integer getIsOrderLevelQueue() {
		return isOrderLevelQueue;
	}
	
	
	/**
	 * Sets the checks if is order level queue.
	 *
	 * @param isOrderLevelQueue the new checks if is order level queue
	 */
	public void setIsOrderLevelQueue(Integer isOrderLevelQueue) {
		if (isOrderLevelQueue != null) {
			this.isOrderLevelQueue = isOrderLevelQueue.intValue();
		}
		else{
			this.isOrderLevelQueue = -1;
		}
	}
	
	
	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}
	
	
	/**
	 * Sets the channel.
	 *
	 * @param channel the new channel
	 */
	public void setChannel(String channel) {
		if(channel != null){
			this.channel = channel;
		}else{
			this.channel = "";
		}
	}
	
	
	/**
	 * Gets the callback preference.
	 *
	 * @return the callback preference
	 */
	public String getCallbackPreference() {
		return callbackPreference;
	}
	
	
	/**
	 * Sets the callback preference.
	 *
	 * @param callbackPreference the new callback preference
	 */
	public void setCallbackPreference(String callbackPreference) {
		if(callbackPreference != null){
			this.callbackPreference = callbackPreference;
		}else{
			this.callbackPreference = "";
		}
	}
	
	
	/**
	 * Gets the active.
	 *
	 * @return the active
	 */
	public String getActive() {
		return active;
	}
	
	
	/**
	 * Sets the active.
	 *
	 * @param active the new active
	 */
	public void setActive(String active) {
		if(active != null){
			this.active = active;
		}else{
			this.active = "";
		}
	}
	
	
	/**
	 * Gets the rep commnets.
	 *
	 * @return the rep commnets
	 */
	public String getRepCommnets() {
		return repCommnets;
	}
	
	
	/**
	 * Sets the rep commnets.
	 *
	 * @param repCommnets the new rep commnets
	 */
	public void setRepCommnets(String repCommnets) {
		if(repCommnets != null){
			this.repCommnets = repCommnets;
		}else{
			this.repCommnets = "";
		}
	}
	
	
	/**
	 * Gets the queue info.
	 *
	 * @return the queue info
	 */
	public String getQueueInfo() {
		return queueInfo;
	}
	
	
	/**
	 * Sets the queue info.
	 *
	 * @param queueInfo the new queue info
	 */
	public void setQueueInfo(String queueInfo) {
		if(queueInfo != null){
			this.queueInfo = queueInfo;
		}else{
			this.queueInfo = "";
		}
	}
	
	
	/**
	 * Gets the escalation type.
	 *
	 * @return the escalation type
	 */
	public String getEscalationType() {
		return escalationType;
	}
	
	
	/**
	 * Sets the escalation type.
	 *
	 * @param escalationType the new escalation type
	 */
	public void setEscalationType(String escalationType) {
		if(escalationType != null){
			this.escalationType = escalationType;
		}else{
			this.escalationType = "";
		}
	}
	
	
	/**
	 * Gets the escalation priority.
	 *
	 * @return the escalation priority
	 */
	public String getEscalationPriority() {
		return escalationPriority;
	}
	
	
	/**
	 * Sets the escalation priority.
	 *
	 * @param escalationPriority the new escalation priority
	 */
	public void setEscalationPriority(String escalationPriority) {
		if(escalationPriority != null){
			this.escalationPriority = escalationPriority;
		}else{
			this.escalationPriority = "";
		}
	}
	
	
	/**
	 * Gets the giga ind.
	 *
	 * @return the giga ind
	 */
	public String getGigaInd() {
		return gigaInd;
	}
	
	
	/**
	 * Sets the giga ind.
	 *
	 * @param gigaInd the new giga ind
	 */
	public void setGigaInd(String gigaInd) {
		if(gigaInd != null){
			this.gigaInd = gigaInd;
		}else{
			this.gigaInd = "";
		}
	}
	
	
	/**
	 * Gets the queue group.
	 *
	 * @return the queue group
	 */
	public String getQueueGroup() {
		return queueGroup;
	}
	
	
	/**
	 * Sets the queue group.
	 *
	 * @param queueGroup the new queue group
	 */
	public void setQueueGroup(String queueGroup) {
		if(queueGroup != null){
			this.queueGroup = queueGroup;
		}else{
			this.queueGroup = "";
		}
	}
	
	
	/**
	 * Gets the request type.
	 *
	 * @return the request type
	 */
	public String getRequestType() {
		return requestType;
	}
	
	
	/**
	 * Sets the request type.
	 *
	 * @param requestType the new request type
	 */
	public void setRequestType(String requestType) {
		if(requestType != null){
			this.requestType = requestType;
		}else{
			this.requestType = "";
		}
	}
	
	
	/**
	 * Gets the last modified by.
	 *
	 * @return the last modified by
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	
	
	/**
	 * Sets the last modified by.
	 *
	 * @param lastModifiedBy the new last modified by
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		if(lastModifiedBy != null){
			this.lastModifiedBy = lastModifiedBy;
		}else{
			this.lastModifiedBy = "";
		}
	}
	
	
	/**
	 * Gets the last_ modified_ by.
	 *
	 * @return the last_ modified_ by
	 */
	public String getLast_Modified_By() {
		return last_Modified_By;
	}
	
	
	/**
	 * Sets the last_ modified_ by.
	 *
	 * @param last_Modified_By the new last_ modified_ by
	 */
	public void setLast_Modified_By(String last_Modified_By) {
		if(last_Modified_By != null){
			this.last_Modified_By = last_Modified_By;
		}else{
			this.last_Modified_By = "";
		}
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueueMasterVO [id=" + id + ", queueType=" + queueType
				+ ", queueDescription=" + queueDescription + ", priority="
				+ priority + ", lineComboFlag=" + lineComboFlag
				+ ", enterpriseType=" + enterpriseType + ", userRoles="
				+ userRoles + ", releaseLock=" + releaseLock + ", vacantAlert="
				+ vacantAlert + ", vacantAlertEmail=" + vacantAlertEmail
				+ ", falloutsThreshold=" + falloutsThreshold
				+ ", no_OrderAlert=" + no_OrderAlert + ", creationDate="
				+ creationDate + ", lastModiedDate=" + lastModiedDate
				+ ", thresholdCount=" + thresholdCount
				+ ", queueLimitAlertEmail=" + queueLimitAlertEmail
				+ ", effectiveFromDate=" + effectiveFromDate
				+ ", effectiveTillDate=" + effectiveTillDate + ", sku=" + sku
				+ ", isOrderLevelQueue=" + isOrderLevelQueue + ", channel="
				+ channel + ", callbackPreference=" + callbackPreference
				+ ", active=" + active + ", repCommnets=" + repCommnets
				+ ", queueInfo=" + queueInfo + ", escalationType="
				+ escalationType + ", escalationPriority=" + escalationPriority
				+ ", gigaInd=" + gigaInd + ", queueGroup=" + queueGroup
				+ ", requestType=" + requestType + ", lastModifiedBy="
				+ lastModifiedBy + ", last_Modified_By=" + last_Modified_By
				+ "]";
	}
	
	
	
	
}
