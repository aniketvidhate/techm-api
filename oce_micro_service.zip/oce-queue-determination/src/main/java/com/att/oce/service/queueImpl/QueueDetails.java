package com.att.oce.service.queueImpl;

import org.springframework.stereotype.Component;

@Component
public class QueueDetails {

	private String queueId;
	private String queueType;
	private String queueSubType;
	private String repComments;
	private String queuePriority;
	private String queueCategory;
	private String actionType;
	private boolean manualIntervention = true;
	
	public QueueDetails() {
	}

	public String getRepComments() {
		return repComments;
	}

	public void setRepComments(String repComments) {
		this.repComments = repComments;
	}

	public String getQueueId() {
		return queueId;
	}

	public void setQueueId(String queueId) {
		this.queueId = queueId;
	}

	public String getQueueType() {
		return queueType;
	}

	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}

	public String getQueueSubType() {
		return queueSubType;
	}

	public void setQueueSubType(String queueSubType) {
		this.queueSubType = queueSubType;
	}

	public String getQueuePriority() {
		return queuePriority;
	}
	
	public void setQueuePriority(String queuePriority) {
		this.queuePriority = queuePriority;
	}

	public String getQueueCategory() {
		return queueCategory;
	}

	public void setQueueCategory(String queueCategory) {
		this.queueCategory = queueCategory;
	}
	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	
	public boolean isManualIntervention() {
		return manualIntervention;
	}
	
	public void setManualIntervention(boolean manualIntervention) {
		this.manualIntervention = manualIntervention;
	}
}
