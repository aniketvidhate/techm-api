package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCELineSubstatus.java - hibernate Annotated Class for OCE_LINESUBSTATUS table
 */

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCELineSubstatus.
 */
@Entity
@Table(name="OCE_LINESUBSTATUS")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCELineSubstatus")
public class OCELineSubstatus {

	/** The id. */
	@Id
	@Column(name="ID")
	private String id;
	
	/** The line sub status. */
	@Column(name="LINE_SUB_STATUS")
	private String lineSubStatus;
	
	/** The product category. */
	@Column(name="PRODUCT_CATEGORY")
	private String productCategory;
	
	/** The status. */
	@Column(name="STATUS")
	private String status;
	
	/** The queue sub type. */
	@Column(name="QUEUE_SUB_TYPE")
	private String queueSubType;
	
	/** The is bulk. */
	@Column(name="ISBULK")
	private int isBulk;
	
	/** The is connected car. */
	@Column(name="ISCONNECTEDCAR")
	private int isConnectedCAR;
	
	/** The manual intervention. */
	@Column(name="MANUAL_INTERVENTION")
	private int manualIntervention;
	
	
	/**
	 * Instantiates a new OCE line substatus.
	 */
	public OCELineSubstatus(){
		
	}


	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * Gets the line sub status.
	 *
	 * @return the lineSubStatus
	 */
	public String getLineSubStatus() {
		return lineSubStatus;
	}


	/**
	 * Sets the line sub status.
	 *
	 * @param lineSubStatus the lineSubStatus to set
	 */
	public void setLineSubStatus(String lineSubStatus) {
		this.lineSubStatus = lineSubStatus;
	}


	/**
	 * Gets the product category.
	 *
	 * @return the productCategory
	 */
	public String getProductCategory() {
		return productCategory;
	}


	/**
	 * Sets the product category.
	 *
	 * @param productCategory the productCategory to set
	 */
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}


	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * Sets the status.
	 *
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}


	/**
	 * Gets the queue sub type.
	 *
	 * @return the queueSubType
	 */
	public String getQueueSubType() {
		return queueSubType;
	}


	/**
	 * Sets the queue sub type.
	 *
	 * @param queueSubType the queueSubType to set
	 */
	public void setQueueSubType(String queueSubType) {
		this.queueSubType = queueSubType;
	}


	/**
	 * Gets the checks if is bulk.
	 *
	 * @return the isBulk
	 */
	public int getIsBulk() {
		return isBulk;
	}


	/**
	 * Sets the checks if is bulk.
	 *
	 * @param isBulk the isBulk to set
	 */
	public void setIsBulk(int isBulk) {
		this.isBulk = isBulk;
	}


	/**
	 * Gets the checks if is connected car.
	 *
	 * @return the isConnectedCAR
	 */
	public int getIsConnectedCAR() {
		return isConnectedCAR;
	}


	/**
	 * Sets the checks if is connected car.
	 *
	 * @param isConnectedCAR the isConnectedCAR to set
	 */
	public void setIsConnectedCAR(int isConnectedCAR) {
		this.isConnectedCAR = isConnectedCAR;
	}


	/**
	 * Gets the manual intervention.
	 *
	 * @return the manualIntervention
	 */
	public int getManualIntervention() {
		return manualIntervention;
	}


	/**
	 * Sets the manual intervention.
	 *
	 * @param manualIntervention the manualIntervention to set
	 */
	public void setManualIntervention(int manualIntervention) {
		this.manualIntervention = manualIntervention;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCELineSubstatus [id=" + id + ", lineSubStatus="
				+ lineSubStatus + ", productCategory=" + productCategory
				+ ", status=" + status + ", queueSubType=" + queueSubType
				+ ", isBulk=" + isBulk + ", isConnectedCAR=" + isConnectedCAR
				+ ", manualIntervention=" + manualIntervention + "]";
	}


}
