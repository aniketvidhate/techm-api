package com.att.oce.service.queue.vo;

/**
 * The Class OceQueueProgramSlaVO.
 *
 * @author AV00419874
 */

public class OceQueueProgramSlaVO {
	
	/** The queue sla id. */
	private String queueSlaId;
	
	/** The program name. */
	private String programName;
	
	/** The sla green min. */
	private Integer slaGreenMin;
	
	/** The sla amber min. */
	private Integer slaAmberMin;
	
	/** The sla red min. */
	private Integer slaRedMin;
	
	/** The sla green max. */
	private Integer slaGreenMax;
	
	/** The sla amber max. */
	private Integer slaAmberMax;
	
	/** The sla red max. */
	private Integer slaRedMax;
	
	/** The at risk. */
	private Integer atRisk;
	
	/** The at violation. */
	private Integer atViolation;
	
	/** The sla alert. */
	private Integer slaAlert;
	
	/** The sla breach. */
	private Integer slaBreach;
	
	/** The threshold breach email. */
	private String thresholdBreachEmail;
	
	/** The program priority. */
	private String programPriority;


	/**
	 * Instantiates a new oce queue program sla vo.
	 */
	public OceQueueProgramSlaVO(){
		
	}


	/**
	 * Gets the queue sla id.
	 *
	 * @return the queueSlaId
	 */
	public String getQueueSlaId() {
		return queueSlaId;
	}


	/**
	 * Sets the queue sla id.
	 *
	 * @param queueSlaId the queueSlaId to set
	 */
	public void setQueueSlaId(String queueSlaId) {
		this.queueSlaId = queueSlaId;
	}


	/**
	 * Gets the program name.
	 *
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}


	/**
	 * Sets the program name.
	 *
	 * @param programName the programName to set
	 */
	public void setProgramName(String programName) {
		this.programName = programName;
	}


	/**
	 * Gets the sla green min.
	 *
	 * @return the slaGreenMin
	 */
	public Integer getSlaGreenMin() {
		return slaGreenMin;
	}


	/**
	 * Sets the sla green min.
	 *
	 * @param slaGreenMin the slaGreenMin to set
	 */
	public void setSlaGreenMin(Integer slaGreenMin) {
		if (slaGreenMin != null) {
			this.slaGreenMin = slaGreenMin.intValue();
		}
		else{
			this.slaGreenMin = -1;
		}
	}


	/**
	 * Gets the sla amber min.
	 *
	 * @return the slaAmberMin
	 */
	public Integer getSlaAmberMin() {
		return slaAmberMin;
	}


	/**
	 * Sets the sla amber min.
	 *
	 * @param slaAmberMin the slaAmberMin to set
	 */
	public void setSlaAmberMin(Integer slaAmberMin) {
		if (slaAmberMin != null) {
			this.slaAmberMin = slaAmberMin.intValue();
		}
		else{
			this.slaAmberMin = -1;
		}
	}


	/**
	 * Gets the sla red min.
	 *
	 * @return the slaRedMin
	 */
	public Integer getSlaRedMin() {
		return slaRedMin;
	}


	/**
	 * Sets the sla red min.
	 *
	 * @param slaRedMin the slaRedMin to set
	 */
	public void setSlaRedMin(Integer slaRedMin) {
		if (slaRedMin != null) {
			this.slaRedMin = slaRedMin.intValue();
		}
		else{
			this.slaRedMin = -1;
		}
	}


	/**
	 * Gets the sla green max.
	 *
	 * @return the slaGreenMax
	 */
	public Integer getSlaGreenMax() {
		return slaGreenMax;
	}


	/**
	 * Sets the sla green max.
	 *
	 * @param slaGreenMax the slaGreenMax to set
	 */
	public void setSlaGreenMax(Integer slaGreenMax) {
		if (slaGreenMax != null) {
			this.slaGreenMax = slaGreenMax.intValue();
		}
		else{
			this.slaGreenMax = -1;
		}
	}


	/**
	 * Gets the sla amber max.
	 *
	 * @return the slaAmberMax
	 */
	public Integer getSlaAmberMax() {
		return slaAmberMax;
	}


	/**
	 * Sets the sla amber max.
	 *
	 * @param slaAmberMax the slaAmberMax to set
	 */
	public void setSlaAmberMax(Integer slaAmberMax) {
		if (slaAmberMax != null) {
			this.slaAmberMax = slaAmberMax.intValue();
		}
		else{
			this.slaAmberMax = -1;
		}
	}


	/**
	 * Gets the sla red max.
	 *
	 * @return the slaRedMax
	 */
	public Integer getSlaRedMax() {
		return slaRedMax;
	}


	/**
	 * Sets the sla red max.
	 *
	 * @param slaRedMax the slaRedMax to set
	 */
	public void setSlaRedMax(Integer slaRedMax) {
		if (slaRedMax != null) {
			this.slaRedMax = slaRedMax.intValue();
		}
		else{
			this.slaRedMax = -1;
		}
	}


	/**
	 * Gets the at risk.
	 *
	 * @return the atRisk
	 */
	public Integer getAtRisk() {
		return atRisk;
	}


	/**
	 * Sets the at risk.
	 *
	 * @param atRisk the atRisk to set
	 */
	public void setAtRisk(Integer atRisk) {
		if (atRisk != null) {
			this.atRisk = atRisk.intValue();
		}
		else{
			this.atRisk = -1;
		}
	}


	/**
	 * Gets the at violation.
	 *
	 * @return the atViolation
	 */
	public Integer getAtViolation() {
		return atViolation;
	}


	/**
	 * Sets the at violation.
	 *
	 * @param atViolation the atViolation to set
	 */
	public void setAtViolation(Integer atViolation) {
		if (atViolation != null) {
			this.atViolation = atViolation.intValue();
		}
		else{
			this.atViolation = -1;
		}
	}


	/**
	 * Gets the sla alert.
	 *
	 * @return the slaAlert
	 */
	public Integer getSlaAlert() {
		return slaAlert;
	}


	/**
	 * Sets the sla alert.
	 *
	 * @param slaAlert the slaAlert to set
	 */
	public void setSlaAlert(Integer slaAlert) {
		if (slaAlert != null) {
			this.slaAlert = slaAlert.intValue();
		}
		else{
			this.slaAlert = -1;
		}
	}


	/**
	 * Gets the sla breach.
	 *
	 * @return the slaBreach
	 */
	public Integer getSlaBreach() {
		return slaBreach;
	}


	/**
	 * Sets the sla breach.
	 *
	 * @param slaBreach the slaBreach to set
	 */
	public void setSlaBreach(Integer slaBreach) {
		if (slaBreach != null) {
			this.slaBreach = slaBreach.intValue();
		}
		else{
			this.slaBreach = -1;
		}
	}


	/**
	 * Gets the threshold breach email.
	 *
	 * @return the thresholdBreachEmail
	 */
	public String getThresholdBreachEmail() {
		return thresholdBreachEmail;
	}


	/**
	 * Sets the threshold breach email.
	 *
	 * @param thresholdBreachEmail the thresholdBreachEmail to set
	 */
	public void setThresholdBreachEmail(String thresholdBreachEmail) {
		this.thresholdBreachEmail = thresholdBreachEmail;
	}


	/**
	 * Gets the program priority.
	 *
	 * @return the programPriority
	 */
	public String getProgramPriority() {
		return programPriority;
	}


	/**
	 * Sets the program priority.
	 *
	 * @param programPriority the programPriority to set
	 */
	public void setProgramPriority(String programPriority) {
		this.programPriority = programPriority;
	}

 

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OceQueueProgramSlaVO [queueSlaId=" + queueSlaId
				+ ", programName=" + programName + ", slaGreenMin="
				+ slaGreenMin + ", slaAmberMin=" + slaAmberMin + ", slaRedMin="
				+ slaRedMin + ", slaGreenMax=" + slaGreenMax + ", slaAmberMax="
				+ slaAmberMax + ", slaRedMax=" + slaRedMax + ", atRisk="
				+ atRisk + ", atViolation=" + atViolation + ", slaAlert="
				+ slaAlert + ", slaBreach=" + slaBreach
				+ ", thresholdBreachEmail=" + thresholdBreachEmail
				+ ", programPriority=" + programPriority + "]";
	}
	
	 
}
