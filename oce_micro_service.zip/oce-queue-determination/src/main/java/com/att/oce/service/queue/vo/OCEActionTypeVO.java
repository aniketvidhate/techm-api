package com.att.oce.service.queue.vo;

/**
 * The Class OCEActionTypeVO.
 *
 * @author AV00419874
 */

public class OCEActionTypeVO {

	/** The action type id. */
	private String actionTypeId;

	/** The action type. */
	private String actionType;

	/**
	 * Gets the action type id.
	 *
	 * @return the actionTypeId
	 */
	public String getActionTypeId() {
		return actionTypeId;
	}

	/**
	 * Sets the action type id.
	 *
	 * @param actionTypeId the actionTypeId to set
	 */
	public void setActionTypeId(String actionTypeId) {
		this.actionTypeId = actionTypeId;
	}

	/**
	 * Gets the action type.
	 *
	 * @return the actionType
	 */
	public String getActionType() {
		return actionType;
	}

	/**
	 * Sets the action type.
	 *
	 * @param actionType the actionType to set
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEActionTypeVO [actionTypeId=" + actionTypeId
				+ ", actionType=" + actionType + "]";
	}

}
