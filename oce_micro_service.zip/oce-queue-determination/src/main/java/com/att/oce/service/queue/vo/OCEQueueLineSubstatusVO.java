package com.att.oce.service.queue.vo;

/**
 * The Class OCEQueueLineSubstatusVO.
 *
 * @author AV00419874
 */

public class OCEQueueLineSubstatusVO {

	/** The id. */
	private String id;
	
	/** The sequence. */
	private int sequence;
	
	/** The sub status id. */
	private String subStatusId;
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public int getSequence() {
		return sequence;
	}
	
	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	
	/**
	 * Gets the sub status id.
	 *
	 * @return the subStatusId
	 */
	public String getSubStatusId() {
		return subStatusId;
	}
	
	/**
	 * Sets the sub status id.
	 *
	 * @param subStatusId the subStatusId to set
	 */
	public void setSubStatusId(String subStatusId) {
		this.subStatusId = subStatusId;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueueLineSubstatusVO [id=" + id + ", sequence=" + sequence
				+ ", subStatusId=" + subStatusId + "]";
	}
	
	
}
