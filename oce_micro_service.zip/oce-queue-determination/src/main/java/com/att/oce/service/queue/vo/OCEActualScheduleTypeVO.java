package com.att.oce.service.queue.vo;

/**
 * The Class OCEActualScheduleTypeVO.
 *
 * @author AV00419874
 */


public class OCEActualScheduleTypeVO {

	/** The actual schedule type. */
	private String actualScheduleType;
	
	/** The selected appointment date. */
	private String selectedAppointmentDate;
	
	/** The selected appointment time. */
	private String selectedAppointmentTime;
	
	/** The start time. */
	private String startTime;
	
	/** The end time. */
	private String endTime;
	
	/** The is realtime calendar. */
	private Integer isRealtimeCalendar;
	
	/** The appmt date chg reason. */
	private String appmtDateChgReason;
	
	/** The work orderid. */
	private String workOrderid;
	/**
	 * Instantiates a new OCE action type.
	 */
	public OCEActualScheduleTypeVO(){
		
	}
	
	/**
	 * Gets the actual schedule type.
	 *
	 * @return the actualScheduleType
	 */
	public String getActualScheduleType() {
		return actualScheduleType;
	}
	
	/**
	 * Sets the actual schedule type.
	 *
	 * @param actualScheduleType the actualScheduleType to set
	 */
	public void setActualScheduleType(String actualScheduleType) {
		this.actualScheduleType = actualScheduleType;
	}
	
	/**
	 * Gets the selected appointment date.
	 *
	 * @return the selectedAppointmentDate
	 */
	public String getSelectedAppointmentDate() {
		return selectedAppointmentDate;
	}
	
	/**
	 * Sets the selected appointment date.
	 *
	 * @param selectedAppointmentDate the selectedAppointmentDate to set
	 */
	public void setSelectedAppointmentDate(String selectedAppointmentDate) {
		this.selectedAppointmentDate = selectedAppointmentDate;
	}
	
	/**
	 * Gets the selected appointment time.
	 *
	 * @return the selectedAppointmentTime
	 */
	public String getSelectedAppointmentTime() {
		return selectedAppointmentTime;
	}
	
	/**
	 * Sets the selected appointment time.
	 *
	 * @param selectedAppointmentTime the selectedAppointmentTime to set
	 */
	public void setSelectedAppointmentTime(String selectedAppointmentTime) {
		this.selectedAppointmentTime = selectedAppointmentTime;
	}
	
	/**
	 * Gets the start time.
	 *
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}
	
	/**
	 * Sets the start time.
	 *
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	
	/**
	 * Gets the end time.
	 *
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}
	
	/**
	 * Sets the end time.
	 *
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	/**
	 * Gets the checks if is realtime calendar.
	 *
	 * @return the isRealtimeCalendar
	 */
	public Integer getIsRealtimeCalendar() {
		return isRealtimeCalendar;
	}
	
	/**
	 * Sets the checks if is realtime calendar.
	 *
	 * @param isRealtimeCalendar the isRealtimeCalendar to set
	 */
	public void setIsRealtimeCalendar(Integer isRealtimeCalendar) {
		if (isRealtimeCalendar != null) {
			this.isRealtimeCalendar = isRealtimeCalendar.intValue();
		}
		else{
			this.isRealtimeCalendar = -1;
		}
	}
	
	/**
	 * Gets the appmt date chg reason.
	 *
	 * @return the appmtDateChgReason
	 */
	public String getAppmtDateChgReason() {
		return appmtDateChgReason;
	}
	
	/**
	 * Sets the appmt date chg reason.
	 *
	 * @param appmtDateChgReason the appmtDateChgReason to set
	 */
	public void setAppmtDateChgReason(String appmtDateChgReason) {
		this.appmtDateChgReason = appmtDateChgReason;
	}
	
	/**
	 * Gets the work orderid.
	 *
	 * @return the workOrderid
	 */
	public String getWorkOrderid() {
		return workOrderid;
	}
	
	/**
	 * Sets the work orderid.
	 *
	 * @param workOrderid the workOrderid to set
	 */
	public void setWorkOrderid(String workOrderid) {
		this.workOrderid = workOrderid;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEActualScheduleTypeVO [actualScheduleType="
				+ actualScheduleType + ", selectedAppointmentDate="
				+ selectedAppointmentDate + ", selectedAppointmentTime="
				+ selectedAppointmentTime + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", isRealtimeCalendar="
				+ isRealtimeCalendar + ", appmtDateChgReason="
				+ appmtDateChgReason + ", workOrderid=" + workOrderid + "]";
	}

	
}
