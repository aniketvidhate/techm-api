package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEShippingCode.java - hibernate Annotated Class 
 * for OCE_SHIPPING_CODE table containing Primary key
 */

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEShippingCode.
 */
@Entity
@Table(name="OCE_SHIPPING_CODE")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEShippingCode")
public class OCEShippingCode {

	/** The ship code id. */
	@Id
	@Column(name="SHIPCODE_ID")
	private String shipCodeId;
	
	/** The shipping code. */
	@Column(name="SHIPPING_CODE")
	private String shippingCode;
	

	/**
	 * Instantiates a new OCE shipping code.
	 */
	public OCEShippingCode(){
		
	}


	/**
	 * Gets the ship code id.
	 *
	 * @return the shipCodeId
	 */
	public String getShipCodeId() {
		return shipCodeId;
	}


	/**
	 * Sets the ship code id.
	 *
	 * @param shipCodeId the shipCodeId to set
	 */
	public void setShipCodeId(String shipCodeId) {
		this.shipCodeId = shipCodeId;
	}


	/**
	 * Gets the shipping code.
	 *
	 * @return the shippingCode
	 */
	public String getShippingCode() {
		return shippingCode;
	}


	/**
	 * Sets the shipping code.
	 *
	 * @param shippingCode the shippingCode to set
	 */
	public void setShippingCode(String shippingCode) {
		this.shippingCode = shippingCode;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEShippingCode [shipCodeId=" + shipCodeId + ", shippingCode="
				+ shippingCode + "]";
	}

	
	

	
}
