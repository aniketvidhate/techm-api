package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEActionType.java - hibernate Annotated Class for OCE_ACTION_TYPE table
 */

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEQueueActionType.
 */
@Entity
@Table(name="OCE_QUEUE_ACTION_TYPE")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEQueueActionType")
public class  OCEQueueActionType{

	/** The id. */
	@Id
	@Column(name="ID")
	private String id;
	
	/** The sequence. */
	@Column(name="SEQUENCE")
	private int sequence;
	
	/** The action type id. */
	@Column(name="ACTIONTYPE_ID")
	private String actionTypeId;
	
	
	/**
	 * Instantiates a new OCE queue action type.
	 */
	public OCEQueueActionType(){
		
	}


	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public int getSequence() {
		return sequence;
	}


	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}


	/**
	 * Gets the action type id.
	 *
	 * @return the actionTypeId
	 */
	public String getActionTypeId() {
		return actionTypeId;
	}


	/**
	 * Sets the action type id.
	 *
	 * @param actionTypeId the actionTypeId to set
	 */
	public void setActionTypeId(String actionTypeId) {
		this.actionTypeId = actionTypeId;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueueActionType [id=" + id + ", sequence=" + sequence
				+ ", actionTypeId=" + actionTypeId + "]";
	}

	
	
	
}
