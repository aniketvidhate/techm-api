package com.att.oce.service.queue;

public interface TaskMgmtService {
	
	public void createTask();
	
	public void updateTask();
}
