package com.att.oce.service.queue.vo.sub;

import java.util.List;
import java.util.Set;
import java.util.SortedMap;

import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtB2B;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtLineItem;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtOrderSource;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtSchedulingInfoList;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.GroupList;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtOrderTask;

public class OCEOrderInfo {

	private String requestType;
	private String requestId;
	private GroupList groupList;
	private String oceOrderNumber;
	private CtOrderSource ctOrderSource;
	private List<CtOrderTask> orderTasklist;
	private boolean nonUnifyWireless;
	private List<CtOrderTask> ctOrderTasks;
	private String programName;
	private CtSchedulingInfoList ctSchedulingInfoList;
	private String losgTypeNonUnifyWireless;
	private String prgmNmeFulfllmntMthd;
	private boolean wirelessUnlock;
	private boolean isWirelessFalloutOrder;
	private List<String> schedulingRefIds;
	private List<String> actionTypeList;
	private SortedMap<String, Set<String>> statusSubStatusMap;
	private List<CtB2B> ctB2BList;
	private List<CtLineItem> ctLineItems;
	private boolean isBulk;
	/**
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}
	/**
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	/**
	 * @return the requestId
	 */
	public String getRequestId() {
		return requestId;
	}
	/**
	 * @param requestId the requestId to set
	 */
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	/**
	 * @return the groupList
	 */
	public GroupList getGroupList() {
		return groupList;
	}
	/**
	 * @param groupList the groupList to set
	 */
	public void setGroupList(GroupList groupList) {
		this.groupList = groupList;
	}
	/**
	 * @return the oceOrderNumber
	 */
	public String getOceOrderNumber() {
		return oceOrderNumber;
	}
	/**
	 * @param oceOrderNumber the oceOrderNumber to set
	 */
	public void setOceOrderNumber(String oceOrderNumber) {
		this.oceOrderNumber = oceOrderNumber;
	}
	/**
	 * @return the ctOrderSource
	 */
	public CtOrderSource getCtOrderSource() {
		return ctOrderSource;
	}
	/**
	 * @param ctOrderSource the ctOrderSource to set
	 */
	public void setCtOrderSource(CtOrderSource ctOrderSource) {
		this.ctOrderSource = ctOrderSource;
	}
	/**
	 * @return the orderTasklist
	 */
	public List<CtOrderTask> getOrderTasklist() {
		return orderTasklist;
	}
	/**
	 * @param orderTasklist the orderTasklist to set
	 */
	public void setOrderTasklist(List<CtOrderTask> orderTasklist) {
		this.orderTasklist = orderTasklist;
	}
	/**
	 * @return the nonUnifyWireless
	 */
	public boolean isNonUnifyWireless() {
		return nonUnifyWireless;
	}
	/**
	 * @param nonUnifyWireless the nonUnifyWireless to set
	 */
	public void setNonUnifyWireless(boolean nonUnifyWireless) {
		this.nonUnifyWireless = nonUnifyWireless;
	}
	/**
	 * @return the ctOrderTasks
	 */
	public List<CtOrderTask> getCtOrderTasks() {
		return ctOrderTasks;
	}
	/**
	 * @param ctOrderTasks the ctOrderTasks to set
	 */
	public void setCtOrderTasks(List<CtOrderTask> ctOrderTasks) {
		this.ctOrderTasks = ctOrderTasks;
	}
	/**
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}
	/**
	 * @param programName the programName to set
	 */
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	/**
	 * @return the ctSchedulingInfoList
	 */
	public CtSchedulingInfoList getCtSchedulingInfoList() {
		return ctSchedulingInfoList;
	}
	/**
	 * @param ctSchedulingInfoList the ctSchedulingInfoList to set
	 */
	public void setCtSchedulingInfoList(CtSchedulingInfoList ctSchedulingInfoList) {
		this.ctSchedulingInfoList = ctSchedulingInfoList;
	}
	/**
	 * @return the losgTypeNonUnifyWireless
	 */
	public String getLosgTypeNonUnifyWireless() {
		return losgTypeNonUnifyWireless;
	}
	/**
	 * @param losgTypeNonUnifyWireless the losgTypeNonUnifyWireless to set
	 */
	public void setLosgTypeNonUnifyWireless(String losgTypeNonUnifyWireless) {
		this.losgTypeNonUnifyWireless = losgTypeNonUnifyWireless;
	}
	/**
	 * @return the prgmNmeFulfllmntMthd
	 */
	public String getPrgmNmeFulfllmntMthd() {
		return prgmNmeFulfllmntMthd;
	}
	/**
	 * @param prgmNmeFulfllmntMthd the prgmNmeFulfllmntMthd to set
	 */
	public void setPrgmNmeFulfllmntMthd(String prgmNmeFulfllmntMthd) {
		this.prgmNmeFulfllmntMthd = prgmNmeFulfllmntMthd;
	}
	/**
	 * @return the wirelessUnlock
	 */
	public boolean isWirelessUnlock() {
		return wirelessUnlock;
	}
	/**
	 * @param wirelessUnlock the wirelessUnlock to set
	 */
	public void setWirelessUnlock(boolean wirelessUnlock) {
		this.wirelessUnlock = wirelessUnlock;
	}
	/**
	 * @return the isWirelessFalloutOrder
	 */
	public boolean isWirelessFalloutOrder() {
		return isWirelessFalloutOrder;
	}
	/**
	 * @param isWirelessFalloutOrder the isWirelessFalloutOrder to set
	 */
	public void setWirelessFalloutOrder(boolean isWirelessFalloutOrder) {
		this.isWirelessFalloutOrder = isWirelessFalloutOrder;
	}
	/**
	 * @return the schedulingRefIds
	 */
	public List<String> getSchedulingRefIds() {
		return schedulingRefIds;
	}
	/**
	 * @param schedulingRefIds the schedulingRefIds to set
	 */
	public void setSchedulingRefIds(List<String> schedulingRefIds) {
		this.schedulingRefIds = schedulingRefIds;
	}
	/**
	 * @return the actionTypeList
	 */
	public List<String> getActionTypeList() {
		return actionTypeList;
	}
	/**
	 * @param actionTypeList the actionTypeList to set
	 */
	public void setActionTypeList(List<String> actionTypeList) {
		this.actionTypeList = actionTypeList;
	}
	/**
	 * @return the statusSubStatusMap
	 */
	public SortedMap<String, Set<String>> getStatusSubStatusMap() {
		return statusSubStatusMap;
	}
	/**
	 * @param statusSubStatusMap the statusSubStatusMap to set
	 */
	public void setStatusSubStatusMap(
			SortedMap<String, Set<String>> statusSubStatusMap) {
		this.statusSubStatusMap = statusSubStatusMap;
	}
	
	/**
	 * @return the ctLineItems
	 */
	public List<CtLineItem> getCtLineItems() {
		return ctLineItems;
	}
	/**
	 * @param ctLineItems the ctLineItems to set
	 */
	public void setCtLineItems(List<CtLineItem> ctLineItems) {
		this.ctLineItems = ctLineItems;
	}
	/**
	 * @return the ctB2BList
	 */
	public List<CtB2B> getCtB2BList() {
		return ctB2BList;
	}
	/**
	 * @param ctB2BList the ctB2BList to set
	 */
	public void setCtB2BList(List<CtB2B> ctB2BList) {
		this.ctB2BList = ctB2BList;
	}
	/**
	 * @return the isBulk
	 */
	public boolean isBulk() {
		return isBulk;
	}
	/**
	 * @param isBulk the isBulk to set
	 */
	public void setBulk(boolean isBulk) {
		this.isBulk = isBulk;
	}
	
	
	
}
