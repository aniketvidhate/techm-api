package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEQueueShippingCode_PK.java - hibernate Annotated Class 
 * for OCE_QUEUE_SHIPPING_CODE table containing Primary key
 */

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The Class OCEQueueShippingCode_PK.
 */
@Embeddable
public class OCEQueueShippingCode_PK implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The queue id. */
	@Column(name="QUEUE_ID")
	private String queueId;
	
	/** The sequence. */
	@Column(name="SEQUENCE")
	private int sequence;
	
	/**
	 * Instantiates a new OCE queue shipping code_ pk.
	 */
	public OCEQueueShippingCode_PK(){
		
	}

	/**
	 * Gets the queue id.
	 *
	 * @return the queueId
	 */
	public String getQueueId() {
		return queueId;
	}

	/**
	 * Sets the queue id.
	 *
	 * @param queueId the queueId to set
	 */
	public void setQueueId(String queueId) {
		this.queueId = queueId;
	}

	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public int getSequence() {
		return sequence;
	}

	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	/**
	 * Gets the serialversionuid.
	 *
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueueShippingCode_PK [queueId=" + queueId + ", sequence="
				+ sequence + "]";
	}

}
