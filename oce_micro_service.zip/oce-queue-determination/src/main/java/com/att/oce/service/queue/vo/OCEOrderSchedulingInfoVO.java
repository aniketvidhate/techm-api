package com.att.oce.service.queue.vo;

/**
 * The Class OCEOrderSchedulingInfoVO.
 *
 * @author AV00419874
 */


public class OCEOrderSchedulingInfoVO {

	/** The order id. */
	private String orderId;
	
	/** The schedulingid. */
	private String schedulingid;
	
	/** The sequence. */
	private int sequence;
	
	/**
	 * Instantiates a new OCE action type.
	 */
	public OCEOrderSchedulingInfoVO(){
		
	}

	/**
	 * Gets the order id.
	 *
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * Sets the order id.
	 *
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * Gets the schedulingid.
	 *
	 * @return the schedulingid
	 */
	public String getSchedulingid() {
		return schedulingid;
	}

	/**
	 * Sets the schedulingid.
	 *
	 * @param schedulingid the schedulingid to set
	 */
	public void setSchedulingid(String schedulingid) {
		this.schedulingid = schedulingid;
	}

	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public int getSequence() {
		return sequence;
	}

	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEOrderSchedulingInfoVO [orderId=" + orderId + ", schedulingid="
				+ schedulingid + ", sequence=" + sequence + "]";
	}

	
}
