package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEActionType.java - hibernate Annotated Class for OCE_ACTION_TYPE table
 */

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEActionType.
 */
@Entity
@Table(name="OCE_ACTION_TYPE")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEActionType")
public class OCEActionType {

	/** The action type id. */
	@Id
	@Column(name="ACTIONTYPE_ID")
	private String actionTypeId;
	
	/** The action type. */
	@Column(name="ACTION_TYPE")
	private String actionType;
	
	/**
	 * Instantiates a new OCE action type.
	 */
	public OCEActionType(){
		
	}

	/**
	 * Gets the action type id.
	 *
	 * @return the actionTypeId
	 */
	public String getActionTypeId() {
		return actionTypeId;
	}

	/**
	 * Sets the action type id.
	 *
	 * @param actionTypeId the actionTypeId to set
	 */
	public void setActionTypeId(String actionTypeId) {
		this.actionTypeId = actionTypeId;
	}

	/**
	 * Gets the action type.
	 *
	 * @return the actionType
	 */
	public String getActionType() {
		return actionType;
	}

	/**
	 * Sets the action type.
	 *
	 * @param actionType the actionType to set
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEActionType [actionTypeId=" + actionTypeId + ", actionType="
				+ actionType + "]";
	}
	
	
}
