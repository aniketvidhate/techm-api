package com.att.oce.service.queue.vo;

/**
 * The Class OCEB2BVO.
 *
 * @author AV00419874
 */


public class OCEB2BVO {

	/** The b2b. */
	private String b2b;
	
	/** The b2b fan. */
	private String b2bFan;
	
	/**
	 * Instantiates a new OCE b2 bvo.
	 */
	public OCEB2BVO(){
		
	}

	/**
	 * Gets the b2b.
	 *
	 * @return the b2b
	 */
	public String getB2b() {
		return b2b;
	}

	/**
	 * Sets the b2b.
	 *
	 * @param b2b the b2b to set
	 */
	public void setB2b(String b2b) {
		this.b2b = b2b;
	}

	/**
	 * Gets the b2b fan.
	 *
	 * @return the b2bFan
	 */
	public String getB2bFan() {
		return b2bFan;
	}

	/**
	 * Sets the b2b fan.
	 *
	 * @param b2bFan the b2bFan to set
	 */
	public void setB2bFan(String b2bFan) {
		this.b2bFan = b2bFan;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEB2B [b2b=" + b2b + ", b2bFan=" + b2bFan + "]";
	}


}
