/**
 * 
 */
package com.att.oce.service.queueImpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TimeZone;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroup;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroupCharacteristics;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtLoSGCharacteristics;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtLoSGStatus;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtOrderSource;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtSchedulingInfo;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtSchedulingInfoList;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.GroupList;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.Order;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StLoSGStatus;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StLoSGType;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StProductCategory;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StRequestType;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtOrderTask;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.StTaskStatus;
import com.att.oce.service.DateUtil;
//import com.att.oce.service.queue.DateUtil;
import com.att.oce.service.queue.OCEOrderQueueService;
import com.att.oce.service.queue.OCEQueueConstants;
import com.att.oce.service.queue.QueueCategoryService;
import com.att.oce.service.queue.QueuePriorityService;
//import com.att.oce.service.queue.QueueCategoryService;
import com.att.oce.service.queue.QueueService;
//import com.att.oce.service.queue.hibernate.orm.OCEQueuePriority;
import com.att.oce.service.queue.vo.OCEQueueDeterminationRequest;
import com.att.oce.service.queue.vo.OCEQueuePriorityCriteriaVO;
import com.att.oce.service.queue.vo.OCEQueuePriorityDataVO;
import com.att.oce.service.queue.vo.OCEQueuePriorityRefVO;
//import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.queue.vo.sub.OCEOrderInfo;
import com.att.oce.service.task.Exception.OCEException;

/**
 * @author JK00423295
 *
 */

@Component
public class OCEOrderQueueServiceImpl implements OCEOrderQueueService {
	private Logger logger = LoggerFactory.getLogger(OCEOrderQueueServiceImpl.class);
	
	@Autowired
	QueueService queueService;
	
	@Autowired(required=true)
	QueuePriorityService queuePriorityService;
	
	@Autowired
	QueueCategoryService queueCategoryService;
	
	public static final String DATEFORMAT = OCEQueueConstants.DATE_FORMAT;
	
	/**
	 * @param request
	 */
	private void updateRequest(OCEQueueDeterminationRequest request) {
		
		boolean wirelessUnlock = false;
		String losgTypeNonUnifyWireless = null;
		String prgmNmeFulfllmntMthd = null;
		Date startTime = DateUtil.getCurrentTimeAsGMT();
		String[] nonUnifyWirelessProgram = OCEQueueConstants.NON_UNIFY_WIRELESS_PROGRAM;
		String[] wirelessProgramChannel= OCEQueueConstants.WIRELESS_PROGRAM_CHANNEL;
		List<String> nonUnifyWirelessProgramList = Arrays.asList(nonUnifyWirelessProgram);
		List<String> wirelessProgramChannelList = Arrays.asList(wirelessProgramChannel);
		String losgSubStatus = null;
		boolean isWirelessFalloutOrder = isWirelessFalloutOrder(request.getOrder().getGroupList());
		request.getOrder().setWirelessFalloutOrder(isWirelessFalloutOrder);
		
		//Get Wrapped object for groups
		
		boolean nonUnifyWireless = false;
		if(null != request.getOrder().getGroupList()) {
			List<CtGroup> groups = request.getOrder().getGroupList().getGroup();
			for(CtGroup groupElement : groups){
				if(null != groupElement.getGroupCharacteristics() 
						&& null != groupElement.getGroupCharacteristics().getLoSGCharacteristics() 
						&& null != groupElement.getGroupCharacteristics().getLoSGCharacteristics().getProductCategory() 
						&& groupElement.getGroupCharacteristics().getLoSGCharacteristics().getProductCategory().value()
						.equalsIgnoreCase(StProductCategory.WIRELESS.value())) {
					StLoSGType loSGType = groupElement.getGroupCharacteristics().getLoSGCharacteristics().getLoSGType();
					CtLoSGStatus losgStatus = groupElement.getGroupCharacteristics().getLoSGCharacteristics().getLoSGStatus();
					losgSubStatus = losgStatus.getSubStatus();							
					StLoSGStatus losgStatusVal = 
							(null != losgStatus && null != losgStatus.getStatus()) ? losgStatus.getStatus() : null;

							if(null != nonUnifyWirelessProgramList && !nonUnifyWirelessProgramList.contains(loSGType)
									&& StLoSGStatus.IN_QUEUE == losgStatusVal) {
								nonUnifyWireless  = true;
								losgTypeNonUnifyWireless = 
										groupElement.getGroupCharacteristics().getLoSGCharacteristics().getLoSGType().value().toString();

								if(loSGType.value().equalsIgnoreCase(StLoSGType.UNLOCK.value())) {
									wirelessUnlock = true;
								}
							}else if (null != wirelessProgramChannelList && !wirelessProgramChannelList.isEmpty() &&
									null != request.getOrder().getCtOrderSource().getChannel() && wirelessProgramChannelList.contains(request.getOrder().getCtOrderSource().getChannel())){
								nonUnifyWireless = true;
								losgTypeNonUnifyWireless = 
										groupElement.getGroupCharacteristics().getLoSGCharacteristics().getLoSGType().value().toString();
							}
				}
			}
		}
		request.getOrder().setNonUnifyWireless(nonUnifyWireless);
		request.getOrder().setLosgTypeNonUnifyWireless(losgTypeNonUnifyWireless);
		//get the fulfillmentMethod
		prgmNmeFulfllmntMthd=getProgramNameFromFulfillmentMethod(request.getOrder().getGroupList());
		
		request.getOrder().setPrgmNmeFulfllmntMthd(prgmNmeFulfllmntMthd);
		request.getOrder().setWirelessUnlock(wirelessUnlock);
		
		/*@SuppressWarnings("unchecked")
		List<HardgoodShippingGroup> shippingCode = order.getShippingGroups();
		for (HardgoodShippingGroup shippingCodes : shippingCode) {
			if(null != shippingCodes.getPropertyValue("SHIPPING_INFOS_SHIPPINGCODE")) {
				shippingCodeList.add((String)shippingCodes.getPropertyValue(OCEOrderConstants.SHIPPING_INFOS_SHIPPINGCODE));
			}
		}
		logInfoIfEnabled(conversationId, orderId, "Shipping code for Queue determination - "+shippingCodeList.toString());*/
		List<String> schedulingRefIds = new ArrayList<>();
		List<String> actionTypeList = new ArrayList<>();
		int grpSize = request.getOrder().getGroupList().getGroup().size();
		String[] queueStatuses = OCEQueueConstants.QUEUE_STATUSES;
		List<String> queueStatusesList = Arrays.asList(queueStatuses);
		QueueStatusComparator statusComptr = new QueueStatusComparator(queueStatusesList);
		SortedMap<String, Set<String>> statusSubStatusMap = new TreeMap<String, Set<String>>(statusComptr);
		for(CtGroup groupItem : request.getOrder().getGroupList().getGroup()) {
			if(null != groupItem.getGroupCharacteristics().getLoSGCharacteristics()
					&& null != groupItem.getGroupCharacteristics().getLoSGCharacteristics().getLoSGStatus()) {
				String losgStatus = groupItem.getGroupCharacteristics().getLoSGCharacteristics().getLoSGStatus().getStatus().value();
				losgSubStatus = groupItem.getGroupCharacteristics().getLoSGCharacteristics().getLoSGStatus().getSubStatus();

				if(!losgStatus.isEmpty()) {
					if(statusSubStatusMap.containsKey(losgStatus)) {
						statusSubStatusMap.get(losgStatus).add(losgSubStatus);
						request.getOrder().setStatusSubStatusMap(statusSubStatusMap);
					} else {
						Set<String> losgSubStatuses = new HashSet<String>();
						losgSubStatuses.add(losgSubStatus);
						statusSubStatusMap.put(losgStatus, losgSubStatuses);
						request.getOrder().setStatusSubStatusMap(statusSubStatusMap);
					}
				}
				if(null!=groupItem.getGroupCharacteristics().getLoSGCharacteristics().getSchedulingInfoRef() && !groupItem.getGroupCharacteristics().getLoSGCharacteristics().getSchedulingInfoRef().isEmpty()) {
					schedulingRefIds.add(groupItem.getGroupCharacteristics().getLoSGCharacteristics().getSchedulingInfoRef());
					request.getOrder().setSchedulingRefIds(schedulingRefIds);
				}
				if(null!=groupItem.getGroupCharacteristics().getLoSGCharacteristics().getActionType() && !groupItem.getGroupCharacteristics().getLoSGCharacteristics().getActionType().value().equalsIgnoreCase("") && actionTypeList.size()==0){
					actionTypeList.add(groupItem.getGroupCharacteristics().getLoSGCharacteristics().getActionType().value());
					request.getOrder().setActionTypeList(actionTypeList);
				}
			}
		}
		
	}

	/**
	 * 
	 * @param order
	 * @return
	 */
	private Boolean checkIsConnectedChar(GroupList groupList) {

		Boolean isConnectedCar=false;

		//get Group list from Current Order OCE_ORDER_GROUPLIST

		if(null != groupList && null != groupList.getGroup() && !groupList.getGroup().isEmpty()) {
			for(CtGroup groupItem : groupList.getGroup()) {


				/*MutableRepositoryItem groupCharacteristicItem = (MutableRepositoryItem) (groupItem
						.getPropertyValue(OCEOrderConstants.GROUP_CHARACTERISTICS));*/

				
				/*if (null != groupCharacteristicItem && null!=groupCharacteristicItem.getPropertyValue(OCEOrderConstants.IS_CONNECTEDCAR)) {

					if((Boolean)groupCharacteristicItem.getPropertyValue(OCEOrderConstants.IS_CONNECTEDCAR)){
						isConnectedCar=true;
						break;
					}
				}*/

			}
		}



		return isConnectedCar;
	}

	@Override
	public QueueDetails determineQueue(OCEQueueDeterminationRequest request) {

		//TaskDetailsVO taskDetailsVO = new TaskDetailsVO();
		
		List<String> shippingCodeList = new ArrayList<String>();
		QueueDetails queueDetails = new QueueDetails();
		boolean isBulk = request.getOrder().isBulk();
		
		
		updateRequest(request); //updating request object call-by-reference.
			
			try {
				
				String defaultQueueName = OCEQueueConstants.DEFAULT_QUEUE_NAME;
				String reqQueueType = request.getOrder().getOrderTasklist().get(0).getQueueType();
				String reqQueueSubType = request.getOrder().getOrderTasklist().get(0).getQueueSubType();
				if (logger.isDebugEnabled()){
					logger.debug(reqQueueType, reqQueueSubType, "reqQueueType reqQueueSubType for Queue determination - ");
				}
				
				if(null != reqQueueType 
						&& null != reqQueueSubType 
						&& reqQueueSubType.equalsIgnoreCase(OCEQueueConstants.QUEUE_SUB_TYPE_OUTBOUND)) {
					//logDebugIfEnabled(conversationId, orderId, "Queue Type request input - "+reqQueueType);
					//logDebugIfEnabled(conversationId, orderId, "Queue Sub Type request input -  - "+reqQueueSubType);
					queueDetails = queueService.getOutboundQueueDetails(reqQueueType, request.getOrder().getCtOrderSource().getChannel());
					//queueDetails.setQueueSubType(reqQueueSubType);
					//taskDetailsVO.setQueueType(reqQueueSubType);
				} else if (!request.getOrder().getCtOrderSource().getChannel().isEmpty() && ! request.getOrder().getStatusSubStatusMap().isEmpty()) {
					String status = request.getOrder().getStatusSubStatusMap().firstKey();
					Set<String>  losgSubStatuses = new HashSet<String>();
					losgSubStatuses = request.getOrder().getStatusSubStatusMap().get(status);
					Boolean isConnectedChar = checkIsConnectedChar(request.getOrder().getGroupList());
					queueDetails = queueService.getQueueDetails(request.getOrder().getRequestId(), request.getOrder().getOceOrderNumber(), request.getOrder().getCtOrderSource().getChannel(), status, 
							status, isBulk, shippingCodeList, request.getOrder().getRequestType(), request.getOrder().getActionTypeList(), isConnectedChar);
					if(null  == queueDetails.getQueueId()) {
						queueDetails = queueService.getDefaultQueueDetails(request.getOrder().getRequestId(), request.getOrder().getOceOrderNumber(), defaultQueueName,request.getOrder().getCtOrderSource().getChannel(), request.getOrder().getRequestType());
					}
				} else if (request.getOrder().getStatusSubStatusMap().isEmpty()) {
					queueDetails = queueService.getDefaultQueueDetails(request.getOrder().getRequestId(), request.getOrder().getOceOrderNumber(), defaultQueueName,request.getOrder().getCtOrderSource().getChannel(), request.getOrder().getRequestType());
				}
				//Determine Queue Priority
				List<OCEQueuePriorityRefVO> queuePrirityDetailsVO = queuePriorityService.getQueuePrirityDetailsVO(queueDetails.getQueueId()); 
				List<OCEQueuePriorityDataVO> queuePriorityDataVO = queuePriorityService.getQueuePriorityDataVO(queuePrirityDetailsVO);
				List<OCEQueuePriorityCriteriaVO> priorityCriteriaVOs = queuePriorityService.getQueuePriorityCriteriaVO(queuePriorityDataVO);
				String queuePriority = queuePriorityService.determineQueuePriority(request.getOrder(),queuePriorityDataVO,priorityCriteriaVOs);
				queueDetails.setQueuePriority(queuePriority);
				
				//Determine Queue Category
				String queueCategory = queueCategoryService.getQueueCatagory(queueDetails.getQueueType(), request, request.getOrder().isNonUnifyWireless());
				queueDetails.setQueueCategory(queueCategory);
				
			} catch (OCEException e) {
				if (logger.isErrorEnabled()) {
					logger.error(e.getMessage());
				}
			}
			
		
		return queueDetails;
	}
	
	/**
	 * 
	 * @param groupList
	 * @return boolean
	 */
	public boolean isWirelessFalloutOrder(GroupList groupList) {
		
		boolean isWirelessFallout = false;
		List<CtGroup> groups = groupList.getGroup();
		for (CtGroup groupItem : groups) {
			if (null != groupItem.getGroupCharacteristics().getLoSGCharacteristics()
					&& null != groupItem.getGroupCharacteristics().getLoSGCharacteristics().getLoSGStatus()) {
				String losgStatus = groupItem.getGroupCharacteristics().getLoSGCharacteristics().getLoSGStatus().getStatus().value();
				String productCategory = groupItem.getGroupCharacteristics().getLoSGCharacteristics().getProductCategory().value();
				String losgType = groupItem.getGroupCharacteristics().getLoSGCharacteristics().getLoSGType().value();
				if(OCEQueueConstants.IN_QUEUE.equalsIgnoreCase(losgStatus) && OCEQueueConstants.WIRELESS.equalsIgnoreCase(productCategory)
						&& OCEQueueConstants.NEW.equalsIgnoreCase(losgType) ){
					isWirelessFallout = true;
					break;
				}

			}
		}
		return isWirelessFallout;
	}
	
	/**
	 * 
	 * @param groupList
	 * @return String
	 */
	private String getProgramNameFromFulfillmentMethod(GroupList groupList) {
		String prgm = null;	
	 if(null != groupList && null != groupList.getGroup()){
		for(CtGroup grpItm : groupList.getGroup()) {
			if(null != grpItm.getGroupCharacteristics().getLoSGCharacteristics()
					&& null != grpItm.getGroupCharacteristics().getLoSGCharacteristics().getFulfillmentMethod()) {
				prgm = grpItm.getGroupCharacteristics().getLoSGCharacteristics().getFulfillmentMethod();
				break;
			}
		}
	 }
		return prgm;
	}
	
	
	//This method added just to make code independent from other ajsc project.
	//This method will be removed after final integration and will be refer from Dateutil class of main project.
	public static Date getCurrentTimeAsGMT(){
		return stringDateToDate(getGMTdatetimeAsString());
	}
	
	public static String getGMTdatetimeAsString()
	{
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}
	
	public static Date stringDateToDate(String StrDate)
	{
		Date dateToReturn = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
		try
		{
			dateToReturn = (Date)dateFormat.parse(StrDate);
		}
		catch (ParseException e)
		{
//			if(logger.isErrorEnabled()) {
//				logger.error("Error while parsing GMT time "); 
//			}
			e.getMessage();
		}

		return dateToReturn;
	}
	
	private String detrmineQueuePriroty (String queueId) {
		//Determine Queue Priority
		String queuePriority = null; 
		String priorityBit = null;
		List<String> queueCriteriaValueList = null;
		int [] priorityList = new int[6];
		Arrays.fill(priorityList, 0);
		int priority = 1;
		//Step1 : obtain List<OCEQueuePriorityRefVO> queuePriorityDetailsObj;
		List<OCEQueuePriorityRefVO> queuePriorityDetailsObj = queuePriorityService.getQueuePrirityDetailsVO(queueId);
		
		//Step2 : obtain List<OCEQueuePriorityDataVO> queuePriorityDataObj;
		List<OCEQueuePriorityDataVO> queuePriorityDataObj = queuePriorityService.getQueuePriorityDataVO(queuePriorityDetailsObj);
		String queueCriteriaValue = null;
		for(OCEQueuePriorityDataVO vo1 : queuePriorityDataObj) {
			System.out.println("Test1 OCEQueuePriorityDataVO getQueuePriorityCriteriaId ::  " +vo1.getQueuePriorityCriteriaId());
			List<String> criteriaValueList = new ArrayList<>();
			queueCriteriaValue = vo1.getCriteriaValue();
			
			if(null != queueCriteriaValue) {
				String[] arrQueueCriteriaValue = queueCriteriaValue.split(",");
				queueCriteriaValueList = new ArrayList<String>(Arrays.asList(arrQueueCriteriaValue));
			}
			
			priority = vo1.getCriteriaRanking();
		}
		//Step3 : obtain List<OCEQueuePriorityCriteriaVO> queuePriorityCriteriaObj
		List<OCEQueuePriorityCriteriaVO> queuePriorityCriteriaObj = queuePriorityService.getQueuePriorityCriteriaVO(queuePriorityDataObj);
		List<String> criteriaValueList = new ArrayList<>();
		
		
		for(OCEQueuePriorityCriteriaVO vo3 : queuePriorityCriteriaObj) {
			System.out.println("Test1 OCEQueuePriorityCriteriaVO priorityCriteriaName ::  " +vo3.getPriorityCriteriaName());
			if (null != vo3) {
				String criteriaRepoPath = vo3.getPriorityCriteriaRerpopath();
				String[] arrCriteriaRepoPath = criteriaRepoPath.split("/");
				final List<String> criteriaRepoPathList = Arrays.asList(arrCriteriaRepoPath);
				String orderLevelPropName = criteriaRepoPathList.get(1);

				if(orderLevelPropName.contains("[]")) {
					orderLevelPropName = orderLevelPropName.replaceAll("[\\[\\]]", "");
				}
				criteriaValueList.add(orderLevelPropName);
				//Object orderLevelPropObj = currentOrderImpl.getPropertyValue(orderLevelPropName);							
				/*if (criteriaRepoPathList.size() <= 2) {
					if(null != orderLevelPropObj) {
						String orderLevelPropValue = (String) orderLevelPropObj;
						criteriaValueList.add(orderLevelPropValue);
					}
				} else {
					criteriaValueList = 
							getQueuePriorityCriteriaOrderValues(orderLevelPropObj, criteriaRepoPathList, 2);
				}*/

			}

			if (null != queueCriteriaValueList) {
				// Setting the particular bit
				for (String queueCriteriaValueItem : queueCriteriaValueList) {
					if (criteriaValueList.contains(queueCriteriaValueItem)) {
						priorityList[priority - 1] = 1;
					}
				}
			}
			StringBuilder priorityBitBldr = new StringBuilder("");
			for(int bitval : priorityList) {
				priorityBitBldr.append(bitval);
			}
			priorityBit = priorityBitBldr.toString();
		}
		return priorityBit;
	}
	
}
