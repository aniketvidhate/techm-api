package com.att.oce.service.queue.vo;

/**
 * The Class DcsppOrderItemVO.
 *
 * @author AV00419874
 */


public class DcsppOrderItemVO {

	/** The order id. */
	private String orderId;
	
	/** The commerce items. */
	private String commerceItems;
	
	/**
	 * Instantiates a new dcspp order item vo.
	 */
	public DcsppOrderItemVO(){
		
	}

	/**
	 * Gets the order id.
	 *
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * Sets the order id.
	 *
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * Gets the commerce items.
	 *
	 * @return the commerceItems
	 */
	public String getCommerceItems() {
		return commerceItems;
	}

	/**
	 * Sets the commerce items.
	 *
	 * @param commerceItems the commerceItems to set
	 */
	public void setCommerceItems(String commerceItems) {
		this.commerceItems = commerceItems;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DcsppOrderItem [orderId=" + orderId + ", commerceItems="
				+ commerceItems + "]";
	}

	

}
