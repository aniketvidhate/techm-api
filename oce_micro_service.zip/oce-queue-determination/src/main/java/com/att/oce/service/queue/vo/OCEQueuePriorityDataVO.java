package com.att.oce.service.queue.vo;


/**
 * The Class OCEQueuePriorityDataVO.
 *
 * @author AV00419874
 */

public class OCEQueuePriorityDataVO {

	/** The queue priority criteria id. */
	private String queuePriorityCriteriaId;
	
	/** The criteria data. */
	private String criteriaData;
	
	/** The criteria value. */
	private String criteriaValue;
	
	/** The criteria ranking. */
	private int criteriaRanking;


	/**
	 * Gets the queue priority criteria id.
	 *
	 * @return the queuePriorityCriteriaId
	 */
	public String getQueuePriorityCriteriaId() {
		return queuePriorityCriteriaId;
	}
	
	/**
	 * Sets the queue priority criteria id.
	 *
	 * @param queuePriorityCriteriaId the queuePriorityCriteriaId to set
	 */
	public void setQueuePriorityCriteriaId(String queuePriorityCriteriaId) {
		this.queuePriorityCriteriaId = queuePriorityCriteriaId;
	}
	
	/**
	 * Gets the criteria data.
	 *
	 * @return the criteriaData
	 */
	public String getCriteriaData() {
		return criteriaData;
	}
	
	/**
	 * Sets the criteria data.
	 *
	 * @param criteriaData the criteriaData to set
	 */
	public void setCriteriaData(String criteriaData) {
		this.criteriaData = criteriaData;
	}
	
	/**
	 * Gets the criteria value.
	 *
	 * @return the criteriaValue
	 */
	public String getCriteriaValue() {
		return criteriaValue;
	}
	
	/**
	 * Sets the criteria value.
	 *
	 * @param criteriaValue the criteriaValue to set
	 */
	public void setCriteriaValue(String criteriaValue) {
		this.criteriaValue = criteriaValue;
	}
	
	/**
	 * Gets the criteria ranking.
	 *
	 * @return the criteriaRanking
	 */
	public int getCriteriaRanking() {
		return criteriaRanking;
	}
	
	/**
	 * Sets the criteria ranking.
	 *
	 * @param criteriaRanking the criteriaRanking to set
	 */
	public void setCriteriaRanking(int criteriaRanking) {
		this.criteriaRanking = criteriaRanking;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueuePriorityVO [queuePriorityCriteriaId="
				+ queuePriorityCriteriaId + ", criteriaData=" + criteriaData
				+ ", criteriaValue=" + criteriaValue + ", criteriaRanking="
				+ criteriaRanking + "]";
	}



}
