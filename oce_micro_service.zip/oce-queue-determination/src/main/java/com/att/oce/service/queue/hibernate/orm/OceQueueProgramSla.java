package com.att.oce.service.queue.hibernate.orm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


/**
 * The Class OceQueueProgramSla.
 */
@Entity
@Table(name = "OCE_QUEUE_PROGRAM_SLA")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OceQueueProgramSla")
public class OceQueueProgramSla {
	
	/** The queue sla id. */
	@Id
	@Column(name = "QUEUE_SLA_ID")
	private String queueSlaId;

	/** The program name. */
	@Column(name = "PROGRAM_NAME")
	private String programName;

	/** The sla green min. */
	@Column(name = "SLA_GREEN_MIN")
	private int slaGreenMin;

	/** The sla amber min. */
	@Column(name = "SLA_AMBER_MIN")
	private int slaAmberMin;

	/** The sla red min. */
	@Column(name = "SLA_RED_MIN")
	private int slaRedMin;

	/** The sla green max. */
	@Column(name = "SLA_GREEN_MAX")
	private int slaGreenMax;

	/** The sla amber max. */
	@Column(name = "SLA_AMBER_MAX")
	private int slaAmberMax;
	
	/** The sla red max. */
	@Column(name = "SLA_RED_MAX")
	private int slaRedMax;

	/** The at risk. */
	@Column(name = "AT_RISK")
	private int atRisk;

	/** The at violation. */
	@Column(name = "AT_VIOLATION")
	private int atViolation;

	/** The sla alert. */
	@Column(name = "SLA_ALERT")
	private int slaAlert;
	
	/** The sla breach. */
	@Column(name = "SLA_BREACH")
	private int slaBreach;

	/** The threshold breach email. */
	@Column(name = "THRESHOLD_BREACH_EMAIL")
	private String thresholdBreachEmail;
	
	/** The program priority. */
	@Column(name = "PROGRAM_PRIORITY")
	private String programPriority;


	/**
	 * Instantiates a new oce queue program sla.
	 */
	public OceQueueProgramSla(){
		
	}


	/**
	 * Gets the queue sla id.
	 *
	 * @return the queueSlaId
	 */
	public String getQueueSlaId() {
		return queueSlaId;
	}


	/**
	 * Sets the queue sla id.
	 *
	 * @param queueSlaId the queueSlaId to set
	 */
	public void setQueueSlaId(String queueSlaId) {
		this.queueSlaId = queueSlaId;
	}


	/**
	 * Gets the program name.
	 *
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}


	/**
	 * Sets the program name.
	 *
	 * @param programName the programName to set
	 */
	public void setProgramName(String programName) {
		this.programName = programName;
	}


	/**
	 * Gets the sla green min.
	 *
	 * @return the slaGreenMin
	 */
	public int getSlaGreenMin() {
		return slaGreenMin;
	}


	/**
	 * Sets the sla green min.
	 *
	 * @param slaGreenMin the slaGreenMin to set
	 */
	public void setSlaGreenMin(int slaGreenMin) {
		this.slaGreenMin = slaGreenMin;
	}


	/**
	 * Gets the sla amber min.
	 *
	 * @return the slaAmberMin
	 */
	public int getSlaAmberMin() {
		return slaAmberMin;
	}


	/**
	 * Sets the sla amber min.
	 *
	 * @param slaAmberMin the slaAmberMin to set
	 */
	public void setSlaAmberMin(int slaAmberMin) {
		this.slaAmberMin = slaAmberMin;
	}


	/**
	 * Gets the sla red min.
	 *
	 * @return the slaRedMin
	 */
	public int getSlaRedMin() {
		return slaRedMin;
	}


	/**
	 * Sets the sla red min.
	 *
	 * @param slaRedMin the slaRedMin to set
	 */
	public void setSlaRedMin(int slaRedMin) {
		this.slaRedMin = slaRedMin;
	}


	/**
	 * Gets the sla green max.
	 *
	 * @return the slaGreenMax
	 */
	public int getSlaGreenMax() {
		return slaGreenMax;
	}


	/**
	 * Sets the sla green max.
	 *
	 * @param slaGreenMax the slaGreenMax to set
	 */
	public void setSlaGreenMax(int slaGreenMax) {
		this.slaGreenMax = slaGreenMax;
	}


	/**
	 * Gets the sla amber max.
	 *
	 * @return the slaAmberMax
	 */
	public int getSlaAmberMax() {
		return slaAmberMax;
	}


	/**
	 * Sets the sla amber max.
	 *
	 * @param slaAmberMax the slaAmberMax to set
	 */
	public void setSlaAmberMax(int slaAmberMax) {
		this.slaAmberMax = slaAmberMax;
	}


	/**
	 * Gets the sla red max.
	 *
	 * @return the slaRedMax
	 */
	public int getSlaRedMax() {
		return slaRedMax;
	}


	/**
	 * Sets the sla red max.
	 *
	 * @param slaRedMax the slaRedMax to set
	 */
	public void setSlaRedMax(int slaRedMax) {
		this.slaRedMax = slaRedMax;
	}


	/**
	 * Gets the at risk.
	 *
	 * @return the atRisk
	 */
	public int getAtRisk() {
		return atRisk;
	}


	/**
	 * Sets the at risk.
	 *
	 * @param atRisk the atRisk to set
	 */
	public void setAtRisk(int atRisk) {
		this.atRisk = atRisk;
	}


	/**
	 * Gets the at violation.
	 *
	 * @return the atViolation
	 */
	public int getAtViolation() {
		return atViolation;
	}


	/**
	 * Sets the at violation.
	 *
	 * @param atViolation the atViolation to set
	 */
	public void setAtViolation(int atViolation) {
		this.atViolation = atViolation;
	}


	/**
	 * Gets the sla alert.
	 *
	 * @return the slaAlert
	 */
	public int getSlaAlert() {
		return slaAlert;
	}


	/**
	 * Sets the sla alert.
	 *
	 * @param slaAlert the slaAlert to set
	 */
	public void setSlaAlert(int slaAlert) {
		this.slaAlert = slaAlert;
	}


	/**
	 * Gets the sla breach.
	 *
	 * @return the slaBreach
	 */
	public int getSlaBreach() {
		return slaBreach;
	}


	/**
	 * Sets the sla breach.
	 *
	 * @param slaBreach the slaBreach to set
	 */
	public void setSlaBreach(int slaBreach) {
		this.slaBreach = slaBreach;
	}


	/**
	 * Gets the threshold breach email.
	 *
	 * @return the thresholdBreachEmail
	 */
	public String getThresholdBreachEmail() {
		return thresholdBreachEmail;
	}


	/**
	 * Sets the threshold breach email.
	 *
	 * @param thresholdBreachEmail the thresholdBreachEmail to set
	 */
	public void setThresholdBreachEmail(String thresholdBreachEmail) {
		this.thresholdBreachEmail = thresholdBreachEmail;
	}


	/**
	 * Gets the program priority.
	 *
	 * @return the programPriority
	 */
	public String getProgramPriority() {
		return programPriority;
	}


	/**
	 * Sets the program priority.
	 *
	 * @param programPriority the programPriority to set
	 */
	public void setProgramPriority(String programPriority) {
		this.programPriority = programPriority;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OceQueueProgramSla [queueSlaId=" + queueSlaId
				+ ", programName=" + programName + ", slaGreenMin="
				+ slaGreenMin + ", slaAmberMin=" + slaAmberMin + ", slaRedMin="
				+ slaRedMin + ", slaGreenMax=" + slaGreenMax + ", slaAmberMax="
				+ slaAmberMax + ", slaRedMax=" + slaRedMax + ", atRisk="
				+ atRisk + ", atViolation=" + atViolation + ", slaAlert="
				+ slaAlert + ", slaBreach=" + slaBreach
				+ ", thresholdBreachEmail=" + thresholdBreachEmail
				+ ", programPriority=" + programPriority + "]";
	}
 	
	
}
