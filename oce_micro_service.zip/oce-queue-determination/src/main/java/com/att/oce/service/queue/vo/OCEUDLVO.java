package com.att.oce.service.queue.vo;

/**
 * @author AV00419874
 * OCEUDL.java - hibernate Annotated Class for OCE_UDL table
 */

public class OCEUDLVO {

	private String udlId;
	private String sequenceNumber;
	private String key;
	private String value;

	/**
	 * Instantiates a new oceudl.
	 */
	public OCEUDLVO(){
		
	}

	/**
	 * @return the udlId
	 */
	public String getUdlId() {
		return udlId;
	}

	/**
	 * @param udlId the udlId to set
	 */
	public void setUdlId(String udlId) {
		this.udlId = udlId;
	}

	/**
	 * @return the sequenceNumber
	 */
	public String getSequenceNumber() {
		return sequenceNumber;
	}

	/**
	 * @param sequenceNumber the sequenceNumber to set
	 */
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEUDLVO [udlId=" + udlId + ", sequenceNumber="
				+ sequenceNumber + ", key=" + key + ", value=" + value + "]";
	}

	



}
