package com.att.oce.service.queue.hibernate.orm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OceQueueProgramSlaDtls.
 */
@Entity
@Table(name = "OCE_QUEUE_PROGRAM_SLA_DTLS")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OceQueueProgramSlaDtls")
public class OceQueueProgramSlaDtls {

	   
	/** The id. */
	@Id
	@Column(name = "ID")
	private String id;

	/** The sequence. */
	@Column(name = "SEQUENCE")
	private String sequence;

	/** The queue sla id. */
	@Column(name = "QUEUE_SLA_ID")
	private String queueSlaId;

	/**
	 * Instantiates a new oce queue program sla dtls.
	 */
	public OceQueueProgramSlaDtls(){
		
	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public String getSequence() {
		return sequence;
	}

	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	/**
	 * Gets the queue sla id.
	 *
	 * @return the queueSlaId
	 */
	public String getQueueSlaId() {
		return queueSlaId;
	}

	/**
	 * Sets the queue sla id.
	 *
	 * @param queueSlaId the queueSlaId to set
	 */
	public void setQueueSlaId(String queueSlaId) {
		this.queueSlaId = queueSlaId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OceQueueProgramSlaDtls [id=" + id + ", sequence=" + sequence
				+ ", queueSlaId=" + queueSlaId + "]";
	}
 
}
