package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEDcsspOrder.java - hibernate Annotated Class for OCE_DCSPP_ORDER table
 */

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEActionType.
 */
@Entity
@Table(name="OCE_DCSPP_ORDER")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEDcsspOrder")
public class OCEDcsspOrder {

	/** The action type id. */
	@Id
	@Column(name="ORDER_ID")
	private String orderId;
	
	/** The action type. */
	@Column(name="CONVERSATION_ID")
	private String conversationId;
	
	/**
	 * Instantiates a new OCE action type.
	 */
	public OCEDcsspOrder(){
		
	}

	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * @return the conversationId
	 */
	public String getConversationId() {
		return conversationId;
	}

	/**
	 * @param conversationId the conversationId to set
	 */
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEDcsspOrder [orderId=" + orderId + ", conversationId="
				+ conversationId + "]";
	}

	
}
