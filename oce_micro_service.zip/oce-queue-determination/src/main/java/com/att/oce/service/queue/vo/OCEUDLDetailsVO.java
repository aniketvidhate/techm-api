package com.att.oce.service.queue.vo;

/**
 * @author AV00419874
 * OCEUDLDetails_PK.java - hibernate Annotated Class for OCE_UDL_DETAILS table
 */


public class OCEUDLDetailsVO {

	private String orderLosgCharacteristics;

	private int sequence;

	private String udlDetailsId;

	private String value;

	/**
	 * Instantiates a new oceudl.
	 */
	public OCEUDLDetailsVO(){

	}

	/**
	 * @return the orderLosgCharacteristics
	 */
	public String getOrderLosgCharacteristics() {
		return orderLosgCharacteristics;
	}

	/**
	 * @param orderLosgCharacteristics the orderLosgCharacteristics to set
	 */
	public void setOrderLosgCharacteristics(String orderLosgCharacteristics) {
		this.orderLosgCharacteristics = orderLosgCharacteristics;
	}

	/**
	 * @return the sequence
	 */
	public int getSequence() {
		return sequence;
	}

	/**
	 * @param sequence the sequence to set
	 */
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	/**
	 * @return the udlDetailsId
	 */
	public String getUdlDetailsId() {
		return udlDetailsId;
	}

	/**
	 * @param udlDetailsId the udlDetailsId to set
	 */
	public void setUdlDetailsId(String udlDetailsId) {
		this.udlDetailsId = udlDetailsId;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEUDLDetailsVO [orderLosgCharacteristics="
				+ orderLosgCharacteristics + ", sequence=" + sequence
				+ ", udlDetailsId=" + udlDetailsId + ", value=" + value + "]";
	}


}
