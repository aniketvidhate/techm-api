package com.att.oce.service.queueImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.stat.Statistics;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.att.oce.service.queue.QueueService;
import com.att.oce.service.queue.hibernate.orm.OCEQueueMaster;
import com.att.oce.service.queue.hibernate.orm.OceQueueProgramSla;
import com.att.oce.service.queue.hibernate.orm.OceQueueProgramSlaDtls;
import com.att.oce.service.queue.vo.OCEActionTypeVO;
import com.att.oce.service.queue.vo.OCELineSubstatusVO;
import com.att.oce.service.queue.vo.OCEQueueActionTypeVO;
import com.att.oce.service.queue.vo.OCEQueueLineSubstatusVO;
import com.att.oce.service.queue.vo.OCEQueueMasterVO;
import com.att.oce.service.queue.vo.OCEQueueShippingCodeVO;
import com.att.oce.service.queue.vo.OceQueueProgramSlaVO;
import com.att.oce.service.task.Exception.OCEException;

@Repository
public class QueueServiceImpl implements QueueService {

	@Autowired 
	QueueDetails queueDetails;

	
	@Autowired(required = true)
	@Qualifier("queueSessionFactory")
	SessionFactory queueSessionFactory;

	private Logger logger = LoggerFactory.getLogger(QueueServiceImpl.class);

	private static final String QUERY_FETCH_QUEUE_BY_TYPE_CHANNEL = 
			"SELECT t1.id as id FROM OCEQueueMaster t1 WHERE t1.queueType = :queueType AND t1.channel = :channel";

	private static final String QUERY_FETCH_OUTBOUND_QUEUE_BY_TYPE_CHANNEL = "SELECT id as id, queueType as queueType from OCEQueueMaster where "
			+ " queueType = :queueType and channel = :channel";
	
	private static final String QUERY_FETCH_ALL_ACTION_TYPE_DETAIL = "SELECT actionTypeId as actionTypeId, actionType as actionType from OCEActionType";
	
	private static final String QUERY_FETCH_ACTION_TYPE_BY_ID = "select id as id, sequence as sequence,actionTypeId as actionTypeId "
					+ " from OCEQueueActionType WHERE id = :queueId";
	
	private static final String QUERY_FETCH_ALL_OCE_QUEUE_LINE_SUBSTATUS = 
			"SELECT sequence as sequence, subStatusId as subStatusId, id as id "
			+ " from OCEQueueLineSubstatus "
			+ " WHERE id = :queueId ORDER BY sequence ASC";
	
	private static final String QUERY_FETCH_SUBSTATUS_BY_ID  = 
			"select id as id, lineSubStatus as lineSubStatus, productCategory as productCategory, "
					+ " status as status, isBulk as isBulk, isConnectedCAR as isConnectedCAR, "
					+ " manualIntervention as manualIntervention, queueSubType as queueSubType from OCELineSubstatus "
					+ " where id in (select subStatusId from OCEQueueLineSubstatus WHERE id = :queueId)";

	private static final String QUERY_FETCH_SHIPPING_DETAILS_BY_ID  =  
			"SELECT t.oceQueueShippingCode_PK.sequence as sequence, t.shipCodeId as shipCodeId "
			+ " FROM OCEQueueShippingCode t WHERE t.oceQueueShippingCode_PK.queueId= :queueId "
			+ " ORDER BY t.oceQueueShippingCode_PK.sequence ASC";
	
	
	private static final String QUERY_FETCH_ALL_QUEUE_MASTER_DETAIL_BY_ID = 
			" SELECT id as id, queueType as queueType, queueDescription as queueDescription, "
			+ "priority as priority, lineComboFlag as lineComboFlag, enterpriseType as enterpriseType, "
			+ "userRoles as userRoles, releaseLock as releaseLock, vacantAlert as vacantAlert, "
			+ "vacantAlertEmail as vacantAlertEmail, falloutsThreshold as falloutsThreshold, "
			+ "no_OrderAlert as no_OrderAlert, creationDate as creationDate, lastModiedDate as lastModiedDate, "
			+ "thresholdCount as thresholdCount, queueLimitAlertEmail as queueLimitAlertEmail, "
			+ "effectiveFromDate as effectiveFromDate, effectiveTillDate as effectiveTillDate, sku as sku, "
			+ "isOrderLevelQueue as isOrderLevelQueue, channel as channel, callbackPreference as callbackPreference, "
			+ "active as active, repCommnets as repCommnets, queueInfo as queueInfo, escalationType as escalationType, "
			+ "escalationPriority as escalationPriority, gigaInd as gigaInd, queueGroup as queueGroup, "
			+ "requestType as requestType, lastModifiedBy as lastModifiedBy, last_Modified_By as last_Modified_By "
			+ "FROM OCEQueueMaster WHERE id = :queueId";
	
	private static final String CONST_QUEUE_TYPE = "queueType";
	private static final String CONST_CHANNEL = "channel";
	private static final String CONST_STATUS = "status";
	private static final String CONST_ISBULK = "isBulk";
	private static final String CONST_ISCONCHAR = "isConChar";
	private static final String CONST_LINESUBSTATUS = "lineSubstatuses";
	private static final String CONST_UNLOCK = "UNLOCK";
	private static final String CONST_IN_QUEUE = "IN_QUEUE";
	private static final String CONST_CRU_MOBILTY = "CRU-MOBILITY";
	private static final String CONST_REQUEST_TYPE = "requestType";
	private static final String CONST_ACTION_TYPE_LIST = "actionTypeList";
	
	 
	 
	@SuppressWarnings("unchecked")
	@Override
	public QueueDetails getOutboundQueueDetails(String reqQueueType, String channel) throws OCEException{


		Session session = null;

		try {
			session = queueSessionFactory.openSession();
			Query fetchQueueQry = session.createQuery(QUERY_FETCH_OUTBOUND_QUEUE_BY_TYPE_CHANNEL);

			//Setting up the parameters
			fetchQueueQry.setParameter(CONST_QUEUE_TYPE, reqQueueType);
			fetchQueueQry.setParameter(CONST_CHANNEL, channel);

			//Enabling Caching
			fetchQueueQry.setCacheable(true);
			
			fetchQueueQry.setResultTransformer(new AliasToBeanResultTransformer(OCEQueueMasterVO.class));

			List<OCEQueueMasterVO> result = fetchQueueQry.list();
			for(OCEQueueMasterVO vo : result) {
				queueDetails.setQueueId(vo.getId());
				queueDetails.setQueueId(vo.getQueueType());
			}

		} catch(HibernateException hbe) {
			throw new OCEException("QueueServiceImpl.java getOutboundQueueDetails() :: ", hbe);
		} finally {
			if (session.isOpen()) {
				session.close();
			}
		}

		return queueDetails;
	}


	@SuppressWarnings("unchecked")
	@Override
	public QueueDetails getDefaultQueueDetails(String conversationId, String orderId, String defaultQueueType,
			String channel,String requestType) throws OCEException {

		String queueId = null;
		Session session = null;
		
		try {
			session = queueSessionFactory.openSession();

			//Step1 : fetch queue id:

			//initialize query and set up the parameters
			Query fetchIdQuery = session.createQuery(QUERY_FETCH_QUEUE_BY_TYPE_CHANNEL);
			fetchIdQuery.setParameter("queueType", defaultQueueType.toUpperCase());
			fetchIdQuery.setParameter("channel", channel);

			//Enabling Caching
			fetchIdQuery.setCacheable(true);

			fetchIdQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEQueueMasterVO.class));

			List<OCEQueueMasterVO> listOfObject = fetchIdQuery.list();
			if (null != listOfObject) {
				for(OCEQueueMasterVO vo : listOfObject) {
					queueId = vo.getId();
				}

			}

			//Step2 : fetch QueueDetails where queueId = queueId from step1.
			if(queueId != null){
				List<OCEQueueMasterVO> queueList = getQueueMasterRecordsById(queueId);

				if (null != queueList ) {
					/**for debugging purpose */ 
					for(OCEQueueMasterVO vo : queueList) {
						System.out.println("queueList ==> "+vo.toString());
						queueDetails.setQueueId(vo.getId());
						queueDetails.setQueueType(vo.getQueueType());
						queueDetails.setRepComments(vo.getRepCommnets());
					}
				}
			}


		} catch(HibernateException hbe) {
			throw new OCEException("QueueServiceImpl.java getDefaultQueueDetails() :: ", hbe);
		} finally {
			if(session.isOpen()) {
				session.close();
			}
		}
		return queueDetails;
	}


	@SuppressWarnings("unchecked")
	@Override
	public QueueDetails getQueueDetails(String conversationId, String orderId, 
			String channel, String losgStatus, String status, 
			Boolean isBulk, List<String> shippingCodeList,
			String requestType,List<String> actionTypeList, Boolean isConnectedCar) throws OCEException{

		Boolean isBulklocal = (null == isBulk) ? Boolean.FALSE : isBulk;
		Boolean isConnectedCarVal = (null == isConnectedCar) ? Boolean.FALSE : isConnectedCar;

		//Step 1 : Determine queueId
		//Step 2 : fetch shipping details where queue_id = id in step1
		//Step3 : fetch queue details from queue_master where id = id in step1
		
		String queueId = null;
		int pos = 4;

		//TODO: define static final constants.
		String[] queueStatuses = {"IN_QUEUE","FOLLOWUP_REQUIRED","SHIPPED", "ACTIVATED", "PENDING", "CANCELED","OTHER","NOKIA_VERIFIED"};
		List<String> queueStatusesList = Arrays.asList(queueStatuses);

		List<String> lineSubstatuses = new ArrayList<String>(queueStatusesList.size()+1);
		lineSubstatuses.add("NA");
		lineSubstatuses.addAll(queueStatusesList);

		//TODO: define static final constants.
		String queryString = "SELECT DISTINCT t1.id as id FROM OCEQueueMaster t1, OCEQueueLineSubstatus t2 "
				+ "WHERE t2.id=t1.id AND t1.channel = :channel AND t2.subStatusId IN "
				+ "( SELECT tt1.id FROM OCELineSubstatus tt1 WHERE tt1.status = :status AND "
				+ "tt1.isBulk = :isBulk AND tt1.isConnectedCAR = :isConChar "
				+ " AND tt1.lineSubStatus IN  (:lineSubstatuses))";
		//+ " AND :pos";

		Session session = null;

		try {
			session = queueSessionFactory.openSession();
			Query selectQuery = session.createQuery(queryString);

			//TODO: define static final constants.
			selectQuery.setParameter(CONST_CHANNEL, channel); 
			selectQuery.setParameter(CONST_STATUS, status);
			selectQuery.setParameter(CONST_ISBULK, 0);
			selectQuery.setParameter(CONST_ISCONCHAR, 0);
			selectQuery.setParameterList(CONST_LINESUBSTATUS, lineSubstatuses);
			//selectQuery.setParameter("pos", pos);

			pos = pos + lineSubstatuses.size();

			/**Changes for US755536 - RequestType,ActionType for CRU-MOBILITY**/
			if(null != requestType && channel.equalsIgnoreCase("CRU-MOBILITY")) {
				//if(null != requestType && channel.equalsIgnoreCase("UNLOCK")) {

				//TODO: define static final constants.
				queryString = "SELECT DISTINCT t1.id FROM OCEQueueMaster t1, OCEQueueLineSubstatus t2 "
						+ "WHERE t2.id=t1.id AND t1.channel = :channel AND t2.subStatusId IN "
						+ "( SELECT tt1.id FROM OCELineSubstatus tt1 WHERE tt1.status = :status AND "
						+ "tt1.isBulk = :isBulk AND tt1.isConnectedCAR = :isConChar AND "
						+ "tt1.lineSubStatus in (:lineSubstatuses)) "
						+ "AND t1.requestType = :requestType ";
				//+ "AND :pos";


				//				pos = pos++;
				//				if(null != actionTypeList && !actionTypeList.isEmpty()) {
				//					
				//					/*channel EQUALS ?0 AND lineSubStatusList INCLUDES ITEM 
				//							(status EQUALS ?1 AND isBulk = ?2 AND isConnectedCar = ?3 
				//									AND (lineSubstatus EQUALS ?4 OR lineSubstatus EQUALS ?5 
				//											OR lineSubstatus EQUALS ?6)) AND requestType EQUALS ?7 
				//													AND queueActionTypeList INCLUDES ITEM ()*/
				//					
				//					
				//					queryString = queryString = "SELECT DISTINCT t1.id FROM oce_queue_master t1, oce_queue_linesubstatus t2 "
				//							+ "WHERE t2.id=t1.id AND ((t1.channel = :channel) AND t2.substatus_id IN "
				//							+ "( SELECT tt1.id FROM oce_linesubstatus tt1 WHERE ((tt1.status = ?) AND "
				//							+ "(tt1.isbulk = :isBulk) AND ((tt1.line_sub_status in (:lineSubStatus1, :lineSubStatus2, lineSubStatus3))) AND "
				//							+ "requestType EQUALS :requestType AND queueActionTypeList INCLUDES :actionTypeList AND :pos)))";
				//					selectQuery.setParameter("pos", ++pos);
				//					pos = pos + actionTypeList.size();
				//					selectQuery.setParameter("actionTypeList", actionTypeList);
				//				}
				//				selectQuery.setParameter("requestType", requestType);
				//				selectQuery.setParameter("pos", pos);
			}

			if(null != requestType && channel.equalsIgnoreCase(CONST_CRU_MOBILTY)) {
				//TODO: define static final constants.	
				selectQuery.setParameter(CONST_REQUEST_TYPE, requestType);
				if(null != actionTypeList && !actionTypeList.isEmpty()) {
					selectQuery.setParameter(CONST_ACTION_TYPE_LIST, actionTypeList);
				}
			}


			//Enabling Caching
			selectQuery.setCacheable(true);

			selectQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEQueueMasterVO.class));

			List<OCEQueueMasterVO> result = selectQuery.list();

			List<QueueDetails> queueDetailList = new ArrayList<QueueDetails>();
			for(OCEQueueMasterVO vo : result) {
				queueDetails.setQueueId(vo.getId());
				queueDetails.setQueueType(vo.getQueueType());
				queueDetails.setQueuePriority(String.valueOf(vo.getPriority()));
				queueDetails.setRepComments(vo.getRepCommnets());
				queueDetailList.add(queueDetails);
				/*private String queueId;
				private String queueType;
				private String queueSubType;
				private String repComments;
				private String queuePriority;
				private String queueCategory;
				private String actionType;*/
			}

			//Step 2 : fetch shipping details where queue_id = id in step1

			Query shipQuery = session.createQuery(QUERY_FETCH_SHIPPING_DETAILS_BY_ID);
			shipQuery.setParameter("queueId", queueDetails.getQueueId());


			//Enabling Caching
			shipQuery.setCacheable(true);

			shipQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEQueueShippingCodeVO.class));

			List<OCEQueueShippingCodeVO> shipDetailsObj = shipQuery.list();


			//Step 3 : fetch queue details from queue_master where id = id in step1

			List<OCEQueueMasterVO> queueList = getQueueMasterRecordsById(queueDetails.getQueueId());

			if (null != queueList ) {
				for(OCEQueueMasterVO vo : queueList) {
					queueDetails.setQueueId(vo.getId());
					queueDetails.setQueueType(vo.getQueueType());
					queueDetails.setQueuePriority(String.valueOf(vo.getPriority()));
					queueDetails.setRepComments(vo.getRepCommnets());
					queueDetailList.add(queueDetails);
				}

			}

			//call select * from oce_queue_linesubstatus where ID = 'Q204'; -- subStatusId

			//call select * from oce_linesubstatus where ID = 'SS100256'; to get queueSubStype

			//set queuesubtype into queuedetails.

			List<OCELineSubstatusVO> lineSubstatusVOs = getSubstatusById(queueDetails.getQueueId());

			if (null != queueList ) {
				/**for debugging purpose */ 
				for(OCELineSubstatusVO vo : lineSubstatusVOs) {
					logger.debug("getSubStatusId ==> "+vo.getQueueSubType());

					if (null != vo.getQueueSubType()) {
						queueDetails.setQueueSubType(vo.getQueueSubType());
						break;
					}
				}

			}

		} catch(HibernateException hbe) {
			//TODO: DON't Eat exceptions, translate to dat access exception and throw to the caller 
			throw new OCEException("QueueServiceImpl.java getQueueDetails() :: ", hbe);
		} finally {
			if (session.isOpen()) {
				session.close();
			}
		}

		return queueDetails;
	}

	

	@SuppressWarnings("unchecked")
	public List<OCEQueueMasterVO> getQueueMasterRecordsById(String queueId) throws OCEException{

		Session session = null;
		List<OCEQueueMasterVO> queueList = new ArrayList<OCEQueueMasterVO>();

		try {

			session = queueSessionFactory.openSession();


			Query selectQuery = session.createQuery(QUERY_FETCH_ALL_QUEUE_MASTER_DETAIL_BY_ID);
			selectQuery.setParameter("queueId", queueId);
			selectQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEQueueMasterVO.class));

			//Enabling Caching
			selectQuery.setCacheable(true);

			queueList = selectQuery.list();

		} catch(HibernateException hbe) {

			//Need to implement logger for temporary using sysout
			throw new OCEException("QueueServiceImpl.java getQueueMasterRecordsById() :: ", hbe);
			//TODO: NEVER EAT AN EXCEPTION.
			//TODO:// log and throw exception back to client. The client to translate this into a meaningful message.
		} finally {

			if (session != null && session.isOpen()) {
				session.close();
			}
		}

		return queueList;
	}


	@SuppressWarnings("unchecked")
	public List<OCELineSubstatusVO> getSubstatusById(String queueId) throws OCEException {

		Session session = null;
		List<OCELineSubstatusVO> subStatusListList = new ArrayList<OCELineSubstatusVO>();

		try {
			session = queueSessionFactory.openSession();


			Query selectQuery = session.createQuery(QUERY_FETCH_SUBSTATUS_BY_ID);
			selectQuery.setParameter("queueId", queueId);
			selectQuery.setResultTransformer(new AliasToBeanResultTransformer(OCELineSubstatusVO.class));

			//Enabling Caching
			selectQuery.setCacheable(true);

			subStatusListList = selectQuery.list();

		} catch(HibernateException hbe) {

			//Need to implement logger for temporary using sysout
			throw new OCEException("QueueServiceImpl.java getSubstatusById() :: ", hbe);
			//TODO: NEVER EAT AN EXCEPTION.
			//TODO:// log and throw exception back to client. The client to translate this into a meaningful message.
		} finally {

			if (session != null && session.isOpen()) {
				session.close();
			}
		}

		
		return subStatusListList;
	}

	
	@SuppressWarnings("unchecked")
	public List<OCEQueueActionTypeVO> getQueueActionTypeDetailsById(String queueId) throws OCEException{

		Session session = null;
		List<OCEQueueActionTypeVO> oceActionTypeDetailsList = new ArrayList<OCEQueueActionTypeVO>();

		try {
			session = queueSessionFactory.openSession();

			Query selectQuery = session.createQuery(QUERY_FETCH_ACTION_TYPE_BY_ID);
			selectQuery.setParameter("queueId", queueId);
			selectQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEQueueActionTypeVO.class));

			//Enabling Caching
			selectQuery.setCacheable(true);

			oceActionTypeDetailsList = selectQuery.list();

		} catch(HibernateException hbe) {

			//Need to implement logger for temporary using sysout
			throw new OCEException("QueueServiceImpl.java getQueueActionTypeDetailsById() :: ", hbe);
			//TODO: NEVER EAT AN EXCEPTION.
			//TODO:// log and throw exception back to client. The client to translate this into a meaningful message.
		} finally {

			if (session != null && session.isOpen()) {
				session.close();
			}
		}

		return oceActionTypeDetailsList;
	}


	@SuppressWarnings("unchecked")
	public List<OCEActionTypeVO> getAllOceActionTypeDetails() throws OCEException{

		Session session = null;
		List<OCEActionTypeVO>  oceActionTypeDetailsList= new ArrayList<OCEActionTypeVO>();

		try {
			session = queueSessionFactory.openSession();


			Query selectQuery = session.createQuery(QUERY_FETCH_ALL_ACTION_TYPE_DETAIL);
			selectQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEActionTypeVO.class));

			//Enabling Caching
			selectQuery.setCacheable(true);

			oceActionTypeDetailsList = selectQuery.list();

		} catch(HibernateException hbe) {

			//Need to implement logger for temporary using sysout
			throw new OCEException("QueueServiceImpl.java getAllOceActionTypeDetails() :: ", hbe);
			//TODO: NEVER EAT AN EXCEPTION.
			//TODO:// log and throw exception back to client. The client to translate this into a meaningful message.
		} finally {

			if (session != null && session.isOpen()) {
				session.close();
			}
		}

		return oceActionTypeDetailsList;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<OCEQueueLineSubstatusVO> getAllOceQueueLineSubstatus(String id) throws OCEException{

		Session session = null;
		List<OCEQueueLineSubstatusVO>  oceQueueLineSubstatusList= new ArrayList<OCEQueueLineSubstatusVO>();

		try {
			session = queueSessionFactory.openSession();


			Query selectQuery = session.createQuery(QUERY_FETCH_ALL_OCE_QUEUE_LINE_SUBSTATUS);
			selectQuery.setParameter("id", id);
			selectQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEQueueLineSubstatusVO.class));

			//Enabling Caching
			selectQuery.setCacheable(true);

			oceQueueLineSubstatusList = selectQuery.list();

		} catch(HibernateException hbe) {
			throw new OCEException("QueueServiceImpl.java getAllOceQueueLineSubstatus() :: ", hbe);
			//Need to implement logger for temporary using sysout
			//TODO: NEVER EAT AN EXCEPTION.
			//TODO:// log and throw exception back to client. The client to translate this into a meaningful message.
			//throw new OCEException(hbe.getMessage(), hbe);
		} finally {

			if (session != null && session.isOpen()) {
				session.close();
			}
		}

		return oceQueueLineSubstatusList;
	}
	

	
	//below are all 2nd level related method...use according to your requirement... Amans code

	/* (non-Javadoc)
	 * @see com.att.oce.service.queue.QueueService#getOCELineSubstatusData()
	 */
	@SuppressWarnings("unchecked")
	public void getOCELineSubstatusData() {

		//Session session = queueSessionFactory.openSession();
		//queueSessionFactory.close();
		Session session = queueSessionFactory.openSession();


		System.out.println("Temp Dir:"+System.getProperty("java.io.tmpdir"));

		Statistics stats = queueSessionFactory.getStatistics();
		System.out.println("Stats enabled="+stats.isStatisticsEnabled());
		stats.setStatisticsEnabled(true);
		System.out.println("Stats enabled="+stats.isStatisticsEnabled());
		String fetchAllTasksQuery=null;
		Iterator it=null;
		printStats(stats, 0);


		try {
			//queueSessionFactory.isClosed();
			fetchAllTasksQuery = "from OCELineSubstatus";
			logger.info("Task in progress in fetchAllTasks()::");
			Query query = session.createQuery(fetchAllTasksQuery);
			//query.setResultTransformer(new AliasToBeanResultTransformer(TaskDetailsVO.class));
			query.setFirstResult(5);
			query.setMaxResults(10);
			query.setCacheable(true);
			List<Object> list = query.list();
			list.size();

			printStats(stats, 0);

		} catch (Exception he) {
			logger.error(he.getMessage());
		} finally {
			session.close();
		}

		Session session1 = queueSessionFactory.openSession();
		fetchAllTasksQuery = "from OCELineSubstatus";
		logger.info("Task in progress in fetchAllTasks()::");
		Query query = session1.createQuery(fetchAllTasksQuery);
		//query.setResultTransformer(new AliasToBeanResultTransformer(TaskDetailsVO.class));
		query.setFirstResult(5);
		query.setMaxResults(10);
		query.setCacheable(true);
		List<Object> list = query.list();
		list.size();
		printStats(stats, 1);

		// TODO Auto-generated method stub
		getOceProgramMasterData();
	}

	@SuppressWarnings("unchecked")
	private void getOceProgramMasterData() {
		Session session = queueSessionFactory.openSession();
		try {
			Query query = session.createQuery("from OCEProgramMaster where programName = 'DF'");
			query.setCacheable(true);
			List<Object> list = query.list();
			list.size();
			//OcePogramMaster record = (OcePogramMaster)session.load(OcePogramMaster.class, 123);
			//System.out.println("program id : " +record.getProgramId());


		} catch (Exception he) {
			logger.error(he.getMessage());
		} finally {
			session.close();
		}

		Session session1 = queueSessionFactory.openSession();
		Query query = session1.createQuery("from OCEProgramMaster where programName = 'DF'");
		query.setCacheable(true);
		List<Object> list = query.list();
		list.size();

		getOceQueueMasterData();
		//getOceQueueProgramSlaData();
	}

	private void getOceQueueMasterData() {
		Session session = queueSessionFactory.openSession();
		try {
			OCEQueueMaster record = (OCEQueueMaster)session.load(OCEQueueMaster.class, "Q203");
			System.out.println("queueDescription : " +record.getQueueDescription());


		} catch (Exception he) {
			logger.error(he.getMessage());
		} finally {
			session.close();
		}

		Session session1 = queueSessionFactory.openSession();
		OCEQueueMaster record = (OCEQueueMaster)session1.load(OCEQueueMaster.class, "Q203");
		System.out.println("queueDescription : " +record.getQueueDescription());

		getOceQueueProgramSlaData();
	}

	private void getOceQueueProgramSlaData() {
		Session session = queueSessionFactory.openSession();
		try {
			Criteria criteria = session.createCriteria(OceQueueProgramSla.class);
			criteria.add(Restrictions.eq("queueSlaId", "M110006"));
			criteria.setCacheable(true);
			OceQueueProgramSla aa = (OceQueueProgramSla)criteria.uniqueResult();
			System.out.println("program name : " +aa.getProgramName());


		} catch (Exception he) {
			logger.error(he.getMessage());
		} finally {
			session.close();
		}

		Session session1 = queueSessionFactory.openSession();
		Criteria criteria = session1.createCriteria(OceQueueProgramSla.class);
		criteria.add(Restrictions.eq("queueSlaId", "M110006"));
		criteria.setCacheable(true);
		OceQueueProgramSla aa = (OceQueueProgramSla)criteria.uniqueResult();
		System.out.println("program name : " +aa.getProgramName());

		getOceQueueProgramSlaDtlsData();

	}

	private void getOceQueueProgramSlaDtlsData() {
		Session session = queueSessionFactory.openSession();
		try {
			OceQueueProgramSlaDtls record = (OceQueueProgramSlaDtls)session.load(OceQueueProgramSlaDtls.class, "QCDEHS67");
			System.out.println("queueSlaId : " +record.getQueueSlaId());


		} catch (Exception he) {
			logger.error(he.getMessage());
		} finally {
			session.close();
		}

		Session session1 = queueSessionFactory.openSession();
		OceQueueProgramSlaDtls record = (OceQueueProgramSlaDtls)session1.load(OceQueueProgramSlaDtls.class, "QCDEHS67");
		System.out.println("queueSlaId : " +record.getQueueSlaId());

	}
	

	/**
	 * This needs to move to appropriate class
	 * @param programName
	 */
	@SuppressWarnings("unchecked")
	public List<OceQueueProgramSlaVO> getSLADetails(String programName, String queueType, String channel) {


		Session session = queueSessionFactory.openSession(); 
		session = queueSessionFactory.openSession();

		List<OceQueueProgramSlaVO> slaQueryList = null;

		try {

			String queryString4 = " SELECT DISTINCT(QSL.queueSlaId) as queueSlaId, QSL.slaGreenMin as slaGreenMin, QSL.slaGreenMax as slaGreenMax, "
					+ " QSL.slaRedMin as slaRedMin, QSL.slaRedMax as slaRedMax, QSL.slaAmberMin as slaAmberMin, "
					+ " QSL.slaAmberMax as slaAmberMax "
					+ " FROM "
					+ " OceQueueProgramSla QSL, "
					+ " OCEQueueMaster QM, "
					+ " OCEProgramMaster PM, "
					+ " OceQueueProgramSlaDtls QSD, "
					+ " OCEQueueDetails ODD "
					+ " WHERE "
					+ " ODD.mQueueType =:queueType "
					+ " AND QM.channel=:channel "
					+ " AND ODD.mProgram =:programName "
					+ " AND QM.id = QSD.id AND QSD.queueSlaId = QSL.queueSlaId AND ODD.mQueueType = QM.queueType "
					+ " AND (QSL.programName = ODD.mQueueCategory OR QSL.programName ='DEFAULT') ";



			Query slaQuery = session.createQuery(queryString4);
			slaQuery.setParameter("queueType", queueType);
			slaQuery.setParameter("channel", channel);
			slaQuery.setParameter("programName", programName);

			//Enabling Caching
			slaQuery.setCacheable(true);

			slaQuery.setResultTransformer(new AliasToBeanResultTransformer(OceQueueProgramSlaVO.class));

			slaQueryList = slaQuery.list();

		} catch(HibernateException hbe) {
			hbe.printStackTrace();
			//throw new OCEException("QueueServiceImpl.java getSLADetails() :: ", hbe);
		} finally {
			if (session.isOpen()) {
				session.close();
			}
		}
		return slaQueryList;
	}



	private static void printStats(Statistics stats, int i) {
		System.out.println("***** " + i + " *****");
		System.out.println("Fetch Count="
				+ stats.getEntityFetchCount());
		System.out.println("Second Level Hit Count="
				+ stats.getSecondLevelCacheHitCount());
		System.out
		.println("Second Level Miss Count="
				+ stats
				.getSecondLevelCacheMissCount());
		System.out.println("Second Level Put Count="
				+ stats.getSecondLevelCachePutCount());
	}

	/**
	 * @return
	 */
	public SessionFactory getqueueSessionFactory() {
		return queueSessionFactory;
	}

	/**
	 * @param queueSessionFactory
	 */
	public void setqueueSessionFactory(SessionFactory queueSessionFactory) {
		this.queueSessionFactory = queueSessionFactory;
	}

}