package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEQueueShippingCode.java - hibernate Annotated Class 
 * for OCE_QUEUE_SHIPPING_CODE table containing Primary key
 */

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEQueueShippingCode.
 */
@Entity
@Table(name="OCE_QUEUE_SHIPPING_CODE")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEQueueShippingCode")
public class OCEQueueShippingCode {

	/** The oce queue shipping code_ pk. */
	@EmbeddedId
	private OCEQueueShippingCode_PK oceQueueShippingCode_PK;
	
	/** The ship code id. */
	@Column(name="SHIPCODE_ID")
	private String shipCodeId;
	
	
	/**
	 * Instantiates a new OCE queue shipping code.
	 */
	public OCEQueueShippingCode(){
		
	}


	/**
	 * Gets the oce queue shipping code_ pk.
	 *
	 * @return the oceQueueShippingCode_PK
	 */
	public OCEQueueShippingCode_PK getOceQueueShippingCode_PK() {
		return oceQueueShippingCode_PK;
	}


	/**
	 * Sets the oce queue shipping code_ pk.
	 *
	 * @param oceQueueShippingCode_PK the oceQueueShippingCode_PK to set
	 */
	public void setOceQueueShippingCode_PK(
			OCEQueueShippingCode_PK oceQueueShippingCode_PK) {
		this.oceQueueShippingCode_PK = oceQueueShippingCode_PK;
	}


	/**
	 * Gets the ship code id.
	 *
	 * @return the shipCodeId
	 */
	public String getShipCodeId() {
		return shipCodeId;
	}


	/**
	 * Sets the ship code id.
	 *
	 * @param shipCodeId the shipCodeId to set
	 */
	public void setShipCodeId(String shipCodeId) {
		this.shipCodeId = shipCodeId;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueueShippingCode [oceQueueShippingCode_PK="
				+ oceQueueShippingCode_PK + ", shipCodeId=" + shipCodeId + "]";
	}

}
