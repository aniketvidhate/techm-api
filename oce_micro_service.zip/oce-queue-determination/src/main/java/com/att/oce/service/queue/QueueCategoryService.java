package com.att.oce.service.queue;

import com.att.oce.service.queue.vo.OCEQueueDeterminationRequest;

public interface QueueCategoryService {
	
	public String getQueueCatagory(String queueType, OCEQueueDeterminationRequest request, boolean nonUnifyWireless);

}
