package com.att.oce.service.queue.vo;

/**
 * @author AV00419874
 * OCEGroupCharacteristics.java - hibernate Annotated Class 
 * for OCE_GROUP_CHARACTERISTICS table
 */

import java.util.Date;

public class OCEGroupCharacteristicsVO {

	private String orderGroupCharacteristics;
	
	private String groupCharacteristicsType;
	
	private String losgReferenceId;
	
	private String losgType;
	
	private String productCatagory;
	
	private String dealerCode;
	
	private String market;
	
	private String subMarket;
	
	private String preferredAreaCode;
	
	private String serviceArea;
	
	private String serviceAreaName;
	
	private String priceCode;
	
	private String customerAccountRef;
	
	private Date requestedExecutionDate;
	
	private Date effectiveDate;
	
	private String status;
	
	private String subStatus;
	
	private String operation;
	
	private String exitCode;
	
	private String description;
	
	private String serviceLocationRef;
	private String fulfillmentMethod;
	private String preOrder;
	
	
	
	/*"SERVICE_QUALIFICATION_REF" VARCHAR2(255 BYTE), 
	"CONFLICTING_SERVICE_INFO_REFS" VARCHAR2(255 BYTE), 
	"PROFILE_CODE" VARCHAR2(255 BYTE), 
	"SCHEDULING_INFO_REF" VARCHAR2(255 BYTE), 
	"INSTALLATION_INSTRUCTIONS" VARCHAR2(255 BYTE), 
	"INSTALL_TYPE" VARCHAR2(255 BYTE), 
	"NOTES" VARCHAR2(255 BYTE), 
	"ADDITIONAL_DETAILS" VARCHAR2(255 BYTE), 
	"NUMBER_PORTINFO" VARCHAR2(255 BYTE), 
	"ACCEPTED" VARCHAR2(255 BYTE), 
	"TIMESTAMP" TIMESTAMP (6), 
	"VERSION" VARCHAR2(500 BYTE), 
	"DEVICE_INSTALL_AGREEMENT_TYPE" VARCHAR2(255 BYTE), 
	"ECONSENT_AGREEMENT_TYPE" VARCHAR2(255 BYTE), 
	"IS_PRIMARY" NUMBER, 
	"FOLLOWUP_DATE" TIMESTAMP (6), 
	"MOBILE_NUMBER" VARCHAR2(255 BYTE), 
	"ACCOUNT_CONVERSION_STATUS" VARCHAR2(255 BYTE), 
	"UPGRADE_TYPE" VARCHAR2(255 BYTE), 
	"IS_PRIMARY_SHARED_PLAN" VARCHAR2(255 BYTE), 
	"IS_SHIPPED_HOT" VARCHAR2(255 BYTE), 
	"SUBSCRIBER_CROSS_INDICATOR" VARCHAR2(255 BYTE), 
	"LNP_INFO" VARCHAR2(255 BYTE), 
	"UPGRADE_QUALIFICATION_INFO" VARCHAR2(255 BYTE), 
	"AVAILABILITY_DATE" TIMESTAMP (6), 
	"E911INFOREF" VARCHAR2(255 BYTE), 
	"VOIPPORTINFO" VARCHAR2(255 BYTE), 
	"DATA_GROUP_ID" VARCHAR2(40 BYTE), 
	"GROUP_REFERENCE_CODE" VARCHAR2(255 BYTE), 
	"IPDSLA_INDICATOR" VARCHAR2(255 BYTE), 
	"SERVICE_AGREEMENT" VARCHAR2(255 BYTE), 
	"OFFER_LANGUAGE" VARCHAR2(255 BYTE), 
	"CATEGORY" VARCHAR2(255 BYTE), 
	"CODE" VARCHAR2(255 BYTE), 
	"PACKAGE_DESCRIPTION" VARCHAR2(255 BYTE), 
	"PRIORITY_NETWORK_TYPE" VARCHAR2(255 BYTE), 
	"BILLING_SYSTEM_ID" VARCHAR2(40 BYTE), 
	"DEALER_ID" VARCHAR2(40 BYTE), 
	"MARKETING_SOURCE_CODE" VARCHAR2(255 BYTE), 
	"MOVE_IN_ORDER" VARCHAR2(255 BYTE), 
	"PROVISIONING_ORDER_REF" VARCHAR2(255 BYTE), 
	"RESERVED_TELEPHONE_NUMBER" VARCHAR2(255 BYTE), 
	"SUBSCRIBER_STATUS" VARCHAR2(255 BYTE), 
	"DEPOSIT_STATUS" VARCHAR2(255 BYTE), 
	"YODA_ACTIVATED" NUMBER, 
	"AS_SUCCESS_FLAG" NUMBER, 
	"COMPENSATION_REP_ID" VARCHAR2(255 BYTE), 
	"COMPENSATION_REP_ACTION" VARCHAR2(255 BYTE), 
	"COMPENSATION_REP_TYPE" VARCHAR2(255 BYTE), 
	"COMPENSATION_DEALER_CODE" VARCHAR2(255 BYTE), 
	"INVOKE_AWPAPI" NUMBER, 
	"COMPENSATION_SUBMITTED_BY" VARCHAR2(255 BYTE), 
	"CROSS_UPGRADE" NUMBER, 
	"UPGRADE_INFO" VARCHAR2(255 BYTE), 
	"IS_QUALIFIED_FOR_AUTOMATION" NUMBER(1,0), 
	"PLAN_TYPE" VARCHAR2(1024 BYTE), 
	"AUTOMATION_SUCCESS" NUMBER(1,0), 
	"CALCULATETAXINDICATOR" NUMBER, 
	"INVENTORYSTORE_ID" VARCHAR2(255 BYTE), 
	"PAYMENT_ID" VARCHAR2(255 BYTE), 
	"ACTIVATION_DATE" TIMESTAMP (6), 
	"FAMILY_GROUP_ID" VARCHAR2(255 BYTE), 
	"LOSG_SEQ_NUMBER" NUMBER, 
	"ACCOUNT_REF" VARCHAR2(40 BYTE), 
	"SUBSCRIBER_NAMEREF" VARCHAR2(40 BYTE), 
	"STORE_ID" VARCHAR2(255 BYTE), 
	"SHIPPING_INFO_REF" VARCHAR2(255 BYTE), 
	"COPAY_DATA" VARCHAR2(40 BYTE), 
	"SPLIT_LIABILITY" VARCHAR2(40 BYTE), 
	"SHOPPING_ZIPCODE" VARCHAR2(40 BYTE), 
	"SN_RELEASED" NUMBER(1,0), 
	"AUTOMATION_ENABLED" NUMBER(1,0), 
	"PRIMARY_SUBSCRIBER_NUMBER" VARCHAR2(40 BYTE), 
	"PENDING_DATE" TIMESTAMP (6), 
	"CHILD_ORDER_ID" VARCHAR2(40 BYTE), 
	"TOLL_FREE_NUMBER" VARCHAR2(255 BYTE) DEFAULT '866-267-4510', 
	"ACTION_TYPE" VARCHAR2(240 BYTE), 
	"ACTION_REASON" VARCHAR2(240 BYTE), 
	"NEW_MOBILE_NUMBER" VARCHAR2(255 BYTE), 
	"IS_CONNECTEDCAR" NUMBER(1,0), 
	"MOBILENUMBER_CC" VARCHAR2(255 BYTE), 
	"VIN" VARCHAR2(255 BYTE), 
	"VEHICLE_MANUFACTURER" VARCHAR2(255 BYTE), 
	"SUBSCRIPTION_CLASS" VARCHAR2(255 BYTE), 
	"MAKE" VARCHAR2(255 BYTE), 
	"MODEL" VARCHAR2(255 BYTE), 
	"TRIM" VARCHAR2(255 BYTE), 
	"YEAR" VARCHAR2(255 BYTE), 
	"LOSG_STATUS_CHANGE_DATE" TIMESTAMP (6), 
	"CREDIT_POLICY_SECURITY_TYPE" VARCHAR2(255 BYTE), 
	"PACKAGE_TYPE" VARCHAR2(255 BYTE), 
	"DWELLING_TYPE"*/
	
	
	
	public OCEGroupCharacteristicsVO(){
		
	}



	/**
	 * @return the orderGroupCharacteristics
	 */
	public String getOrderGroupCharacteristics() {
		return orderGroupCharacteristics;
	}



	/**
	 * @param orderGroupCharacteristics the orderGroupCharacteristics to set
	 */
	public void setOrderGroupCharacteristics(String orderGroupCharacteristics) {
		this.orderGroupCharacteristics = orderGroupCharacteristics;
	}



	/**
	 * @return the groupCharacteristicsType
	 */
	public String getGroupCharacteristicsType() {
		return groupCharacteristicsType;
	}



	/**
	 * @param groupCharacteristicsType the groupCharacteristicsType to set
	 */
	public void setGroupCharacteristicsType(String groupCharacteristicsType) {
		this.groupCharacteristicsType = groupCharacteristicsType;
	}



	/**
	 * @return the losgReferenceId
	 */
	public String getLosgReferenceId() {
		return losgReferenceId;
	}



	/**
	 * @param losgReferenceId the losgReferenceId to set
	 */
	public void setLosgReferenceId(String losgReferenceId) {
		this.losgReferenceId = losgReferenceId;
	}



	/**
	 * @return the losgType
	 */
	public String getLosgType() {
		return losgType;
	}



	/**
	 * @param losgType the losgType to set
	 */
	public void setLosgType(String losgType) {
		this.losgType = losgType;
	}



	/**
	 * @return the productCatagory
	 */
	public String getProductCatagory() {
		return productCatagory;
	}



	/**
	 * @param productCatagory the productCatagory to set
	 */
	public void setProductCatagory(String productCatagory) {
		this.productCatagory = productCatagory;
	}



	/**
	 * @return the dealerCode
	 */
	public String getDealerCode() {
		return dealerCode;
	}



	/**
	 * @param dealerCode the dealerCode to set
	 */
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}



	/**
	 * @return the market
	 */
	public String getMarket() {
		return market;
	}



	/**
	 * @param market the market to set
	 */
	public void setMarket(String market) {
		this.market = market;
	}



	/**
	 * @return the subMarket
	 */
	public String getSubMarket() {
		return subMarket;
	}



	/**
	 * @param subMarket the subMarket to set
	 */
	public void setSubMarket(String subMarket) {
		this.subMarket = subMarket;
	}



	/**
	 * @return the preferredAreaCode
	 */
	public String getPreferredAreaCode() {
		return preferredAreaCode;
	}



	/**
	 * @param preferredAreaCode the preferredAreaCode to set
	 */
	public void setPreferredAreaCode(String preferredAreaCode) {
		this.preferredAreaCode = preferredAreaCode;
	}



	/**
	 * @return the serviceArea
	 */
	public String getServiceArea() {
		return serviceArea;
	}



	/**
	 * @param serviceArea the serviceArea to set
	 */
	public void setServiceArea(String serviceArea) {
		this.serviceArea = serviceArea;
	}



	/**
	 * @return the serviceAreaName
	 */
	public String getServiceAreaName() {
		return serviceAreaName;
	}



	/**
	 * @param serviceAreaName the serviceAreaName to set
	 */
	public void setServiceAreaName(String serviceAreaName) {
		this.serviceAreaName = serviceAreaName;
	}



	/**
	 * @return the priceCode
	 */
	public String getPriceCode() {
		return priceCode;
	}



	/**
	 * @param priceCode the priceCode to set
	 */
	public void setPriceCode(String priceCode) {
		this.priceCode = priceCode;
	}



	/**
	 * @return the customerAccountRef
	 */
	public String getCustomerAccountRef() {
		return customerAccountRef;
	}



	/**
	 * @param customerAccountRef the customerAccountRef to set
	 */
	public void setCustomerAccountRef(String customerAccountRef) {
		this.customerAccountRef = customerAccountRef;
	}



	/**
	 * @return the requestedExecutionDate
	 */
	public Date getRequestedExecutionDate() {
		return requestedExecutionDate;
	}



	/**
	 * @param requestedExecutionDate the requestedExecutionDate to set
	 */
	public void setRequestedExecutionDate(Date requestedExecutionDate) {
		this.requestedExecutionDate = requestedExecutionDate;
	}



	/**
	 * @return the effectiveDate
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}



	/**
	 * @param effectiveDate the effectiveDate to set
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}



	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}



	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}



	/**
	 * @return the subStatus
	 */
	public String getSubStatus() {
		return subStatus;
	}



	/**
	 * @param subStatus the subStatus to set
	 */
	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}



	/**
	 * @return the operation
	 */
	public String getOperation() {
		return operation;
	}



	/**
	 * @param operation the operation to set
	 */
	public void setOperation(String operation) {
		this.operation = operation;
	}



	/**
	 * @return the exitCode
	 */
	public String getExitCode() {
		return exitCode;
	}



	/**
	 * @param exitCode the exitCode to set
	 */
	public void setExitCode(String exitCode) {
		this.exitCode = exitCode;
	}



	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}



	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}



	/**
	 * @return the serviceLocationRef
	 */
	public String getServiceLocationRef() {
		return serviceLocationRef;
	}



	/**
	 * @param serviceLocationRef the serviceLocationRef to set
	 */
	public void setServiceLocationRef(String serviceLocationRef) {
		this.serviceLocationRef = serviceLocationRef;
	}



	/**
	 * @return the fulfillmentMethod
	 */
	public String getFulfillmentMethod() {
		return fulfillmentMethod;
	}



	/**
	 * @param fulfillmentMethod the fulfillmentMethod to set
	 */
	public void setFulfillmentMethod(String fulfillmentMethod) {
		this.fulfillmentMethod = fulfillmentMethod;
	}



	/**
	 * @return the preOrder
	 */
	public String getPreOrder() {
		return preOrder;
	}



	/**
	 * @param preOrder the preOrder to set
	 */
	public void setPreOrder(String preOrder) {
		this.preOrder = preOrder;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEGroupCharacteristicsVO [orderGroupCharacteristics="
				+ orderGroupCharacteristics + ", groupCharacteristicsType="
				+ groupCharacteristicsType + ", losgReferenceId="
				+ losgReferenceId + ", losgType=" + losgType
				+ ", productCatagory=" + productCatagory + ", dealerCode="
				+ dealerCode + ", market=" + market + ", subMarket="
				+ subMarket + ", preferredAreaCode=" + preferredAreaCode
				+ ", serviceArea=" + serviceArea + ", serviceAreaName="
				+ serviceAreaName + ", priceCode=" + priceCode
				+ ", customerAccountRef=" + customerAccountRef
				+ ", requestedExecutionDate=" + requestedExecutionDate
				+ ", effectiveDate=" + effectiveDate + ", status=" + status
				+ ", subStatus=" + subStatus + ", operation=" + operation
				+ ", exitCode=" + exitCode + ", description=" + description
				+ ", serviceLocationRef=" + serviceLocationRef
				+ ", fulfillmentMethod=" + fulfillmentMethod + ", preOrder="
				+ preOrder + "]";
	}


	



}
