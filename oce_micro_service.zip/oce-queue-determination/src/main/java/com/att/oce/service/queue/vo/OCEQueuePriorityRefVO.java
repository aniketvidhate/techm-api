package com.att.oce.service.queue.vo;

/**
 * The Class OCEQueuePriorityRefVO.
 *
 * @author AV00419874
 */

public class OCEQueuePriorityRefVO {

	/** The id. */
	private String id;
	
	/** The sequence. */
	private String sequence;
	
	/** The queue priority criteria id. */
	private String queuePriorityCriteriaId;
	
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public String getSequence() {
		return sequence;
	}


	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}


	/**
	 * Gets the queue priority criteria id.
	 *
	 * @return the queuePriorityCriteriaId
	 */
	public String getQueuePriorityCriteriaId() {
		return queuePriorityCriteriaId;
	}


	/**
	 * Sets the queue priority criteria id.
	 *
	 * @param queuePriorityCriteriaId the queuePriorityCriteriaId to set
	 */
	public void setQueuePriorityCriteriaId(String queuePriorityCriteriaId) {
		this.queuePriorityCriteriaId = queuePriorityCriteriaId;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueuePriorityRefVO [id=" + id + ", sequence=" + sequence
				+ ", queuePriorityCriteriaId=" + queuePriorityCriteriaId + "]";
	}
	
	

}
