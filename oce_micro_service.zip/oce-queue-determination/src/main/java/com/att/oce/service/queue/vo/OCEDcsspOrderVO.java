package com.att.oce.service.queue.vo;

/**
 * @author AV00419874
 */


/**
 * The Class OCEDcsspOrderVO.
 */
public class OCEDcsspOrderVO {

	/** The order id. */
	private String orderId;
	
	/** The conversation id. */
	private String conversationId;
	
	
	/**
	 * Instantiates a new OCE dcssp order vo.
	 */
	public OCEDcsspOrderVO(){
		
	}

	/**
	 * Gets the order id.
	 *
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * Sets the order id.
	 *
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * Gets the conversation id.
	 *
	 * @return the conversationId
	 */
	public String getConversationId() {
		return conversationId;
	}

	/**
	 * Sets the conversation id.
	 *
	 * @param conversationId the conversationId to set
	 */
	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEDcsspOrderVO [orderId=" + orderId + ", conversationId="
				+ conversationId + "]";
	}

	
}
