package com.att.oce.service.queue.vo;

/**
 * The Class OCESchedulingInfoListVO.
 *
 * @author AV00419874
 */


/**
 * The Class OCEActionType.
 */
public class OCESchedulingInfoListVO {

	/** The schedulingInfoid. */
	private String schedulingInfoid;
	
	/** The id. */
	private String id;
	
	/** The actual schedule. */
	private String actualSchedule;
	
	/** The confirm schedule. */
	private String confirmSchedule;
	/**
	 * Instantiates a new OCE action type.
	 */
	public OCESchedulingInfoListVO(){
		
	}
	
	/**
	 * Gets the schedulingInfoid.
	 *
	 * @return the schedulingInfoid
	 */
	public String getSchedulingInfoid() {
		return schedulingInfoid;
	}
	
	/**
	 * Sets the schedulingid.
	 *
	 * @param schedulingid the schedulingid to set
	 */
	public void setSchedulingInfoid(String schedulingInfoid) {
		this.schedulingInfoid = schedulingInfoid;
	}
	
	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Gets the actual schedule.
	 *
	 * @return the actualSchedule
	 */
	public String getActualSchedule() {
		return actualSchedule;
	}
	
	/**
	 * Sets the actual schedule.
	 *
	 * @param actualSchedule the actualSchedule to set
	 */
	public void setActualSchedule(String actualSchedule) {
		this.actualSchedule = actualSchedule;
	}
	
	/**
	 * Gets the confirm schedule.
	 *
	 * @return the confirmSchedule
	 */
	public String getConfirmSchedule() {
		return confirmSchedule;
	}
	
	/**
	 * Sets the confirm schedule.
	 *
	 * @param confirmSchedule the confirmSchedule to set
	 */
	public void setConfirmSchedule(String confirmSchedule) {
		this.confirmSchedule = confirmSchedule;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCESchedulingInfoListVO [schedulingInfoid=" + schedulingInfoid + ", id="
				+ id + ", actualSchedule=" + actualSchedule
				+ ", confirmSchedule=" + confirmSchedule + "]";
	}


	
}
