package com.att.oce.service.queueImpl;




import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtB2B;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroup;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtLineItem;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtUDL;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StContractType;
import com.att.oce.service.queue.OCEQueueConstants;
import com.att.oce.service.queue.QueuePriorityService;
import com.att.oce.service.queue.vo.OCEQueuePriorityCriteriaVO;
import com.att.oce.service.queue.vo.OCEQueuePriorityDataVO;
import com.att.oce.service.queue.vo.OCEQueuePriorityRefVO;
import com.att.oce.service.queue.vo.sub.OCEOrderInfo;


@Repository
public class QueuePriorityServiceImpl implements QueuePriorityService{

	//@Autowired 
	//OCEQueuePriority oceQueuePriority;

//	@Autowired
//	@Qualifier("queueTemplate")
//	HibernateTemplate hTemplate;

	@Autowired(required = true)
	//@Qualifier("queueSessionFactory")
	SessionFactory queueSessionFactory;

	private Logger logger = LoggerFactory.getLogger(QueuePriorityServiceImpl.class);

	/* (non-Javadoc)
	 * @see com.att.oce.service.queue.QueuePriorityService#getQueuePriorityRefVo(java.lang.String)
	 */
	@Override
	public List<OCEQueuePriorityRefVO> getQueuePrirityDetailsVO(String queueId) {
		Session session = null;
		List<OCEQueuePriorityRefVO> queuePriorityDetailsObj = null;
		try {
			session = queueSessionFactory.openSession();
			String queryString =  "SELECT t.oceQueuePriorityRef_PK.id as id, t.oceQueuePriorityRef_PK.sequence as sequence, "
					+ "t.queuePriorityCriteriaId as queuePriorityCriteriaId FROM OCEQueuePriorityRef t "
					+ " WHERE t.oceQueuePriorityRef_PK.id= :id ORDER BY t.oceQueuePriorityRef_PK.sequence ASC";
			Query queuePriorityQuery = session.createQuery(queryString);
			queuePriorityQuery.setParameter(OCEQueueConstants.ID, queueId);
			//Enabling Caching
			queuePriorityQuery.setCacheable(true);
			queuePriorityQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEQueuePriorityRefVO.class));
			queuePriorityDetailsObj = queuePriorityQuery.list();
			
		} catch(HibernateException hbe) {
			if (logger.isErrorEnabled()) {
				logger.error(hbe.getMessage());
			}
		}
		return queuePriorityDetailsObj;
	}
	Session session = null;
	/* (non-Javadoc)
	 * @see com.att.oce.service.queue.QueuePriorityService#getQueuePriorityDataVo(java.lang.String)
	 */
	@Override
	public List<OCEQueuePriorityDataVO> getQueuePriorityDataVO(
			List<OCEQueuePriorityRefVO> queuePriorityRefVOs) {
		Session session = queueSessionFactory.openSession();
		List<OCEQueuePriorityDataVO> queuePriorityDataObj = null;
		String priorityBit = null;
		List<OCEQueuePriorityRefVO> queuePriorityDetailsObj = null;
		try {
			session = queueSessionFactory.openSession();
			for(OCEQueuePriorityRefVO vo : queuePriorityRefVOs) {
				logger.info("Test1 OCEQueuePriorityRefVO ID ::  " +vo.getId());
				String queryString1 =  " select t.queuePriorityCriteriaId as queuePriorityCriteriaId, t.criteriaData as criteriaData, "
						+ " t.criteriaValue as criteriaValue, t.criteriaRanking as criteriaRanking FROM OCEQueuePriorityData t "
						+ " WHERE t.queuePriorityCriteriaId IN (select t1.queuePriorityCriteriaId from OCEQueuePriorityRef t1 "
						+ " where t1.oceQueuePriorityRef_PK.id= :id)";
				Query queuePriorityDataQuery = session.createQuery(queryString1);
				queuePriorityDataQuery.setParameter(OCEQueueConstants.ID, vo.getId());
				//Enabling Caching
				queuePriorityDataQuery.setCacheable(true);
				queuePriorityDataQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEQueuePriorityDataVO.class));
				queuePriorityDataObj = queuePriorityDataQuery.list();
			}
		} catch (HibernateException hbe) {
			if (logger.isErrorEnabled()) {
				logger.error(hbe.getMessage());
			}
		} finally {
			if (session.isOpen()) {
				session.close();
			}
		}
		return queuePriorityDataObj;
	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.queue.QueuePriorityService#getQueuePriorityCriteriaVo(java.lang.String)
	 */
	/* (non-Javadoc)
	 * @see com.att.oce.service.queue.QueuePriorityService#getQueuePriorityCriteriaVO(java.util.List)
	 */
	List<OCEQueuePriorityCriteriaVO> queuePriorityCriteriaObj = new ArrayList<OCEQueuePriorityCriteriaVO>();
	List<OCEQueuePriorityCriteriaVO> queuePriorityCriteriaList = new ArrayList<OCEQueuePriorityCriteriaVO>();
	List<String> queueCriteriaValueList = null;
	int priority = 1;
	@Override
	public List<OCEQueuePriorityCriteriaVO> getQueuePriorityCriteriaVO(
			List<OCEQueuePriorityDataVO> queuePriorityDateVOs) {
		try {
			session = queueSessionFactory.openSession();		
			for(OCEQueuePriorityDataVO vo1 : queuePriorityDateVOs) {
				System.out.println("Test1 OCEQueuePriorityDataVO getQueuePriorityCriteriaId ::  " +vo1.getQueuePriorityCriteriaId());
				List<String> criteriaValueList = new ArrayList<>();
				String queueCriteriaValue = vo1.getCriteriaValue();
				queueCriteriaValueList = null;
				if(null != queueCriteriaValue) {
					String[] arrQueueCriteriaValue = queueCriteriaValue.split(",");
					queueCriteriaValueList = new ArrayList<String>(Arrays.asList(arrQueueCriteriaValue));
				}
				priority = vo1.getCriteriaRanking();
				String queryString2 =  " select priorityCriteriaName as priorityCriteriaName, priorityCriteriaXpath as priorityCriteriaXpath, "
						+ " priorityCriteriaRerpopath as priorityCriteriaRerpopath FROM OCEQueuePriorityCriteria "
						+ " WHERE priorityCriteriaName IN (:id)";
				Query queuePriorityCriteriaQuery = session.createQuery(queryString2);
				queuePriorityCriteriaQuery.setParameter(OCEQueueConstants.ID, vo1.getCriteriaData());
				//Enabling Caching
				queuePriorityCriteriaQuery.setCacheable(true);
				queuePriorityCriteriaQuery.setResultTransformer(new AliasToBeanResultTransformer(OCEQueuePriorityCriteriaVO.class));
				queuePriorityCriteriaObj=queuePriorityCriteriaQuery.list();
				if (null != queuePriorityCriteriaObj) {
					for (OCEQueuePriorityCriteriaVO criteriaVO : queuePriorityCriteriaObj) {
						if (null != criteriaVO) {
							queuePriorityCriteriaList.add(criteriaVO);
						}
					}
				}
			}
		} catch(HibernateException hbe) {
			if (logger.isErrorEnabled()) {
				logger.error(hbe.getMessage());
			}
		} finally {
			if (session.isOpen()) {
				session.close();
			}
		}
		return queuePriorityCriteriaList;
	}
	
	/* (non-Javadoc)
	 * @see com.att.oce.service.queue.QueuePriorityService#determineQueuePririty(java.util.List)
	 */
	@Override
	public String determineQueuePriority(OCEOrderInfo oceOrderInfo,List<OCEQueuePriorityDataVO> queuePriorityDataVO,
			List<OCEQueuePriorityCriteriaVO> getQueuePriorityCriteriaVO) {
		List<String> criteriaValueList = new ArrayList<>();
		int [] priorityList = new int[6];
		Arrays.fill(priorityList, 0);
		String priorityBit = null;
		List<String> priorityCriteriaName = new ArrayList<String>();
		String criteriaName=null;
		try {
			session = queueSessionFactory.openSession();
			for(OCEQueuePriorityCriteriaVO vo1 : getQueuePriorityCriteriaVO) {
				criteriaName=vo1.getPriorityCriteriaName();
				if(null!=criteriaName)
				{
					priorityCriteriaName.add(criteriaName);
				}
			}
			Map<String, List<String>> priorityCriteriaListMap=getPriorityCriteriaListMap(priorityCriteriaName, oceOrderInfo);
			for(OCEQueuePriorityDataVO vo3 : queuePriorityDataVO) {
				//System.out.println("Test1 OCEQueuePriorityCriteriaVO priorityCriteriaName ::  " +vo3.getPriorityCriteriaName());
				if (null != vo3) {
					String queueCriteriaValue=vo3.getCriteriaValue();
					if(null != queueCriteriaValue) {
						String[] arrQueueCriteriaValue = queueCriteriaValue.split(",");
						queueCriteriaValueList = new ArrayList<String>(Arrays.asList(arrQueueCriteriaValue));
					}
					int priority=vo3.getCriteriaRanking();
					String criteriaData=vo3.getCriteriaData();
					List<String> priorityCriteriaList = new ArrayList<String>();
					priorityCriteriaList=priorityCriteriaListMap.get(criteriaData);
					if (null != priorityCriteriaList && !priorityCriteriaList.contains(null)) {
						// Setting the particular bit
						for (String queueCriteriaValueItem : priorityCriteriaList) {
							if (priorityCriteriaList.contains(queueCriteriaValueItem)) {
								if(priority>0){
								priorityList[priority - 1] = 1;
								}
							}
						}
					}

				}
				StringBuilder priorityBitBldr = new StringBuilder("");
				for(int bitval : priorityList) {
					priorityBitBldr.append(bitval);
				}
				priorityBit = priorityBitBldr.toString();
			}
		} catch(HibernateException hbe ) {
			hbe.getMessage();
		} finally {
			if (session.isOpen()) {
				session.close();
			}
		}
		return priorityBit;
	}
	
/*	*//**
	 * This is a recurssive method which will take priority criteria values
	 * configured for the order from repository according to repo path
	 * 
	 * @param OrderPriorityElement
	 * @param criteriaRepoPathList
	 * @param index
	 * @return criteriaValueList
	 *//*
	private List<String> getQueuePriorityCriteriaOrderValues(
			Object repoPropertySourceProperty, List<String> criteriaRepoPathList, int index) {
		List<String> criteriaValueList = new ArrayList<>();
		if(repoPropertySourceProperty == null)
			return criteriaValueList;
		
		boolean isPropertyList = 
				List.class.isAssignableFrom(repoPropertySourceProperty.getClass());

		
		if(index >= criteriaRepoPathList.size()-1) {



			if(isPropertyList) {
				@SuppressWarnings("unchecked")
				List<Order> repoSourcePropertyList = 
						(List<Order>) repoPropertySourceProperty;
				for(Order orderLevelPropObj : repoSourcePropertyList) {
					Object propertyValueObj = null;//orderLevelPropObj.get(criteriaRepoPathList.get(index));
					criteriaValueList.add(
							(null == propertyValueObj) ? null : (String)propertyValueObj);
				}
			} else {
				Order order =(Order)repoPropertySourceProperty;
				Object propertyValueObj =null;//order.get(criteriaRepoPathList.get(index));
				if(propertyValueObj instanceof String)
				{
				criteriaValueList.add(
						(null == propertyValueObj) ? null : (String)propertyValueObj);
				}
				else
				{
					criteriaValueList.add(
							(null == propertyValueObj) ? null : propertyValueObj.toString());
				}
			}


		} else {			
			String repoPropertyName = criteriaRepoPathList.get(index);
			repoPropertyName = repoPropertyName.replaceAll("[\\[\\]]", "");
			if(isPropertyList) {
				@SuppressWarnings("unchecked")
				List<Order> repoSourcePropertyList = 
						(List<Order>) repoPropertySourceProperty;
				for(Order srcPropRepoItem : repoSourcePropertyList) {
					Object nextSrcPropertyObj = null;//srcPropRepoItem.get(repoPropertyName);
					criteriaValueList.addAll(
							getQueuePriorityCriteriaOrderValues(nextSrcPropertyObj, criteriaRepoPathList, index + 1));
				}			
			} else {
				Order order =(Order)repoPropertySourceProperty;

				Object nextSrcPropertyObj = null;//	order.get(repoPropertyName);
				criteriaValueList.addAll(
				getQueuePriorityCriteriaOrderValues(nextSrcPropertyObj, criteriaRepoPathList, index + 1));
			}
		}
		return criteriaValueList;
	}*/
	
	
	@Override
	public Map<String, List<String>> getPriorityCriteriaListMap(List<String> criteriaList, OCEOrderInfo oceOrderInfo) {
		Session session = null;
		Map<String, List<String>> priorityCriteriaMap = new HashMap<String, List<String>>();
		List<String> fulfillmentMethod = new ArrayList<String>();
		boolean preOrder = false;
		List<String> preOrderList = new ArrayList<String>();
		List<String> fan = new ArrayList<String>();
		List<String> contractTypeList = new ArrayList<String>();
		List<String> itemDetailList = new ArrayList<String>();
		List<String> udlDetailList = new ArrayList<String>();
		
		try {
			session = queueSessionFactory.openSession();
			
				if(criteriaList.contains("FULFILLMENT_METHOD") 
						|| criteriaList.contains("PREORDER")){
					for (CtGroup ctGroup : oceOrderInfo.getGroupList().getGroup()) {
						if (null != ctGroup.getGroupCharacteristics().getLoSGCharacteristics() &&
								null != ctGroup.getGroupCharacteristics().getLoSGCharacteristics().getFulfillmentMethod()) {
							fulfillmentMethod.add(ctGroup.getGroupCharacteristics().getLoSGCharacteristics().getFulfillmentMethod());
						}
						if (null != ctGroup.getGroupCharacteristics().getLoSGCharacteristics() && 
								null != ctGroup.getGroupCharacteristics().getLoSGCharacteristics().getWirelessLOSChars()
								&& null != ctGroup.getGroupCharacteristics().getLoSGCharacteristics().getWirelessLOSChars().isPreOrder()) {
							preOrder = ctGroup.getGroupCharacteristics().getLoSGCharacteristics().getWirelessLOSChars().isPreOrder();
						}
						if (preOrder) {
							preOrderList.add("1");
						} else {
							preOrderList.add("0");
						}
					}
					
				}
				if(criteriaList.contains(OCEQueueConstants.PRE_ORDER)){
					if(null != oceOrderInfo.getCtB2BList()) {
						for (CtB2B b2b : oceOrderInfo.getCtB2BList()) {
							fan.add(b2b.getB2BFAN());
						}
					}
				}
				if(criteriaList.contains(OCEQueueConstants.FAN)){
					//fan.add(oceOrderInfo.getB2bFan());
				}
				if(criteriaList.contains(OCEQueueConstants.CONTRACT_TYPE)){
					if (null != oceOrderInfo.getCtLineItems()) {
						for (CtLineItem ctLineItem : oceOrderInfo.getCtLineItems()) {
							if (null !=ctLineItem.getContractDetails() && null != ctLineItem.getContractDetails().getContractType()) {
								StContractType stContractType = ctLineItem.getContractDetails().getContractType();
								contractTypeList.add(stContractType.name());
							}
						}
					}
				}
				if(criteriaList.contains(OCEQueueConstants.PRODUCT_SKU)){
					if (null != oceOrderInfo.getCtLineItems()) {
						for (CtLineItem ctLineItem : oceOrderInfo.getCtLineItems()) {
							itemDetailList.add(ctLineItem.getProductSku());
						}
					}
				}
				if(criteriaList.contains(OCEQueueConstants.UDL)){
					if (null != oceOrderInfo.getGroupList() 
							&& null != oceOrderInfo.getGroupList().getGroup()
							&& null != oceOrderInfo.getGroupList().getGroup().get(0).getGroupCharacteristics()
							&& null != oceOrderInfo.getGroupList().getGroup().get(0).getGroupCharacteristics().getLoSGCharacteristics()
							&& null != oceOrderInfo.getGroupList().getGroup().get(0).getGroupCharacteristics().getLoSGCharacteristics().getUDLs()
							&& null != oceOrderInfo.getGroupList().getGroup().get(0).getGroupCharacteristics().getLoSGCharacteristics().getUDLs().getUDL()){
						for (CtUDL ctUDL : oceOrderInfo.getGroupList().getGroup().get(0).getGroupCharacteristics().getLoSGCharacteristics().getUDLs().getUDL()) {
							if (null != ctUDL) {
								udlDetailList.add(ctUDL.getValue());
							}
						}
					}
				}
			priorityCriteriaMap.put(OCEQueueConstants.FULFILLMENT_METHOD, fulfillmentMethod);
			priorityCriteriaMap.put(OCEQueueConstants.PRE_ORDER, preOrderList);
			priorityCriteriaMap.put(OCEQueueConstants.FAN, fan);
			priorityCriteriaMap.put(OCEQueueConstants.CONTRACT_TYPE, contractTypeList);
			priorityCriteriaMap.put(OCEQueueConstants.PRODUCT_SKU, itemDetailList);
			priorityCriteriaMap.put(OCEQueueConstants.UDL, udlDetailList);
		} catch(HibernateException hbe) {
			if (logger.isErrorEnabled()) {
				logger.error(hbe.getMessage());
			}
		} finally {
			if (session.isOpen()) {
				session.close();
			}
		}
		return priorityCriteriaMap;
	}
}
