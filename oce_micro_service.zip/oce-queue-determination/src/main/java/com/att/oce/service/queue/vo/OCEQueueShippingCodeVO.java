package com.att.oce.service.queue.vo;


/**
 * The Class OCEQueueShippingCodeVO.
 */
public class OCEQueueShippingCodeVO {

	/** The queue id. */
	private String queueId;
	
	/** The sequence. */
	private int sequence;
	
	/** The ship code id. */
	private String shipCodeId;
	
	
	/**
	 * Gets the queue id.
	 *
	 * @return the queue id
	 */
	public String getQueueId() {
		return queueId;
	}
	
	
	/**
	 * Sets the queue id.
	 *
	 * @param queueId the new queue id
	 */
	public void setQueueId(String queueId) {
		this.queueId = queueId;
	}
	
	
	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public int getSequence() {
		return sequence;
	}
	
	
	/**
	 * Sets the sequence.
	 *
	 * @param sequence the new sequence
	 */
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	
	
	/**
	 * Gets the ship code id.
	 *
	 * @return the ship code id
	 */
	public String getShipCodeId() {
		return shipCodeId;
	}
	
	
	/**
	 * Sets the ship code id.
	 *
	 * @param shipCodeId the new ship code id
	 */
	public void setShipCodeId(String shipCodeId) {
		this.shipCodeId = shipCodeId;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueueShippingCodeVO [queueId=" + queueId + ", sequence="
				+ sequence + ", shipCodeId=" + shipCodeId + "]";
	}
	
	
	
	
}
