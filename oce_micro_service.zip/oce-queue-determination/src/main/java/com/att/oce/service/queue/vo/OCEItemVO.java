package com.att.oce.service.queue.vo;

/**
 * @author AV00419874
 * OCEItem.java - hibernate Annotated Class for OCE_ITEM table
 */


public class OCEItemVO {

	private String commerceItemId;
	private String contractDetailsId;
	private String productSku;
	
	public OCEItemVO(){
		
	}

	/**
	 * @return the commerceItemId
	 */
	public String getCommerceItemId() {
		return commerceItemId;
	}

	/**
	 * @param commerceItemId the commerceItemId to set
	 */
	public void setCommerceItemId(String commerceItemId) {
		this.commerceItemId = commerceItemId;
	}

	/**
	 * @return the contractDetailsId
	 */
	public String getContractDetailsId() {
		return contractDetailsId;
	}

	/**
	 * @param contractDetailsId the contractDetailsId to set
	 */
	public void setContractDetailsId(String contractDetailsId) {
		this.contractDetailsId = contractDetailsId;
	}

	/**
	 * @return the productSku
	 */
	public String getProductSku() {
		return productSku;
	}

	/**
	 * @param productSku the productSku to set
	 */
	public void setProductSku(String productSku) {
		this.productSku = productSku;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEItemVO [commerceItemId=" + commerceItemId
				+ ", contractDetailsId=" + contractDetailsId + ", productSku="
				+ productSku + "]";
	}


}
