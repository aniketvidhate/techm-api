package com.att.oce.service.queue.hibernate.orm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEProgramMaster.
 */
@Entity
@Table(name = "OCE_PROGRAM_MASTER")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OceProgramMaster")
public class OCEProgramMaster {
		
	/** The program name. */
	@Id
	@Column(name = "PROGRAM_NAME")
	private String programName;

	/** The priority. */
	@Column(name = "PRIORITY")
	private String priority;

	/** The program id. */
	@Column(name = "PROGRAM_ID")
	private String programId;

	/** The program type. */
	@Column(name = "PROGRAM_TYPE")
	private String programType;

	/** The channel. */
	@Column(name = "CHANNEL")
	private String channel;

	/** The changed by. */
	@Column(name = "CHANGED_BY")
	private String changedBy;

	/** The changed date. */
	@Column(name = "CHANGED_DATE")
	private String changedDate;

	
	/**
	 * Instantiates a new OCE program master.
	 */
	public OCEProgramMaster(){
		
	}


	/**
	 * Gets the program name.
	 *
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}


	/**
	 * Sets the program name.
	 *
	 * @param programName the programName to set
	 */
	public void setProgramName(String programName) {
		this.programName = programName;
	}


	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}
 

	/**
	 * Sets the priority.
	 *
	 * @param priority the priority to set
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}


	/**
	 * Gets the program id.
	 *
	 * @return the programId
	 */
	public String getProgramId() {
		return programId;
	}


	/**
	 * Sets the program id.
	 *
	 * @param programId the programId to set
	 */
	public void setProgramId(String programId) {
		this.programId = programId;
	}


	/**
	 * Gets the program type.
	 *
	 * @return the programType
	 */
	public String getProgramType() {
		return programType;
	}


	/**
	 * Sets the program type.
	 *
	 * @param programType the programType to set
	 */
	public void setProgramType(String programType) {
		this.programType = programType;
	}


	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}


	/**
	 * Sets the channel.
	 *
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}


	/**
	 * Gets the changed by.
	 *
	 * @return the changedBy
	 */
	public String getChangedBy() {
		return changedBy;
	}


	/**
	 * Sets the changed by.
	 *
	 * @param changedBy the changedBy to set
	 */
	public void setChangedBy(String changedBy) {
		this.changedBy = changedBy;
	}


	/**
	 * Gets the changed date.
	 *
	 * @return the changedDate
	 */
	public String getChangedDate() {
		return changedDate;
	}


	/**
	 * Sets the changed date.
	 *
	 * @param changedDate the changedDate to set
	 */
	public void setChangedDate(String changedDate) {
		this.changedDate = changedDate;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEProgramMaster [programName=" + programName + ", priority="
				+ priority + ", programId=" + programId + ", programType="
				+ programType + ", channel=" + channel + ", changedBy="
				+ changedBy + ", changedDate=" + changedDate + "]";
	}
	 

}
