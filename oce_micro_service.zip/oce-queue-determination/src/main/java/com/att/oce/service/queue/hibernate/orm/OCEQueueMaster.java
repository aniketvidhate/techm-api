package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEQueueMaster.java - hibernate Annotated Class for OCE_QUEUE_MASTER table
 */

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEQueueMaster.
 */
@Entity
@Table(name="OCE_QUEUE_MASTER")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEQueueMaster")
public class OCEQueueMaster {

	/** The id. */
	@Id
	@Column(name="ID")
	private String id;
	
	/** The queue type. */
	@Column(name="QUEUE_TYPE")
	private String queueType;
	
	/** The queue description. */
	@Column(name="QUEUE_DESCRIPTION")
	private String queueDescription;
	
	/** The priority. */
	@Column(name="PRIORITY")
	private int priority;
	
	/** The line combo flag. */
	@Column(name="LINECOMBOFLAG")
	private String lineComboFlag;
	
	/** The enterprise type. */
	@Column(name="ENTERPRISE_TYPE")
	private String enterpriseType;
	
	/** The user roles. */
	@Column(name="USER_ROLES")
	private String userRoles;
	
	/** The release lock. */
	@Column(name="RELEASE_LOCK")
	private int releaseLock;
	
	/** The vacant alert. */
	@Column(name="VACANT_ALERT")
	private int vacantAlert;
	
	/** The vacant alert email. */
	@Column(name="VACANT_ALERT_EMAIL")
	private String vacantAlertEmail;
	
	/** The fallouts threshold. */
	@Column(name="FALLOUTS_THRESHOLD")
	private int falloutsThreshold;
	
	/** The no_ order alert. */
	@Column(name="NO_ORDER_ALERT")
	private int no_OrderAlert;
	
	/** The creation date. */
	@Column(name="CREATION_DATE")
	private Date creationDate;
	
	/** The last modied date. */
	@Column(name="LAST_MODIFIED_DATE")
	private Date lastModiedDate;
	
	/** The threshold count. */
	@Column(name="THRESHOLD_COUNT")
	private int thresholdCount;
	
	/** The queue limit alert email. */
	@Column(name="QUEUE_LIMIT_ALERT_EMAIL")
	private String queueLimitAlertEmail;
	
	/** The effective from date. */
	@Column(name="EFFECTIVE_FROM_DATE")
	private Date effectiveFromDate;
	
	/** The effective till date. */
	@Column(name="EFFECTIVE_TILL_DATE")
	private Date effectiveTillDate;

	/** The sku. */
	@Column(name="SKU")
	private String sku;
	
	/** The is order level queue. */
	@Column(name="IS_ORDER_LEVEL_QUEUE")
	private int isOrderLevelQueue;
	
	/** The channel. */
	@Column(name="CHANNEL")
	private String channel;
	
	/** The callback preference. */
	@Column(name="CALLBACK_PREFERENCE")
	private String callbackPreference;
	
	/** The active. */
	@Column(name="ACTIVE")
	private String active;
	
	/** The rep commnets. */
	@Column(name="REP_COMMENTS")
	private String repCommnets;
		
	/** The queue info. */
	@Column(name="QUEUE_INFO")
	private String queueInfo;
	
	/** The escalation type. */
	@Column(name="ESCALATION_TYPE")
	private String escalationType;
	
	/** The escalation priority. */
	@Column(name="ESCALATION_PRIORITY")
	private String escalationPriority;
	
	/** The giga ind. */
	@Column(name="GIGA_IND")
	private String gigaInd;
	
	/** The queue group. */
	@Column(name="QUEUE_GROUP")
	private String queueGroup;
	
	/** The request type. */
	@Column(name="REQUEST_TYPE")
	private String requestType;
	
	/** The last modified by. */
	@Column(name="LAST_MODIFIEDBY")
	private String lastModifiedBy;
	
	/** The last_ modified_ by. */
	@Column(name="LAST_MODIFIED_BY")
	private String last_Modified_By;
	
	
	/**
	 * Instantiates a new OCE queue master.
	 */
	public OCEQueueMaster(){
		
	}


	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * Gets the queue type.
	 *
	 * @return the queueType
	 */
	public String getQueueType() {
		return queueType;
	}


	/**
	 * Sets the queue type.
	 *
	 * @param queueType the queueType to set
	 */
	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}


	/**
	 * Gets the queue description.
	 *
	 * @return the queueDescription
	 */
	public String getQueueDescription() {
		return queueDescription;
	}


	/**
	 * Sets the queue description.
	 *
	 * @param queueDescription the queueDescription to set
	 */
	public void setQueueDescription(String queueDescription) {
		this.queueDescription = queueDescription;
	}


	/**
	 * Gets the priority.
	 *
	 * @return the priority
	 */
	public int getPriority() {
		return priority;
	}


	/**
	 * Sets the priority.
	 *
	 * @param priority the priority to set
	 */
	public void setPriority(int priority) {
		this.priority = priority;
	}


	/**
	 * Gets the line combo flag.
	 *
	 * @return the lineComboFlag
	 */
	public String getLineComboFlag() {
		return lineComboFlag;
	}


	/**
	 * Sets the line combo flag.
	 *
	 * @param lineComboFlag the lineComboFlag to set
	 */
	public void setLineComboFlag(String lineComboFlag) {
		this.lineComboFlag = lineComboFlag;
	}


	/**
	 * Gets the enterprise type.
	 *
	 * @return the enterpriseType
	 */
	public String getEnterpriseType() {
		return enterpriseType;
	}


	/**
	 * Sets the enterprise type.
	 *
	 * @param enterpriseType the enterpriseType to set
	 */
	public void setEnterpriseType(String enterpriseType) {
		this.enterpriseType = enterpriseType;
	}


	/**
	 * Gets the user roles.
	 *
	 * @return the userRoles
	 */
	public String getUserRoles() {
		return userRoles;
	}


	/**
	 * Sets the user roles.
	 *
	 * @param userRoles the userRoles to set
	 */
	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}


	/**
	 * Gets the release lock.
	 *
	 * @return the releaseLock
	 */
	public int getReleaseLock() {
		return releaseLock;
	}


	/**
	 * Sets the release lock.
	 *
	 * @param releaseLock the releaseLock to set
	 */
	public void setReleaseLock(int releaseLock) {
		this.releaseLock = releaseLock;
	}


	/**
	 * Gets the vacant alert.
	 *
	 * @return the vacantAlert
	 */
	public int getVacantAlert() {
		return vacantAlert;
	}


	/**
	 * Sets the vacant alert.
	 *
	 * @param vacantAlert the vacantAlert to set
	 */
	public void setVacantAlert(int vacantAlert) {
		this.vacantAlert = vacantAlert;
	}


	/**
	 * Gets the vacant alert email.
	 *
	 * @return the vacantAlertEmail
	 */
	public String getVacantAlertEmail() {
		return vacantAlertEmail;
	}


	/**
	 * Sets the vacant alert email.
	 *
	 * @param vacantAlertEmail the vacantAlertEmail to set
	 */
	public void setVacantAlertEmail(String vacantAlertEmail) {
		this.vacantAlertEmail = vacantAlertEmail;
	}


	/**
	 * Gets the fallouts threshold.
	 *
	 * @return the falloutsThreshold
	 */
	public int getFalloutsThreshold() {
		return falloutsThreshold;
	}


	/**
	 * Sets the fallouts threshold.
	 *
	 * @param falloutsThreshold the falloutsThreshold to set
	 */
	public void setFalloutsThreshold(int falloutsThreshold) {
		this.falloutsThreshold = falloutsThreshold;
	}


	/**
	 * Gets the no_ order alert.
	 *
	 * @return the no_OrderAlert
	 */
	public int getNo_OrderAlert() {
		return no_OrderAlert;
	}


	/**
	 * Sets the no_ order alert.
	 *
	 * @param no_OrderAlert the no_OrderAlert to set
	 */
	public void setNo_OrderAlert(int no_OrderAlert) {
		this.no_OrderAlert = no_OrderAlert;
	}


	/**
	 * Gets the creation date.
	 *
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}


	/**
	 * Sets the creation date.
	 *
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}


	/**
	 * Gets the last modied date.
	 *
	 * @return the lastModiedDate
	 */
	public Date getLastModiedDate() {
		return lastModiedDate;
	}


	/**
	 * Sets the last modied date.
	 *
	 * @param lastModiedDate the lastModiedDate to set
	 */
	public void setLastModiedDate(Date lastModiedDate) {
		this.lastModiedDate = lastModiedDate;
	}


	/**
	 * Gets the threshold count.
	 *
	 * @return the thresholdCount
	 */
	public int getThresholdCount() {
		return thresholdCount;
	}


	/**
	 * Sets the threshold count.
	 *
	 * @param thresholdCount the thresholdCount to set
	 */
	public void setThresholdCount(int thresholdCount) {
		this.thresholdCount = thresholdCount;
	}


	/**
	 * Gets the queue limit alert email.
	 *
	 * @return the queueLimitAlertEmail
	 */
	public String getQueueLimitAlertEmail() {
		return queueLimitAlertEmail;
	}


	/**
	 * Sets the queue limit alert email.
	 *
	 * @param queueLimitAlertEmail the queueLimitAlertEmail to set
	 */
	public void setQueueLimitAlertEmail(String queueLimitAlertEmail) {
		this.queueLimitAlertEmail = queueLimitAlertEmail;
	}


	/**
	 * Gets the effective from date.
	 *
	 * @return the effectiveFromDate
	 */
	public Date getEffectiveFromDate() {
		return effectiveFromDate;
	}


	/**
	 * Sets the effective from date.
	 *
	 * @param effectiveFromDate the effectiveFromDate to set
	 */
	public void setEffectiveFromDate(Date effectiveFromDate) {
		this.effectiveFromDate = effectiveFromDate;
	}


	/**
	 * Gets the effective till date.
	 *
	 * @return the effectiveTillDate
	 */
	public Date getEffectiveTillDate() {
		return effectiveTillDate;
	}


	/**
	 * Sets the effective till date.
	 *
	 * @param effectiveTillDate the effectiveTillDate to set
	 */
	public void setEffectiveTillDate(Date effectiveTillDate) {
		this.effectiveTillDate = effectiveTillDate;
	}


	/**
	 * Gets the sku.
	 *
	 * @return the sku
	 */
	public String getSku() {
		return sku;
	}


	/**
	 * Sets the sku.
	 *
	 * @param sku the sku to set
	 */
	public void setSku(String sku) {
		this.sku = sku;
	}


	/**
	 * Gets the checks if is order level queue.
	 *
	 * @return the isOrderLevelQueue
	 */
	public int getIsOrderLevelQueue() {
		return isOrderLevelQueue;
	}


	/**
	 * Sets the checks if is order level queue.
	 *
	 * @param isOrderLevelQueue the isOrderLevelQueue to set
	 */
	public void setIsOrderLevelQueue(int isOrderLevelQueue) {
		this.isOrderLevelQueue = isOrderLevelQueue;
	}


	/**
	 * Gets the channel.
	 *
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}


	/**
	 * Sets the channel.
	 *
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}


	/**
	 * Gets the callback preference.
	 *
	 * @return the callbackPreference
	 */
	public String getCallbackPreference() {
		return callbackPreference;
	}


	/**
	 * Sets the callback preference.
	 *
	 * @param callbackPreference the callbackPreference to set
	 */
	public void setCallbackPreference(String callbackPreference) {
		this.callbackPreference = callbackPreference;
	}


	/**
	 * Gets the active.
	 *
	 * @return the active
	 */
	public String getActive() {
		return active;
	}


	/**
	 * Sets the active.
	 *
	 * @param active the active to set
	 */
	public void setActive(String active) {
		this.active = active;
	}


	/**
	 * Gets the rep commnets.
	 *
	 * @return the repCommnets
	 */
	public String getRepCommnets() {
		return repCommnets;
	}


	/**
	 * Sets the rep commnets.
	 *
	 * @param repCommnets the repCommnets to set
	 */
	public void setRepCommnets(String repCommnets) {
		this.repCommnets = repCommnets;
	}


	/**
	 * Gets the queue info.
	 *
	 * @return the queueInfo
	 */
	public String getQueueInfo() {
		return queueInfo;
	}


	/**
	 * Sets the queue info.
	 *
	 * @param queueInfo the queueInfo to set
	 */
	public void setQueueInfo(String queueInfo) {
		this.queueInfo = queueInfo;
	}


	/**
	 * Gets the escalation type.
	 *
	 * @return the escalationType
	 */
	public String getEscalationType() {
		return escalationType;
	}


	/**
	 * Sets the escalation type.
	 *
	 * @param escalationType the escalationType to set
	 */
	public void setEscalationType(String escalationType) {
		this.escalationType = escalationType;
	}


	/**
	 * Gets the escalation priority.
	 *
	 * @return the escalationPriority
	 */
	public String getEscalationPriority() {
		return escalationPriority;
	}


	/**
	 * Sets the escalation priority.
	 *
	 * @param escalationPriority the escalationPriority to set
	 */
	public void setEscalationPriority(String escalationPriority) {
		this.escalationPriority = escalationPriority;
	}


	/**
	 * Gets the giga ind.
	 *
	 * @return the gigaInd
	 */
	public String getGigaInd() {
		return gigaInd;
	}


	/**
	 * Sets the giga ind.
	 *
	 * @param gigaInd the gigaInd to set
	 */
	public void setGigaInd(String gigaInd) {
		this.gigaInd = gigaInd;
	}


	/**
	 * Gets the queue group.
	 *
	 * @return the queueGroup
	 */
	public String getQueueGroup() {
		return queueGroup;
	}


	/**
	 * Sets the queue group.
	 *
	 * @param queueGroup the queueGroup to set
	 */
	public void setQueueGroup(String queueGroup) {
		this.queueGroup = queueGroup;
	}


	/**
	 * Gets the request type.
	 *
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}


	/**
	 * Sets the request type.
	 *
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}


	/**
	 * Gets the last modified by.
	 *
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}


	/**
	 * Sets the last modified by.
	 *
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}


	/**
	 * Gets the last_ modified_ by.
	 *
	 * @return the last_Modified_By
	 */
	public String getLast_Modified_By() {
		return last_Modified_By;
	}


	/**
	 * Sets the last_ modified_ by.
	 *
	 * @param last_Modified_By the last_Modified_By to set
	 */
	public void setLast_Modified_By(String last_Modified_By) {
		this.last_Modified_By = last_Modified_By;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueueMaster [id=" + id + ", queueType=" + queueType
				+ ", queueDescription=" + queueDescription + ", priority="
				+ priority + ", lineComboFlag=" + lineComboFlag
				+ ", enterpriseType=" + enterpriseType + ", userRoles="
				+ userRoles + ", releaseLock=" + releaseLock + ", vacantAlert="
				+ vacantAlert + ", vacantAlertEmail=" + vacantAlertEmail
				+ ", falloutsThreshold=" + falloutsThreshold
				+ ", no_OrderAlert=" + no_OrderAlert + ", creationDate="
				+ creationDate + ", lastModiedDate=" + lastModiedDate
				+ ", thresholdCount=" + thresholdCount
				+ ", queueLimitAlertEmail=" + queueLimitAlertEmail
				+ ", effectiveFromDate=" + effectiveFromDate
				+ ", effectiveTillDate=" + effectiveTillDate + ", sku=" + sku
				+ ", isOrderLevelQueue=" + isOrderLevelQueue + ", channel="
				+ channel + ", callbackPreference=" + callbackPreference
				+ ", active=" + active + ", repCommnets=" + repCommnets
				+ ", queueInfo=" + queueInfo + ", escalationType="
				+ escalationType + ", escalationPriority=" + escalationPriority
				+ ", gigaInd=" + gigaInd + ", queueGroup=" + queueGroup
				+ ", requestType=" + requestType + ", lastModifiedBy="
				+ lastModifiedBy + ", last_Modified_By=" + last_Modified_By
				+ "]";
	}
 
	
}
