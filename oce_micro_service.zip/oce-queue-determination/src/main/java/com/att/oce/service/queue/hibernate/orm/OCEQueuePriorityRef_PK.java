package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEQueuePriorityRef_PK.java - hibernate Annotated Class 
 * for OCE_QUEUE_PRIORITY_REF table containing Primary key
 */

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The Class OCEQueuePriorityRef_PK.
 */
@Embeddable
public class OCEQueuePriorityRef_PK implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The id. */
	@Column(name="ID")
	private String id;
	
	/** The sequence. */
	@Column(name="SEQUENCE")
	private String sequence;
	
	
	/**
	 * Instantiates a new OCE queue priority ref_ pk.
	 */
	public OCEQueuePriorityRef_PK(){
		
	}


	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public String getSequence() {
		return sequence;
	}


	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}


	/**
	 * Gets the serialversionuid.
	 *
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueuePriorityRef_PK [id=" + id + ", sequence=" + sequence
				+ "]";
	}

}
