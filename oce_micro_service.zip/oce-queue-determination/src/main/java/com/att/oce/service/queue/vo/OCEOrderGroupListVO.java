package com.att.oce.service.queue.vo;

/**
 * @author AV00419874
 * OCEOrderGroupList.java - Custom pojo mapped to hibernate annotted pojo
 */


/**
 * The Class OCEOrderGroupListVO.
 */
public class OCEOrderGroupListVO {

	/** The order id. */
	private String orderId;
	
	/** The group list id. */
	private String groupListId;
	
	/** The sequence. */
	private int sequence;
	
	/**
	 * Instantiates a new OCE order group list vo.
	 */
	public OCEOrderGroupListVO(){
		
	}

	/**
	 * Gets the order id.
	 *
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * Sets the order id.
	 *
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * Gets the group list id.
	 *
	 * @return the groupListId
	 */
	public String getGroupListId() {
		return groupListId;
	}

	/**
	 * Sets the group list id.
	 *
	 * @param groupListId the groupListId to set
	 */
	public void setGroupListId(String groupListId) {
		this.groupListId = groupListId;
	}

	/**
	 * Gets the sequence.
	 *
	 * @return the sequence
	 */
	public int getSequence() {
		return sequence;
	}

	/**
	 * Sets the sequence.
	 *
	 * @param sequence the sequence to set
	 */
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEOrderGroupListVO [orderId=" + orderId + ", groupListId="
				+ groupListId + ", sequence=" + sequence + "]";
	}

	
}
