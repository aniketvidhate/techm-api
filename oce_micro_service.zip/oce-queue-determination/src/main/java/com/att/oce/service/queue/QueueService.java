package com.att.oce.service.queue;

import java.util.Collection;
import java.util.List;

import com.att.oce.service.queue.vo.OCEActionTypeVO;
import com.att.oce.service.queue.vo.OCEQueueActionTypeVO;
import com.att.oce.service.queue.vo.OCEQueueLineSubstatusVO;
import com.att.oce.service.queue.vo.OceQueueProgramSlaVO;
import com.att.oce.service.queueImpl.QueueDetails;
import com.att.oce.service.task.Exception.OCEException;

public interface QueueService {

	public QueueDetails getOutboundQueueDetails(String reqQueueType, String channel) throws OCEException;
	
	public QueueDetails  getQueueDetails(String conversationId, String orderId, 
			String channel, String losgStatus, String status, 
			Boolean isBulk, List<String> shippingCodeList,
			String requestType,List<String> actionTypeList, Boolean isConnectedCar) throws OCEException;
	
	public QueueDetails getDefaultQueueDetails(String conversationId, String orderId, 
			String defaultQueueType,String channel,String requestType) throws OCEException;
	
	public void getOCELineSubstatusData() throws OCEException;

	public List<OCEQueueLineSubstatusVO> getAllOceQueueLineSubstatus(String string) throws OCEException;

	public List<OCEActionTypeVO> getAllOceActionTypeDetails() throws OCEException;
	
	public List<OCEQueueActionTypeVO> getQueueActionTypeDetailsById(String queueId) throws OCEException;
	
	public List<OceQueueProgramSlaVO> getSLADetails(String programName, 
			String queueType, String channel) ;

}