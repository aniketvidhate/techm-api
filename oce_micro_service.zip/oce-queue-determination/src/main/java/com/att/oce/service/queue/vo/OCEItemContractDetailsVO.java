package com.att.oce.service.queue.vo;

/**
 * The Class OCEItemContractDetailsVO.
 *
 * @author AV00419874
 */


public class OCEItemContractDetailsVO {

	/** The id. */
	private String id;
	
	/** The contract type. */
	private String contractType;
	
	/**
	 * Instantiates a new OCE item contract details vo.
	 */
	public OCEItemContractDetailsVO(){
		
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Gets the contract type.
	 *
	 * @return the contractType
	 */
	public String getContractType() {
		return contractType;
	}

	/**
	 * Sets the contract type.
	 *
	 * @param contractType the contractType to set
	 */
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEItemContractDetails [id=" + id + ", contractType="
				+ contractType + "]";
	}

	


}
