package com.att.oce.service.queue.hibernate.orm;

/**
 * @author AV00419874
 * OCEQueuePriorityCriteria.java - hibernate Annotated Class for OCE_QUEUE_PRIORITY_CRITERIA table
 */

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * The Class OCEQueuePriorityCriteria.
 */
@Entity
@Table(name="OCE_QUEUE_PRIORITY_CRITERIA")
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY, region="OCEQueuePriorityCriteria")
public class OCEQueuePriorityCriteria {

	/** The priority criteria name. */
	@Id
	@Column(name="PRIORITY_CRITERIA_NAME")
	private String priorityCriteriaName;
	
	/** The priority criteria xpath. */
	@Column(name="PRIORITY_CRITERIA_XPATH")
	private String priorityCriteriaXpath;
	
	/** The priority criteria rerpopath. */
	@Column(name="PRIORITY_CRITERIA_REPOPATH")
	private String priorityCriteriaRerpopath;
	
	
	/**
	 * Instantiates a new OCE queue priority criteria.
	 */
	public OCEQueuePriorityCriteria(){
		
	}


	/**
	 * Gets the priority criteria name.
	 *
	 * @return the priorityCriteriaName
	 */
	public String getPriorityCriteriaName() {
		return priorityCriteriaName;
	}


	/**
	 * Sets the priority criteria name.
	 *
	 * @param priorityCriteriaName the priorityCriteriaName to set
	 */
	public void setPriorityCriteriaName(String priorityCriteriaName) {
		this.priorityCriteriaName = priorityCriteriaName;
	}


	/**
	 * Gets the priority criteria xpath.
	 *
	 * @return the priorityCriteriaXpath
	 */
	public String getPriorityCriteriaXpath() {
		return priorityCriteriaXpath;
	}


	/**
	 * Sets the priority criteria xpath.
	 *
	 * @param priorityCriteriaXpath the priorityCriteriaXpath to set
	 */
	public void setPriorityCriteriaXpath(String priorityCriteriaXpath) {
		this.priorityCriteriaXpath = priorityCriteriaXpath;
	}


	/**
	 * Gets the priority criteria rerpopath.
	 *
	 * @return the priorityCriteriaRerpopath
	 */
	public String getPriorityCriteriaRerpopath() {
		return priorityCriteriaRerpopath;
	}


	/**
	 * Sets the priority criteria rerpopath.
	 *
	 * @param priorityCriteriaRerpopath the priorityCriteriaRerpopath to set
	 */
	public void setPriorityCriteriaRerpopath(String priorityCriteriaRerpopath) {
		this.priorityCriteriaRerpopath = priorityCriteriaRerpopath;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "OCEQueuePriorityCriteria [priorityCriteriaName="
				+ priorityCriteriaName + ", priorityCriteriaXpath="
				+ priorityCriteriaXpath + ", priorityCriteriaRerpopath="
				+ priorityCriteriaRerpopath + "]";
	}

	
}
