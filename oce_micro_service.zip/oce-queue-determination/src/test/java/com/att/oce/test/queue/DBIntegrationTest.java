/**
 * 
 */
package com.att.oce.test.queue;

/**
 * @author bk436x
 *
 */
public interface DBIntegrationTest {

}
