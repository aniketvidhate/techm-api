package com.att.oce.test.queue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroup;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroupCharacteristics;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtLoSGCharacteristics;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtLoSGStatus;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtOrderSource;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtSchedulingInfoList;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.GroupList;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.Order;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StLoSGStatus;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StLoSGType;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StProductCategory;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StRequestType;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtOrderTask;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.StTaskStatus;
import com.att.oce.service.queue.OCEOrderQueueService;
import com.att.oce.service.queue.QueuePriorityService;
import com.att.oce.service.queue.QueueService;
import com.att.oce.service.queue.vo.OCEQueueDeterminationRequest;
import com.att.oce.service.queue.vo.sub.OCEOrderInfo;
import com.att.oce.service.queueImpl.QueueDetails;


/**
 * The Class QueueServiceTest.
 */
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = "classpath:/com/att/oce/service/test/queue/OCEQueueBeanTest.xml")
//@Category(DBIntegrationTest.class)
public class QueueServiceTest {

	/** The qservice. */
	@Autowired
	QueueService qservice;

	@Autowired
	QueuePriorityService queuePriorityService;
	
	/** The order queue service. */
	@Autowired
	OCEOrderQueueService orderQueueService;
	
	/**
	 * Test get outbound queue details.
	 */
	//@Test
	public void TestGetOutboundQueueDetails() {

		try {
			
			QueueDetails details = null;
			
			if (null != details) {
				System.out.println(details.getQueueId());
			} else {
				System.out.println("Queue Details is null.");
			}
			
			OCEQueueDeterminationRequest request = new OCEQueueDeterminationRequest();
			
			pupulateDataForQueueDetermination(request);
			
			details = orderQueueService.determineQueue(request);
			
			if (null != details) {
				System.out.println("Id = " + details.getQueueId());
				System.out.println("queueType = " + details.getQueueType());
				System.out.println("queueSubType = " + details.getQueueSubType());
				System.out.println("repComments : " + details.getRepComments());
				System.out.println("ActionType = " + details.getActionType());
				System.out.println("Manual intervention : " + details.isManualIntervention());
				System.out.println("Queue Priority : " + details.getQueuePriority());
				System.out.println("Queue Category : " + details.getQueueCategory());
			} else {
				System.out.println("Queue Details is null.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param request
	 */
	private void pupulateDataForQueueDetermination(
			OCEQueueDeterminationRequest request) {
		OCEOrderInfo oceOrderInfo = new OCEOrderInfo();

		System.out.println("Hello OCE");

		QueueDetails queueDetails = new QueueDetails();
		Order order = new Order();
		List<CtOrderTask> orderTasklist = new ArrayList<CtOrderTask>();
		CtOrderTask ctOrderTask = new CtOrderTask();
		ctOrderTask.setQueueType("BULK_UNLOCK_QUEUE");
		StTaskStatus stTaskStatus = StTaskStatus.NEW;
		ctOrderTask.setTaskStatus(stTaskStatus);
		GroupList groupList = new GroupList();
		List<CtGroup> ctGroups = new ArrayList<CtGroup>();

		CtGroup ctGroup = new CtGroup();
		CtGroupCharacteristics ctGroupCharacteristics = new CtGroupCharacteristics();
		CtLoSGCharacteristics ctLoSGCharacteristics = new CtLoSGCharacteristics();
		CtLoSGStatus loSGStatus = new CtLoSGStatus();

		loSGStatus.setStatus(StLoSGStatus.IN_QUEUE);
		loSGStatus.setSubStatus("NEW");
		ctLoSGCharacteristics.setLoSGStatus(loSGStatus);
		StProductCategory stProductCategory = ctLoSGCharacteristics.getProductCategory();
		if (stProductCategory == null) {
			stProductCategory = stProductCategory.valueOf("WIRELESS");
		}
		ctLoSGCharacteristics.setProductCategory(stProductCategory);
		StLoSGType stLoSGType = ctLoSGCharacteristics.getLoSGType();
		if (stLoSGType == null) {
			stLoSGType = stLoSGType.valueOf("UNLOCK");
		}
		ctLoSGCharacteristics.setLoSGType(stLoSGType);
		ctGroupCharacteristics.setLoSGCharacteristics(ctLoSGCharacteristics);
		ctGroup.setGroupCharacteristics(ctGroupCharacteristics);
		ctGroups.add(ctGroup);
		groupList.getGroup().add(ctGroup);
		order.setGroups(groupList);
		order.setOCEOrderNumber("OCEK1440064");

		order.setRequestType(StRequestType.SOR);
		CtOrderSource ctOrderSource = new CtOrderSource();
		ctOrderSource.setChannel("UNLOCK");
		order.setOrderSource(ctOrderSource);
		boolean nonUnifyWireless = false;
		orderTasklist.add(ctOrderTask);
		StRequestType stRequestType = order.getRequestType();
		String requestType = stRequestType.value();
		if(order.getOrderSource().getChannel().equalsIgnoreCase("CRU-MOBILITY")
				&& null == requestType) {
			requestType = "SOR";
		}
		String requestId = null;
		if (null != order.getRequestId()) {
			requestId = order.getRequestId().getValue();
		}

		oceOrderInfo.setCtOrderSource(ctOrderSource);
		oceOrderInfo.setGroupList(groupList);
		oceOrderInfo.setOceOrderNumber(order.getOCEOrderNumber());
		oceOrderInfo.setRequestId(requestId);
		oceOrderInfo.setRequestType(requestType);
		oceOrderInfo.setCtOrderSource(ctOrderSource);
		oceOrderInfo.setNonUnifyWireless(nonUnifyWireless);
		oceOrderInfo.setOrderTasklist(orderTasklist);
		oceOrderInfo.setCtOrderTasks(orderTasklist);
		oceOrderInfo.setProgramName(order.getProgramName());
		oceOrderInfo.setCtSchedulingInfoList(order.getSchedulingInfos());
		//CtSchedulingInfoList ctSchedulingInfoList =  order.getSchedulingInfos();
		request.setOrder(oceOrderInfo);

	}

	/**
	 * Test get default queue details.
	 */
//	@Test
//	public void testGetDefaultQueueDetails() {
//
//		try {
//			QueueDetails details = qservice.getDefaultQueueDetails("", "", "SPEED MISMATCH", "EDE-EG", "");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}

	/**
	 * Test get queue details.
	 */
//	@Test
//	public void testGetQueueDetails() {
//
//		try {
//			QueueDetails details = qservice.getQueueDetails(null, null, null, null, null, false, null, null, null, false);
//		} catch (Exception e) { 
//			e.printStackTrace();
//		}
//	}

//	@Test
//	public void test() {
//
//		try {
//			List<String> l = new ArrayList<String>();
//			l.add("FULFILLMENT_METHOD");
//			l.add("CONTRACT_TYPE");
//			l.add("FAN");
//			l.add("PREORDER");
//			l.add("PRODUCT_SKU");
//			l.add("UDL");
//			System.out.println("result==> "+queuePriorityService.getPriorityCriteriaListMap(l, "OCEK1440064"));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}

	
	//@Test
	public void testHQL() {
		try {
//			System.out.println("getConverstationIdFromOCEDcsspOrder result==> "+queuePriorityService.getConverstationIdFromOCEDcsspOrder("OCEK1440064"));
//			System.out.println("getOceOrderSchedulingDetailsByOrderId result==> "+queuePriorityService.getOceOrderSchedulingDetailsByOrderId("D51000003"));
//			System.out.println("getOceSchedulingInfoListById result==> "+queuePriorityService.getOceSchedulingInfoListById("D529300001"));
//			System.out.println("getOceActualScheduleTypeDetailsById result==> "+queuePriorityService.getOceActualScheduleTypeDetailsById("D521600001"));
//			System.out.println("getOceActualScheduleTypeDetailsById result==> "+queuePriorityService.getOceFalloutPropertiesById("OCEK1440064"));
			System.out.println("getSLADetails result==> "+qservice.getSLADetails("UV - DTV", "PROCESSING", "CDE-HS"));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
