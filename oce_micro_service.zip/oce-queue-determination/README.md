# Create and Update Task Service

[![N|Solid](https://codecloud.web.att.com/users/bk436x/repos/oce_micro_service/browse/oce-queue-determination/CreateAndUpdateTaskService.pdf)](https://nodesource.com/products/nsolid)

TaskService is an important functionality for order that is not successfully submitted. 
Create task service contains the following phases :

1. Determine Queue
2. Determine Queue Priority
3. Determine Queue Category
4. Create Task if task does not exist
5. Update task if task exists

### Sql Query is required for the Queue Determination :
### I: fetchDefaultQueueDetailsForOutBound :::
1.  SELECT t1.id
   FROM oce_queue_master t1
  WHERE ((t1.queue_type = ?)
    AND (t1.channel = ?))
-- Parameters --
p[1] = {pd: queueType} BULK_UNLOCK_QUEUE (java.lang.String)
p[2] = {pd: channel} UNLOCK (java.lang.String)
[--SQLQuery--]

2.  SELECT queue_type,queue_description,priority,lineComboFlag,enterprise_type,user_roles,release_lock,VACANT_ALERT,vacant_alert_email,fallouts_threshold,effective_from_date,effective_till_date,last_modified_by,creation_date,last_modified_date,no_order_alert,sku,queue_limit_alert_email,is_order_level_queue,GIGA_IND,QUEUE_GROUP,threshold_count,channel,active,queue_Info,rep_Comments,request_type
   FROM oce_queue_master
  WHERE id=?
-- Parameters --
p[1] = {pd} QUBU001 (java.lang.String)
[--SQLSelect--]
-----------------
###II : fetchQueueDetails : 

channel EQUALS ?0 AND lineSubStatusList INCLUDES ITEM (status EQUALS ?1 AND isBulk = ?2 AND isConnectedCar = ?3

(channel EQUALS ?0 AND lineSubStatusList INCLUDES ITEM ((status EQUALS ?1 AND isBulk = ?2 AND isConnectedCar = ?3 AND (lineSubstatus EQUALS ?4 OR lineSubstatus EQUALS ?5 OR lineSubstatus EQUALS ?6))))

[UNLOCK, IN_QUEUE, true, false, NA, NEW, BULK_UNLOCK_ORDER]

1.  SELECT DISTINCT t1.id
   FROM oce_queue_master t1, oce_queue_linesubstatus t2
  WHERE t2.id=t1.id
    AND ((t1.channel = ?)
    AND t2.substatus_id IN ( SELECT tt1.id
   FROM oce_linesubstatus tt1
  WHERE ((tt1.status = ?)
    AND (tt1.isbulk = ?)
    AND (tt1.isconnectedcar = ?)
    AND ((tt1.line_sub_status = ?)
    OR (tt1.line_sub_status = ?)
    OR (tt1.line_sub_status = ?)))))
-- Parameters --
p[1] = {pd: channel} UNLOCK (java.lang.String)
p[2] = {pd: status} IN_QUEUE (java.lang.String)
p[3] = {pd: isBulk} true (java.lang.Boolean)
p[4] = {pd: isConnectedCar} false (java.lang.Boolean)
p[5] = {pd: lineSubstatus} NA (java.lang.String)
p[6] = {pd: lineSubstatus} NEW (java.lang.String)
p[7] = {pd: lineSubstatus} BULK_UNLOCK_ORDER (java.lang.String)
[--SQLQuery--]

2.  SELECT sequence,shipCode_Id
   FROM OCE_QUEUE_SHIPPING_CODE
  WHERE QUEUE_ID=? ORDER BY 1 ASC
-- Parameters --
p[1] = {pd} QUBU001 (java.lang.String)
[--SQLSelect--]
------------------------------
### Decide Queue :::

1.  SELECT sequence,substatus_id
   FROM oce_queue_linesubstatus
  WHERE id=? ORDER BY 1 ASC
-- Parameters --
p[1] = {pd} QUBU001 (java.lang.String)
[--SQLSelect--]

================================================================
### III . fetchDefaultQueueDetails :::

1. fetchQueueDetails : if queueDetails is having queueId
 SELECT t1.id
   FROM oce_queue_master t1
  WHERE ((t1.queue_type = ?)
    AND (t1.channel = ?))
-- Parameters --
p[1] = {pd: queueType} UNDEFINED (java.lang.String)
p[2] = {pd: channel} UNLOCK (java.lang.String)
[--SQLQuery--]

2. SELECT queue_type,queue_description,priority,lineComboFlag,enterprise_type,user_roles,release_lock,VACANT_ALERT,vacant_alert_email,fallouts_threshold,effective_from_date,effective_till_date,last_modified_by,creation_date,last_modified_date,no_order_alert,sku,queue_limit_alert_email,is_order_level_queue,GIGA_IND,QUEUE_GROUP,threshold_count,channel,active,queue_Info,rep_Comments,request_type
   FROM oce_queue_master
  WHERE id=?
-- Parameters --
p[1] = {pd} Q212 (java.lang.String)
[--SQLSelect--]

----------------------------
----------------------------
### Detrmining Queue Priority :::
1. Query to get priorityItem :

 SELECT sequence,queue_priority_criteria_id
   FROM oce_queue_priority_ref
  WHERE id=? ORDER BY 1 ASC
-- Parameters --
p[1] = {pd} Q212 (java.lang.String)
[--SQLSelect--]

---------------------------------

### Technical details 

Create Task Service uses the following :

* [Camel Router] - Routing the input JSON/XML with Annotation class
* [Maven]  - awesome builder to build the project
* [Camel Parser] - Parsing the input xml/json with the source java file
* [REST] - communication medium with API
* [Spring Event Listener] - records events of the task manupulation

Readmes, how to use them in your own application can be found here:

* [plugins/dropbox/README.md] [PlDb]
* [plugins/github/README.md] [PlGh]
* [plugins/googledrive/README.md] [PlGd]
* [plugins/onedrive/README.md] [PlOd]

### Class Diagram 
Please refer the class diagram in the path : 
[![N|Solid] [https://codecloud.web.att.com/users/bk436x/repos/oce_micro_service/browse/oce-queue-determination/CreateTaskClassDesign.jpg] (https://nodesource.com/products/nsolid)

### Create Task Service 
[![N|Solid] https://codecloud.web.att.com/users/bk436x/repos/oce_micro_service/browse/oce-queue-determination/CreateTaskService.pdf (https://nodesource.com/products/nsolid)

## Update Task Service 
[![N|Solid] https://codecloud.web.att.com/users/bk436x/repos/oce_micro_service/browse/oce-queue-determination/UpdateTaskService.pdf (https://nodesource.com/products/nsolid)

### Todos

 - Develop code for Queue Determination, Determine Queue Priority, Determine Queue Category, Create Task Service, Update Task Service
 - Create class diagram for create task service
 - Implement Business Logic for the above
 - Add Code Comments

### Order Payload 
We can find the sample order payload in the below path :

[![N|Solid][https://codecloud.web.att.com/users/bk436x/repos/oce_micro_service/browse/oce-queue-determination/OrderPayload.xml] (https://nodesource.com/products/nsolid)