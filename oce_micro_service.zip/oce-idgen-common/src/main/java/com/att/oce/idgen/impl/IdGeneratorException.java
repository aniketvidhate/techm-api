/**
 * 
 */
package com.att.oce.idgen.impl;

/**
 * @author JK00423295
 *
 */
public class IdGeneratorException extends ContainerException {

	private static final long serialVersionUID = 1L;

	public IdGeneratorException(String pMessage) {
		super(pMessage);
	}

	public IdGeneratorException(Throwable pSourceException) {
		super(pSourceException);
	}

	public IdGeneratorException(String pMessage, Throwable pSourceException) {
		super(pMessage, pSourceException);
	}
}
