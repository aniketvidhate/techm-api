package com.att.oce.idgen.hibernate.dao;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "das_id_generator")
public class OCEIdgenerator {

	private String idSpaceName;
	private BigDecimal seed;
	private BigDecimal batchSize;
	private String prefix;
	private String suffix;

	public OCEIdgenerator() {
	}

	public OCEIdgenerator(String idSpaceName, BigDecimal seed,
			BigDecimal batchSize) {
		this.idSpaceName = idSpaceName;
		this.seed = seed;
		this.batchSize = batchSize;
	}

	public OCEIdgenerator(String idSpaceName, BigDecimal seed,
			BigDecimal batchSize, String prefix, String suffix) {
		this.idSpaceName = idSpaceName;
		this.seed = seed;
		this.batchSize = batchSize;
		this.prefix = prefix;
		this.suffix = suffix;
	}

	@Id
	@Column(name = "ID_SPACE_NAME", unique = true, nullable = false, length = 60)
	public String getIdSpaceName() {
		return this.idSpaceName;
	}

	public void setIdSpaceName(String idSpaceName) {
		this.idSpaceName = idSpaceName;
	}

	@Column(name = "SEED", nullable = false, scale = 0)
	public BigDecimal getSeed() {
		return this.seed;
	}

	public void setSeed(BigDecimal seed) {
		this.seed = seed;
	}

	@Column(name = "BATCH_SIZE", nullable = false, precision = 22, scale = 0)
	public BigDecimal getBatchSize() {
		return this.batchSize;
	}

	public void setBatchSize(BigDecimal batchSize) {
		this.batchSize = batchSize;
	}

	@Column(name = "PREFIX", length = 10)
	public String getPrefix() {
		return this.prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	@Column(name = "SUFFIX", length = 10)
	public String getSuffix() {
		return this.suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
}
