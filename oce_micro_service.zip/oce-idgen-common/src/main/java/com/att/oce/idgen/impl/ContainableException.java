/**
 * 
 */
package com.att.oce.idgen.impl;

/**
 * @author JK00423295
 *
 */
public interface ContainableException {

	public abstract Throwable getSourceException();
}
