package com.att.oce.idgen.hibernate.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;


/**
 * 
 * @author SX00352475
 *
 */
public class OCEIdGeneratorDAOImpl {
	
	private Logger logger = LoggerFactory.getLogger(OCEIdGeneratorDAOImpl.class);
	
	long seed;
	String prefix;
	String suffix;
	String idSpaceName;
	long batchSize;
	long lastSeed;
	
	private String mDefaultIdSpaceName = "__default__";
	
	/**
	 * @return the idSpaceName
	 */
	public String getIdSpaceName() {
		return idSpaceName;
	}

	/**
	 * @param idSpaceName the idSpaceName to set
	 */
	public void setIdSpaceName(String idSpaceName) {
		this.idSpaceName = idSpaceName;
	}

	/**
	 * @return the mDefaultIdSpaceName
	 */
	public String getDefaultIdSpaceName() {
		return mDefaultIdSpaceName;
	}

	/**
	 * @param mDefaultIdSpaceName the mDefaultIdSpaceName to set
	 */
	public void setDefaultIdSpaceName(String mDefaultIdSpaceName) {
		this.mDefaultIdSpaceName = mDefaultIdSpaceName;
	}

	public OCEIdGeneratorDAOImpl () {
		
	}
	
	public OCEIdGeneratorDAOImpl (String idSpaceNAme) {
		this.mDefaultIdSpaceName = idSpaceNAme;
	}
	
	@Autowired(required = true)
	private HibernateTemplate idgenTemplate;
	

	/**
	 * @return the seed
	 */
	public long getSeed() {
		return seed;
	}

	/**
	 * @param seed the seed to set
	 */
	public void setSeed(long seed) {
		this.seed = seed;
	}

	/**
	 * @return the prefix
	 */
	public String getPrefix() {
		return prefix;
	}

	/**
	 * @param prefix the prefix to set
	 */
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	/**
	 * @return the suffix
	 */
	public String getSuffix() {
		return suffix;
	}

	/**
	 * @param suffix the suffix to set
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/**
	 * @return the batchSize
	 */
	public long getBatchSize() {
		return batchSize;
	}

	/**
	 * @param batchSize the batchSize to set
	 */
	public void setBatchSize(long batchSize) {
		this.batchSize = batchSize;
	}
	
	

	/**
	 * @return the lastSeed
	 */
	public long getLastSeed() {
		return lastSeed;
	}

	/**
	 * @param lastSeed the lastSeed to set
	 */
	public void setLastSeed(long lastSeed) {
		this.lastSeed = lastSeed;
	}

	/**
	 * This initializes the IDSpace.
	 */
	public void fetchIdGenerator() {
		
		//retrieve values from db
		//create connection and get IdSpaceName from DB and initialize IdSpace.java
		Session session = null;
		IdSpace idspace;
		//IdSpace[] idSpaces ; 
		int i = 0;
		try {
			
			session = idgenTemplate.getSessionFactory().openSession();
			session.getTransaction().begin();
			
			Query updateQry = session.createQuery("UPDATE OCEIdgenerator SET seed = seed + batchSize WHERE idSpaceName = :idSpaceName");
   		 	updateQry.setParameter("idSpaceName", mDefaultIdSpaceName);
   		 	int updateInt = updateQry.executeUpdate();
   		 	if (updateInt > 0) {
   		 		System.out.println();
   		 	} else {
   		 		throw new HibernateException("Exception in UPDATE OF idgenerator table");
   		 	}
			
			String fetchIdSpaceQuery = "select t1.idSpaceName, t1.seed, t1.batchSize, t1.prefix, t1.suffix from OCEIdgenerator t1 where  t1.idSpaceName = :idSpaceName";
			
			if (null != session) {
				Query qry = session.createQuery(fetchIdSpaceQuery);
				logger.debug("Query = "+ qry);
				qry.setParameter("idSpaceName", mDefaultIdSpaceName);
				List<Object> l = qry.list();
				logger.debug("Total Number Of Records : "+l.size());
				Map<String, Object> idgenMap = new HashMap<String,Object>();
				for (Object obj : l) {
					if (obj instanceof Object[]) {
						Object o[] = (Object[])obj;

						idgenMap.put("ID_SPACE_NAME", o[0]);
						setIdSpaceName((String) o[0]);
						idgenMap.put("SEED", o[1]);
						setSeed((Long.valueOf(o[1].toString())));
						idgenMap.put("BATCH_SIZE", o[2]);
						setBatchSize((Long.valueOf(o[2].toString())));
						idgenMap.put("PREFIX", o[3]);
						setPrefix((String) o[3]);
						idgenMap.put("SUFFIX", o[4]);
						setSuffix((String) o[4]);

						setLastSeed(getSeed() + getBatchSize() - 1L);
						idspace = new IdSpace(getIdSpaceName(), getSeed(),getLastSeed() , (int) getBatchSize(), getPrefix(), getSuffix());
					}

				}
				session.getTransaction().commit();
			} 
		} catch(Exception e) {
			logger.error(e.getMessage());
		} finally {
			session.close();
		}
		
	}
}
