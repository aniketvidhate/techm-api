/**
 * 
 */
package com.att.oce.idgen.impl;

/**
 * @author JK00423295
 *
 */
import java.io.PrintStream;
import java.io.PrintWriter;



























































public class ContainerException extends Exception
  implements ContainableException
{
  public static String CLASS_VERSION = "$Id: //product/DAS/version/11.0/Java/atg/core/exception/ContainerException.java#1 $$Change: 848678 $";
private Object[] mMessageArguments;






















  public void setSourceException(Throwable pSourceException)
  {
    initCause(pSourceException);
  }




  public Throwable getSourceException()
  {
    return getCause();
  }











  public void setMessageArguments(Object[] pMessageArguments)
  {
    this.mMessageArguments = pMessageArguments;
  }




  public Object[] getMessageArguments()
  {
    return this.mMessageArguments;
  }
















  public ContainerException(String pStr)
  {
    super(pStr);
  }






  public ContainerException(Throwable pSourceException)
  {
    initCause(pSourceException);
  }






  public ContainerException(String pStr, Throwable pSourceException)
  {
    super(pStr);
    initCause(pSourceException);
  }









  public void printStackTrace(boolean pDisplaySource)
  {
    printStackTrace(System.err, pDisplaySource);
  }







  public void printStackTrace(PrintStream pStream, boolean pDisplaySource)
  {
    if ((pDisplaySource) && (getSourceException() != null)) {
      pStream.print("CAUGHT AT:");
      super.printStackTrace(pStream);
      pStream.print("SOURCE EXCEPTION:");
      getSourceException().printStackTrace(pStream);
    }
    else {
      super.printStackTrace(pStream);
    }
  }





  public void printStackTrace(PrintWriter pWriter)
  {
    printStackTrace(pWriter, true);
  }






  public void printStackTrace(PrintWriter pWriter, boolean pDisplaySource)
  {
    if ((pDisplaySource) && (getSourceException() != null)) {
      pWriter.write("CAUGHT AT:");
      super.printStackTrace(pWriter);
      pWriter.write("SOURCE EXCEPTION:");
      getSourceException().printStackTrace(pWriter);
    }
    else {
      super.printStackTrace(pWriter);
    }
  }




  public String toString()
  {
    return toString(true);
  }





  public String toString(boolean pDisplaySource)
  {
    if ((pDisplaySource) && (getSourceException() != null)) {
      StringBuffer sb = new StringBuffer();
      sb.append("CONTAINER:").append(super.toString());
      sb.append("; SOURCE:").append(getSourceException().toString());
      return sb.toString();
    }
    return super.toString();
  }
}