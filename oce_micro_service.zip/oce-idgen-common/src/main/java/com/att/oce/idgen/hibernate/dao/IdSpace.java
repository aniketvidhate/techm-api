/**
 * 
 */
package com.att.oce.idgen.hibernate.dao;

/**
 * @author JK00423295
 *
 */
import java.io.Serializable;
import java.util.Set;

public class IdSpace implements Cloneable, Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected transient int hashCode;
	String name;
	protected long seed;
	long lastSeed;
	int batchSize;
	int idsPerBatch;
	String prefix;
	String suffix;
	Set usedLongIds;

	public IdSpace() {
		this.hashCode = 0;

		this.name = null;

		this.seed = 0L;

		this.lastSeed = -1L;

		this.batchSize = 100000;
	}

	public IdSpace(String pName, long pSeed) {
		this.hashCode = 0;

		this.name = null;

		this.seed = 0L;

		this.lastSeed = -1L;

		this.batchSize = 100000;

		setName(pName);
		setSeed(pSeed);
	}

	public IdSpace(String pName, long pSeed, String pPrefix, String pSuffix) {
		this(pName, pSeed);
		this.prefix = pPrefix;
		this.suffix = pSuffix;
	}

	public IdSpace(String pName, long pSeed, int pBatchSize, String pPrefix,
			String pSuffix) {
		this(pName, pSeed, pPrefix, pSuffix);
		this.batchSize = pBatchSize;
	}

	protected IdSpace(String pName, long pSeed, long pLastSeed, int pBatchSize,
			String pPrefix, String pSuffix) {
		this(pName, pSeed, pBatchSize, pPrefix, pSuffix);
		this.lastSeed = pLastSeed;
	}

	public String getName() {
		return this.name;
	}

	void setName(String pName) {
		this.name = pName;

		if (this.name == null)
			this.hashCode = 0;
		else
			this.hashCode = this.name.hashCode();
	}

	public long getSeed() {
		return this.seed;
	}

	public void setSeed(long pSeed) {
		this.seed = pSeed;
	}

	public long getLastSeed() {
		return this.lastSeed;
	}

	public void setLastSeed(long pLastSeed) {
		this.lastSeed = pLastSeed;
	}

	public void setBatchSize(int pBatchSize) {
		this.batchSize = pBatchSize;
	}

	public int getBatchSize() {
		return this.batchSize;
	}

	public void setIdsPerBatch(int pIdsPerBatch) {
		this.idsPerBatch = pIdsPerBatch;
	}

	public int getIdsPerBatch() {
		return this.idsPerBatch;
	}

	public void setPrefix(String pPrefix) {
		this.prefix = pPrefix;
	}

	public String getPrefix() {
		return this.prefix;
	}

	public void setSuffix(String pSuffix) {
		this.suffix = pSuffix;
	}

	public String getSuffix() {
		return this.suffix;
	}

	public void setUsedLongIds(Set pUsedLongIds) {
		this.usedLongIds = pUsedLongIds;
	}

	public Set getUsedLongIds() {
		return this.usedLongIds;
	}

	public int hashCode() {
		return this.hashCode;
	}

	public boolean equals(Object pOther) {
		if (pOther == null) {
			return false;
		}
		IdSpace o;
		try {
			o = (IdSpace) pOther;
		} catch (ClassCastException cce) {
			return false;
		}
		if (getName() == null) {
			return (o.getName() == null);
		}
		return getName().equals(o.getName());
	}

	public String toString() {
		return "IdSpace(" + this.name + ',' + this.seed + ','
				+ this.lastSeed + ',' + this.batchSize + ','
				+ this.idsPerBatch + ',' + this.prefix + ',' + this.suffix
				+ ')';
	}

	public Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException impossible) {
			throw new InternalError();
		}
	}

	public void copyFrom(IdSpace pOther) {
		setName(pOther.getName());
		setSeed(pOther.getSeed());
		setBatchSize(pOther.getBatchSize());
		setPrefix(pOther.getPrefix());
		setSuffix(pOther.getSuffix());
		setLastSeed(pOther.getLastSeed());
	}
}