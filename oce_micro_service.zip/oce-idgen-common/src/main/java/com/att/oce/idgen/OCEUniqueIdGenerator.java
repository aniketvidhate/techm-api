/**
 * 
 */
package com.att.oce.idgen;

import com.att.oce.idgen.hibernate.dao.IdSpace;


/**
 * @author JK00423295
 *
 */
public interface OCEUniqueIdGenerator {

	public abstract IdSpace getDefaultIdSpace();

	public abstract long generateLongId() throws Exception;

	public abstract String generateStringId() throws Exception;
}
