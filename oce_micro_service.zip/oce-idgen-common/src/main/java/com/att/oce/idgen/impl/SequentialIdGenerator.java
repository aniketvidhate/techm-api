package com.att.oce.idgen.impl;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.att.oce.idgen.OCEUniqueIdGenerator;
import com.att.oce.idgen.hibernate.dao.IdSpace;
import com.att.oce.idgen.hibernate.dao.OCEIdGeneratorDAOImpl;

/**
 * @author JK00423295
 *
 */
@Component
public class SequentialIdGenerator implements OCEUniqueIdGenerator {


	@Autowired(required = true)
	@Qualifier("idgenTemplate")
	private HibernateTemplate hTemplate;

	@Autowired
	private OCEIdGeneratorDAOImpl idGeneratorDAOImpl;


	protected static int STATE_NEW = 0;
	protected static int STATE_INITIALIZING = 1;
	protected static int STATE_RUNNING = 2;
	protected static int STATE_ERROR = 3;
	protected static String ERR_HWM_BAD_STATE = "ERR_HWM_BAD_STATE";
	protected static String ERR_HWM_FAIL = "ERR_HWM_FAIL";
	protected static String ERR_NULL_DS = "ERR_NULL_DS";
	protected static String ERR_QUERY_TABLE = "ERR_QUERY_TABLE";
	protected static String ERR_RESERVE_BAD_STATE = "ERR_RESERVE_BAD_STATE";
	protected static String ERR_UNSUPPORTED = "ERR_UNSUPPORTED";
	protected static String ERR_BAD_SPACE = "ERR_BAD_SPACE";
	protected static String ERR_ROLLBACK = "ERR_ROLLBACK";
	public static float MAX_DENSITY = 0.1F;
	protected static String ERR_TOO_DENSE = "ERR_TOO_DENSE";
	protected static String ERR_ADD_NULL_SPACE = "ERR_ADD_NULL_SPACE";
	protected static String ERR_ADD_BAD_STATE = "ERR_ADD_BAD_STATE";
	@SuppressWarnings("unused")
	private int mState = 0;

	@SuppressWarnings("unused")
	private SessionFactory sessionFactory;
	private Logger logger = LoggerFactory.getLogger(SequentialIdGenerator.class);

	private IdSpace mDefaultIdSpace;
	private String mDefaultIdSpaceName = "__default__";
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected Map mSpaces = Collections.synchronizedMap(new HashMap(89));
	private boolean mAutoCreate = true;

	public SequentialIdGenerator() {

	}
	public SequentialIdGenerator(String pDefaultSpaceName) {
		mDefaultIdSpaceName = pDefaultSpaceName;
	}

	/**
	 * @return the mAutoCreate
	 */
	public boolean isAutoCreate() {
		return mAutoCreate;
	}

	/**
	 * @param pAutoCreate the mAutoCreate to set
	 */
	public void setAutoCreate(boolean pAutoCreate) {
		this.mAutoCreate = pAutoCreate;
	}

	/**
	 * @return the mDefaultIdSpaceName
	 */
	public String getDefaultIdSpaceName() {

		return mDefaultIdSpaceName;
	}

	/**
	 * @param pDefaultIdSpaceName the mDefaultIdSpaceName to set
	 */
	public void setmDefaultIdSpaceName(String pDefaultIdSpaceName) {
		this.mDefaultIdSpaceName = pDefaultIdSpaceName;
	}

	/**
	 * @return the mDefaultIdSpace
	 */
	public IdSpace getDefaultIdSpace() {
		return mDefaultIdSpace;
	}

	/**
	 * @param pDefaultIdSpace the mDefaultIdSpace to set
	 */
	public void setDefaultIdSpace(IdSpace pDefaultIdSpace) {
		this.mDefaultIdSpace = pDefaultIdSpace;
	}

	@Override
	public long generateLongId() {
		return generateLongId(idGeneratorDAOImpl.getIdSpaceName());
	}

	/**
	 * This method generate Unique String Id.
	 * @param pIdSpaceName
	 * @return
	 */
	private long generateLongId(String pIdSpaceName) {
		IdSpace space;
		try {
			if (pIdSpaceName == null) {
				space = getDefaultIdSpace();
			} else {
				synchronized (this.mSpaces) {
					space = (IdSpace) this.mSpaces.get(pIdSpaceName);

					if ((space == null) && (isAutoCreate())) {

						space = new IdSpace(pIdSpaceName, 1l);
						addIdSpace(space);

						space = (IdSpace) this.mSpaces.get(pIdSpaceName);
					}
				}
			}

			if (space == null) {
				throw new Exception("null id space");
			}


			long answer = getLongId(space);

			return postGenerateLongId(pIdSpaceName, answer);

		} catch(Exception e) {
			e.printStackTrace();
		}
		return 0;

	}

	/**
	 * This method update seed in id generator table and initialises IDSpace.
	 * @param pSpace
	 * @return
	 * @throws IdGeneratorException
	 */
	protected boolean addPersistentIdSpace(IdSpace pSpace)
			throws IdGeneratorException {

		Session session = null;
		IdGeneratorException error = null;
		boolean status = false;

		try
		{
			session = hTemplate.getSessionFactory().openSession();
			session.beginTransaction();
			try
			{
				Query updateQry = session.createQuery("UPDATE OCEIdgenerator SET seed = seed + batchSize WHERE idSpaceName = :idSpaceName");
				updateQry.setParameter("idSpaceName", pSpace.getName());
				int updateInt = updateQry.executeUpdate();

				Query selectQry = session.createQuery("SELECT seed, batchSize, prefix,suffix  FROM OCEIdgenerator WHERE idSpaceName = :idSpaceName");
				selectQry.setParameter("idSpaceName", pSpace.getName());

				List<Object> l = selectQry.list();
				if (l.size() > 0 && null != l) {
					logger.debug("Total Number Of Records : "+l.size());
					Map<String, Object> idgenMap = new HashMap<String,Object>();
					for (Object obj : l) {
						if (obj instanceof Object[]) {
							Object o[] = (Object[])obj;

							idgenMap.put("SEED", o[0]);
							pSpace.setSeed((Long.valueOf(o[0].toString())));
							idgenMap.put("BATCH_SIZE", o[1]);
							pSpace.setBatchSize((Integer.valueOf(o[1].toString())));
							idgenMap.put("PREFIX", o[2]);
							pSpace.setPrefix((String) o[2]);
							idgenMap.put("SUFFIX", o[3]);
							pSpace.setSuffix((String) o[3]);

							pSpace.setLastSeed(pSpace.getSeed() + pSpace.getBatchSize() - 1L);
						}
					}
					status = true;
				}
				else {
					String insertStatement = "Insert into OCEIdgenerator (idSpaceName,SEED,batchSize,PREFIX,SUFFIX) values (:spaceName,:seed,:batchSize,:prefix,:suffix)";

					Query insertQuery = session.createQuery(insertStatement);
					insertQuery.setParameter("spaceName", pSpace.getName());
					insertQuery.setParameter("seed", pSpace.getSeed());
					insertQuery.setParameter("batchSize", pSpace.getBatchSize());
					insertQuery.setParameter("prefix", pSpace.getPrefix());
					insertQuery.setParameter("suffix", pSpace.getSuffix());

					int inserted = insertQuery.executeUpdate();
					status = true;
				}
				session.getTransaction().commit();
			}
			catch (HibernateException sqle)
			{
				error = new IdGeneratorException(sqle);
			}


		}
		catch (HibernateException e2)
		{
			if (error == null) {
				error = new IdGeneratorException(e2);
			}
		}
		finally
		{
			try
			{
				session.close();

			}
			catch (HibernateException e2)
			{
				if (error == null) {
					error = new IdGeneratorException(e2);
				}
			}

		}

		if (error != null)
		{
			setState(STATE_ERROR);
			throw error;

		}

		return status;
	}
	/**
	 * This method updates IDSpace
	 * @param pSpace
	 * @return
	 * @throws Exception
	 */
	public boolean addIdSpace(IdSpace pSpace) throws Exception {
		if (pSpace == null) {
			throw new Exception("attempt to add null space");
		}
		String name = pSpace.getName();

		try {
			pSpace.setSeed(idGeneratorDAOImpl.getSeed());
			pSpace.setBatchSize((int) idGeneratorDAOImpl.getBatchSize());
			pSpace.setSuffix(idGeneratorDAOImpl.getSuffix());
			pSpace.setPrefix(idGeneratorDAOImpl.getPrefix());
			pSpace.setLastSeed(idGeneratorDAOImpl.getLastSeed());
			//logger.debug("Object saved successfully.....!!");

			synchronized (this.mSpaces) {
				if (this.mSpaces.containsKey(name)) {
					return false;
				}
				this.mSpaces.put(name, pSpace);
				return true;
			} 
		}catch (Exception e) {
			throw e;
		}
	}

	/**
	 * This method is generating unique String ID based on the IDSpace seed value.
	 * @param pSpace
	 * @return
	 * @throws Exception
	 */
	String getStringId(IdSpace pSpace) throws Exception {
		long longValue;
		String prefix;
		String suffix;
		synchronized (pSpace) {
			longValue = getLongId(pSpace);
			prefix = pSpace.getPrefix();
			suffix = pSpace.getSuffix();
		}

		String answer = longToString(longValue);

		if ((prefix != null) || (suffix != null)) {
			StringBuffer sb = new StringBuffer(answer.length() + 20);

			if (prefix != null) {
				sb.append(prefix);
			}

			sb.append(answer);

			if (suffix != null) {
				sb.append(suffix);
			}

			answer = sb.toString();
		}

		return answer;
	}

	String longToString(long pLong) {
		return String.valueOf(pLong);
	}

	/**
	 * This method gives unique Long ID.
	 * @param pSpace
	 * @return
	 * @throws IdGeneratorException
	 */
	long getLongId(IdSpace pSpace) throws IdGeneratorException {
		long seed;
		synchronized (pSpace) {
			seed = pSpace.getSeed();
			long lastSeed = pSpace.getLastSeed();

			if (seed > lastSeed) {
				reserveSeeds(pSpace);
				seed = pSpace.getSeed();
			}

			pSpace.setSeed(seed + 1L);
		}

		return seed;
	}
	/**
	 * This is returning candidate ID.
	 * @param pIdSpaceName
	 * @param pCandidateId
	 * @return
	 * @throws Exception
	 */
	protected long postGenerateLongId(String pIdSpaceName, long pCandidateId)
			throws Exception {
		return pCandidateId;
	}

	//String Id generation :::

	@Override
	public String generateStringId() throws Exception {
		return generateStringId(idGeneratorDAOImpl.getIdSpaceName());
	}

	/**
	 * 
	 * @param pIdSpaceName
	 * @return : String
	 * @throws Exception
	 */
	public String generateStringId(String pIdSpaceName)
			throws Exception {
		IdSpace space;
		if (pIdSpaceName == null) {
			space = getDefaultIdSpace();
		} else {
			space = (IdSpace) this.mSpaces.get(pIdSpaceName);

			if ((space == null) && (isAutoCreate())) {
				space = new IdSpace(pIdSpaceName, 1L);
				addIdSpace(space);
			}
		}
		if (space == null) {
			throw new Exception("null id space");
		}
		logger.debug("generateStringId, space before=" + space);

		String answer = getStringId(space);

		logger.debug("generateStringId, id=" + answer + "space after=" + space);

		return postGenerateStringId(pIdSpaceName, answer);
	}
	/**
	 * 
	 * @param pIdSpaceName
	 * @param pCandidateId
	 * @return : long
	 * @throws Exception
	 */
	protected String postGenerateStringId(String pIdSpaceName,
			String pCandidateId) throws Exception {
		return pCandidateId;
	}

	/**
	 * 
	 * @param pSpace
	 * @throws IdGeneratorException
	 */
	protected void reserveSeeds(IdSpace pSpace) throws IdGeneratorException {
		
		IdSpace originalSpace = (IdSpace)pSpace.clone();

		Session session = hTemplate.getSessionFactory().openSession();

		//TransactionDemarcation td = new TransactionDemarcation();
		IdGeneratorException error = null;

		try
		{
			int mode = 4;
			if ((pSpace.getBatchSize() == 1) /*&& (getUseRequiredTransactionMode()*/) {
				mode = 3;
			}
			session.beginTransaction();

			try
			{
				//Updating ID Generator Table.
				Query updateQry = session.createQuery("UPDATE OCEIdgenerator SET seed = seed + batchSize WHERE idSpaceName = :idSpaceName");
				updateQry.setParameter("idSpaceName", pSpace.getName());
				int updateInt = updateQry.executeUpdate();
				//Getting ID Generator Table.
				Query selectQry = session.createQuery("SELECT seed, batchSize, prefix,suffix  FROM OCEIdgenerator WHERE idSpaceName = :idSpaceName");
				selectQry.setParameter("idSpaceName", pSpace.getName());


				List<Object> l = selectQry.list();
				logger.debug("Total Number Of Records : "+l.size());
				Map<String, Object> idgenMap = new HashMap<String,Object>();
				for (Object obj : l) {
					if (obj instanceof Object[]) {
						Object o[] = (Object[])obj;

						//idgenMap.put("ID_SPACE_NAME", o[0]);
						//setIdSpaceName((String) o[0]);
						idgenMap.put("SEED", o[0]);
						pSpace.setSeed((Long.valueOf(o[0].toString())));
						idgenMap.put("BATCH_SIZE", o[1]);
						pSpace.setBatchSize((Integer.valueOf(o[1].toString())));
						idgenMap.put("PREFIX", o[2]);
						pSpace.setPrefix((String) o[2]);
						idgenMap.put("SUFFIX", o[3]);
						pSpace.setSuffix((String) o[3]);

						pSpace.setLastSeed(pSpace.getSeed() + pSpace.getBatchSize() - 1L);
					}
				}
				session.getTransaction().commit();
			}
			catch (HibernateException sqle)
			{
				pSpace.copyFrom(originalSpace);
				error = new IdGeneratorException(sqle);
			}
			finally
			{
				session.close();
			}

		} catch (HibernateException e2)
		{
			pSpace.copyFrom(originalSpace);

			if (error == null) {
				error = new IdGeneratorException("exception");
			}
		}


		if (error == null)
			return;
		setState(STATE_ERROR);
		pSpace.copyFrom(originalSpace);
		throw error;
	}


	/**
	 * 
	 * @param pMsgKey
	 * @param pArg
	 * @return
	 */
	public static String format(String pMsgKey, Object pArg)
	{
		Object[] a = { pArg };
		System.out.println("format(" + pMsgKey + "," + pArg);
		return format(pMsgKey, a);
	}
	/**
	 * 
	 * @param pMsgKey
	 * @return
	 */
	public static String format(String pMsgKey)
	{
		return format(pMsgKey, null);
	}

	/**
	 * 
	 * @param pState
	 */
	protected final void setState(int pState)
	{
		synchronized (this.mSpaces)
		{
			this.mState = pState;
		}
	}

	/**
	 * 
	 * @throws IdGeneratorException
	 */
	public void initialize() throws IdGeneratorException {
		synchronized (this.mSpaces){
			removeAllIdSpaces();

			if (getDefaultIdSpace() == null) {
				setDefaultIdSpace(new IdSpace(getDefaultIdSpaceName(), 1L));
			}

			//addIdSpace(getDefaultIdSpace());
		}
	}

	public void removeAllIdSpaces() throws IdGeneratorException {
		this.mSpaces.clear();
	}
}