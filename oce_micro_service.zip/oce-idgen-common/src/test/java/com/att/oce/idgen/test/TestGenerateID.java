package com.att.oce.idgen.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.att.oce.idgen.OCEUniqueIdGenerator;
import com.att.oce.idgen.hibernate.dao.OCEIdGeneratorDAOImpl;


/**
 * @author JK00423295
 *
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:/com/att/oce/idgen/test/OCEIdgenBeanTest.xml")
public class TestGenerateID {

	private Logger logger = LoggerFactory.getLogger(OCEIdGeneratorDAOImpl.class);
	@Autowired
	OCEUniqueIdGenerator idGenerator;
	
	@Test
	public void TestidGenerator() {

		try {
	        //long id = idGenerator.generateLongId();
			//logger.info(Unique Long id = " + id);
			for (int i=0; i<=22; i++) {
				String uniqueId = idGenerator.generateStringId();
				logger.info("UniqueId = " + uniqueId);
				System.out.println(uniqueId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
