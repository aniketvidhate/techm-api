package com.att.oce.test.task;

import static org.junit.Assert.*;

import org.junit.Test;

public class TaskServiceTest{

	@Test
	public void test123() {
		assert(true);
		System.out.println("running");
		//fail("Not yet implemented");
	}

}
