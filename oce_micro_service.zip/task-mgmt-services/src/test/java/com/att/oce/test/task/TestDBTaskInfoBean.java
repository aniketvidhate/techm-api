package com.att.oce.test.task;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.service.task.Bean.DBTaskInfoBean;
import com.att.oce.service.task.VO.TaskDetailsVO;

@Category(DBIntegrationTest.class)
public class TestDBTaskInfoBean extends TaskMgmtBaseTest{

	@Autowired
	DBTaskInfoBean dbTaskInfoBean;
	

	//Commented test. as it scan all tables and print. to reduce build timing. whenever required need to uncomment and test eact test case
	
	@Test
	public void testInitialize() {
		try {
			//dbTaskInfoBean.initialize(null);
			System.out.println("Testing testInitialize taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}
	

	

	//@Test
	public void testFetchAllTasks() {
		try {
			Collection<TaskDetailsVO> tasks = dbTaskInfoBean.fetchAllTasks();
			for(TaskDetailsVO vo: tasks) {
				System.out.println("Task Details are : " +vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}

	}

	//@Test
	public void testFetchAllOpenTask() {
		try {
			Collection<TaskDetailsVO> result = dbTaskInfoBean.fetchAllOpenTask();
			assertFalse(result.isEmpty());
			for(TaskDetailsVO vo: result) {
				System.out.println("VO: " +vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}

	//@Test
	public void testFetchAllOpenTasksIds() {
		try {
			Collection<String> taskIdList = dbTaskInfoBean.fetchAllOpenTasksIds();
			for(String id: taskIdList)
			{
				System.out.println("taskIdList-----------"+id);
			}
			System.out.println("Testing testFetchAllOpenTasksIds taskInfoBeanImpl completed successfully"+taskIdList);
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}
	
	//@Test
	public void testCreateTask() {
		try {
			List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetailsVO = dbsimulator.getTestTaskDetailsVO(1);
			tskList.add(taskDetailsVO);
			dbTaskInfoBean.createTasks(tskList);
			System.out.println("Testing testCreateTask taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}

	//@Test
	public void test_a_UpdateTask() {
		try {
			List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetailsVO = dbsimulator.getTestTaskDetailsVO(1);
			tskList.add(taskDetailsVO);
			dbTaskInfoBean.updateTasks(tskList);
			System.out
					.println("Testing testUpdateTask taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}

	

	//@Test
	public void testGetTaskInfo() {
		try {
			TaskDetailsVO taskDetailsVO = dbsimulator.getTestTaskDetailsVO(1);
			taskDetailsVO=dbTaskInfoBean.getTaskDetails(taskDetailsVO.getTaskId());
			if(null!=taskDetailsVO){
			System.out.println("taskDetailsVO task id------"+taskDetailsVO.getTaskId()+"taskDetailsVO retry attempt------"+taskDetailsVO.getTaskRetryAttempt());
			}
			else{
				System.out.println("No record was found..");
			}
			System.out.println("Testing createTasks taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
		
	}

}