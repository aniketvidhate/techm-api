package com.att.oce.test.task;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.service.task.Bean.OrderCountStatusBean;
import com.att.oce.service.task.Bean.request.ProgramCountRequest;
import com.att.oce.service.task.VO.OrderCountStatusKey;
import com.att.oce.service.task.VO.OrderCountStatusValue;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.ooce.core.CtFallout.Fallout;
import com.att.ooce.core.OrderQueueResponse;


/**
 * The Class TestOrderCountStatusBean.
 */
public class TestOrderCountStatusBean extends TaskMgmtBaseTest {

	/** The ordr cnt sts bean. */
	@Autowired
	OrderCountStatusBean ordrCntStsBean;
	//OrderCountStatusBean orderCountStatusBean;


	/**
	 * Test b create task.
	 */
	@Test
	public void test_b_CreateTask() {
		try {
			// need to fix this
			System.out.println("pass");
			/*List<TaskDetailsVO> taskDetailsList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
			taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(2);
			taskDetailsList.add(taskDetailsVO1);
			ordrCntStsBean.createTasks(taskDetailsList);
			System.out.println("Testing testFetchAllTasks taskInfoBeanImpl completed successfully");*/
		} catch (Exception e) {
			e.printStackTrace(); 
			fail("testInitialize failed");
		}

	}
	/**
	 * Test get queue items by channel.
	 */
	//@Test
	public void test_e_getQueueItemsByChannel() {
		TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
		test_b_CreateTask();
		OrderCountStatusKey ordCntKey = new OrderCountStatusKey(taskDetailsVO1);
		List<OrderCountStatusKey> ordCntKeyList = new ArrayList<OrderCountStatusKey>();
		ordCntKeyList.add(ordCntKey);
		ProgramCountRequest request = new ProgramCountRequest();
		List<String> orgUnitList = new ArrayList<String>();
		orgUnitList.add("UNLOCK1");
		List<String> partnerList = new ArrayList<String>();
		partnerList.add("ATT");
		List<String> queueTypeList = new ArrayList<String>();
		queueTypeList.add("BULK_UNLOCK_QUEUE");
		queueTypeList.add("NOKIA");
		request.setOrgUnitList(orgUnitList);
		request.setPartnerList(partnerList);
		request.setQueueTypeList(queueTypeList);
		request.setGlobalVisible(true);
		request.setCallbackPreference("callbackPreference");
		request.setQueueOrProgram("programName");
		String queueInputType = "OUTBOUND";
		request.setQueueInputType(queueInputType);
		ordrCntStsBean.getQueueItemsByChannel(request);
	}
	
	/**
	 * Test get outbound items by channel.
	 */
	//@Test
	public void test_d_getOutBoundItemsByChannel() {
		TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
		test_b_CreateTask();
		OrderCountStatusKey ordCntKey = new OrderCountStatusKey(taskDetailsVO1);
		List<OrderCountStatusKey> ordCntKeyList = new ArrayList<OrderCountStatusKey>();
		ordCntKeyList.add(ordCntKey);
		ProgramCountRequest request = new ProgramCountRequest();
		List<String> orgUnitList = new ArrayList<String>();
		orgUnitList.add("UNLOCK1");
		List<String> partnerList = new ArrayList<String>();
		partnerList.add("ATT");
		List<String> queueTypeList = new ArrayList<String>();
		queueTypeList.add("BULK_UNLOCK_QUEUE");
		queueTypeList.add("NOKIA");
		request.setOrgUnitList(orgUnitList);
		request.setPartnerList(partnerList);
		request.setQueueTypeList(queueTypeList);
		request.setGlobalVisible(true);
		request.setCallbackPreference("callbackPreference");
		request.setQueueOrProgram("programName");
		String queueInputType = "OUTBOUND";
		request.setQueueInputType(queueInputType);
		ordrCntStsBean.getOutBoundItemsByChannel(request);
	}
	

	/**
	 * Test c update tasks.
	 */
	//@Test
	public void test_c_UpdateTasks() {
		try {
			List<TaskDetailsVO> taskDetailsList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
			taskDetailsList.add(taskDetailsVO1);
			ordrCntStsBean.updateTasks(taskDetailsList);
			System.out.println("Testing testFetchAllOpenTask taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}
	
	/**
	 * Test get program count.
	 */
	//@Test
	public void test_f_getProgramCount(){
		TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
		test_b_CreateTask();
		OrderCountStatusKey ordCntKey = new OrderCountStatusKey(taskDetailsVO1);
		List<OrderCountStatusKey> ordCntKeyList = new ArrayList<OrderCountStatusKey>();
		ordCntKeyList.add(ordCntKey);
		ProgramCountRequest request = new ProgramCountRequest();
		List<String> orgUnitList = new ArrayList<String>();
		orgUnitList.add("UNLOCK1");
		List<String> partnerList = new ArrayList<String>();
		partnerList.add("ATT");
		List<String> queueTypeList = new ArrayList<String>();
		queueTypeList.add("BULK_UNLOCK_QUEUE");
		queueTypeList.add("NOKIA");
		request.setOrgUnitList(orgUnitList);
		request.setPartnerList(partnerList);
		request.setQueueTypeList(queueTypeList);
		request.setGlobalVisible(true);
		request.setCallbackPreference("callbackPreference");
		request.setQueueOrProgram("programName");
		String queueInputType = "OUTBOUND";
		request.setQueueInputType(queueInputType);
		List<Fallout> programCount = ordrCntStsBean.getProgramCount(request);
		Assert.assertNotNull(programCount);
	}
	
	/**
	 * Test get total order count.
	 */
	//@Test
	public void test_g_getTotalOrderCount(){
		TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
		test_b_CreateTask();
		OrderCountStatusKey ordCntKey = new OrderCountStatusKey(taskDetailsVO1);
		List<OrderCountStatusKey> ordCntKeyList = new ArrayList<OrderCountStatusKey>();
		ordCntKeyList.add(ordCntKey);
		ProgramCountRequest request = new ProgramCountRequest();
		List<String> orgUnitList = new ArrayList<String>();
		orgUnitList.add("UNLOCK1");
		List<String> partnerList = new ArrayList<String>();
		partnerList.add("ATT");
		List<String> queueTypeList = new ArrayList<String>();
		queueTypeList.add("BULK_UNLOCK_QUEUE");
		queueTypeList.add("NOKIA");
		request.setOrgUnitList(orgUnitList);
		request.setPartnerList(partnerList);
		request.setQueueTypeList(queueTypeList);
		request.setGlobalVisible(true);
		request.setCallbackPreference("callbackPreference");
		request.setQueueOrProgram("programName");
		String queueInputType = "OUTBOUND";
		request.setQueueInputType(queueInputType);
		boolean isWirelessFalloutOrder =false;
		Long totalOrderCount = ordrCntStsBean.getTotalOrderCount(request, isWirelessFalloutOrder);
		Assert.assertEquals(Long.valueOf(2l), totalOrderCount);
	}

	/**
	 * Test a initialize.
	 */
	//@Before
	public void test_a_Initialize() {
		try {
			List<TaskDetailsVO> taskDetailsList = dbsimulator.getTestTaskDetailsVOList();
			ordrCntStsBean.initialize(taskDetailsList);
			System.out.println("Testing testInitialize taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}
	
	/**
	 * Test total order count with fallout lists.
	 */
	//@Test
	public void test_h_fetchOrderQueueCount(){
		TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
		OrderQueueResponse orderQueueResponse =new OrderQueueResponse();
		test_b_CreateTask();
		OrderCountStatusKey ordCntKey = new OrderCountStatusKey(taskDetailsVO1);
		List<OrderCountStatusKey> ordCntKeyList = new ArrayList<OrderCountStatusKey>();
		ordCntKeyList.add(ordCntKey);
		ProgramCountRequest request = new ProgramCountRequest();
		List<String> orgUnitList = new ArrayList<String>();
		orgUnitList.add("UNLOCK1");
		List<String> partnerList = new ArrayList<String>();
		partnerList.add("ATT");
		List<String> queueTypeList = new ArrayList<String>();
		queueTypeList.add("BULK_UNLOCK_QUEUE");
		queueTypeList.add("NOKIA");
		request.setOrgUnitList(orgUnitList);
		request.setPartnerList(partnerList);
		request.setQueueTypeList(queueTypeList);
		request.setGlobalVisible(true);
		request.setCallbackPreference("callbackPreference");
		request.setQueueOrProgram("programName");
		String queueInputType = "OUTBOUND";
		request.setQueueInputType(queueInputType);
		request.setRequestType("UP");
		orderQueueResponse = ordrCntStsBean.fetchOrderQueueCount(request);
	}
}