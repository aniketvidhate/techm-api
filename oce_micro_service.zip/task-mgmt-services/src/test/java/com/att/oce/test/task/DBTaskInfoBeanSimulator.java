package com.att.oce.test.task;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.TaskConstants;

import reactor.bus.Event;
import reactor.bus.EventBus;
import reactor.fn.Consumer;

public class DBTaskInfoBeanSimulator implements Consumer<Event<List<TaskDetailsVO>>> {

	private EventBus eventBus;

	public void setEventBus(EventBus pEventBus) {
		this.eventBus = pEventBus;
	}

	private List<TaskDetailsVO> getTestTaskDetailsVOList(int counterStart, int counterEnd) {

		List<TaskDetailsVO> taskDetailsList = new ArrayList<TaskDetailsVO>();

		for (int i = counterStart; i < counterEnd; i++) {
			TaskDetailsVO taskDetailsVO = this.getTestTaskDetailsVO(i);
			taskDetailsList.add(taskDetailsVO);
		}

		return taskDetailsList;
	}

	public List<TaskDetailsVO> getTestTaskDetailsVOList() {
		return this.getTestTaskDetailsVOList(1, 2);
	}

	public TaskDetailsVO getTestTaskDetailsVO(int i) {

		TaskDetailsVO taskDetailsVO = null;
		List<String> partnerNameList = Arrays.asList("STI", "ATT");
		taskDetailsVO = new TaskDetailsVO();
		taskDetailsVO.setTaskId("TAK123" + String.valueOf(i));
		taskDetailsVO.setTaskStatus(TaskConstants.NEW);
		taskDetailsVO.setTaskSubStatus(("IN_QUEUE"));
		taskDetailsVO.setTaskRetryAttempt(0);
		taskDetailsVO.setdCreationDate(new Date());
		taskDetailsVO.setCreationDate(new Date());
		taskDetailsVO.setLineAction("NEW");
		taskDetailsVO.setLineCombos("INTERNET");
		taskDetailsVO.setOwner("TEST");
		taskDetailsVO.setProgram("GIGAPOWER");
		taskDetailsVO.setQueueType("SCHEDULED_OUTBOUND");
		taskDetailsVO.setQueueInputType("OUTBOUND");
		taskDetailsVO.setChannel("UNLOCK"+i);
		taskDetailsVO.setCsrId("TEST");
		taskDetailsVO.setPartnerName(partnerNameList);
		taskDetailsVO.setAcceptedDate(new Date());
		taskDetailsVO.setAvos_task_id("TAK123" + String.valueOf(i));
		taskDetailsVO.setLast_modified_date(new Date());
		taskDetailsVO.setLosgId("OCEK1520047:dtv,OCEK1520047:uvDTV");
		taskDetailsVO.setOrderRef("OCE1234" + String.valueOf(i));
		taskDetailsVO.setRequestType("UP");
		List<String> orgUnitList = new ArrayList<String>();
		orgUnitList.add("UNLOCK1");
		taskDetailsVO.setOrgUnitList(orgUnitList);
		return taskDetailsVO;
	}

	public List<TaskDetailsVO> fetchAllTasks() throws OCEException {
		System.out.println("DBTaskInfoBeanSimulator >>>> fetchAllTasks is called");
		return this.getTestTaskDetailsVOList(0, 300);
	}

	public List<TaskDetailsVO> fetchAllOpenTask() throws OCEException {
		System.out.println("DBTaskInfoBeanSimulator >>>> fetchAllOpenTask is called");
		return this.getTestTaskDetailsVOList(0, 200);
	}

	public List<String> fetchAllOpenTasksIds() throws OCEException {
		System.out.println("DBTaskInfoBeanSimulator >>>>  fetchAllOpenTasksIds is called");
		List<TaskDetailsVO> tasks = this.fetchAllOpenTask();
		List<String> taskIds = new ArrayList<String>();
		for (TaskDetailsVO vo : tasks) {
			taskIds.add(vo.getTaskId());
		}
		return taskIds;
	}

	public void publishEvent(String eventId, List<TaskDetailsVO> taskDetailsList) {
		eventBus.notify(TaskConstants.TASK_LOADED, Event.wrap(taskDetailsList));
	}

	public void createTasks(List<TaskDetailsVO> tasks) throws OCEException {
		System.out.println("DBTaskInfoBeanSimulator >>>> Create Tasks is called" + tasks);
	}

	public void updateTasks(List<TaskDetailsVO> tasks) throws OCEException {
		System.out.println("DBTaskInfoBeanSimulator >>> updateTasks is called" + tasks);
	}

	public void initialize(List<TaskDetailsVO> list) throws OCEException {
		List<TaskDetailsVO> result = this.fetchAllOpenTask();

		if (result.size() > 0) {
			System.out.println("DBTaskInfoBeanSimulator >>> initialize():: Before publishing detaislList");
			publishEvent(TaskConstants.TASK_LOADED, result);
			System.out.println("DBTaskInfoBeanSimulator >>> initialize():: After publishing detaislList");
		}
	}

	public void accept(Event<List<TaskDetailsVO>> ev) {

		try {
			if (ev.getKey().toString().equals(TaskConstants.TASK_CREATED)) {
				createTasks(ev.getData());
			} else if (ev.getKey().toString().equals(TaskConstants.TASK_UPDATED)) {
				updateTasks(ev.getData());
			}
		} catch (OCEException e) {
			e.printStackTrace();
		}
	}

	public TaskDetailsVO getTaskDetails(String id) throws OCEException {
		TaskDetailsVO retVal = this.getTestTaskDetailsVO(1);
		System.out.println("DBTaskInfoBeanSimulator >>> getTaskDetails():: is called");
		return retVal;
	}

}