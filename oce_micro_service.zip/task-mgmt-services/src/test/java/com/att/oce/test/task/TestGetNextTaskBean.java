package com.att.oce.test.task;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.service.task.Bean.GetNextTaskBean;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;

public class TestGetNextTaskBean extends TaskMgmtBaseTest {

	@Autowired
	GetNextTaskBean getNextTaskBean;

	@Before
	public void testInitialize() {
		try {

			List<TaskDetailsVO> taskDetailsList = dbsimulator.getTestTaskDetailsVOList();
			getNextTaskBean.initialize(taskDetailsList);
			System.out.println("Testing testInitialize taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}

	@Test
	public void testCreateTask() {
		try {
			List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetailsVO = dbsimulator.getTestTaskDetailsVO(1);
			tskList.add(taskDetailsVO);
			getNextTaskBean.createTasks(tskList);
			System.out.println("Testing testCreateTask taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testCreateTask failed");
		}
	}

	@Test
	public void testGetNextTask() {
		try {
			TaskDetailsVO taskDetailsVO = dbsimulator.getTestTaskDetailsVO(1);
			String taskId = getNextTaskBean.getNextTask(taskDetailsVO);
			System.out.println("getNextTask returned : " + taskId);
		} catch (Exception e) {
			e.printStackTrace();
			fail("testGetNextTask failed");
		}
	}

	@After
	public void purgeTestData() {

		try {
			getNextTaskBean.purgeTestData();
		} catch (OCEException e) {
			e.printStackTrace();
		}

		System.out.println("Removed test data from memory");
	}

}