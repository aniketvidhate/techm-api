package com.att.oce.service.task.Bean;

import java.util.List;
import java.util.Set;

import reactor.bus.Event;
import reactor.fn.Consumer;

import com.att.oce.service.task.VO.TaskDetailsVO;

public interface OrderTaskBean  extends BasicTaskBean {
	
	Set getTaskForAnOrder(String OrderId);
	Set getTaskForAnOrderOnStatus(String OrderId,String status);
	String getTaskforAnUpdate(String Orderid,String AvosRefId);

}
