package com.att.oce.service.task.util;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class CalenderUtils {
  
	public static Date gstDate() throws ParseException{
		
		TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
		Calendar cal=Calendar.getInstance(TimeZone.getDefault());
		Date dateGMT=cal.getTime();
		return dateGMT;	
	}
	
}
