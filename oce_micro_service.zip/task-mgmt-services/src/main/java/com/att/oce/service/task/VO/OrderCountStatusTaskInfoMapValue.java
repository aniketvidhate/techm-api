package com.att.oce.service.task.VO;

public class OrderCountStatusTaskInfoMapValue {

	private OrderCountStatusKey key = null;
	private BasicTaskDetailsVO taskInfo = null;
	
	private OrderCountStatusTaskInfoMapValue() { }
	
	public OrderCountStatusTaskInfoMapValue(TaskDetailsVO task) {
		this();
		this.key = new OrderCountStatusKey(task);
		this.taskInfo = new BasicTaskDetailsVO(task);
	}

	/**
	 * @return the key
	 */
	public OrderCountStatusKey getKey() {
		return key;
	}

	/**
	 * @return the taskInfo
	 */
	public BasicTaskDetailsVO getTaskInfo() {
		return this.taskInfo;
	}

}
