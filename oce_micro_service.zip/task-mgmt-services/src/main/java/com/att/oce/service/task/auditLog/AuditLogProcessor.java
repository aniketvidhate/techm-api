package com.att.oce.service.task.auditLog;

import java.util.Calendar;
import java.util.Properties;
import java.util.UUID;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.att.oce.dblog.util.AuditLog;
import com.att.oce.dblog.util.AuditLogUtil;
import com.att.oce.dblog.util.OCEManager;

/**
 * 
 *  This class is responsible for Auditing of all request and response
 *
 */
public class AuditLogProcessor implements Processor {
	
	String brokerURL;
	String mqUsername;
	String mqPassword;
	String queueName;
	String dbURL;
	
	
	String dbUsername;
	public String getDbUsername() {
		return dbUsername;
	}

	public void setDbUsername(String dbUsername) {
		this.dbUsername = dbUsername;
	}

	public String getDbPassword() {
		return dbPassword;
	}

	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}


	String dbPassword;
	
	
	
	public String getBrokerURL() {
		return brokerURL;
	}

	public void setBrokerURL(String brokerURL) {
		this.brokerURL = brokerURL;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getDbURL() {
		return dbURL;
	}

	public void setDbURL(String dbURL) {
		this.dbURL = dbURL;
	}

	public String getMqUsername() {
		return mqUsername;
	}

	public void setMqUsername(String mqUsername) {
		this.mqUsername = mqUsername;
	}

	public String getMqPassword() {
		return mqPassword;
	}

	public void setMqPassword(String mqPassword) {
		this.mqPassword = mqPassword;
	}


	@Override
	public void process(Exchange exchange) throws Exception {
		
		Object ReqRespFlag = null;
		String body = exchange.getIn().getBody(String.class);
		
		ReqRespFlag = exchange.getIn().getHeader("isResponse");
		//CtOrderTask orderTask = (CtOrderTask) exchange.getIn().getBody();
		
		
		
		//System.out.println("body ="+body);
		
		AuditLog auditLog = new AuditLog();
		
		//System.out.println("Preparing audit logs");
		auditLog.setInsertedBy("SYSTEM");
		
		// Request id will be retrieve from payload requestid
		auditLog.setRequestID("requestId");  
		auditLog.setOperationName("INSERT");
		auditLog.setLayer("taskMgmtService"); 
		auditLog.setRequestTime(Calendar.getInstance());  //GMT time not the server local time...
		auditLog.setServiceName("GetNext");
		
		if(ReqRespFlag == null){
			auditLog.setRequest(body);
		} else {
		  auditLog.setResponse(body);
		}
		
		auditLog.setInterfaceName("MicroService");
		//GMT time not the server local time
		auditLog.setInsertedDate(Calendar.getInstance());  
		auditLog.setLogType(1);			
		auditLog.setIsExternal(0);
		auditLog.setCorrelationID(UUID.randomUUID().toString());  
		
		//System.out.println("Preparing mq factory");
		org.apache.activemq.pool.PooledConnectionFactory mQPooledConnectionFactory = null;
		org.apache.commons.dbcp2.BasicDataSource ods = null;
		Properties mqProp = new Properties();
	    
		brokerURL = brokerURL;// + TaskConstants.qSuffix;	
        
		mqProp.setProperty("brokerURL", brokerURL);
		
		mqProp.setProperty("user", mqUsername);
		mqProp.setProperty("password", mqPassword);
		
		mQPooledConnectionFactory = OCEManager.getMQInstance(mqProp);
		
		Properties dbProp = new Properties();
		dbProp.setProperty("dbURL", dbURL);
		dbProp.setProperty("username",dbUsername);
		dbProp.setProperty("password", dbPassword);
		
		dbProp.setProperty("minIdleConn", "5");
		dbProp.setProperty("maxIdleConn", "10");
		dbProp.setProperty("dbInitialSize", "50");
		dbProp.setProperty("dbMaxTotal", "100");
		dbProp.setProperty("dbMaxOpenPreparedStatements","180");
		
		ods = OCEManager.getConnectionPoolInstance(dbProp);
		
		AuditLogUtil auditLogUtil = new AuditLogUtil();
		
		String retStatus = null;
		try {
		System.out.println("Publishing logs");
		retStatus = auditLogUtil.publishLog(auditLog,mQPooledConnectionFactory, ods,queueName);
		} catch(Exception e){
				//e.printStackTrace();
		} catch(Throwable t){
			//	t.printStackTrace();
		}
		
		// This condition is indicator of response. in case of response do not set body
		if(ReqRespFlag == null){
			exchange.getOut().setHeaders(exchange.getIn().getHeaders());
			exchange.getOut().setBody(body);
		}
		
	}

}
