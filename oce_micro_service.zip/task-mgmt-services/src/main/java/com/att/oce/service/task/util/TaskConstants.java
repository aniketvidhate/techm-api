package com.att.oce.service.task.util;

public class TaskConstants {

	public static final String TASK_CREATED = "TASKCREATED";
	public static final String TASK_LOADED = "TASKLOADED";
	public static final String TASK_UPDATED = "TASKUPDATED ";
	public static final String IN_QUEUE = "IN_QUEUE";
	public static final String IN_PROGRESS = "IN_PROGRESS";
	public static final String NEW = "NEW";
	public static final String UNCLAIMED = "UNCLAIMED";
	public static final String REP_PROCESSING = "REP_PROCESSING";
	public static final String FIRST_CALL_QUEUE = "FIRST_CALL_QUEUE";
	public static final String OUTBOUND = "OUTBOUND";
	public static final String OPEN = "OPEN";
	public static final String SYSTEM = "SYSTEM";
	public static final String CRUMOBILITY = "CRU-MOBILITY";
	public static final String SCR = "SCR";
	public static final String NA = "NA";
	public static final String UNLOCK = "UNLOCK";
	public static final String SOR = "SOR";
	public static final String NACKTRIAGE = "NACK TRIAGE";
	public static final String NACK = "NACK";
	public static final String UNKNOWN = "UNKNOWN";
	public static final String WIRELESS =  "WIRELESS";
	public static final String CDEHS =  "CDE-HS";
	public static final String DF =  "DF";
	public static final String DE_MOBILITY = "DE-MOBILITY";
	//Application specific System Properties
	public static final String DMN_FILE_PATH = "DMN_FILE_PATH";
	//public static final String qSuffix="?initialReconnectDelay=30&randomize=false&maxReconnectDelay=500&maxReconnectAttempts=1&backup=true&timeout=1000";
	public static final String qSuffix="?initialReconnectDelay=30&jms.prefetchPolicy.queuePrefetch=1&randomize=false&maxReconnectDelay=500&maxReconnectAttempts=1&backup=true&timeout=1000";
	
	public static final String SLA_RED="slared";
	public static final String SLA_AMBER="slaamber";
	public static final String SLA_GREEN="slagreen";
	public static String TASK_ID_PREFIX = "TAK";
	public static String AVOS_TASK_ID_PREFIX = "M";
	public static final String CRU_PROGRAM_NAME = "CRU";
	
	// Audit log constants
		public static String INSERTED_BY = "SYSTEM";
		public static String OPERATION_NAME = "INSERT";
		public static String LAYER = "taskMgmtService";
		public static String SERVICE_NAME = "GetNext";
		public static String INTERFACE_NAME = "MicroService";
		
		public static String BROKER_URL = "brokerURL";
		public static String BROKER_UNAME = "user";
		public static String BROKER_PWD = "password";
		public static String DB_URL = "dbURL";
		public static String DB_UNAME = "username";
		public static String DB_PWD = "password";
		
	
}
