package com.att.oce.service;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.oce.service.task.Exception.OCEException;

/**
 * The Class DateUtil.
 */
public final class DateUtil { 

	/** The logger. */
	private static Logger logger = LoggerFactory.getLogger(DateUtil.class);
	
	/** The Constant tz. */
	public static final TimeZone tz = TimeZone.getTimeZone("America/Los_Angeles");
	
	/** The Constant gmt. */
	public static final TimeZone gmt = TimeZone.getTimeZone("GMT");
	
	/** The Constant DATEFORMAT. */
	public static final String DATEFORMAT = "dd-MMM-yy HH:mm:ss:SSS";
	
	/**
	 * Instantiates a new date util.
	 */
	private DateUtil() {
	}

	/**
	 * Convert date to string.
	 *
	 * @param format the format
	 * @param date the date
	 * @return the string
	 */
	public static String convertDateToString(String format, Date date)
	{
		String dateAsString = null;
		if(null == format )
		{
			return dateAsString;
		}
		SimpleDateFormat simpleFormatter =new SimpleDateFormat(format);
		dateAsString = simpleFormatter.format(date);
		return dateAsString;
	}
	
	/**
	 * if input time is like  T09:59:47Z this method will convert it to actual Time. 
	 * As we are passing time only , it will consider today date as default. 
	 *
	 * @param timeStamp the time stamp
	 * @return the time based on time stamp
	 */
	public static Date getTimeBasedOnTimeStamp(String timeStamp){
		Date date = null;
		String[] parsePattern = {"'T'HH:mm:ss"};
		try {
			DateUtils.parseDate(timeStamp, parsePattern);
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing time"); 
			}
		}
		return date;
	}
	
	
	/**
	 * Gets the GMT string as date.
	 *
	 * @param timeStamp the time stamp
	 * @return the GMT string as date
	 */
	public static Date getGMTStringAsDate(String timeStamp){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));		
		Date parsedDate = null;
		try {
			parsedDate = dateFormat.parse(timeStamp);
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing time inside getGMTStringAsDate for input string : "+timeStamp); 
			}
		}
		return parsedDate;
	}
	
	/**
	 * get current time as GMT.
	 *
	 * @return the current time as GMT
	 */
	public static Date getCurrentTimeAsGMT(){
		return stringDateToDate(getGMTdatetimeAsString());
	}
	
	/**
	 * Gets the current time as PST.
	 *
	 * @return the current time as PST
	 */
	public static Date getCurrentTimeAsPST(){
		return stringDateToDate(getPSTdatetimeAsString());
	}

	/**
	 * Gets the GM tdatetime as string.
	 *
	 * @return the GM tdatetime as string
	 */
	public static String getGMTdatetimeAsString()
	{
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}

	
	/**
	 * Gets the PS tdatetime as string.
	 *
	 * @return the PS tdatetime as string
	 */
	public static String getPSTdatetimeAsString()
	{
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
		sdf.setTimeZone(TimeZone.getDefault());
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}
	
	
	/**
	 * Gets the GM tdate as string.
	 *
	 * @return the GM tdate as string
	 */
	public static String getGMTdateAsString()
	{
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		final String utcTime;
		utcTime = sdf.format(new Date());
		return utcTime;
	}

	/**
	 * String date to date.
	 *
	 * @param StrDate the str date
	 * @return the date
	 */
	public static Date stringDateToDate(String StrDate)
	{
		Date dateToReturn = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
		try
		{
			dateToReturn = (Date)dateFormat.parse(StrDate);
		}
		catch (ParseException e)
		{
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing GMT time "); 
			}
		}

		return dateToReturn;
	}

	/**
	 * String to date.
	 *
	 * @param StrDate the str date
	 * @return the date
	 */
	public static Date stringToDate(String StrDate)
	{
		Date dateToReturn = null;
		String DATEFORMAT = "dd MMM yyyy hh:mm:ss a";
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
		try
		{
			dateToReturn = (Date)dateFormat.parse(StrDate);
		}
		catch (ParseException e)
		{
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing GMT time "); 
			}
		}

		return dateToReturn;
	}



	/**
	 * if input time is like  2015-05-02T09:59:47Z this method will convert it to actual Date . 
	 *  
	 *
	 * @param dateTimeStamp the date time stamp
	 * @return the date time based on date time stamp
	 */
	public static Date getDateTimeBasedOnDateTimeStamp(String dateTimeStamp){
		Date date = null;
		String[] parsePattern = {"yyyy-MM-dd'T'HH:mm:ss"};
		try {
			DateUtils.parseDate(dateTimeStamp, parsePattern);
		} catch (ParseException e) {
			if(logger.isDebugEnabled()) {
				logger.debug("Error while parsing Date n time"); 
			}
		}
		return date;
	}
	
	/**
	 * if input time is like  T09:59:47Z this method will convert it to actual Date into string time format .
	 * for given example it will convert to 09:59:47
	 *  
	 * delimiter parameter will be used for adding de-limits b/w time like 09:12:12  here : is delimiter.
	 * if nothing is passed default is ":"
	 *
	 * @param timeStamp the time stamp
	 * @param delimiter the delimiter
	 * @return the time as string based on time stamp
	 */
	public static String getTimeAsStringBasedOnTimeStamp(String timeStamp,String delimiter){
		String[] parsePattern = {"'T'HH:mm:ss'Z'"};
		if(StringUtils.isBlank(delimiter)){
			delimiter = ":";
		}
		StringBuilder dateBuilder = new StringBuilder();
		try {
			if(StringUtils.isNotBlank(timeStamp)){
				Date patternDate = DateUtils.parseDate(timeStamp, parsePattern);
				Calendar cal = Calendar.getInstance();
				cal.setTime(patternDate);
				int hour = cal.get(Calendar.HOUR);
				int minute = cal.get(Calendar.MINUTE);

				dateBuilder.append(hour);
				dateBuilder.append(delimiter);
				dateBuilder.append(minute);

				if(cal.get(Calendar.AM_PM)==0){
					dateBuilder.append(" a.m");
				}else{
					dateBuilder.append(" p.m");
				}
			}
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing Date n time"); 
			}
		}
		return dateBuilder.toString();
	}
	
	/**
	 * Convert date string to date.
	 *
	 * @param format the format
	 * @param date the date
	 * @return the date
	 */
	public static Date convertDateStringToDate(String format, String date)
	{
		Date dateAsDate = null;
		if(null == format )
		{
			return dateAsDate;
		}
		SimpleDateFormat simpleFormatter =new SimpleDateFormat(format);
		try {
			dateAsDate = simpleFormatter.parse(date);
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
		}
		return dateAsDate;
	}

	/**
	 * Gets the current date.
	 *
	 * @return the current date
	 */
	public static String getCurrentDate(){
		String toDate=null;
		Date date= new Date();

		SimpleDateFormat simpleformatter =new SimpleDateFormat("dd-MMM-yyyy");
		toDate=simpleformatter.format(date);

		return toDate;
	}

	/**
	 * Gets the current date time.
	 *
	 * @return the current date time
	 */
	public static String getCurrentDateTime(){


		Calendar calendar = Calendar.getInstance();
		java.util.Date now = calendar.getTime();
		java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

		String formattedTimeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz").format(currentTimestamp);


		return formattedTimeStamp;
	}


	/**
	 * This method adds a day to the to date since the date is considered as dd-MMM-yyyy 00:00:00. adding a day covers to whole day.
	 *
	 * @param incomingDate the incoming date
	 * @return the string
	 */
	public static String toDateCalculation(String incomingDate) {
		String toDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");

		try {
			Calendar calendar = GregorianCalendar.getInstance();
			calendar.setTime(formatter.parse(incomingDate));
			calendar.add(Calendar.DATE, 1);
			toDate = formatter.format(calendar.getTime());
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
		}
		return toDate;
	}

	//::Begin :: iteration 35
	
	/**
	 * Format timestamp.
	 *
	 * @param incomingDate the incoming date
	 * @return the string
	 */
	public static String formatTimestamp(String incomingDate) {
		String toDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");
		SimpleDateFormat formattedTimeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");

		//19-Sep-2015 18:35:00
		
		try {
			Calendar calendar = GregorianCalendar.getInstance();
			calendar.setTime(formatter.parse(incomingDate));
			//calendar.add(Calendar.DATE, 1);
			toDate = formattedTimeStamp.format(calendar.getTime());
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
		}
		return toDate;
	}
	
	
	/**
	 * This method returns back date according to parameter received.
	 * means if parameter value is 10 then it'll return 10 days back date 
	 *
	 * @param hrs the hrs
	 * @return the back date based on hrs
	 */
	public static String getBackDateBasedOnHrs(int hrs){
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		///HHmmss
		Calendar cal = Calendar.getInstance();
		
		cal.setTime(getCurrentTimeAsGMT());
		
		cal.add(Calendar.HOUR, -hrs);
		Date backDate = cal.getTime();   
		String fromdate = dateFormat.format(backDate);
		return fromdate;
	}
	
	
	/**
	 * Gets the back date.
	 *
	 * @param noOfDays the no of days
	 * @return the back date
	 */
	public static String getBackDate(int noOfDays){
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -noOfDays);
		Date backDate = cal.getTime();    
		String fromdate = dateFormat.format(backDate);
		return fromdate;
	}


	/**
	 * Gets the tomorrows date.
	 *
	 * @return the tomorrows date
	 */
	public static String getTomorrowsDate(){
		String toDate=null;
		// Add a day to date since even if the format is dd-MMM-yy ATG makes it dd-MMM-yy 00:00:00
		Calendar calendar = GregorianCalendar.getInstance();
		SimpleDateFormat formatter =new SimpleDateFormat("dd-MMM-yy");
		calendar.add(Calendar.DATE, 1);
		toDate=formatter.format(calendar.getTime());
		return toDate;
	}
	
	/**
	 * This method subtracts a day to the to date.
	 *
	 * @param incomingDate the incoming date
	 * @return the yesterday date
	 */
	public static String getYesterdayDate(String incomingDate) {
		String toDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy");

		try {
			Calendar calendar = GregorianCalendar.getInstance();
			calendar.setTime(formatter.parse(incomingDate));
			calendar.add(Calendar.DATE, -1);
			toDate = formatter.format(calendar.getTime());
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
		}
		return toDate;
	}

	//TODO Need to check: Commenting Out for Client Demo
	/**
	 * public static String formatDate(String incomingDate){
	 * 
	 * 		// Get Today's Date in the format is dd-MMM-yy 
	 * 		try {
	 * 			SimpleDateFormat formatter =new SimpleDateFormat("dd-MMM-yyyy");
	 * 
	 * 			SimpleDateFormat requiredFormat =new SimpleDateFormat("dd-MMM-yy");
	 * 
	 * 			Calendar calendar = GregorianCalendar.getInstance();
	 * 			calendar.setTime(formatter.parse(incomingDate));
	 * 			incomingDate = requiredFormat.format(calendar.getTime());
	 * 		}catch (ParseException e) {
	 * 			mlogger.error(e);
	 * 		}
	 * 		return incomingDate;
	 * 	}
	 *
	 * @param toDate the to date
	 * @return the string
	 */

	public static String fromDateCalculation(String toDate) {
		String fromDate=null;

		//TODO Need to check: Changing the format to dd-MMM-yyyy from dd-MMM-yy for Client Demo
		DateFormat formatter =new SimpleDateFormat("dd-MMM-yyyy");
		GregorianCalendar gc = new GregorianCalendar();
		Date currentDate;
		try {
			currentDate = formatter.parse(toDate);

			gc.setTime(currentDate);
			gc.add(Calendar.YEAR, -1);
			Date year = gc.getTime();
			fromDate=formatter.format(year);
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
		}
		return fromDate;	
	}






	/**
	 * From date calculation for day.
	 *
	 * @param toDate the to date
	 * @param day the day
	 * @return the string
	 * @throws OCEException the OCE exception
	 */
	public static String fromDateCalculationForDay(String toDate, int day) throws OCEException{
		String fromDate=null;
		int dayInt = day;
		try{
			dayInt=dayInt-1;
			DateFormat formatter =new SimpleDateFormat("dd-MMM-yy");
			Date currentDate=formatter.parse(toDate);
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTime(currentDate);
			gc.add(Calendar.DATE, -dayInt);
			Date year = gc.getTime();
			fromDate=formatter.format(year);
		}catch (ParseException pe) {
			throw new OCEException(pe.getMessage());

		}
		return fromDate;
	}

	/**
	 * Adding GMT timeZone to given date.
	 *
	 * @param date the date
	 * @return String
	 */
	public static String dateConversionGMT(String date) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy hh:mm:ss a");
		Date convertedDate = null;
		SimpleDateFormat formatter = null;
		//String timeZone = "GMT";

		date =date +" "+"00:01:00";

		formatter = new SimpleDateFormat("dd-MMM-yy hh:mm:ss");
		try {
			//formatter.setTimeZone(TimeZone.getTimeZone("EST"));
			convertedDate = (Date) formatter.parse(date);
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing time"); 
			}
		} 
		/* if (timeZone == null || "".equalsIgnoreCase(timeZone.trim())) {
            timeZone = Calendar.getInstance().getTimeZone().getID();
        }*/
		//sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
		return sdf.format(convertedDate);
	}
	
	/**
	 * Adding GMT timeZone to given date.
	 *
	 * @param date the date
	 * @return String
	 */
	public static String dateConversion(String date) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy hh:mm:ss a");
		Date convertedDate = null;
		SimpleDateFormat formatter = null;
		String timeZone = "GMT";

		date =date +" "+"00:01:00";

		formatter = new SimpleDateFormat("dd-MMM-yy hh:mm:ss");
		try {
			formatter.setTimeZone(TimeZone.getTimeZone("EST"));
			convertedDate = (Date) formatter.parse(date);
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing time"); 
			}
		} 
		/* if (timeZone == null || "".equalsIgnoreCase(timeZone.trim())) {
            timeZone = Calendar.getInstance().getTimeZone().getID();
        }*/
		sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
		return sdf.format(convertedDate);
	}
	
	/**
	 * Adding GMT timeZone to given date based on timezone.
	 *
	 * @param date the date
	 * @param timeZone the time zone
	 * @param preference the preference
	 * @param timezoneValues the timezone values
	 * @param tzRequired the tz required
	 * @return String
	 */
	public static String timezoneConversion(String date,String timeZone,String preference,Map<String,String> timezoneValues,String tzRequired) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy hh:mm:ss a");
		Date convertedDate = null;
		SimpleDateFormat formatter = null;
		SimpleDateFormat format  = null;
		String cdate = null;
		String timeZoneRequired = null;
		String morningTime = "08:00:00 AM";
		String afternoonTime = "11:00:00 AM";
		String eveningTime = "02:00:00 PM";
		
		if(null != tzRequired) {
			timeZoneRequired = tzRequired;
		} 
		if (null != timezoneValues) {
			if (timezoneValues.containsKey("PREFERENCE_MORNING")) {
				morningTime = timezoneValues.get("PREFERENCE_MORNING");
			}
			if (timezoneValues.containsKey("PREFERENCE_AFTERNOON")) {
				afternoonTime = timezoneValues.get("PREFERENCE_AFTERNOON");
			}
			if (timezoneValues.containsKey("PREFERENCE_EVENING")) {
				eveningTime = timezoneValues.get("PREFERENCE_EVENING");
			}
		}
			if(preference.equalsIgnoreCase("PREFERENCE_MORNING")) {
				date =date +" "+morningTime;
			} else if(preference.equalsIgnoreCase("PREFERENCE_AFTERNOON")) {
				date =date +" "+afternoonTime;
			} else if(preference.equalsIgnoreCase("PREFERENCE_EVENING")) {
				date =date +" "+eveningTime;
			}

		formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
		format = new SimpleDateFormat("dd-MMM-yy hh:mm:ss a");
		try {
	
			cdate = (String)format.format(formatter.parse(date));
			format.setTimeZone(TimeZone.getTimeZone(timeZone));
			convertedDate = format.parse(cdate);
			
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing time"); 
			}
		} 
		/* if (timeZone == null || "".equalsIgnoreCase(timeZone.trim())) {
            timeZone = Calendar.getInstance().getTimeZone().getID();
        }*/
		sdf.setTimeZone(TimeZone.getTimeZone(timeZoneRequired));
		return sdf.format(convertedDate);
	}
	
	/**
	 * Date in GMT.
	 *
	 * @param xgdate the xgdate
	 * @return the date
	 */
	public static Date dateInGMT(XMLGregorianCalendar xgdate) {

		XMLGregorianCalendar normalizeGMT=xgdate.normalize();

		GregorianCalendar gc12=new GregorianCalendar
				(normalizeGMT.getYear(),normalizeGMT.getMonth()-1,normalizeGMT.getDay(),normalizeGMT.getHour(),
						normalizeGMT.getMinute(),normalizeGMT.getSecond() );
		Date date= gc12.getTime();
		return date;
	}

	/**
	 * Date in GMT for marker.
	 *
	 * @param xgdate the xgdate
	 * @return the date
	 */
	public static Date dateInGMTForMarker(XMLGregorianCalendar xgdate) {
		XMLGregorianCalendar normalizeGMT=xgdate.normalize();
		
		GregorianCalendar gc12=new GregorianCalendar
				(normalizeGMT.getYear(),normalizeGMT.getMonth()-1,normalizeGMT.getDay(),normalizeGMT.getHour(),
						normalizeGMT.getMinute(),normalizeGMT.getSecond() );
		Date date= gc12.getTime();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.MILLISECOND, xgdate.getMillisecond());
		return cal.getTime();
	}

	/**
	 * Method used to add the required number of days to current date.
	 *
	 * @param noOfDays the no of days
	 * @return the days after
	 */
	public static Date getDaysAfter(int noOfDays){
		String toDate=null;
		Date dateToReturn = null;
		Calendar calendar = GregorianCalendar.getInstance();
		SimpleDateFormat formatter =new SimpleDateFormat("dd-MMM-yy");
		calendar.add(Calendar.DATE, noOfDays);
		toDate=formatter.format(calendar.getTime());
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
		try {
			dateToReturn = (Date)dateFormat.parse(toDate);
		}
		
		catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing GMT time "); 
			}
		}
		return dateToReturn;
	}


	/**
	 * Gets the GMT date.
	 *
	 * @param dateValue the date value
	 * @return the GMT date
	 */
	public static Date getGMTDate(Date dateValue){
		//create a new calendar in GMT time zone, set to this date and add the offset
		Calendar gmtCal = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
		gmtCal.setTime(dateValue);
		// Removed the code to add offset - current time 14:00:00 CDT. should display as 14:00:00 -0600 instead it is showing 08:00:00 -0600 
		//gmtCal.add(java.util.Calendar.MILLISECOND, offsetFromUTC);
		return gmtCal.getTime();
	}

	/**
	 * Method used to convert Data format to Calendar format.
	 *
	 * @param date the date
	 * @return the calendar
	 */
	public static Calendar dateToCalendar(Date date){ 
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal;
	}
	
	/**
	 * Adding GMT timeZone to given date based on timezone.
	 *
	 * @param date the date
	 * @param timeZone the time zone
	 * @param preference the preference
	 * @param timezoneValues the timezone values
	 * @param tzRequired the tz required
	 * @param operation the operation
	 * @return String
	 */
	public static String getPreferencetimezone(String date,String timeZone,String preference,Map<String,String> timezoneValues,String tzRequired,String operation) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy hh:mm:ss a");
		Date convertedDate = null;
		SimpleDateFormat formatter = null;
		SimpleDateFormat format  = null;
		String cdate = null;
		String morningTime = "02:00:00 PM";
		String afternoonTime = "05:00:00 PM";
		String eveningTime = "08:00:00 PM";
		String timeZoneRequired = null;
		if(null != tzRequired) {
			timeZoneRequired = tzRequired;
		} 

		if (null != timezoneValues) {
			if (timezoneValues.containsKey("PREFERENCE_MORNING")) {
				morningTime = timezoneValues.get("PREFERENCE_MORNING");
			}
			if (timezoneValues.containsKey("PREFERENCE_AFTERNOON")) {
				afternoonTime = timezoneValues.get("PREFERENCE_AFTERNOON");
			}
			if (timezoneValues.containsKey("PREFERENCE_EVENING")) {
				eveningTime = timezoneValues.get("PREFERENCE_EVENING");
			}
		}
			if(preference.equalsIgnoreCase("PREFERENCE_MORNING")) {
				date =date +" "+morningTime;
			} else if(preference.equalsIgnoreCase("PREFERENCE_AFTERNOON")) {
				date =date +" "+afternoonTime;
			} else if(preference.equalsIgnoreCase("PREFERENCE_EVENING")) {
				date =date +" "+eveningTime;
			} 

		formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
		format = new SimpleDateFormat("dd-MMM-yy hh:mm:ss a");
		try {
	
			cdate = (String)format.format(formatter.parse(date));
			format.setTimeZone(TimeZone.getTimeZone(timeZone));
			convertedDate = format.parse(cdate);
			if(preference.equalsIgnoreCase("PREFERENCE_EVENING") && operation.equalsIgnoreCase("NEXT_SEARCH")) {
				Calendar cal = Calendar.getInstance();
		        cal.setTime(convertedDate);
		        cal.add(Calendar.DATE, 1);
		        convertedDate = cal.getTime();
			}
			
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing time"); 
			}
		} 
		/* if (timeZone == null || "".equalsIgnoreCase(timeZone.trim())) {
            timeZone = Calendar.getInstance().getTimeZone().getID();
        }*/
		sdf.setTimeZone(TimeZone.getTimeZone(timeZoneRequired));
		return sdf.format(convertedDate);
	}
	
	
	/**
	 * Gets the XML date value.
	 *
	 * @param dateValue the date value
	 * @return the XML date value
	 */
	public static XMLGregorianCalendar getXMLDateValue(Object dateValue){
		//mLogger.logDebug("dateValue "+dateValue);
		XMLGregorianCalendar xmGregCalendarValue2 = null;
		try {
			GregorianCalendar calendarValue2 = (GregorianCalendar) GregorianCalendar.getInstance();
			calendarValue2.setTime((Date) dateValue);
			//mLogger.logDebug("calendarValue2 "+calendarValue2);
			/*xmGregCalendarValue2 = DatatypeFactory
					.newInstance().newXMLGregorianCalendar(
							calendarValue2);*/
			xmGregCalendarValue2 = DatatypeFactory.newInstance().newXMLGregorianCalendarDate(calendarValue2.get(Calendar.YEAR), calendarValue2.get(Calendar.MONTH)+1, calendarValue2.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);
			//mLogger.logDebug("xmGregCalendarValue2 "+xmGregCalendarValue2);
		} catch (DatatypeConfigurationException e) {
			if(logger.isErrorEnabled()) {
				logger.error("DatatypeConfigurationException Error while parsing time"); 
			}
		}
		return xmGregCalendarValue2;
	}

	/**
	 * Convert Staring to XMLGregorianCalendar.
	 *
	 * @param dateString the date string
	 * @return the XML gregorian calendar
	 */
	public static XMLGregorianCalendar convertStringToXmlGregorian(String dateString)
	{
	      try {
	    	  	DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	            Date date = sdf.parse(dateString);
	            GregorianCalendar gc = (GregorianCalendar) GregorianCalendar.getInstance();
	            gc.setTime(date);
	            return DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
	      } catch (ParseException e) {
				if(logger.isErrorEnabled()) {
					logger.error("ParseException Error while parsing time"); 
				}
	        }catch (DatatypeConfigurationException e) {
           	 if(logger.isErrorEnabled()) {
				logger.error("DatatypeConfigurationException Error while parsing time"); 
			}
       } 
		return null; 
	}
	
	/**
	 * Date string to date.
	 *
	 * @param StrDate the str date
	 * @return the date
	 */
	public static Date dateStringToDate(String StrDate)
	{
		Date dateToReturn = null;		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		try
		{
			dateToReturn = (Date)dateFormat.parse(StrDate);
		}
		catch (ParseException e)
		{
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing GMT time "); 
			}
		}

		return dateToReturn;
	}
	
	/**
	 * Date to string.
	 *
	 * @param date the date
	 * @return the string
	 */
	public static String dateToString(Date date)
	{
		String dateToReturn = null;		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSS a");
		
		dateToReturn = dateFormat.format(date);

		return dateToReturn;
	}
	
	/**
	 * Gets the XML gregorian calendar value.
	 *
	 * @param dateValue the date value
	 * @return the XML gregorian calendar value
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendarValue(Date dateValue){
		//mLogger.logDebug("dateValue "+dateValue);
		XMLGregorianCalendar xmGregCalendarValue = null;
		try {
			GregorianCalendar gregory = new GregorianCalendar();
			gregory.setTime(dateValue);

			xmGregCalendarValue = DatatypeFactory.newInstance()
			        .newXMLGregorianCalendar(
			            gregory);
		} catch (DatatypeConfigurationException e) {
			if(logger.isErrorEnabled()) {
				logger.error("DatatypeConfigurationException Error while parsing time"); 
			}
		}
		return xmGregCalendarValue;
	}
	
	/**
	 * Convert string to GMT.
	 *
	 * @param date the date
	 * @return the string
	 */
	public static String convertStringToGMT(String date) {	
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSS a");
		Date convertedDate = null;		
		String timeZone = "GMT";
		try {			
			sdf.setTimeZone(TimeZone.getTimeZone("EST"));
			convertedDate = (Date) sdf.parse(date);
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing time"); 
			}
		} 		
		sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
		return sdf.format(convertedDate);
	}
	
	/**
	 * Convert GMT to EST.
	 *
	 * @param inputDate the input date
	 * @return the date
	 */
	public static Date convertGMTToEST (Date inputDate) {		
		
		DateFormat df = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSS a");		
		String date = df.format(inputDate);

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSS a");
		Date convertedDate = null;		
		String timeZone = "EST";

		try {
			sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
			convertedDate = (Date) sdf.parse(date);
			sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
			
			//input GMT Date object is converted to equivalent EST string
			String estDateString = sdf.format(convertedDate);
			
			//converting EST string to date object
			SimpleDateFormat estDF = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SSS a");			
			inputDate = estDF.parse(estDateString);
		} catch (ParseException e) {
			e.printStackTrace();
		} 
		return inputDate;		
	}
	
	/**
	 * String date.
	 *
	 * @param StrDate the str date
	 * @return the date
	 */
	public static Date stringDate(String StrDate)
	{
		Date dateToReturn = null;
		String DATEFORMAT = "dd-MMM-yy hh.mm.ss.SSS a";
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
		try
		{
			dateToReturn = (Date)dateFormat.parse(StrDate);
		}
		catch (ParseException e)
		{
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing GMT time "); 
			}
		}

		return dateToReturn;
	}
	
	/**
	 * Smart video date conversion.
	 *
	 * @param date the date
	 * @return String
	 */
	public static String smartVideoDateConversion(String date) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy hh:mm:ss a");
		Date convertedDate = null;
		SimpleDateFormat formatter = null;
		String timeZone = "GMT";
		String stringDate = date;
		date =date +" "+"00:01:00";

		formatter = new SimpleDateFormat("dd-MMM-yy hh:mm:ss");
		try {
			formatter.setTimeZone(TimeZone.getTimeZone("EST"));
			convertedDate = (Date) formatter.parse(date);
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing time"); 
			}
		} 
		/* if (timeZone == null || "".equalsIgnoreCase(timeZone.trim())) {
            timeZone = Calendar.getInstance().getTimeZone().getID();
        }*/
		sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
		
		Date inputDate = new Date(stringDate);
		int hour = inputDate.getHours();
        int updatedHour = convertedDate.getHours();
        updatedHour = updatedHour+12;
        if(hour == 12){
        	convertedDate.setHours(updatedHour);
        }
		return sdf.format(convertedDate);
	}
	
	/**
	 * String date only format.
	 *
	 * @param StrDate the str date
	 * @return the string
	 */
	public static String stringDateOnlyFormat(String StrDate)
	{
		Date dateToReturn = null;
		String date=StringUtils.EMPTY;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String[] monthNames = {"January", "February", "March", "April", "May", "June", 
				"July", "August", "September", "October", "November", "December"};
		
		try
		{
			dateToReturn = (Date)dateFormat.parse(StrDate);
			Calendar c=Calendar.getInstance();
			c.setTime(dateToReturn);
			StringBuilder b = new StringBuilder();
			b.append(monthNames[c.get(Calendar.MONTH)]);
			b.append(" ");
			b.append(c.get(Calendar.DATE));
			b.append(", ");
			b.append(c.get(Calendar.YEAR)); 
			date = b.toString();
		}
		catch (ParseException e)
		{
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing GMT time "); 
			}
		}

		return date;
	}
	
	/**
	 * String date format.
	 *
	 * @param StrDate the str date
	 * @return the string 
	 */
	public static String stringDateFormat(String StrDate)
	{
		Date dateToReturn = null;
		String date=StringUtils.EMPTY;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.sss'Z'");
		String[] monthNames = {"January", "February", "March", "April", "May", "June", 
				"July", "August", "September", "October", "November", "December"};
		
		try
		{
			dateToReturn = (Date)dateFormat.parse(StrDate);
			Calendar c=Calendar.getInstance();
			c.setTime(dateToReturn);
			StringBuilder b = new StringBuilder();
			b.append(monthNames[c.get(Calendar.MONTH)]);
			b.append(" ");
			b.append(c.get(Calendar.DATE));
			b.append(", ");
			b.append(c.get(Calendar.YEAR)); 
			date = b.toString();
		}
		catch (ParseException e)
		{
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing GMT time : "+e.getMessage()); 
			}
		}

		return date;
	}
	
	/**
	 * Gets the current date time format.
	 *
	 * @return the current date time format
	 */
	public static String getCurrentDateTimeFormat(){


		Calendar calendar = Calendar.getInstance();
		java.util.Date now = calendar.getTime();
		java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

		String formattedTimeStamp = new SimpleDateFormat("dd-MMM-yy hh:mm:ss.SSSSSS a").format(currentTimestamp);


		return formattedTimeStamp;
	}
	
	/**
	 * Date calculation.
	 *
	 * @param formattedCurrentTimeStamp the formatted current time stamp
	 * @param noOfDays the no of days
	 * @return the string
	 */
	public static String dateCalculation(String formattedCurrentTimeStamp,int noOfDays) {
		String toDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yy hh:mm:ss.SSSSSS a");

		try {
			Calendar calendar = GregorianCalendar.getInstance();
			calendar.setTime(formatter.parse(formattedCurrentTimeStamp));
			calendar.add(Calendar.DATE,-noOfDays);
			toDate = formatter.format(calendar.getTime());
		} catch (ParseException e) {
			if(logger.isErrorEnabled()) {
				logger.error(e.getMessage());
			}
		}
		return toDate;
	}
	
	/**
	 * Gets the SQL time stamp.
	 *
	 * @param date the date
	 * @return the SQL time stamp
	 */
	public static Timestamp getSQLTimeStamp(Date date){
		java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(date.getTime());
		return currentTimestamp;
	}
	
	/**
	 * String date convert.
	 *
	 * @param StrDate the str date
	 * @return the date
	 */
	public static Date stringDateConvert(String StrDate)
	{
		Date dateToReturn = null;
		String DATEFORMAT = "dd-MMM-yy hh:mm:ss.SSSSSS a";
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);
		try
		{
			dateToReturn = (Date)dateFormat.parse(StrDate);
		}
		catch (ParseException e)
		{
			if(logger.isErrorEnabled()) {
				logger.error("Error while parsing GMT time "); 
			}
		}

		return dateToReturn;
	}
	
	/**
	 * Gets the XML gregorian value.
	 *
	 * @param escalationDate the escalation date
	 * @return the XML gregorian value
	 */
	public static XMLGregorianCalendar getXMLGregorianValue(Date escalationDate){
		
		XMLGregorianCalendar xmGregCalendarValue = null;
		
		if(null != escalationDate){
			GregorianCalendar calendarValue = (GregorianCalendar) GregorianCalendar.getInstance();
			calendarValue.setTime(DateUtil.getGMTDate(escalationDate));
			try {
				xmGregCalendarValue = DatatypeFactory
					.newInstance().newXMLGregorianCalendar(
							calendarValue);
				xmGregCalendarValue.setTimezone(TimeZone.getTimeZone("UTC").getRawOffset());
			} catch (DatatypeConfigurationException e) {
				if(logger.isErrorEnabled()) {
					logger.error("Error while converting gregorian value "); 
				}
			}
		}
		return xmGregCalendarValue;
	}
	
	/**
	 * Gets the time after minutes.
	 *
	 * @param minutesVal the minutes val
	 * @return the time after minutes
	 */
	public static Date getTimeAfterMinutes(int minutesVal){
		
		Date currentDate = getCurrentTimeAsGMT();
		Date newDate = DateUtils.addMinutes(currentDate, minutesVal); 
		return newDate;
	}
	
	/**
	 * get current date in est timestamp.
	 *
	 * @return the current date EST timestamp
	 */
	public static Date getCurrentDateESTTimestamp(){
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss.SSS");
		dateFormat.setTimeZone(TimeZone.getTimeZone("EST5EDT"));
	    DateFormat formatter = new SimpleDateFormat("yyyy-MMM-dd HH:mm:ss.SSS");
	    Date date = null;
		try {
			date = (Date) formatter.parse(dateFormat.format(new Date()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
	    java.sql.Timestamp timeStampDate = new Timestamp(date.getTime());
		return timeStampDate;
	}
	
	
	/**
	 * Gets the day diff.
	 *
	 * @param taskCreationDate the task creation date
	 * @param currentDate the current date
	 * @return the day diff
	 */
	public static long getDayDiff(Date taskCreationDate , Date currentDate) {
		currentDate = getCurrentTimeAsGMT();
		Date taskDate = getGMTDate(taskCreationDate);
		
		long diff = (currentDate.getTime() - taskDate.getTime())/1000 / 60 / 60 / 24;
		
       // System.out.println ("Days: " + diff);
        
		return  diff;
	}
	
	public static XMLGregorianCalendar getCurrentTime(){
	GregorianCalendar gregorianCalendar = new GregorianCalendar();
    DatatypeFactory datatypeFactory = null;
	try {
		datatypeFactory = DatatypeFactory.newInstance();
	} catch (DatatypeConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    XMLGregorianCalendar now = datatypeFactory.newXMLGregorianCalendar(gregorianCalendar);
	return now;
	}
}