package com.att.oce.service.task.BeanImpl;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.att.oce.service.task.Bean.OrderTaskBean;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.BasicTaskDetailsVO;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.TaskConstants;

@Component
public class OrderTaskBeanImpl extends AbstractTaskBeanImpl implements OrderTaskBean {

	private Logger logger = LoggerFactory.getLogger(OrderTaskBeanImpl.class);

	Map<String, Set<BasicTaskDetailsVO>> orderMap = new ConcurrentHashMap<String, Set<BasicTaskDetailsVO>>();

	/**
	 * This method will add orderid and task into orderMap. If Orderid already
	 * exist it will update the task in existing order
	 * 
	 */

	@Override
	public void createTasks(List<TaskDetailsVO> tasks) {

		logger.info("createTask Started");
		this.poppulateHashTable(TaskConstants.TASK_CREATED, tasks);
		logger.info("createTask Completed");
	}

	/**
	 * This method will update the task for given order into orderMap or add new
	 * order id and task if order not already exist.
	 * 
	 */

	@Override
	public void updateTasks(List<TaskDetailsVO> tasks) {

		logger.info("updateTask Started");
		this.poppulateHashTable(TaskConstants.TASK_UPDATED, tasks);
		logger.info("updateTask Completed");
	}

	/**
	 * This method will be invoked once DB bean will publish all open task and
	 * notify this bean. It will add order id and all related task into the
	 * order map
	 */
	@Override
	public void initialize(List<TaskDetailsVO> taskDetailsList) {

		logger.info("initialization Started");
		createTasks(taskDetailsList);
		logger.info("initialization Completed");

	}

	private void poppulateHashTable(String type, List<TaskDetailsVO> tasks) {

		logger.trace("poppulateHashTable Started");
		BasicTaskDetailsVO t1 = null;
		Set<BasicTaskDetailsVO> taskSet = null;

		for (TaskDetailsVO task : tasks) {

			String orderId = task.getOrderRef();

			synchronized (this) {

				t1 = new BasicTaskDetailsVO(task);

				if (orderMap.containsKey(orderId)) {
					taskSet = orderMap.get(orderId);
				} else {
					taskSet = new HashSet<BasicTaskDetailsVO>();
				}

				Set<BasicTaskDetailsVO> actualSet = new HashSet<BasicTaskDetailsVO>();

				if (type.equals(TaskConstants.TASK_UPDATED)) {
					/*
					 * Any way, we are traversing the whole set, shall we remove
					 * the dirty object at the same iteration... Hmmmm... Hmm..
					 * lets think
					 */
					for (BasicTaskDetailsVO vo : taskSet) {
						if (!vo.equals(t1)) {
							actualSet.add(vo);
						}
					}
				} else {
					actualSet.addAll(taskSet);
				}

				actualSet.add(t1);
				orderMap.put(orderId, actualSet);
			}

			logger.trace("poppulateHashTable Completed");
		}
	}

	@Override
	public Set getTaskForAnOrder(String pOrderId) {
		
		logger.info("getTaskForAnOrder is called with order id " +pOrderId);
		Set<BasicTaskDetailsVO> taskSet = this.orderMap.get(pOrderId);

		Set<String> retVal = new HashSet<String>();

		if (null != taskSet) {
			for (BasicTaskDetailsVO vo : taskSet) {
				retVal.add(vo.getTaskId());
			}
		}
		logger.trace("getTaskForAnOrder is returning " +retVal);	
		return retVal;
	}
	
	public Set getTaskForAnOrderOnStatus(String OrderId,String status){
		Set<BasicTaskDetailsVO> taskSet = this.orderMap.get(OrderId);
		Set<String> retVal = new HashSet<String>();
		logger.info("getTaskForAnOrder is called with order id " +OrderId);
		for (BasicTaskDetailsVO vo : taskSet) {
			if(null != vo && vo.getTaskStatus().equalsIgnoreCase(status)){			
			retVal.add(vo.getTaskId());
			}
		}
		logger.trace("getTaskForAnOrder is returning " +retVal);	
		return retVal;	
	}

	/*
	 * ******************* BE CAUTIOUS !!! ********************************* Do
	 * not use this method unnecessarily, it will affect the over all
	 * functionality. This method is created only to purge testData not the real
	 * data. Please take care.
	 * 
	 */

	@Override
	public void purgeTestData() throws OCEException {
		this.orderMap.clear();
	}
   
	/**
	 * This method will accept orderid and AvosRef Id
	 * 1. will retrieve all task associated with given orders
	 * 2. Retrieve task comparing with AvosRefid
	 */
	
	@Override
	public String getTaskforAnUpdate(String Orderid, String AvosRefId) {

		// Set<BasicTaskDetailsVO> taskSet = getTaskForAnOrder(Orderid);
		Set<BasicTaskDetailsVO> taskSet = this.orderMap.get(Orderid);

		String taskId = null;

		if (taskSet != null) {
			for (BasicTaskDetailsVO vo : taskSet) {
				// This equal can be implemented more efficiently.. Yeah. it can
				// also be implemented with predicate JDK1.8 feature
				if (vo.getAvosRefId() != null
						&& vo.getAvosRefId().equalsIgnoreCase(AvosRefId)) {
					taskId = vo.getTaskId();
					break;
				}
			}
		}
		
		return taskId;
	}
}
