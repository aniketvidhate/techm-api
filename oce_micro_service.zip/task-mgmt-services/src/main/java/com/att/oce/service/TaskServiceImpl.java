package com.att.oce.service;

import static reactor.bus.selector.Selectors.$;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.camel.Exchange;
import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import reactor.bus.EventBus;

import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtError;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtErrorList;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.Order;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtLineCombo;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtOrderTask;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.OrderTasks;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.StTaskStatus;
import com.att.oce.service.queue.OCEOrderQueueService;
import com.att.oce.service.task.Bean.DBTaskInfoBean;
import com.att.oce.service.task.Bean.GetNextTaskBean;
import com.att.oce.service.task.Bean.OrderCountStatusBean;
import com.att.oce.service.task.Bean.OrderTaskBean;
import com.att.oce.service.task.Bean.TaskInfoBean;
import com.att.oce.service.task.Bean.request.ProgramCountRequest;
import com.att.oce.service.task.BeanImpl.AbstractTaskBeanImpl;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.OrderCountStatusKey;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.CalenderUtils;
import com.att.oce.service.task.util.TaskConstants;
import com.att.ooce.core.CtMetaInformation;
import com.att.ooce.core.GetNextOrderResponse;
import com.att.ooce.core.ObjectFactory;
import com.att.ooce.core.OrderQueueResponse;
import com.att.ooce.core.OrderResponse;
import com.att.ooce.core.OrderTasksResponse;
import com.att.ooce.core.ProcessOrderRequest;
import com.att.ooce.core.Response;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * The Class TaskServiceImpl.
 *
 * @author SX00352475
 */

public class TaskServiceImpl {

	/** The task info bean. */
	@Autowired
	TaskInfoBean taskInfoBean;

	/** The get next task bean. */
	@Autowired
	GetNextTaskBean getNextTaskBean;

	/** The db task bean. */
	@Autowired
	DBTaskInfoBean dbTaskBean;

	/** The rest template. */
	@Autowired
	RestTemplate restTemplate;

	/** The order task bean. */
	@Autowired
	OrderTaskBean orderTaskBean;
	
	/** The ordr cnt sts bean. */
	@Autowired
	OrderCountStatusBean ordrCntStsBean;
	
	/** The order queue service. */
	@Autowired
	OCEOrderQueueService orderQueueService;
	
	/** The event bus. */
	private EventBus eventBus;
	
	/** The results. */
	private ConcurrentHashMap<String, List<String>> results = null;
	
	private String taskNotificationURL;

	/**
	 * @return the taskNotificationURL
	 */
	public String getTaskNotificationURL() {
		return taskNotificationURL;
	}

	/**
	 * @param taskNotificationURL the taskNotificationURL to set
	 */
	public void setTaskNotificationURL(String taskNotificationURL) {
		this.taskNotificationURL = taskNotificationURL;
	}

	/** The logger. */
	private Logger logger = LoggerFactory.getLogger(TaskServiceImpl.class);
	
	
	/**
	 * Queue count.
	 *
	 * @param e the e
	 */
	public final void queueCount(Exchange e) {
		logger.info("Create Task request is made, started processing"); 
		  
		OrderQueueResponse queueResponse = null;
		try{
		String jsonString = ((String) e.getIn().getHeader("searchString"));	
		Map<String, Object> result = new HashMap<String, Object>(); 
		ObjectMapper objectMapper = new ObjectMapper();
		result = objectMapper.readValue(jsonString, HashMap.class);
	
		ProgramCountRequest request = new ProgramCountRequest();
		
		List<String> partnerList = new ArrayList<String>();
		List<Map<String, Object>> partnersMap=new ArrayList<Map<String, Object>>();
		if(result.containsKey("partners")){
			partnersMap=(List<Map<String, Object>>) result.get("partners");
			
			for(Map<String, Object> partnersMapObj : partnersMap){
				Iterator<Entry<String,Object>> it = partnersMapObj.entrySet().iterator();
			    while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        partnerList.add(pair.getValue().toString());
			    }
			}
		}
		String queueInputType = null;
		String requestType = null;
		if(null!=result){
			if(result.containsKey("queueType")){
				queueInputType=(String) result.get("queueType");
			}
		}
		if(null!=result){
			if(result.containsKey("requestType")){
				requestType=(String) result.get("requestType");
			}
		}
		request.setOrgUnitList((List<String>) result.get("view"));
		request.setPartnerList(partnerList);
		request.setGlobalVisible(true);
		//request.setCallbackPreference("callbackPreference");
		request.setQueueOrProgram("programName");
		
		request.setQueueInputType(queueInputType);
		request.setRequestType(requestType);
		queueResponse = ordrCntStsBean.fetchOrderQueueCount(request);
		
		CtMetaInformation meta = new CtMetaInformation();
		meta.setLimit("100");
		meta.setOffset("0");
		meta.setTotal("12");
		
		ObjectFactory objectFactory = new ObjectFactory();
		JAXBElement<CtMetaInformation> jaxbElement = objectFactory.createOrderQueueResponseMetaInformation(meta);
		queueResponse.setMetaInformation(jaxbElement);
		
		XMLGregorianCalendar now = DateUtil.getCurrentTime();
		queueResponse.setCurrentDateTime(now);
		logger.info("Create Task request is completed successfully");
		}
		catch(Exception ex){
		  //  reponse = errorResponse("ERRGETNXT4001", "Error while creating task");
		    logger.error("Error while creating task", ex);
		}
		
		 e.getOut().setHeaders(e.getIn().getHeaders());
		 e.getOut().setBody(queueResponse);	
}
	

	/**
	 * Creates the task.
	 *
	 * @param e the e
	 */
	public final void createTask(Exchange e) {

		logger.info("Create Task request is made, started processing");
		OrderTasksResponse response = new OrderTasksResponse();				
		try
		{
			ProcessOrderRequest processOrderRequest = (ProcessOrderRequest) e.getIn().getBody();		
			List<TaskDetailsVO> tskList = taskInfoBean.createTask(processOrderRequest); 
			taskInfoBean.createTasks(tskList);       
			// Need to fix. Ideally it should be for each create task
			response = successUpdateResponse(tskList.get(0));
			logger.info("Create Task request is completed successfully");
		}
		catch(Exception ex){
			response = errorUpdateResponse("ERRGETNXT4001", "Error while creating task");
		    logger.error("Error while creating task", ex);
		}	
		 e.getOut().setHeaders(e.getIn().getHeaders());
		 e.getOut().setBody(response);
		 

	}
	
	/**
	 * Error update response.
	 *
	 * @param errorCode the error code
	 * @param errorDescription the error description
	 * @return the order tasks response
	 */
	private OrderTasksResponse errorUpdateResponse(String errorCode , String errorDescription){
		
		OrderTasksResponse response = new OrderTasksResponse();
		response.setMetaInformation(null);
		 CtError error = new CtError();
		 error.setErrorCode(errorCode);
		 error.setErrorDescription(errorDescription);
		 CtErrorList errors = new CtErrorList();
		 errors.getError().add(error);
		 response.setErrors(errors);
		 
		 return response;
	}

	/**
	 * Success update response.
	 *
	 * @param taskDetailsVO the task details VO
	 * @return the order tasks response
	 * @throws ParseException the parse exception
	 */
	private OrderTasksResponse successUpdateResponse(TaskDetailsVO taskDetailsVO) throws ParseException {
		
		OrderTasksResponse response = new OrderTasksResponse();
		
		 CtMetaInformation m = new CtMetaInformation();
		 m.setLimit("100");
		 m.setOffset("0");
		 m.setTotal("1");
		 
		ObjectFactory objectFactory = new ObjectFactory();
		JAXBElement<CtMetaInformation> jaxbElement = objectFactory.createOrderTasksResponseMetaInformation(m);
		
		response.setMetaInformation(jaxbElement);	
		
		OrderTasks orderTasks = new OrderTasks();
		CtOrderTask ctOrderTasks = new CtOrderTask();
		ctOrderTasks.setOrderNumber(taskDetailsVO.getOrderRef());
		ctOrderTasks.setTaskId(taskDetailsVO.getTaskId());
		
		//ctOrderTasks.setTaskStatus(StTaskStatus.fromValue(taskDetailsVO.getTaskStatus()));
		//ctOrderTasks.setTaskStatus(StTaskStatus.valueOf(taskDetailsVO.getTaskStatus()));
		if (taskDetailsVO.getTaskStatus() == null) {
			ctOrderTasks.setTaskStatus(StTaskStatus.NEW);
		} else {
			ctOrderTasks.setTaskStatus(StTaskStatus.valueOf(taskDetailsVO.getTaskStatus()));
		}
		ctOrderTasks.setLastModifiedBy(taskDetailsVO.getLast_modified_by());
		ctOrderTasks.setLastModifiedDateTime(taskDetailsVO.getLast_modified_date().toString());
		
		if(taskDetailsVO.getCreationDate() == null){
			ctOrderTasks.setCreationDateTime(CalenderUtils.gstDate().toString());
		} else {
			ctOrderTasks.setCreationDateTime(taskDetailsVO.getCreationDate().toString());
		}
		
		orderTasks.getOrderTask().add(ctOrderTasks);
		
		response.setOrderTasks(orderTasks);
		
		//response.se

		return response;
	}


	/**
	 * Success response.
	 *
	 * @param orderRef the order ref
	 * @return the gets the next order response
	 */
	private GetNextOrderResponse successResponse(String orderRef){
		 GetNextOrderResponse reponse = new GetNextOrderResponse();
		 reponse.setParentOrderId(orderRef);
		 CtMetaInformation m = new CtMetaInformation();
		 m.setLimit("100");
		 m.setOffset("0");
		 m.setTotal("1");
		 
		ObjectFactory objectFactory = new ObjectFactory();
		JAXBElement<CtMetaInformation> jaxbElement = objectFactory.createGetNextOrderResponseMetaInformation(m);
		reponse.setMetaInformation(jaxbElement);	 
		return reponse;
		
	}
	
	/**
	 * Error response.
	 *
	 * @param errorCode the error code
	 * @param errorDescription the error description
	 * @return the gets the next order response
	 */
	private GetNextOrderResponse errorResponse(String errorCode , String errorDescription){		
		GetNextOrderResponse reponse = new GetNextOrderResponse();
		 reponse.setMetaInformation(null);
		 CtError error = new CtError();
		 error.setErrorCode(errorCode);
		 error.setErrorDescription(errorDescription);
		 CtErrorList errors = new CtErrorList();
		 errors.getError().add(error);
		 reponse.setErrors(errors);	
		 return reponse;
		
	}
	
//	private static String extractParameter(String uri, String parameterName) {
//	    Matcher m = Pattern.compile(parameterName + "=([^&]+)").matcher(uri);
//	    return m.find() ? m.group(1) : null;
//	} 
	
/**
 * Update task.
 *
 * @param e the e
 * @throws OCEException the OCE exception
 */
/*
 * Incoming request provides Avosrefid and OCEOrdernunber, Based on this information, it fetches the task details from the orderTaskBean and TaskInfobeanImpl
 * and update the status, lastmodified date and the csrid as per the request payload. Based on that, response has to be sent to the caller.  
 *  
 */
	public final void updateTask(Exchange e) throws OCEException {

		logger.info("Update Task request is made, started processing");
		
		

		OrderTasksResponse response = new OrderTasksResponse();
		//String avosRefId =extractParameter(e.getIn().getHeader("CamelHttpUri").toString(),"avosRefId");
		try {
			//String avosRefId =e.getIn().getHeader("avosRefId").toString();
			
			String[] strSplit = e.getIn().getHeader("CamelHttpUri").toString().split("/");
			String avosRefId =strSplit[strSplit.length-1];
		
			System.out.println("-avosRefId---"+avosRefId);
			CtOrderTask orderTask = (CtOrderTask) e.getIn().getBody();		
			TaskDetailsVO taskDetailsVO = new TaskDetailsVO(orderTask);	
			OrderResponse order = null;
			String orderId = taskDetailsVO.getOrderRef();
			order = (OrderResponse) e.getIn().getHeader("orderId");
			//Set<String> taskIds = orderTaskBean.getTaskForAnOrder(taskDetailsVO.getOrderRef());
			String taskId = orderTaskBean.getTaskforAnUpdate(taskDetailsVO.getOrderRef(), avosRefId);
			TaskDetailsVO taskDetails  = taskInfoBean.getTaskInfo(taskId);
			taskDetails.setAvos_task_id(avosRefId);
			String taskStatus = orderTask.getTaskStatus().toString();
			//taskDetails.setTaskStatus(orderTask.getTaskStatus().toString());
		
			taskDetails.setTaskStatus(taskStatus);
			if(e.getIn().getHeader("csp-attuid") != null){
			   taskDetails.setCsrId(e.getIn().getHeader("csp-attuid").toString());
			} else{
			   taskDetails.setCsrId("SYSTEM");
			}
			List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
			tskList.add(taskDetails);
			
			taskInfoBean.updateTasks(tskList);
			response = successUpdateResponse(taskDetails);
			logger.info("update Task request is completed");
			
			//Sending task notification to AVOS for UNLOCK
			if (null != response) {
				boolean success = taskInfoBean.sendTaskInfoToPostNotifyUnlockCamunda(taskDetails.getOrderRef(),taskDetails.getApplicationName());

				if (null == results) {
					results = new ConcurrentHashMap<String, List<String>>();
				} 
				if(success)
				{
					List<String> successList = results.get("success");
					if(null == successList)
					{
						successList = new Vector<String>();

					}
					successList.add(taskDetails.getTaskId());
					results.put("success", successList);
					taskInfoBean.updateTaskNotificationStatus(taskDetails);
					taskInfoBean.incrementTaskRetry(taskDetails);
				}
				else
				{
					List<String> failure = results.get("failure");
					if(null == failure)
					{
						failure = new Vector<String>();

					}
					failure.add(taskDetails.getTaskId());
					results.put("failure", failure);
					taskInfoBean.incrementTaskRetry(taskDetails);
				}
			}
		} catch (ParseException e1) {
			response = errorUpdateResponse("ERRUPDATETASK4003", "Error while updating task");
		} catch (HibernateException e1) {
			logger.error(e1.getMessage());
		}	
		e.getOut().setHeaders(e.getIn().getHeaders());
		e.getOut().setBody(response);

	}
	/**
	 * Prepare response.
	 *
	 * @param list the list
	 * @return the order tasks
	 */
	private OrderTasks prepareResponse(Collection<TaskDetailsVO> list) {

		OrderTasks taskList = new OrderTasks();
		CtOrderTask task = null;
		for (TaskDetailsVO vo : list) {

			task = new CtOrderTask();
			task.setApplicationName(vo.getApplicationName());
			// task.setCallbackPreference(vo.getc);
			task.setChildOrderNumber(vo.getChild_order_ref());
			task.setCreatedBy(vo.getCreated_by());
			if (vo.getCreationDate() != null)
				task.setCreationDateTime(vo.getCreationDate().toString());
			task.setCsrId(vo.getCsrId());
			task.setCustomerOrderNumber(vo.getExternalOrderNum());
			task.setLastModifiedBy(vo.getLast_modified_by());
			if (vo.getLast_modified_date() != null)
				task.setLastModifiedDateTime(vo.getLast_modified_date().toString());
			task.setLineAction(vo.getLineAction());

			CtLineCombo ctLineCombo = new CtLineCombo();
			ctLineCombo.getLineCombo().add(vo.getLineCombos());
			task.setLineCombination(ctLineCombo);

			if (vo.getLineCount() != null)
				task.setLineCount(Integer.parseInt(vo.getLineCount()));
			task.setOrderNumber(vo.getOrderRef());
			task.setPartners(null);
			task.setProgramName(vo.getProgram());
			task.setQueuePriorityValue(vo.getQueue_Priority_value());
			task.setQueueSubType(vo.getQueueCategory());
			task.setQueueType(vo.getQueueType());
			task.setRepComments(null);
			task.setTaskId(vo.getTaskId());
			task.setTaskStatus(StTaskStatus.ASSIGNED);
			task.setViews(null);
			taskList.getOrderTask().add(task);
		}

		return taskList;
	}

	/**
	 * Gets the all tasks.
	 *
	 * @param e the e
	 * @return the all tasks
	 */
	public final void getAllTasks(Exchange e) {
		logger.info("getAllTasks, started processing");
		try {
			Collection<TaskDetailsVO> list = dbTaskBean.fetchAllTasks();
			OrderTasks taskList = prepareResponse(list);
			e.getOut().setHeaders(e.getIn().getHeaders());
			e.getOut().setHeader("Response", "fineResponse");
			e.getOut().setBody(taskList);
			logger.info("getAllTasks request is completed");
		} catch (Exception e1) {
			GetNextOrderResponse reponse = errorResponse("ERRGETNXT4006", "Error while fetching all tasks");					
			 e.getOut().setHeaders(e.getIn().getHeaders());
			 e.getOut().setHeader("Response", "errorResponse");
			 e.getOut().setBody(reponse);
			 logger.error("Error while getAllTasks", e1);
		}

	}

	/**
	 * Gets the all open tasks.
	 *
	 * @param e the e
	 * @return the all open tasks
	 */
	public final void getAllOpenTasks(Exchange e) {
		logger.info("getAllOpenTasks, started processing");
		try {
			Collection<TaskDetailsVO> list = taskInfoBean.getAllTask();
			OrderTasks taskList = prepareResponse(list);
			e.getOut().setHeaders(e.getIn().getHeaders());
			e.getOut().setHeader("Response", "fineResponse");
			e.getOut().setBody(taskList);
			logger.info("getAllOpenTasks request is completed");
		} catch (Exception e1) {
			GetNextOrderResponse reponse = errorResponse("ERRGETNXT4007", "Error while fetching all open tasks");			
			 e.getOut().setHeaders(e.getIn().getHeaders());
			 e.getOut().setHeader("Response", "errorResponse");
			 e.getOut().setBody(reponse);
			 logger.error("Error while getAllOpenTasks", e1);
		}

	}

	/**
	 * Atg response.
	 *
	 * @param e the e
	 */
	public void atgResponse(Exchange e) {
		GetNextOrderResponse reponse = new GetNextOrderResponse();
		try{
			if(e.getIn().getBody() instanceof Response){
				logger.info("out bound synchornous response success");
				Response atgResult= (Response)e.getIn().getBody();
				List<TaskDetailsVO> tasks = new ArrayList<TaskDetailsVO>();
				TaskDetailsVO taskDetails = (TaskDetailsVO)e.getIn().getHeader("taskDetails");
				Set<String> taskIds = orderTaskBean.getTaskForAnOrder(taskDetails.getOrderRef());
                for(String taskId : taskIds){
                	logger.debug("Associated Tasks : " + taskId);
                	taskDetails = taskInfoBean.getTaskInfo(taskId);
                	logger.trace("Associated Task Details    : " + taskDetails);
                	taskDetails.setCsrId("bk436x"); 
                	taskDetails.setTaskStatus(TaskConstants.REP_PROCESSING);
                	tasks.add(taskDetails);
                	 
                 }
				taskInfoBean.updateTasks(tasks);
				
				reponse = successResponse(atgResult.getOrderNumber().getValue());	
			}
			else
			{
				logger.error("No Order In Queue");
				 reponse = errorResponse("ERRGETNXT4002", "No Order In Queue");
			}
		}
		catch(Exception ex){
			logger.error("out bound synchornous response failed");
			reponse = errorResponse("ERRGETNXT4005", "ATG API giving exception");

		}
		
		 e.getOut().setHeaders((Map<String, Object>) e.getIn().getHeader("originalHeaders"));
		 e.getOut().setBody(reponse);

	}

	/**
	 * Gets the next task.
	 *
	 * @param e the e
	 * @return the next task
	 */
	public final void getNextTask(Exchange e) {

		logger.info("getNext Task request is made, started processing");
		Boolean errorResponse = false;

		try {
			
			
			CtOrderTask orderTask = (CtOrderTask) e.getIn().getBody();
			TaskDetailsVO taskDetailsVO = new TaskDetailsVO(orderTask);
			
//			List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
			
			//ordrCntStsBean.createTasks(tskList);
			
			TaskDetailsVO taskDetailsVO1 = getTestTaskDetailsVO(1);
			//tskList.add(taskDetailsVO1);
			OrderCountStatusKey ordCntKey = new OrderCountStatusKey(taskDetailsVO1);
			
			//ordrCntStsBean.getProgramCount(ordCntKey);

			


			logger.trace("Received objects : " + taskDetailsVO);

			String taskId = getNextTaskBean.getNextTask(taskDetailsVO);

			TaskDetailsVO taskDetails = null;
			if (taskId != null) {

				taskDetails = taskInfoBean.getTaskInfo(taskId);
				
				ProcessOrderRequest request = new ProcessOrderRequest();
				Order order = new Order();
				order.setCustomerOrderNumber(taskDetails.getExternalOrderNum());
				order.setIsLocked(true);
				order.setLockOwner(taskDetails.getCsrId());
				order.setOCEOrderNumber(taskDetails.getOrderRef());
				// order.setOrderType(StOrderType.UPDATE);
				request.setOrder(order);

				e.getOut().setHeader("Response", "fineResponse");
				e.getOut().setHeader("taskDetails", taskDetails);
				e.getOut().setHeader("originalHeaders", e.getIn().getHeaders());
				e.getOut().setBody(request);
			}
			else
			{
				errorResponse = true;
				logger.error("taskId is null");
			}


		} catch (Exception ex) {
			errorResponse = true;
			logger.error("getNext Exception occurred", ex);
		}
		
		if(errorResponse){
			GetNextOrderResponse reponse = errorResponse("ERRGETNXT4004", "No task Id for a given input");
			 e.getOut().setHeader("Response", "errorResponse");
			 e.getOut().setBody(reponse);
		}

	}

	/**
	 * Register event.
	 */
	private void registerEvent() {
		try{
		eventBus = AbstractTaskBeanImpl.eventBus;

		eventBus.on($(TaskConstants.TASK_LOADED), taskInfoBean);
		eventBus.on($(TaskConstants.TASK_LOADED), orderTaskBean);
		eventBus.on($(TaskConstants.TASK_LOADED), getNextTaskBean);
		eventBus.on($(TaskConstants.TASK_LOADED), ordrCntStsBean);
		
		

		eventBus.on($(TaskConstants.TASK_CREATED), dbTaskBean);
		eventBus.on($(TaskConstants.TASK_CREATED), orderTaskBean);
		eventBus.on($(TaskConstants.TASK_CREATED), getNextTaskBean);
		eventBus.on($(TaskConstants.TASK_CREATED), ordrCntStsBean);
	

		eventBus.on($(TaskConstants.TASK_UPDATED), dbTaskBean);
		eventBus.on($(TaskConstants.TASK_UPDATED), orderTaskBean);
		eventBus.on($(TaskConstants.TASK_UPDATED), getNextTaskBean);
		eventBus.on($(TaskConstants.TASK_UPDATED), ordrCntStsBean);
		
		dbTaskBean.initialize(null);
		}
		catch (Exception ex) {
			logger.error("exception while initializing and registering events", ex);
		}

	}

	/**
	 * Gets the env.
	 *
	 * @return the env
	 */
	public EventBus getEnv() {
		return getEnv();
	}

	/**
	 * Gets the task info bean.
	 *
	 * @return the task info bean
	 */
	public TaskInfoBean getTaskInfoBean() {
		return taskInfoBean;
	}

	/**
	 * Sets the task info bean.
	 *
	 * @param taskInfoBean the new task info bean
	 */
	public void setTaskInfoBean(TaskInfoBean taskInfoBean) {
		this.taskInfoBean = taskInfoBean;
	}

	/**
	 * Gets the db task bean.
	 *
	 * @return the db task bean
	 */
	public DBTaskInfoBean getDbTaskBean() {
		return dbTaskBean;
	}

	/**
	 * Sets the db task bean.
	 *
	 * @param dbTaskBean the new db task bean
	 */
	public void setDbTaskBean(DBTaskInfoBean dbTaskBean) {
		this.dbTaskBean = dbTaskBean;
	}
	
	/**
	 * Gets the test task details VO.
	 *
	 * @param i the i
	 * @return the test task details VO
	 */
	public TaskDetailsVO getTestTaskDetailsVO(int i) {

		TaskDetailsVO taskDetailsVO = null;

		taskDetailsVO = new TaskDetailsVO();
		taskDetailsVO.setTaskId("TAK123" + String.valueOf(i));
		taskDetailsVO.setTaskStatus(TaskConstants.NEW);
		taskDetailsVO.setTaskRetryAttempt(0);
		taskDetailsVO.setdCreationDate(new Date());
		taskDetailsVO.setCreationDate(new Date());
		taskDetailsVO.setLineAction("NEW");
		taskDetailsVO.setLineCombos("INTERNET");
		taskDetailsVO.setOwner("TEST");
		taskDetailsVO.setProgram("GIGAPOWER");
		taskDetailsVO.setQueueType("SCHEDULED_OUTBOUND");
		taskDetailsVO.setChannel("UNLOCK");
		taskDetailsVO.setCsrId("TEST");
		taskDetailsVO.setLast_modified_date(new Date());
		taskDetailsVO.setLosgId("OCEK1520047:dtv,OCEK1520047:uvDTV");
		taskDetailsVO.setOrderRef("OCE1234" + String.valueOf(i));
	
		return taskDetailsVO;
	}
	
	
}
