package com.att.oce.task.hibernate.orm;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="oce_dcspp_order")
public class OceDcsppOrder {

	    @Id
	    @Column(name = "order_id")
	    private String mOrderId; 
	    
	    @Column(name = "EXTERNAL_ORDER_NUM")
	    private String mExternalOrderNum;
	    
	    @Column(name = "ACCEPTED_DATE")
	    private Date mAcceptedDate;

	   /**
		 * @return the mAcceptedDate
		 */
		public Date getmAcceptedDate() {
			return mAcceptedDate;
		}

		/**
		 * @param mAcceptedDate the mAcceptedDate to set
		 */
		public void setmAcceptedDate(Date mAcceptedDate) {
			this.mAcceptedDate = mAcceptedDate;
		}

	public String getmOrderId() {
			return mOrderId;
		}

		public void setmOrderId(String mOrderId) {
			this.mOrderId = mOrderId;
		}

		public String getmExternalOrderNum() {
			return mExternalOrderNum;
		}

		public void setmExternalOrderNum(String mExternalOrderNum) {
			this.mExternalOrderNum = mExternalOrderNum;
		}
}
