package com.att.oce.service.task.Bean;

import java.util.List;

import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;

import reactor.fn.Consumer;
import reactor.bus.Event;

/**
 * The Interface BasicTaskBean.
 */
public interface BasicTaskBean extends Consumer<Event<List<TaskDetailsVO>>> {

	/**
	 * Creates the tasks.
	 *
	 * @param task the task
	 * @throws OCEException the OCE exception
	 */
	abstract public void createTasks(List<TaskDetailsVO> task) throws OCEException;

	/**
	 * Update tasks.
	 *
	 * @param task the task
	 * @throws OCEException the OCE exception
	 */
	abstract public void updateTasks(List<TaskDetailsVO> task) throws OCEException;

	/**
	 * Initialize.
	 *
	 * @param list the list
	 * @throws OCEException the OCE exception
	 */
	abstract public void initialize(List<TaskDetailsVO> list) throws OCEException;
	
	/**
	 * Purge test data.
	 *
	 * @throws OCEException the OCE exception
	 */
	abstract public void purgeTestData() throws OCEException;
}
