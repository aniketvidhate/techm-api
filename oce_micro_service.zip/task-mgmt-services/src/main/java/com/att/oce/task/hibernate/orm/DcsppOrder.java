package com.att.oce.task.hibernate.orm;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "dcspp_order")
public class DcsppOrder {

	@Id
	@Column(name = "order_id")
	private String mOrderId;

	@Column(name = "state")
	private Date mState;
	
	
	@Column(name = "creation_date")
	private Date dCreationDate;





	public Date getdCreationDate() {
		return dCreationDate;
	}

	public void setdCreationDate(Date dCreationDate) {
		this.dCreationDate = dCreationDate;
	}

	@OneToMany
	@JoinColumn(name = "order_id")
	private Set<OCETaskDetails> mOrderDetails = new HashSet<OCETaskDetails>();

	public String getOrderId() {
		return mOrderId;
	}

	public void setOrderId(String mOrderId) {
		this.mOrderId = mOrderId;
	}

	public Date getState() {
		return mState;
	}

	public void setState(Date mState) {
		this.mState = mState;
	}

	public Set<OCETaskDetails> getOrderDetails() {
		return mOrderDetails;
	}

	public void setOrderDetails(Set<OCETaskDetails> mOrderDetails) {
		this.mOrderDetails = mOrderDetails;
	}

}
