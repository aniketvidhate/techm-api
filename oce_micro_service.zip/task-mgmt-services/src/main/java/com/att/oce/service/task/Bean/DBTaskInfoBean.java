package com.att.oce.service.task.Bean;

import java.util.Collection;

import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;

/**
 * The Interface DBTaskInfoBean.
 */
public interface DBTaskInfoBean extends BasicTaskBean {

	/**
	 * Fetch all tasks.
	 *
	 * @return the collection
	 * @throws OCEException the OCE exception
	 */
	abstract public Collection<TaskDetailsVO> fetchAllTasks() throws OCEException;

	/**
	 * Fetch all open tasks ids.
	 *
	 * @return the collection
	 * @throws OCEException the OCE exception
	 */
	abstract public Collection<String> fetchAllOpenTasksIds() throws OCEException;

	/**
	 * Gets the task details.
	 *
	 * @param id the id
	 * @return the task details
	 * @throws OCEException the OCE exception
	 */
	abstract public TaskDetailsVO getTaskDetails(String id) throws OCEException;

	/**
	 * Fetch all open task.
	 *
	 * @return the collection
	 * @throws OCEException the OCE exception
	 */
	abstract public Collection<TaskDetailsVO> fetchAllOpenTask() throws OCEException;
	
	/**
	 * Fetch all outbound task.
	 *
	 * @return the collection
	 * @throws OCEException the OCE exception
	 */
	public Collection<TaskDetailsVO> fetchAllOutboundTasks() throws OCEException; 
}
