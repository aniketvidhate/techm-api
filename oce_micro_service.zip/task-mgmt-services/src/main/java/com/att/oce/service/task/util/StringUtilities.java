package com.att.oce.service.task.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;

/**
 * @author Balabaskaran Kanagasabai, Tech Mahindra
 * @creation date 03/02/2016
 * 
 */

public abstract class StringUtilities {
	private static final Map<String, List<XmlReplacementPattern>> XML_ELEMENT_PARSE_MAP = new HashMap<String, List<XmlReplacementPattern>>();
	private static final String ATTRIBUTE_XML_REPLACEMENT = "$1HIDDEN VALUE$4";
	private static final String ELEMENT_XML_REPLACEMENT = "$1HIDDEN VALUE$4";
	private static final String ELEMENT_REPLACE_UNFORMATTED_PATTERN = "(<(\\w+:)?%1$s>)(.*?)(</(\\w+:)?%1$s>)";
	private static final String ATTRIBUTE_REPLACE_UNFORMATTED_PATTERN = "( (\\w+:)?%1$s=['\"])(.*?)(['\"])";
	private static final String ATTRIBUTE_SEARCH_UNFORMATTED_PATTERN = "%1$s=";
	private static final String ELEMENT_SEARCH_UNFORMATTED_PATTERN = "%1$s>";
	private static final byte[] HexChars = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e',
			'f' };

	protected StringUtilities() {
	}

	private static class XmlReplacementPattern {
		private final String searchPattern;
		private final Pattern replacePattern;
		private final String replacement;

		public XmlReplacementPattern(String searchPattern, Pattern replacePattern, String replacement) {
			this.searchPattern = searchPattern;
			this.replacePattern = replacePattern;
			this.replacement = replacement;
		}

		public Pattern getReplacePattern() {
			return replacePattern;
		}

		public boolean supports(String xml) {
			return xml.contains(searchPattern);
		}

		public String getReplacement() {
			return replacement;
		}

	}

	/**
	 * Removes the value from element name
	 *
	 * @param elementName
	 * @param xmlString
	 * @return
	 */
	public static String removeXMLValue(String elementName, String xmlString) {
		String retVal = xmlString;
		if (retVal.contains(elementName)) {
			List<XmlReplacementPattern> patterns = getPatterns(elementName);
			for (XmlReplacementPattern pattern : patterns) {
				if (pattern.supports(retVal)) {
					Matcher matcher = pattern.getReplacePattern().matcher(retVal);
					retVal = matcher.replaceAll(pattern.getReplacement());
				}
			}
		}
		return retVal;
	}

	private static List<XmlReplacementPattern> getPatterns(String elementName) {
		List<XmlReplacementPattern> retVal;
		if (!XML_ELEMENT_PARSE_MAP.containsKey(elementName)) {
			loadPatterns(elementName);
		}
		retVal = XML_ELEMENT_PARSE_MAP.get(elementName);
		return retVal;
	}

	private static void loadPatterns(String elementName) {
		synchronized (XML_ELEMENT_PARSE_MAP) {
			if (!XML_ELEMENT_PARSE_MAP.containsKey(elementName)) {
				List<XmlReplacementPattern> patterns = new ArrayList<XmlReplacementPattern>(2);
				// Element search
				String elementRegexp = String.format(ELEMENT_REPLACE_UNFORMATTED_PATTERN, elementName);
				Pattern elementPattern = Pattern.compile(elementRegexp);
				String elementSearch = String.format(ELEMENT_SEARCH_UNFORMATTED_PATTERN, elementName);
				XmlReplacementPattern elementReplacePattern = new XmlReplacementPattern(elementSearch, elementPattern,
						ELEMENT_XML_REPLACEMENT);
				patterns.add(elementReplacePattern);
				// Attribute search
				String attributeRegexp = String.format(ATTRIBUTE_REPLACE_UNFORMATTED_PATTERN, elementName);
				Pattern attributePattern = Pattern.compile(attributeRegexp);
				String attributeSearch = String.format(ATTRIBUTE_SEARCH_UNFORMATTED_PATTERN, elementName);
				XmlReplacementPattern attributeReplacePattern = new XmlReplacementPattern(attributeSearch,
						attributePattern, ATTRIBUTE_XML_REPLACEMENT);
				patterns.add(attributeReplacePattern);
				XML_ELEMENT_PARSE_MAP.put(elementName, patterns);
			}
		}
	}

	/**
	 * Checks if a string is empty or null
	 *
	 * @param inputValue
	 * @return
	 */
	public static boolean isEmptyOrNull(String inputValue) {
		return StringUtils.isBlank(inputValue);
	}

	/**
	 * Checks if all strings are empty or null
	 *
	 * @param inputValues
	 * @return true if all inputValues are empty or null; false otherwise
	 */
	public static boolean isEmptyOrNull(String... inputValues) {
		boolean retVal = isEmptyOrNull(inputValues[0]);
		for (String inputValue : inputValues) {
			retVal = (retVal && isEmptyOrNull(inputValue));
		}
		return retVal;
	}

	/**
	 * Checks if a string is empty or null and returns a default value if it is
	 * otherwise return inputValue
	 *
	 * @param inputValue
	 * @return "" or inputValue
	 */
	public static String validateString(String inputValue) {
		return isEmptyOrNull(inputValue) ? "" : inputValue;
	}

	/**
	 * Returns the given string if not empty or null, otherwise, returns the
	 * specified default value
	 *
	 * @param str
	 * @param defaultValue
	 * @return defaultValue or str
	 */
	public static String formatString(String str, String defaultValue) {
		return isEmptyOrNull(str) ? defaultValue : str;
	}

	/**
	 * @param inputValue
	 * @param paddingCharacter
	 * @param length
	 * @return
	 */
	public static String padLeft(String inputValue, char paddingCharacter, int length) {
		return StringUtils.leftPad(inputValue, length, paddingCharacter);
	}

	/**
	 * @param inputValue
	 * @param paddingCharacter
	 * @param length
	 * @return
	 */
	public static String padRight(String inputValue, char paddingCharacter, int length) {
		return StringUtils.rightPad(inputValue, length, paddingCharacter);
	}

	/**
	 * @param inputValue
	 * @return
	 */
	public static String xmlEncode(String inputValue) {
		return StringEscapeUtils.escapeXml(inputValue);
	}

	/**
	 *
	 * @param inputValue
	 * @return
	 */
	public static String xmlDecode(String inputValue) {
		return StringEscapeUtils.unescapeXml(inputValue);
	}

	/**
	 * @param t
	 * @return
	 */
	public static String exceptionToString(Throwable t) {
		String retVal;
		if (t == null) {
			retVal = "";
		} else {
			retVal = ExceptionUtils.getStackTrace(t);
		}
		return retVal;
	}

	/**
	 * @param stringVal
	 * @return
	 */
	public static int safeParsingInt(String stringVal) {
		return safeParsingInt(stringVal, 0);
	}

	public static int safeParsingInt(String stringVal, int defaultValue) {
		if (!isEmptyOrNull(stringVal)) {
			try {
				defaultValue = Integer.parseInt(stringVal.trim());
			} catch (NumberFormatException e) {
				// Return the default value.
			}
		}
		return defaultValue;
	}

	/**
	 * @param stringVal
	 * @return
	 */
	public static float safeParsingFloat(String stringVal, float defaultVal) {
		if (!isEmptyOrNull(stringVal)) {
			try {
				defaultVal = Float.parseFloat(stringVal.trim());
			} catch (NumberFormatException e) {
				// Return the default value.
			}
		}
		return defaultVal;
	}

	/**
	 * @param stringVal
	 * @return
	 */
	public static double safeParsingDouble(String stringVal, double defaultVal) {
		if (!isEmptyOrNull(stringVal)) {
			try {
				defaultVal = Double.parseDouble(stringVal.trim());
			} catch (NumberFormatException e) {
				// Return the default value.
			}
		}
		return defaultVal;
	}

	/**
	 * @param stringVal
	 * @return
	 */
	public static short safeParsingShort(String stringVal) {
		return safeParsingShort(stringVal, (short) 0);
	}

	public static short safeParsingShort(String stringVal, short defaultValue) {
		if (!isEmptyOrNull(stringVal)) {
			try {
				defaultValue = Short.parseShort(stringVal.trim());
			} catch (NumberFormatException e) {
				// Return the default value.
			}
		}
		return defaultValue;
	}

	public static byte safeParsingByte(String stringVal, byte defaultValue) {
		if (isNotEmptyOrNull(stringVal)) {
			try {
				defaultValue = Byte.parseByte(stringVal.trim());
			} catch (NumberFormatException e) {
				// Return the default value.
			}
		}
		return defaultValue;
	}

	public static long safeParsingLong(String stringVal) {
		return safeParsingLong(stringVal, 0L);
	}

	public static long safeParsingLong(String stringVal, long defaultValue) {
		if (!isEmptyOrNull(stringVal)) {
			try {
				defaultValue = Long.parseLong(stringVal.trim());
			} catch (NumberFormatException e) {
				// Return the default value.
			}
		}
		return defaultValue;
	}

	public static char safeCharAt(String strVal, int index, char defaultVal) {
		if (!isEmptyOrNull(strVal) && index < strVal.length()) {
			return strVal.charAt(index);
		}
		return defaultVal;
	}

	/**
	 * Returns an empty string if Character c is null, or the \0 character.
	 *
	 * @param c
	 * @return
	 */
	public static String safeCharacterToString(Character c) {
		String defaultVal = "";
		if (c != null && c != '\0') {
			defaultVal = c.toString();
		}
		return defaultVal;
	}

	/**
	 * Truncate a string to the given maximum length, if necessary
	 *
	 * @param strVal
	 *            the string to truncate, if it exceeds maximumLength
	 * @param maximumLength
	 *            the maximum length of the string
	 * @return
	 */
	public static String safeTruncate(String strVal, int maximumLength) {
		String retVal = "";
		if (isNotEmptyOrNull(strVal)) {
			retVal = strVal;
			if (maximumLength >= 0) {
				retVal = StringUtils.substring(strVal, 0, maximumLength);
			}
		}
		return retVal;
	}

	/**
	 * Method to split the string
	 *
	 * @param str
	 * @param splitKey
	 * @return
	 */
	public static String[] split(String str, String splitKey) {
		return StringUtils.split(str, splitKey);
	}

	/**
	 * Checks if a string is not empty/null
	 *
	 * @param inputValue
	 * @return
	 */
	public static boolean isNotEmptyOrNull(String inputValue) {
		return !isEmptyOrNull(inputValue);
	}

	/**
	 * Checks if all strings are not empty/null
	 *
	 * @param inputValues
	 * @return true if all inputValues are not empty/null; false otherwise
	 */
	public static boolean isNotEmptyOrNull(String... inputValues) {
		boolean retVal = isNotEmptyOrNull(inputValues[0]);
		for (String inputValue : inputValues) {
			retVal = (retVal && isNotEmptyOrNull(inputValue));
		}
		return retVal;
	}

	/**
	 * Converts first letter of inValue string to capital case.
	 *
	 * @param inValue
	 * @return
	 */
	public static String firstLetterToUpperCase(String inValue) {
		return inValue.substring(0, 1).toUpperCase() + inValue.substring(1);
	}

	public static BigDecimal safeParseBigDecimal(String value) {
		BigDecimal retVal = null;
		if (isNotEmptyOrNull(value)) {
			retVal = new BigDecimal(value);
		}
		return retVal;
	}

	/**
	 * Converts inValue string to upper case (and trims)
	 *
	 * @param inValue
	 * @return
	 */
	public static String safeUpperCase(String inValue) {
		String retVal = "";
		if (isNotEmptyOrNull(inValue)) {
			retVal = inValue.toUpperCase();
		}
		return retVal.trim();
	}

	public static String decimalFormat(double value) {
		return customFormat("###,##0.00", value);
	}

	public static String customFormat(String pattern, double value) {
		DecimalFormat myFormatter = new DecimalFormat(pattern);
		String output = myFormatter.format(value);
		return output;
	}

	public static String stripLeading(String value, String strippedChars) {
		return StringUtils.stripStart(value, strippedChars);
	}

	public static String stripTrailing(String value, String strippedChars) {
		return StringUtils.stripEnd(value, strippedChars);
	}

	public static String removeAll(String value, String removeChars) {
		return StringUtils.remove(value, removeChars);
	}

	public static String stripCharsInBag(String s, String bag) {
		String returnString = "";
		char c;
		// Search through string's characters one by one.
		// If character is not in bag, append to returnString.
		for (int i = 0; i < s.length(); i++) {
			// Check that current character isn't whitespace.
			c = s.charAt(i);
			if (bag.indexOf(c) == -1) {
				returnString += c;
			}
		}
		return returnString;
	}

	public static boolean safeParseBoolean(String value, String trueValue, boolean ignoreCase) {
		boolean retVal = false;
		if (isNotEmptyOrNull(value)) {
			if (ignoreCase) {
				retVal = value.equalsIgnoreCase(trueValue);
			} else {
				retVal = value.equals(trueValue);
			}
		}
		return retVal;
	}

	/**
	 * <b>Uses:</b> <br/>
	 * contains("abc", null) returns false <br/>
	 * contains("abc, "") returns false <br/>
	 * contains(null, "abc") returns false <br/>
	 * contains("", "abc") returns false <br/>
	 * contains(null, null) returns false <br/>
	 * contains("", "") returns false <br/>
	 * contains("abc", "a") returns true
	 *
	 * @param str
	 * @param searchStr
	 * @return <code>true</code> if the str contains the searchStr. <br/>
	 *         or <code>false</code> if str is blank, or searchStr is blank.
	 */
	public static boolean safeContains(String str, String searchStr) {
		if (isEmptyOrNull(str) || isEmptyOrNull(searchStr)) {
			return false;
		}
		return str.contains(searchStr);
	}

	/**
	 * Removes multiple occurrence of space by one space, removes
	 * leading/trailing spaces alongwith
	 *
	 * @param str
	 *            - String from which the extra spaces needs to be removed
	 * @return - String without extra spaces.
	 */
	public static String removeExtraSpaces(String str) {
		String newStr = "";
		String[] strParts;
		strParts = str.split(" ");
		for (int i = 0; i < strParts.length; i++) {
			if (strParts[i].length() != 0) {
				newStr += strParts[i] + " ";
			}
		}
		return newStr.trim();
	}

	/**
	 * Removes multiple occurrence of space by one space, removes
	 * leading/trailing spaces alongwith
	 *
	 * @param str
	 *            - String from which the extra spaces needs to be removed and
	 *            handles null conditions
	 * @return - String without extra spaces.
	 */
	public static String safeRemoveExtraSpaces(String str) {
		String newStr = "";
		if (isNotEmptyOrNull(str)) {
			String[] strParts;
			strParts = str.split(" ");
			for (int i = 0; i < strParts.length; i++) {
				if (strParts[i].length() != 0) {
					newStr += strParts[i] + " ";
				}
			}
			return newStr.trim();
		}
		return newStr;
	}

	public static String getRootCauseMessage(Throwable th) {
		Throwable root = ExceptionUtils.getRootCause(th);
		root = (root == null ? th : root);
		return root.getMessage();
	}

	public static List<String> splitStringBySize(String str, int size) {
		List<String> strList = new ArrayList<String>();
		if (StringUtilities.isNotEmptyOrNull(str)) {
			for (int start = 0; start < str.length(); start += size) {
				String text = str.substring(start, Math.min(str.length(), start + size));
				strList.add(text);
			}
		}
		return strList;
	}

	/**
	 * Masks a card number. Masks all the numbers with # except for the last 4
	 * digits.<br/>
	 *
	 * <pre>
	 * maskCardNumber(null)               = ""
	 * maskCardNumber("")                 = ""
	 * maskCardNumber("0")                = "0"
	 * maskCardNumber("2222")             = "2222"
	 * maskCardNumber("1234567890")       = "######7890"
	 * maskCardNumber("1234567890123456") = "############3456"
	 * </pre>
	 *
	 * @param cardNumber
	 * @return
	 */
	public static String maskCardNumber(String cardNumber, final char MASK_CHAR) {
		if (cardNumber == null) {
			return "";
		}
		char[] array = cardNumber.toCharArray();
		char[] c = new char[cardNumber.length()];
		if (cardNumber.length() < 4) {
			for (int i = 0; i < cardNumber.length(); i++) {
				c[i] = array[i];
			}
		} else {
			for (int i = 0; i < cardNumber.length() - 4; i++) {
				c[i] = MASK_CHAR;
			}
			for (int i = cardNumber.length() - 4; i < cardNumber.length(); i++) {
				c[i] = array[i];
			}
		}
		return new String(c);
	}

	/**
	 * Returns the same number of MASK_CHAR as string length.
	 *
	 * @param s
	 * @param MASK_CHAR
	 * @return
	 */
	public static String maskAll(String s, final char MASK_CHAR) {
		if (isEmptyOrNull(s)) {
			return "";
		}
		char[] c = new char[s.length()];
		for (int i = 0; i < s.length(); i++) {
			c[i] = MASK_CHAR;
		}
		return new String(c);
	}

	/**
	 * Join a List of strings.
	 *
	 * @param inp
	 *            - input List
	 * @param sep
	 *            - separator String.
	 * @return
	 */
	public static String join(List<String> inp, String sep) {
		if (inp == null || inp.size() == 0) {
			return "";
		}
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < inp.size(); i++) {
			if (i > 0) {
				sb.append(sep);
			}
			sb.append(inp.get(i));
		}
		return sb.toString();
	}

	/**
	 * Converts inputValue string to Integer Array inputValue may be string
	 * seperated by a "," "~" or any other string Example : inputValue -
	 * "6,06,33,86,7,07,56,63". seperator - "," inputValue - "75". seperator -
	 * ""
	 *
	 * @param inputValue
	 * @param seperator
	 * @return
	 */
	public static Integer[] converToIntegerArray(String inputValue, String seperator) {
		String[] strArray = inputValue.split(seperator);
		Integer[] integerArray = new Integer[strArray.length];
		for (int i = 0; i < strArray.length; i++) {
			integerArray[i] = Integer.valueOf(strArray[i]);
		}
		return integerArray;
	}

	public static String substringBefore(String str, String separator) {
		return StringUtils.substringBefore(str, separator);
	}

	public static String hexEncode(byte[] _bytes) {
		StringBuilder s = new StringBuilder(2 * _bytes.length);
		for (int i = 0; i < _bytes.length; i++) {
			int v = _bytes[i] & 0xff;
			s.append((char) HexChars[v >> 4]);
			s.append((char) HexChars[v & 0xf]);
		}
		return s.toString();
	}

	public static byte[] hexDecode(String _hexedByteString) {
		byte[] _bytes = new byte[0];
		if (isNotEmptyOrNull(_hexedByteString)) {
			_bytes = new BigInteger(_hexedByteString, 16).toByteArray();
		}
		return _bytes;
	}

	public static String prepad(String inStr, char prepadChar, int totalLength) {
		String paddedStr = "";
		int numPaddingReqd = totalLength - inStr.length();
		for (int i = 0; i < numPaddingReqd; i++) {
			paddedStr += prepadChar;
		}
		paddedStr += inStr;
		return paddedStr;
	}
}
