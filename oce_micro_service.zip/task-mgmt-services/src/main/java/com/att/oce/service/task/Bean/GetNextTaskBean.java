package com.att.oce.service.task.Bean;

import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;

public interface GetNextTaskBean extends BasicTaskBean{

	String getNextTask(TaskDetailsVO taskDetailsVO) throws OCEException;
}