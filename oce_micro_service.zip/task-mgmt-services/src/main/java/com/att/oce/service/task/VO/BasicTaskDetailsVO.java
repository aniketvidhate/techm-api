package com.att.oce.service.task.VO;

import java.util.Arrays;
import java.util.Date;

import com.att.oce.service.task.util.StringUtilities;

public class BasicTaskDetailsVO {

	private String mTaskId;
	private Date mCreationDate;
	private String mTaskStatus;
	private String avosRefId;
	private Date mOrderAcceptedDate;
	long taskLineCount;

	/**
	 * @return the taskLineCount
	 */
	public long getTaskLineCount() {
		return taskLineCount;
	}
	/**
	 * @param taskLineCount the taskLineCount to set
	 */
	public void setTaskLineCount(long taskLineCount) {
		this.taskLineCount = taskLineCount;
	}
	public String getAvosRefId() {
		return avosRefId;
	}
	public void setAvosRefId(String avosRefId) {
		this.avosRefId = avosRefId;
	}

	private Date mLast_modified_date;

	public BasicTaskDetailsVO(TaskDetailsVO vo) {
		this.setTaskCreationDate(vo.getCreationDate());
		this.setTaskId(vo.getTaskId());
		this.setTaskModifiedDate(vo.getLast_modified_date());
		this.setTaskStatus(vo.getTaskStatus());
		this.setAvosRefId(vo.getAvos_task_id());
		this.setOrderAcceptedDate(vo.getAcceptedDate());
		this.setTaskLineCount(getLosgIdsCount(vo.getLosgId()));
		
	}
	
	/**
	 * Gets the losg ids.
	 *
	 * @param losgId the losg id
	 * @return the losg ids
	 */
	private long getLosgIdsCount(String losgId) {
		
		String[] items = null;
		if (StringUtilities.isNotEmptyOrNull(losgId)) {
			items = losgId.split(",");
			return (Arrays.asList(items).size());
			
		} else {
			return 0;
		}
	}
	/**
	 * @return the mTaskId
	 */
	public String getTaskId() {
		return mTaskId;
	}

	/**
	 * @param mTaskId
	 *            the mTaskId to set
	 */
	public void setTaskId(String mTaskId) {
		this.mTaskId = mTaskId;
	}

	/**
	 * @return the mTaskCreationDate
	 */
	public Date getTaskCreationDate() {
		return mCreationDate;
	}

	/**
	 * @param mTaskCreationDate
	 *            the mTaskCreationDate to set
	 */
	public void setTaskCreationDate(Date mTaskCreationDate) {
		this.mCreationDate = mTaskCreationDate;
	}

	/**
	 * @return the mTaskStatus
	 */
	public String getTaskStatus() {
		return mTaskStatus;
	}

	/**
	 * @param mTaskStatus
	 *            the mTaskStatus to set
	 */
	public void setTaskStatus(String mTaskStatus) {
		this.mTaskStatus = mTaskStatus;
	}

	@Override
	public boolean equals(Object object) {
		boolean result = false;
		if (object == null || object.getClass() != getClass()) {
			result = false;
		} else {
			BasicTaskDetailsVO vo = (BasicTaskDetailsVO) object;
			if (this.mTaskId == vo.getTaskId()) {
				result = true;
			}
		}
		return result;
	}

	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();

		buf.append("Task Id : ");
		buf.append(this.mTaskId);
		buf.append(" Creation Date : ");
		buf.append(this.mCreationDate);
		buf.append(" Task Status : ");
		buf.append(this.mTaskStatus);
		buf.append(" Task Modified Date : ");
		buf.append(this.mLast_modified_date);
		buf.append(" Avos Ref Id : ");
		buf.append(this.avosRefId);
		buf.append(" Order Creation Date : ");
		buf.append(this.mOrderAcceptedDate);
		
		return buf.toString();
	}

	/**
	 * @return the mTaskModifiedDate
	 */
	public Date getTaskModifiedDate() {
		return mLast_modified_date;
	}

	/**
	 * @param mTaskModifiedDate
	 *            the mTaskModifiedDate to set
	 */
	public void setTaskModifiedDate(Date pTaskModifiedDate) {
		this.mLast_modified_date = pTaskModifiedDate;
	}
	/**
	 * @return the mOrderCreationDate
	 */
	public Date getOrderAcceptedDate() {
		return mOrderAcceptedDate;
	}
	/**
	 * @param mOrderCreationDate the mOrderCreationDate to set
	 */
	public void setOrderAcceptedDate(Date mOrderCreationDate) {
		this.mOrderAcceptedDate = mOrderCreationDate;
	}

}
