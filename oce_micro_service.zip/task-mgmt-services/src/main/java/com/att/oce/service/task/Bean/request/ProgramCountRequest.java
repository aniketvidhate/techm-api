package com.att.oce.service.task.Bean.request;

import java.util.List;

/**
 * The Class ProgramCountRequest.
 */
public class ProgramCountRequest {

	/** The org unit list. */
	private List<String> orgUnitList; 
	
	/** The partner list. */
	private List<String> partnerList; 
	
	/** The queue type list. */
	private List<String> queueTypeList; 
	
	/** The queue or program. */
	private String queueOrProgram; 
	
	/** The callback preference. */
	private String callbackPreference; 
	
	/** The is global visible. */
	private boolean isGlobalVisible;
	
	/** The request type. */
	private String requestType;
	
	/** The queue input type. */
	private String queueInputType;
	
	/**
	 * Gets the org unit list.
	 *
	 * @return the orgUnitList
	 */
	public List<String> getOrgUnitList() {
		return orgUnitList;
	}
	
	/**
	 * Gets the partner list.
	 *
	 * @return the partnerList
	 */
	public List<String> getPartnerList() {
		return partnerList;
	}
	
	/**
	 * Gets the queue type list.
	 *
	 * @return the queueTypeList
	 */
	public List<String> getQueueTypeList() {
		return queueTypeList;
	}
	
	/**
	 * Gets the queue or program.
	 *
	 * @return the queueOrProgram
	 */
	public String getQueueOrProgram() {
		return queueOrProgram;
	}
	
	/**
	 * Gets the callback preference.
	 *
	 * @return the callbackPreference
	 */
	public String getCallbackPreference() {
		return callbackPreference;
	}
	
	/**
	 * Checks if is global visible.
	 *
	 * @return the isGlobalVisible
	 */
	public boolean isGlobalVisible() {
		return isGlobalVisible;
	}
	
	/**
	 * Sets the org unit list.
	 *
	 * @param orgUnitList the orgUnitList to set
	 */
	public void setOrgUnitList(List<String> orgUnitList) {
		this.orgUnitList = orgUnitList;
	}
	
	/**
	 * Sets the partner list.
	 *
	 * @param partnerList the partnerList to set
	 */
	public void setPartnerList(List<String> partnerList) {
		this.partnerList = partnerList;
	}
	
	/**
	 * Sets the queue type list.
	 *
	 * @param queueTypeList the queueTypeList to set
	 */
	public void setQueueTypeList(List<String> queueTypeList) {
		this.queueTypeList = queueTypeList;
	}
	
	/**
	 * Sets the queue or program.
	 *
	 * @param queueOrProgram the queueOrProgram to set
	 */
	public void setQueueOrProgram(String queueOrProgram) {
		this.queueOrProgram = queueOrProgram;
	}
	
	/**
	 * Sets the callback preference.
	 *
	 * @param callbackPreference the callbackPreference to set
	 */
	public void setCallbackPreference(String callbackPreference) {
		this.callbackPreference = callbackPreference;
	}
	
	/**
	 * Sets the global visible.
	 *
	 * @param isGlobalVisible the isGlobalVisible to set
	 */
	public void setGlobalVisible(boolean isGlobalVisible) {
		this.isGlobalVisible = isGlobalVisible;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {

		StringBuffer buf = new StringBuffer();
		buf.append("Organization List : ");
		buf.append(this.getOrgUnitList().toString());
		buf.append("Partner List : ");
		buf.append(this.getPartnerList().toString());
		buf.append("QueueTypeList : ");
		buf.append(this.getQueueTypeList().toString());
		buf.append("QueueorProgram : ");
		buf.append(this.getQueueOrProgram());
		buf.append("callBackPreference : ");
		buf.append(this.getCallbackPreference());
		buf.append("isGlobalVisisble : ");
		buf.append(this.isGlobalVisible());
		buf.append("requestType : ");
		buf.append(this.getRequestType());
		
		return buf.toString();
	}
	
	/**
	 * Gets the request type.
	 *
	 * @return the requestType
	 */
	public String getRequestType() {
		return requestType;
	}
	
	/**
	 * Sets the request type.
	 *
	 * @param requestType the requestType to set
	 */
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	
	/**
	 * Gets the queue input type.
	 *
	 * @return the queueInputType
	 */
	public String getQueueInputType() {
		return queueInputType;
	}
	
	/**
	 * Sets the queue input type.
	 *
	 * @param queueInputType the queueInputType to set
	 */
	public void setQueueInputType(String queueInputType) {
		this.queueInputType = queueInputType;
	}
}
