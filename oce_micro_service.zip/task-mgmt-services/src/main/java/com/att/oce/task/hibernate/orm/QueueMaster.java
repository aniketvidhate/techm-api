package com.att.oce.task.hibernate.orm;

public class QueueMaster {
	
	private String queueType;

	public String getQueueType() {
		return queueType;
	}

	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}
	

}
