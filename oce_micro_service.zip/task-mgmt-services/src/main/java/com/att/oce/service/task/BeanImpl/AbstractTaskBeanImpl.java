package com.att.oce.service.task.BeanImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.oce.service.task.Bean.BasicTaskBean;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.TaskConstants;

import reactor.Environment;
import reactor.bus.Event;
import reactor.bus.EventBus;

/**
 * This method will have common functionality of below beans Taskinfo bean DB
 * TaskInfo Bean GetNext Bean Order Bean
 * 
 * @author SX00352475
 *
 */
public abstract class AbstractTaskBeanImpl implements BasicTaskBean {

	public static EventBus eventBus = null;

	protected static Environment environment = null;
	private Logger logger = LoggerFactory.getLogger(AbstractTaskBeanImpl.class);

	static {
		System.out.println("Initialzing envrionment");
		Environment environment = Environment.initializeIfEmpty().assignErrorJournal();
		eventBus = EventBus.create(environment, Environment.THREAD_POOL);
	}

	public void prepareEnvironment() throws OCEException {
		try {
			logger.info("In prepare environment");

			if (environment == null && eventBus == null) {

				logger.info("First time Preparing envrionment ");

				Environment environment = Environment.initializeIfEmpty().assignErrorJournal();
				eventBus = EventBus.create(environment, Environment.THREAD_POOL);

			} else {

				logger.info("Environment already prepared");
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			throw new OCEException(ex.getMessage());
		}
	}

	public EventBus getEnv() {

		return eventBus;
	}

	/**
	 * This method will notify all below beans to process create task operation
	 * 
	 */
	protected void publishEvent(String eventId, List<TaskDetailsVO> taskDetailsList) {

		eventBus.notify(eventId, Event.wrap(taskDetailsList));

	}

	@Override
	public void accept(Event<List<TaskDetailsVO>> ev) {
		try {
			if (ev.getKey().toString().equals(TaskConstants.TASK_LOADED)) {
				initialize(ev.getData());
			} else if (ev.getKey().toString().equals(TaskConstants.TASK_CREATED)) {
				createTasks(ev.getData());
			} else if (ev.getKey().toString().equals(TaskConstants.TASK_UPDATED)) {
				updateTasks(ev.getData());
			} else {
				logger.error("Unknown event is caught");
			}
		} catch (OCEException e) {
			logger.error("OCEException Occurred", e);
		}
	}

	@Override
	public void purgeTestData() throws OCEException {
	}
	
}
