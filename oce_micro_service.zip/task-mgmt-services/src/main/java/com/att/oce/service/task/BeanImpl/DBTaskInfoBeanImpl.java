package com.att.oce.service.task.BeanImpl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.AliasToBeanResultTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtOrderTask;
import com.att.oce.service.DateUtil;
import com.att.oce.service.queueImpl.QueueDetails;
import com.att.oce.service.task.Bean.DBTaskInfoBean;
import com.att.oce.service.task.Bean.request.ProgramCountRequest;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.TaskConstants;
import com.att.oce.task.hibernate.orm.OCEQueueDetails;
import com.att.oce.task.hibernate.orm.OCETaskDetails;

import reactor.bus.Event;

/**
 * 
 * @author SX00352475
 *
 */
@Component
public class DBTaskInfoBeanImpl extends AbstractTaskBeanImpl implements DBTaskInfoBean {

//	@Autowired(required = true)
//	private HibernateTemplate hTemplate;

	@Autowired(required = true)
	@Qualifier("mysessionFactory")
	private SessionFactory sessionFactory;
	private Logger logger = LoggerFactory.getLogger(DBTaskInfoBeanImpl.class);

	@Value("${channel}")
	private String channel;
	
	/**
	 * This method is used to fetch all task records from oce_task_details
	 * 
	 * @throws OCEException
	 * 
	 */
	@Override
	public Collection<TaskDetailsVO> fetchAllTasks() throws OCEException {
		List<TaskDetailsVO> detaislList = new ArrayList<TaskDetailsVO>();
		Session session = sessionFactory.openSession();
		try {

			String fetchAllTasksQuery = "select t1.mTaskId as mTaskId, t1.mCreationDate as mCreationDate, t1.mOrderRef as mOrderRef,t1.mCsrId as mCsrId,t1.mChannel as mChannel,t1.mOwner as mOwner,t1.mLosgId as mLosgId,t1.mRequestType as mRequestType,t1.mActionType as mActionType,t1.mWirelessFallout as mWirelessFallout,"
					+ "t1.mTaskStatus as mTaskStatus,t1.mTaskSubStatus as mTaskSubStatus,t2.mQueueType as mQueueType,t2.mQueueCategory as mQueueCategory,t2.mProgram as mProgram,t2.mLineAction as mLineAction,t2.mLineCombos as mLineCombos,t2.mLineCount as mLineCount "
					+ "from OCETaskDetails t1,OCEQueueDetails t2,DcsppOrder o where t2.mTaskId = t1.mTaskId and o.mOrderId = t1.mOrderRef AND t1.mTaskSubStatus = 'IN_QUEUE' AND o.mState = 'IN_PROGRESS'";
			logger.info("Task in progress in fetchAllTasks()::");
			Query query = session.createQuery(fetchAllTasksQuery);
			query.setResultTransformer(new AliasToBeanResultTransformer(TaskDetailsVO.class));
			query.setFirstResult(5);
			query.setMaxResults(10);
			detaislList = query.list();

			for (TaskDetailsVO vo : detaislList) {
				logger.trace("VO :" + vo);
			}

		} catch (Exception he) {
			logger.error(he.getMessage());
			throw new OCEException(he.getMessage());
		} finally {
			session.close();
		}

		return detaislList;
	}
	
	
	/**
	 * This method is used to fetch all outbound task records from oce_task_details, OCE_Queue_Details, 
	 * dcspp_order, oce_dcspp_order 
	 * 
	 * @throws OCEException
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Collection<TaskDetailsVO> fetchAllOutboundTasks() throws OCEException {
		
		List<TaskDetailsVO> detaislList = new ArrayList<TaskDetailsVO>();
		Session session = sessionFactory.openSession();
		
		try {

			String fetchAllOutboundTasksQuery = "SELECT t1.mTaskId as mTaskId, t1.mCreationDate as mCreationDate, "
					+ " t1.mOrderRef as mOrderRef, o1.mExternalOrderNum as mExternalOrderNum, t1.mCsrId as mCsrId, "
					+ " t1.mChannel as mChannel, t1.mOwner as mOwner, t1.mLosgId as mLosgId, "
					+ " t1.mRequestType as mRequestType, t1.mActionType as mActionType, "
					+ " t1.mWirelessFallout as mWirelessFallout, t1.mTaskStatus as mTaskStatus, "
					+ " t1.mTaskSubStatus as mTaskSubStatus, t2.mQueueType as mQueueType, "
					+ " t2.mQueueCategory as mQueueCategory, t2.mProgram as mProgram, "
					+ " t2.mLineAction as mLineAction, t2.mLineCombos as mLineCombos, t2.mLineCount as mLineCount,"
					+ " o1.mAcceptedDate as mAcceptedDate "
					+ " FROM OCETaskDetails t1, OCEQueueDetails t2, DcsppOrder o , OceDcsppOrder o1 "
					+ " WHERE o.mOrderId =o1.mOrderId and t2.mTaskId = t1.mTaskId "
					+ " and o.mOrderId = t1.mOrderRef and t1.mTaskStatus IN('NEW','UNCLAIMED') "
					+ " AND t1.mTaskSubStatus = 'IN_QUEUE' and t2.mQueueType ='UNSCHEDULED_OUTBOUND'";
			
			logger.info("Task in progress in fetchAllOutboundTasks()::");
			
			Query query = session.createQuery(fetchAllOutboundTasksQuery);
			query.setResultTransformer(new AliasToBeanResultTransformer(TaskDetailsVO.class));
			detaislList = query.list();

			for (TaskDetailsVO vo : detaislList) {
				logger.trace("VO :" + vo);
			}

		} catch (Exception he) {
			logger.error(he.getMessage());
			throw new OCEException(he.getMessage());
		} finally {
			session.close();
		}

		return detaislList;
	}
	

	/**
	 * This method is used to fetch all task records from oce_task_details
	 * 
	 */
	@Override
	public Collection<TaskDetailsVO> fetchAllOpenTask() throws OCEException {

		List<TaskDetailsVO> result = null;
		Session session = sessionFactory.openSession();
		try {
			/*String fetchAllOpenTaskQuery = "select t1.mTaskId as mTaskId,t1.mAvos_task_id as mAvos_task_id, t1.mCreationDate as mCreationDate, t1.mOrderRef as mOrderRef,o1.mExternalOrderNum as mExternalOrderNum,t1.mCsrId as mCsrId,t1.mChannel as mChannel,t1.mOwner as mOwner,t1.mLosgId as mLosgId,t1.mRequestType as mRequestType,t1.mActionType as mActionType,t1.mWirelessFallout as mWirelessFallout,"
			+ "t1.mTaskStatus as mTaskStatus,t1.mTaskSubStatus as mTaskSubStatus,t2.mQueueType as mQueueType,t2.mQueueCategory as mQueueCategory,t2.mProgram as mProgram,t2.mLineAction as mLineAction,t2.mLineCombos as mLineCombos,t2.mLineCount as mLineCount, t1.mLast_modified_date as mLast_modified_date," 
			+ "o.dCreationDate as dCreationDate,o1.mAcceptedDate as mAcceptedDate, t1.mCallbackPreference as mCallbackPreference from OCETaskDetails t1,OCEQueueDetails t2,"
			+ "DcsppOrder o ,OceDcsppOrder o1 where o.mOrderId =o1.mOrderId and t2.mTaskId = t1.mTaskId and o.mOrderId = t1.mOrderRef and t1.mTaskStatus IN ('"
			+ TaskConstants.NEW + "', '" + TaskConstants.UNCLAIMED + "') " + "AND t1.mTaskSubStatus = '" 
			+ TaskConstants.IN_QUEUE + "' AND o.mState = '" + TaskConstants.IN_PROGRESS + "'";*/

			// 2 records
			/*String fetchAllOpenTaskQuery = "select t1.mTaskId as mTaskId,t1.mTaskId as mTaskId,t1.mAvos_task_id as mAvos_task_id, t1.mCreationDate as mCreationDate, t1.mOrderRef as mOrderRef,o1.mExternalOrderNum as mExternalOrderNum,t1.mCsrId as mCsrId,t1.mChannel as mChannel,t1.mOwner as mOwner,t1.mLosgId as mLosgId,t1.mRequestType as mRequestType,t1.mActionType as mActionType,t1.mWirelessFallout as mWirelessFallout,"
					+ "t1.mTaskStatus as mTaskStatus,t1.mTaskSubStatus as mTaskSubStatus,t2.mQueueType as mQueueType,t2.mQueueCategory as mQueueCategory,t2.mProgram as mProgram,t2.mLineAction as mLineAction,t2.mLineCombos as mLineCombos,t2.mLineCount as mLineCount, t1.mLast_modified_date as mLast_modified_date, "
					+ " o.dCreationDate as dCreationDate from OCETaskDetails t1,OCEQueueDetails t2,"
					+ "DcsppOrder o ,OceDcsppOrder o1 where o.mOrderId =o1.mOrderId and t2.mTaskId = t1.mTaskId and o.mOrderId = t1.mOrderRef and t1.mTaskStatus IN ('"
					+ TaskConstants.NEW
					+ "', '"
					+ TaskConstants.UNCLAIMED
					+ "') "
					+ "AND t1.mTaskSubStatus = '"
					+ TaskConstants.IN_QUEUE
					+ "' AND o.mState = '"
					+ TaskConstants.IN_PROGRESS
					+ "'"
					+ " and t2.mLineCombos='INTERNET + DIRECTV' AND t2.mProgram='UV - DTV' AND t2.mLineAction='NEW' "
					+ "AND t2.mQueueType='OTHER' AND t2.mQueueCategory='REGULAR' AND t1.mChannel='CDE-HS' AND t1.mRequestType='NA'"
					+ "AND t1.mActionType='NA'";*/
			
		 
			
			//D2 19000 records
			String fetchAllOpenTaskQuery = "select t1.mTaskId as mTaskId,t1.mTaskId as mTaskId,t1.mAvos_task_id as mAvos_task_id, t1.mCreationDate as mCreationDate, t1.mOrderRef as mOrderRef,o1.mExternalOrderNum as mExternalOrderNum,t1.mCsrId as mCsrId,t1.mChannel as mChannel,t1.mOwner as mOwner,t1.mLosgId as mLosgId,t1.mRequestType as mRequestType,t1.mActionType as mActionType,t1.mWirelessFallout as mWirelessFallout,"
			+ "t1.mTaskStatus as mTaskStatus,t1.mTaskSubStatus as mTaskSubStatus,t2.mQueueType as mQueueType,t2.mQueueCategory as mQueueCategory,t2.mProgram as mProgram,t2.mLineAction as mLineAction,t2.mLineCombos as mLineCombos,t2.mLineCount as mLineCount, t1.mLast_modified_date as mLast_modified_date, "
			+ " o.dCreationDate as dCreationDate,o1.mAcceptedDate as mAcceptedDate, t1.mCallbackPreference as mCallbackPreference from OCETaskDetails t1,OCEQueueDetails t2,"
			+ "DcsppOrder o ,OceDcsppOrder o1 where o.mOrderId =o1.mOrderId and t2.mTaskId = t1.mTaskId and o.mOrderId = t1.mOrderRef and t1.mTaskStatus IN ('"
			+ TaskConstants.NEW
			+ "', '"
			+ TaskConstants.UNCLAIMED
			+ "') "
			+ "AND t1.mTaskSubStatus = '"
			+ TaskConstants.IN_QUEUE
			+ "' AND o.mState = '"
			+ TaskConstants.IN_PROGRESS
			+ "'"
			+ " AND t2.mProgram='UV - DTV' "
			+ " AND t1.mChannel IN ("+ channel +")";
			
			/*and t2.mLineCombos='WIRELESS + DIRECTV' AND t2.mLineAction='NEW' "
			+ "AND t2.mQueueType='PROCESSING' AND t2.mQueueCategory='REGULAR' AND t1.mChannel='CDE-HS' AND t1.mRequestType='NA'"
			+ "AND t1.mActionType='NA' AND t1.mOwner='STI' ";*/
			
			// 66
			/*String fetchAllOpenTaskQuery = "select t1.mTaskId as mTaskId,t1.mTaskId as mTaskId,t1.mAvos_task_id as mAvos_task_id, t1.mCreationDate as mCreationDate, t1.mOrderRef as mOrderRef,o1.mExternalOrderNum as mExternalOrderNum,t1.mCsrId as mCsrId,t1.mChannel as mChannel,t1.mOwner as mOwner,t1.mLosgId as mLosgId,t1.mRequestType as mRequestType,t1.mActionType as mActionType,t1.mWirelessFallout as mWirelessFallout,"
					+ "t1.mTaskStatus as mTaskStatus,t1.mTaskSubStatus as mTaskSubStatus,t2.mQueueType as mQueueType,t2.mQueueCategory as mQueueCategory,t2.mProgram as mProgram,t2.mLineAction as mLineAction,t2.mLineCombos as mLineCombos,t2.mLineCount as mLineCount, t1.mLast_modified_date as mLast_modified_date, "
					+ " o.dCreationDate as dCreationDate,o1.mAcceptedDate as mAcceptedDate, t1.mCallbackPreference as mCallbackPreference from OCETaskDetails t1,OCEQueueDetails t2,"
					+ "DcsppOrder o ,OceDcsppOrder o1 where o.mOrderId =o1.mOrderId and t2.mTaskId = t1.mTaskId and o.mOrderId = t1.mOrderRef and t1.mTaskStatus IN ('"
					+ TaskConstants.NEW
					+ "', '"
					+ TaskConstants.UNCLAIMED
					+ "') "
					+ "AND t1.mTaskSubStatus = '"
					+ TaskConstants.IN_QUEUE
					+ "' AND o.mState = '"
					+ TaskConstants.IN_PROGRESS
					+ "'"
					+ " and t2.mLineCombos='WIRELESS + DIRECTV' AND t2.mProgram='UV - DTV' AND t2.mLineAction='NEW' "
					+ "AND t2.mQueueType='PROCESSING' AND t2.mQueueCategory='REGULAR' AND t1.mChannel='CDE-HS' AND t1.mRequestType='NA'"
					+ "AND t1.mActionType='NA' AND t1.mOwner='STI' ";*/
					
					
			/*String fetchAllOpenTaskQuery = "select t1.mTaskId as mTaskId,t1.mTaskId as mTaskId,t1.mAvos_task_id as mAvos_task_id, t1.mCreationDate as mCreationDate, t1.mOrderRef as mOrderRef,o1.mExternalOrderNum as mExternalOrderNum,t1.mCsrId as mCsrId,t1.mChannel as mChannel,t1.mOwner as mOwner,t1.mLosgId as mLosgId,t1.mRequestType as mRequestType,t1.mActionType as mActionType,t1.mWirelessFallout as mWirelessFallout,"
			+ "t1.mTaskStatus as mTaskStatus,t1.mTaskSubStatus as mTaskSubStatus,t2.mQueueType as mQueueType,t2.mQueueCategory as mQueueCategory,t2.mProgram as mProgram,t2.mLineAction as mLineAction,t2.mLineCombos as mLineCombos,t2.mLineCount as mLineCount, t1.mLast_modified_date as mLast_modified_date, "
			+ " o.dCreationDate as dCreationDate from OCETaskDetails t1,OCEQueueDetails t2,"
			+ "DcsppOrder o ,OceDcsppOrder o1 where o.mOrderId =o1.mOrderId and t2.mTaskId = t1.mTaskId and o.mOrderId = t1.mOrderRef and t1.mTaskStatus IN ('"
			+ TaskConstants.NEW + "', '" + TaskConstants.UNCLAIMED + "') " + "AND t1.mTaskSubStatus = '" 
			+ TaskConstants.IN_QUEUE + "' AND o.mState = '" + TaskConstants.IN_PROGRESS + "'" + " and t2.mLineCombos='WIRELESS + INTERNET + VOIP + DIRECTV' AND t2.mProgram='DF' AND t2.mLineAction='NO_CHANGE' AND t2.mQueueType='PROCESSING'";*/
			
	        logger.info("Task in progress in fetchAllOpenTask()::");
			Query query = session.createQuery(fetchAllOpenTaskQuery);
			query.setResultTransformer(new AliasToBeanResultTransformer(TaskDetailsVO.class));
			/*
			 * query.setFirstResult(5); query.setMaxResults(10);
			 */
			result = query.list();

			/*for (TaskDetailsVO vo : result) {
				logger.trace("VO :" + vo);
			}*/
			
		if(result != null){	
			logger.debug("retrieved data="+result.size());
		}

		} catch (HibernateException he) {
			logger.error(he.getMessage());
			throw new OCEException(he.getMessage());
		} finally {
			session.close();
		}

		return result;

	}

	/**
	 * This method is used to fetch all task records from oce_task_details
	 * 
	 */
	@Override
	public Collection<String> fetchAllOpenTasksIds() throws OCEException {
		List<TaskDetailsVO> detaislList = new ArrayList<TaskDetailsVO>();
		List<String> taskIdList = new ArrayList<String>();
		Session session = sessionFactory.openSession();
		try {
			String initializeQuery = "select t1.mTaskId from OCETaskDetails t1,OCEQueueDetails t2,DcsppOrder o where t2.mTaskId = t1.mTaskId and o.mOrderId = t1.mOrderRef and t1.mTaskStatus IN ('NEW', 'UNCLAIMED') AND t1.mTaskSubStatus = 'IN_QUEUE' AND o.mState = 'IN_PROGRESS'";
			logger.info("Task in progress in initialize()::");
			Query query = session.createQuery(initializeQuery);
			/*
			 * query.setFirstResult(5); query.setMaxResults(10);
			 */
			taskIdList = query.list();
			logger.info("fetchAllOpenTasksIds()::  taskIdList" + taskIdList);
		} catch (HibernateException he) {
			logger.error(he.getMessage());
			throw new OCEException(he.getMessage());
		} finally {
			session.close();
		}
		return taskIdList;
	}

	/**
	 * input Param: TaskDetailsVO object This method is used to insert a record
	 * for oce_task_details
	 * 
	 */
	@Override
	public void createTasks(List<TaskDetailsVO> tasks) throws OCEException {
		Session session = sessionFactory.openSession();
		if (tasks == null || tasks.isEmpty()) {
			return;
		}
		try {
			for (TaskDetailsVO task : tasks) {
				session.beginTransaction();
				
				OCETaskDetails oCETaskDetails = new OCETaskDetails();
				OCEQueueDetails oceQueueDetails = new OCEQueueDetails();
				
				populateTaskDetails(task, oCETaskDetails);
				
				updateQueueDetails(oceQueueDetails, task);
				
				session.save(oCETaskDetails);
				session.save(oceQueueDetails);
				logger.info("Session Saved succussfully createTask()::");
				session.getTransaction().commit();
				logger.info("Transaction Saved succussfully createTask()::");
			}

		} catch (HibernateException he) {
			logger.error(he.getMessage());
			throw new OCEException(he.getMessage());
		} finally {
			session.close();
		}
	}

	/**
	 * 
	 * @param pQueueDetails
	 * @param pTask
	 */
	private void updateQueueDetails(OCEQueueDetails pQueueDetails, TaskDetailsVO pTask) {
		
		if (null != pTask.getTaskId()) {
			pQueueDetails.setTaskId(pTask.getTaskId());
		}
		if (null != pTask.getQueueId()) {
			pQueueDetails.setQueueId(pTask.getQueueId());
		}
		if (null != pTask.getQueueType()) {
			pQueueDetails.setQueueType(pTask.getQueueType());
		}
		if (null != pTask.getQueueSubType()) {
			pQueueDetails.setQueueSubType(pTask.getQueueSubType());
		}
		if (null != pTask.getQueueCategory()) {
			pQueueDetails.setQueueCategory(pTask.getQueueCategory());
		}
		if (null != pTask.getLineAction()) {
			pQueueDetails.setLineAction(pTask.getLineAction());
		}
		if (null != pTask.getLineCombos()) {
			pQueueDetails.setLineCombos(pTask.getLineCombos());
		}
		if (null != pTask.getProgram()) {
			pQueueDetails.setProgram(pTask.getProgram());
		}
		if (null != pTask.getRepComments()) {
			pQueueDetails.setRepComments(pTask.getRepComments());
		}
		
	}


	private void populateTaskDetails(TaskDetailsVO task,
			OCETaskDetails oCETaskDetails) {
		
		if (null != task.getTaskId()) {
			oCETaskDetails.setTaskId(task.getTaskId());
		}
		if (task.getTaskRetryAttempt() >= 0) {
			oCETaskDetails.setTaskRetryAttempt(task.getTaskRetryAttempt());
		}
		if (null != task.getCsrId()) {
			oCETaskDetails.setCsrId(task.getCsrId());
		}
		if (null != task.getTaskStatus()) {
			oCETaskDetails.setTaskStatus(task.getTaskStatus());
		}
		if (null != task.getOrderRef()) {
			oCETaskDetails.setOrderRef(task.getOrderRef());
		}
		if (null != task.getProgram()) {
			oCETaskDetails.setProgramName(task.getProgram());
		}
		if (null != task.getAvos_task_id()) {
			oCETaskDetails.setAvos_task_id(task.getAvos_task_id());
		}
		if (null != task.getProgram()) {
			oCETaskDetails.setProgramName(task.getProgram());
		}
		if (null != task.getCreated_by()) {
			oCETaskDetails.setCreated_by(task.getCreated_by());
		}
		if (null != task.getQueue_Priority_value()) {
			oCETaskDetails.setQueue_Priority_value(task.getQueue_Priority_value());
		}
		if (null != task.getApplicationName()) {
			oCETaskDetails.setApplicationName(task.getApplicationName());
		}
		if (null != task.getChannel()) {
			oCETaskDetails.setChannel(task.getChannel());
		}
		if (null != task.getCreationDate()) {
			oCETaskDetails.setCreationDate(task.getCreationDate());
		}
		if (null != task.getOwner()) {
			oCETaskDetails.setOwner(task.getOwner());
		}
		if (null != task.getWirelessFallout()) {
			oCETaskDetails.setWirelessFallout(task.getWirelessFallout());
		}
		if (null != task.getTaskSubStatus()) {
			oCETaskDetails.setTaskSubStatus(task.getTaskSubStatus());
		}
		if (null != task.getLast_modified_by()) {
			oCETaskDetails.setLast_modified_by(task.getLast_modified_by());
		}
		if (null != task.getLast_modified_date()) {
			oCETaskDetails.setLast_modified_date(task.getLast_modified_date());
		}
		if (null != task.getFallout_end_date()) {
			oCETaskDetails.setFallout_end_date(task.getFallout_end_date());
		}
		if (null != task.getVersion()) {
			oCETaskDetails.setVersion(task.getVersion());
		}
		if (null != task.getQueueType()) {
			oCETaskDetails.setQueueType(task.getQueueType());
		}
		if (null != task.getLineAction()) {
			oCETaskDetails.setLineAction(task.getLineAction());
		}
		if (null != task.getLineCombos()) {
			oCETaskDetails.setLineCombos(task.getLineCombos());
		}
		if (null != task.getActionType()) {
			oCETaskDetails.setActionType(task.getActionType());
		}
		if (null != task.getCallbackPreference()) {
			oCETaskDetails.setCallbackPreference(task.getCallbackPreference());
		}
		if (null != task.getLast_Communication_timestamp()) {
			oCETaskDetails.setLast_Communication_timestamp(task.getLast_Communication_timestamp());
		}
		if (null != task.getCommunication_status()) {
			oCETaskDetails.setCommunication_status(task.getCommunication_status());
		}
		if (null != task.getLosgId()) {
			oCETaskDetails.setLosgId(task.getLosgId());
		}
		if (null != task.getChild_order_ref()) {
			oCETaskDetails.setChild_order_ref(task.getChild_order_ref());
		}
		if (null != task.getRequestType()) {
			oCETaskDetails.setRequestType(task.getRequestType());
		}
	}

	
	
	/**
	 * input Param: TaskDetailsVO object This method is used to update a record
	 * for oce_task_details table
	 * 
	 */
	@Override
	public void updateTasks(List<TaskDetailsVO> tasks) throws OCEException {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		if (tasks == null || tasks.isEmpty()) {
			return;
		}
		try {
			for (TaskDetailsVO task : tasks) {
				String updateTaskQuery = "UPDATE OCETaskDetails set mCreationDate = :creationDate, mOrderRef = :orderRef, "
						+ "mLineCombos = :lineCombos, mLineAction = :lineAction, mQueueType = :queueType, mTaskStatus = :taskStatus, mTaskSubStatus = :taskSubStatus, "
						+ "mChannel = :channel, mOwner = :owner, mTaskRetryAttempt = :taskRetryAttempt, mLosgId = :losgId, mRequestType = :requestType"
						+ ", mActionType = :actionType, mWirelessFallout = :wirelessFallout, mCsrId  = :csrId, mLast_modified_date = :last_modified_date WHERE mTaskId = :taskId";
				logger.info("Task in progress in updateTask()::");
				Query query = session.createQuery(updateTaskQuery);
				query.setParameter("taskId", task.getTaskId());
				query.setParameter("creationDate", task.getCreationDate());
				query.setParameter("orderRef", task.getOrderRef());
				query.setParameter("lineCombos", task.getLineCombos());
				query.setParameter("lineAction", task.getLineAction());
				//query.setParameter("program", task.getProgram());
				query.setParameter("queueType", task.getQueueType());
				query.setParameter("taskStatus", task.getTaskStatus());
				query.setParameter("taskSubStatus", task.getTaskSubStatus());
				query.setParameter("channel", task.getChannel());
				query.setParameter("owner", task.getOwner());
				query.setParameter("taskRetryAttempt", task.getTaskRetryAttempt());
				query.setParameter("losgId", task.getLosgId());
				query.setParameter("requestType", task.getRequestType());
				query.setParameter("actionType", task.getActionType());
				query.setParameter("csrId", task.getCsrId());
				query.setParameter("last_modified_date", task.getLast_modified_date());
				if (task.getWirelessFallout() != null) {
					query.setParameter("wirelessFallout", task.getWirelessFallout());
				} else {
					query.setParameter("wirelessFallout", 0);
				}
				
				int result = query.executeUpdate();
				logger.info("updateTask()::  Rows affected" + result);
			}
		} catch (HibernateException he) {
			logger.error(he.getMessage());
			throw new OCEException(he.getMessage());
		} finally {
			session.close();
		}
	}

	/**
	 * This method is used to fetch all task records from oce_task_details
	 * 
	 */

	@Override
	public void initialize(List<TaskDetailsVO> list) throws OCEException {
		List<TaskDetailsVO> result = new ArrayList<TaskDetailsVO>(this.fetchAllOpenTask());
		result.addAll( new ArrayList<TaskDetailsVO>(this.fetchAllOutboundTasks()));
		for (int i = 0; i < result.size(); i++) {
			//System.out.println("result ==> "+result);
			if(logger.isDebugEnabled()){
				logger.debug(""+ result);
			}
		}
		
		if (result.size() > 0) {
			logger.info("fetchAllOpenTask():: Before publishing detaislList");
			publishEvent(TaskConstants.TASK_LOADED, result);
			logger.info("fetchAllOpenTask():: After publishing detaislList");
		}
		logger.info("Initialization is done");
	}



	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void accept(Event<List<TaskDetailsVO>> ev) {
		try {
			if (ev.getKey().toString().equals(TaskConstants.TASK_CREATED)) {
				createTasks(ev.getData());
			} else if (ev.getKey().toString().equals(TaskConstants.TASK_UPDATED)) {
				updateTasks(ev.getData());
			}
		} catch (OCEException e) {
			logger.error("OCEException Occurred", e);
		}
	}

	/**
	 * input Param: taskId(String) This method is used to fetch all task details
	 * from oce_task_details using task_id
	 * 
	 */
	@Override
	public TaskDetailsVO getTaskDetails(String id) throws OCEException {
		List<TaskDetailsVO> detaislList = null;
		Session session = sessionFactory.openSession();
		try {
			String getTaskDetailsQuery = "select t1.mTaskId as mTaskId, t1.mCreationDate as mCreationDate, t1.mOrderRef as mOrderRef,t1.mCsrId as mCsrId,t1.mChannel as mChannel,t1.mOwner as mOwner,t1.mLosgId as mLosgId,t1.mRequestType as mRequestType,t1.mActionType as mActionType,t1.mWirelessFallout as mWirelessFallout,"
					+ "t1.mTaskStatus as mTaskStatus,t1.mTaskSubStatus as mTaskSubStatus,t2.mQueueType as mQueueType,t2.mQueueCategory as mQueueCategory,t2.mProgram as mProgram,t2.mLineAction as mLineAction,t2.mLineCombos as mLineCombos,t2.mLineCount as mLineCount "
					+ "from OCETaskDetails t1, OCEQueueDetails t2 where t2.mTaskId = t1.mTaskId and mTaskId=:mTaskId";
			logger.info("Task in progress in getTaskDetails()::");
			Query query = session.createQuery(getTaskDetailsQuery);
			query.setParameter("mTaskId", id);
			query.setResultTransformer(new AliasToBeanResultTransformer(TaskDetailsVO.class));
			detaislList = query.list();

			for (TaskDetailsVO vo : detaislList) {
				logger.trace("VO :" + vo);
			}

			logger.info("getTaskDetails()::  queryList" + detaislList);
		} catch (HibernateException he) {
			logger.error(he.getMessage());
			throw new OCEException(he.getMessage());
		} finally {
			session.close();
		}

		TaskDetailsVO vo = null;
		if (detaislList != null && !detaislList.isEmpty()) {
			vo = detaislList.get(0);
		}

		return vo;
	}

}
