package com.att.oce.task.hibernate.orm;

public class TaskDetails {

	
	public void getOrderRef(){
		
	}
	
     public void setOrderRef(){
		
	}

}
