/**
 * 
 */
package com.att.oce.service.task.util;

import java.io.Serializable;
import java.util.Comparator;

import com.att.oce.service.task.VO.BasicTaskDetailsVO;

/**
 * @author bk436x
 *
 */
public class OrderTaskMaxDateComparator implements Comparator<BasicTaskDetailsVO>, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */

	@Override
	public int compare(BasicTaskDetailsVO t1, BasicTaskDetailsVO t2) {
		return t1.getOrderAcceptedDate().compareTo(t2.getOrderAcceptedDate());
	}
	
}
