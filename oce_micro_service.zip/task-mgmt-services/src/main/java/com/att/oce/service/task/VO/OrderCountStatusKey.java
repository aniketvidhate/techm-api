package com.att.oce.service.task.VO;

import java.util.ArrayList;
import java.util.List;

public class OrderCountStatusKey {
	
	//key
	private String queueType;
	private String queueCategory;
	private String   programName;
	private String   lineAction;
	private String   linecombos;
	private String   owner;
	private String   channel;
	private String   priority;
	private String   requestType;
	private String actionType;
	private Integer  wirelessFallout;
	private List<String> orgUnitList;
	private List<String> partnerName;
	private List<String> queueTypes;
	private String queueInputType;
	private boolean isWirelessFalloutOrder;
	private boolean isGlobalVisible;
	private String state;
	private List<String> taskStatusList;
	private String subStatus;
	private String callbackPreference;

	public OrderCountStatusKey(TaskDetailsVO task) {
		this.queueType = task.getQueueType();
		this.queueCategory = task.getQueueCategory();
		this.programName = task.getProgram();
		this.lineAction = task.getLineAction();
		this.linecombos = task.getLineCombos();
		this.owner = task.getOwner();
		this.channel = task.getChannel();
		this.priority = task.getQueue_Priority_value();
		this.requestType = task.getRequestType();
		this.actionType = task.getActionType();
		this.wirelessFallout = task.getWirelessFallout();
		this.queueTypes = task.getQueueTypes();
		this.queueInputType = task.getQueueInputType();
		this.isWirelessFalloutOrder = task.isWirelessFalloutOrder();
		this.isGlobalVisible = task.isGlobalVisible();
		this.state = task.getTaskStatus();
		this.subStatus = task.getTaskSubStatus();

		if(this.taskStatusList == null){
			taskStatusList = new ArrayList<String>();
			taskStatusList.add(task.getTaskStatus());
		} else {
			taskStatusList.add(task.getTaskStatus());
		}
		
		if(this.partnerName == null){
			partnerName = new ArrayList<String>();
			partnerName.add(task.getOwner());
		} else {
			partnerName.add(task.getOwner());
		}
		
		if(this.orgUnitList == null){
			orgUnitList = new ArrayList<String>();
			orgUnitList.add(task.getChannel());
		} else {
			orgUnitList.add(task.getChannel());
		}
		
	}

	public String getQueueType() {
		return queueType;
	}
	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}
	public String getQueueCategory() {
		return queueCategory;
	}
	public void setQueueCategory(String queueCategory) {
		this.queueCategory = queueCategory;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLineAction() {
		return lineAction;
	}
	public void setLineAction(String lineAction) {
		this.lineAction = lineAction;
	}
	public String getLinecombos() {
		return linecombos;
	}
	public void setLinecombos(String linecombos) {
		this.linecombos = linecombos;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	public Integer getWirelessFallout() {
		return wirelessFallout;
	}
	public void setWirelessFallout(Integer wirelessFallout) {
		this.wirelessFallout = wirelessFallout;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderCountStatusKey other = (OrderCountStatusKey) obj;
		
		if (channel == null) {
			if (other.channel != null)
				return false;
		} else if (!channel.equals(other.channel))
			return false;
		/*if (isGlobalVisible != other.isGlobalVisible)
			return false;*/
		
		if (lineAction == null) {
			if (other.lineAction != null)
				return false;
		} else if (!lineAction.equals(other.lineAction))
			return false;
		if (linecombos == null) {
			if (other.linecombos != null)
				return false;
		} else if (!linecombos.equals(other.linecombos))
			return false;
		/*if (orgUnitList == null) {
			if (other.orgUnitList != null)
				return false;
		} else if (!orgUnitList.equals(other.orgUnitList))
			return false;*/
		if (owner == null) {
			if (other.owner != null)
				return false;
		} else if (!owner.equals(other.owner))
			return false;
		/*if (partnerName == null) {
			if (other.partnerName != null)
				return false;
		} else if (!partnerName.equals(other.partnerName))
			return false;*/
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		if (programName == null) {
			if (other.programName != null)
				return false;
		} else if (!programName.equals(other.programName))
			return false;
		if (queueCategory == null) {
			if (other.queueCategory != null)
				return false;
		} else if (!queueCategory.equals(other.queueCategory))
			return false;
		/*if (queueInputType == null) {
			if (other.queueInputType != null)
				return false;
		} else if (!queueInputType.equals(other.queueInputType))
			return false;*/
		if (queueType == null) {
			if (other.queueType != null)
				return false;
		} else if (!queueType.equals(other.queueType))
			return false;
		/*if (queueTypes == null) {
			if (other.queueTypes != null)
				return false;
		} else if (!queueTypes.equals(other.queueTypes))
			return false;*/
		
		if (!other.getQueueType().equalsIgnoreCase("UNSCHEDULED_OUTBOUND")) {
			if (requestType == null) {
				if (other.requestType != null)
					return false;
			} else if (!requestType.equals(other.requestType))
				return false;

			if (actionType == null) {
				if (other.actionType != null)
					return false;
			} else if (!actionType.equals(other.actionType))
				return false;

			/*if (isWirelessFalloutOrder != other.isWirelessFalloutOrder)
				return false;*/
			
			if (wirelessFallout == null) {
				if (other.wirelessFallout != null)
					return false;
			} else if (!wirelessFallout.equals(other.wirelessFallout))
				return false;
		}
		
	if(other.getQueueType().equalsIgnoreCase("UNSCHEDULED_OUTBOUND"))	{
		if (callbackPreference == null) {
			if (other.callbackPreference != null)
				return false;
		} else if (!callbackPreference.equals(other.callbackPreference))
			return false;
	}
		
		
		/*if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;*/
		/*if (subStatus == null) {
			if (other.subStatus != null)
				return false;
		} else if (!subStatus.equals(other.subStatus))
			return false;*/
		/*if (taskStatusList == null) {
			if (other.taskStatusList != null)
				return false;
		} else if (!taskStatusList.equals(other.taskStatusList))
			return false;*/
		
		
		return true;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((actionType == null) ? 0 : actionType.hashCode());
		result = prime * result + ((channel == null) ? 0 : channel.hashCode());
		result = prime * result
				+ ((lineAction == null) ? 0 : lineAction.hashCode());
		result = prime * result
				+ ((linecombos == null) ? 0 : linecombos.hashCode());
		result = prime * result + ((owner == null) ? 0 : owner.hashCode());
		result = prime * result
				+ ((priority == null) ? 0 : priority.hashCode());
		result = prime * result
				+ ((programName == null) ? 0 : programName.hashCode());
		result = prime * result
				+ ((queueCategory == null) ? 0 : queueCategory.hashCode());
		result = prime * result
				+ ((queueType == null) ? 0 : queueType.hashCode());
		result = prime * result
				+ ((requestType == null) ? 0 : requestType.hashCode());
		/*result = prime * result + (isGlobalVisible ? 1231 : 1237);
		 result = prime * result + (isWirelessFalloutOrder ? 1231 : 1237);
		 result = prime * result
				+ ((orgUnitList == null) ? 0 : orgUnitList.hashCode());
		 result = prime * result
				+ ((partnerName == null) ? 0 : partnerName.hashCode());
		 result = prime * result
				+ ((queueInputType == null) ? 0 : queueInputType.hashCode());
		 result = prime * result
				+ ((queueTypes == null) ? 0 : queueTypes.hashCode());
		 result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result
				+ ((subStatus == null) ? 0 : subStatus.hashCode());
		result = prime * result
				+ ((taskStatusList == null) ? 0 : taskStatusList.hashCode());*/
		result = prime * result
				+ ((wirelessFallout == null) ? 0 : wirelessFallout.hashCode());
		result = prime * result
				+ ((callbackPreference == null) ? 0 : callbackPreference.hashCode());
		return result;
	}
	public List<String> getOrgUnitList() {
		return orgUnitList;
	}
	public void setOrgUnitList(List<String> orgUnitList) {
		this.orgUnitList = orgUnitList;
	}
	public List<String> getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(List<String> partnerName) {
		this.partnerName = partnerName;
	}
	public List<String> getQueueTypes() {
		return queueTypes;
	}
	public void setQueueTypes(List<String> queueTypes) {
		this.queueTypes = queueTypes;
	}
	public String getQueueInputType() {
		return queueInputType;
	}
	public void setQueueInputType(String queueInputType) {
		this.queueInputType = queueInputType;
	}
	public boolean isWirelessFalloutOrder() {
		return isWirelessFalloutOrder;
	}
	public void setWirelessFalloutOrder(boolean isWirelessFalloutOrder) {
		this.isWirelessFalloutOrder = isWirelessFalloutOrder;
	}
	public boolean isGlobalVisible() {
		return isGlobalVisible;
	}
	public void setGlobalVisible(boolean isGlobalVisible) {
		this.isGlobalVisible = isGlobalVisible;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public List<String> getTaskStatusList() {
		return taskStatusList;
	}
	public void setTaskStatusList(List<String> taskStatusList) {
		this.taskStatusList = taskStatusList;
	}
	public String getSubStatus() {
		return subStatus;
	}
	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	/**
	 * @return the callbackPreference
	 */
	public String getCallbackPreference() {
		return callbackPreference;
	}

	/**
	 * @param callbackPreference the callbackPreference to set
	 */
	public void setCallbackPreference(String callbackPreference) {
		this.callbackPreference = callbackPreference;
	}
	
	@Override
	public String toString() {
		return "OrderCountStatusKey [queueType=" + queueType
				+ ", queueCategory=" + queueCategory + ", programName="
				+ programName + ", lineAction=" + lineAction + ", linecombos="
				+ linecombos + ", owner=" + owner + ", channel=" + channel
				+ ", priority=" + priority + ", requestType=" + requestType
				+ ", actionType=" + actionType + ", wirelessFallout="
				+ wirelessFallout + ", orgUnitList=" + orgUnitList
				+ ", partnerName=" + partnerName + ", queueTypes=" + queueTypes
				+ ", queueInputType=" + queueInputType
				+ ", isWirelessFalloutOrder=" + isWirelessFalloutOrder
				+ ", isGlobalVisible=" + isGlobalVisible + ", state=" + state
				+ ", taskStatusList=" + taskStatusList + ", subStatus="
				+ subStatus + "]";
	}
}
