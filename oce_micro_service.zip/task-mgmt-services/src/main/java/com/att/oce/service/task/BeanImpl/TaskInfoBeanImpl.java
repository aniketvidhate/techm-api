package com.att.oce.service.task.BeanImpl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.oce.idgen.OCEUniqueIdGenerator;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroup;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroupCharacteristics;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtOrderSource;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.Order;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.StOrderType;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtOrderTask;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.StTaskStatus;
import com.att.oce.service.DateUtil;
import com.att.oce.service.queue.OCEOrderQueueService;
import com.att.oce.service.queue.vo.OCEQueueDeterminationRequest;
import com.att.oce.service.queue.vo.sub.OCEOrderInfo;
import com.att.oce.service.queueImpl.QueueDetails;
import com.att.oce.service.task.Bean.OrderTaskBean;
import com.att.oce.service.task.Bean.TaskInfoBean;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.StringUtilities;
import com.att.oce.service.task.util.TaskConstants;
import com.att.ooce.core.ProcessOrderRequest;

import reactor.bus.Event;

/**
 * The Class TaskInfoBeanImpl.
 *
 * @author SX00352475 Mukhtar Shaikh
 * 
 *         This class responsibility is as follows Initialize TaskMap Create
 *         task Publish events to DB,GetNext and Order reactors Update task
 */

@Component
public class TaskInfoBeanImpl extends AbstractTaskBeanImpl implements TaskInfoBean {

	/** The logger. */
	private Logger logger = LoggerFactory.getLogger(TaskInfoBeanImpl.class);
	private List<TaskDetailsVO> taskList;
	
	/** The results. */
	private ConcurrentHashMap<String, List<String>> results = null;
	
	@Value("${taskNotificationURL}")   
	private String taskNotificationURL;
	
	@Autowired(required = true)
	@Qualifier("mysessionFactory")
	SessionFactory sessionFactory;
	
	/**
	 * @return the taskList
	 */
	public List<TaskDetailsVO> getTaskList() {
		return taskList;
	}

	/**
	 * @param taskList the taskList to set
	 */
	public void setTaskList(List<TaskDetailsVO> taskList) {
		this.taskList = taskList;
	}

	/** The task map. */
	Map<String, TaskDetailsVO> taskMap = new ConcurrentHashMap<String, TaskDetailsVO>();
	
	/** The order queue service. */
	@Autowired
	OCEOrderQueueService orderQueueService;

	/** The uniqueue id generator service. */
	@Autowired
	OCEUniqueIdGenerator idGenerator;

	/** The order task bean. */
	@Autowired
	OrderTaskBean orderTaskBean;
	
	/**
	 * The Enum TaskUpdateOperation.
	 *
	 * @author RetheeshM_R
	 */
	protected static enum TaskUpdateOperation {
		
		/** The null. */
		NULL("",0),
		
		/** The release. */
		RELEASE("RELEASE",1), 
		
		/** The claim. */
		CLAIM("CLAIM",2),
		
		/** The assign. */
		ASSIGN("ASSIGN",3),
		
		/** The close. */
		CLOSE("CLOSE",4),
		
		/** The backtoqueue. */
		BACKTOQUEUE("BACKTOQUEUE",5);
		
		/** The request value. */
		private String requestValue;
		
		/** The value. */
		private int value;

		/**
		 * Instantiates a new task update operation.
		 *
		 * @param requestValue the request value
		 * @param value the value
		 */
		private TaskUpdateOperation(String requestValue, int value) {
			this.requestValue = requestValue;
			this.value = value;
		}
		
		/**
		 * Gets the request value.
		 *
		 * @return the request value
		 */
		public String getRequestValue() {
			return this.requestValue;
		}

		/**
		 * Gets the value.
		 *
		 * @return the value
		 */
		public int getValue() {
			return this.value;
		}
		
	}
	
	

	/**
	 * This method will accept the event DBTaskInfoBeanImpl GetNextTaskBeanImpl.
	 *
	 * @param ev the ev
	 */
	@Override
	public void accept(Event<List<TaskDetailsVO>> ev) {
		if (ev.getKey().toString().equals(TaskConstants.TASK_LOADED)) {
			initialize(ev.getData());
		}
	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.BasicTaskBean#createTasks(java.util.List)
	 */
	@Override
	public void createTasks(List<TaskDetailsVO> tasks) {

		logger.info("create Tasks is called");
		
		if (tasks == null || tasks.isEmpty()) {
			// Ideally, we need to throw an exception, Lets see..
			logger.error("create event is called with null object");
			return;
		}

		synchronized (this) {
			
			List<TaskDetailsVO> detaislList = new ArrayList<TaskDetailsVO>();
			
			for (TaskDetailsVO task : tasks) {
				logger.trace("Task create request is made for the task" +task);
				
				String uniqueKey = null;
				try {
					//uniqueKey = idGenerator.generateStringId();
					//task.setTaskId(uniqueKey);
					taskMap.put(task.getTaskId(), task);
					detaislList.add(task);
					logger.trace("Task is created : " +task);
				} catch (Exception e) {
					if (logger.isErrorEnabled()) {
						logger.error(e.getMessage());
					}
				}
			}

			if (!detaislList.isEmpty()) {
				logger.trace("TASK CREATED event will be published");
				publishEvent(TaskConstants.TASK_CREATED, detaislList);
			}

		}
		
		logger.info("create Tasks is ended ");

	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.BasicTaskBean#updateTasks(java.util.List)
	 */
	@Override
	public void updateTasks(List<TaskDetailsVO> tasks) {

		logger.info("updateTasks Tasks is called");
		if (tasks == null || tasks.isEmpty()) {
			// Ideally, we need to throw an exception, Lets see..
			logger.error("update event is called with null object");
			return;
		}
		synchronized (this) {
			List<TaskDetailsVO> detaislList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetails = null;
		for (TaskDetailsVO task : tasks) {
				logger.trace("Task update request is made for the task" +task);
					taskDetails = new TaskDetailsVO();
					String taskId = task.getTaskId();
					logger.trace("taskId------" +task);
					logger.trace("taskMap------" +taskMap);
					if (taskMap.containsKey(taskId)) {
						taskDetails = taskMap.get(taskId);
						taskDetails =  this.mergeData(taskDetails, task);
						String orderId = taskDetails.getOrderRef();
						logger.trace("orderId------" +orderId + "");
						TaskUpdateOperation operation = determineTaskOperation(taskDetails.getCsrId(),taskDetails.getTaskStatus(),taskDetails.getTaskStatus());
						logger.trace("operation------" +operation);
						//TODO: get order from db. outbound call
						//http://zld00925.vci.att.com:7605//oce/api/orders/D53690012?
						//fields={"orderDetails":["order","errorItem","orderTasks"],"order":["customerOrderNumber","acceptedDate","orderStatus","orderSource","orderContact","account","lineItems","groups"]}
						//lock = true
						//losg status update
						switch(operation) {
						case RELEASE:
								taskDetails = releaseTask(orderId, taskDetails);
								//order lock = false
								//losg status update
							break;
							case CLAIM:
								//order lock = true
								//losg status update
								//Validate Task limit
								checkForTaskLimit(taskDetails.getCsrId(), taskDetails.getChannel(),"INPROGRESS");
						//		authorizeTaskClaim(loginName,taskDetails);
								taskDetails = claimTask(orderId, taskDetails,taskDetails.getCsrId(),taskDetails.getChannel());
								logger.trace("CLAIM--taskDetails----" +taskDetails);
							break;
						case ASSIGN:
								/*if(!OCEOrderConstants.SYSTEM.equalsIgnoreCase(loginName))
									authorizeUserForTaskAssign(role);*/
								//Validate CSR Id in request
							//	validateCSRId(orderTask.getCsrId());
								//Validate Task limit
								checkForTaskLimit(taskDetails.getCsrId(), taskDetails.getChannel(),"INPROGRESS");
								taskDetails = assignTask(orderId, taskDetails, taskDetails.getCsrId(), taskDetails.getChannel());
								break;
						case CLOSE:
								taskDetails = closeTask(orderId, taskDetails);
								break;
						case BACKTOQUEUE:
								assignTasksBackToQueue(orderId);
								break;
						case NULL:
								break;
							
						}
						//Sending task notification to AVOS for UNLOCK
						boolean success = false;
						try {
							success = sendTaskInfoToPostNotifyUnlockCamunda(taskDetails.getOrderRef(),taskDetails.getApplicationName());
						} catch (OCEException e) {
							logger.error(e.getMessage());
						}
						
						if (null == results) {
							results = new ConcurrentHashMap<String, List<String>>();
						} 
						if(success)
						{
							List<String> successList = results.get("success");
							if(null == successList)
							{
								successList = new Vector<String>();
								
							}
							successList.add(taskDetails.getTaskId());
							results.put("success", successList);
							updateTaskNotificationStatus(taskDetails);
							incrementTaskRetry(taskDetails);
						}
						else
						{
							List<String> failure = results.get("failure");
							if(null == failure)
							{
								failure = new Vector<String>();
								
							}
							failure.add(taskDetails.getTaskId());
							results.put("failure", failure);
							incrementTaskRetry(taskDetails);
						}
						List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
						tskList.add(taskDetails);
						logger.debug("CLAIM--taskDetails----" +tskList);
						logger.debug("update Task request is completed");
					} else {
						taskDetails = task;
					}
			    task.setLast_modified_date(new Date());
				taskMap.put(taskId, task);
				detaislList.add(taskDetails);
				this.taskList = detaislList;
			}
			logger.debug("TASK UPDATED event will be published");
			publishEvent(TaskConstants.TASK_UPDATED, this.taskList);
		}
		
		logger.info("updateTasks Tasks is ended");
	}
	/**
	 * Assign tasks back to queue.
	 *
	 * @param orderId the order id
	 */
	private void assignTasksBackToQueue(String orderId) {
		
	}
	
	
	
	
	/**
	 * Close task.
	 *
	 * @param orderId the order id
	 * @param taskDetails the task details
	 * @return the task details VO
	 */
	private TaskDetailsVO closeTask(String orderId, TaskDetailsVO taskDetails) {
			taskDetails.setLast_modified_date(new Timestamp(DateUtil.getCurrentTimeAsGMT().getTime()));
			// The task has been updated. Now set the lock time to null
			//orderImpl.setLockTime(null);
			return taskDetails;
	}
	
	/**
	 * Check for task limit.
	 *
	 * @param csrId the csr id
	 * @param channel the channel
	 * @param taskStatus the task status
	 */
	private void checkForTaskLimit(String csrId, String channel,String taskStatus){
		/*try {
			List<TaskDetailsVO> taskDetailList = (List<TaskDetailsVO>) dbTaskBean.fetchAllTasks();
			TaskDetailsPredicate pre = null;
			List<TaskDetailsVO> existingTaskCount = (List<TaskDetailsVO>) pre.getExistingTaskCount(taskDetailList,pre.existingTaskPredicate(csrId, channel, taskStatus));
			if(existingTaskCount >= getTaskLimitForUser(csrId, channel)) {
				if(isLoggingInfo()) {
					logInfo("Task Limit exceeded , can't claim/assign more tasks");
				}
				orderTaskTools.errorLookup("ERR403004");
			}
		} catch (OCEException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	
	/**
	 * Claim task.
	 *
	 * @param orderId the order id
	 * @param taskDetails the task details
	 * @param loginName the login name
	 * @param channel the channel
	 * @return the task details VO
	 */
	private TaskDetailsVO claimTask(String orderId, TaskDetailsVO taskDetails,String loginName,String channel){
		taskDetails.setCsrId(loginName);
		taskDetails.setLast_modified_date(new Timestamp(DateUtil.getCurrentTimeAsGMT().getTime()));
		taskDetails.setTaskRetryAttempt(taskDetails.getTaskRetryAttempt());
		ProcessOrderRequest request = new ProcessOrderRequest();
		Order order = new Order();
		order.setCustomerOrderNumber(taskDetails.getExternalOrderNum());
		order.setIsLocked(true);
		Date lockTime = DateUtil.getCurrentTimeAsGMT();
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(lockTime);
		XMLGregorianCalendar date2 = null;
		try {
			date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		order.setLockTime(date2);
		order.setLockOwner(loginName);
		order.setOCEOrderNumber(taskDetails.getOrderRef());
		
		order.setOrderType(StOrderType.UPDATE);
		request.setOrder(order);

		//taskDetails.setLocked(null);
		return taskDetails;
	}
	
	/**
	 * Assign task.
	 *
	 * @param orderId the order id
	 * @param taskDetails the task details
	 * @param loginName the login name
	 * @param channel the channel
	 * @return the task details VO
	 */
	private TaskDetailsVO assignTask(String orderId, TaskDetailsVO taskDetails,String loginName,String channel){
		taskDetails.setCsrId(loginName);
		taskDetails.setLast_modified_date(new Timestamp(DateUtil.getCurrentTimeAsGMT().getTime()));
		ProcessOrderRequest request = new ProcessOrderRequest();
		Order order = new Order();
		order.setCustomerOrderNumber(taskDetails.getExternalOrderNum());
		order.setIsLocked(true);
	//	Date lockTime = DateUtil.getCurrentTimeAsGMT();	
		order.setLockTime(null);
		order.setLockOwner(loginName);
		order.setOCEOrderNumber(taskDetails.getOrderRef());
		
		// order.setOrderType(StOrderType.UPDATE);
		request.setOrder(order);

		//taskDetails.setLocked(null);
		return taskDetails;
	}
	
	/**
	 * Release task.
	 *
	 * @param orderId the order id
	 * @param taskDetails the task details
	 * @return the task details VO
	 */
	private TaskDetailsVO releaseTask(String orderId, TaskDetailsVO taskDetails){
		taskDetails.setTaskSubStatus("IN_QUEUE");
		taskDetails.setCsrId(null);
		taskDetails.setLast_modified_date(new Timestamp(DateUtil.getCurrentTimeAsGMT().getTime()));
		ProcessOrderRequest request = new ProcessOrderRequest();
		Order order = new Order();
		order.setCustomerOrderNumber(taskDetails.getExternalOrderNum());
		order.setIsLocked(false);
		order.setLockTime(null);
		order.setLockOwner(taskDetails.getCsrId());
		order.setOCEOrderNumber(taskDetails.getOrderRef());
		//Checking if CRU Order
		//boolean isCRU = getOrderTaskTools().isCRUOrder(orderImpl);
		// order.setOrderType(StOrderType.UPDATE);
		request.setOrder(order);

		//taskDetails.setLocked(null);
		return taskDetails;
	}
	/**
	 * Determine task operation.
	 *
	 * @param csrId the csr id
	 * @param currentTaskStatus the current task status
	 * @param taskStatus the task status
	 * @return the task update operation
	 */
	private TaskUpdateOperation determineTaskOperation(String csrId,String currentTaskStatus, String taskStatus){
		List<String> taskClosedStatus = new ArrayList<String>();
		taskClosedStatus.add("REJECTED");
		taskClosedStatus.add("COMPLETED");
		taskClosedStatus.add("ONHOLD");
		taskClosedStatus.add("CANCELED");
		if ("NEW".equalsIgnoreCase(currentTaskStatus) 
				|| ("UNCLAIMED".equalsIgnoreCase(currentTaskStatus))
				&& ("IN_PROGRESS".equalsIgnoreCase(taskStatus))
			    ||"IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& ("IN_PROGRESS".equalsIgnoreCase(taskStatus)
				&& (null == csrId || csrId.isEmpty()))) {
			return TaskUpdateOperation.CLAIM;
		} else if ("IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& "NEW".equalsIgnoreCase(taskStatus)) {
			return TaskUpdateOperation.RELEASE;
		} else if ("IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& "IN_PROGRESS".equalsIgnoreCase(taskStatus)) {
			return TaskUpdateOperation.ASSIGN;
		} else if("IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& "UNCLAIMED".equalsIgnoreCase(taskStatus)) {
			return TaskUpdateOperation.BACKTOQUEUE;
		} else if ("IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& taskClosedStatus.contains(taskStatus.toUpperCase())) {
				return TaskUpdateOperation.CLOSE;
		} else {
		}
		return TaskUpdateOperation.NULL;
	}
	
	/**
	 * Merge data.
	 *
	 * @param existingTask the existing task
	 * @param newTask the new task
	 * @return the task details VO
	 */
	private TaskDetailsVO mergeData(TaskDetailsVO existingTask, TaskDetailsVO newTask ) {
		
		logger.info("mergeData Tasks is called");
		
		logger.trace("mergeData is called for the task1" +existingTask);
		
		logger.trace("mergeData is called for the task2" +newTask);
	
		TaskDetailsVO mergedDataVO = newTask;
		
		try {
			mergedDataVO = existingTask.merge(newTask);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		
		logger.trace("mergeData responded with merged data" +mergedDataVO);
		
		logger.info("mergeData Tasks is ended");
		
		return mergedDataVO;
	}
	
	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.BasicTaskBean#initialize(java.util.List)
	 */
	@Override
	public void initialize(List<TaskDetailsVO> taskDetailsList) {

		logger.info("Task in progress in taskinfobean");
		
		for (TaskDetailsVO taskDetailsVO : taskDetailsList) {
			taskMap.put(taskDetailsVO.getTaskId(), taskDetailsVO);
		}

		logger.info("Initialization is done.. size of map in init=" + taskMap.size());

	}

	/**
	 * This method will return task details based on taskid.
	 *
	 * @param id the id
	 * @return the task info
	 */

	@Override
	public TaskDetailsVO getTaskInfo(String id) {
		logger.info("getTaskInfo is called for task Id" + id);
		TaskDetailsVO retVal = taskMap.get(id); 
		logger.trace("The return value is :" +retVal);
		return retVal;
	}

	/**
	 * This method will return all task available in cache(in taskMap).
	 *
	 * @return the all task
	 */

	@Override
	public Collection<TaskDetailsVO> getAllTask() {
		logger.info("getAllTask is called");
		return taskMap.values();
	}

	/*
	 * ******************* BE CAUTIOUS !!! *********************************
	 * Do not use this method unnecessarily, it will affect the over all functionality. 
	 * This method is created only to purge testData not the real data. Please take care.
	 * 
	 */
	
	/* (non-Javadoc)
	 * @see com.att.oce.service.task.BeanImpl.AbstractTaskBeanImpl#purgeTestData()
	 */
	@Override
	public void purgeTestData() throws OCEException {
		logger.error("purgeTest Data is called to clear the map");
		this.taskMap.clear();
	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.TaskInfoBean#createTask(com.att.oce.service.task.Bean.ProcessOrderRequest)
	 */
	@Override
	public List<TaskDetailsVO> createTask(
			ProcessOrderRequest processOrderRequest)
			throws OCEException {
		QueueDetails details = null;		
		OCEQueueDeterminationRequest request = new OCEQueueDeterminationRequest(processOrderRequest);
		details = orderQueueService.determineQueue(request);		
		List<TaskDetailsVO> tskList = processPayloadForTask(request, processOrderRequest,details); 
		return tskList;
	}
	
	/**
	 * 
	 * @param request
	 * @param processOrderRequest
	 * @param details
	 * @return
	 * @throws OCEException
	 */
	public List<TaskDetailsVO>  processPayloadForTask(OCEQueueDeterminationRequest request, ProcessOrderRequest processOrderRequest, QueueDetails details) throws OCEException {

		String taskOrderId = processOrderRequest.getOrder().getCustomerOrderNumber();
		String channel = "";		
		channel = (String) processOrderRequest.getOrder().getOrderSource().getChannel();
		List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
		boolean taskExists = handleDuplicateTask(request.getOrder().getOrderTasklist(),
				request.getOrder().getOceOrderNumber(), taskOrderId, details.getQueueType());
		String prgmNmeFulfllmntMthd = request.getOrder().getPrgmNmeFulfllmntMthd();
		
		
		if(taskExists){
			updateTasks(this.taskList);
		} else {
			if (null != request.getOrder().getOrderTasklist()) {
				for (CtOrderTask ctorderTask : request.getOrder().getOrderTasklist()) {
					if (null != processOrderRequest.getOrder().getOCEOrderNumber()) {
						ctorderTask.setOrderNumber(processOrderRequest.getOrder().getOCEOrderNumber());
					}
					TaskDetailsVO taskDetailsVO = new TaskDetailsVO(ctorderTask);
					taskDetailsVO.setChannel(channel);
					taskDetailsVO.setProgram(request.getOrder().getProgramName());
					String taskId = null;
					String losgRefId = getLosgRefId(request.getOrder(), channel);
					taskDetailsVO.setLosgId(losgRefId);
					try {
						taskId = idGenerator.generateStringId();
					} catch (Exception e) {
						if (logger.isErrorEnabled()){
							logger.error(e.getMessage());
						}
					}
					if (null != details) {
						taskDetailsVO.setQueueType(details.getQueueType());
						taskDetailsVO.setQueueCategory(details
								.getQueueCategory());
						if(null != details.getQueueSubType()){
							taskDetailsVO.setQueueSubType(details
									.getQueueSubType());
							if (null != details.getQueueSubType() && details.getQueueSubType().equalsIgnoreCase(TaskConstants.OUTBOUND)) {
								if (null != ctorderTask.getCallbackPreference()) {
									taskDetailsVO.setCallbackPreference(ctorderTask.getCallbackPreference());
								} else {
									taskDetailsVO.setCallbackPreference(TaskConstants.FIRST_CALL_QUEUE);
								}
							}
						}
						taskDetailsVO.setQueueId(details.getQueueId());
						ctorderTask.setQueueType(details.getQueueType().toUpperCase());
						ctorderTask.setQueueSubType(details.getQueueSubType());
						// Updating Rep Comments with actual values from order.
						if (null != details.getRepComments()) {
							ctorderTask.setRepComments(details.getRepComments());
							taskDetailsVO.setRepComments(details.getRepComments());
						}
						// Updating QueuePriority
						if (null != details.getQueuePriority()) {
							ctorderTask.setQueuePriorityValue(details.getQueuePriority());
							taskDetailsVO.setQueue_Priority_value(details.getQueuePriority());
						}
						// Added for US786130: Queue Design change
						if (details.isManualIntervention()) {
							taskDetailsVO.setTaskSubStatus(TaskConstants.IN_QUEUE);
						} else {
							taskDetailsVO.setTaskSubStatus(TaskConstants.OPEN);
						}
					}
					//Update order and losgids of task
					if (null != ctorderTask
							&& null != ctorderTask.getChildOrderNumber()) {
						taskDetailsVO.setChild_order_ref(ctorderTask.getChildOrderNumber());
					} else {
						taskDetailsVO.setChild_order_ref(ctorderTask.getOrderNumber());
					}

					if (null != ctorderTask
							&& null != ctorderTask.getTaskStatus()) {
						ctorderTask.setTaskStatus(ctorderTask.getTaskStatus());
					} else if (!details.isManualIntervention()) {
						ctorderTask.setTaskStatus(StTaskStatus.OPEN);
					} else {
						ctorderTask.setTaskStatus(StTaskStatus.NEW);
					}
					taskDetailsVO.setTaskStatus(ctorderTask.getTaskStatus().toString());
					ctorderTask.setCsrId("");
					if(null == ctorderTask.getCreatedBy()) {
						ctorderTask.setCreatedBy(TaskConstants.SYSTEM);
						ctorderTask.setLastModifiedBy(TaskConstants.SYSTEM);
					} else {
						ctorderTask.setCreatedBy(ctorderTask.getCreatedBy());
						ctorderTask.setLastModifiedBy(ctorderTask.getCreatedBy().toUpperCase());
					}
					taskDetailsVO.setCreated_by(ctorderTask.getCreatedBy());
					taskDetailsVO.setLast_modified_by(ctorderTask.getLastModifiedBy());
					//new changes for ORDER_TASK_APPLICATION_NAME
					if(null != ctorderTask && null !=ctorderTask.getApplicationName()) {
						ctorderTask.setApplicationName(ctorderTask.getApplicationName());;
					}
					taskDetailsVO.setApplicationName(ctorderTask.getApplicationName());
					/** Set action type for CRU-MOBLITY **/
					if(processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase(TaskConstants.CRUMOBILITY)){
						if(null!=processOrderRequest.getOrder().getRequestType() && 
								processOrderRequest.getOrder().getRequestType().toString().equalsIgnoreCase(TaskConstants.SCR)){
							if(null!=details.getActionType()){
								taskDetailsVO.setActionType(details.getActionType());
							}
							else{
								/** To set Action Type as NA in case its not present in SCR order.**/
								taskDetailsVO.setActionType(TaskConstants.NA);
							}
						}
						else{
							taskDetailsVO.setActionType(TaskConstants.NA);
						}


					}
					else{
						taskDetailsVO.setActionType(TaskConstants.NA);
					}

					/*if(null != ctorderTask.getCamundaTaskId()) {
						String camundaTaskId = ctorderTask.getCamundaTaskId();
						taskDetailsVO.setAvos_task_id(camundaTaskId);
						ctorderTask.setTaskId(camundaTaskId);
					} else {*/
					// Set Main Task Id
					String avosRefTaskId = ctorderTask.getTaskId();
					taskId = TaskConstants.TASK_ID_PREFIX +taskId.toUpperCase();
					taskDetailsVO.setTaskId(taskId);
					
					avosRefTaskId = ((null == avosRefTaskId) ? TaskConstants.AVOS_TASK_ID_PREFIX + taskId.toUpperCase() : avosRefTaskId);
					taskDetailsVO.setAvos_task_id(avosRefTaskId);
					ctorderTask.setTaskId(avosRefTaskId);

					//}

					if(request.getOrder().isWirelessUnlock()) {			
						if (request.getOrder().getCtOrderSource().getChannel().equalsIgnoreCase(TaskConstants.UNLOCK)) {
							taskDetailsVO.setProgram(processOrderRequest.getOrder().getProgramName());
							ctorderTask.setProgramName(processOrderRequest.getOrder().getProgramName());
							taskDetailsVO.setLineAction("");
							List<String> lineComboList = new ArrayList<String>();
							if (null != ctorderTask.getLineCombination()) {
								lineComboList = ctorderTask.getLineCombination().getLineCombo();
							}
							if (null != lineComboList && !lineComboList.isEmpty()) {
								for(String lineCombo : lineComboList){
									taskDetailsVO.setLineCombos(lineCombo);
								}
							}
							taskDetailsVO.setLineCount("1");
						} 
						/** END IRU_UNLOCK PMT:*/
						else {
							taskDetailsVO.setProgram(TaskConstants.CRU_PROGRAM_NAME);
							ctorderTask.setProgramName(TaskConstants.CRU_PROGRAM_NAME);
						}

						
					}
					if (TaskConstants.UNLOCK.equals(request.getOrder().getCtOrderSource().getChannel())) {
						Date currentDate = DateUtil.getCurrentTimeAsGMT();
						Timestamp timestamp =  new Timestamp(currentDate.getTime());
						taskDetailsVO.setCreationDate(timestamp);
						taskDetailsVO.setLast_modified_date(timestamp);
					}

					taskDetailsVO.setOrderRef(ctorderTask.getOrderNumber());
					//TODO: Calculate Task SLA is pending
					//calculateSLAForTask(taskDetailsVO);
					
					//Setting isWirelessFalloutOrder
					taskDetailsVO.setWirelessFalloutOrder(request.getOrder().isWirelessFalloutOrder());

					if(ctorderTask != null && null !=ctorderTask.getTaskStatus()) {
						taskDetailsVO.setTaskStatus(ctorderTask.getTaskStatus().toString());
					} else {
						taskDetailsVO.setTaskStatus(TaskConstants.NEW);
					}
					/** Populate request type for CRU-MOBILITY
					 * 
					 */
					if(processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase(TaskConstants.CRUMOBILITY)){
						if(null!=processOrderRequest.getOrder().getRequestType()){
							taskDetailsVO.setRequestType(processOrderRequest.getOrder().getRequestType().toString());
						}
						else{
							taskDetailsVO.setRequestType(TaskConstants.SOR);
						}
					}
					else{
						taskDetailsVO.setRequestType(TaskConstants.NA);
					}
					// Star Changes
					boolean isUnlockLOSG = isUnlockLOSGAvailableInRepo(processOrderRequest);
					/** START IRU_UNLOCK PMT:*/
					boolean isIruUnlock = isIruUnlockAvailableInRepo(processOrderRequest);
					String queueType = null;
					queueType = ctorderTask.getQueueType();
					if (null == queueType) {
						queueType = details.getQueueType();
					}
					String lineAction = null;
					boolean isNackQueue = false;
					//For NACK Type
					if(null != ctorderTask && ctorderTask.getQueueType()!=null 
							&& queueType.equalsIgnoreCase(TaskConstants.NACKTRIAGE)) {
						isNackQueue = true;
						taskDetailsVO.setLineCombos(TaskConstants.UNKNOWN);
						taskDetailsVO.setProgram(TaskConstants.NACK);
						taskDetailsVO.setLineAction(TaskConstants.UNKNOWN);
						lineAction = TaskConstants.UNKNOWN;
						//if child order is created by parent order
					} 
					else {

						List<String> lineComboList = new ArrayList<String>();
						if (null != ctorderTask.getLineCombination() && null != ctorderTask.getLineCombination().getLineCombo()) {
							lineComboList = ctorderTask.getLineCombination().getLineCombo();
						}
						if (null != lineComboList && !lineComboList.isEmpty()) {
							for(String lineCombo : lineComboList){
								taskDetailsVO.setLineCombos(lineCombo);
							}
						}	
						if (null != ctorderTask.getLineAction()) {
							lineAction = ctorderTask.getLineAction();
							taskDetailsVO.setLineAction(lineAction);

						}

					}
					if(request.getOrder().isNonUnifyWireless()) {		
						if (TaskConstants.CDEHS.equalsIgnoreCase(channel)) {
							taskDetailsVO.setProgram(TaskConstants.WIRELESS);					
						}	
						if(null != prgmNmeFulfllmntMthd) {
							if(!isNackQueue && TaskConstants.CRUMOBILITY.equalsIgnoreCase(channel)){
								taskDetailsVO.setProgram(prgmNmeFulfllmntMthd);			
							}
						} else {
							if(!isNackQueue && TaskConstants.CRUMOBILITY.equalsIgnoreCase(channel)){
								taskDetailsVO.setProgram(TaskConstants.DF);		
							}
						}
						//setting default lineAction for wireless if pgmFromFulfillmentMethod is null
						if(null != request.getOrder().getLosgTypeNonUnifyWireless()) {
							lineAction = request.getOrder().getLosgTypeNonUnifyWireless();
							taskDetailsVO.setLineAction(lineAction);
						} else {
							lineAction = TaskConstants.NEW;
							taskDetailsVO.setLineAction(lineAction);
						}		
					}
					if(processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase("DE-SMB") ||
							processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase("SMB-WEB-CENTER")){
						if(!isNackQueue){
							if(null != request.getOrder().getLosgTypeNonUnifyWireless()) {
								lineAction = ctorderTask.getLineAction();
								taskDetailsVO.setLineAction(lineAction);
							}
							taskDetailsVO.setProgram(processOrderRequest.getOrder().getProgramName());	
						}
					}

					if(isUnlockLOSG) {
						taskDetailsVO.setOwner(TaskConstants.NA);

						if(null != ctorderTask && null!=ctorderTask.getQueueSubType() && !ctorderTask.getQueueSubType().isEmpty()) {		
							taskDetailsVO.setLineAction(ctorderTask.getQueueSubType());
						} else {
							if (isIruUnlock){
								//taskDetailsVO.setLineAction(ctorderTask.getLineAction());
								taskDetailsVO.setOwner("ATT");
							} else {
								taskDetailsVO.setLineAction(TaskConstants.NA);
							}
						}
					}
					else {
						/*String ownerName = null;
							if(processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase("CDE-HS") || 
									processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase("SMB-WEB-CENTER")){
								/* For NACK follow the existing logic *
								if(null!=ctorderTask && ctorderTask.getQueueType()!=null 
										&& queueType.equalsIgnoreCase("NACK TRIAGE")) {
									ownerName = determineOwnerNameForTask(ctorderTask.getQueueType(),processOrderRequest.getOrder().getOrderSource().getChannel().toUpperCase());
									if(StringUtils.isNotEmpty(currentOrderImpl.getPartnerID()) && currentOrderImpl.getPartnerID().length()>0 && currentOrderImpl.getChannel().equalsIgnoreCase(OCEOrderConstants.SMB_WEB_CENTER)){
										ownerName=getDataAccessHelper().getPartnerNameFromOrderPartner(currentOrderImpl.getPartnerID());	
									}
								}
								else if(null!=ctorderTask.getOrderNumber()){
									//ownerName=getDataAccessHelper().getPartnerNameFromOrder(orderTask.getOrderNumber());
									/** To handle the case of Task Creation along with order creation .
						 * Use PartnerId from Current Order instead of fetching same from DB*
									if(StringUtils.isNotEmpty(currentOrderImpl.getPartnerID()) && currentOrderImpl.getPartnerID().length()>0){
										ownerName=getDataAccessHelper().getPartnerNameFromOrderPartner(currentOrderImpl.getPartnerID());	
									}
								}

							}else{
								ownerName = determineOwnerNameForTask(ctorderTask.getQueueType(),processOrderRequest.getOrder().getOrderSource().getChannel().toUpperCase());
							}*/
						/** Changes for US706168: Assigning Partner to Order END **/	

						//IF owner is not found, should be udpated as NA since the queue repository does not understand null.
						/*	ownerName = (null == ownerName || ownerName.isEmpty()) ? "NA" :ownerName;	
							taskDetailsVO.setOwner(ownerName);		*/	
						if(null!= lineAction && !lineAction.equals(TaskConstants.UNKNOWN)) {/*STAR req*/
							if(!isNackQueue){
								taskDetailsVO.setLineAction(lineAction);
							}
						}
					}
					if (isIruUnlock){
						taskDetailsVO.setLineCount("1");
					}
					taskDetailsVO.setCommunication_status("IN_SYSTEM");
					tskList.add(taskDetailsVO);
					this.taskList = tskList;
				}
			}
		}
		return this.taskList;
	}
	
	/**
	 * performs duplicate task processing
	 * 
	 * @param taskList
	 * @param parentOrderId
	 * @param taskOrderId
	 * @param queueType
	 * @return
	 * @throws OCEOrderException
	 */
	private boolean handleDuplicateTask(List<CtOrderTask> taskList,
			String parentOrderId, String taskOrderId, String queueType) {
		boolean taskExists = false;
		if (activeTasksExistForQueue(taskList, parentOrderId, taskOrderId,
				queueType)) {

			for (CtOrderTask currentTask : taskList) {
				if(null != currentTask.getChildOrderNumber()){
					String childOrderNum = currentTask.getChildOrderNumber();
					String orderNum = parentOrderId;
					if (null == orderNum) {
						orderNum = childOrderNum;
					}
					// need new and uncalim both
					String status  = "NEW";
					Set<String> resultList = orderTaskBean.getTaskForAnOrderOnStatus(orderNum,status);
					for (String taskId : resultList) {
						logger.debug("Associated Tasks : " + taskId);
						taskExists = true;
						TaskDetailsVO taskDetails = null;
						taskDetails = getTaskInfo(taskId);
						if (null == this.taskList || this.taskList.isEmpty()) {
							this.taskList.add(taskDetails);
						}
						currentTask.setQueueType(taskDetails.getQueueType());
						currentTask.setTaskId(taskDetails.getTaskId());
						currentTask.setTaskStatus(StTaskStatus.NEW);
					}
				}
				else if (null != currentTask.getOrderNumber()){
					String orderNum = currentTask.getOrderNumber();
					String status  = "NEW";
					String childOrderNum = currentTask.getChildOrderNumber();
					Set<String> resultList = orderTaskBean.getTaskForAnOrderOnStatus(orderNum,status);
					for (String taskId : resultList) {
						logger.debug("Associated Tasks : " + taskId);
						taskExists = true;
						TaskDetailsVO taskDetails = null;
						taskDetails = getTaskInfo(taskId);
						currentTask.setQueueType(taskDetails.getQueueType());
						currentTask.setTaskId(taskDetails.getTaskId());
						currentTask.setTaskStatus(StTaskStatus.NEW);
					}
				}
				//add null check
				taskExists = true;
			}
		}
		return taskExists;
	}
	
	/**
	 * 
	 * @param processOrderRequest
	 * @return
	 */
	public boolean isIruUnlockAvailableInRepo(ProcessOrderRequest processOrderRequest) {
		CtOrderSource ctOrderSource = processOrderRequest.getOrder().getOrderSource();
		
		boolean isIruUnlock = isIRUUnlockAvail(ctOrderSource);
		return isIruUnlock;
		
	}
	
	/**
	 * 
	 * @param ctOrderSource
	 * @return
	 */
	public boolean isIRUUnlockAvail(CtOrderSource ctOrderSource) {
		boolean isIruUnlock = false;
		
		
		String channel = "";
		if (ctOrderSource != null) {
			channel = (String) ctOrderSource.getChannel();
		}
		if("UNLOCK".equalsIgnoreCase(channel)) {
			isIruUnlock = true;
		}
		return isIruUnlock;
	}
	
	/**
	 * 
	 * @param processOrderRequest
	 * @return
	 */
	public boolean isUnlockLOSGAvailableInRepo(ProcessOrderRequest processOrderRequest) {
		boolean isUnlockLOSGAvailable = false;
		if (null != processOrderRequest.getOrder().getGroups()) {
			List<CtGroup> groupsItemList = processOrderRequest.getOrder().getGroups().getGroup();
			isUnlockLOSGAvailable = isUnlockLOSGAvailableInRepo( groupsItemList);
		}
		return isUnlockLOSGAvailable;
		
	}
	
	/**
	 * 
	 * @param groupsItemList
	 * @return
	 */
	public boolean isUnlockLOSGAvailableInRepo( List<CtGroup> groupsItemList) {
		boolean isUnlockLOSGAvailable = false;
		if(null == groupsItemList) {
			return isUnlockLOSGAvailable;
		}
		for (CtGroup grpItem : groupsItemList) {
			
			CtGroupCharacteristics groupItemChar = grpItem.getGroupCharacteristics();
			if(null != groupItemChar) {
				if (null != groupItemChar.getLoSGCharacteristics()
						&& null != groupItemChar.getLoSGCharacteristics().getLoSGType()){
					String losgType = (String) groupItemChar.getLoSGCharacteristics().getLoSGType().toString();
					if("UNLOCK".equalsIgnoreCase(losgType)) {
						isUnlockLOSGAvailable = true;
					}
				}
			}

		}
		return isUnlockLOSGAvailable;
	}
	
	/**
	 * Method to check if active task is already available for same queuetype
	 * under same order
	 * 
	 * @param orderIdInput
	 * @param list
	 * @param currentOrder
	 * @throws CommerceException
	 * @throws RepositoryException
	 * @throws OCEOrderException
	 */
	boolean activeTasksExistForQueue(List<CtOrderTask> taskList,
			String parentOrderId, String orderId, String pQueueType) {
		boolean activeTasks = false;
		boolean createTasks = false;
		List<String> avosRefTasks = new ArrayList<String>();
		for (CtOrderTask task : taskList) {
			if (null == task.getTaskId() || task.getTaskId().isEmpty())
				createTasks = true;
		}

		if (createTasks && StringUtilities.isNotEmptyOrNull(pQueueType)) {
			Set<String> allOrderIds = new HashSet<String>();
			allOrderIds.add(parentOrderId);
			allOrderIds.add(orderId);
			if(allOrderIds.contains(parentOrderId)) {
				Set<String> taskIds = orderTaskBean.getTaskForAnOrder(parentOrderId);
				for (String taskId : taskIds) {
					logger.debug("Associated Tasks : " + taskId);
					TaskDetailsVO taskDetails = null;
					taskDetails = getTaskInfo(taskId);
					String queueType = taskDetails.getQueueType();
					if(queueType.equalsIgnoreCase(pQueueType)){
						activeTasks = true;
						break;
					}
				}
			}
		}
		return activeTasks;

	}
	
	/**
	 * 
	 * @param ctGroups
	 * @return String
	 */
	private String getLosgRefId(OCEOrderInfo oceOrderInfo, String channel) {
		String losgRefId = null;
		StringBuilder losgRefIdBuilder = new StringBuilder();
		int i = 0;
		if (null != oceOrderInfo
				&& null != oceOrderInfo.getGroupList()
				&& null != oceOrderInfo.getGroupList().getGroup()) {
			i = oceOrderInfo.getGroupList().getGroup().size();
			for (CtGroup ctGroup : oceOrderInfo.getGroupList().getGroup()) {
				if (null != ctGroup.getGroupCharacteristics()) {
					if (null != ctGroup.getGroupCharacteristics().getLoSGCharacteristics()) {
						losgRefId = ctGroup.getGroupCharacteristics().getLoSGCharacteristics().getLoSGReferenceId();
						losgRefIdBuilder.append(oceOrderInfo.getOceOrderNumber());
						losgRefIdBuilder.append(":");
						losgRefIdBuilder.append(losgRefId);
						--i;
						if (i != 0) {
							losgRefIdBuilder.append(", ");
						}
					}
				}
			}
			
		}
		return losgRefIdBuilder.toString();
	}
	
	
	/*
	 * This method is written to call a separate Camunda process workflow
	 * (NotifyPostUnlockService) which is applicable only for UNLOCK channel.
	 * 
	 * @param taskMessage
	 * 
	 * @param applicationName
	 * 
	 * @return
	 * 
	 * @throws ServiceException
	 * 
	 * @throws RemoteException
	 * 
	 * @throws RepositoryException
	 */

	public <HttpResponse> boolean sendTaskInfoToPostNotifyUnlockCamunda(String orderId,
			String applicationName) throws OCEException {
		logger.info("CamundaIntegrationService::: sendTaskInfoToPostNotifyUnlockCamunda--------"+ applicationName);
		boolean success = false;
		int statusCode = -1;
		//RepositoryItem unlockTask = null;
		/*Map<String, Object> inputJson = new HashMap<String, Object>();//http://zld02808.vci.att.com:7603/ -- for D5
		//http://zlt04350.vci.att.com:8130 --- for T3
		String url = taskNotificationURL;
		String postNotifyUnlockEndPointURLCamunda = url;
		try {
			if (orderId == null || orderId == "") {
				logger.info("No orderId found in ATG DB::: hence skip the Camunda notification");
				return false;
			}
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpResponse response = null;
			// HttpHost proxy = new HttpHost("one.proxy.att.com", 8080, "http");
			Object body = null;
			try {
				
				RepositoryItem orderItem = getOrderManager().getOrderRepository().getItem(
						orderId, OCEOrderConstants.OCE_ORDER_ITEM);

				StAccountSubCategory subCategory = this.getAccountSubCategory(orderItem); 
				if(StAccountSubCategory.EXISTING != subCategory) {
					vlogInfo("Current task order is not part of the existing ATT cusotmer, hence skipping to send AVOS notification for order id : {0}, account Sub Category {1}", orderItem, subCategory );
					return false;
				}
				
				 * httpClient.getParams().setParameter(
				 * ConnRoutePNames.DEFAULT_PROXY, proxy);
				 
				String uri = postNotifyUnlockEndPointURLCamunda.concat(orderId.trim());
				logger.info("CamundaIntegrationService::: uri--------" + uri);
				HttpGet getRequest = new HttpGet(uri);
				logger.info("CamundaIntegrationService::: getRequest--------"
						+ getRequest);
				ResponseHandler<?> responseHandler = new BasicResponseHandler();
				response = (HttpResponse) httpClient.execute(getRequest);
				logger.info("CamundaIntegrationService::: response--------"
						+ response);
				if (null != response) {
					statusCode = ((org.apache.http.HttpResponse) response).getStatusLine().getStatusCode();
					logger.info("CamundaIntegrationService::: statusCode--------"
							+ statusCode);
				}
				if (statusCode == 200 || statusCode == 202) {
					body = responseHandler.handleResponse((org.apache.http.HttpResponse) response);
					success = true;
					logger.info("CamundaIntegrationService::: body--------" + body);
					String json = "{\"name\":\"mkyong\", \"age\":29}";
					JSONObject jObject  = new JSONObject(json);
					
					Iterator<String> keysItr = jObject.keys();
				    while(keysItr.hasNext()) {
				        String key = keysItr.next();
				        Object value = jObject.get(key);
				        inputJson.put(key, value);
				    }
					
					
					ObjectMapper mapper = new ObjectMapper();
					Map<String, Object> map = new HashMap<String, Object>();
					inputJson = mapper.readValue(body.toString(), new TypeReference<Map<String, String>>(){});
					logger.info("CamundaIntegrationService::: inputJson--------" + inputJson);
					System.out.println(inputJson);
					inputJson = getTransformationUtil().createMapfromJson(
							body.toString());
					String responseCode = inputJson.get("code").toString();
					if (null != responseCode && "" != responseCode
							&& responseCode.equals("400")) {
						logger.info("CamundaIntegrationService::: Camunda processes is down..."
								+ inputJson.toString());
						return false;
					} else {
						success = true;
					}
				}
				if (statusCode == 503 || statusCode == 400 || statusCode == 403
						|| statusCode == 409 || statusCode == 500) {
					success = false;
					logger.error("CamundaIntegrationService::: sendTaskInfoToPostNotifyUnlockCamunda throws exceptions...."
							+ response.toString());
				}
			} catch (Exception e) {
				logger.error("CamundaIntegrationService::: sendTaskInfoToPostNotifyUnlockCamunda throws exceptions...." + e.getMessage());
			} finally {
				logger.info("CamundaIntegrationService::: sendTaskInfoToPostNotifyUnlockCamunda finally called....");
				// Important: Close the connect
				httpClient.getConnectionManager().shutdown();
			}
			if (logger.isTraceEnabled()) {
				logger.trace("Leaving CamundaIntegrationService::: sendTaskInfoToPostNotifyUnlockCamunda");
			}
		} catch (Exception e) {
			logger.error(e +" sendTaskInfoToPostNotifyUnlockCamunda : NotifyUnlockParentType ERROR SCENARIO ");
		}
*/		return success;
	}
	
	
	/**
	 * @param taskMessage
	 * @throws RepositoryException
	 */
	public void updateTaskNotificationStatus(TaskDetailsVO orderTask) throws HibernateException{
		if (logger.isTraceEnabled()) {
			logger.trace(orderTask.getTaskId(),
					"updating notification status");
		}
		String updateTaskNotificationQuery ="UPDATE OCETaskDetails SET mCommunication_status= :commStatus , "
				+ "mLast_Communication_timestamp = SYSDATE WHERE mAvos_task_id= :avosTaskRefId";
		//PreparedStatement stmt = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(updateTaskNotificationQuery);
			
			if (null != orderTask) {
				session.getTransaction().begin();
				query.setParameter("commStatus", "NOTIFIED");
				query.setParameter("avosTaskRefId", orderTask.getAvos_task_id());
				query.executeUpdate();
				session.getTransaction().commit();
			}
		} catch (HibernateException e) {
			if (logger.isErrorEnabled()){
				logger.error(e.getMessage());
			}
			e.printStackTrace();
		} finally {
			if(null != session){
				try {
					session.close();
				} catch (HibernateException e) {
					if (logger.isErrorEnabled()) {
						logger.error(e.getMessage());
					}
				}
			}
		}
		if (logger.isInfoEnabled()) {
			logger.info(orderTask.getTaskId(),
					"Task " + orderTask.getTaskId() + " notified");
		}
		if (logger.isTraceEnabled()) {
			logger.trace("After updateTaskNotificationStatus");
		}
	}
	
	/**
	 * 
	 * @param orderTask
	 * @throws HibernateException
	 */
	public void incrementTaskRetry(TaskDetailsVO orderTask) throws HibernateException{
		if(logger.isTraceEnabled()) {
			logger.trace(orderTask.getTaskId(),"updating retry attempts");
		}
		String updateRetryCountQuery = "UPDATE OCETaskDetails SET mTaskRetryAttempt = mTaskRetryAttempt + 1 "
				+ "WHERE mAvos_task_id= :avosTaskRefId";
		Session session = null;
		
		try {
			session = sessionFactory.openSession();
			session.getTransaction().begin();
			Query query = session.createQuery(updateRetryCountQuery);
			if (null != orderTask) {
				
				query.setParameter("avosTaskRefId", orderTask.getAvos_task_id());
				query.executeUpdate();
				session.getTransaction().commit();
			}
		} catch (HibernateException e) {
			if (logger.isErrorEnabled()){
				logger.error(e.getMessage());
			}
			e.printStackTrace();
		} finally {
			if(null != session){
				try {
					session.close();
				} catch (HibernateException e) {
					if (logger.isErrorEnabled()) {
						logger.error(e.getMessage());
					}
				}
			}
		}
		if(logger.isInfoEnabled()) {
			logger.info("Task "+orderTask.getTaskId()+" will be retried");
		}
	}
}
