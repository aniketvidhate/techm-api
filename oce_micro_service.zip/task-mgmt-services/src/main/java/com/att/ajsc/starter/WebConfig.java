package com.att.ajsc.starter;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.Filter;

import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.exception.VelocityException;
import org.apache.velocity.runtime.RuntimeConstants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ui.velocity.VelocityEngineFactory;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.velocity.VelocityLayoutViewResolver;

import com.att.cadi.filter.CadiFilter;

@Configuration
public class WebConfig {

	@Bean
	public WebMvcConfigurerAdapter forwardToIndex() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addViewControllers(ViewControllerRegistry registry) {
				registry.addViewController("/swagger").setViewName("redirect:/mvc/swagger/index.html");
			}
		};
	}
	
	
	/* Velocity Engine configuration */
	
	

	@Value("${spring.velocity.prefix}")
	private String vtplPrefix;
	
	
	@Bean
	public VelocityEngine getVelocityEngine() throws VelocityException, IOException {

		VelocityEngineFactory factory = new VelocityEngineFactory();
		Properties props = new Properties();
		props.put(RuntimeConstants.RESOURCE_LOADER, "classpath");
		props.put("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
		factory.setVelocityProperties(props);
		return factory.createVelocityEngine();
	}


	@Bean
	public ViewResolver viewResolver() {
		 final VelocityLayoutViewResolver velocitybean = new VelocityLayoutViewResolver();
		velocitybean.setCache(true);
		velocitybean.setPrefix(vtplPrefix);
		velocitybean.setSuffix(".vm");
		velocitybean.setOrder(1);
		return velocitybean;
	}

	/*//AAF Cadi code Starts
	@Bean
	public FilterRegistrationBean cadiFilterRegistration() {

		FilterRegistrationBean registration = new FilterRegistrationBean();

		registration.setFilter(cadiFilter());
		registration.addUrlPatterns("/*");
		registration.addInitParameter("cadi_prop_files", "src/main/resources/cadi.properties");
		registration.setName("cadiFilter");
		registration.setOrder(0);

		return registration;
	}

	@Bean(name = "cadiFilter")
	public Filter cadiFilter() {
		return new CadiFilter();
	}*/
	
	//AAF Cadi code Ends
}

