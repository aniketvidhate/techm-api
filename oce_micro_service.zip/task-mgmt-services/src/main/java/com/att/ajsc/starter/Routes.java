package com.att.ajsc.starter;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.ajsc.common.camel.AjscRouteBuilder;

//@DependsOn("camelContext")
@Component
public class Routes extends RouteBuilder {
	@Autowired
	private AjscRouteBuilder ajscRoute;
	
//    @Autowired
//    private CamelContext camelContext;

	@Override
	public void configure() throws Exception {
	//	RouteBuilder builder = this;
		//org.apache.camel.impl.defaultm
		
//	ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"camelContext.xml"});
//    CamelContext camel = SpringCamelContext.springCamelContext(context); 
//    camel.start();
  //  camel.getProcessorDefinition("routeAuditLog");
//		InputStream is1 = getClass().getResourceAsStream("routes/camelContext.routes");
//		is1.available();
//		InputStream is = getClass().getResourceAsStream("camelContext.xml");
//		RoutesDefinition routesDef = this.getContext().loadRoutesDefinition(is);
//		this.getContext().addRouteDefinitions(routesDef.getRoutes());
		
    
//    SimpleRegistry registry = new SimpleRegistry();
//    registry.put("taskService", new TaskServiceImpl());
//    CamelContext context1 = new DefaultCamelContext(registry); 
//    camel.setRestRegistry(registry);
 //   JacksonDataFormat
    
      //  this.camelContext = camel;
         //this.setContext(camel);
        // this.
		ajscRoute.initialize(this);
		//ajscRoute.
		//ajscRoute.setRoute(from("servlet:/?matchOnUriPrefix=true").to("cxfbean:jaxrsServices?providers=jaxrsProviders"));
	
		//ajscRoute.
		//ajscRoute.setRoute(from("servlet:/?matchOnUriPrefix=true").to("cxfbean:jaxrsServices"));
	}
	
//	@PostConstruct
//    public void init(){
//         
//        camelContext.addInterceptStrategy(new AjscInterceptStrategy());
//    }

}
