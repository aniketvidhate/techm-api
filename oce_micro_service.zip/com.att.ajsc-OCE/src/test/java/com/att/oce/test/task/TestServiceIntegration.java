package com.att.oce.test.task;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static reactor.bus.selector.Selectors.$;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.service.task.Bean.DBTaskInfoBean;
import com.att.oce.service.task.Bean.GetNextTaskBean;
import com.att.oce.service.task.Bean.OrderTaskBean;
import com.att.oce.service.task.Bean.TaskInfoBean;
import com.att.oce.service.task.BeanImpl.AbstractTaskBeanImpl;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.TaskConstants;

import reactor.bus.EventBus;

public class TestServiceIntegration extends TaskMgmtBaseTest {

	@Autowired
	private GetNextTaskBean getNextTaskBean;
	@Autowired
	private OrderTaskBean orderTaskBean;
	@Autowired
	private DBTaskInfoBean dbTaskBean;
	@Autowired
	private TaskInfoBean taskInfoBean;

	private EventBus eventBus;
	
	@Before
	public void testIntegrationInitialize() throws OCEException {
		
		eventBus  = AbstractTaskBeanImpl.eventBus;
		
		eventBus.on($(TaskConstants.TASK_LOADED), taskInfoBean);
		eventBus.on($(TaskConstants.TASK_LOADED), orderTaskBean);
		eventBus.on($(TaskConstants.TASK_LOADED), getNextTaskBean);
		
		//eventBus.on($(TaskConstants.TASK_CREATED), dbTaskBean);
		eventBus.on($(TaskConstants.TASK_CREATED), dbsimulator);
		eventBus.on($(TaskConstants.TASK_CREATED), orderTaskBean);
		eventBus.on($(TaskConstants.TASK_CREATED), getNextTaskBean);
		
		//eventBus.on($(TaskConstants.TASK_UPDATED), dbTaskBean);
		eventBus.on($(TaskConstants.TASK_UPDATED), orderTaskBean);
		eventBus.on($(TaskConstants.TASK_UPDATED), getNextTaskBean);
		
		List tasks = dbsimulator.fetchAllOpenTask();
		taskInfoBean.initialize(tasks);
		orderTaskBean.initialize(tasks);
		getNextTaskBean.initialize(tasks);
    }
	

	@Test
	public void testCreateTaskIntegration() {
		TaskDetailsVO task = dbsimulator.getTestTaskDetailsVO(500);
		List<TaskDetailsVO> tasks = new ArrayList<TaskDetailsVO>();
		tasks.add(task);
		try {
			
			Collection<TaskDetailsVO>newTasks = taskInfoBean.getAllTask();
			assertFalse(tasks.isEmpty());
			for (TaskDetailsVO task1 : newTasks) {
				System.out.println("IntegrationTesting >>> Before Task Creation:" + task1);
			}
			
			taskInfoBean.createTasks(tasks);
			newTasks = taskInfoBean.getAllTask();
			assertFalse(tasks.isEmpty());
			for (TaskDetailsVO task1 : newTasks) {
				System.out.println("IntegrationTesting >>> After Task Creation:" + task1);
			}
			
		} catch (OCEException e) {
			e.printStackTrace();
		}
		System.out.println("IntegrationTesting >>> Creation test completed");
	}

	@Test
	public void testUpdateTaskIntegration() {
		TaskDetailsVO task = dbsimulator.getTestTaskDetailsVO(100);
		
		task.setOrderRef("Bala");
		List<TaskDetailsVO> tasks = new ArrayList<TaskDetailsVO>();
		tasks.add(task);
		try {
			System.out.println("IntegrationTesting >>>  Before Update : " + taskInfoBean.getTaskInfo(task.getTaskId()));
			taskInfoBean.updateTasks(tasks);
			System.out.println("IntegrationTesting >>> After Update : " + taskInfoBean.getTaskInfo(task.getTaskId()));
		} catch (OCEException e) {
			e.printStackTrace();
		}
		System.out.println("IntegrationTesting >>> Creation test completed");
	}
	
	@Test
	public void testGetNextTaskIntegration() {

		TaskDetailsVO task;
		try {

			task = dbsimulator.getTestTaskDetailsVO(1);  // Actual request from the external world
			String taskId = getNextTaskBean.getNextTask(task);
			assertNotNull("IntegrationTesting >>> Task Id is Null", taskId);
			
			task = taskInfoBean.getTaskInfo(taskId);
			assertNotNull("IntegrationTesting >>> Task is Null", task);
			System.out.println("IntegrationTesting >>> Task Obtained:" +task);
			
			//First Outbound call to update the order in ATG synchronously
			//Second Outbound call to ATG to update the marker entry asynchronously
			
			Set<String> test = orderTaskBean.getTaskForAnOrder(task.getOrderRef());
			assertNotNull("IntegrationTesting >>> Task is Null", task);

			List<TaskDetailsVO> tasks = new ArrayList<TaskDetailsVO>();
			
			for(String id: test) {
				System.out.println("IntegrationTesting >>> Task associated : " +id);
				task = taskInfoBean.getTaskInfo(id);
				System.out.println("IntegrationTesting >>> Task Details    : " +task);
				task.setCsrId("bk436x");
				task.setTaskStatus(TaskConstants.REP_PROCESSING);
				tasks.add(task);
			}
			
			taskInfoBean.updateTasks(tasks);
			
			//Now respond to the caller with the task id and its associated order id
			
		} catch (OCEException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetAllOpenTask() {

		Collection<TaskDetailsVO> tasks;
		try {
			tasks = taskInfoBean.getAllTask();
			assertFalse(tasks.isEmpty());
			for (TaskDetailsVO task : tasks) {
				System.out.println("IntegrationTesting >>> Task info:" + task);
			}
		} catch (OCEException e) {
			e.printStackTrace();
		}
	}

	@After
	public void purgeTestData() {
		try {
			taskInfoBean.purgeTestData();
			orderTaskBean.purgeTestData();
			getNextTaskBean.purgeTestData();
		} catch (OCEException e) {
			e.printStackTrace();
		}
	}

}