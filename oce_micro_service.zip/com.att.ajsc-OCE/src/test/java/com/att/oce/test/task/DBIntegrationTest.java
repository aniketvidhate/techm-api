/**
 * 
 */
package com.att.oce.test.task;

/**
 * @author bk436x
 *
 */
public interface DBIntegrationTest {

}
