package com.att.oce.test.task;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.service.task.Bean.TaskInfoBean;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.TaskConstants;

public class TestTaskInfoBean extends TaskMgmtBaseTest {

	@Autowired
	TaskInfoBean taskInfoBean;

	@Before
	public void testInitialize() {
		try {
			taskInfoBean.initialize(dbsimulator.getTestTaskDetailsVOList());
			System.out.println("Testing create task taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}

	}

	@Test
	public void testCreateTask() {

		try {
			List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetailsVO = dbsimulator.getTestTaskDetailsVO(87);
			tskList.add(taskDetailsVO);
			taskInfoBean.createTasks(tskList);
			System.out.println("Testing create task taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			fail("Testing create task taskInfoBeanImpl failed");
		}
	}

	@Test
	public void testUpdateTask() {

		try {
			List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetailsVO = dbsimulator.getTestTaskDetailsVO(1);
			tskList.add(taskDetailsVO);
			taskInfoBean.updateTasks(tskList);
			System.out.println("Testing update task taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			fail("Testing create task taskInfoBeanImpl failed");
		}
	}
	@Test
	public void testGetTaskInfo() {

		TaskDetailsVO taskDetailsVO = null;

		try {

			taskDetailsVO = dbsimulator.getTestTaskDetailsVO(1);

			taskDetailsVO = taskInfoBean.getTaskInfo(taskDetailsVO.getTaskId());

			if (taskDetailsVO != null) {
				System.out.println("Task id in testGetAllTask >>>>>" + taskDetailsVO);
			}

			System.out.println("Testing get task info failed completed successfully");
		} catch (Exception e) {
			fail("Testing get task info failed");
		}
	}

	@Test
	public void test_a_GetAllTask() {
		Collection<TaskDetailsVO> taskdetails = null;

		try {
			taskdetails = taskInfoBean.getAllTask();
		} catch (OCEException e) {
			e.printStackTrace();
		}

		if (taskdetails != null) {
			for (TaskDetailsVO vo : taskdetails) {
				System.out.println("Task id in testGetAllTask >>>>>" + vo);
			}
		}

	}

	@After
	public void purgeTestData() {
		try {
			taskInfoBean.purgeTestData();
		} catch (OCEException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testVOMerge() {

		TaskDetailsVO taskDetailsVO = dbsimulator.getTestTaskDetailsVO(1);
		System.out.println("Initial : " + taskDetailsVO);
		try {
			TaskDetailsVO vo2 = dbsimulator.getTestTaskDetailsVO(2);
			System.out.println("New One : " + vo2);
			vo2.setChannel(null);
			vo2.setProgram(null);
			vo2.setQueueType(null);
			vo2.setTaskStatus(TaskConstants.UNCLAIMED);
			System.out.println("Mod One : " + vo2);
			taskDetailsVO = taskDetailsVO.merge(vo2);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		System.out.println("End State : " + taskDetailsVO);

	}
}