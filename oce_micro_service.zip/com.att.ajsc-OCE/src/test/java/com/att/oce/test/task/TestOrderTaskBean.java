package com.att.oce.test.task;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.att.oce.service.task.Bean.OrderTaskBean;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;

public class TestOrderTaskBean extends TaskMgmtBaseTest {

	@Autowired
	OrderTaskBean orderTaskBean;

	@Test
	public void test_b_CreateTask() {
		try {
			List<TaskDetailsVO> taskDetailsList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
			taskDetailsList.add(taskDetailsVO1);
			orderTaskBean.createTasks(taskDetailsList);
			System.out.println("Testing testFetchAllTasks taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}

	}

	@Test
	public void test_c_UpdateTasks() {
		try {
			List<TaskDetailsVO> taskDetailsList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
			taskDetailsList.add(taskDetailsVO1);
			orderTaskBean.updateTasks(taskDetailsList);
			System.out.println("Testing testFetchAllOpenTask taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}

	@Before
	public void test_a_Initialize() {
		try {
			List<TaskDetailsVO> taskDetailsList = dbsimulator.getTestTaskDetailsVOList();
			orderTaskBean.initialize(taskDetailsList);
			System.out.println("Testing testInitialize taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}

	@Test
	public void test_d_getTaskInfo() {
		try {
			TaskDetailsVO taskDetailsVO1 = dbsimulator.getTestTaskDetailsVO(1);
			orderTaskBean.getTaskForAnOrder(taskDetailsVO1.getOrderRef());
			System.out.println("Testing testInitialize taskInfoBeanImpl completed successfully");
		} catch (Exception e) {
			e.printStackTrace();
			fail("testInitialize failed");
		}
	}

	@After
	public void purgeTestData() {

		try {
			orderTaskBean.purgeTestData();
		} catch (OCEException e) {
			e.printStackTrace();
		}
		System.out.println("Removed test data from memory");
	}

}