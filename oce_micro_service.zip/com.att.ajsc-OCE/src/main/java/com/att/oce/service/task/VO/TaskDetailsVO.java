package com.att.oce.service.task.VO;

import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtOrderTask;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.util.CalenderUtils;
import com.att.oce.service.task.util.StringUtilities;

public class TaskDetailsVO {

	private String mTaskId;
	private Date mCreationDate;
	private Date dCreationDate;
	private Date mAcceptedDate;
	private String mOrderRef;
	private String mLineCombos;
	private String mLineAction;
	private String mProgram;
	private String mQueueType;
	private String mTaskStatus;
	private String mTaskSubStatus;
	private String mChannel;
	private String mOwner;
	private int mTaskRetryAttempt;
	private String mLosgId;
	private String mRequestType;
	private String mActionType;
	private Integer mWirelessFallout;
	private String mExternalOrderNum;
	private String mLineCount;
	private String queueSubType;
	

	private String mQueueCategory;

	private String mAvos_task_id;

	private String mCreated_by;

	private String mChild_order_ref;

	private String mLast_modified_by;

	private Date mLast_modified_date;

	private Date mFallout_end_date;

	private String mCommunication_status;

	private String mLast_Communication_timestamp;

	private String mVersion;

	private String mApplicationName;

	private String mQueue_Priority_value;

	private String mCsrId;
	private List<String> orgUnitList;
	private List<String> partnerName;
	private List<String> queueTypes;
	private String queueInputType;
	private boolean isWirelessFalloutOrder;
	private boolean isGlobalVisible;
	private String state;
	private List<String> taskStatusList;
	private String subStatus;
	private String callbackPreference;
	private String queueId;
	private String repComments;
	
	/**
	 * @return the mAcceptedDate
	 */
	public Date getAcceptedDate() {
		return mAcceptedDate;
	}

	/**
	 * @param mAcceptedDate the mAcceptedDate to set
	 */
	public void setAcceptedDate(Date mAcceptedDate) {
		this.mAcceptedDate = mAcceptedDate;
	}
	
	
	public Date getdCreationDate() {
		return dCreationDate;
	}

	public void setdCreationDate(Date oCreationDate) {
		this.dCreationDate = oCreationDate;
	}

	public String getCsrId() {
		return mCsrId;
	}

	public void setCsrId(String mCsrId) {
		this.mCsrId = mCsrId;
	}

	public String getAvos_task_id() {
		return mAvos_task_id;
	}

	public void setAvos_task_id(String mAvos_task_id) {
		this.mAvos_task_id = mAvos_task_id;
	}

	public String getCreated_by() {
		return mCreated_by;
	}

	public void setCreated_by(String mCreated_by) {
		this.mCreated_by = mCreated_by;
	}

	public String getChild_order_ref() {
		return mChild_order_ref;
	}

	public void setChild_order_ref(String mChild_order_ref) {
		this.mChild_order_ref = mChild_order_ref;
	}

	public String getLast_modified_by() {
		return mLast_modified_by;
	}

	public void setLast_modified_by(String mLast_modified_by) {
		this.mLast_modified_by = mLast_modified_by;
	}

	public Date getLast_modified_date() {
		return mLast_modified_date;
	}

	public void setLast_modified_date(Date mLast_modified_date) {
		this.mLast_modified_date = mLast_modified_date;
	}

	public Date getFallout_end_date() {
		return mFallout_end_date;
	}

	public void setFallout_end_date(Date mFallout_end_date) {
		this.mFallout_end_date = mFallout_end_date;
	}

	public String getCommunication_status() {
		return mCommunication_status;
	}

	public void setCommunication_status(String mCommunication_status) {
		this.mCommunication_status = mCommunication_status;
	}

	public String getLast_Communication_timestamp() {
		return mLast_Communication_timestamp;
	}

	public void setLast_Communication_timestamp(String mLast_Communication_timestamp) {
		this.mLast_Communication_timestamp = mLast_Communication_timestamp;
	}

	public String getVersion() {
		return mVersion;
	}

	public void setVersion(String mVersion) {
		this.mVersion = mVersion;
	}

	public String getApplicationName() {
		return mApplicationName;
	}

	public void setApplicationName(String mApplicationName) {
		this.mApplicationName = mApplicationName;
	}

	public String getQueue_Priority_value() {
		return mQueue_Priority_value;
	}

	public void setQueue_Priority_value(String mQueue_Priority_value) {
		this.mQueue_Priority_value = mQueue_Priority_value;
	}

	public int getTaskRetryAttempt() {
		return mTaskRetryAttempt;
	}

	public void setTaskRetryAttempt(int mTaskRetryAttempt) {
		this.mTaskRetryAttempt = mTaskRetryAttempt;
	}

	public String getTaskId() {
		return mTaskId;
	}

	public void setTaskId(String mTaskId) {
		this.mTaskId = mTaskId;
	}

	public Date getCreationDate() {
		return mCreationDate;
	}

	public void setCreationDate(Date mCreationDate) {
		this.mCreationDate = mCreationDate;
	}

	public String getOrderRef() {
		return mOrderRef;
	}

	public void setOrderRef(String mOrderRef) {
		this.mOrderRef = mOrderRef;
	}

	public String getLineCombos() {
		return mLineCombos;
	}

	public void setLineCombos(String mLineCombos) {
		this.mLineCombos = mLineCombos;
	}

	public String getLineAction() {
		return mLineAction;
	}

	public void setLineAction(String mLineAction) {
		this.mLineAction = mLineAction;
	}

	public String getProgram() {
		return mProgram;
	}

	public void setProgram(String mProgram) {
		this.mProgram = mProgram;
	}

	public String getQueueType() {
		return mQueueType;
	}

	public void setQueueType(String mQueueType) {
		this.mQueueType = mQueueType;
	}

	public String getTaskStatus() {
		return mTaskStatus;
	}

	public void setTaskStatus(String mTaskStatus) {
		this.mTaskStatus = mTaskStatus;
	}

	public String getTaskSubStatus() {
		return mTaskSubStatus;
	}

	public void setTaskSubStatus(String mTaskSubStatus) {
		this.mTaskSubStatus = mTaskSubStatus;
	}

	public String getChannel() {
		return mChannel;
	}

	public void setChannel(String mChannel) {
		this.mChannel = mChannel;
	}

	public String getOwner() {
		return mOwner;
	}

	public void setOwner(String mOwner) {
		this.mOwner = mOwner;
	}

	public String getLosgId() {
		return mLosgId;
	}

	public void setLosgId(String mLosgId) {
		this.mLosgId = mLosgId;
	}

	public String getRequestType() {
		return mRequestType;
	}

	public void setRequestType(String mRequestType) {
		this.mRequestType = mRequestType;
	}

	public String getActionType() {
		return mActionType;
	}

	public void setActionType(String mActionType) {
		this.mActionType = mActionType;
	}

	public Integer getWirelessFallout() {
		return mWirelessFallout;
	}

	public void setWirelessFallout(int mWirelessFallout) {
		this.mWirelessFallout = mWirelessFallout;
	}

	public String getExternalOrderNum() {
		return mExternalOrderNum;
	}

	public void setExternalOrderNum(String mExternalOrderNum) {
		this.mExternalOrderNum = mExternalOrderNum;
	}

	public int hashCode() {
		int hashcode = 0;
		hashcode = mTaskId.hashCode() * 20;
		return hashcode;
	}

	public boolean equals(Object obj) {
		if (obj instanceof TaskDetailsVO) {
			TaskDetailsVO taskDetailsVO = (TaskDetailsVO) obj;
			return (taskDetailsVO.mTaskId.equals(this.mTaskId));
		} else {
			return false;
		}
	}

	@Override
	public String toString() {
		StringBuffer buf = new StringBuffer();

		buf.append("Task Id : ");
		buf.append(this.mTaskId);
		buf.append(" Creation Date : ");
		buf.append(this.mCreationDate);
		buf.append(" Order Id : ");
		buf.append(this.mOrderRef);
		buf.append(" Line Combo : ");
		buf.append(this.mLineCombos);
		buf.append(" Line Action : ");
		buf.append(this.mLineAction);
		buf.append(" Program : ");
		buf.append(this.mProgram);
		buf.append(" QueueType : ");
		buf.append(this.mQueueType);
		buf.append(" Task Status : ");
		buf.append(this.mTaskStatus);
		buf.append(" Task Sub Status : ");
		buf.append(this.mTaskSubStatus);
		buf.append(" Channel : ");
		buf.append(this.mChannel);
		buf.append(" Owner : ");
		buf.append(this.mOwner);
		buf.append(" Retry Attempt : ");
		buf.append(this.mTaskRetryAttempt);
		buf.append(" LOSG Id : ");
		buf.append(this.mLosgId);
		buf.append(" Request Type : ");
		buf.append(this.mRequestType);
		buf.append(" Action Type : ");
		buf.append(this.mActionType);
		buf.append(" Wireless Fallout : ");
		buf.append(this.mWirelessFallout);

		return buf.toString();
	}

	public TaskDetailsVO merge(TaskDetailsVO vo)
			throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {

		Field[] fields = this.getClass().getDeclaredFields();
		for (Field field : fields) {
			// get value
			Object newValue = field.get(vo);

			Object existingvalue = field.get(this);

			// check the values are different, then update
			if (newValue == null && existingvalue instanceof String
					&& StringUtilities.isNotEmptyOrNull((String) existingvalue)) {
				field.set(vo, existingvalue);
			}
		}
		return vo;
	}

	public TaskDetailsVO() {

	}

	/**
	 * @return the mQueueCategory
	 */
	public String getQueueCategory() {
		return mQueueCategory;
	}

	/**
	 * @param mQueueCategory
	 *            the mQueueCategory to set
	 */
	public void setQueueCategory(String mQueueCategory) {
		this.mQueueCategory = mQueueCategory;
	}

	/**
	 * @return the mLineCount
	 */
	public String getLineCount() {
		return mLineCount;
	}

	/**
	 * @param mLineCount
	 *            the mLineCount to set
	 */
	public void setLineCount(String mLineCount) {
		this.mLineCount = mLineCount;
	}

	public TaskDetailsVO(CtOrderTask orderTask) throws OCEException {
		try{
			
			
		
		if(StringUtilities.isNotEmptyOrNull(orderTask.getCustomerOrderNumber())) {
			this.setExternalOrderNum(orderTask.getCustomerOrderNumber());
		}
			
		if(StringUtilities.isNotEmptyOrNull(orderTask.getChildOrderNumber())) {
			this.setChild_order_ref(orderTask.getCustomerOrderNumber());
		}
		
		if(StringUtilities.isNotEmptyOrNull(orderTask.getOrderNumber())) {
			this.setOrderRef(orderTask.getOrderNumber());
		}
		
		if(StringUtilities.isNotEmptyOrNull(orderTask.getApplicationName())) {
			this.setApplicationName(orderTask.getApplicationName());
		}
		
		if(StringUtilities.isNotEmptyOrNull(orderTask.getCsrId())) {
			this.setCsrId(orderTask.getCsrId());
		}

		//DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		//if(StringUtilities.isNotEmptyOrNull(orderTask.getLastModifiedDateTime())) {
			this.setLast_modified_date(CalenderUtils.gstDate());
		//}
		
		if(StringUtilities.isNotEmptyOrNull(orderTask.getTaskId())) {
			this.setTaskId(orderTask.getTaskId());
		}

		if(StringUtilities.isNotEmptyOrNull(orderTask.getProgramName())) {
			this.setProgram(orderTask.getProgramName());
		}
		
		if(StringUtilities.isNotEmptyOrNull(orderTask.getQueueType())) {
			this.setQueueType(orderTask.getQueueType());
		}
		
		if(StringUtilities.isNotEmptyOrNull(orderTask.getLineAction())) {
			this.setLineAction(orderTask.getLineAction());
		}

		if(orderTask.getTaskStatus() != null && StringUtilities.isNotEmptyOrNull(orderTask.getTaskStatus().value())) {
			this.setTaskStatus(orderTask.getTaskStatus().value());
		}

		//Following has to be tested.
		if(orderTask.getPartners() !=null && orderTask.getPartners().getPartnerName() != null && !orderTask.getPartners().getPartnerName().isEmpty() && StringUtilities.isNotEmptyOrNull(orderTask.getPartners().getPartnerName().toString())) {
			StringBuffer buffer = new StringBuffer();
			boolean start = false;
			for (String partner : orderTask.getPartners().getPartnerName()) {
				if(start) {
					buffer.append(" + ");
				} else {
					start = true;
				}
				buffer.append(partner);
			}
			
			this.setOwner(buffer.toString());
			
		}
		
		if(orderTask.getLineCombination() != null &&  orderTask.getLineCombination().getLineCombo() != null && !orderTask.getLineCombination().getLineCombo().isEmpty()) {
			StringBuffer buffer = new StringBuffer();
			boolean start = false;
			for (String linecombo : orderTask.getLineCombination().getLineCombo()) {
				if(start) {
					buffer.append(" + ");
				} else {
					start = true;
				}
				buffer.append(linecombo);
			}
			
			this.setLineCombos(buffer.toString());
		}
		
		if(orderTask.getViews() != null && orderTask.getViews().getViewName() != null && !orderTask.getViews().getViewName().isEmpty() && StringUtilities.isNotEmptyOrNull(orderTask.getViews().getViewName().toString())) {
			this.setChannel(orderTask.getViews().getViewName().get(0));	
		}
		}catch(ParseException pe){
			throw new OCEException(pe.getMessage());
		}	   
	}

	public List<String> getOrgUnitList() {
		return orgUnitList;
	}

	public void setOrgUnitList(List<String> orgUnitList) {
		this.orgUnitList = orgUnitList;
	}

	public List<String> getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(List<String> partnerName) {
		this.partnerName = partnerName;
	}

	public List<String> getQueueTypes() {
		return queueTypes;
	}

	public void setQueueTypes(List<String> queueTypes) {
		this.queueTypes = queueTypes;
	}

	public String getQueueInputType() {
		return queueInputType;
	}

	public void setQueueInputType(String queueInputType) {
		this.queueInputType = queueInputType;
	}

	public boolean isWirelessFalloutOrder() {
		return isWirelessFalloutOrder;
	}

	public void setWirelessFalloutOrder(boolean isWirelessFalloutOrder) {
		this.isWirelessFalloutOrder = isWirelessFalloutOrder;
	}

	public boolean isGlobalVisible() {
		return isGlobalVisible;
	}

	public void setGlobalVisible(boolean isGlobalVisible) {
		this.isGlobalVisible = isGlobalVisible;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public List<String> getTaskStatusList() {
		return taskStatusList;
	}

	public void setTaskStatusList(List<String> taskStatusList) {
		this.taskStatusList = taskStatusList;
	}

	public String getSubStatus() {
		return subStatus;
	}

	public void setSubStatus(String subStatus) {
		this.subStatus = subStatus;
	}

	public String getQueueSubType() {
		return queueSubType;
	}

	public void setQueueSubType(String queueSubType) {
		this.queueSubType = queueSubType;
	}

	public String getCallbackPreference() {
		return callbackPreference;
	}

	public void setCallbackPreference(String callbackPreference) {
		this.callbackPreference = callbackPreference;
	}

	public String getQueueId() {
		return queueId;
	}

	public void setQueueId(String queueId) {
		this.queueId = queueId;
	}

	public String getRepComments() {
		return repComments;
	}

	public void setRepComments(String repComments) {
		this.repComments = repComments;
	}

}
