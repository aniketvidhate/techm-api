package com.att.oce.service.task.VO;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.att.oce.service.task.predicates.OrderQueueCountPredicate;
import com.att.oce.service.task.util.OrderTaskMaxDateComparator;
import com.att.oce.service.task.util.OrderTaskMinDateComparator;
import com.att.oce.service.task.util.TaskConstants;
import com.att.oce.service.task.util.TaskMaxDateComparator;
import com.att.oce.service.task.util.TaskMinDateComparator;

public class OrderCountStatusValue {
	
	private long slaGreen;
	private long slaAmber;
	private long slaRed; 
	
	private long slaRedMax;
	private long slaRedMin;
	private long slaGreenMax;
	private long slaGreenMin;
	private long slaAmberMax;
	private long slaAmberMin;
	
	private Set<BasicTaskDetailsVO> taskInfoCollection = new HashSet<BasicTaskDetailsVO>();
	private Set<String> orderRefCollection = new HashSet<String>();
	private Set<String> losgIdCollection = new HashSet<String>();
	
	/**
	 * @return the slaRedMax
	 */
	public long getSlaRedMax() {
		
		return slaRedMax;
		
		}

	/**
	 * @param slaRedMax the slaRedMax to set
	 */
	public void setSlaRedMax(long slaRedMax) {
		this.slaRedMax = slaRedMax;
	}

	/**
	 * @return the slaRedMin
	 */
	public long getSlaRedMin() {
	  
		 return slaRedMin;
	
	}

	/**
	 * @param slaRedMin the slaRedMin to set
	 */
	public void setSlaRedMin(long slaRedMin) {
		this.slaRedMin = slaRedMin;
	}

	/**
	 * @return the slaGreenMax
	 */
	public long getSlaGreenMax() {
	   
		return slaGreenMax;
	
	}

	/**
	 * @param slaGreenMax the slaGreenMax to set
	 */
	public void setSlaGreenMax(long slaGreenMax) {
		this.slaGreenMax = slaGreenMax;
	}

	/**
	 * @return the slaGreenMin
	 */
	public long getSlaGreenMin() {
		
		 return slaGreenMin;
		}

	/**
	 * @param slaGreenMin the slaGreenMin to set
	 */
	public void setSlaGreenMin(long slaGreenMin) {
		this.slaGreenMin = slaGreenMin;
	}

	/**
	 * @return the slaAmberMax
	 */
	public long getSlaAmberMax() {
		
	  return slaAmberMax;
	}

	/**
	 * @param slaAmberMax the slaAmberMax to set
	 */
	public void setSlaAmberMax(long slaAmberMax) {
		this.slaAmberMax = slaAmberMax;
	}

	/**
	 * @return the slaAmberMin
	 */
	public long getSlaAmberMin() {
		
		return slaAmberMin;
	}

	/**
	 * @param slaAmberMin the slaAmberMin to set
	 */
	public void setSlaAmberMin(long slaAmberMin) {
		this.slaAmberMin = slaAmberMin;
	}


	/**
	 * @return the orderRef
	 */
	public Set<String> getOrderRefCollection() {
		return orderRefCollection;
	}
	
	/**
	 * @param orderRef the orderRef to set
	 */
	public void setOrderRefCollection(Collection<String> pOrderRefCollection) {
		this.orderRefCollection.addAll(pOrderRefCollection);
	}
	
	public void setOrderRef(String pOrderRef) {
		this.orderRefCollection.add(pOrderRef);
	}
	
	public void removeOrderRefs(Collection<String> pOrderRefs) {
		this.losgIdCollection.removeAll(pOrderRefs);
	}
	
	public void removeOrderRef(String pOrderRef) {
		this.losgIdCollection.remove(pOrderRef);
	}
	
	/**
	 * @return the losgId
	 */
	public Set<String> getLosgIdCollection() {
		return losgIdCollection;
	}
	/**
	 * @param losgId the losgId to set
	 */
	public void setLosgIdCollection(Collection<String> pLosgId) {
		this.losgIdCollection.addAll(pLosgId);
	}
	
	public void removeLosgIds(Collection<String> plosgIds) {
		this.losgIdCollection.removeAll(plosgIds);
	}
	
	public OrderCountStatusValue() {
	}
	
	public Date getMinAccDate() {
		Date retVal = null;
		SortedSet<BasicTaskDetailsVO> t = new TreeSet<BasicTaskDetailsVO>(new OrderTaskMinDateComparator());
		t.addAll(this.taskInfoCollection);
		for (BasicTaskDetailsVO itr : t) {
			if (itr.getTaskStatus().equals(TaskConstants.NEW) || itr.getTaskStatus().equals(TaskConstants.UNCLAIMED)) {
				retVal = itr.getOrderAcceptedDate();
			}
		}
		return retVal;
	}
	
	
	public Date getMaxAccdate() {
		Date retVal = null;
		SortedSet<BasicTaskDetailsVO> t = new TreeSet<BasicTaskDetailsVO>(new OrderTaskMaxDateComparator());
		t.addAll(this.taskInfoCollection);
		for (BasicTaskDetailsVO itr : t) {
			if (itr.getTaskStatus().equals(TaskConstants.NEW) || itr.getTaskStatus().equals(TaskConstants.UNCLAIMED)) {
				retVal = itr.getOrderAcceptedDate();
			}
		}
		return retVal;
	}
	
	
	public Date getMinAccFalloutDate() {
		Date retVal = null;
		SortedSet<BasicTaskDetailsVO> t = new TreeSet<BasicTaskDetailsVO>(new TaskMinDateComparator());
		t.addAll(this.taskInfoCollection);
		for (BasicTaskDetailsVO itr : t) {
			if (itr.getTaskStatus().equals(TaskConstants.NEW) || itr.getTaskStatus().equals(TaskConstants.UNCLAIMED)) {
				retVal = itr.getTaskCreationDate();
			}
		}
		return retVal;
	}
	
	
	public Date getMaxAccFaloutDate() {
		Date retVal = null;
		SortedSet<BasicTaskDetailsVO> t = new TreeSet<BasicTaskDetailsVO>(new TaskMaxDateComparator());
		t.addAll(this.taskInfoCollection);
		for (BasicTaskDetailsVO itr : t) {
			if (itr.getTaskStatus().equals(TaskConstants.NEW) || itr.getTaskStatus().equals(TaskConstants.UNCLAIMED)) {
				retVal = itr.getTaskCreationDate();
			}
		}
		return retVal;
	}
  
	
	public long getRecordCount() {
		return this.getOrderRefCollection().size();
	}

	public long getLineCount() {
		return this.getLosgIdCollection().size();
	}
	
	public long getSlaGreen() {
		
		OrderQueueCountPredicate pre = null;
		List<BasicTaskDetailsVO> slaQueryResult = null;
		List<BasicTaskDetailsVO> basictaskvoList = new ArrayList<BasicTaskDetailsVO>(
				taskInfoCollection);
		//slaQueryResult =(List<BasicTaskDetailsVO>) pre.getSLAQuery(basictaskvoList,pre.getSLA(this.slaAmberMax, this.slaAmberMin));
		slaQueryResult =(List<BasicTaskDetailsVO>) pre.getSLAQuery(basictaskvoList,this.slaGreenMax, this.slaGreenMin,TaskConstants.SLA_GREEN);

		if (slaQueryResult != null) {
			return slaQueryResult.size();
		} else {
			return 0;
		}
	}
	
	public void setSlaGreen(long slaGreen) {
		this.slaGreen = slaGreen;
	}
	
	public long getSlaAmber() {
		
		OrderQueueCountPredicate pre = new OrderQueueCountPredicate();
		//OrderQueueCountPredicate pre = null;
		List<BasicTaskDetailsVO> slaQueryResult = null;
		List<BasicTaskDetailsVO> basictaskvoList = new ArrayList<BasicTaskDetailsVO>(
				taskInfoCollection);
		//slaQueryResult = (List<BasicTaskDetailsVO>)pre.getSLAQuery(basictaskvoList,pre.getSLA(this.slaAmberMax, this.slaAmberMin));
		slaQueryResult =(List<BasicTaskDetailsVO>) pre.getSLAQuery(basictaskvoList,this.slaAmberMax, this.slaAmberMin,TaskConstants.SLA_AMBER);

		if (slaQueryResult != null) {
			return slaQueryResult.size();
		} else {
			return 0;
		}

	}
	
	public void setSlaAmber(long slaAmber) {
		this.slaAmber = slaAmber;
	}
	
	public long getSlaRed() {
		
		OrderQueueCountPredicate pre = null;
		List<BasicTaskDetailsVO> slaQueryResult = null;
		List<BasicTaskDetailsVO> basictaskvoList = new ArrayList<BasicTaskDetailsVO>(
				taskInfoCollection);
		//slaQueryResult =(List<BasicTaskDetailsVO>) pre.getSLAQuery(basictaskvoList,pre.getSLA(this.slaAmberMax, this.slaAmberMin));
		slaQueryResult =(List<BasicTaskDetailsVO>) pre.getSLAQuery(basictaskvoList,this.slaRedMax, this.slaRedMin,TaskConstants.SLA_RED);
		
		//Iterate and count total losgi id for predicate return for actual sla count values
		long totalCount =0;
		if(slaQueryResult != null){
			for(BasicTaskDetailsVO vo :slaQueryResult ){
				totalCount = totalCount + vo.getTaskLineCount();
			}
		}
		

		
		//if (slaQueryResult != null) {
		//	return slaQueryResult.size();
		//} else {
			return totalCount;
		//}
	}
	
	public void setSlaRed(long slaRed) {
		this.slaRed = slaRed;
	}

	@Override
	public String toString() {
		return "OrderCountStatusValue [minAccDate=" + this.getMinAccDate()
				+ ", maxAccdate=" + this.getMaxAccdate() + ", minAccFalloutDate="
				+ this.getMinAccFalloutDate() + ", maxAccFaloutDate=" + this.getMinAccFalloutDate()
				+ ", recordCount=" + this.orderRefCollection.size() + ", lineCount=" + this.losgIdCollection.size()
				+ ", slaGreen=" + slaGreen + ", slaAmber=" + slaAmber
				+ ", slaRed=" + slaRed + "]";
	}

	/**
	 * @return the taskInfoCollection
	 */
	public Set<BasicTaskDetailsVO> getTaskInfoCollection() {
		return taskInfoCollection;
	}

	/**
	 * @param taskInfoCollection the taskInfoCollection to set
	 */
	public void setTaskInfoCollection(Set<BasicTaskDetailsVO> taskInfoCollection) {
		this.taskInfoCollection = taskInfoCollection;
	}
	
	public void setTaskInfo(TaskDetailsVO taskInfo) {
		BasicTaskDetailsVO vo = new BasicTaskDetailsVO(taskInfo);
		this.taskInfoCollection.add(vo);
	}
	
	public void removeTaskInfo(TaskDetailsVO taskInfo) {
		BasicTaskDetailsVO vo = new BasicTaskDetailsVO(taskInfo);
		this.taskInfoCollection.remove(vo);
	}
}