package com.att.oce.service.task.BeanImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.oce.service.DateUtil;
import com.att.oce.service.queue.QueueService;
import com.att.oce.service.queue.vo.OceQueueProgramSlaVO;
import com.att.oce.service.task.Bean.OrderCountStatusBean;
import com.att.oce.service.task.Bean.request.ProgramCountRequest;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.OrderCountStatusKey;
import com.att.oce.service.task.VO.OrderCountStatusTaskInfoMapValue;
import com.att.oce.service.task.VO.OrderCountStatusValue;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.predicates.OrderQueueCountPredicate;
import com.att.oce.service.task.util.StringUtilities;
import com.att.oce.service.task.util.TaskConstants;
import com.att.ooce.core.CtFallout;
import com.att.ooce.core.CtFallout.Fallout;
import com.att.ooce.core.CtFallout.Fallout.Age;
import com.att.ooce.core.CtFallout.Fallout.Count;
import com.att.ooce.core.CtFallout.Fallout.FalloutAge;
import com.att.ooce.core.CtFallout.Fallout.Sla;
import com.att.ooce.core.OrderQueueResponse;

/**
 * The Class OrderCountStatusBeanImpl.
 */
@Component
public class OrderCountStatusBeanImpl extends AbstractTaskBeanImpl implements OrderCountStatusBean {

	/** The logger. */
	private Logger logger = LoggerFactory.getLogger(OrderCountStatusBeanImpl.class);
 
	
	/** The order count map. */
	Map<OrderCountStatusKey, OrderCountStatusValue> orderCountMap = new ConcurrentHashMap<OrderCountStatusKey, OrderCountStatusValue>();
	
	/** The task id key info map. */
	Map<String, OrderCountStatusTaskInfoMapValue> taskIdKeyInfoMap = new HashMap<String, OrderCountStatusTaskInfoMapValue>();
	
	
	@Autowired
	QueueService queuedb;
	
	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.BasicTaskBean#createTasks(java.util.List)
	 */
	@Override
	public void createTasks(List<TaskDetailsVO> tasks) throws OCEException {

		logger.info("create Tasks is called");
		this.poppulateLocalCache(tasks);
		logger.info("create Tasks is ended");
		
	}

	/**
	 * Gets the losg ids.
	 *
	 * @param losgId the losg id
	 * @return the losg ids
	 */
	private String[] getLosgIds(String losgId) {
	
		String[] items = null;
		if (StringUtilities.isNotEmptyOrNull(losgId)) {
			items = losgId.split(",");
		}
		return items;
	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.BasicTaskBean#updateTasks(java.util.List)
	 */
	@Override
	public void updateTasks(List<TaskDetailsVO> tasks) throws OCEException {

		logger.info(" OrderCountStatus updateTasks Tasks is called");
		this.poppulateLocalCache(tasks);
		/*OrderQueueCountPredicate pre = null;
		logger.info(" OrderCountStatusBeanImpl updateTasks is called for key " + taskDetailsVOList);
		List<TaskDetailsVO> taskDetailsList = (List<TaskDetailsVO>) pre.populateTaskItem(taskDetailsVOList,pre.getTaskItem(taskId));*/
	 	logger.info(" OrderCountStatus updateTasks Tasks is Ended");
	}
	
	/**
	 * Poppulate local cache.
	 *
	 * @param tasks the tasks
	 * @throws OCEException the OCE exception
	 */
	private void poppulateLocalCache(List<TaskDetailsVO> tasks) throws OCEException{
		logger.info(" OrderCountStatus poppulateLocalCache started");
		if (tasks == null || tasks.isEmpty()) {
			// Ideally, we need to throw an exception, Lets see..
			logger.error("update event is called with null object");
			return;
		}
		try {
			synchronized (this) {
				for (TaskDetailsVO task : tasks) {
					logger.trace("Order Count Status request is made for the task"+ task);
					OrderCountStatusKey existingOrderCntStssKey = null;
					OrderCountStatusKey orderCntStssKey = new OrderCountStatusKey(task);
					OrderCountStatusValue orderCntStatusValue = null;
					if(taskIdKeyInfoMap.containsKey(task.getTaskId())) {
						existingOrderCntStssKey = (taskIdKeyInfoMap.get(task.getTaskId())).getKey();
						if(existingOrderCntStssKey.equals(orderCntStssKey)) {
							logger.trace("Order Countstatus is not updating Task, : " + task + "   -  because this task is already counted");
							return;
						} else {
							orderCntStatusValue = orderCountMap.get(existingOrderCntStssKey);
							orderCntStatusValue.removeLosgIds(Arrays.asList(getLosgIds(task.getLosgId())));
							orderCntStatusValue.removeTaskInfo(task);
							if(StringUtilities.isNotEmptyOrNull(task.getOrderRef())){
								orderCntStatusValue.removeOrderRef(task.getOrderRef());
							}
							taskIdKeyInfoMap.remove(task.getTaskId());
							orderCountMap.put(existingOrderCntStssKey, orderCntStatusValue);
							orderCntStatusValue = null;
						}
					} 
					taskIdKeyInfoMap.put(task.getTaskId(), new OrderCountStatusTaskInfoMapValue(task));
					if (orderCountMap.containsKey(orderCntStssKey)) {
						orderCntStatusValue = orderCountMap.get(orderCntStssKey);
					} else {
						orderCntStatusValue = new OrderCountStatusValue();
					}
					orderCntStatusValue.setTaskInfo(task);
					orderCntStatusValue.setLosgIdCollection(Arrays.asList(getLosgIds(task.getLosgId())));
					if(StringUtilities.isNotEmptyOrNull(task.getOrderRef())){
						orderCntStatusValue.setOrderRef(task.getOrderRef());
					}
					
					List<OceQueueProgramSlaVO> sqlDetailList = queuedb.getSLADetails(orderCntStssKey.getProgramName(),orderCntStssKey.getQueueType(),orderCntStssKey.getChannel() );
					
					if(sqlDetailList != null || !sqlDetailList.isEmpty()) {
						OceQueueProgramSlaVO  programSla = sqlDetailList.get(0);
						
						orderCntStatusValue.setSlaRedMax(programSla.getSlaRedMax());
						orderCntStatusValue.setSlaRedMin(programSla.getSlaRedMin());
						orderCntStatusValue.setSlaAmberMax(programSla.getSlaAmberMax());
						orderCntStatusValue.setSlaAmberMin(programSla.getSlaAmberMin());
						orderCntStatusValue.setSlaGreenMax(programSla.getSlaGreenMax());
						orderCntStatusValue.setSlaGreenMin(programSla.getSlaGreenMin());
					}
			
					orderCountMap.put(orderCntStssKey, orderCntStatusValue);
					logger.trace("Order Countstatus is updated : " + task);
				}
			}
		} catch (Exception e) {
			throw new OCEException(e);
		}
		logger.info(" OrderCountStatus poppulateLocalCache Ended");
	}
		
	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.BasicTaskBean#initialize(java.util.List)
	 */
	@Override
	public void initialize(List<TaskDetailsVO> taskDetailsList) throws OCEException {
		logger.info(" OrderCountStatusBeanImpl initialization Started");
		createTasks(taskDetailsList);
		logger.info(" OrderCountStatusBeanImpl initialization Completed");
	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.OrderCountStatusBean#getProgramCount(java.util.List, com.att.oce.service.task.Bean.request.ProgramCountRequest)
	 */
	@Override
	public List<Fallout> getProgramCount(ProgramCountRequest programCountRequest) {
		OrderQueueCountPredicate pre = null;
		List<OrderCountStatusKey> countQueryResult = null;
		logger.info(" OrderCountStatusBeanImpl getProgramCount is called for key " + this.orderCountMap.keySet());  
		if(null != programCountRequest.getQueueInputType() &&  programCountRequest.getQueueInputType().contains(TaskConstants.OUTBOUND)){
			countQueryResult = (List<OrderCountStatusKey>) pre.getOrderCountBasedOnQueueOrProgramOrPreference(this.orderCountMap.keySet(),pre.isQueueOrProgramOrPreference(programCountRequest));
		} else {
			countQueryResult = (List<OrderCountStatusKey>) pre.getOrderCountBasedOnQueueOrProgram(this.orderCountMap.keySet(),pre.isQueueOrProgram(programCountRequest));
		}
		List<Fallout> retVal = updateFalloutList(countQueryResult);
		logger.trace("The return value is :" + retVal);
		return retVal;
	}
	
	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.OrderCountStatusBean#getQueueItemsByChannel(java.util.List, java.lang.String, java.util.List, java.util.List, boolean, java.lang.String, boolean)
	 */
	@SuppressWarnings({ "static-access", "unchecked" })
	@Override
	public List<Fallout> getQueueItemsByChannel(ProgramCountRequest programCountRequest){
		OrderQueueCountPredicate pre = null;
		List<OrderCountStatusKey> countQueryResult = null;
		logger.info(" OrderCountStatusBeanImpl getQueueCountByChannel is called for key ");
     	countQueryResult = (List<OrderCountStatusKey>) pre.getQueueCountByChannelQuery(this.orderCountMap.keySet(),pre.getCountOnChannel(programCountRequest));
     	List<Fallout> retVal = updateFalloutList(countQueryResult);
		logger.trace("The return value is :" + retVal);
		return retVal;
	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.OrderCountStatusBean#getOutBoundItemsByChannel(java.util.List, java.lang.String, java.util.List, java.util.List)
	 */
	@Override
	public List<Fallout> getOutBoundItemsByChannel(ProgramCountRequest programCountRequest) {
		OrderQueueCountPredicate pre = null;
		List<OrderCountStatusKey> countQueryResult = null;
		logger.info(" OrderCountStatusBeanImpl getQueueCountByChannel is called for key ");
		countQueryResult = (List<OrderCountStatusKey>) pre.getQueueCountByChannelQuery(this.orderCountMap.keySet(),pre.getCountOnOutbound(programCountRequest));
		List<Fallout> retVal = updateFalloutList(countQueryResult);
		logger.trace("The return value is :" + retVal);
		return retVal;
	}

	/**
	 * Gets the age.
	 *
	 * @param orderCntStatusValue the order cnt status value
	 * @return the age
	 */
	private Age getAge(OrderCountStatusValue orderCntStatusValue){
		Age age = new Age();
		if (null != orderCntStatusValue.getMinAccDate()) {
			Date dateValue = orderCntStatusValue.getMinAccDate();
			age.setOldest(DateUtil.getXMLGregorianCalendarValue(dateValue));
		}
		if (null != orderCntStatusValue.getMaxAccdate()) {
			Date dateMaxValue = orderCntStatusValue.getMaxAccdate();
			age.setNewest(DateUtil.getXMLGregorianCalendarValue(dateMaxValue));
		}
		return age;
	}
	
	/**
	 * Gets the fallout age.
	 *
	 * @param orderCntStatusValue the order cnt status value
	 * @return the fallout age
	 */
	private FalloutAge getFalloutAge(OrderCountStatusValue orderCntStatusValue){
		FalloutAge falloutAge = new FalloutAge();
		if (null != orderCntStatusValue.getMinAccFalloutDate()) {
			Date dateValueMinAccFalloutDate = (Date) orderCntStatusValue.getMinAccFalloutDate();
			falloutAge.setOldest(DateUtil.getXMLGregorianCalendarValue(dateValueMinAccFalloutDate));
		}
		if (null != orderCntStatusValue.getMaxAccFaloutDate()) {
			Date dateValueMax = orderCntStatusValue.getMaxAccFaloutDate();
			falloutAge.setNewest(DateUtil.getXMLGregorianCalendarValue(dateValueMax));
		}
		return falloutAge;
	}
	/**
	 * Update fallout list.
	 *
	 * @param countQueryResult the count query result
	 * @return the list
	 */
	public List<Fallout> updateFalloutList(List<OrderCountStatusKey> countQueryResult){
		Sla sla = new Sla();	
	 	List<Fallout> retVal = new ArrayList<Fallout>();
		Fallout fallout = new Fallout();
		String queueType="";
		String callRef="";
		String queueCat="";	
		String actionType="";
		String lineCombo="";
		String lineAction="";
		String programName= "";
		int lineCount;
		int recordCount;
		int slaGreen = 0;
		int slaAmber = 0;
		int slaRed = 0;
		Count count = new Count();
		for (OrderCountStatusKey countQueryResultMap : countQueryResult) {
			OrderCountStatusValue orderCntStatusValue = orderCountMap.get(countQueryResultMap);
			if(null!= countQueryResultMap.getQueueType())
			{
				queueType = countQueryResultMap.getQueueType();
			}
			fallout.setQueueName(queueType);
			callRef = countQueryResultMap.getCallbackPreference();
			fallout.setCallbackPreference(callRef);
			queueCat = countQueryResultMap.getQueueCategory();
			fallout.setCallbackPreference(queueCat);
			actionType = countQueryResultMap.getActionType();
			fallout.setCallbackPreference(actionType);
			lineCombo = countQueryResultMap.getLinecombos();
			fallout.setCallbackPreference(lineCombo);
			lineAction = countQueryResultMap.getLineAction();
			fallout.setCallbackPreference(lineAction);
			programName = countQueryResultMap.getProgramName();
			fallout.setCallbackPreference(programName);
			//priority = orderCntStatusValue.getPriority();
			lineCount =  (int) orderCntStatusValue.getLineCount();
			recordCount = (int) orderCntStatusValue.getRecordCount();
			count.setLineCount(lineCount);
			count.setOrderCount(recordCount);
			fallout.setCount(count);
			if (lineCount > 0) {
				slaGreen =(int) (orderCntStatusValue.getSlaGreen() * 100 / lineCount);
				
			}
			if (lineCount > 0) {
				slaAmber = (int) (orderCntStatusValue.getSlaAmber() * 100 / lineCount);
			}
			if (lineCount > 0) {
				slaRed = (int) (orderCntStatusValue.getSlaRed() * 100 / lineCount);
			}
			sla.setAmberValue(slaAmber);
			sla.setGreenValue(slaGreen);
			sla.setRedValue(slaRed);
			fallout.setSla(sla);
			fallout.setAge(getAge(orderCntStatusValue));
			fallout.setFalloutAge(getFalloutAge(orderCntStatusValue));
			retVal.add(fallout);
			
			}
		return retVal;
	}
	
	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.OrderCountStatusBean#getTotalOrderCount()
	 */
	@Override
	public Long getTotalOrderCount(ProgramCountRequest programCountRequest,boolean isWirelessFalloutOrder) {
		OrderQueueCountPredicate pre = null;
		List<OrderCountStatusKey> countQueryResult = (List<OrderCountStatusKey>) pre.getTotalOrderCount(this.orderCountMap.keySet(),pre.isTotalOrder(programCountRequest));
     	return Long.valueOf(countQueryResult.size());
	}

	/**
	 * Gets the total order count with fallout lists.
	 *
	 * @param programCountRequest the program count request
	 * @return the order queue response
	 */
	@Override
	public OrderQueueResponse fetchOrderQueueCount(ProgramCountRequest programCountRequest) {
		OrderQueueResponse orderQueueResponse =new OrderQueueResponse();
		CtFallout ctFallout=new CtFallout();
		List<Fallout> falloutList = new ArrayList<Fallout>();
		ctFallout.getFallout().addAll(getProgramCount(programCountRequest));
		ctFallout.getFallout().addAll(getQueueItemsByChannel(programCountRequest));
		ctFallout.getFallout().addAll(getOutBoundItemsByChannel(programCountRequest));
		orderQueueResponse.setFalloutDetail(ctFallout);
		falloutList=ctFallout.getFallout();
		int totalOutboundCount = 0; 
		boolean isWirelessFalloutOrder = false;
		if(programCountRequest.getOrgUnitList().contains(TaskConstants.DE_MOBILITY)){
			isWirelessFalloutOrder = true;
		}
		if(null != falloutList) {
			for(Fallout fallout : falloutList) {
				totalOutboundCount = totalOutboundCount + fallout.getCount().getOrderCount();
			}
		}
		Long totalOrderCount = null;
		if(null != programCountRequest.getQueueInputType() && programCountRequest.getQueueInputType().contains(TaskConstants.OUTBOUND)) {
			totalOrderCount=(long) totalOutboundCount;
		} else {
			totalOrderCount=getTotalOrderCount(programCountRequest, isWirelessFalloutOrder);	
		}		
		orderQueueResponse.setTotalCount((int) (long)totalOrderCount );
		return orderQueueResponse;
	}
	
}