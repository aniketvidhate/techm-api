package com.att.oce.service.task.predicates;

public class TestPredicate {

}