package com.att.oce.task.hibernate.orm;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "OCE_TASK_DETAILS")
public class OCETaskDetails {

	@Id
	@Column(name = "task_id")
	private String mTaskId;

	@Column(name = "creation_date")
	private Date mCreationDate;

	@Column(name = "order_ref")
	private String mOrderRef;

	@Column(name = "task_status")
	private String mTaskStatus;

	@Column(name = "task_sub_status")
	private String mTaskSubStatus;

	@Column(name = "channel")
	private String mChannel;

	@Column(name = "owner")
	private String mOwner;

	@Column(name = "callback_preference")
	private String mCallbackPreference;

	@Column(name = "wireless_fallout")
	private int mWirelessFallout;

	@Column(name = "request_type")
	private String mRequestType;

	@Column(name = "action_type")
	private String mActionType;

	@Column(name = "losg_ids")
	private String mLosgId;

	@Column(name = "TASK_RETRY_ATTEMPT")
	private int mTaskRetryAttempt;

	@Column(name = "Linecombos")
	private String mLineCombos;

	@Column(name = "Line_action")
	private String mLineAction;

	@Column(name = "Program_name")
	private String programName;

	@Column(name = "Queue_type")
	private String mQueueType;

	@Column(name = "CSR_ID")
	private String mCsrId;

	@Column(name = "AVOS_REF_TASK_ID")
	private String mAvos_task_id;

	@Column(name = "CREATED_BY")
	private String mCreated_by;

	@Column(name = "CHILD_ORDER_NUMBER")
	private String mChild_order_ref;

	@Column(name = "LAST_MODIFIED_BY")
	private String mLast_modified_by;

	@Column(name = "LAST_MODIFIED_DATE")
	private Date mLast_modified_date;

	@Column(name = "FALLOUT_END_DATE")
	private Date mFallout_end_date;

	@Column(name = "COMMUNICATION_STATUS")
	private String mCommunication_status;

	@Column(name = "LAST_COMMUNICATION_TIMESTAMP")
	private String mLast_Communication_timestamp;

	@Column(name = "VERSION")
	private String mVersion;

	@Column(name = "APPLICATION_NAME")
	private String mApplicationName;

	@Column(name = "QUEUE_PRIORITY_VALUE")
	private String mQueue_Priority_value;

	@OneToMany
	@JoinColumn(name = "task_id")
	private Set<OCEQueueDetails> mQueueDetails = new HashSet<OCEQueueDetails>();

	public int getTaskRetryAttempt() {
		return mTaskRetryAttempt;
	}

	public void setTaskRetryAttempt(int mTaskRetryAttempt) {
		this.mTaskRetryAttempt = mTaskRetryAttempt;
	}

	public String getLosgId() {
		return mLosgId;
	}

	public void setLosgId(String mLosgId) {
		this.mLosgId = mLosgId;
	}

	public String getOrderRef() {
		return mOrderRef;
	}

	public void setOrderRef(String pOrderRef) {
		this.mOrderRef = pOrderRef;
	}

	public String getTaskStatus() {
		return mTaskStatus;
	}

	public void setTaskStatus(String pTaskStatus) {
		this.mTaskStatus = pTaskStatus;
	}

	public String getTaskSubStatus() {
		return mTaskSubStatus;
	}

	public void setTaskSubStatus(String pTaskSubStatus) {
		this.mTaskSubStatus = pTaskSubStatus;
	}

	public String getChannel() {
		return mChannel;
	}

	public void setChannel(String pChannel) {
		this.mChannel = pChannel;
	}

	public String getOwner() {
		return mOwner;
	}

	public void setOwner(String pOwner) {
		this.mOwner = pOwner;
	}

	public String getTaskId() {
		return mTaskId;
	}

	public void setTaskId(String pTaskId) {
		this.mTaskId = pTaskId;
	}

	public Date getCreationDate() {
		return mCreationDate;
	}

	public void setCreationDate(Date pCreationDate) {
		this.mCreationDate = pCreationDate;
	}

	@Override
	public String toString() {
		return "TaskDetails [TaskId=" + mTaskId + ", CreationDate=" + mCreationDate + ", OrderRef=" + mOrderRef
				+ ", TaskStatus=" + mTaskStatus + ", TaskSubStatus=" + mTaskSubStatus + ", Channel=" + mChannel
				+ ", Owner=" + mOwner + "]";
	}

	public Set<OCEQueueDetails> getQueueDetails() {
		return mQueueDetails;
	}

	public void setQueueDetails(Set<OCEQueueDetails> mQueueDetails) {
		this.mQueueDetails = mQueueDetails;
	}

	public String getCallbackPreference() {
		return mCallbackPreference;
	}

	public void setCallbackPreference(String callbackPreference) {
		this.mCallbackPreference = callbackPreference;
	}

	public int getWirelessFallout() {
		return mWirelessFallout;
	}

	public void setWirelessFallout(int mWirelessFallout) {
		this.mWirelessFallout = mWirelessFallout;
	}

	public String getRequestType() {
		return mRequestType;
	}

	public void setmRequestType(String mRequestType) {
		this.mRequestType = mRequestType;
	}

	public String getActionType() {
		return mActionType;
	}

	public void setActionType(String mActionType) {
		this.mActionType = mActionType;
	}

	public String getCsrId() {
		return mCsrId;
	}

	public void setCsrId(String mCsrId) {
		this.mCsrId = mCsrId;
	}

	public String getAvos_task_id() {
		return mAvos_task_id;
	}

	public void setAvos_task_id(String mAvos_task_id) {
		this.mAvos_task_id = mAvos_task_id;
	}

	public String getCreated_by() {
		return mCreated_by;
	}

	public void setCreated_by(String mCreated_by) {
		this.mCreated_by = mCreated_by;
	}

	public String getChild_order_ref() {
		return mChild_order_ref;
	}

	public void setChild_order_ref(String mChild_order_ref) {
		this.mChild_order_ref = mChild_order_ref;
	}

	public String getLast_modified_by() {
		return mLast_modified_by;
	}

	public void setLast_modified_by(String mLast_modified_by) {
		this.mLast_modified_by = mLast_modified_by;
	}

	public Date getLast_modified_date() {
		return mLast_modified_date;
	}

	public void setLast_modified_date(Date mLast_modified_date) {
		this.mLast_modified_date = mLast_modified_date;
	}

	public Date getFallout_end_date() {
		return mFallout_end_date;
	}

	public void setFallout_end_date(Date mFallout_end_date) {
		this.mFallout_end_date = mFallout_end_date;
	}

	public String getCommunication_status() {
		return mCommunication_status;
	}

	public void setCommunication_status(String mCommunication_status) {
		this.mCommunication_status = mCommunication_status;
	}

	public String getLast_Communication_timestamp() {
		return mLast_Communication_timestamp;
	}

	public void setLast_Communication_timestamp(String mLast_Communication_timestamp) {
		this.mLast_Communication_timestamp = mLast_Communication_timestamp;
	}

	public String getVersion() {
		return mVersion;
	}

	public void setVersion(String mVersion) {
		this.mVersion = mVersion;
	}

	public String getApplicationName() {
		return mApplicationName;
	}

	public void setApplicationName(String mApplicationName) {
		this.mApplicationName = mApplicationName;
	}

	public String getQueue_Priority_value() {
		return mQueue_Priority_value;
	}

	public void setQueue_Priority_value(String mQueue_Priority_value) {
		this.mQueue_Priority_value = mQueue_Priority_value;
	}

	/**
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}

	/**
	 * @param programName the programName to set
	 */
	public void setProgramName(String programName) {
		this.programName = programName;
	}

	

}
