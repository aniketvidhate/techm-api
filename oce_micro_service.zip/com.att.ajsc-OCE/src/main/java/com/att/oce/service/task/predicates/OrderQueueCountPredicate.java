package com.att.oce.service.task.predicates;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.att.oce.service.DateUtil;
import com.att.oce.service.task.Bean.request.ProgramCountRequest;
import com.att.oce.service.task.VO.BasicTaskDetailsVO;
import com.att.oce.service.task.VO.OrderCountStatusKey;
import com.att.oce.service.task.VO.OrderCountStatusValue;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.TaskConstants;

/**
 * The Class OrderQueueCountPredicate.
 */
public class OrderQueueCountPredicate {
	
	/** The order count map. */
	Map<OrderCountStatusKey, OrderCountStatusValue> orderCountMap = new ConcurrentHashMap<OrderCountStatusKey, OrderCountStatusValue>();
	
	/**
	 * Gets the count on channel.
	 *
	 * @param channel the channel
	 * @return the count on channel
	 */
	public static Predicate<OrderCountStatusKey> getCountOnChannel(ProgramCountRequest programCountRequest){
        Predicate<OrderCountStatusKey> predicate = null;
		    if (programCountRequest.isGlobalVisible()){
		                    predicate = p ->   p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
		                                                  && p.getRequestType().equalsIgnoreCase(programCountRequest.getRequestType())
		                                                    && p.getPartnerName().contains(programCountRequest.getPartnerList())         
		                                                    && p.getQueueTypes().contains(programCountRequest.getQueueTypeList());
		                    //&& p.getWirelessFallout().equals(programCountRequest.getWirelessFallout());           
		    }
		    else{
		    if (null != programCountRequest.getPartnerList() && programCountRequest.getPartnerList().size() > 0){
		                    predicate = p -> p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
		                                                    && p.getRequestType().equalsIgnoreCase(programCountRequest.getRequestType())
		                                                    && p.getPartnerName().contains(programCountRequest.getPartnerList());
		                                                    //&& p.getWirelessFallout().equals(programCountRequest.getWirelessFallout());
		    }
		    }
	    return predicate;
	}
	
	/**
	 * Gets the count on outbound.
	 *
	 * @param view the view
	 * @param partnerName the partner name
	 * @param queueTypes the queue types
	 * @return the count on outbound
	 */
	public static Predicate<OrderCountStatusKey> getCountOnOutbound(ProgramCountRequest programCountRequest){
		 Predicate<OrderCountStatusKey> predicate = null;
         if (null != programCountRequest.getPartnerList() && programCountRequest.getPartnerList().size() > 0){
                         predicate = p -> p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
                                                         && p.getPartnerName().contains(programCountRequest.getPartnerList())
                                                         && (p.getCallbackPreference().equalsIgnoreCase("SECOND_CALL_QUEUE")
                                                                                         || p.getCallbackPreference().equalsIgnoreCase("FIRST_CALL_QUEUE"));
         }
         return predicate;
	}
	
	/**
	 * Gets the queue count by channel query.
	 *
	 * @param ordCntKey the ord cnt key
	 * @param predicate the predicate
	 * @return the queue count by channel query
	 */
	public static Collection<OrderCountStatusKey> getQueueCountByChannelQuery (Collection<OrderCountStatusKey> ordCntKey, Predicate<OrderCountStatusKey> predicate) {

		return ordCntKey.stream().filter( predicate ).collect(Collectors.<OrderCountStatusKey>toList());
    }
	
	/**
	 * Checks if is queue or program or preference.
	 *
	 * @param programCountRequest the program count request
	 * @return the predicate
	 */
	public static Predicate<OrderCountStatusKey> isQueueOrProgramOrPreference(ProgramCountRequest programCountRequest){
		Predicate<OrderCountStatusKey> predicate = null;
		if (programCountRequest.isGlobalVisible()){
			predicate =  p -> p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") && p.getSubStatus().equalsIgnoreCase("IN_QUEUE") && p.getOrgUnitList().contains(programCountRequest.getOrgUnitList());
		} else {
			if (null != programCountRequest.getPartnerList() && programCountRequest.getPartnerList().size() > 0){
				predicate =  p -> p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") 
							&& p.getSubStatus().equalsIgnoreCase("IN_QUEUE") 
							&& p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
							&& p.getQueueTypes().contains(programCountRequest.getQueueTypeList()) 
							&& p.getPartnerName().contains(programCountRequest.getPartnerList());
			} else {
				predicate =  p -> p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") 
							&& p.getSubStatus().equalsIgnoreCase("IN_QUEUE") 
							&& p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
							&& p.getQueueTypes().contains(programCountRequest.getQueueTypeList());
			}
		}
		return predicate;
	}
	
	/**
	 * Checks if is queue or program.
	 *
	 * @param programCountRequest the program count request
	 * @return the predicate
	 */
	public static Predicate<OrderCountStatusKey> isQueueOrProgram(ProgramCountRequest programCountRequest){
		Predicate<OrderCountStatusKey> predicate = null;
		if (programCountRequest.isGlobalVisible()){
			predicate =  p -> p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") 
						&& p.getSubStatus().equalsIgnoreCase("IN_QUEUE") 
						&& p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
						&& p.getRequestType().equalsIgnoreCase(programCountRequest.getRequestType());
		} else {
			if (null != programCountRequest.getPartnerList() && programCountRequest.getPartnerList().size() > 0){
					predicate =  p -> p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") 
								&& p.getSubStatus().equalsIgnoreCase("IN_QUEUE") 
								&& p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
								&& p.getQueueTypes().contains(programCountRequest.getQueueTypeList()) 
								&& p.getPartnerName().contains(programCountRequest.getPartnerList())
								&& p.getRequestType().equalsIgnoreCase(programCountRequest.getRequestType());
		
			} else {
					predicate =  p -> p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") 
								&& p.getSubStatus().equalsIgnoreCase("IN_QUEUE") 
								&& p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
								&& p.getQueueTypes().contains(programCountRequest.getQueueTypeList()) 
								&& p.getRequestType().equalsIgnoreCase(programCountRequest.getRequestType());
			}
		}
		return predicate;
	}
	
	/**
	 * Checks if is total order.
	 *
	 * @param programCountRequest the program count request
	 * @return the predicate
	 */
	public static Predicate<OrderCountStatusKey> isTotalOrder(ProgramCountRequest programCountRequest){
		Predicate<OrderCountStatusKey> predicate = null;
		if (programCountRequest.isGlobalVisible()){
			predicate =  p -> p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") 
						&& p.getSubStatus().equalsIgnoreCase("IN_QUEUE") 
						&& p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
						&& p.getRequestType().equalsIgnoreCase(programCountRequest.getRequestType());
		} else {
			if (null != programCountRequest.getPartnerList() && programCountRequest.getPartnerList().size() > 0){
					predicate =  p -> p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") 
								&& p.getSubStatus().equalsIgnoreCase("IN_QUEUE") 
								&& p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
								&& p.getQueueTypes().contains(programCountRequest.getQueueTypeList()) 
								&& p.getPartnerName().contains(programCountRequest.getPartnerList())
								&& p.getRequestType().equalsIgnoreCase(programCountRequest.getRequestType());
		
			} else {
					predicate =  p -> p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") 
								&& p.getSubStatus().equalsIgnoreCase("IN_QUEUE") 
								&& p.getOrgUnitList().contains(programCountRequest.getOrgUnitList()) 
								&& p.getQueueTypes().contains(programCountRequest.getQueueTypeList()) 
								&& p.getRequestType().equalsIgnoreCase(programCountRequest.getRequestType());
			}
		}
		return predicate;
	}
	
	/**
	 * Gets the task item.
	 *
	 * @param taskId the task id
	 * @return the task item
	 */
	public static Predicate<TaskDetailsVO> getTaskItem(String taskId){
		return p -> p.getTaskId().equalsIgnoreCase(taskId) 
					&& p.getOrderRef().equalsIgnoreCase(taskId) 
					&& p.getTaskStatusList().contains("New") || p.getTaskStatusList().contains("UNCLAIMED") || p.getTaskStatusList().contains("IN_QUEUE") ;
	}
	
	/**
	 * Gets the total order count.
	 *
	 * @param ordCntKey the ord cnt key
	 * @param predicate the predicate
	 * @return the total order count
	 */
	public static Collection<OrderCountStatusKey> getTotalOrderCount (Collection<OrderCountStatusKey> ordCntKey, Predicate<OrderCountStatusKey> predicate) {

		return ordCntKey.stream().filter( predicate ).collect(Collectors.<OrderCountStatusKey>toList());
    }
	
	/**
	 * Populate task item.
	 *
	 * @param taskDetailsList the task details list
	 * @param predicate the predicate
	 * @return the collection
	 */
	public static Collection<TaskDetailsVO> populateTaskItem (Collection<TaskDetailsVO> taskDetailsList, Predicate<TaskDetailsVO> predicate) {

		return taskDetailsList.stream().filter( predicate ).collect(Collectors.<TaskDetailsVO>toList());
    }
	/**
	 * Gets the order count based on queue or program or preference.
	 *
	 * @param ordCntKey the ord cnt key
	 * @param predicate the predicate
	 * @return the order count based on queue or program or preference
	 */
	public static Collection<OrderCountStatusKey> getOrderCountBasedOnQueueOrProgramOrPreference (Collection<OrderCountStatusKey> ordCntKey, Predicate<OrderCountStatusKey> predicate) {

		return ordCntKey.stream().filter( predicate ).collect(Collectors.<OrderCountStatusKey>toList());
    }
	
	/**
	 * Gets the order count based on queue or program.
	 *
	 * @param ordCntKey the ord cnt key
	 * @param predicate the predicate
	 * @return the order count based on queue or program
	 */
	public static Collection<OrderCountStatusKey> getOrderCountBasedOnQueueOrProgram (Collection<OrderCountStatusKey> ordCntKey, Predicate<OrderCountStatusKey> predicate) {

		return ordCntKey.stream().filter( predicate ).collect(Collectors.<OrderCountStatusKey>toList());
    }
	
	
	/**
	 * Gets the sla.
	 *
	 * @param max the max
	 * @param min the min
	 * @return the sla
	 */
	public static Predicate<BasicTaskDetailsVO> getSLA(long max,long min){
	 
	   //Substract current date time with creation date and compare. Need to find how to substract current date time with
		//creation date in predicate
		return p -> p.getTaskCreationDate().getTime() > max && p.getTaskCreationDate().getTime() < min;
   }
	
	
	/**
	 * Gets the SLA query.
	 *
	 * @param vo the vo
	 * @param predicate the predicate
	 * @return the SLA query
	 */
/**	public static Collection<BasicTaskDetailsVO> getSLAQuery(List<BasicTaskDetailsVO> vo, Predicate<BasicTaskDetailsVO> predicate){
		return vo.stream().filter(predicate).collect(Collectors.<BasicTaskDetailsVO>toList());
	}*/
	
	
	/**
	 * Need to remove this method after resolving java8 issue. will use above  predicate methods.
	 * @param basictaskvoList
	 * @param slaAmberMax
	 * @param slaAmberMin
	 * @return
	 */
	public static List<BasicTaskDetailsVO>  getSLAQuery(
			List<BasicTaskDetailsVO> basictaskvoList, long slaMax, long slaMin,String slaFlag) {
		
		List<BasicTaskDetailsVO> filterList = new ArrayList();

		for (BasicTaskDetailsVO vo : basictaskvoList) {

			if (vo.getTaskStatus().equalsIgnoreCase(TaskConstants.NEW)
					|| vo.getTaskStatus().equalsIgnoreCase(
							TaskConstants.UNCLAIMED)) {
				long daydiff = (24 * 60 * (DateUtil.getDayDiff(vo.getTaskCreationDate(),DateUtil.getCurrentTimeAsGMT())));

				if (slaMax > daydiff && slaMin < daydiff) {

					filterList.add(vo);

				} else if (slaFlag.equalsIgnoreCase(TaskConstants.SLA_RED) && daydiff > slaMin) {

					filterList.add(vo);
				}
			}
			return filterList;
		
	 }
  }
}