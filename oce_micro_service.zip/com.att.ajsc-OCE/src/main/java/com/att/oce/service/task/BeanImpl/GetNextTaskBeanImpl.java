package com.att.oce.service.task.BeanImpl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.att.oce.dmn.engine.OCECamundaGetNextException;
import com.att.oce.dmn.engine.OCEGetNextTaskDecisionTable;
import com.att.oce.dmn.model.BinDecisionInputViewModel;
import com.att.oce.service.task.Bean.GetNextTaskBean;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.BasicTaskDetailsVO;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.TaskMinDateComparator;
import com.att.oce.service.task.util.TaskConstants;
import com.ibm.icu.util.Calendar;

@Component
public class GetNextTaskBeanImpl extends AbstractTaskBeanImpl implements GetNextTaskBean {

	private Logger logger = LoggerFactory.getLogger(GetNextTaskBeanImpl.class);

	Map<String, SortedSet<BasicTaskDetailsVO>> taskMap = new ConcurrentHashMap<String, SortedSet<BasicTaskDetailsVO>>();

	private String dmnFilePath;

	@Autowired
	OCEGetNextTaskDecisionTable oceDecisionTable;

	@Override
	public void initialize(List<TaskDetailsVO> taskDetailsList) {
		logger.info("Initialization started");
		this.createTasks(taskDetailsList);
		logger.info("Initialization done");
	}

	private String getBinId(TaskDetailsVO taskDetailsVO) throws OCECamundaGetNextException {

		logger.trace("getting Bin id for vo : " + taskDetailsVO);

		BinDecisionInputViewModel inputModel = new BinDecisionInputViewModel();

		inputModel.setDMNfile(this.getDmnFilePath());

		inputModel.setLineAction(taskDetailsVO.getLineAction());
		inputModel.setLineCombo(taskDetailsVO.getLineCombos());
		inputModel.setPartner(taskDetailsVO.getOwner());
		inputModel.setProgram(taskDetailsVO.getProgram());
		inputModel.setQueueType(taskDetailsVO.getQueueType());
		inputModel.setView(taskDetailsVO.getChannel());

		String binId = oceDecisionTable.getBinDecisionID(inputModel);

		logger.trace("Got the Bin id : " + binId);

		return binId;

	}

	private void dumpDMNToFile() throws OCECamundaGetNextException {

		logger.debug("dumpDMNToFile is called ");

		BinDecisionInputViewModel inputModel = new BinDecisionInputViewModel();

		inputModel.setDMNfile(this.getDmnFilePath());

		oceDecisionTable.dumpDecisionTableToFile(inputModel);

		logger.info("DMN is dumped to : " + this.getDmnFilePath());
	}

	private void poppulateHashTable(String type, List<TaskDetailsVO> taskDetails) {

		SortedSet<BasicTaskDetailsVO> taskValues;

		BasicTaskDetailsVO t1 = null;

		String binId = null;

		logger.debug("Hash table poppulation started for the event : " + type);

		for (TaskDetailsVO taskDetailsVO : taskDetails) {

			logger.trace("poppulating ... TaskDetailsVO : " + taskDetailsVO);

			try {
				binId = this.getBinId(taskDetailsVO);
				logger.trace("Received bin id : " + binId);
			} catch (OCECamundaGetNextException e) {
				logger.error("bin decision failed for the VO : " + taskDetailsVO);
				continue;
			}

			synchronized (this) {

				t1 = new BasicTaskDetailsVO(taskDetailsVO);

				if (taskMap.containsKey(binId)) {
					taskValues = taskMap.get(binId);
				} else {
					taskValues = new TreeSet<BasicTaskDetailsVO>(new TaskMinDateComparator());
					logger.trace("New Bin TaskDetailsVO : " +taskDetailsVO);
				}

				SortedSet<BasicTaskDetailsVO> actualSet = new TreeSet<BasicTaskDetailsVO>(new TaskMinDateComparator());

				if (type.equals(TaskConstants.TASK_UPDATED)) {

					Calendar cal = Calendar.getInstance();
					 
					for (BasicTaskDetailsVO vo : taskValues) {
						cal.setTime(vo.getTaskModifiedDate());
						cal.add(Calendar.HOUR, cal.get(Calendar.HOUR) -1);
						Date oneHourBack = cal.getTime();
						if(!( vo.getTaskStatus().equals(TaskConstants.NEW) || vo.getTaskStatus().equals(TaskConstants.UNCLAIMED) || vo.getTaskStatus().equals(TaskConstants.REP_PROCESSING)) && (vo.getTaskModifiedDate().before(oneHourBack)) ) {
							continue;
						} else if (!vo.equals(t1)) {
							actualSet.add(vo);
						} 
					}
				} else {
					actualSet.addAll(taskValues);
				}

				actualSet.add(t1);
				taskMap.put(binId, actualSet);
				logger.trace("Hashtable ... is poppulated");
			}
		}

		logger.debug("Hash table poppulation is done");

	}

	@Override
	public void createTasks(List<TaskDetailsVO> taskDetails) {
		logger.info("Create Task is called");
		try {
			this.poppulateHashTable(TaskConstants.TASK_CREATED, taskDetails);
			this.dumpDMNToFile();
		} catch (Exception e) {
			logger.error("CreateTasks Method Exception Occurred", e);
		}
		logger.info("Create Task is called");
	}

	@Override
	public void updateTasks(List<TaskDetailsVO> taskDetails) {
		logger.info("Update Task is called");
		this.poppulateHashTable(TaskConstants.TASK_UPDATED, taskDetails);
		logger.info("Update Task is called");
	}

	@Override
	public String getNextTask(TaskDetailsVO taskDetailsVO) throws OCEException {

		logger.info("getNextTask is called ");
		logger.trace("getNextTask is called for : " + taskDetailsVO);

		String retVal = null;
		try {
			String binId = this.getBinId(taskDetailsVO);
			SortedSet<BasicTaskDetailsVO> taskValues = taskMap.get(binId);
			if (taskValues != null) {
				BasicTaskDetailsVO vo = null;
				for (BasicTaskDetailsVO itr : taskValues) {
					if (itr.getTaskStatus().equals(TaskConstants.NEW) || itr.getTaskStatus().equals(TaskConstants.UNCLAIMED)) {
						vo = itr;
						break;
					} 
				}
				if (vo != null) {
					retVal = vo.getTaskId();
				}
			}
		} catch (OCECamundaGetNextException e) {
			logger.error("DMN Failure", e);
			throw new OCEException(e.getMessage());
		} catch (NoSuchElementException e) {
			logger.error("No Task id for the given query", e);
			throw e;
		}

		logger.debug("getNextTask returns : " + retVal);
		return retVal;
	}

	/*
	 * ******************* BE CAUTIOUS !!! ********************************* Do
	 * not use this method unnecessarily, it will affect the over all
	 * functionality. This method is created only to purge testData not the real
	 * data. Please take care.
	 * 
	 */
	@Override
	public void purgeTestData() throws OCEException {
		this.taskMap.clear();
	}

	/**
	 * @return the dmnFilePath
	 */
	public String getDmnFilePath() {
		return dmnFilePath;
	}

	/**
	 * @param dmnFilePath the dmnFilePath to set
	 */
	public void setDmnFilePath(String dmnFilePath) {
		this.dmnFilePath = dmnFilePath;
	}
}