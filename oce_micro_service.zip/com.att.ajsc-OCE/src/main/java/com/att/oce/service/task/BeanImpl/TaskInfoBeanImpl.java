package com.att.oce.service.task.BeanImpl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import reactor.bus.Event;

import com.att.oce.idgen.OCEUniqueIdGenerator;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroup;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtGroupCharacteristics;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.CtOrderSource;
import com.att.oce.oce.namespaces.types._private.ocedatamodel.Order;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.CtOrderTask;
import com.att.oce.oce.namespaces.types._private.ocedatamodelextensionv1_0.StTaskStatus;
import com.att.oce.service.DateUtil;
import com.att.oce.service.queue.OCEOrderQueueService;
import com.att.oce.service.queue.vo.OCEQueueDeterminationRequest;
import com.att.oce.service.queueImpl.QueueDetails;
import com.att.oce.service.task.Bean.OrderTaskBean;
import com.att.oce.service.task.Bean.TaskInfoBean;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.oce.service.task.util.StringUtilities;
import com.att.oce.service.task.util.TaskConstants;
import com.att.ooce.core.ProcessOrderRequest;

/**
 * The Class TaskInfoBeanImpl.
 *
 * @author SX00352475 Mukhtar Shaikh
 * 
 *         This class responsibility is as follows Initialize TaskMap Create
 *         task Publish events to DB,GetNext and Order reactors Update task
 */

@Component
public class TaskInfoBeanImpl extends AbstractTaskBeanImpl implements TaskInfoBean {

	/** The logger. */
	private Logger logger = LoggerFactory.getLogger(TaskInfoBeanImpl.class);

	/** The task map. */
	Map<String, TaskDetailsVO> taskMap = new ConcurrentHashMap<String, TaskDetailsVO>();

	/** The order queue service. */
	@Autowired
	OCEOrderQueueService orderQueueService;

	/** The uniqueue id generator service. */
	@Autowired
	OCEUniqueIdGenerator idGenerator;

	/** The order task bean. */
	@Autowired
	OrderTaskBean orderTaskBean;

	/** The unique key. */
	UUID uniqueKey = UUID.randomUUID();

	/**
	 * The Enum TaskUpdateOperation.
	 *
	 * @author RetheeshM_R
	 */
	protected static enum TaskUpdateOperation {

		/** The null. */
		NULL("",0),

		/** The release. */
		RELEASE("RELEASE",1), 

		/** The claim. */
		CLAIM("CLAIM",2),

		/** The assign. */
		ASSIGN("ASSIGN",3),

		/** The close. */
		CLOSE("CLOSE",4),

		/** The backtoqueue. */
		BACKTOQUEUE("BACKTOQUEUE",5);

		/** The request value. */
		private String requestValue;

		/** The value. */
		private int value;

		/**
		 * Instantiates a new task update operation.
		 *
		 * @param requestValue the request value
		 * @param value the value
		 */
		private TaskUpdateOperation(String requestValue, int value) {
			this.requestValue = requestValue;
			this.value = value;
		}

		/**
		 * Gets the request value.
		 *
		 * @return the request value
		 */
		public String getRequestValue() {
			return this.requestValue;
		}

		/**
		 * Gets the value.
		 *
		 * @return the value
		 */
		public int getValue() {
			return this.value;
		}

	}

	/** The idd generator. */
	@Autowired 
	@Qualifier("sequentialIdGenerator") 
	OCEUniqueIdGenerator iddGenerator;

	/**
	 * This method will accept the event DBTaskInfoBeanImpl GetNextTaskBeanImpl.
	 *
	 * @param ev the ev
	 */
	@Override
	public void accept(Event<List<TaskDetailsVO>> ev) {
		if (ev.getKey().toString().equals(TaskConstants.TASK_LOADED)) {
			initialize(ev.getData());
		}
	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.BasicTaskBean#createTasks(java.util.List)
	 */
	@Override
	public void createTasks(List<TaskDetailsVO> tasks) {

		logger.info("create Tasks is called");

		if (tasks == null || tasks.isEmpty()) {
			// Ideally, we need to throw an exception, Lets see..
			logger.error("create event is called with null object");
			return;
		}

		synchronized (this) {

			List<TaskDetailsVO> detaislList = new ArrayList<TaskDetailsVO>();

			for (TaskDetailsVO task : tasks) {
				logger.trace("Task create request is made for the task" +task);

				UUID uniqueKey = UUID.randomUUID();
				task.setTaskId(uniqueKey.toString());
				taskMap.put(uniqueKey.toString(), task);
				detaislList.add(task);
				logger.trace("Task is created : " +task);
			}

			if (!detaislList.isEmpty()) {
				logger.trace("TASK CREATED event will be published");
				publishEvent(TaskConstants.TASK_CREATED, detaislList);
			}

		}

		logger.info("create Tasks is ended ");

	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.BasicTaskBean#updateTasks(java.util.List)
	 */
	@Override
	public void updateTasks(List<TaskDetailsVO> tasks) {

		logger.info("updateTasks Tasks is called");
		if (tasks == null || tasks.isEmpty()) {
			// Ideally, we need to throw an exception, Lets see..
			logger.error("update event is called with null object");
			return;
		}
		synchronized (this) {
			List<TaskDetailsVO> detaislList = new ArrayList<TaskDetailsVO>();
			TaskDetailsVO taskDetails = null;
			for (TaskDetailsVO task : tasks) {
				logger.trace("Task update request is made for the task" +task);
				taskDetails = new TaskDetailsVO();
				String taskId = task.getTaskId();
				logger.trace("taskId------" +task);
				logger.trace("taskMap------" +taskMap);
				if (taskMap.containsKey(taskId)) {
					taskDetails = taskMap.get(taskId);
					taskDetails =  this.mergeData(taskDetails, task);
					String orderId = taskDetails.getOrderRef();
					logger.trace("orderId------" +orderId);
					TaskUpdateOperation operation = determineTaskOperation(taskDetails.getCsrId(),taskDetails.getTaskStatus(),taskDetails.getTaskStatus());
					logger.trace("operation------" +operation);
					switch(operation) {
					case RELEASE:
						taskDetails = releaseTask(orderId, taskDetails);
						break;
					case CLAIM:
						//Validate Task limit
						checkForTaskLimit(taskDetails.getCsrId(), taskDetails.getChannel(),"INPROGRESS");
						//		authorizeTaskClaim(loginName,taskDetails);
						taskDetails = claimTask(orderId, taskDetails,taskDetails.getCsrId(),taskDetails.getChannel());
						logger.trace("CLAIM--taskDetails----" +taskDetails);
						break;
					case ASSIGN:
						/*if(!OCEOrderConstants.SYSTEM.equalsIgnoreCase(loginName))
									authorizeUserForTaskAssign(role);*/
						//Validate CSR Id in request
						//	validateCSRId(orderTask.getCsrId());
						//Validate Task limit
						checkForTaskLimit(taskDetails.getCsrId(), taskDetails.getChannel(),"INPROGRESS");
						taskDetails = assignTask(orderId, taskDetails, taskDetails.getCsrId(), taskDetails.getChannel());
						break;
					case CLOSE:
						taskDetails = closeTask(orderId, taskDetails);
						break;
					case BACKTOQUEUE:
						assignTasksBackToQueue(orderId);
						break;
					case NULL:
						break;

					}
					List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
					tskList.add(taskDetails);
					logger.debug("CLAIM--taskDetails----" +tskList);
					logger.debug("update Task request is completed");
				} else {
					taskDetails = task;
				}
				task.setLast_modified_date(new Date());
				taskMap.put(taskId, task);
				detaislList.add(taskDetails);
			}
			logger.debug("TASK UPDATED event will be published");
			publishEvent(TaskConstants.TASK_UPDATED, detaislList);
		}

		logger.info("updateTasks Tasks is ended");
	}
	/**
	 * Assign tasks back to queue.
	 *
	 * @param orderId the order id
	 */
	private void assignTasksBackToQueue(String orderId) {

	}




	/**
	 * Close task.
	 *
	 * @param orderId the order id
	 * @param taskDetails the task details
	 * @return the task details VO
	 */
	private TaskDetailsVO closeTask(String orderId, TaskDetailsVO taskDetails) {
		taskDetails.setLast_modified_date(new Timestamp(DateUtil.getCurrentTimeAsGMT().getTime()));
		// The task has been updated. Now set the lock time to null
		//orderImpl.setLockTime(null);
		return taskDetails;
	}

	/**
	 * Check for task limit.
	 *
	 * @param csrId the csr id
	 * @param channel the channel
	 * @param taskStatus the task status
	 */
	private void checkForTaskLimit(String csrId, String channel,String taskStatus){
		//try {
		//List<TaskDetailsVO> taskDetailList = (List<TaskDetailsVO>) dbTaskBean.fetchAllTasks();
		//	TaskDetailsPredicate pre = null;
		//List<TaskDetailsVO> existingTaskCount = (List<TaskDetailsVO>) pre.getExistingTaskCount(taskDetailList,pre.existingTaskPredicate(csrId, channel, taskStatus));
		/*if(existingTaskCount >= getTaskLimitForUser(csrId, channel)) {
				if(isLoggingInfo()) {
					logInfo("Task Limit exceeded , can't claim/assign more tasks");
				}
				orderTaskTools.errorLookup("ERR403004");
			}*/
		/*} catch (OCEException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

	/**
	 * Claim task.
	 *
	 * @param orderId the order id
	 * @param taskDetails the task details
	 * @param loginName the login name
	 * @param channel the channel
	 * @return the task details VO
	 */
	private TaskDetailsVO claimTask(String orderId, TaskDetailsVO taskDetails,String loginName,String channel){
		taskDetails.setCsrId(loginName);
		taskDetails.setLast_modified_date(new Timestamp(DateUtil.getCurrentTimeAsGMT().getTime()));
		ProcessOrderRequest request = new ProcessOrderRequest();
		Order order = new Order();
		order.setCustomerOrderNumber(taskDetails.getExternalOrderNum());
		order.setIsLocked(true);
		//	Date lockTime = DateUtil.getCurrentTimeAsGMT();	
		//order.setLockTime(lockTime);
		order.setLockOwner(loginName);
		order.setOCEOrderNumber(taskDetails.getOrderRef());

		// order.setOrderType(StOrderType.UPDATE);
		request.setOrder(order);

		//taskDetails.setLocked(null);
		return taskDetails;
	}

	/**
	 * Assign task.
	 *
	 * @param orderId the order id
	 * @param taskDetails the task details
	 * @param loginName the login name
	 * @param channel the channel
	 * @return the task details VO
	 */
	private TaskDetailsVO assignTask(String orderId, TaskDetailsVO taskDetails,String loginName,String channel){
		taskDetails.setCsrId(loginName);
		taskDetails.setLast_modified_date(new Timestamp(DateUtil.getCurrentTimeAsGMT().getTime()));
		ProcessOrderRequest request = new ProcessOrderRequest();
		Order order = new Order();
		order.setCustomerOrderNumber(taskDetails.getExternalOrderNum());
		order.setIsLocked(true);
		//	Date lockTime = DateUtil.getCurrentTimeAsGMT();	
		order.setLockTime(null);
		order.setLockOwner(loginName);
		order.setOCEOrderNumber(taskDetails.getOrderRef());

		// order.setOrderType(StOrderType.UPDATE);
		request.setOrder(order);

		//taskDetails.setLocked(null);
		return taskDetails;
	}

	/**
	 * Release task.
	 *
	 * @param orderId the order id
	 * @param taskDetails the task details
	 * @return the task details VO
	 */
	private TaskDetailsVO releaseTask(String orderId, TaskDetailsVO taskDetails){
		taskDetails.setTaskSubStatus("IN_QUEUE");
		taskDetails.setCsrId(null);
		taskDetails.setLast_modified_date(new Timestamp(DateUtil.getCurrentTimeAsGMT().getTime()));
		ProcessOrderRequest request = new ProcessOrderRequest();
		Order order = new Order();
		order.setCustomerOrderNumber(taskDetails.getExternalOrderNum());
		order.setIsLocked(false);
		order.setLockTime(null);
		order.setLockOwner(taskDetails.getCsrId());
		order.setOCEOrderNumber(taskDetails.getOrderRef());
		//Checking if CRU Order
		//boolean isCRU = getOrderTaskTools().isCRUOrder(orderImpl);
		// order.setOrderType(StOrderType.UPDATE);
		request.setOrder(order);

		//taskDetails.setLocked(null);
		return taskDetails;
	}
	/**
	 * Determine task operation.
	 *
	 * @param csrId the csr id
	 * @param currentTaskStatus the current task status
	 * @param taskStatus the task status
	 * @return the task update operation
	 */
	private TaskUpdateOperation determineTaskOperation(String csrId,String currentTaskStatus, String taskStatus){
		List<String> taskClosedStatus = new ArrayList<String>();
		taskClosedStatus.add("REJECTED");
		taskClosedStatus.add("COMPLETED");
		taskClosedStatus.add("ONHOLD");
		taskClosedStatus.add("CANCELED");
		if ("NEW".equalsIgnoreCase(currentTaskStatus) 
				|| ("UNCLAIMED".equalsIgnoreCase(currentTaskStatus))
				&& ("IN_PROGRESS".equalsIgnoreCase(taskStatus))
				||"IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& ("IN_PROGRESS".equalsIgnoreCase(taskStatus)
						&& (null == csrId || csrId.isEmpty()))) {
			return TaskUpdateOperation.CLAIM;
		} else if ("IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& "NEW".equalsIgnoreCase(taskStatus)) {
			return TaskUpdateOperation.RELEASE;
		} else if ("IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& "IN_PROGRESS".equalsIgnoreCase(taskStatus)) {
			return TaskUpdateOperation.ASSIGN;
		} else if("IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& "UNCLAIMED".equalsIgnoreCase(taskStatus)) {
			return TaskUpdateOperation.BACKTOQUEUE;
		} else if ("IN_PROGRESS".equalsIgnoreCase(currentTaskStatus)
				&& taskClosedStatus.contains(taskStatus.toUpperCase())) {
			return TaskUpdateOperation.CLOSE;
		} else {
		}
		return TaskUpdateOperation.NULL;
	}

	/**
	 * Merge data.
	 *
	 * @param existingTask the existing task
	 * @param newTask the new task
	 * @return the task details VO
	 */
	private TaskDetailsVO mergeData(TaskDetailsVO existingTask, TaskDetailsVO newTask ) {

		logger.info("mergeData Tasks is called");

		logger.trace("mergeData is called for the task1" +existingTask);

		logger.trace("mergeData is called for the task2" +newTask);

		TaskDetailsVO mergedDataVO = newTask;

		try {
			mergedDataVO = existingTask.merge(newTask);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		logger.trace("mergeData responded with merged data" +mergedDataVO);

		logger.info("mergeData Tasks is ended");

		return mergedDataVO;
	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.BasicTaskBean#initialize(java.util.List)
	 */
	@Override
	public void initialize(List<TaskDetailsVO> taskDetailsList) {

		logger.info("Task in progress in taskinfobean");

		for (TaskDetailsVO taskDetailsVO : taskDetailsList) {
			taskMap.put(taskDetailsVO.getTaskId(), taskDetailsVO);
		}

		logger.info("Initialization is done.. size of map in init=" + taskMap.size());

	}

	/**
	 * This method will return task details based on taskid.
	 *
	 * @param id the id
	 * @return the task info
	 */

	@Override
	public TaskDetailsVO getTaskInfo(String id) {
		logger.info("getTaskInfo is called for task Id" + id);
		TaskDetailsVO retVal = taskMap.get(id); 
		logger.trace("The return value is :" +retVal);
		return retVal;
	}

	/**
	 * This method will return all task available in cache(in taskMap).
	 *
	 * @return the all task
	 */

	@Override
	public Collection<TaskDetailsVO> getAllTask() {
		logger.info("getAllTask is called");
		return taskMap.values();
	}

	/*
	 * ******************* BE CAUTIOUS !!! *********************************
	 * Do not use this method unnecessarily, it will affect the over all functionality. 
	 * This method is created only to purge testData not the real data. Please take care.
	 * 
	 */

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.BeanImpl.AbstractTaskBeanImpl#purgeTestData()
	 */
	@Override
	public void purgeTestData() throws OCEException {
		logger.error("purgeTest Data is called to clear the map");
		this.taskMap.clear();
	}

	/* (non-Javadoc)
	 * @see com.att.oce.service.task.Bean.TaskInfoBean#createTask(com.att.oce.service.queue.vo.OCEQueueDeterminationRequest)
	 */
	@Override
	public List<TaskDetailsVO> createTask(ProcessOrderRequest processOrderRequest)
			throws OCEException {
		QueueDetails details = null;// qservice.getOutboundQueueDetails("TESTQU2NEW", "CRU-MOBILITY");		
		OCEQueueDeterminationRequest request = new OCEQueueDeterminationRequest();	
		request = new OCEQueueDeterminationRequest(request, processOrderRequest);
		details = orderQueueService.determineQueue(request);		
		List<TaskDetailsVO> tskList = extractPayload(request, processOrderRequest,details); 
		return tskList;
	}

	public List<TaskDetailsVO>  extractPayload(OCEQueueDeterminationRequest request, ProcessOrderRequest processOrderRequest, QueueDetails details) throws OCEException {

		String taskOrderId = processOrderRequest.getOrder().getCustomerOrderNumber();
		String channel = "";		
		channel = (String) processOrderRequest.getOrder().getOrderSource().getChannel();
		List<TaskDetailsVO> tskList = new ArrayList<TaskDetailsVO>();
		boolean taskExists = handleDuplicateTask(request.getOrder().getCtOrderTasks(),
				request.getOrder().getOceOrderNumber(), taskOrderId, details.getQueueType());
		String prgmNmeFulfllmntMthd = request.getOrder().getPrgmNmeFulfllmntMthd();
		if(taskExists){
			updateTasks(tskList);
		} else {
			for (CtOrderTask ctorderTask : request.getOrder().getCtOrderTasks()) {
				TaskDetailsVO taskDetailsVO = new TaskDetailsVO(ctorderTask);
				String taskId = null;
				try {
					taskId = idGenerator.generateStringId();
				} catch (Exception e) {
					if (logger.isErrorEnabled()){
						logger.error(e.getMessage());
					}
				}
				if (null != details) {
					taskDetailsVO.setQueueType(details.getQueueType());
					taskDetailsVO.setQueueCategory(details
							.getQueueCategory());
					taskDetailsVO.setQueueSubType(details
							.getQueueSubType());
					if (null != details.getQueueSubType() && details.getQueueSubType().equalsIgnoreCase(TaskConstants.OUTBOUND)) {
						if (null != ctorderTask.getCallbackPreference()) {
							taskDetailsVO.setCallbackPreference(ctorderTask.getCallbackPreference());
						} else {
							taskDetailsVO.setCallbackPreference(TaskConstants.FIRST_CALL_QUEUE);
						}
					}
					taskDetailsVO.setQueueId(details.getQueueId());
					ctorderTask.setQueueType(details.getQueueType().toUpperCase());
					ctorderTask.setQueueSubType(details.getQueueSubType());
					// Updating Rep Comments with actual values from order.
					if (null != details.getRepComments()) {
						ctorderTask.setRepComments(details.getRepComments());
						taskDetailsVO.setRepComments(details.getRepComments());
					}
					// Updating QueuePriority
					if (null != details.getQueuePriority()) {
						ctorderTask.setQueuePriorityValue(details.getQueuePriority());
						taskDetailsVO.setQueue_Priority_value(details.getQueuePriority());
					}
					// Added for US786130: Queue Design change
					if (details.isManualIntervention()) {
						taskDetailsVO.setSubStatus(TaskConstants.IN_QUEUE);
					} else {
						taskDetailsVO.setSubStatus(TaskConstants.OPEN);
					}
				}

				if (null != ctorderTask
						&& null != ctorderTask.getChildOrderNumber()) {
					taskDetailsVO.setChild_order_ref(ctorderTask.getChildOrderNumber());
				}

				if (null != ctorderTask
						&& null != ctorderTask.getTaskStatus()) {
					ctorderTask.setTaskStatus(ctorderTask.getTaskStatus());
				} else if (!details.isManualIntervention()) {
					ctorderTask.setTaskStatus(StTaskStatus.OPEN);
				} else {
					ctorderTask.setTaskStatus(StTaskStatus.NEW);
				}
				ctorderTask.setCsrId("");
				if(null == ctorderTask.getCreatedBy()) {
					ctorderTask.setCreatedBy(TaskConstants.SYSTEM);
					ctorderTask.setLastModifiedBy(TaskConstants.SYSTEM);
				} else {
					ctorderTask.setCreatedBy(ctorderTask.getCreatedBy());
					ctorderTask.setLastModifiedBy(ctorderTask.getCreatedBy().toUpperCase());
				}
				//new changes for ORDER_TASK_APPLICATION_NAME
				if(null != ctorderTask && null !=ctorderTask.getApplicationName()) {
					ctorderTask.setApplicationName(ctorderTask.getApplicationName());;
				}
				taskDetailsVO.setApplicationName(ctorderTask.getApplicationName());
				/** Set action type for CRU-MOBLITY **/
				if(processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase(TaskConstants.CRUMOBILITY)){
					if(null!=processOrderRequest.getOrder().getRequestType() && 
							processOrderRequest.getOrder().getRequestType().toString().equalsIgnoreCase(TaskConstants.SCR)){
						if(null!=details.getActionType()){
							taskDetailsVO.setActionType(details.getActionType());
						}
						else{
							/** To set Action Type as NA in case its not present in SCR order.**/
							taskDetailsVO.setActionType(TaskConstants.NA);
						}
					}
					else{
						taskDetailsVO.setActionType(TaskConstants.NA);
					}


				}
				else{
					taskDetailsVO.setActionType(TaskConstants.NA);
				}

				/*if(null != ctorderTask.getCamundaTaskId()) {
						String camundaTaskId = ctorderTask.getCamundaTaskId();
						taskDetailsVO.setAvos_task_id(camundaTaskId);
						ctorderTask.setTaskId(camundaTaskId);
					} else {*/
				// Set Main Task Id
				String avosRefTaskId = ctorderTask.getTaskId();
				if(avosRefTaskId!=null){
					avosRefTaskId = ((null == avosRefTaskId) ? "M" + taskId.toUpperCase() : avosRefTaskId);
				}
				taskDetailsVO.setAvos_task_id(avosRefTaskId);
				ctorderTask.setTaskId(avosRefTaskId);
				//}

				if(request.getOrder().isWirelessUnlock()) {			
					if (request.getOrder().getCtOrderSource().getChannel().equalsIgnoreCase(TaskConstants.UNLOCK)) {
						taskDetailsVO.setProgram(processOrderRequest.getOrder().getProgramName());
						taskDetailsVO.setLineAction("");
						List<String> lineComboList = ctorderTask.getLineCombination().getLineCombo();
						if (null != lineComboList && !lineComboList.isEmpty()) {
							for(String lineCombo : lineComboList){
								taskDetailsVO.setLineCombos(lineCombo);
							}
						}
						taskDetailsVO.setLineCount("1");
					} 
					/** END IRU_UNLOCK PMT:*/
					else {
						taskDetailsVO.setProgram(TaskConstants.NA);
					}

					if (TaskConstants.UNLOCK.equals(request.getOrder().getCtOrderSource().getChannel())) {
						Date currentDate = DateUtil.getCurrentTimeAsGMT();
						Timestamp timestamp =  new Timestamp(currentDate.getTime());
						taskDetailsVO.setCreationDate(timestamp);
						taskDetailsVO.setLast_modified_date(timestamp);
					}

				}
				taskDetailsVO.setOrderRef(ctorderTask.getOrderNumber());
				//Calculate Task SLA is pending
				//calculateSLAForTask(newTaskItem);
				taskDetailsVO.setWirelessFalloutOrder(request.getOrder().isWirelessFalloutOrder());

				if(ctorderTask != null && null !=ctorderTask.getTaskStatus()) {
					taskDetailsVO.setTaskStatus(ctorderTask.getTaskStatus().toString());
				} else {
					taskDetailsVO.setTaskStatus(TaskConstants.NEW);
				}
				/** Populate request type for CRU-MOBILITY
				 * 
				 */
				if(processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase(TaskConstants.CRUMOBILITY)){
					if(null!=processOrderRequest.getOrder().getRequestType()){
						taskDetailsVO.setRequestType(processOrderRequest.getOrder().getRequestType().toString());
					}
					else{
						taskDetailsVO.setRequestType(TaskConstants.SOR);
					}
				}
				else{
					taskDetailsVO.setRequestType(TaskConstants.NA);
				}
				// Star Changes
				boolean isUnlockLOSG = isUnlockLOSGAvailableInRepo(processOrderRequest);
				/** START IRU_UNLOCK PMT:*/
				boolean isIruUnlock = isIruUnlockAvailableInRepo(processOrderRequest);
				String queueType = null;
				if(null!=ctorderTask){
					queueType = ctorderTask.getQueueType();
				}
				String lineAction = null;
				boolean isNackQueue = false;
				//For NACK Type
				if(null != ctorderTask && ctorderTask.getQueueType()!=null 
						&& queueType.equalsIgnoreCase(TaskConstants.NACKTRIAGE)) {
					isNackQueue = true;
					taskDetailsVO.setLineCombos(TaskConstants.UNKNOWN);
					taskDetailsVO.setProgram(TaskConstants.NACK);
					taskDetailsVO.setLineAction(TaskConstants.UNKNOWN);
					lineAction = TaskConstants.UNKNOWN;
					//if child order is created by parent order
				} 
				/*else if(null != processOrderRequest.getOrder().getParentOrderId()) {			
							OCEOrderImpl parentOrder = (OCEOrderImpl) getOceOrderManager().loadOrder(currentOrderImpl.getCreatedByOrderId());
							if(null != parentOrder.getLineCombos()){
							taskItem.setPropertyValue(
									OCEOrderConstants.OrderTaskConstants.ORDER_TASK_LINECOMBOS,
									parentOrder.getLineCombos());
							}

							taskItem.setPropertyValue(OCEOrderConstants.OrderTaskConstants.ORDER_TASK_PROGRAMNAME,
									(null==parentOrder.getProgram())?OCEOrderConstants.PGMNAME_DEFAULT_ON_NULL:parentOrder.getProgram());

							lineAction = parentOrder.getLineAction();		
					}
					else {
						if(null != processOrderRequest.getOrder().getLineCombos()){
						taskItem.setPropertyValue(
								OCEOrderConstants.OrderTaskConstants.ORDER_TASK_LINECOMBOS,	currentOrderImpl.getLineCombos());
						}			
						taskItem.setPropertyValue(OCEOrderConstants.OrderTaskConstants.ORDER_TASK_PROGRAMNAME,
								(null==currentOrderImpl.getProgram())?OCEOrderConstants.PGMNAME_DEFAULT_ON_NULL:currentOrderImpl.getProgram());
						lineAction = currentOrderImpl.getLineAction();
				//	}*/

				if(request.getOrder().isNonUnifyWireless()) {		
					if (TaskConstants.CDEHS.equalsIgnoreCase(channel)) {
						taskDetailsVO.setProgram(TaskConstants.WIRELESS);					
					}	
					if(null != prgmNmeFulfllmntMthd) {
						if(!isNackQueue && TaskConstants.CRUMOBILITY.equalsIgnoreCase(channel)){
							taskDetailsVO.setProgram(prgmNmeFulfllmntMthd);			
						}
					} else {
						if(!isNackQueue && TaskConstants.CRUMOBILITY.equalsIgnoreCase(channel)){
							taskDetailsVO.setProgram(TaskConstants.DF);		
						}
					}
					//setting default lineAction for wireless if pgmFromFulfillmentMethod is null
					if(null != request.getOrder().getLosgTypeNonUnifyWireless()) {
						lineAction = request.getOrder().getLosgTypeNonUnifyWireless();
					} else {
						lineAction = TaskConstants.NEW;
					}		
				}
				if(processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase("DE-SMB") ||
						processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase("SMB-WEB-CENTER")){
					if(!isNackQueue){
						if(null != request.getOrder().getLosgTypeNonUnifyWireless()) {
							lineAction = ctorderTask.getLineAction();
						}
						taskDetailsVO.setProgram(processOrderRequest.getOrder().getProgramName());	
					}
				}

				if(isUnlockLOSG) {
					taskDetailsVO.setOwner(TaskConstants.NA);

					if(null != ctorderTask && null!=ctorderTask.getQueueSubType() && !ctorderTask.getQueueSubType().isEmpty()) {		
						taskDetailsVO.setLineAction(ctorderTask.getQueueSubType());
					} else {
						if (isIruUnlock){
							taskDetailsVO.setLineAction(ctorderTask.getLineAction());
							taskDetailsVO.setOwner("ATT");
						} else {
							taskDetailsVO.setLineAction(TaskConstants.NA);
						}
					}
				}
				else {
					/*String ownerName = null;
							if(processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase("CDE-HS") || 
									processOrderRequest.getOrder().getOrderSource().getChannel().equalsIgnoreCase("SMB-WEB-CENTER")){
								/* For NACK follow the existing logic *
								if(null!=ctorderTask && ctorderTask.getQueueType()!=null 
										&& queueType.equalsIgnoreCase("NACK TRIAGE")) {
									ownerName = determineOwnerNameForTask(ctorderTask.getQueueType(),processOrderRequest.getOrder().getOrderSource().getChannel().toUpperCase());
									if(StringUtils.isNotEmpty(currentOrderImpl.getPartnerID()) && currentOrderImpl.getPartnerID().length()>0 && currentOrderImpl.getChannel().equalsIgnoreCase(OCEOrderConstants.SMB_WEB_CENTER)){
										ownerName=getDataAccessHelper().getPartnerNameFromOrderPartner(currentOrderImpl.getPartnerID());	
									}
								}
								else if(null!=ctorderTask.getOrderNumber()){
									//ownerName=getDataAccessHelper().getPartnerNameFromOrder(orderTask.getOrderNumber());
									/** To handle the case of Task Creation along with order creation .
					 * Use PartnerId from Current Order instead of fetching same from DB*
									if(StringUtils.isNotEmpty(currentOrderImpl.getPartnerID()) && currentOrderImpl.getPartnerID().length()>0){
										ownerName=getDataAccessHelper().getPartnerNameFromOrderPartner(currentOrderImpl.getPartnerID());	
									}
								}

							}else{
								ownerName = determineOwnerNameForTask(ctorderTask.getQueueType(),processOrderRequest.getOrder().getOrderSource().getChannel().toUpperCase());
							}*/
					/** Changes for US706168: Assigning Partner to Order END **/	

					//IF owner is not found, should be udpated as NA since the queue repository does not understand null.
					/*	ownerName = (null == ownerName || ownerName.isEmpty()) ? "NA" :ownerName;	
							taskDetailsVO.setOwner(ownerName);		*/	
					if(null!= lineAction && !lineAction.equals(TaskConstants.UNKNOWN)) {/*STAR req*/
						if(!isNackQueue){
							taskDetailsVO.setLineAction(lineAction);
						}
					}
				}
				if (isIruUnlock){
					taskDetailsVO.setLineCount("1");
				}
				tskList.add(taskDetailsVO);
			}
		}
		return tskList;
	}
	/**
	 * performs duplicate task processing
	 * 
	 * @param taskList
	 * @param parentOrderId
	 * @param taskOrderId
	 * @param queueType
	 * @return
	 * @throws OCEOrderException
	 */
	private boolean handleDuplicateTask(List<CtOrderTask> taskList,
			String parentOrderId, String taskOrderId, String queueType) {
		boolean taskExists = false;
		if (activeTasksExistForQueue(taskList, parentOrderId, taskOrderId,
				queueType)) {

			for (CtOrderTask currentTask : taskList) {
				if(null != currentTask.getChildOrderNumber()){
					String childOrderNum = currentTask.getChildOrderNumber();
					String orderNum = currentTask.getOrderNumber();
					String status  = "NEW";
					Set<String> resultList = orderTaskBean.getTaskForAnOrderOnStatus(orderNum,status);
					for (String taskId : resultList) {
						logger.debug("Associated Tasks : " + taskId);
						taskExists = true;
						TaskDetailsVO taskDetails = null;
						taskDetails = getTaskInfo(taskId);
						currentTask.setQueueType(taskDetails.getQueueType());
						currentTask.setTaskId(taskDetails.getTaskId());
						currentTask.setTaskStatus(StTaskStatus.NEW);
					}
				}
				else if (null != currentTask.getOrderNumber()){
					String orderNum = currentTask.getOrderNumber();
					String status  = "NEW";
					String childOrderNum = currentTask.getChildOrderNumber();
					Set<String> resultList = orderTaskBean.getTaskForAnOrderOnStatus(orderNum,status);
					for (String taskId : resultList) {
						logger.debug("Associated Tasks : " + taskId);
						taskExists = true;
						TaskDetailsVO taskDetails = null;
						taskDetails = getTaskInfo(taskId);
						currentTask.setQueueType(taskDetails.getQueueType());
						currentTask.setTaskId(taskDetails.getTaskId());
						currentTask.setTaskStatus(StTaskStatus.NEW);
					}
				}
				//add null check
				taskExists = true;
			}
		}
		return taskExists;
	}
	public boolean isIruUnlockAvailableInRepo(ProcessOrderRequest processOrderRequest) {
		CtOrderSource ctOrderSource = processOrderRequest.getOrder().getOrderSource();
		
		boolean isIruUnlock = isIRUUnlockAvail(ctOrderSource);
		return isIruUnlock;
		
	}
	public boolean isIRUUnlockAvail(CtOrderSource ctOrderSource) {
		boolean isIruUnlock = false;
		
		
		String channel = "";
		if (ctOrderSource != null) {
			channel = (String) ctOrderSource.getChannel();
		}
		if("UNLOCK".equalsIgnoreCase(channel)) {
			isIruUnlock = true;
		}
		return isIruUnlock;
	}
	public boolean isUnlockLOSGAvailableInRepo(ProcessOrderRequest processOrderRequest) {
		boolean isUnlockLOSGAvailable = false;
		@SuppressWarnings("unchecked")
		List<CtGroup> groupsItemList = processOrderRequest.getOrder().getGroups().getGroup();
		isUnlockLOSGAvailable = isUnlockLOSGAvailableInRepo( groupsItemList);
		return isUnlockLOSGAvailable;
		
	}
	public boolean isUnlockLOSGAvailableInRepo( List<CtGroup> groupsItemList) {
		boolean isUnlockLOSGAvailable = false;
		if(null == groupsItemList) {
			return isUnlockLOSGAvailable;
		}
		for (CtGroup grpItem : groupsItemList) {
			
			CtGroupCharacteristics groupItemChar = grpItem.getGroupCharacteristics();
			if(null != groupItemChar) {
				String losgType = (String) groupItemChar.getLoSGCharacteristics().getLoSGType().toString();
				if("UNLOCK".equalsIgnoreCase(losgType)) {
					isUnlockLOSGAvailable = true;
				}
			}

		}
		return isUnlockLOSGAvailable;
	}
	
	/**
	 * Method to check if active task is already available for same queuetype
	 * under same order
	 * 
	 * @param orderIdInput
	 * @param list
	 * @param currentOrder
	 * @throws CommerceException
	 * @throws RepositoryException
	 * @throws OCEOrderException
	 */
	boolean activeTasksExistForQueue(List<CtOrderTask> taskList,
			String parentOrderId, String orderId, String pQueueType) {
		boolean activeTasks = false;
		boolean createTasks = false;
		List<String> avosRefTasks = new ArrayList<String>();
		for (CtOrderTask task : taskList) {
			if (null == task.getTaskId() || task.getTaskId().isEmpty())
				createTasks = true;
		}

		if (createTasks && StringUtilities.isNotEmptyOrNull(pQueueType)) {
			Set<String> allOrderIds = new HashSet<String>();
			allOrderIds.add(parentOrderId);
			allOrderIds.add(orderId);
			if(allOrderIds.contains(parentOrderId)) {
				Set<String> taskIds = orderTaskBean.getTaskForAnOrder(parentOrderId);
				for (String taskId : taskIds) {
					logger.debug("Associated Tasks : " + taskId);
					TaskDetailsVO taskDetails = null;
					taskDetails = getTaskInfo(taskId);
					String queueType = taskDetails.getQueueType();
					if(queueType.equalsIgnoreCase(pQueueType)){
						activeTasks = true;
						break;
				}
			}
		}
		}
		return activeTasks;

	}
}
