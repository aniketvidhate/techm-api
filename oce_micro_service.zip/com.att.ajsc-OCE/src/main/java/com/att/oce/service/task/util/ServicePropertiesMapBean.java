package com.att.oce.service.task.util;

import com.att.oce.service.task.filemonitor.ServicePropertiesMap;

public class ServicePropertiesMapBean {

	public static String getProperty(String propFileName, String propertyKey) {
		return ServicePropertiesMap.getProperty(propFileName, propertyKey);
	}
}
