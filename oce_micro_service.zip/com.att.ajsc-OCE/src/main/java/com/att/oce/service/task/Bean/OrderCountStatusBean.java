package com.att.oce.service.task.Bean;

import java.util.List;

import com.att.oce.service.task.Bean.request.ProgramCountRequest;
import com.att.ooce.core.CtFallout.Fallout;
import com.att.ooce.core.OrderQueueResponse;

/**
 * The Interface OrderCountStatusBean.
 */
public interface OrderCountStatusBean extends BasicTaskBean {
	
	/**
	 * Gets the program count.
	 *
	 * @param programCountRequest the program count request
	 * @return the program count
	 */
	public List<Fallout> getProgramCount(ProgramCountRequest programCountRequest);
	
	/**
	 * Gets the queue items by channel.
	 *
	 * @param programCountRequest the program count request
	 * @return the queue items by channel
	 */
	public List<Fallout> getQueueItemsByChannel(ProgramCountRequest programCountRequest);
	
	/**
	 * Gets the out bound items by channel.
	 *
	 * @param programCountRequest the program count request
	 * @return the out bound items by channel
	 */
	public List<Fallout> getOutBoundItemsByChannel(ProgramCountRequest programCountRequest);
	
	/**
	 * Gets the total order count.
	 *
	 * @param programCountRequest the program count request
	 * @param isWirelessFalloutOrder the is wireless fallout order
	 * @return the total order count
	 */
	public Long getTotalOrderCount(ProgramCountRequest programCountRequest,boolean isWirelessFalloutOrder);

	/**
	 * Gets the total order count with fallout lists.
	 *
	 * @param programCountRequest the program count request
	 * @return the order queue response
	 */
	public OrderQueueResponse fetchOrderQueueCount(ProgramCountRequest programCountRequest);
}
