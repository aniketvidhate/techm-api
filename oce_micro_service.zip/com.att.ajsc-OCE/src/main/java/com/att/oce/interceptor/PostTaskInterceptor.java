package com.att.oce.interceptor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PostTaskInterceptor implements ajsc.beans.interceptors.AjscInterceptor {

	private static PostTaskInterceptor classInstance = null;

	public static PostTaskInterceptor getInstance() {
		if (classInstance == null) {
			classInstance = new PostTaskInterceptor();
		}
		return classInstance;
	}

	@Override
	public boolean allowOrReject(HttpServletRequest arg0, HttpServletResponse arg1, Map<?, ?> arg2) throws Exception {
		// TODO Auto-generated method stub

		// arg1.get
		System.out.println("In post interceptor interceptor");

		StringBuilder sb = new StringBuilder();
		try {
			BufferedReader reader = this.getReader(arg0);
			reader.mark(10000);

			String line;
			do {
				line = reader.readLine();
				sb.append(line).append("\n");
			} while (line != null);
			reader.reset();
			// do NOT close the reader here, or you won't be able to get the
			// post data twice
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("request in post =" + sb.toString());

		// return sb.toString();

		// arg0.GETR
		return true;
	}

	private BufferedReader getReader(HttpServletRequest request) throws IOException {
		return new BufferedReader(new InputStreamReader(request.getInputStream()));
	}

}
