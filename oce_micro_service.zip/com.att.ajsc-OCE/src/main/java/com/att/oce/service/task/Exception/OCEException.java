/**
 * 
 */
package com.att.oce.service.task.Exception;

/**
 * @author Tech Mahindra Americas Generic Exception class that can be used as a
 *         wrapper
 */
public class OCEException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -864912641185465459L;

	/**
	 * @param pThrowable
	 */
	public OCEException(Throwable pThrowable) {
		super(pThrowable);
	}

	/**
	 * @param pMsg
	 */
	public OCEException(String pMsg) {
		super(pMsg);
	}
	
	public OCEException(String pMsg, Throwable pThrowable) {
		super(pMsg, pThrowable);
	}
}
