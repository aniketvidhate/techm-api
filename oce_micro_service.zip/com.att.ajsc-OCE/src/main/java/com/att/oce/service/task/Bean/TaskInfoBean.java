package com.att.oce.service.task.Bean;

import java.util.Collection;
import java.util.List;

import com.att.oce.service.queue.vo.OCEQueueDeterminationRequest;
import com.att.oce.service.task.Exception.OCEException;
import com.att.oce.service.task.VO.TaskDetailsVO;
import com.att.ooce.core.ProcessOrderRequest;

public interface TaskInfoBean extends BasicTaskBean {

	TaskDetailsVO getTaskInfo(String id) throws OCEException;

	Collection<TaskDetailsVO> getAllTask() throws OCEException;
	
	List<TaskDetailsVO> createTask(ProcessOrderRequest processOrderRequest) throws OCEException;
	
}