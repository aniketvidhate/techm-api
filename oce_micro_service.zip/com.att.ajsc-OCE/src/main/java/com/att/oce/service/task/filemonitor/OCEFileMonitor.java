package com.att.oce.service.task.filemonitor;

import java.io.File;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import com.att.ssf.filemonitor.FileChangedListener;
import com.att.ssf.filemonitor.FileMonitorThread;
import com.att.ssf.filemonitor.NamedThreadFactory;

public class OCEFileMonitor {
	private static OCEFileMonitor instance = null;
	private static final long DEFAULT_FILE_MONITOR_INTERVAL = 30L;
	private static final int DEFAULT_FILE_MONITOR_THREADPOOL_SIZE = 1;
	public static final String SSF_FILEMONITOR_POLLING_INTERVAL = "ssf_filemonitor_polling_interval";
	public static final String SSF_FILEMONITOR_THREADPOOL_SIZE = "ssf_filemonitor_threadpool_size";
	private AtomicInteger key = new AtomicInteger();
	private final long initialDelay = 0L;
	private long filePollingInterval;
	private int threadPoolSize;
	private ConcurrentHashMap<Integer, ScheduledFuture<?>> listeners;
	private ScheduledExecutorService scheduler;
	private boolean loadOnStartup = false;

	public static synchronized OCEFileMonitor getInstance() {
		if (instance == null)
			instance = new OCEFileMonitor();
		return instance;
	}

	private OCEFileMonitor() {
		try {
			this.filePollingInterval = Long.parseLong(System.getProperty("ssf_filemonitor_polling_interval"));
		} catch (Exception e) {
			this.filePollingInterval = 30L;
		}
		try {
			this.threadPoolSize = Integer.parseInt(System.getProperty("ssf_filemonitor_threadpool_size"));
		} catch (Exception e) {
			this.threadPoolSize = 1;
		}

		this.scheduler = Executors.newScheduledThreadPool(this.threadPoolSize, new NamedThreadFactory("file-monitor-"));
		this.listeners = new ConcurrentHashMap();
	}

	public void destroy() {
		if (this.listeners != null) {
			Set<Map.Entry<Integer, ScheduledFuture<?>>> entrySet = this.listeners.entrySet();
			for (Map.Entry entry : entrySet) {
				((ScheduledFuture) entry.getValue()).cancel(true);
			}
			this.listeners.clear();
			this.listeners = null;
		}
		this.scheduler.shutdownNow();
	}

	public void setFileChangedListeners(Map<String, FileChangedListener> map) {
		for (String key : map.keySet()) {
			File file = new File(key);
			if (file.exists())
				addFileChangedListener(file, (FileChangedListener) map.get(key));
		}
	}

	public void setLoadOnStartup(boolean loadOnStartup) {
		this.loadOnStartup = loadOnStartup;
	}

	public void addFileChangedListener(File file, FileChangedListener listener) {
		addFileChangedListener(file, listener, this.loadOnStartup);
	}

	public void addFileChangedListener(File file, FileChangedListener listener, boolean loadOnStartup) {
		Runnable task = new FileMonitorThread(file, listener, loadOnStartup);
		ScheduledFuture sf = this.scheduler.scheduleWithFixedDelay(task, 0L, this.filePollingInterval,
				TimeUnit.SECONDS);
		this.listeners.put(Integer.valueOf(this.key.getAndIncrement()), sf);
	}
}