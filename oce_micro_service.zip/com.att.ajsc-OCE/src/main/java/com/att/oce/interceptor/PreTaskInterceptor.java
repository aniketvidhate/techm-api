package com.att.oce.interceptor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Scanner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*import com.att.oce.dblog.util.AuditLog;
import com.att.oce.dblog.util.AuditLogUtil;
import com.att.oce.dblog.util.OCEManage*/;

public class PreTaskInterceptor implements ajsc.beans.interceptors.AjscInterceptor {

	 private static PreTaskInterceptor classInstance = null;
	
	public static PreTaskInterceptor getInstance() {
        if(classInstance == null){
            classInstance = new PreTaskInterceptor();
        }
        return classInstance;
    }
	
	
	@Override
	public boolean allowOrReject(HttpServletRequest request, HttpServletResponse response, Map<?, ?> arg2) throws Exception {
		System.out.println("In PreTaskInterceptor interceptor");
		
		//ContentCachingRequestWrapper hReq = new ContentCachingRequestWrapper((HttpServletRequest) request);
        
/*		Scanner s = null;
				
		StringBuilder sb = new StringBuilder();
	    try {
	        BufferedReader reader = this.getReader(arg0);
	        reader.mark(10000);

	        String line;
	        do {
	            line = reader.readLine();
	            sb.append(line).append("\n");
	        } while (line != null);
	        reader.reset();
	        // do NOT close the reader here, or you won't be able to get the post data twice
	    } catch(IOException e) {
	        e.printStackTrace();
	    }*/
	    
	   // System.out.println("request =" + extractPostRequestBody(hReq));
	    
	    
	   /* AuditLog auditLog = new AuditLog();
		
		System.out.println("Preparing audit logs");
		auditLog.setInsertedBy("SYSTEM");
		auditLog.setRequestID("requestId");
		auditLog.setOperationName("INSERT");
		auditLog.setLayer("MicroService");
		auditLog.setRequestTime(Calendar.getInstance());
		auditLog.setServiceName("GetNext");
		
		//auditLog.setRequest(body);
		auditLog.setInterfaceName("MicroService");
		auditLog.setInsertedDate(Calendar.getInstance());
		auditLog.setLogType(1);			
		auditLog.setIsExternal(0);
		auditLog.setCorrelationID("uuid");
		
		try {
		System.out.println("Preparing mq factory");
		org.apache.activemq.pool.PooledConnectionFactory mQPooledConnectionFactory = null;
		org.apache.commons.dbcp2.BasicDataSource ods = null;
		Properties mqProp = new Properties();
		mqProp.setProperty("brokerURL", "failover:(tcp://zlt04353.vci.att.com:8501,tcp://zlt04344.vci.att.com:8501)?initialReconnectDelay=30&randomize=false&maxReconnectDelay=500&maxReconnectAttempts=1&backup=true&timeout=1000");
		mqProp.setProperty("user", "admin");
		mqProp.setProperty("password", "test2ensemble");
		
		mQPooledConnectionFactory = OCEManager.getMQInstance(mqProp);
		
				
		Properties dbProp = new Properties();
		dbProp.setProperty("dbURL", "jdbc:oracle:thin:@zlt03295.vci.att.com:1524:t1c3d316");
		//dbProp.setProperty("minIdleConn", getPropertyManager().getMinIdleConn());
		//dbProp.setProperty("maxIdleConn", getPropertyManager().getMaxIdleConn());
		dbProp.setProperty("username", "OCE_AUDITLOG");
		dbProp.setProperty("password", "tstATGHay2015");
		
		System.out.println("getting connection");
		ods = OCEManager.getConnectionPoolInstance(dbProp);
		
		AuditLogUtil auditLogUtil = new AuditLogUtil();
		System.out.println("Publishing logs");
		String retStatus = auditLogUtil.publishLog(auditLog,mQPooledConnectionFactory, ods,"AuditLog");
		
		} catch(Exception e){
			e.printStackTrace();
		} */
		
		return true;
	}

	private BufferedReader getReader(HttpServletRequest request) throws IOException {
		return new BufferedReader(new InputStreamReader(request.getInputStream()));
	}
	
	private String extractPostRequestBody(HttpServletRequest request) {
	    if ("POST".equalsIgnoreCase(request.getMethod())) {
	        Scanner s = null;
	        try {
	            s = new Scanner(request.getInputStream(), "UTF-8").useDelimiter("\\A");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return s.hasNext() ? s.next() : "";
	    }
	    return "";
	}

}
