package com.att.oce.task.hibernate.orm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OCE_QUEUE_DETAILS")

public class OCEQueueDetails {

	@Id
	@Column(name = "task_id")
	private String mTaskId;

	@Column(name = "Linecombos")
	private String mLineCombos;
	@Column(name = "Line_action")
	private String mLineAction;
	@Column(name = "Program_name")
	private String mProgram;
	@Column(name = "Queue_type")
	private String mQueueType;

	public String getTaskId() {
		return mTaskId;
	}

	public void setTaskId(String mTaskId) {
		this.mTaskId = mTaskId;
	}

	public String getQueueCategory() {
		return mQueueCategory;
	}

	public void setQueueCategory(String mQueueCategory) {
		this.mQueueCategory = mQueueCategory;
	}

	public String getLineCount() {
		return mLineCount;
	}

	public void setLineCount(String mLineCount) {
		this.mLineCount = mLineCount;
	}

	@Column(name = "queue_category")
	private String mQueueCategory;
	@Column(name = "line_count")
	private String mLineCount;

	public String getLineCombos() {
		return mLineCombos;
	}

	public void setLineCombos(String mLineCombos) {
		this.mLineCombos = mLineCombos;
	}

	public String getLineAction() {
		return mLineAction;
	}

	public void setLineAction(String mLineAction) {
		this.mLineAction = mLineAction;
	}

	public String getProgram() {
		return mProgram;
	}

	public void setProgram(String mProgram) {
		this.mProgram = mProgram;
	}

	public String getQueueType() {
		return mQueueType;
	}

	public void setQueueType(String mQueueType) {
		this.mQueueType = mQueueType;
	}

}
