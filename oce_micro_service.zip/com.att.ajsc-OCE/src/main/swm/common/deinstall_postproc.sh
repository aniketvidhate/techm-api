#!/bin/sh

. `dirname $0`/deinstall.env
rm -rf ${ROOT_DIR}
exit 0
