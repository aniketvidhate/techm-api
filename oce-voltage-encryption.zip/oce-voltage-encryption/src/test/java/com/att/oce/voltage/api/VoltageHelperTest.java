package com.att.oce.voltage.api;

import static org.junit.Assert.assertEquals;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.voltage.securedata.enterprise.VeException;
import com.voltage.toolkit.ToolkitException;

public class VoltageHelperTest {

	VoltageHelper volHelper;

	@Before
	public void setUp() throws Exception {
		Properties props = new Properties();
		FileInputStream in = new FileInputStream("./src/test/resources/oce.encryption.properties");
		props.load(in);
		in.close();

		volHelper = VoltageHelper.getInstance(props);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void decryptCCTest() {
		String expectedStr = "4761739001010010", inputStr = "GACC9L8CGHBBKGAX",returnString=null;
		boolean noException = false;
		try {
			returnString = volHelper.decrypt(inputStr, VoltageEfpeFormatType.valueOf("CC_NUM"));
			noException = true;
		} catch (ToolkitException e) {
			noException = false;
			e.printStackTrace();
		} catch (VeException e) {
			noException = false;
			e.printStackTrace();
		}finally {
			
			assertEquals(true,noException);
			assertEquals(true, expectedStr.equals(returnString)?true:returnString.length()==16);
		}
		
	}

	@Test
	public void encryptCCTest() {
		String expectedStr = "GACC9L8CGHBBKGAX", inputStr = "4761739001010010",returnString=null;
		boolean noException=false;
		try {
			returnString = (volHelper.encrypt(inputStr, VoltageEfpeFormatType.valueOf("CC_NUM")));
			noException=true;
		} catch (ToolkitException e) {
			noException=false;
			e.printStackTrace();
		} catch (VeException e) {
			noException=false;
			e.printStackTrace();
		}finally {
			assertEquals(true,noException);
			assertEquals(true,expectedStr.equals(returnString)?true:expectedStr.length()==16);
		}
	}

	@Test
	public void encryptCCwithEncryptedInputTest() {
		String encryptedInputStr = "GACC9L8CGHBBKGAX", exceptionMsg = "";
		boolean noException = false;
		try {
			volHelper.encrypt(encryptedInputStr, VoltageEfpeFormatType.valueOf("CC_NUM"));
			noException = true;
		} catch (ToolkitException e) {
			noException = false;
			exceptionMsg = e.getMessage();
		} catch (VeException e) {
			noException = false;
			exceptionMsg = e.getMessage();
		}
		assertEquals(false, noException);
		assertEquals(true, exceptionMsg.contains("VE_ERROR_INVALID_INPUT"));
	}

	@Test
	public void decryptCCwithDecryptedInputTest() {
		String decryptedInputStr = "4761739001010010", exceptionMsg = "";
		boolean noException = false;
		try {
			volHelper.decrypt(decryptedInputStr, VoltageEfpeFormatType.valueOf("CC_NUM"));
			noException = true;
		} catch (ToolkitException e) {
			noException = false;
			exceptionMsg = e.getMessage();
		} catch (VeException e) {
			noException = false;
			exceptionMsg = e.getMessage();
		}
		assertEquals(false, noException);
		
	}
	
}
