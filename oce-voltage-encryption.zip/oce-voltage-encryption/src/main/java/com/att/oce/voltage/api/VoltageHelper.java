package com.att.oce.voltage.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.oce.voltage.util.NativeUtils;
import com.voltage.securedata.enterprise.FPE;
import com.voltage.securedata.enterprise.LibraryContext;
import com.voltage.securedata.enterprise.VeException;
import com.voltage.toolkit.ToolkitException;

/**
 * Common Voltage utility used by all TOs to encrypt or decrypt values to the
 * special SPI fields.
 *
 * This Class will load the Voltage DLL(Windows)/SO(Solarais) and provide
 * methods to encrypt and decrypt the SPI Data.
 *
 * @author
 */

public class VoltageHelper {

	private static final Logger LOG = LoggerFactory.getLogger(VoltageHelper.class);

	private static LibraryContext CTX_INSTANCE = null;

	private VoltagePropertiesHelper voltagePropertiesHelper;
	private String keyCacheDir;
	private String trustStoreDir;
	private String keyServerURL;
	private String mechId;
	private String passWord;
	private String FPEIdentity;
	private String FPEPCIIdentity;
	private String enabler;

	private static Map<String, FPE> hmFPE = null;

	private static VoltageHelper INSTANCE = null;

	/**
	 * Constructor
	 */
	private VoltageHelper(Properties props) {

		voltagePropertiesHelper = new VoltagePropertiesHelper(props);

		keyCacheDir = voltagePropertiesHelper.getKeyCacheDir();
		trustStoreDir = voltagePropertiesHelper.getTrustStoreDir();
		keyServerURL = voltagePropertiesHelper.getKeyServerURL();
		mechId = voltagePropertiesHelper.getMechId();
		passWord = voltagePropertiesHelper.getPassWord();
		FPEIdentity = voltagePropertiesHelper.getFPEIdentity();
		FPEPCIIdentity = voltagePropertiesHelper.getFPEPCIIdentity();
		enabler = voltagePropertiesHelper.getEnabler();

		try {
			getLibraryContext();

		} catch (VeException te) {
			logStackTrace(te, "VeException");
		}
	}

	
	public synchronized static VoltageHelper getInstance(Properties props) {
		if (INSTANCE == null) {
			
			  String osDataModel = System.getProperty("sun.arch.data.model");
			  String osName = System.getProperty("os.name");
			
			LOG.info("Loading lib for ->"+osName+" "+osDataModel);
			
			if (osName.toLowerCase().contains("win")) {
				try {    
		            NativeUtils.loadLibraryFromJar("/vibesimplejava.dll");   
		        } catch (IOException e) {
		            e.printStackTrace();
		            LOG.error("Failed to load library vibesimplejava.dll");
		        }    
			} else {
				try {    
		            NativeUtils.loadLibraryFromJar("/libvibesimplejava.so");   
		        } catch (IOException e) {
		            e.printStackTrace();
		            LOG.error("Failed to load library libvibesimplejava.so");
		        }    
			}
			INSTANCE = new VoltageHelper(props);
		}
		return INSTANCE;
	}

	/**
	 * This method will return the LibraryContext object if all the
	 * configurations are correct otherwise it will throw an exception.
	 *
	 * @return LibraryContext
	 * @throws ToolkitException
	 */
	@SuppressWarnings("static-access")
	public synchronized LibraryContext getLibraryContext() throws VeException {
		if (CTX_INSTANCE == null) {

			try {
				
				LOG.info("keyServerURL: " + keyServerURL + " keyCacheDir: " +keyCacheDir + " trustStoreDir: "+ trustStoreDir);
				
				CTX_INSTANCE = new LibraryContext.Builder().setPolicyURL(keyServerURL).setFileCachePath(keyCacheDir)
						.setTrustStorePath(trustStoreDir).build();

				if (CTX_INSTANCE != null) {
					// Create fbe objects for list of fields
					hmFPE = new HashMap<String, FPE>();

					hmFPE.put(VoltageEfpeFormatType.CC_NUM.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.CC_NUM.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEPCIIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.CC_VARNUM.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.CC_VARNUM.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEPCIIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.ALLNUM_SSN.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.ALLNUM_SSN.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.ALPHANUM_SSN.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.ALPHANUM_SSN.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.DRIVER_LIC_NUM.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.DRIVER_LIC_NUM.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.BIRTH_DATE.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.BIRTH_DATE.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.ALLNUM_PIN.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.ALLNUM_PIN.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.ALPHANUM_PIN.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.ALPHANUM_PIN.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.PSWD_HINT.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.PSWD_HINT.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.MOBILITY_LOC.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.MOBILITY_LOC.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.GENERIC_STRING.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.GENERIC_STRING.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.GENERIC_STRING_PCI.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.GENERIC_STRING_PCI.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEPCIIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.BANK_NUM.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.BANK_NUM.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.SO_GENERIC_SHORT.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.SO_GENERIC_SHORT.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.B64_GENERIC.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.B64_GENERIC.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.CV_ALLNUM_PIN.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.CV_ALLNUM_PIN.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEPCIIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.SO_GENERIC_SHORT.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.SO_GENERIC_SHORT.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.LPI_DATA.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.LPI_DATA.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.ALPHA_NUM.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.ALPHA_NUM.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.CC_EXP.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.CC_EXP.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());
					hmFPE.put(VoltageEfpeFormatType.CC_NAME.name(),
							CTX_INSTANCE.getFPEBuilder(VoltageEfpeFormatType.CC_NAME.name())
									.setUsernamePassword(mechId, passWord).setIdentity(FPEIdentity).build());

					logInfo("Voltage API Initialized Successfully. " + CTX_INSTANCE.getVersion());

				} else {
					logStackTrace("Unable to find voltage configuration / Invalid configuration.");

				}
			} catch (VeException te) {
				logStackTrace(te, "Voltage API Initialized Failed.");
				te.printStackTrace();
				throw te;
			}
		}
		return CTX_INSTANCE;
	}

	/**
	 * This method encrypts the data in the given EFPE format consuming the
	 * exception(if any) thrown by Voltage. This method is best suitable for
	 * encrypting TO attributes where exception is not thrown.
	 *
	 * @param data
	 * @param formatType
	 * @return encrypted value of the specified data
	 */
	public String encryptNoException(String data, VoltageEfpeFormatType formatType) {
		String encryptedData = data;
		try {
			encryptedData = encrypt(data, formatType);
		} catch (VeException te) {
			logStackTrace(te, null);
		} catch (ToolkitException te) {
			logStackTrace(te, null);
		}
		return encryptedData;
	}

	/**
	 * This method encrypts the data in the given EFPE format and can throw
	 * exception(if any). This method is best suitable for encrypting the
	 * attributes from down stream systems where we need to handle the
	 * exceptions (if any).
	 *
	 * @param data
	 * @param formatType
	 * @return encrypted value of the specified data
	 * @throws ToolkitException
	 * @throws Exception
	 */
	public String encrypt(String data, VoltageEfpeFormatType formatType) throws ToolkitException, VeException {
		String encryptedData = null;

		if ("true".equals(enabler)) {

			if (CTX_INSTANCE == null) {
				LOG.info("Voltage Libray is Null, Library Context Initialized Again.");
				getLibraryContext();
			}

			logInfo("Encrypt : Format Name - " + formatType.name());

			FPE fpeEncObj = null;
			if (null != data) {
				fpeEncObj = (FPE) hmFPE.get(formatType.name());

				if ((formatType.name()).equals(VoltageEfpeFormatType.B64_GENERIC.name())) {
					byte[] b_str;
					byte[] b64_b_str;
					b_str = data.getBytes();
					boolean wrapLines = false;
					b64_b_str = CTX_INSTANCE.base64Encode(b_str, wrapLines).getBytes();
					String b64_str = new String(b64_b_str);
					// Pad with :
					String pb64_str = String.format("%-15s", b64_str).replace(' ', ':');
					encryptedData = fpeEncObj.protect(pb64_str);
				} else if (VoltageEfpeFormatType.ALLNUM_SSN.name().equals(formatType.name())) {
					// Padding logic for ALLNUM_SSN
					if (null != data && data.length() < 9) {
						data = String.format("%9s", data).replace(' ', '0');
					}
					encryptedData = fpeEncObj.protect(data);
				} else {
					encryptedData = fpeEncObj.protect(data);
				}

			}
		} else {
			encryptedData = data;
		}

		return encryptedData;
	}

	/**
	 * This method decrypts the data in the given EFPE format consuming the
	 * exception(if any) thrown by Voltage. This method is best suitable for
	 * decrypting TO attributes where exception is not thrown.
	 *
	 * @param encryptedData
	 * @param formatType
	 * @return decrypted value of the specified data
	 */
	public String decryptNoException(String data, VoltageEfpeFormatType formatType) {
		String decryptedData = data;
		try {
			decryptedData = decrypt(data, formatType);
		} catch (VeException ve) {
			logStackTrace(ve, "Voltage Exception @ decryptNoException");
		} catch (ToolkitException e) {
			logStackTrace("decryptNoException - Exception : " + e);
		}
		return decryptedData;
	}

	/**
	 * This method decrypts the data in the given EFPE format and can throw
	 * exception(if any). This method is best suitable for decrypting the
	 * attributes from down stream systems where we need to handle the
	 * exceptions (if any).
	 *
	 * @param encryptedData
	 * @param formatType
	 * @return decrypted value of the specified data
	 * @throws ToolkitException
	 * @throws Exception
	 */
	public String decrypt(String encryptedData, VoltageEfpeFormatType formatType) throws ToolkitException, VeException {

		String decryptedData = null;

		if ("true".equals(enabler)) {

			if (CTX_INSTANCE == null) {
				logInfo("Voltage Libray is Null in decrypt, Library Context Initialized Again.");
				getLibraryContext();
			}

			String dec_pb64 = null;
			FPE fpeDecObj = null;
			fpeDecObj = (FPE) hmFPE.get(formatType.name());

			if ((formatType.name()).equals(VoltageEfpeFormatType.B64_GENERIC.name())) {
				dec_pb64 = fpeDecObj.access(encryptedData).replace(':', ' ').trim();
				byte[] b_strd;
				byte[] b64_b_strd;
				b64_b_strd = dec_pb64.getBytes();
				boolean ignoreInvalidChars = true;
				b_strd = CTX_INSTANCE.base64Decode(new String(b64_b_strd), ignoreInvalidChars);
				decryptedData = new String(b_strd);
			} else {
				decryptedData = fpeDecObj.access(encryptedData);
			}
		} else {
			decryptedData = encryptedData;
		}
		return decryptedData;
	}

	/**
	 * 
	 * Encode the input string using Voltage Base64
	 * 
	 */

	public String encode(String data) {

		String encodeData = data;

		try {
			boolean wrapLines = false;
			encodeData = CTX_INSTANCE.base64Encode(data.getBytes(), wrapLines);
		} catch (VeException e) {
			byte[] byteArray = org.apache.commons.codec.binary.Base64.encodeBase64(data.getBytes());
			encodeData = new String(byteArray);
		}
		return encodeData;
	}

	/**
	 * 
	 * Decode the input string using Voltage Base64
	 * 
	 */

	public String decode(String data) {
		String decodeData = data;
		try {
			boolean ignoreInvalidChars = true;
			decodeData = new String(CTX_INSTANCE.base64Decode(data, ignoreInvalidChars));
		} catch (VeException e) {
			byte[] byteArray = org.apache.commons.codec.binary.Base64.decodeBase64(data.getBytes());
			decodeData = new String(byteArray);
		}
		return decodeData;
	}

	/**
	 * 
	 * Encode the input string using Voltage Base64
	 * 
	 */

	public String encryptEncode(String value, VoltageEfpeFormatType formatName) throws VeException, ToolkitException {
		return encode(encrypt(value, formatName));
	}

	public String encryptEncodeNoException(String value, VoltageEfpeFormatType formatType) {
		String encryptedData = value;
		try {
			encryptedData = encode(encrypt(value, formatType));
		} catch (VeException ve) {
			logStackTrace(ve, "Voltage Exception @ encryptEncode");
		} catch (ToolkitException e) {
			logStackTrace("encryptEncodeNoException - Exception : " + e);
		}
		return encryptedData;
	}

	/**
	 * 
	 * Decode the input string using Voltage Base64
	 * 
	 */

	public String decodeDecrypt(String value, VoltageEfpeFormatType formatName) throws VeException, ToolkitException {
		return decrypt(decode(value), formatName);
	}

	public String decodeDecryptNoException(String value, VoltageEfpeFormatType formatType) {
		String decryptedData = value;
		try {
			decryptedData = decrypt(decode(value), formatType);
		} catch (VeException ve) {
			logStackTrace(ve, "Voltage Exception");
		} catch (ToolkitException e) {
			logStackTrace("decodeDecryptNoException - Exception : " + e);
		}
		return decryptedData;
	}

	public void logStackTrace(Exception ve, String errorMessage) {
		if (null != ve) {
			String description = "ToolkitException : " + ve.getMessage() + "; Error Message : " + errorMessage;
			LOG.error(description, ve);
		} else {
			LOG.error(errorMessage);
		}
	}

	public void logStackTrace(String errorMessage) {
		LOG.error(errorMessage);

	}

	public static void logInfo(String message) {
		LOG.info(message);
	}

	/**
	 * 
	 * Delete the Voltage Library context
	 * 
	 * @return
	 * 
	 */
	public static void destroy() {
		if (CTX_INSTANCE != null) {

			deleteFBE();
			CTX_INSTANCE.delete();
			logInfo("Voltage clean up done");
		}
	}

	/**
	 * 
	 * Delete the Voltage fpe objects
	 * 
	 */

	public static void deleteFBE() {
		for (Map.Entry<String, FPE> entry : hmFPE.entrySet()) {
			FPE efpe = (FPE) entry.getValue();
			efpe.delete();
		}

		logInfo("Voltage FBE delete done");
	}


	public List<String> encryptAll(List<String> formatValue, String formatType) {
		List<String> encryptedData = new ArrayList<String>();

		try {
			for (String value : formatValue) {
				String result = encrypt(value, VoltageEfpeFormatType.valueOf(formatType));
				encryptedData.add(result);
			}

		} catch (ToolkitException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return encryptedData;
	}

	public List<String> decryptAll(List<String> formatValue, String formatType) {
		List<String> decryptedData = new ArrayList<String>();
		try {
			for (String value : formatValue) {
				String result = decrypt(value, VoltageEfpeFormatType.valueOf(formatType));
				decryptedData.add(result);
			}
		} catch (ToolkitException e) {
			e.printStackTrace();
		} catch (VeException e) {
			e.printStackTrace();
		}
		return decryptedData;
	}
}
