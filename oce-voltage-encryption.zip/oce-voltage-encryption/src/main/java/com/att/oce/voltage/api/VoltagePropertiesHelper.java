package com.att.oce.voltage.api;

import java.util.Properties;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VoltagePropertiesHelper {

	private static final Logger LOG = LoggerFactory.getLogger(VoltagePropertiesHelper.class);

	private String keyCacheDir;
	private String trustStoreDir;
	private String keyServerURL;
	private String mechId;
	private String passWord;
	private String FPEIdentity;
	private String FPEPCIIdentity;
	private String EMPFPEIdentity;
	private String enabler;
	private StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
	
	public VoltagePropertiesHelper(Properties props) {
		
			encryptor.setPassword("oce-cxf");
			this.keyServerURL = props.getProperty("voltage.key.server.url");
			this.keyCacheDir = props.getProperty("voltage.storage.path");
			this.trustStoreDir = props.getProperty("voltage.trust.store.path");
			this.mechId = props.getProperty("voltage.mech.id");
			this.passWord = props.getProperty("voltage.password");
			this.FPEIdentity = props.getProperty("voltage.identity.cust.id");
			this.FPEPCIIdentity = props.getProperty("voltage.identity.cust.pci");
			this.EMPFPEIdentity = props.getProperty("voltage.identity.emp.id");
			this.enabler = props.getProperty("voltage.enable");
		
	}

	/**
	 * @return the enabler
	 */
	public String getEnabler() {
		return enabler;
	}

	/**
	 * @param enabler
	 *            the enabler to set
	 */
	public void setEnabler(String enabler) {
		this.enabler = enabler;
	}

	/**
	 * @return the keyCacheDir
	 */
	public String getKeyCacheDir() {
		return keyCacheDir;
	}

	/**
	 * @param keyCacheDir
	 *            the keyCacheDir to set
	 */
	public void setKeyCacheDir(String keyCacheDir) {
		this.keyCacheDir = keyCacheDir;
	}

	/**
	 * @return the trustStoreDir
	 */
	public String getTrustStoreDir() {
		return trustStoreDir;
	}

	/**
	 * @param trustStoreDir
	 *            the trustStoreDir to set
	 */
	public void setTrustStoreDir(String trustStoreDir) {
		this.trustStoreDir = trustStoreDir;
	}

	/**
	 * @return the keyServerURL
	 */
	public String getKeyServerURL() {
		return keyServerURL;
	}

	/**
	 * @param keyServerURL
	 *            the keyServerURL to set
	 */
	public void setKeyServerURL(String keyServerURL) {
		this.keyServerURL = keyServerURL;
	}

	/**
	 * @return the mechId
	 */
	public String getMechId() {
		return mechId;
	}

	/**
	 * @param mechId
	 *            the mechId to set
	 */
	public void setMechId(String mechId) {
		this.mechId = mechId;
	}

	/**
	 * @return the passWord
	 * in case the encrypted string is invalid it will return the same string passed to it.
	 */
	public String getPassWord() {
		try{
		
		return encryptor.decrypt(passWord);
		}catch(Exception e){
			LOG.error("Error in getPassWord() : "+e);
			return passWord;
		}
	}


	/**
	 * @param passWord
	 *            the passWord to set
	 */
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	/**
	 * @return the fPEIdentity
	 */
	public String getFPEIdentity() {
		return FPEIdentity;
	}

	/**
	 * @param fPEIdentity
	 *            the fPEIdentity to set
	 */
	public void setFPEIdentity(String fPEIdentity) {
		FPEIdentity = fPEIdentity;
	}

	/**
	 * @return the fPEPCIIdentity
	 */
	public String getFPEPCIIdentity() {
		return FPEPCIIdentity;
	}

	/**
	 * @param fPEPCIIdentity
	 *            the fPEPCIIdentity to set
	 */
	public void setFPEPCIIdentity(String fPEPCIIdentity) {
		FPEPCIIdentity = fPEPCIIdentity;
	}

	/**
	 * @return the eMPFPEIdentity
	 */
	public String getEMPFPEIdentity() {
		return EMPFPEIdentity;
	}

	/**
	 * @param eMPFPEIdentity
	 *            the eMPFPEIdentity to set
	 */
	public void setEMPFPEIdentity(String eMPFPEIdentity) {
		EMPFPEIdentity = eMPFPEIdentity;
	}

}
