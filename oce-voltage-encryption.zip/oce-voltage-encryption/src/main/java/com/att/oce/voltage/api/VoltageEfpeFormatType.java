/* 
 * Copyright 2009 AT&T Inc.
 * All Rights Reserved
 *
 * This software is the confidential and proprietary information
 * of AT&T. Unauthorized copying, adaptation, distribution,
 * use, or display is prohibited.
 */
package com.att.oce.voltage.api;

/**
 * Enum Added with EFPE Format Types mapped.
 * 
 * @author
 */

public enum VoltageEfpeFormatType {
	CC_NUM("1"), CC_VARNUM("2"), ALLNUM_SSN("3"), ALPHANUM_SSN("4"), DRIVER_LIC_NUM("5"), BIRTH_DATE("6"), ALLNUM_PIN(
			"7"), ALPHANUM_PIN("8"), PSWD_HINT("9"), MOBILITY_LOC("10"), GENERIC_STRING("11"), GENERIC_STRING_PCI(
					"12"), BANK_NUM("13"), B64_GENERIC("14"), CV_ALLNUM_PIN("15"), SO_GENERIC_SHORT("16"), LPI_DATA(
							"17"), ALPHA_NUM("18"), CC_EXP("19"), CC_NAME("20");
	private String efpeFormatEnum;

	/**
	 * AccountType
	 * 
	 * @param accountType
	 *            String
	 */
	VoltageEfpeFormatType(String efpeFormatEnum) {
		this.efpeFormatEnum = efpeFormatEnum;
	}

	/**
	 * getAccountType
	 * 
	 * @return String
	 */
	public String getEfpeFormatEnum() {
		return efpeFormatEnum;
	}
}
