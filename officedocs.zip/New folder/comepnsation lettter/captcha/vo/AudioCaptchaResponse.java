package com.att.unlock.captcha.vo;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <b>Name:</b> AudioCaptchaResponse <b>Purpose:</b>This class is designed
 * for Audio captcha response.
 * 
 * @author VS00343711
 */
@XmlRootElement
public class AudioCaptchaResponse {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private ServiceStatus serviceStatus;
    private CaptchaDetail captchaDetail;

    /**
     * Default constructor
     */
    public AudioCaptchaResponse() {

    }

    /**
     * @param serviceStatus
     * @param imeiDetail
     */
    public AudioCaptchaResponse(ServiceStatus serviceStatus,
            CaptchaDetail captchaDetail) {
        this.serviceStatus = serviceStatus;
        this.captchaDetail = captchaDetail;
    }

    /**
     * @return serviceStatus
     */
    public ServiceStatus getServiceStatus() {
        return serviceStatus;
    }

    /**
     * @param serviceStatus
     *            the serviceStatus to set
     */
    public void setServiceStatus(ServiceStatus serviceStatus) {
        this.serviceStatus = serviceStatus;
    }

    /**
     * @return imeiDetail
     */
    public CaptchaDetail getCaptchaDetail() {
        return captchaDetail;
    }

    /**
     * @param imeiDetail
     *            the imeiDetail to set
     */
    public void setCaptchaDetail(CaptchaDetail captchaDetail) {
        this.captchaDetail = captchaDetail;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "AudioCaptchaResponse [serviceStatus=" + serviceStatus
                + ", captchaDetail=" + captchaDetail + "]";
    }

}
