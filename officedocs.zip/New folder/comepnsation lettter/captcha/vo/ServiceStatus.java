package com.att.unlock.captcha.vo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * <b>Name:</b> ServiceStatus <b>Purpose:</b>This class is designed
 * for service  status.
 * @author VS00343711
 *
 */
@XmlRootElement
public class ServiceStatus {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private String code;
    private String description;

    /**
     * Default Constructor
     */
    public ServiceStatus() {
        super();
    }

    /**
     *
     * @param code
     * @param description
     */
    public ServiceStatus(String code, String description) {
        super();
        this.code = code;
        this.description = description;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code
     *            the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Code: " + code + ", Description: " + description;
    }

}
