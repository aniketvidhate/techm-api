/**
 *
 */
package com.att.unlock.captcha.vo;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <b>Name:</b> CaptchaDetail <b>Purpose:</b>This class is designed
 * for captcha details.
 * 
 * @author VV00124304
 */
@XmlRootElement
public class CaptchaDetail {

    /**
    *
    */
    private static final long serialVersionUID = 1L;

    private String captchaID;
    private String captchaChallenge;
    private String captchaRefId;

    public CaptchaDetail() {

    }
    
    /**
     * @return the captchaRefId
     */
    public String getCaptchaRefId() {
        return captchaRefId;
    }


    /**
     * @param captchaRefId
     *            the captchaRefId to set
     */
    public void setCaptchaRefId(String captchaRefId) {
        this.captchaRefId = captchaRefId;
    }



    /**
     * @return the captchaID
     */
    public String getCaptchaID() {
        return captchaID;
    }

    /**
     * @param captchaID
     *            the captchaID to set
     */
    public void setCaptchaID(String captchaID) {
        this.captchaID = captchaID;
    }

    /**
     * @return the captchaChallenge
     */
    public String getCaptchaChallenge() {
        return captchaChallenge;
    }

    /**
     * @param captchaChallenge
     *            the captchaChallenge to set
     */
    public void setCaptchaChallenge(String captchaChallenge) {
        this.captchaChallenge = captchaChallenge;
    }

}
