/**
 *
 */
package com.att.unlock.captcha.vo;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <b>Name:</b> ImageCaptchaRequest <b>Purpose:</b>This class is designed
 * for image captcha request.
 *
 * @author VV00124304
 */
@XmlRootElement
public class ImageCaptchaRequest {

    /**
    *
    */
    private static final long serialVersionUID = 1L;
    private String captchaType;

    /**
     * Default constructor
     */
    public ImageCaptchaRequest() {

    }

    /**
     * Parameterized Constructor
     *
     * @param capcthaType
     */
    public ImageCaptchaRequest(String captchaType) {
        this.captchaType = captchaType;
    }



    /**
     * @return the captchaType
     */
    public String getCaptchaType() {
        return captchaType;
    }

    /**
     * @param captchaType the captchaType to set
     */
    public void setCaptchaType(String captchaType) {
        this.captchaType = captchaType;
    }

    /*
     * (non-Javadoc)
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ImageCaptchaRequest [captchaType=" + captchaType + "]";
    }
}
