package com.att.unlock.captcha.util;

/**
 * <b>Name:</b> UnlockApplicationException.
 * <b>Purpose:</b>This class is designed to generate
 *  unlock application exception exception.
 *  @author SS00349933
 *
 */
public class UnlockApplicationException extends Exception {
    /**
    *
    */
    private static final long serialVersionUID = 1L;

    /**
    *
    */
    private String message = null;

    /**
    *
    */
    private String errorCode = "";

    /**
     * <b>Name:</b> UnlockApplicationException class constructor.
     */
    public UnlockApplicationException() {
        super();
    }

    /**
     * <b>Name:</b> UnlockApplicationException class constructor.
     * @param messagee as String
     */
    public UnlockApplicationException(final String messagee) {
        super(messagee);
        this.message = messagee;
    }

    /**
     * <b>Name:</b> UnlockApplicationException class constructor.
     * @param cause as Throwable
     */
    public UnlockApplicationException(final Throwable cause) {
        super(cause);
    }

    /**
     * <b>Name:</b> UnlockApplicationException class constructor.
     * @param cause as Throwable
     * @param errorCodee as String
     */
    public UnlockApplicationException(final Throwable cause,
            final String errorCodee) {
        super(cause);
        this.errorCode = errorCodee;
    }

    @Override
    public final String toString() {
        return message;
    }

    @Override
    public final String getMessage() {
        return message;
    }

    /**
     * @return the errorCode
     */
    public final String getErrorCode() {
        return errorCode;
    }

    /**
     * @param errorCodee
     *            the errorCode to set
     */
    public final void setErrorCode(final String errorCodee) {
        this.errorCode = errorCodee;
    }

    /**
     * @param messagee
     *            the message to set
     */
    public final void setMessage(final String messagee) {
        this.message = messagee;
    }
}
