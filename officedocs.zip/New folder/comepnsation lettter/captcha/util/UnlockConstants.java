package com.att.unlock.captcha.util;

/**
 * <b>Name:</b> UnlockConstants <b>Purpose:</b> It is an interface is designed
 * to contain constant.
 *
 * @author VV00124304
 *
 */

public final class UnlockConstants {

    /**
    *
    */
    private UnlockConstants() {
    }

    /**
     *
     */
    public static final String PROPERTIES_FILE = "/ApplicationResources.properties";
    /**
     *
     */
    public static final String ERROR_STR = "error";

    /**
     *
     */
    public static final String SERVICELOG_STR = "serviceLog";

    /**
     *
     */
    public static final String IMEI_CONTROLLER = "IMEIController";

    /**
    *
    */
   public static final String CSRF_CONTROLLER = "CSRFController";

    /**
     *
     */
    public static final String EMAIL_CONTROLLER = "EmailController";

    /**
     *
     */
    public static final String PAYMENT_CONTROLLER = "PaymentController";

    /**
     *
     */
    public static final String ORDER_CONTROLLER = "OrderController";

    /**
    *
    */
    public static final String TAX_CONTROLLER = "TaxController";

    /**
     *
     */
    public static final String UNLOCK_EXCEPTION_UTIL = "UnlockExceptionUtil";

    /**
    *
    */
   public static final String CSRF_TOKEN_INTERCEPTOR = "CSRFTokenInterceptor";

    /**
     *
     */
    public static final String REQUEST = "Request--------";

    /**
     *
     */
    public static final String RESPONSE = "Response--------";

    /**
     *
     */
    public static final String LOG_ENABLE = "log_enable";

    /**
     *
     */
    public static final String BLANK = "";

    /**
     *
     */
    public static final int ONE = 1;

    /**
     *
     */
    public static final int TWO = 2;

    /**
     *
     */
    public static final int ZERO = 0;

    /**
     *
     */
    public static final String STATUS_CODE_TWO = "2";

    /**
     *
     */
    public static final String FAILURE = "FAILURE";

    /**
     *
     */
    public static final String SUCCESS = "SUCCESS";

    /**
     *
     */
    public static final String INVALID_EMAIL_ERROR_CODE = "ULP_1010";

    /**
     *
     */
    public static final String INVALID_EMAIL_ERROR_DESC = "Enter a secure Email Address.";

    /**
     *
     */
    public static final int RESPONSE_CODE = 200;

    /**
    *
    */
    public static final int MAX_AGE = 1209600;

    /**
    *
    */
    public static final String UNLOCK_BUNDLE_ACTIVATOR = "UnlockBundleActivator";

    /**
    *
    */
    public static final String NON_ATT_CUSTOMER = "Non AT&T customer";

    /**
    *
    */
    public static final String GO_PHONE = "GoPhone";

    /**
    *
    */
    public static final int FIFTEEN = 15;

    /**
    *
    */
    public static final int TEN = 10;

    /**
     *
     */
    public static final String SYSTEM_ERROR_CODE = "2";
    /**
     *
     */
    public static final String SYSTEM_ERROR_MESSAGE = "Failure";
    /**
     *
     */
    public static final String ORDER_NUMBER = "123456";

    /**
     *
     */
    public static final String EMAIL_VALIDATOR = "EmailValidator";
    /**
     *
     */
    public static final String IMEI_VALIDATOR = "IMEIValidator";
    /**
     *
     */
    public static final String ORDER_VALIDATOR = "OrderValidator";
    /**
     *
     */
    public static final String PAYMENT_VALIDATOR = "PaymentValidator";
    /**
     *
     */
    public static final String TAX_VALIDATOR = "TAXValidator";
    /**
     *
     */
    public static final String UNLOCK_VALIDATOR = "UnlockValidator";

    /**  */
    public static final String APPLICATION = "application";

    /** */
    public static final String SECURITY_GATEWAY_ENABLE = "security.gateway.enable";

    /**  */
    public static final String CSRF_CALLS_PER_TOKEN  = "csrf.callspertoken";

    /** */
    public static final String CSRF_TOKEN_TTL  = "csrf.ttl";

    /**  */
    public static final String CSRF_GUARD_JS  = "csrfguard.js";

    /**
    *
    */
   public static final String CSRF_TOKEN = "OWASP_CSRFTOKEN";

   /**
   *
   */
   public static final String IN_VALID = "inValid";

   /**
   *
   */
   public static final String INVALID_TOKEN_ERROR_CODE = "ULS_3001";

   /**
   *
   */
  public static final String INVALID_TOKEN_ERROR_DESC = "We\u2019re sorry, but we\u2019re having "
        + "technical difficulties with our network at the moment. Please try again later.\n\nIf this problem persists, "
        + "try clearing the cache and cookies from your device.\n\nQuestions? Call us at <strong>800.331.0500<\\/strong>, "
        + "or dial <strong>611<\\/strong> from your AT&T wireless phone.\\n(errorCode.ULS3001)";

  /**  */
  public static final String AUDIO_CONTROLLER = "AudioController";

  /**  */
  public static final String IMAGE_CONTROLLER = "ImageController";

  /**  */
  public static final String UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL = "UnlockCaptchaValidatorServiceImpl";

  /**  */
  public static final String METHOD_GET = "GET";

  /**  */
  public static final String OWASP_CSRFTOKEN = "OWASP-CSRFTOKEN";

  /**  */
  public static final String CAPTCHA_TYPE_IMAGE = "image";

  /**  */
  public static final String CAPTCHA_TYPE_AUDIO = "audio";
  
}
