package com.att.unlock.captcha.util;

import org.apache.log4j.Logger;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;



/**
 * <b>Name:</b> UnlockBundleActivator. <b>Purpose:</b> Activator class for this bundle.
 * Will start and stop the bundle during
 * deployment and undeployment.
 *
 * @author VV00124304
 *
 */
public class UnlockBundleActivator implements BundleActivator {

    /** Declaration of the logger */
    public final static Logger LOG = Logger
            .getLogger(UnlockBundleActivator.class);

    /**
     * Method to start the bundle context
     *
     * @param context
     *            as BundleContext
     * @return void
     */
    public void start(BundleContext context) throws Exception {
        String voices = System.getProperty("freetts.voices");
        if (voices == null || ("").equals(voices.trim())) {
             System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_time_awb.AlanVoiceDirectory,com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");
             LOG.info("set freetts.voices property");
        }
        System.setProperty("file.encoding", "Cp1252");
        LOG.info("Starting the bundle captcha:UnlockBundleActivator");
    }

    /**
     * Method to stop the bundle context
     *
     * @param context
     *            as BundleContext
     * @return void
     */
    public void stop(BundleContext context) {
        LOG.info("Stopping the bundle captcha:UnlockBundleActivator");
    }

}