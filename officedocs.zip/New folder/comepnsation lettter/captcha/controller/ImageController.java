package com.att.unlock.captcha.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.DatatypeConverter;

import org.apache.cxf.interceptor.InInterceptors;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;
import org.apache.cxf.transport.http.Headers;
import org.apache.log4j.Logger;

import com.att.unlock.base.util.UnlockCollectionUtil;
import com.att.unlock.base.util.UnlockCryptoUtil;
import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.captcha.service.UnlockCaptchaService;
import com.att.unlock.captcha.util.UnlockConstants;
import com.att.unlock.captcha.vo.CaptchaDetail;
import com.att.unlock.captcha.vo.ImageCaptchaRequest;
import com.att.unlock.captcha.vo.ImageCaptchaResponse;
import com.att.unlock.captcha.vo.ServiceStatus;
import com.octo.captcha.service.CaptchaServiceException;

/**
 * <b>Name:</b> ImageController. <b>Purpose:</b>This class is designed as a
 * controller for Image captcha service for getting the captcha image.
 *
 * @author VV00124304
 */
@CrossOriginResourceSharing(allowAllOrigins = true, allowCredentials = true, maxAge = 1209600, allowHeaders = { })
@InInterceptors(interceptors = { "com.att.unlock.captcha.util.CSRFTokenInterceptor" })
@Path("/image")
public class ImageController {
    /** Declaration of the logger */
    public final static Logger LOG = Logger.getLogger(ImageController.class);

    /**
     * Message to handle csrf token.
     */
    private Message message;

    /**
     * <b>Name:</b> getImageCaptcha. <b>Purpose:</b>This method is used for
     * image captcha service for image in json format.
     * @param imageCaptchaRequest
     * @return ImageCaptchaResponse
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final ImageCaptchaResponse getImageCaptcha(
            final ImageCaptchaRequest imageCaptchaRequest) {
        UnlockLogUtil.endPointInfo(UnlockConstants.IMAGE_CONTROLLER,
                "getImageCaptcha", UnlockConstants.REQUEST);
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.IMAGE_CONTROLLER,
                "getImageCaptcha", UnlockConstants.REQUEST, imageCaptchaRequest);

        ImageCaptchaResponse captchaResponse = null;

        ByteArrayOutputStream imgOutputStream = new ByteArrayOutputStream();
        String captchaId;
        byte[] captchaBytes;
        String csrfToken = null;
        String reqId = null;
        String capchaRefId = null;
        String rawText = null;
        String csrfTokenValue = null;
        
        try {
             message = JAXRSUtils.getCurrentMessage();
            if (null != message) {
               // csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
                reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.IMAGE_CONTROLLER,"getImageCaptcha");
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)
                    && validateRequest(imageCaptchaRequest)) {
                
                //Retrieving CSRF token Id
                 List<String> csrfs=Headers
                         .getSetProtocolHeaders(message).get("OWASP-CSRFTOKEN");
                 if(!UnlockCollectionUtil.isEmptyList(csrfs)){
                     csrfTokenValue = csrfs.get(0);
                 } 
                  UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                         "OrderFlowRequestDO", "csrfToken:" + csrfToken);

                // This ID is used to identify the particular captcha.
                captchaId = String
                        .valueOf(new Random().nextInt(900000) + 10000);
                reqId = reqId + ":captchaId:" + captchaId;
                // Generate the captcha image.
                LOG.info("In getImageCaptcha: " + reqId);
                BufferedImage challengeImage = UnlockCaptchaService
                        .getImageInstance().getImageChallengeForID(captchaId);
                ImageIO.write(challengeImage, "png", imgOutputStream);
                captchaBytes = imgOutputStream.toByteArray();

                // Prepare captcha response in JSON
                String encodedImage = DatatypeConverter
                        .printBase64Binary(captchaBytes);
                
                //Encrptying csrfToken + captcha
                rawText = csrfTokenValue + "~" + captchaId;
                capchaRefId = UnlockCryptoUtil.encrypt(rawText); 

                captchaResponse = prepareImageResponse(captchaId, encodedImage, capchaRefId);
            } else {
                captchaResponse = prepareErrorResponse();
            }

        } catch (CaptchaServiceException | IOException cse) {
             UnlockLogUtil.errorInfo(UnlockConstants.IMAGE_CONTROLLER,
                     "getImageCaptcha", "[Exception caught: Class "
                             + UnlockConstants.IMAGE_CONTROLLER + " : method : "
                             + "getImageCaptcha" + reqId + "]",
                     UnlockExceptionUtil.generateStackTraceString(cse));
            captchaResponse = prepareErrorResponse();
        } catch (Exception ioe) {
             UnlockLogUtil.errorInfo(UnlockConstants.IMAGE_CONTROLLER,
                     "getImageCaptcha", "[Exception caught: Class "
                             + UnlockConstants.IMAGE_CONTROLLER + " : method : "
                             + "getImageCaptcha" + reqId + "]",
                     UnlockExceptionUtil.generateStackTraceString(ioe));
            captchaResponse = prepareErrorResponse();
        }
        // logging the response
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.IMAGE_CONTROLLER,
                "getImageCaptcha", reqId + UnlockConstants.RESPONSE, captchaResponse);
        UnlockLogUtil.endPointInfo(UnlockConstants.IMAGE_CONTROLLER,
                "getImageCaptcha", UnlockConstants.RESPONSE);
        return captchaResponse;
    }
    
    
    /**
     * <b>Name:</b> getImageCaptcha. <b>Purpose:</b>This method is
     * return image captcha in png format for the input captchaID as
     * a path parameter.
     * @param captchaId ID is used to identify the particular captcha.
     * @return bytes[]
     */
    @GET
    @Path("/{captchaId}")
    @Produces("image/png")
    public final byte[] getImageCaptcha(@PathParam("captchaId") String captchaId) {
        UnlockLogUtil.endPointInfo(UnlockConstants.IMAGE_CONTROLLER,
                "getImageCaptcha", UnlockConstants.REQUEST);
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.IMAGE_CONTROLLER,
                "getImageCaptcha", UnlockConstants.REQUEST, captchaId);
        ByteArrayOutputStream imgOutputStream = new ByteArrayOutputStream();
        byte[] captchaBytes = null;
        String csrfToken = null;
        String reqId = null;

        try {
             message = JAXRSUtils.getCurrentMessage();
            if (null != message) {
                csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
                reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.IMAGE_CONTROLLER,"getImageCaptcha:captchaId");
                reqId = reqId + ":captchaId:" + captchaId;
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)
                    && UnlockStringUtil.isNotEmpty(captchaId)
                    && captchaId.trim().matches("[0-9]+")) {
                // Generate the captcha image.
                LOG.info("In getImageCaptcha: " + captchaId + "and" + reqId);
                BufferedImage challengeImage = UnlockCaptchaService
                        .getImageInstance().getImageChallengeForID(
                                captchaId.trim());
                ImageIO.write(challengeImage, "png", imgOutputStream);
                captchaBytes = imgOutputStream.toByteArray();

            } else {
                captchaBytes = new byte[] {};
            }

        } catch (CaptchaServiceException | IOException cse) {
            UnlockLogUtil.errorInfo(UnlockConstants.IMAGE_CONTROLLER,
                    "getImageCaptcha", "[Exception caught: Class "
                            + UnlockConstants.IMAGE_CONTROLLER + " : method : "
                            + "getImageCaptcha" + reqId + "]",
                    UnlockExceptionUtil.generateStackTraceString(cse));
            captchaBytes = new byte[] {};
        } catch (Exception ioe) {
            UnlockLogUtil.errorInfo(UnlockConstants.IMAGE_CONTROLLER,
                    "getImageCaptcha", "[Exception caught: Class "
                            + UnlockConstants.IMAGE_CONTROLLER + " : method : "
                            + "getImageCaptcha" + reqId + "]",
                    UnlockExceptionUtil.generateStackTraceString(ioe));
            captchaBytes = new byte[] {};
        }
        // logging the response
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.IMAGE_CONTROLLER,
                "getImageCaptcha", reqId + UnlockConstants.RESPONSE, captchaId);
        UnlockLogUtil.endPointInfo(UnlockConstants.IMAGE_CONTROLLER,
                "getImageCaptcha", UnlockConstants.RESPONSE);
        return captchaBytes;
    }

    /**
     * This method prepare ImageCaptchaResponse when there is no any error.
     *
     * @param captchaID
     * @param imgString
     * @return ImageCaptchaResponse
     */
    private ImageCaptchaResponse prepareImageResponse(String captchaID,
            String imgString, String capchaRefId) {
        ImageCaptchaResponse imageCaptchaResponse = new ImageCaptchaResponse();

        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(String.valueOf(UnlockConstants.ZERO));
        serviceStatus.setDescription(UnlockConstants.SUCCESS);

        CaptchaDetail captchaDetail = new CaptchaDetail();
        captchaDetail.setCaptchaID(captchaID);
        captchaDetail.setCaptchaChallenge(imgString);
        captchaDetail.setCaptchaRefId(capchaRefId);

        imageCaptchaResponse.setServiceStatus(serviceStatus);
        imageCaptchaResponse.setCaptchaDetail(captchaDetail);

        return imageCaptchaResponse;
    }

    /**
     * This method  prepare ImageCaptchaResponse in case any exception occurs.
     *
     * @return ImageCaptchaResponse
     */
    private ImageCaptchaResponse prepareErrorResponse() {
        ImageCaptchaResponse imageCaptchaResponse = new ImageCaptchaResponse();

        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);

        CaptchaDetail captchaDetail = new CaptchaDetail();
        captchaDetail.setCaptchaID("");
        captchaDetail.setCaptchaChallenge("");

        imageCaptchaResponse.setServiceStatus(serviceStatus);
        imageCaptchaResponse.setCaptchaDetail(captchaDetail);

        return imageCaptchaResponse;
    }


    /**
     * Used for checking the null request and the captcha type.
     * @param imageCaptchaRequest
     * @return boolean
     */
    private boolean validateRequest(ImageCaptchaRequest imageCaptchaRequest) {
        if (null != imageCaptchaRequest) {
            return UnlockStringUtil.isEquals(imageCaptchaRequest.getCaptchaType().trim(),
                    UnlockConstants.CAPTCHA_TYPE_IMAGE);
        } else {
            return false;
        }
    }

    /**
     * @return the message
     */
    public Message getMessage() {
        return message;
    }

    /**
     * @param message
     *            the message to set
     */
    public void setMessage(Message message) {
        this.message = message;
    }
    
    /**
     * @return
     */
    private String getRemoteIp(Message message,String className,String methodName) {
        String remoteIPAddress;
        HttpServletRequest request = (HttpServletRequest)message.get("HTTP.REQUEST");
        
        if (request == null){
            UnlockLogUtil.errorInfo(className,
                    methodName, UnlockConstants.REQUEST,
            "request is null from message! ");
        }
        remoteIPAddress = request.getHeader("X-Real-IP");
        if (remoteIPAddress == null) {
            String ips = request.getHeader("X-Forwarded-For");
            if (ips != null) {
                remoteIPAddress = ips.split(",")[0];
            }
            else {
                 remoteIPAddress = request.getRemoteAddr();
            }
        }
        return remoteIPAddress;
    }
    
}
