package com.att.unlock.captcha.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Random;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.codec.binary.Base64;
import org.apache.cxf.interceptor.InInterceptors;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;
import org.apache.cxf.transport.http.Headers;

import com.att.unlock.base.util.UnlockCollectionUtil;
import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.captcha.service.UnlockCaptchaService;
import com.att.unlock.captcha.util.UnlockConstants;
import com.att.unlock.captcha.vo.AudioCaptchaRequest;
import com.att.unlock.captcha.vo.AudioCaptchaResponse;
import com.att.unlock.captcha.vo.CaptchaDetail;
import com.att.unlock.captcha.vo.ServiceStatus;
import com.octo.captcha.service.CaptchaServiceException;

import javax.servlet.http.HttpServletRequest;

/**
 * <b>Name:</b> ImageController. <b>Purpose:</b>This class is designed as a
 * controller for Image captcha service for getting the captcha image.
 *
 * @author VV00124304
 */
@CrossOriginResourceSharing(allowAllOrigins = true, allowCredentials = true, maxAge = 1209600, allowHeaders = { })
@InInterceptors(interceptors = { "com.att.unlock.captcha.util.CSRFTokenInterceptor" })
@Path("/sound")
public class AudioController {

    /**
     * Message to handle csrf token.
     */
    private Message message;
    
    private static String privateKey= "!@#$%)(&^)";

    /**
     * <b>Name:</b> getSoundCaptcha. <b>Purpose:</b>This method is exposed as a web
     * service which will return sound in json format.
     * @param imageCaptchaRequest
     * @return ImageCaptchaResponse
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final AudioCaptchaResponse getSoundCaptcha(
            final AudioCaptchaRequest audioCaptchaRequest) {
         UnlockLogUtil.endPointInfo(UnlockConstants.AUDIO_CONTROLLER,
                 "getSoundCaptcha", UnlockConstants.REQUEST);

         UnlockLogUtil.endPointDebugInfo(UnlockConstants.AUDIO_CONTROLLER,
                   "getSoundCaptcha", UnlockConstants.REQUEST, audioCaptchaRequest);

        AudioCaptchaResponse captchaResponse = null;

        ByteArrayOutputStream soundOutputStream = new ByteArrayOutputStream();
        String captchaId;
        byte[] captchaBytes;
        String csrfToken = null;
        String reqId = null;
        String capchaRefId = null;
        String rawText = null;
        String csrfTokenValue = null;
        try {
             message = JAXRSUtils.getCurrentMessage();
            if (null != message) {
                csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
                reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.AUDIO_CONTROLLER,"getSoundCaptcha");
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)
                    && validateRequest(audioCaptchaRequest)) {
            	
            	//Retrieving CSRF token Id
                List<String> csrfs=Headers
                        .getSetProtocolHeaders(message).get("OWASP-CSRFTOKEN");
                if(!UnlockCollectionUtil.isEmptyList(csrfs)){
                    csrfTokenValue = csrfs.get(0);
                } 
                
                // This ID is used to identify the particular captcha.
                captchaId = String
                        .valueOf(new Random().nextInt(900000) + 10000);
                reqId = reqId + ":captchaId:" + captchaId;
                // call the AudioCaptchaService getChallenge method to get
                // audio.
                AudioInputStream challangeAudio = UnlockCaptchaService
                        .getAudioInstance().getSoundChallengeForID(captchaId);

                AudioSystem.write(challangeAudio,
                        javax.sound.sampled.AudioFileFormat.Type.WAVE,
                        soundOutputStream);

                captchaBytes = soundOutputStream.toByteArray();

                // Prepare captcha response in JSON
                String encodedAudio = DatatypeConverter
                        .printBase64Binary(captchaBytes);
                
              //Encrptying csrfToken + captcha
                rawText = csrfTokenValue + "~" + captchaId;
                capchaRefId = encrypt(rawText); 
                
                captchaResponse = prepareSoundResponse(captchaId, encodedAudio, capchaRefId);
            } else {
                captchaResponse = prepareErrorResponse();
            }
        } catch (Exception ioe) {
             UnlockLogUtil.errorInfo(UnlockConstants.AUDIO_CONTROLLER,
                     "getSoundCaptcha", "[Exception caught: Class "
                             + UnlockConstants.AUDIO_CONTROLLER + " : method : "
                             + "getSoundCaptcha" + reqId + "]",
                     UnlockExceptionUtil.generateStackTraceString(ioe));
            captchaResponse = prepareErrorResponse();
        }
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.AUDIO_CONTROLLER,
                "getSoundCaptcha", reqId + UnlockConstants.RESPONSE, captchaResponse);
        // logging the response
        UnlockLogUtil.endPointInfo(UnlockConstants.AUDIO_CONTROLLER,
                "getSoundCaptcha", UnlockConstants.RESPONSE);
        return captchaResponse;
    }
    
    /**
     * Code to encrypt the raw text
     * @param rawText
     * @return
     * @throws InvalidKeyException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws IOException
     */
    public static String encrypt(String rawText) throws InvalidKeyException,
        IllegalBlockSizeException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, IOException {
        if (rawText == null)
            return null;
        byte[] toEncryptArray = rawText.getBytes("UTF-8");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, generateSecretKey(privateKey));
        byte[] encrypted = cipher.doFinal(toEncryptArray);
        return new String(URLEncoder.encode(
        new String(Base64.encodeBase64(encrypted)), "UTF-8"));
    }
    
   /**
    * Code to generate the secret Key.
    * @param privateKey
    * @return
    */
    public static SecretKeySpec generateSecretKey(String privateKey) {
        SecretKeySpec secretKey = null;
        try {
            MessageDigest mDigest = MessageDigest.getInstance("MD5");
        
        byte[] keyAsBytes;
        
            keyAsBytes = mDigest.digest(privateKey
                    .getBytes("UTF-8"));
            secretKey = new SecretKeySpec(keyAsBytes, "AES");
        } catch (UnsupportedEncodingException e) {
         //continue
          UnlockLogUtil.serviceDebugInfo(
                    "AudioController","AudioController", "Error in retrieving the private Key");
        } catch (Exception e) {  
            UnlockLogUtil.serviceDebugInfo(
                    "AudioController", "AudioController", "Error in retrieving the private Key");
        }
        return secretKey;
        
    }

    /**
     * <b>Name:</b> getSoundCaptcha. <b>Purpose:</b>This method is exposed as a web
     * service which will return sound in wav format for
     * the captcha ID provided as a path paramater.
     * @param captchaId ID is used to identify the particular captcha.
     * @return bytes[]
     */
    @GET
    @Path("/{captchaId}")
    @Produces("audio/wav")
    public final byte[] getSoundCaptcha(@PathParam("captchaId") String captchaId) {

        UnlockLogUtil.endPointInfo(UnlockConstants.AUDIO_CONTROLLER,
                 "getSoundCaptcha", UnlockConstants.REQUEST);
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.AUDIO_CONTROLLER,
                "getSoundCaptcha", UnlockConstants.REQUEST, captchaId);
        ByteArrayOutputStream soundOutputStream = new ByteArrayOutputStream();
        byte[] captchaBytes = null;
        String csrfToken = null;
        String reqId = null;
        try {
             message = JAXRSUtils.getCurrentMessage();
            if (null != message) {
                csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
                reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.AUDIO_CONTROLLER,"getSoundCaptcha"); 
                reqId = reqId + ":captchaId:" + captchaId;
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)
                    && UnlockStringUtil.isNotEmpty(captchaId)
                    && captchaId.trim().matches("[0-9]+")) {

                // Call the AudioCaptchaService getChallenge method to get
                // audio.
                AudioInputStream challangeAudio = UnlockCaptchaService
                        .getAudioInstance().getSoundChallengeForID(captchaId);

                AudioSystem.write(challangeAudio,
                        javax.sound.sampled.AudioFileFormat.Type.WAVE,
                        soundOutputStream);

                captchaBytes = soundOutputStream.toByteArray();

            } else {
                captchaBytes = new byte[] {};
            }
        } catch (CaptchaServiceException | IOException cse) {
             UnlockLogUtil.errorInfo(UnlockConstants.AUDIO_CONTROLLER,
                     "getSoundCaptcha", "[Exception caught: Class "
                             + UnlockConstants.AUDIO_CONTROLLER + " : method : "
                             + "getSoundCaptcha" + reqId + "]",
                     UnlockExceptionUtil.generateStackTraceString(cse));
            captchaBytes = new byte[] {};
        } catch (Exception exp) {
             UnlockLogUtil.errorInfo(UnlockConstants.AUDIO_CONTROLLER,
                     "getSoundCaptcha", "[Exception caught: Class "
                             + UnlockConstants.AUDIO_CONTROLLER + " : method : "
                             + "getSoundCaptcha" + reqId + "]",
                     UnlockExceptionUtil.generateStackTraceString(exp));
            captchaBytes = new byte[] {};
        }
        // logging the response
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.AUDIO_CONTROLLER,
                "getSoundCaptcha", reqId + UnlockConstants.RESPONSE, captchaBytes);
        UnlockLogUtil.endPointInfo(UnlockConstants.AUDIO_CONTROLLER,
                "getSoundCaptcha", UnlockConstants.RESPONSE);
        return captchaBytes;
    }

    /**
     * This method prepare AudioCaptchaResponse when there is no any error.
     * @param captchaID
     * @param audioString
     * @return AudioCaptchaResponse
     */
    private AudioCaptchaResponse prepareSoundResponse(String captchaID,
            String audioString, String capchaRefId) {
        AudioCaptchaResponse audioCaptchaResponse = new AudioCaptchaResponse();

        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(String.valueOf(UnlockConstants.ZERO));
        serviceStatus.setDescription(UnlockConstants.SUCCESS);

        CaptchaDetail captchaDetail = new CaptchaDetail();
        captchaDetail.setCaptchaID(captchaID);
        captchaDetail.setCaptchaChallenge(audioString);
        captchaDetail.setCaptchaRefId(capchaRefId);

        audioCaptchaResponse.setServiceStatus(serviceStatus);
        audioCaptchaResponse.setCaptchaDetail(captchaDetail);

        return audioCaptchaResponse;
    }

    /**
     * This method prepare AudioCaptchaResponse in case any exception occurs.
     * @return AudioCaptchaResponse
     */
    private AudioCaptchaResponse prepareErrorResponse() {
        AudioCaptchaResponse audioCaptchaResponse = new AudioCaptchaResponse();

        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);

        CaptchaDetail captchaDetail = new CaptchaDetail();
        captchaDetail.setCaptchaID("");
        captchaDetail.setCaptchaChallenge("");

        audioCaptchaResponse.setServiceStatus(serviceStatus);
        audioCaptchaResponse.setCaptchaDetail(captchaDetail);

        return audioCaptchaResponse;
    }

    /**
     * Used for checking the null request and the captcha type.
     * @param audioCaptchaRequest
     * @return boolean
     */
    private boolean validateRequest(AudioCaptchaRequest audioCaptchaRequest) {
        if (null != audioCaptchaRequest) {
            return UnlockStringUtil.isEquals(audioCaptchaRequest.getCaptchaType().trim(),
                    UnlockConstants.CAPTCHA_TYPE_AUDIO);
        } else {
            return false;
        }
    }

    /**
     * @return the message
     */
    public Message getMessage() {
        return message;
    }

    /**
     * @param message
     *            the message to set
     */
    public void setMessage(Message message) {
        this.message = message;
    }
    
    /**
     * @return
     */
    private String getRemoteIp(Message message,String className,String methodName) {
        String remoteIPAddress;
        HttpServletRequest request = (HttpServletRequest)message.get("HTTP.REQUEST");
        
        if (request == null){
            UnlockLogUtil.errorInfo(className,
                    methodName, UnlockConstants.REQUEST,
            "request is null from message! ");
        }
        remoteIPAddress = request.getHeader("X-Real-IP");
        if (remoteIPAddress == null) {
            String ips = request.getHeader("X-Forwarded-For");
            if (ips != null) {
                remoteIPAddress = ips.split(",")[0];
            }
            else {
                 remoteIPAddress = request.getRemoteAddr();
            }
        }
        return remoteIPAddress;
    }
}
