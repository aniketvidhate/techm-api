package com.att.unlock.captcha.service;

import com.att.unlock.captcha.component.sound.wordtosound.FreeTTSWordToSound;
import com.octo.captcha.CaptchaFactory;
import com.octo.captcha.component.sound.soundconfigurator.FreeTTSSoundConfigurator;
import com.octo.captcha.engine.CaptchaEngine;
import com.octo.captcha.engine.GenericCaptchaEngine;
import com.octo.captcha.service.captchastore.CaptchaStore;
import com.octo.captcha.service.captchastore.FastHashMapCaptchaStore;
import com.octo.captcha.service.sound.AbstractManageableSoundCaptchaService;
import com.octo.captcha.service.sound.SoundCaptchaService;
import com.octo.captcha.sound.gimpy.GimpySoundFactory;

/**
 * <p>
 * Default service implementation : use a {@link FastHashMapCaptchaStore} as
 * captcha store, and a {@link SpellerSoundCaptchaEngine}
 * </p>
 * It is initialized with thoses default values :
 * <ul>
 * <li>min guaranted delay : s</li>
 * <li>max store size : captchas</li>
 * <li>max store size before garbage collection :</li>
 * </ul>
 *
 * @author <a href="mailto:marc.antoine.garrigue@gmail.com">Marc-Antoine
 *         Garrigue</a>
 * @version $Id: DefaultManageableSoundCaptchaService.java -- ::Z antoineveret $
 */
public class DefaultManageableSoundCaptchaService extends
        AbstractManageableSoundCaptchaService implements SoundCaptchaService {

    private static final String voiceName = "kevin16";

    private static final String voicePackage = "com.sun.speech.freetts.en.us.cmu_time_awb.AlanVoiceDirectory,com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory";

    // private static
    // com.octo.captcha.component.word.wordgenerator.WordGenerator words = new
    // com.octo.captcha.component.word.wordgenerator.RandomWordGenerator("1234567890");

     private static final
     com.octo.captcha.component.word.wordgenerator.WordGenerator words = new
     com.octo.captcha.component.word.wordgenerator.RandomWordGenerator("123456789BCDFGJKQTVX");

    /*private static com.octo.captcha.component.word.wordgenerator.WordGenerator words = new DictionaryWordGenerator(
            new FileDictionary("sound"));*/

    private static final CaptchaFactory soundFactory[] = { new GimpySoundFactory(
            words, new FreeTTSWordToSound(new FreeTTSSoundConfigurator(
                    voiceName, voicePackage, 1.0f, 110, 70), 5, 5)) };

    /**
     * Construct a new SoundCaptchaService with a
     * {@link FastHashMapCaptchaStore} and a {@link SpellerSoundCaptchaEngine}
     *
     * @param minGuarantedStorageDelayInSeconds
     *
     * @param maxCaptchaStoreSize
     * @param captchaStoreLoadBeforeGarbageCollection
     *
     */
    public DefaultManageableSoundCaptchaService(
            int minGuarantedStorageDelayInSeconds, int maxCaptchaStoreSize,
            int captchaStoreLoadBeforeGarbageCollection) {

        super(new FastHashMapCaptchaStore(), new GenericCaptchaEngine(
                soundFactory), minGuarantedStorageDelayInSeconds,
                maxCaptchaStoreSize, captchaStoreLoadBeforeGarbageCollection);
    }

    /**
     * Construct a new SoundCaptchaService with a
     * {@link FastHashMapCaptchaStore} and a {@link SpellerSoundCaptchaEngine}
     * minGuarantedStorageDelayInSeconds s maxCaptchaStoreSize
     * captchaStoreLoadBeforeGarbageCollection
     */
    public DefaultManageableSoundCaptchaService() {
        this(180, 100000, 75000);
    }

    public DefaultManageableSoundCaptchaService(CaptchaStore captchaStore,
            CaptchaEngine captchaEngine, int minGuarantedStorageDelayInSeconds,
            int maxCaptchaStoreSize, int captchaStoreLoadBeforeGarbageCollection) {
        super(captchaStore, captchaEngine, minGuarantedStorageDelayInSeconds,
                maxCaptchaStoreSize, captchaStoreLoadBeforeGarbageCollection);
    }
}
