package com.att.unlock.captcha.service;

import org.apache.log4j.Logger;

import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.captcha.util.UnlockConstants;
import com.octo.captcha.service.CaptchaServiceException;

/**
 * <b>Name:</b> UnlockCaptchaValidatorServiceImpl. <b>Purpose:</b>This class is used  for
 * validating image and sound captcha.
 * 
 * @author SS00349933
 */
public class UnlockCaptchaValidatorServiceImpl implements
        UnlockCaptchaValidatorService {

    /** Declaration of the logger */
    public final static Logger LOG = Logger
            .getLogger(UnlockCaptchaValidatorServiceImpl.class);

    /**
     * This method is used for validate image captcha.
     * @param captchaId as String ,inputChars as String.
     * @return boolean
     */
    @Override
    public boolean validateImageCaptcha(String captchaId, String inputChars) {
        UnlockLogUtil.serviceInfo(UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL,
                "validateImageCaptcha", "[Start: Class "
                        + UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL
                        + " : Method : " + "validateImageCaptcha" + "]");
        boolean bValidated = false;
        try {
            bValidated = UnlockCaptchaService.getImageInstance()
                    .validateResponseForID(captchaId, inputChars);
         
        } catch (CaptchaServiceException cse) {
          UnlockLogUtil.errorInfo(UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL,
                     "validateImageCaptcha", "[Exception caught: Class "
                             + UnlockConstants.IMAGE_CONTROLLER + " : method : "
                             + "validateImageCaptcha" + "]",
                     UnlockExceptionUtil.generateStackTraceString(cse));
        }
        
        UnlockLogUtil.serviceInfo(UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL,
                "validateImageCaptcha", "[End: Class "
                        + UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL
                        + " : Method : " + "validateImageCaptcha" + "]");
        return bValidated;
    }

    /**
     * This method is used for validate sound captcha.
     * @param captchaId as String ,inputChars as String.
     * @return boolean
     */
    @Override
    public boolean validateSoundCaptcha(String captchaId, String inputChars) {
   
        UnlockLogUtil.serviceInfo(UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL,
                "validateSoundCaptcha", "[Start: Class "
                        + UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL
                        + " : Method : " + "validateSoundCaptcha" + "]");
        boolean bValidated = false;
        try {
            bValidated = UnlockCaptchaService.getAudioInstance()
                    .validateResponseForID(captchaId, inputChars);
        } catch (CaptchaServiceException cse) {
           
            UnlockLogUtil.errorInfo(UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL,
                    "validateSoundCaptcha", "[Exception caught: Class "
                            + UnlockConstants.IMAGE_CONTROLLER + " : method : "
                            + "validateSoundCaptcha" + "]",
                    UnlockExceptionUtil.generateStackTraceString(cse));
        }
        UnlockLogUtil.serviceInfo(UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL,
                "validateSoundCaptcha", "[End: Class "
                        + UnlockConstants.UNLOCK_CAPTCHA_VALIDATOR_SERVICE_IMPL
                        + " : Method : " + "validateSoundCaptcha" + "]");
        return bValidated;
    }
}
