package com.att.unlock.captcha.service;

/**
 * <b>Name:</b> UnlockCaptchaValidatorService <b>Purpose:</b> It is an interface that will define
 * the method for validating image and sound captcha 
 * the class implementing this interface will provide the definition for
 * the method declared in this interface.
 * 
 * @author SS00349933
 *
 */
public interface UnlockCaptchaValidatorService {

    /**
     * @param captchaId
     * @param inputChars
     * @return
     */
    boolean validateImageCaptcha(String captchaId, String inputChars);

    /**
     * @param captchaId
     * @param inputChars
     * @return
     */
    boolean validateSoundCaptcha(String captchaId, String inputChars);

}
