package com.att.unlock.captcha.service;

import org.apache.log4j.Logger;

import com.octo.captcha.service.image.DefaultManageableImageCaptchaService;
import com.octo.captcha.service.image.ImageCaptchaService;
import com.octo.captcha.service.sound.SoundCaptchaService;

/**
 * <b>Name:</b> UnlockCaptchaService. <b>Purpose:</b>This class is used  for
 * getting image and sound instance.
 * 
 * @author SS00349933
 *
 */
public class UnlockCaptchaService {

    /** Declaration of the logger */
    public final static Logger LOG = Logger
            .getLogger(UnlockCaptchaService.class);

    // a singleton class
    /** Instance of ImageCaptchaService. */
    private static ImageCaptchaService instance = new DefaultManageableImageCaptchaService();

     private static SoundCaptchaService audioInstance = new
     DefaultManageableSoundCaptchaService();
     
    /**
     * It returns the instance of ImageCaptchaService.
     * @return ImageCaptchaService
     */
    public static ImageCaptchaService getImageInstance() {
        LOG.debug("UnlockCaptchaService: Returing the instance of ImageCaptchaService");
        return instance;
    }
    
    /**
     * It returns the instance of SoundCaptchaService.
     * @return SoundCaptchaService
     */
     public static SoundCaptchaService getAudioInstance() {
     LOG.debug("UnlockCaptchaService: Returing the instance of SoundCaptchaService");
     return audioInstance;
     }
}