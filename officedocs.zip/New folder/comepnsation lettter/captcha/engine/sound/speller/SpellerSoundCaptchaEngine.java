package com.att.unlock.captcha.engine.sound.speller;

import com.att.unlock.captcha.component.sound.wordtosound.FreeTTSWordToSound;
import com.octo.captcha.component.sound.soundconfigurator.FreeTTSSoundConfigurator;
import com.octo.captcha.component.sound.soundconfigurator.SoundConfigurator;
import com.octo.captcha.component.word.worddecorator.SpellerWordDecorator;
import com.octo.captcha.engine.sound.ListSoundCaptchaEngine;
import com.octo.captcha.sound.gimpy.GimpySoundFactory;

/**
 * <p/>
 * Engine to generate a SpellerSound captcha. This captcha provide a sound that
 * is the spelling of a word
 * </p>
 *
 * @author Benoit Doumas
 * @version .
 */
public class SpellerSoundCaptchaEngine extends ListSoundCaptchaEngine {

    private static String voiceName = "kevin16";

    private static String voicePackage = "com.sun.speech.freetts.en.us.cmu_time_awb.AlanVoiceDirectory,com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory";

    /*
     * private static CaptchaFactory soundFactory[] = { new
     * GimpySoundFactory(new DictionaryWordGenerator( new
     * FileDictionary("sound")), new FreeTTSWordToSound(new
     * FreeTTSSoundConfigurator(voiceName, voicePackage, 1.0f, 100, 100), 4,
     * 10)) };
     */

    /**
     * @see com.octo.captcha.engine.sound.ListSoundCaptchaEngine#buildInitialFactories()
     */
    protected void buildInitialFactories() {

        com.octo.captcha.component.word.wordgenerator.WordGenerator words = new com.octo.captcha.component.word.wordgenerator.RandomWordGenerator(
                "ABCDEFGHIJKLMNOPQRSTUVWXYZ");

        SoundConfigurator configurator = new FreeTTSSoundConfigurator(
                voiceName, voicePackage, 1.0f, 100, 110);
        FreeTTSWordToSound wordToSound = new FreeTTSWordToSound(configurator,
                4, 10);

        SpellerWordDecorator decorator = new SpellerWordDecorator(", ");
        this.addFactory(new GimpySoundFactory(words, wordToSound));

    }

}
