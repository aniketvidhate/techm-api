/**
 * @author VV00124304
 */
package com.att.unlock.rest.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.att.unlock.base.util.UnlockBeanUtil;

/**
 * @author VV00124304
 *
 */
public class UnlockValidatorUtil {

    /**
     * It checks whether input string contains any special character among(/,:<>!~@#$%^&()+=?()\"|!\\[#$-).
     *
     * @param inputString
     * @return boolean
     */
    public static boolean containsSpecialCharacter(String inputString) {

        Pattern pattern = Pattern.compile(UnlockBeanUtil.getRegExpSpecialChar());
        Matcher patternMatcher = pattern.matcher(inputString.trim());
        return patternMatcher.find();
    }


    /**
     * It checks whether input email address is valid or not.
     *
     * @param emailString
     * @return boolean
     */
    public static boolean isValidEmail(String emailString) {

        Pattern pattern = Pattern.compile(UnlockBeanUtil.getRegExpEmail());
        Matcher patternMatcher = pattern.matcher(emailString.trim());
        return patternMatcher.find();
    }

}
