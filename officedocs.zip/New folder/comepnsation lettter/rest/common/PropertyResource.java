package com.att.unlock.rest.common;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * <b>Name:</b> PropertyResource.
 * <b>Purpose:</b>This class is designed as a
 * PropertyResource for getting and loading the property file.
 * @author
 */
public final class PropertyResource {

    /**
    *
    */
    static final Logger LOG = Logger.getLogger(PropertyResource.class);

    /**
    *
    */
    private static PropertyResource propertyResource = null;

    /**
    *
    */
    private Map<String, Properties> mapProperties;

    /**
    *
    */
    public static final String APP_PATH = "";

    /**
    *
    */
    public static final String APPLICATION = "application";

    /**
     * private constructor defined for making the class as singleton class.
     */
    private PropertyResource() {
        mapProperties = new HashMap<String, Properties>();
    }

    /**
     * <b>Name:</b> getPropertyResource.
     * <b>Purpose:</b>This Method defined for getting the
     * PropertyResource object.
     * @return PropertyResource object
     */
    public static PropertyResource getPropertyResource() {
        if (propertyResource == null) {
            propertyResource = new PropertyResource();
        }
        return propertyResource;
    }

    /**
     * <b>Name:</b> addProp.
     * <b>Purpose:</b>This Method defined for adding
     *  properites into Properity file.
     *  @param resourceKey as String
     *  @param resourceFile as String
     *  @throws UnlockApplicationException as Exception
     */
    public void addProp(final String resourceKey, final String resourceFile)
            throws UnlockApplicationException {
        Properties properties = null;
        try {
            properties = new Properties();
            properties.load(this.getClass().getClassLoader()
                    .getResourceAsStream(resourceFile));
            add(resourceKey, properties);
        } catch (FileNotFoundException e) {
            LOG.error("Missing property file. Unable to load properties. ", e);
            throw new UnlockApplicationException(e);
        } catch (IOException e) {
            LOG.error("I/O Error occured while loading the properties. ", e);
            throw new UnlockApplicationException(e);
        } catch (NullPointerException e) {
            LOG.error("Missing property file. Unable to load properties. ", e);
            throw new UnlockApplicationException(e);
        }

    }

    /**
     * <b>Name:</b> add.
     * <b>Purpose:</b>This Method defined for adding the property
     * files into Property file.
     * @param resourceKey as String
     * @param resourceFile as String
     * @throws UnlockApplicationException as Exception
     */
    public void add(final String resourceKey, final String resourceFile)
            throws UnlockApplicationException {
        Properties properties = null;
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(resourceFile);
            properties = new Properties();
            properties.load(fileInputStream);
            add(resourceKey, properties);
        } catch (FileNotFoundException e) {
            LOG.error("Missing property file. Unable to load properties. ", e);
            throw new UnlockApplicationException(e);
        } catch (IOException e) {
            LOG.error("I/O Error occured while loading the properties. ", e);
            throw new UnlockApplicationException(e);
        } catch (NullPointerException e) {
            LOG.error("Missing property file. Unable to load properties. ", e);
            throw new UnlockApplicationException(e);
        }

    }

    /**
     * <b>Name:</b> add.
     * <b>Purpose:</b>This Method defined for adding the properties file.
     * @param resourceKey as String
     * @param properties as Properties
     */
    private void add(final String resourceKey, final Properties properties) {
        mapProperties.put(resourceKey, properties);
    }

    /**
     * <b>Name:</b> remove.
     * <b>Purpose:</b>This Method defined for removing
     * the properties file from the Map.
     * @param resourceKey as String
     */
    public void remove(final String resourceKey) {
        mapProperties.remove(resourceKey);
    }

    /**
     * <b>Name:</b> get.
     *  <b>Purpose:</b>This Method defined for getting the
     * properties object from the Map.
     * @param resourceKey as String
     * @return Properties object
     */
    public Properties get(final String resourceKey) {
        return mapProperties.get(resourceKey);
    }

    /**
     * <b>Name:</b> get.
     * <b>Purpose:</b>This Method defined for getting the
     * property value from the properties file.
     * @param resourceKey as String
     * @param propertyKey as String
     * @return String object
     */
    private String get(final String resourceKey, final String propertyKey) {
        Properties properties = get(resourceKey);
        if (properties == null) {

            return null;
        }

        return properties.getProperty(propertyKey);
    }

    /**
     * <b>Name:</b> getProperty.
     * <b>Purpose:</b>This Method returns
     * property resource value.
     * @param resourceKey as String
     * @param propertyKey as String
     * @return String object
     */
    public static String getProperty(final String resourceKey,
            final String propertyKey) {
        if (propertyResource == null) {
            LOG.error("Properties not initialized");
            return null;
        }
        return propertyResource.get(resourceKey, propertyKey);
    }
}
