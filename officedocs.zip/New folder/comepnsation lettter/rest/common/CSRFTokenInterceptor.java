package com.att.unlock.rest.common;

import java.util.List;
import java.util.Map;

import org.apache.cxf.helpers.CastUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.transport.http.Headers;

import com.att.unlock.api.CSRFService;
import com.att.unlock.api.common.UnlockServiceException;
import com.att.unlock.base.util.UnlockBeanUtil;
import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;

/**
 * <b>Name:</b> CSRFTokenInterceptor <b>Purpose:</b> This class is designed for
 * validating request on the basis of csrf token.
 *
 */
public class CSRFTokenInterceptor extends AbstractPhaseInterceptor<Message> {

    /**
     *
     */
    private static CSRFService csrfService;

    /**
     *
     */
    public CSRFTokenInterceptor() {

        super(Phase.READ);

        UnlockLogUtil.endPointInfo(UnlockConstants.CSRF_TOKEN_INTERCEPTOR,
                "CSRFTokenInterceptor", UnlockConstants.REQUEST,
                "CSRFTokenInterceptor");
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * org.apache.cxf.interceptor.Interceptor#handleMessage(org.apache.cxf.message
     * .Message)
     */
    public void handleMessage(Message message) {
        UnlockLogUtil.endPointDebugInfo("ServiceResponseInterceptor",
                "ServiceResponseInterceptor", UnlockConstants.REQUEST, message);

        UnlockLogUtil.endPointDebugInfo(UnlockConstants.CSRF_TOKEN_INTERCEPTOR,
                "handleMessage", UnlockConstants.REQUEST, message);

        // If security gateway is not enabled return from here
        // no additional checks are required
        if (!isGatewayEnabled()) {
            // filterChain.doFilter(request, response);
            return;
        } else { // if gateway is enabled
            // check for validity of the token
            try {
                if (!isValidRequest(message)) {
                    message.put(UnlockConstants.CSRF_TOKEN,
                            UnlockConstants.IN_VALID);
                }
            } catch (Exception e) {
                UnlockLogUtil.errorInfo(UnlockConstants.CSRF_TOKEN_INTERCEPTOR,
                        "isValidRequest", "[Exception caught: Class "
                                + UnlockConstants.CSRF_TOKEN_INTERCEPTOR
                                + " : method : " + "isValidRequest" + "]",
                        UnlockExceptionUtil.generateStackTraceString(e));
                message.put(UnlockConstants.CSRF_TOKEN,
                        UnlockConstants.IN_VALID);
            }
            // csrfGuard.updateTokens(httpRequest);
        }
    }

    /**
     * @return
     */
    private boolean isGatewayEnabled() {
        UnlockLogUtil.endPointInfo(UnlockConstants.CSRF_TOKEN_INTERCEPTOR,
                "isGatewayEnabled", UnlockConstants.REQUEST, "");
        Boolean isGatewayEnable = Boolean.valueOf(UnlockBeanUtil
                .getSecurityGatewayEnable());
        UnlockLogUtil.endPointInfo(UnlockConstants.CSRF_TOKEN_INTERCEPTOR,
                "isGatewayEnabled", UnlockConstants.REQUEST, ""
                        + isGatewayEnable);
        return isGatewayEnable;
    }

    /**
     * This method is used to validate request on the basis of token associated
     * in message.
     *
     * @param message
     * @return
     */
    @SuppressWarnings("unused")
    public boolean isValidRequest(Message message) {
        boolean valid = false;
        String tokenFromRequest = null;
        String resourceName = null;
        try {
            String tokenValue = "";
            Map<String, List<String>> headers = Headers
                    .getSetProtocolHeaders(message);

            try {

                for (Map.Entry<String, List<String>> headerEntry : headers
                        .entrySet()) {
                    
                    UnlockLogUtil.endPointDebugInfo(
                            UnlockConstants.CSRF_TOKEN_INTERCEPTOR,
                            "isValidRequest",
                            UnlockConstants.REQUEST,
                            "Header entry: key::::::::::: : "
                                    + headerEntry.getKey()
                                    + " ::::::::::Value ::::::: "
                                    + headerEntry.getValue());
                    if (UnlockStringUtil.isEquals(headerEntry.getKey(),
                            "OWASP-CSRFTOKEN")) {
                        List<String> headerEntryList = headerEntry.getValue();
                        for (String token : headerEntryList) {
                            tokenFromRequest = token;
                            break;
                        }
                    }
                }
            } catch (Exception e) {

                UnlockLogUtil.errorInfo(UnlockConstants.CSRF_TOKEN_INTERCEPTOR,
                        "isValidRequest", "[Exception caught: Class "
                                + UnlockConstants.CSRF_TOKEN_INTERCEPTOR
                                + " : method : " + "isValidRequest" + "]",
                        UnlockExceptionUtil.generateStackTraceString(e));

            }
            UnlockLogUtil.endPointDebugInfo(UnlockConstants.CSRF_TOKEN_INTERCEPTOR,
                    "isValidRequest", UnlockConstants.REQUEST);
            if (tokenFromRequest == null
                    || tokenFromRequest.trim().length() == 0) {
                /** FAIL: token is missing from the request **/

                throw new UnlockServiceException(
                        "required token is missing from the request");
            } else {

                /*
                 * if (tokenFromRequest.contains(",")) { tokenFromRequest =
                 * tokenFromRequest.substring(0,
                 * tokenFromRequest.indexOf(',')).trim(); }
                 */
                if (verifyToken(tokenFromRequest)) {
                    valid = true;
                } else {
                    throw new UnlockServiceException(
                            "request token does not match Stored token");
                }
            }

        } catch (UnlockServiceException csrfe) {
            // callActionsOnError(request, response, csrfe);
            UnlockLogUtil.errorInfo(UnlockConstants.CSRF_TOKEN_INTERCEPTOR,
                    "isValidRequest", "[Exception caught: Class "
                            + UnlockConstants.CSRF_TOKEN_INTERCEPTOR
                            + " : method : " + "isValidRequest" + "]",
                    UnlockExceptionUtil.generateStackTraceString(csrfe));
            valid = false;
        }
        return true;
    }

    /**
     * This method verify token
     *
     * @param tokenKey
     * @return
     * @throws UnlockServiceException
     */
    private boolean verifyToken(String tokenKey) throws UnlockServiceException {
        // check for the validity of token
        // check for maximum no of tries of the token
        boolean verified = false;
        /** calling csrfService for getting the token from Cassandra database */
        String count = csrfService.findCSRFToken(tokenKey);
        int int_count = Integer.parseInt(count);

        if (int_count > 0) {
            verified = true;
            csrfService.saveCSRFToken(tokenKey, --int_count
                    + UnlockConstants.BLANK);
        } else {
            verified = false;
        }
        return verified;
    }

    /**
     * @return the csrfService
     */
    public CSRFService getCsrfService() {
        return csrfService;
    }

    /**
     * @param csrfService
     *            the csrfService to set
     */
    public void setCsrfService(CSRFService csrfService) {
        this.csrfService = csrfService;
    }
}
