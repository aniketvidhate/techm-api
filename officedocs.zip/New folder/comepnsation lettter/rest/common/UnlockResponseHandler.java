package com.att.unlock.rest.common;

import com.att.unlock.api.vo.UnlockBaseVO;

/**
 * <b>Name:</b> UnlockResponseHandler <b>Purpose:</b> It is an interface that will define
 * the method for handling response. The class implementing this interface will provide the definition for
 * the method declared in this interface.
 * @author SS00349933
 *
 */
public interface UnlockResponseHandler {

    /**
     * @param baseVO
     * @param exception
     * @return
     */
    UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception);
    
    
    /**
     * @param baseVO
     * @param exception
     * @param rcDetailInternal
     * @return
     */
    UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception, String rcDetailInternal );
    
    /**
     * @param baseVO
     * @return
     */
    UnlockBaseVO setInvalidResponse(final UnlockBaseVO baseVO);

    /**
     * @param baseVO
     * @param rcDetailInternal
     * @return
     */
    UnlockBaseVO setInvalidResponse(final UnlockBaseVO baseVO, String rcDetailInternal);
    
}
