package com.att.unlock.rest.common;


/**
 * <b>Name:</b> UnlockConstants <b>Purpose:</b> It is an interface is designed
 * to contain constant.
 *
 * @author VV00124304
 *
 */

public final class UnlockConstants {

    /**
    *
    */
    private UnlockConstants() {
    }

    /**
     *
     */
    public static final String PROPERTIES_FILE = "/ApplicationResources.properties";
    /**
     *
     */
    public static final String ERROR_STR = "error";

    /**
     *
     */
    public static final String SERVICELOG_STR = "serviceLog";

    /**
     *
     */
    public static final String IMEI_CONTROLLER = "IMEIController";

    /**
    *
    */
   public static final String CSRF_CONTROLLER = "CSRFController";

    /**
     *
     */
    public static final String EMAIL_CONTROLLER = "EmailController";

    /**
     *
     */
    public static final String PAYMENT_CONTROLLER = "PaymentController";

    /**
     *
     */
    public static final String ORDER_CONTROLLER = "OrderController";

    /**
    *
    */
    public static final String TAX_CONTROLLER = "TaxController";

    /**
     *
     */
    public static final String UNLOCK_EXCEPTION_UTIL = "UnlockExceptionUtil";

    /**
    *
    */
   public static final String CSRF_TOKEN_INTERCEPTOR = "CSRFTokenInterceptor";

    /**
     *
     */
    public static final String REQUEST = "Request--------";

    /**
     *
     */
    public static final String RESPONSE = "Response--------";

    /**
     *
     */
    public static final String LOG_ENABLE = "log_enable";

    /**
     *
     */
    public static final String BLANK = "";

    /**
     *
     */
    public static final int ONE = 1;

    /**
     *
     */
    public static final int TWO = 2;

    /**
     *
     */
    public static final int ZERO = 0;

    /**
     *
     */
    public static final String STATUS_CODE_TWO = "2";

    /**
     *
     */
    public static final String FAILURE = "FAILURE";

    /**
     *
     */
    public static final String SUCCESS = "SUCCESS";

    /**
     *
     */
    public static final String INVALID_EMAIL_ERROR_CODE = "ULP_1010";

    /**
     *
     */
    public static final String INVALID_EMAIL_ERROR_DESC = "Enter a secure Email Address.";

    /**
     *
     */
    public static final int RESPONSE_CODE = 200;

    /**
    *
    */
    public static final int MAX_AGE = 1209600;

    /**
    *
    */
    public static final String UNLOCK_BUNDLE_ACTIVATOR = "UnlockBundleActivator";

    /**
    *
    */
    public static final String NON_ATT_CUSTOMER = "Non AT&T customer";

    /**
    *
    */
    public static final String GO_PHONE = "GoPhone";

    /**
    *
    */
    public static final int FIFTEEN = 15;

    /**
    *
    */
    public static final int TEN = 10;

    /**
     *
     */
    public static final String SYSTEM_ERROR_CODE = "2";
    /**
     *
     */
    public static final String SYSTEM_ERROR_MESSAGE = "Failure";
    /**
     *
     */
    public static final String ORDER_NUMBER = "123456";

    /**
     *
     */
    public static final String EMAIL_VALIDATOR = "EmailValidator";
    /**
     *
     */
    public static final String IMEI_VALIDATOR = "IMEIValidator";
    /**
     *
     */
    public static final String ORDER_VALIDATOR = "OrderValidator";
    /**
     *
     */
    public static final String PAYMENT_VALIDATOR = "PaymentValidator";
    /**
     *
     */
    public static final String TAX_VALIDATOR = "TAXValidator";
    /**
     *
     */
    public static final String UNLOCK_VALIDATOR = "UnlockValidator";

    /**  */
    public static final String APPLICATION = "application";

    /** */
    public static final String SECURITY_GATEWAY_ENABLE = "security.gateway.enable";
    
    public static final String TIME_DIFFERENCE="TimeDifference";

    /**  */
    public static final String CSRF_CALLS_PER_TOKEN  = "csrf.callspertoken";

    /** */
    public static final String CSRF_TOKEN_TTL  = "csrf.ttl";

    /**  */
    public static final String CSRF_GUARD_JS  = "csrfguard.js";

    /**
    *
    */
   public static final String CSRF_TOKEN = "csrfToken";

   /**
   *
   */
  public static final String IN_VALID = "inValid";

  /**
  *
  */
  public static final String INVALID_TOKEN_ERROR_CODE = "ULS_3001";
  
  /**
  *
  */
  public static final String NON_CUSTOMER = "Non-Customer";

  /**
  *
  */
  public static final String INVALID_TOKEN_ERROR_DESC = "We\u2019re sorry, but we\u2019re having technical difficulties"
        + " with our network at the moment. Please try again later.\n\nIf this problem persists, try clearing the "
        + "cache and cookies from your device.\n\nQuestions? Call us at <strong>800.331.0500</strong>, or dial "
        + "<strong>611</strong> from your AT&T wireless phone. (errorCode.ULS3001)";

  public static final String OCE_ATT_ORDER_PREFIX = "CUL";

 	public static final String OCE_NON_ATT_ORDER_PREFIX = "NUL";
 	
 	public static final String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
 	
	public static final String ERROR_CODE_CTNREQUIRED = "ULF_0001";
	
	public static final String ERROR_DESCRIPTION_CTNREQUIRED = "Enter an AT&T Wireless Number";
	
	public static final String ERROR_CODE_CTNLENGTH = "ULF_0002";
	
	public static final String ERROR_DESCRIPTION_CTNLENGTH = "Enter a valid 10-digit AT&T wireless number with area code first (example: 5035557654)";
	
	public static final String ERROR_CODE_FIRSTNAMEREQUIRED = "ULF_0003";
	
	public static final String ERROR_DESCRIPTION_FIRSTNAMEREQUIRED = "Enter the Account Holder's First Name";
	
	public static final String ERROR_CODE_LASTNAMEREQUIRED = "ULF_0004";
	
	public static final String ERROR_DESCRIPTION_LASTNAMEREQUIRED = "Enter the Account Holder's Last Name";
	
	public static final String ERROR_CODE_CAPTCHAREQUIRED = "ULF_0005";
	
	public static final String ERROR_DESCRIPTION_CAPTCHAREQUIRED = "Enter the characters shown in the image to continue";
	
	public static final String ERROR_CODE_SSNREQUIRED = "ULF_0006";
	
	public static final String ERROR_DESCRIPTION_SSNREQUIRED = "Enter the Last 4 Digits of the Account Holder's SSN";
	
	public static final String ERROR_CODE_SSNLENGTH = "ULF_0007";
	
	public static final String ERROR_DESCRIPTION_SSNLENGTH = "Enter a valid Last 4 Digits of the Account Holder's SSN";
	
	public static final String ERROR_CODE_EMAILREQUIRED = "ULF_0008";
	
	public static final String ERROR_DESCRIPTION_EMAILREQUIRED = "Enter an Email Address";
	
	public static final String ERROR_CODE_EMAILVALID = "ULF_0009";
	
	public static final String ERROR_DESCRIPTION_EMAILVALID = "Enter a valid Email Address (example: user@att.com)";
	
	public static final String ERROR_CODE_BUSINESSNAMEREQUIRED = "ULF_0010";
	
	public static final String ERROR_DESCRIPTION_BUSINESSNAMEREQUIRED = "Enter a valid Business Account Name";
	
	public static final String ERROR_CODE_BUSINESSACCOUNTNUMBERREQUIRED = "ULF_0011";
	
	public static final String ERROR_DESCRIPTION_BUSINESSACCOUNTNUMBERREQUIRED = "Enter the last 4 of BAN";
	
	public static final String ERROR_CODE_BUSINESSACCOUNTNUMBERLENGTH = "ULF_0012";
	
	public static final String ERROR_DESCRIPTION_BUSINESSACCOUNTNUMBERLENGTH = "Please enter valid Last 4 Digits of Business Account Number";
	
	public static final String ERROR_CODE_ACTIVESIMREQUIRED = "ULF_0013";
	
	public static final String ERROR_DESCRIPTION_ACTIVESIMREQUIRED = "Enter the last 4 of active SIM card";
	
	public static final String ERROR_CODE_ACTIVESIMLENGTH = "ULF_0014";
	
	public static final String ERROR_DESCRIPTION_ACTIVESIMLENGTH = "Please enter valid Last 4 Numbers of Active SIM Card";
	
	public static final String ERROR_CODE_IMEIREQUIRED = "ULF_0015";
	
	public static final String ERROR_DESCRIPTION_IMEIREQUIRED = "Enter a valid IMEI number";
		
	public static final String ERROR_CODE_IMEILENGTH = "ULF_0016";
	
	public static final String ERROR_DESCRIPTION_IMEILENGTH = "Enter a valid IMEI number";
	
	public static final String ERROR_CODE_MAKEANDMODELREQUIRED = "ULF_0017";
	
	public static final String ERROR_DESCRIPTION_MAKEANDMODELREQUIRED = "MAKE and Model field should not be empty";
	
	public static final int FOUR = 4;
	public static final String API_USER_NAME = "unlockAPI";
	public static final String API_PASSWORD = "#$#%$#%@#@#%#$^%$%";
	public static final String INVALID_OCE_TOKEN_ERROR_CODE = "ULS_8045";
	public static final String INVALID_OCE_TOKEN_ERROR_DESC = "Session is expired.";

    public static final String ERROR_INTERNAL_STATUS_0001="0001";
    
    public static final String ERROR_INTERNAL_STATUS_0002="0002";
    
    public static final String ERROR_INTERNAL_STATUS_0003="0003";
    
    public static final String ERROR_INTERNAL_STATUS_0004="0004";
    
    public static final String ERROR_INTERNAL_STATUS_0005="0005";
    
    public static final String ERROR_INTERNAL_STATUS_0006="0006";
    
    public static final String ERROR_INTERNAL_STATUS_0007="0007";
    
    public static final String ERROR_INTERNAL_STATUS_0008="0008";
    
    public static final String ERROR_INTERNAL_STATUS_0009="0009";
    
    public static final String ERROR_INTERNAL_STATUS_0010="0010";
    
    public static final String ERROR_INTERNAL_STATUS_0011="0011";
    
    public static final String ERROR_INTERNAL_STATUS_0012="0012";
    
    public static final String ERROR_INTERNAL_STATUS_0013="0013";
    
    public static final String ERROR_INTERNAL_STATUS_0014="0014";
    
    public static final String ERROR_INTERNAL_STATUS_0015="0015";
    
    public static final String ERROR_INTERNAL_STATUS_0016="0016";
    
    public static final String ERROR_INTERNAL_STATUS_0017="0017";    

    public static final String ERROR_INTERNAL_STATUS_0018="0018";
    
    public static final String ERROR_INTERNAL_STATUS_0019="0019";
    
    public static final String ERROR_INTERNAL_STATUS_0020="0020";
    
    public static final String ERROR_INTERNAL_STATUS_0021="0021";
    
    public static final String ERROR_INTERNAL_STATUS_0022="0022";
    
    public static final String ERROR_INTERNAL_STATUS_0023="0023";
    
    public static final String ERROR_INTERNAL_STATUS_0024="0024";
    
    public static final String ERROR_INTERNAL_STATUS_0025="0025";
    
    public static final String ERROR_INTERNAL_STATUS_0026="0026";
    
    public static final String ERROR_INTERNAL_STATUS_0027="0027";
}
