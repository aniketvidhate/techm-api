package com.att.unlock.rest.common;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <b>Name:</b> ServiceException.
 * <b>Purpose:</b>This class is designed to generate service exception.
 * @author SS00349933
 *
 */
@XmlRootElement(name = "ServiceException")
public class ServiceException extends Exception implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
    *
    */
    private ServiceExceptionDetails[] faultDetails;

    /**
     * <b>Name:</b> ServiceException class constructor.
     * @param faultDetailse as ServiceExceptionDetails
     */
    public ServiceException(final ServiceExceptionDetails[] faultDetailse) {
        faultDetails = faultDetailse;
    }

    /**
     * <b>Name:</b> ServiceException class constructor.
     * @param message as String
     * @param faultDetailse as ServiceExceptionDetails
     */
    public ServiceException(final String message,
            final ServiceExceptionDetails[] faultDetailse) {
        super(message);
        faultDetails = faultDetailse;
    }

    /**
     * <b>Name:</b> getFaultDetails.
     * <b>Purpose:</b>This method is used to return service exception.
     * @return ServiceExceptionDetails[]
     */
    public final ServiceExceptionDetails[] getFaultDetails() {
        return faultDetails;
    }

}
