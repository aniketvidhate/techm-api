package com.att.unlock.rest.common;


/**
 * <b>Name:</b> InvalidRequestException.
 * <b>Purpose:</b>This class is designed to generate invalid request exception.
 * @author SS00349933
 *
 */
public class InvalidRequestException extends Exception {

/**
 *
 */
    private static final long serialVersionUID = 1L;

    /**
     * <b>Name:</b> InvalidRequestException class constructor.
     */
    public InvalidRequestException() {
        super();
    }

    /**
     * <b>Name:</b> InvalidRequestException class constructor.
     * @param message as String
     * @param cause as Throwable
     * @param enableSuppression as boolean
     * @param writableStackTrace as boolean
     */
    public InvalidRequestException(final String message, final Throwable cause,
            final boolean enableSuppression, final boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * <b>Name:</b> InvalidRequestException class constructor.
     * @param message as String
     * @param cause as Throwable
     */
    public InvalidRequestException(final String message,
            final Throwable cause) {
        super(message, cause);
    }

    /**
     * <b>Name:</b> InvalidRequestException class constructor.
     * @param message as String
     */
    public InvalidRequestException(final String message) {
        super(message);
    }

    /**
     * @param cause as Throwable
     */
    public InvalidRequestException(final Throwable cause) {
        super(cause);
    }

}
