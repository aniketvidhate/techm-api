package com.att.unlock.rest.common;

import org.apache.log4j.Logger;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;

/**
 * <b>Name:</b> UnlockBundleActivator.
 * <b>Purpose:</b>Activator class for this bundle. Will start and stop
 *  the bundle during deployment and undeployment.
 * @author
 */
public class UnlockBundleActivator implements BundleActivator {


     /**
     *  Declaration of the logger.
     */
    public static final Logger LOG = Logger
            .getLogger(UnlockBundleActivator.class);

    /**
     * <b>Name:</b> start
     * <b>Purpose:</b>This method is used to to start
     * the bundle context.
     * @param context as BundleContext
     */
    public final void start(final BundleContext context) {
        LOG.debug("Starting the bundle>>>>>>>>>>>>>>$$$$$$$$$$");
        System.setProperty("file.encoding", "Cp1252");
        /*PropertyResource propertyResource = PropertyResource
                .getPropertyResource();
        try {
            propertyResource.addProp(PropertyResource.APPLICATION,
                    UnlockConstants.PROPERTIES_FILE);
        } catch (UnlockApplicationException e) {
            LOG.error("ERROR LOADING PROPERTY FILES");
             UnlockLogUtil.errorInfo(UnlockConstants
                     .UNLOCK_BUNDLE_ACTIVATOR,
                     "start", "[Exception caught: Class "
                             + UnlockConstants.UNLOCK_BUNDLE_ACTIVATOR
                             + " : method : " + "start"
                             + "]",
                             UnlockExceptionUtil.generateStackTraceString(e));

        }
*/
    }

    /**
     * <b>Name:</b> start.
     * <b>Purpose:</b>This Method to stop the bundle context.
     * @param context as BundleContext
     */
    public final void stop(final BundleContext context) {
        LOG.debug("Stopping the bundle");
    }

}
