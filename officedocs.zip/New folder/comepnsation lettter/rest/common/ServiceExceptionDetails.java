package com.att.unlock.rest.common;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * <b>Name:</b> ServiceExceptionDetails.
 * <b>Purpose:</b>This class is designed to generate service exception.
 * @author SS00349933
 *
 */
@XmlRootElement(name = "ServiceExceptionDetails")
public class ServiceExceptionDetails implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    /**
     *
     */
    private String faultCode;
    /**
     *
     */
    private String faultMessage;

    /**
     * <b>Name:</b> ServiceExceptionDetails class constructor.
     */
    public ServiceExceptionDetails() {
    }

    /**
     * @return the faultCode
     */
    public final String getFaultCode() {
        return faultCode;
    }

    /**
     * @param faultCodes the faultCode to set
     */
    public final void setFaultCode(final String faultCodes) {
        faultCode = faultCodes;
    }

    /**
     * @return the faultMessage
     */
    public final String getFaultMessage() {
        return faultMessage;
    }

    /**
     * @param faultMessages
     *            the faultMessage to set
     */
    public final void setFaultMessage(final String faultMessages) {
        faultMessage = faultMessages;
    }

}
