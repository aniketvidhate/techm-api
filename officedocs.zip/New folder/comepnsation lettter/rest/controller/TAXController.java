package com.att.unlock.rest.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.interceptor.InInterceptors;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;
import javax.servlet.http.HttpServletRequest;
import com.att.unlock.api.TAXService;
import com.att.unlock.api.common.UnlockServiceException;
import com.att.unlock.api.vo.CalculateTaxRequest;
import com.att.unlock.api.vo.CalculateTaxResponse;
import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.rest.validator.UnlockValidator;

/**
 * <b>Name:</b> TAXController. <b>Purpose:</b>This class is designed as a
 * controller for calculation of tax on the basis of ZIP code enetered by user.
 *
 * @author VV00124304
 *
 */

@CrossOriginResourceSharing(allowAllOrigins = true, allowCredentials = true, maxAge = UnlockConstants.MAX_AGE, allowHeaders = { })
@InInterceptors(interceptors = { "com.att.unlock.rest.common.CSRFTokenInterceptor" })
@Path("/UnlockUtility/Tax")
public class TAXController {

    /**
     * TAXService Service.
     */
    private TAXService taxService;

    /**
     * TAXValidator Validator.
     */
    private UnlockValidator taxValidator;

    private UnlockResponseHandler responseHandler;

    /**
     * Message to handle csrf token.
     */
    private Message message;

    /**
     * <b>Name:</b> calculateTax. <b>Purpose:</b>This method is used for for
     * calculate tax.
     *
     * @param calculateTaxRequest
     *            as CalculateTaxRequest
     * @return CalculateTaxResponse
     */

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final CalculateTaxResponse calculateTax(
            CalculateTaxRequest calculateTaxRequest) {
        CalculateTaxResponse calculateTaxResponse = null;
        UnlockLogUtil.endPointInfo(UnlockConstants.TAX_CONTROLLER,
                "calculateTax", UnlockConstants.REQUEST + calculateTaxRequest);
        String reqId =  null; 
        // Request Validation
        try {
            message = JAXRSUtils.getCurrentMessage();
            String csrfToken = null;
            if (null != message) {
            csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
            reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.TAX_CONTROLLER,"calculateTax"); 
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {
            List<ErrorDetail> errorList = taxValidator
                    .validate(calculateTaxRequest);
            if (errorList.size() > UnlockConstants.ZERO) {
                if (calculateTaxRequest == null) {
                    calculateTaxRequest = new CalculateTaxRequest();
                }
                calculateTaxResponse = (CalculateTaxResponse) taxValidator
                        .getValidationResponse(calculateTaxRequest, errorList);
                return calculateTaxResponse;
            }
            // Calling Service for getting the Tax details
            calculateTaxResponse = taxService.calculateTax(calculateTaxRequest);
            } else {
                // Preparing the error response
                if (calculateTaxResponse == null) {
                    calculateTaxResponse = new CalculateTaxResponse();
                }

                calculateTaxResponse = (CalculateTaxResponse) responseHandler
                        .setInvalidResponse(calculateTaxResponse,UnlockConstants.ERROR_INTERNAL_STATUS_0025 + reqId + " Invalid CSRF Token ");
            }

        } catch (UnlockServiceException e) {
            UnlockLogUtil.errorInfo(UnlockConstants.TAX_CONTROLLER,
                    "calculateTax", "[Exception caught: Class "
                            + UnlockConstants.TAX_CONTROLLER + " : method : "
                            + "calculateTax" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));

            // Preparing the error response
            if (calculateTaxResponse == null) {
                calculateTaxResponse = new CalculateTaxResponse();
            }

            calculateTaxResponse = (CalculateTaxResponse) responseHandler
                    .handleResponse(calculateTaxResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0026 + reqId);

        } catch (Exception e) {
            UnlockLogUtil.errorInfo(UnlockConstants.TAX_CONTROLLER,
                    "calculateTax", "[Exception caught: Class "
                            + UnlockConstants.TAX_CONTROLLER + " : method : "
                            + "calculateTax" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));

            // Preparing the error response
            if (calculateTaxResponse == null) {
                calculateTaxResponse = new CalculateTaxResponse();
            }
            calculateTaxResponse = (CalculateTaxResponse) responseHandler
                    .handleResponse(calculateTaxResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0027 + reqId);
        }
        // logging the response
        UnlockLogUtil.endPointInfo(UnlockConstants.TAX_CONTROLLER,
                "calculateTax",
                UnlockConstants.RESPONSE + calculateTaxResponse.toString());

        // returning the response to UI
        return calculateTaxResponse;
    }

    /**
     * @return the taxService
     */
    public final TAXService getTaxService() {
        return taxService;
    }

    /**
     * @param taxServicee
     *            the taxService to set
     */
    public final void setTaxService(final TAXService taxServicee) {
        taxService = taxServicee;
    }

    /**
     * @return the taxValidator
     */
    public final UnlockValidator getTaxValidator() {
        return taxValidator;
    }

    /**
     * @param taxValidator
     *            the taxValidator to set
     */
    public final void setTaxValidator(UnlockValidator taxValidator) {
        this.taxValidator = taxValidator;
    }

    /**
     * @return the responseHandler
     */
    public UnlockResponseHandler getResponseHandler() {
        return responseHandler;
    }

    /**
     * @param responseHandler
     *            the responseHandler to set
     */
    public void setResponseHandler(UnlockResponseHandler responseHandler) {
        this.responseHandler = responseHandler;
    }
    
    /**
     * @return
     */
    private String getRemoteIp(Message message,String className,String methodName) {
        String remoteIPAddress;
        HttpServletRequest request = (HttpServletRequest)message.get("HTTP.REQUEST");
        
        if (request == null){
            UnlockLogUtil.errorInfo(className,
                    methodName, UnlockConstants.REQUEST,
            "request is null from message! ");
        }
        remoteIPAddress = request.getHeader("X-Real-IP");
        if (remoteIPAddress == null) {
            String ips = request.getHeader("X-Forwarded-For");
            if (ips != null) {
                remoteIPAddress = ips.split(",")[0];
            }
            else {
                 remoteIPAddress = request.getRemoteAddr();
            }
        }
        return remoteIPAddress;
    }

}
