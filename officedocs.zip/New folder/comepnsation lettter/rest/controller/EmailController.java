package com.att.unlock.rest.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.interceptor.InInterceptors;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;
import javax.servlet.http.HttpServletRequest;
import com.att.unlock.api.EmailService;
import com.att.unlock.api.common.UnlockServiceException;
import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.ResendEmailNotificationRequest;
import com.att.unlock.api.vo.ResendEmailNotificationResponse;
import com.att.unlock.api.vo.UnlockValidateEmailRequest;
import com.att.unlock.api.vo.UnlockValidateEmailResponse;
import com.att.unlock.api.vo.UnlockVerifyEmailRequest;
import com.att.unlock.api.vo.UnlockVerifyEmailResponse;
import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.rest.validator.UnlockValidator;

/**
 * <b>Name:</b> EmailController. <b>Purpose:</b>This class is designed as a
 * controller to validate and verify and resend email functionality .
 *
 * @author
 */

@CrossOriginResourceSharing(allowAllOrigins = false, allowCredentials = true, maxAge = UnlockConstants.MAX_AGE, allowHeaders = { })
@InInterceptors(interceptors = { "com.att.unlock.rest.common.CSRFTokenInterceptor" })
@Path("/UnlockUtility")
public class EmailController {

    /**
    *
    */
    private EmailService emailservice;

    /**
    *
    */
    private UnlockValidator emailValidator;

    private UnlockResponseHandler responseHandler;

   /**
    * Message to handle csrf token.
    */
    private Message message;


    /**
     * <b>Name:</b> validateEmail. <b>Purpose:</b>This method is used to
     * validate the email.
     *
     * @param unlockValidateEmailRequest
     *            as UnlockValidateEmailRequest
     * @return UnlockValidateEmailResponse
     */
    @POST
    @Path("/Verify/ValidateEmail")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final UnlockValidateEmailResponse validateEmail(
            UnlockValidateEmailRequest unlockValidateEmailRequest) {
    	
    	 UnlockLogUtil.endPointInfo(UnlockConstants.EMAIL_CONTROLLER,
                 "validateEmail", UnlockConstants.REQUEST
                         );
    	 
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.EMAIL_CONTROLLER,
                "validateEmail", UnlockConstants.REQUEST
                        + unlockValidateEmailRequest);
        UnlockValidateEmailResponse unlockValidateEmailResponse = null;
        String reqId = null;
        try {
            message = JAXRSUtils.getCurrentMessage();
            String csrfToken = null;
            if (null != message) {
            csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
            reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.EMAIL_CONTROLLER,"validateEmail"); 
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {
                List<ErrorDetail> errorList = emailValidator
                        .validate(unlockValidateEmailRequest);
                if (errorList.size() > 0) {
                    if (null == unlockValidateEmailRequest) {
                        unlockValidateEmailRequest = new UnlockValidateEmailRequest();
                    }
                    // Prepare error response || Pending clarification from
                    unlockValidateEmailResponse = (UnlockValidateEmailResponse) emailValidator
                            .getValidationResponse(unlockValidateEmailRequest,
                                    errorList);
                    return unlockValidateEmailResponse;
                }

                // Call the email service to validate the email
                unlockValidateEmailResponse = emailservice
                        .validateEmailRequest(unlockValidateEmailRequest);
            } else {
                if (unlockValidateEmailResponse == null) {
                    unlockValidateEmailResponse = new UnlockValidateEmailResponse();
                }
                // Preparing the error response
                unlockValidateEmailResponse = (UnlockValidateEmailResponse) responseHandler.
                        setInvalidResponse(unlockValidateEmailResponse,UnlockConstants.ERROR_INTERNAL_STATUS_0016 + reqId + " Invalid CSRF Token ");
            }
        } catch (UnlockServiceException e) {
            UnlockLogUtil.errorInfo(UnlockConstants.EMAIL_CONTROLLER,
                    "validateEmail", "[Exception caught: Class "
                            + UnlockConstants.EMAIL_CONTROLLER + " : method : "
                            + "validateEmail" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (unlockValidateEmailResponse == null) {
                unlockValidateEmailResponse = new UnlockValidateEmailResponse();
            }
            // Preparing the error response
            unlockValidateEmailResponse = (UnlockValidateEmailResponse) responseHandler
                    .handleResponse(unlockValidateEmailResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0017 + reqId);
        } catch (Exception e) {
            UnlockLogUtil.errorInfo(UnlockConstants.EMAIL_CONTROLLER,
                    "validateEmail", "[Exception caught: Class "
                            + UnlockConstants.EMAIL_CONTROLLER + " : method : "
                            + "validateEmail" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (unlockValidateEmailResponse == null) {
                unlockValidateEmailResponse = new UnlockValidateEmailResponse();
            }
            // Preparing the error response
            unlockValidateEmailResponse = (UnlockValidateEmailResponse) responseHandler
                    .handleResponse(unlockValidateEmailResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0018 + reqId);
        }
        
        UnlockLogUtil.endPointInfo(UnlockConstants.EMAIL_CONTROLLER,
                "validateEmail", UnlockConstants.RESPONSE
                        );
        
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.EMAIL_CONTROLLER,
                "validateEmail", UnlockConstants.RESPONSE
                        + unlockValidateEmailResponse.toString());
        return unlockValidateEmailResponse;
    }

    /**
     * <b>Name:</b> verifyEmail. <b>Purpose:</b>This method is used to verify
     * the email.
     *
     * @param unlockVerifyEmailRequest
     *            as UnlockVerifyEmailRequest
     * @return UnlockVerifyEmailResponse as UnlockVerifyEmailResponse
     */
    @POST
    @Path("/Verify/VerifyEmail")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final UnlockVerifyEmailResponse verifyEmail(
            UnlockVerifyEmailRequest unlockVerifyEmailRequest) {
    	
    	 UnlockLogUtil.endPointInfo(UnlockConstants.EMAIL_CONTROLLER,
                 "verifyEmail", UnlockConstants.REQUEST
                         );
    	 
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.EMAIL_CONTROLLER,
                "verifyEmail", UnlockConstants.REQUEST
                        + unlockVerifyEmailRequest);
        UnlockVerifyEmailResponse unlockVerifyEmailResponse = null;
        String reqId = null;
        try {
            message = JAXRSUtils.getCurrentMessage();
            String csrfToken = null;
            if (null != message) {
            csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
            reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.EMAIL_CONTROLLER,"verifyEmail"); 
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {
                List<ErrorDetail> errorList = emailValidator
                        .validate(unlockVerifyEmailRequest);
                if (errorList.size() > 0) {
                    if (null == unlockVerifyEmailRequest) {
                        unlockVerifyEmailRequest = new UnlockVerifyEmailRequest();
                    }
                    unlockVerifyEmailResponse = (UnlockVerifyEmailResponse) emailValidator
                            .getValidationResponse(unlockVerifyEmailRequest,
                                    errorList);
                    return unlockVerifyEmailResponse;
                }

                // Call the email service to verify the email
                unlockVerifyEmailResponse = emailservice
                        .verifyEmailRequest(unlockVerifyEmailRequest);
            } else {
                if (unlockVerifyEmailResponse == null) {
                    unlockVerifyEmailResponse = new UnlockVerifyEmailResponse();
                }
                // Preparing the error response
                unlockVerifyEmailResponse = (UnlockVerifyEmailResponse) responseHandler
                        .setInvalidResponse(unlockVerifyEmailResponse,UnlockConstants.ERROR_INTERNAL_STATUS_0019 + reqId + " Invalid CSRF Token ");

            }
        } catch (UnlockServiceException e) {
            UnlockLogUtil.errorInfo(UnlockConstants.EMAIL_CONTROLLER,
                    "verifyEmail", "[Exception caught: Class "
                            + UnlockConstants.EMAIL_CONTROLLER + " : method : "
                            + "verifyEmail" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (unlockVerifyEmailResponse == null) {
                unlockVerifyEmailResponse = new UnlockVerifyEmailResponse();
            }
            // Preparing the error response
            unlockVerifyEmailResponse = (UnlockVerifyEmailResponse) responseHandler
                    .handleResponse(unlockVerifyEmailResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0020 + reqId);

        } catch (Exception e) {
            UnlockLogUtil.errorInfo(UnlockConstants.EMAIL_CONTROLLER,
                    "verifyEmail", "[Exception caught: Class "
                            + UnlockConstants.EMAIL_CONTROLLER + " : method : "
                            + "verifyEmail" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (unlockVerifyEmailResponse == null) {
                unlockVerifyEmailResponse = new UnlockVerifyEmailResponse();
            }
            // Preparing the error response
            unlockVerifyEmailResponse = (UnlockVerifyEmailResponse) responseHandler
                    .handleResponse(unlockVerifyEmailResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0021 + reqId);
        }

        UnlockLogUtil.endPointInfo(UnlockConstants.EMAIL_CONTROLLER,
                "verifyEmail", UnlockConstants.RESPONSE
                        );
        
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.EMAIL_CONTROLLER,
                "verifyEmail", UnlockConstants.RESPONSE
                        + unlockVerifyEmailResponse.toString());
        return unlockVerifyEmailResponse;
    }

    /**
     * <b>Name:</b> resendEmail. <b>Purpose:</b>This method is used to resend
     * the email notification.
     *
     * @param resendEmailNotificationRequest
     *            as ResendEmailNotificationRequest
     * @return ResendEmailNotificationResponse
     */
    @POST
    @Path("/resendEmail")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final ResendEmailNotificationResponse resendEmail(
            ResendEmailNotificationRequest resendEmailNotificationRequest) {
    	
        UnlockLogUtil.endPointInfo(UnlockConstants.EMAIL_CONTROLLER,
                "resendEmail", UnlockConstants.RESPONSE
                        );
        
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.EMAIL_CONTROLLER,
                "resendEmail", UnlockConstants.RESPONSE
                        + resendEmailNotificationRequest);

        ResendEmailNotificationResponse resendEmailNotificationResponse = null;
        String reqId = null;
        try {
            message = JAXRSUtils.getCurrentMessage();
            String csrfToken = null;
            if (null != message) {
            csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
            reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.EMAIL_CONTROLLER,"resendEmail"); 
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {
                List<ErrorDetail> errorList = emailValidator
                        .validate(resendEmailNotificationRequest);
                if (errorList.size() > 0) {
                    if (null == resendEmailNotificationRequest) {
                        resendEmailNotificationRequest = new ResendEmailNotificationRequest();
                    }
                    resendEmailNotificationResponse = (ResendEmailNotificationResponse) emailValidator
                            .getValidationResponse(
                                    resendEmailNotificationRequest, errorList);
                    return resendEmailNotificationResponse;
                }
                // Call the email service to resend the email notification
                resendEmailNotificationResponse = emailservice
                        .resendEmailNotification(resendEmailNotificationRequest);
            } else {
                if (resendEmailNotificationResponse == null) {
                    resendEmailNotificationResponse = new ResendEmailNotificationResponse();
                }
                // Preparing the error response
                resendEmailNotificationResponse = (ResendEmailNotificationResponse) responseHandler
                        .setInvalidResponse(resendEmailNotificationResponse,UnlockConstants.ERROR_INTERNAL_STATUS_0022 + reqId + " Invalid CSRF Token ");
            }
        } catch (UnlockServiceException e) {
            UnlockLogUtil.errorInfo(UnlockConstants.EMAIL_CONTROLLER,
                    "resendEmail", "[Exception caught: Class "
                            + UnlockConstants.EMAIL_CONTROLLER + " : method : "
                            + "resendEmail" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (resendEmailNotificationResponse == null) {
                resendEmailNotificationResponse = new ResendEmailNotificationResponse();
            }
            // Preparing the error response
            resendEmailNotificationResponse = (ResendEmailNotificationResponse) responseHandler
                    .handleResponse(resendEmailNotificationResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0023 + reqId);

        } catch (Exception e) {
            UnlockLogUtil.errorInfo(UnlockConstants.EMAIL_CONTROLLER,
                    "resendEmail", "[Exception caught: Class "
                            + UnlockConstants.EMAIL_CONTROLLER + " : method : "
                            + "resendEmail" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (resendEmailNotificationResponse == null) {
                resendEmailNotificationResponse = new ResendEmailNotificationResponse();
            }

            // Preparing the error response
            resendEmailNotificationResponse = (ResendEmailNotificationResponse) responseHandler
                    .handleResponse(resendEmailNotificationResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0024 + reqId);
        }

        
        UnlockLogUtil.endPointInfo(UnlockConstants.EMAIL_CONTROLLER,
                "resendEmail", UnlockConstants.RESPONSE
                        );
        
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.EMAIL_CONTROLLER,
                "resendEmail", UnlockConstants.RESPONSE
                        + resendEmailNotificationResponse.toString());
        return resendEmailNotificationResponse;
    }

    /**
     * @return the emailservice
     */
    public final EmailService getEmailservice() {
        return emailservice;
    }

    /**
     * @param emailservicee
     *            the emailservice to set
     */
    public final void setEmailservice(final EmailService emailservicee) {
        emailservice = emailservicee;
    }

    /**
     * @return the emailValidator
     */
    public final UnlockValidator getEmailValidator() {
        return emailValidator;
    }

    /**
     * @param emailValidatorr
     *            the emailValidator to set
     */
    public final void setEmailValidator(final UnlockValidator emailValidatorr) {
        emailValidator = emailValidatorr;
    }

    /**
     * @return the responseHandler
     */
    public UnlockResponseHandler getResponseHandler() {
        return responseHandler;
    }

    /**
     * @param responseHandler
     *            the responseHandler to set
     */
    public void setResponseHandler(UnlockResponseHandler responseHandler) {
        this.responseHandler = responseHandler;
    }
    
    /**
     * @return
     */
    private String getRemoteIp(Message message,String className,String methodName) {
        String remoteIPAddress;
        HttpServletRequest request = (HttpServletRequest)message.get("HTTP.REQUEST");
        
        if (request == null){
            UnlockLogUtil.errorInfo(className,
                    methodName, UnlockConstants.REQUEST,
            "request is null from message! ");
        }
        remoteIPAddress = request.getHeader("X-Real-IP");
        if (remoteIPAddress == null) {
            String ips = request.getHeader("X-Forwarded-For");
            if (ips != null) {
                remoteIPAddress = ips.split(",")[0];
            }
            else {
                 remoteIPAddress = request.getRemoteAddr();
            }
        }
        return remoteIPAddress;
    }
}
