package com.att.unlock.rest.controller;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.interceptor.InInterceptors;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;

import com.att.unlock.api.OrderService;
import com.att.unlock.api.common.UnlockServiceException;
import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.OCEUnlockOrderStatusDO;
import com.att.unlock.api.vo.UnlockBaseVO;
import com.att.unlock.api.vo.UnlockOrderRequest;
import com.att.unlock.api.vo.UnlockOrderResponse;
import com.att.unlock.api.vo.UnlockOrderStatusRequest;
import com.att.unlock.api.vo.UnlockOrderStatusResponse;
import com.att.unlock.api.vo.ValidationErrors;
import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.rest.validator.UnlockValidator;

/**
 * <b>Name:</b> OrderController. <b>Purpose:</b>This class is designed as a
 * controller for unlock order submit request and unlock order lookup.
 *
 * @author VS00343711
 */

@CrossOriginResourceSharing(allowAllOrigins = false, allowCredentials = true, maxAge = UnlockConstants.MAX_AGE, allowHeaders = { })
@InInterceptors(interceptors = { "com.att.unlock.rest.common.CSRFTokenInterceptor" })
@Path("/UnlockOrder")
public class OrderController {

 
	/**
     * OrderService Service.
     */
    private OrderService orderService;

    /**
     * UnlockValidator Validator.
     */
    private UnlockValidator orderValidator;

    private UnlockResponseHandler responseHandler;

    /**
     * Message to handle csrf token.
     */
    private Message message;

    /**
     * <b>Name:</b> unlockOrderRequest. <b>Purpose:</b>This method used to
     * submit unlock order request.
     *
     * @param unlockOrderRequest
     *            as UnlockOrderRequest
     * @return UnlockOrderResponse
     */

    @POST
    @Path("/unlockOrder")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final UnlockOrderResponse unlockOrderRequest(
            UnlockOrderRequest unlockOrderRequest) {
        UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                 "unlockOrderRequest", UnlockConstants.REQUEST + "name");
    
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                "unlockOrderRequest", UnlockConstants.REQUEST,
                unlockOrderRequest);
        String reqId = null;
        UnlockOrderResponse unlockOrderResponse = null;
        try {
            message = JAXRSUtils.getCurrentMessage();
            UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                    "unlockOrderRequest", "message:" + message);
            
            String csrfToken = null;
            if (null != message) {
            reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.ORDER_CONTROLLER,"unlockOrderRequest");    
            //If CSRF token is valid or if securityGateWayEnable is false, this will be null
            csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);            
            UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                    "unlockOrderRequest", "csrfToken:" + csrfToken + reqId);
            
            
            if(unlockOrderRequest != null && unlockOrderRequest.getOrderDetail() != null)
            {
            unlockOrderRequest.getOrderDetail().setIpAddress(this.getRemoteIp(message,UnlockConstants.ORDER_CONTROLLER,"unlockOrderRequest"));
            }
            UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                    "unlockOrderRequest", UnlockConstants.REQUEST + reqId);
            
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {              
             UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                     "unlockOrderRequest", "csrf token is valid" + reqId);
             
                List<ErrorDetail> errorList = orderValidator
                        .validate(unlockOrderRequest);                
                //QC#40632, Added 'OR' condition to check email domain
                //There are errors or email is from prohibited domain
                //Log as error, do not hide
                if (errorList.size() > UnlockConstants.ZERO  || 
                        orderService.checkEmailDomain(unlockOrderRequest)) { 
                    if(errorList.size() > UnlockConstants.ZERO)
                    {
                        UnlockLogUtil.errorInfo(UnlockConstants.ORDER_CONTROLLER,
                                "unlockOrderRequest", "errorList.size():" + errorList.size(),"");  
                    }
                    else
                    {
                        UnlockLogUtil.errorInfo(UnlockConstants.ORDER_CONTROLLER,
                                "unlockOrderRequest", "Email is in blocked list", ""); 
                    }
                    if (unlockOrderRequest == null) {
                        unlockOrderRequest = new UnlockOrderRequest();
                    }
                    unlockOrderResponse = (UnlockOrderResponse) orderValidator
                            .getValidationResponse(unlockOrderRequest,
                                    errorList);
                    return unlockOrderResponse;
                }
                unlockOrderResponse = orderService
                        .submitUnlockOrderRequest(unlockOrderRequest);
            } else {                
             UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                     "unlockOrderRequest", "csrf token is Invalid");
             
                if (unlockOrderResponse == null) {
                    unlockOrderResponse = new UnlockOrderResponse();
                }
                // Preparing the error response
                unlockOrderResponse = (UnlockOrderResponse) responseHandler
                        .setInvalidResponse(unlockOrderResponse, UnlockConstants.ERROR_INTERNAL_STATUS_0001 + reqId + " Invalid CSRF Token ");

            }
        } catch (UnlockServiceException e) {
            UnlockLogUtil.errorInfo(UnlockConstants.ORDER_CONTROLLER,
                    "unlockOrderRequest", "[Exception caught: Class "
                            + UnlockConstants.ORDER_CONTROLLER + " : method : "
                            + "unlockOrderRequest" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));

            // Preparing the error response
            if (unlockOrderResponse == null) {
                unlockOrderResponse = new UnlockOrderResponse();
            }

            unlockOrderResponse = (UnlockOrderResponse) responseHandler
                    .handleResponse(unlockOrderResponse, e, UnlockConstants.ERROR_INTERNAL_STATUS_0002 + reqId);

        } catch (Exception e) {
            UnlockLogUtil.errorInfo(UnlockConstants.ORDER_CONTROLLER,
                    "unlockOrderRequest", "[Exception caught: Class "
                            + UnlockConstants.ORDER_CONTROLLER + " : method : "
                            + "unlockOrderRequest" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));

            // Preparing the error response
            if (unlockOrderResponse == null) {
                unlockOrderResponse = new UnlockOrderResponse();
            }
            unlockOrderResponse = (UnlockOrderResponse) responseHandler
                    .handleResponse(unlockOrderResponse, e, UnlockConstants.ERROR_INTERNAL_STATUS_0003 + reqId);
        }
        UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                "unlockOrderRequest", UnlockConstants.RESPONSE);
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                "unlockOrderRequest", UnlockConstants.RESPONSE
                        + unlockOrderResponse.toString());
        return unlockOrderResponse;

    }

    

    /**
     * <b>Name:</b> unlockOrderStatus. <b>Purpose:</b>This method is used for
     * unlock order lookup.
     *
     * @param unlockOrderStatusRequest
     *            as UnlockOrderStatusRequest
     * @return UnlockOrderStatusResponse
     * @throws WebApplicationException
     */
    @POST
    @Path("/unlockOrderStatus")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final UnlockBaseVO unlockOrderStatus(
            UnlockOrderStatusRequest unlockOrderStatusRequest) {
    	boolean isOCEOrder=isOCEOrder(unlockOrderStatusRequest);
        UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                "unlockOrderStatus", UnlockConstants.REQUEST);
        
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                "unlockOrderStatus", UnlockConstants.REQUEST,
                unlockOrderStatusRequest);
        UnlockOrderStatusResponse unlockOrderStatusResponse = null;
        OCEUnlockOrderStatusDO OCEorderStatusDO=null;
        String reqId = null;        
        try {
            message = JAXRSUtils.getCurrentMessage();
            String csrfToken = null;
            if (null != message) {
            csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
            reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.ORDER_CONTROLLER,"unlockOrderStatus");            
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {
            	List<ErrorDetail> errorList =new ArrayList<ErrorDetail>();
            	if(!isOCEOrder) {
            		errorList = orderValidator.validate(unlockOrderStatusRequest);
            	}
                    
                if (errorList.size() > UnlockConstants.ZERO) {
                    if (unlockOrderStatusRequest == null) {
                        unlockOrderStatusRequest = new UnlockOrderStatusRequest();
                    }
                    if(isOCEOrder) {
                    	//its OCEOrder
                    	OCEUnlockOrderStatusDO OCEStatusDO=new OCEUnlockOrderStatusDO();
                    	ValidationErrors errors=new ValidationErrors();
                    	errors.setErrorList(errorList);
                    	OCEStatusDO.setValidationErrors(errors);
                    	return OCEStatusDO;
                    } else {
                    unlockOrderStatusResponse = (UnlockOrderStatusResponse) orderValidator
                            .getValidationResponse(unlockOrderStatusRequest,
                                    errorList);
                    return unlockOrderStatusResponse;
                    }
                }
                if(isOCEOrder) {
                	OCEorderStatusDO=orderService.getOrderStatusByOCE(unlockOrderStatusRequest);
                } else {
                unlockOrderStatusRequest.getOrderDetail().setIpAddress(this.getRemoteIp(message,UnlockConstants.ORDER_CONTROLLER,"unlockOrderStatus"));
                unlockOrderStatusResponse = orderService
                        .unlockOrderStatus(unlockOrderStatusRequest);
                }
            } else {
                //CSRF token is invalid
            	if(isOCEOrder) {

                    if (OCEorderStatusDO == null) {
                    	OCEorderStatusDO = new OCEUnlockOrderStatusDO();
                    }
                    OCEorderStatusDO = (OCEUnlockOrderStatusDO) responseHandler
                            .setInvalidResponse(OCEorderStatusDO);
                
            	}
            	else {
            
                if (unlockOrderStatusResponse == null) {
                    unlockOrderStatusResponse = new UnlockOrderStatusResponse();
                }
                unlockOrderStatusResponse = (UnlockOrderStatusResponse) responseHandler
                        .setInvalidResponse(unlockOrderStatusResponse, UnlockConstants.ERROR_INTERNAL_STATUS_0004 + reqId + " Invalid CSRF Token ");
            		}
            	}
            
        } catch (UnlockServiceException e) {
            UnlockLogUtil.errorInfo(UnlockConstants.ORDER_CONTROLLER,
                    "unlockOrderStatus", "[Exception caught: Class "
                            + UnlockConstants.ORDER_CONTROLLER + " : method : "
                            + "unlockOrderStatus" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            // Preparing the error response
            if (unlockOrderStatusResponse == null) {
                unlockOrderStatusResponse = new UnlockOrderStatusResponse();
            }
           unlockOrderStatusResponse = (UnlockOrderStatusResponse) responseHandler
                    .handleResponse(unlockOrderStatusResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0005 + reqId);

        } catch (Exception e) {
            UnlockLogUtil.errorInfo(UnlockConstants.ORDER_CONTROLLER,
                    "unlockOrderStatus", "[Exception caught: Class "
                            + UnlockConstants.ORDER_CONTROLLER + " : method : "
                            + "unlockOrderStatus" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            // Preparing the error response
            if (unlockOrderStatusResponse == null) {
                unlockOrderStatusResponse = new UnlockOrderStatusResponse();
            }
            unlockOrderStatusResponse = (UnlockOrderStatusResponse) responseHandler
                    .handleResponse(unlockOrderStatusResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0006 + reqId);

        }
        UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                "unlockOrderStatus", UnlockConstants.RESPONSE);
        if(isOCEOrder) { 
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                "unlockOrderStatus", UnlockConstants.RESPONSE
                        + OCEorderStatusDO.toString());
        
        	return OCEorderStatusDO;
        }
        else {
        	  UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                      "unlockOrderStatus",reqId + ":" + UnlockConstants.RESPONSE+ unlockOrderStatusResponse.toString());
        return unlockOrderStatusResponse;
        }

    }

    private boolean isOCEOrder(UnlockOrderStatusRequest unlockOrderStatusRequest) {
		// TODO Auto-generated method stub
    	String orderNumber=unlockOrderStatusRequest.getOrderDetail().getOrderNumber();
//    	String validationString=orderNumber.substring(0,4);
    	boolean isOCEOrder=false;
    	//OCE Order Conditions
    	if(orderNumber.startsWith(UnlockConstants.OCE_ATT_ORDER_PREFIX) ||orderNumber.startsWith(UnlockConstants.OCE_NON_ATT_ORDER_PREFIX)) {
    		isOCEOrder=true;
    	}
		return isOCEOrder;
	}

	/**
     * @return the orderService
     */
    public final OrderService getOrderService() {
        return orderService;
    }

    /**
     * @param orderServicee
     *            the orderService to set
     */
    public final void setOrderService(final OrderService orderServicee) {
        orderService = orderServicee;
    }

    /**
     * @return the orderValidator
     */
    public final UnlockValidator getOrderValidator() {
        return orderValidator;
    }

    /**
     * @param orderValidatorr
     *            the orderValidator to set
     */
    public final void setOrderValidator(final UnlockValidator orderValidatorr) {
        orderValidator = orderValidatorr;
    }

    /**
     * @return the responseHandler
     */
    public UnlockResponseHandler getResponseHandler() {
        return responseHandler;
    }

    /**
     * @param responseHandler
     *            the responseHandler to set
     */
    public void setResponseHandler(UnlockResponseHandler responseHandler) {
        this.responseHandler = responseHandler;
    }
    
    /**
     * @return
     */
    private String getRemoteIp(Message message,String className,String methodName) {
        String remoteIPAddress;
        HttpServletRequest request = (HttpServletRequest)message.get("HTTP.REQUEST");
        
        if (request == null){
            UnlockLogUtil.errorInfo(className,
                    methodName, UnlockConstants.REQUEST,
            "request is null from message! ");
        }
        remoteIPAddress = request.getHeader("X-Real-IP");
        if (remoteIPAddress == null) {
            String ips = request.getHeader("X-Forwarded-For");
            if (ips != null) {
                remoteIPAddress = ips.split(",")[0];
            }
            else {
                 remoteIPAddress = request.getRemoteAddr();
            }
        }
        return remoteIPAddress;
    }
}
