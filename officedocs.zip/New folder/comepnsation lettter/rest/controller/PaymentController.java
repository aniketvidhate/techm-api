package com.att.unlock.rest.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.servlet.http.HttpServletRequest;
import org.apache.cxf.interceptor.InInterceptors;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;

import com.att.unlock.api.PaymentService;
import com.att.unlock.api.common.UnlockServiceException;
import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.UnLockVerifyPaymentDetailRequest;
import com.att.unlock.api.vo.UnLockVerifyPaymentDetailResponse;
import com.att.unlock.api.vo.UnlockPaymentProcessRequest;
import com.att.unlock.api.vo.UnlockPaymentProcessResponse;
import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.rest.validator.UnlockValidator;

/**
 * <b>Name:</b> PaymentController. <b>Purpose:</b>This class is designed as a
 * controller for providing wireline payment service to the UI.
 *
 * @author VV00124304
 */

@CrossOriginResourceSharing(allowAllOrigins = true, allowCredentials = true, maxAge = UnlockConstants.MAX_AGE, allowHeaders = { })
@InInterceptors(interceptors = { "com.att.unlock.rest.common.CSRFTokenInterceptor" })
@Path("/UnlockUtility/Payment")
public class PaymentController {

    /**
     * PaymentService Service.
     */
    private PaymentService paymentService;

    /**
     * paymentValidator as PaymentValidato to handle validation.
     */
    private UnlockValidator paymentValidator;

    /**
     * responseHandler as PaymentValidator to handle Exception.
     */
    private UnlockResponseHandler responseHandler;

    /**
     * Message to handle csrf token.
     */
    private Message message;

    /**
     * <b>Name:</b> VerifyPayment. <b>Purpose:</b>This method invoke
     * verifyPayment method of paymentService.
     *
     * @author
     * @param unlockVerifyPaymentRequest
     *            as UnLockVerifyPaymentDetailRequest
     * @return UnLockVerifyPaymentDetailResponse
     */

    @POST
    @Path("/VerifyPayment")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final UnLockVerifyPaymentDetailResponse verifyPayment(
            UnLockVerifyPaymentDetailRequest unlockVerifyPaymentRequest) {

        UnlockLogUtil.endPointInfo(UnlockConstants.PAYMENT_CONTROLLER,
                "verifyPayment", UnlockConstants.REQUEST,
                unlockVerifyPaymentRequest);
        String reqId = null;
        UnLockVerifyPaymentDetailResponse unlockVerifyPaymentResponse = null;
        try {
            message = JAXRSUtils.getCurrentMessage();
            String csrfToken = null;
            if (null != message) {
            csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
            reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.PAYMENT_CONTROLLER,"verifyPayment"); 
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {
                List<ErrorDetail> errorList = paymentValidator
                        .validate(unlockVerifyPaymentRequest);
                if (errorList.size() > UnlockConstants.ZERO) {

                    if (null == unlockVerifyPaymentRequest) {
                        unlockVerifyPaymentRequest = new UnLockVerifyPaymentDetailRequest();
                    }
                    unlockVerifyPaymentResponse = (UnLockVerifyPaymentDetailResponse) paymentValidator
                            .getValidationResponse(unlockVerifyPaymentRequest,
                                    errorList);
                    return unlockVerifyPaymentResponse;

                }

                // Call the payment service to verify the payment
                unlockVerifyPaymentResponse = paymentService
                        .verifyPayment(unlockVerifyPaymentRequest);
            } else {
                if (unlockVerifyPaymentResponse == null) {
                    unlockVerifyPaymentResponse = new UnLockVerifyPaymentDetailResponse();
                }

                // Preparing the error response
                unlockVerifyPaymentResponse = (UnLockVerifyPaymentDetailResponse) responseHandler
                        .setInvalidResponse(unlockVerifyPaymentResponse,UnlockConstants.ERROR_INTERNAL_STATUS_0010 + reqId + " Invalid CSRF Token ");
            }
        } catch (UnlockServiceException e) {
            UnlockLogUtil.errorInfo(UnlockConstants.PAYMENT_CONTROLLER,
                    "verifyPayment", "[Exception caught: Class "
                            + UnlockConstants.PAYMENT_CONTROLLER
                            + " : method : " + "verifyPayment" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (unlockVerifyPaymentResponse == null) {
                unlockVerifyPaymentResponse = new UnLockVerifyPaymentDetailResponse();
            }

            // Preparing the error response
            unlockVerifyPaymentResponse = (UnLockVerifyPaymentDetailResponse) responseHandler
                    .handleResponse(unlockVerifyPaymentResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0011 + reqId);

        } catch (Exception e) {
            UnlockLogUtil.errorInfo(UnlockConstants.PAYMENT_CONTROLLER,
                    "verifyPayment", "[Exception caught: Class "
                            + UnlockConstants.EMAIL_CONTROLLER + " : method : "
                            + "verifyPayment" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (unlockVerifyPaymentResponse == null) {
                unlockVerifyPaymentResponse = new UnLockVerifyPaymentDetailResponse();
            }

            // Preparing the error response
            unlockVerifyPaymentResponse = (UnLockVerifyPaymentDetailResponse) responseHandler
                    .handleResponse(unlockVerifyPaymentResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0012 + reqId);

        }

        UnlockLogUtil.endPointInfo(UnlockConstants.PAYMENT_CONTROLLER,
                "verifyPayment", UnlockConstants.RESPONSE,
                unlockVerifyPaymentResponse);

        return unlockVerifyPaymentResponse;
    }

    /**
     * <b>Name:</b> paymentProcessRequest. <b>Purpose:</b>This method invoke
     * paymentProcessRequest method of paymentService.
     *
     * @author
     * @param unlockPaymentProcessRequest
     *            as UnlockPaymentProcessRequest
     * @return UnlockPaymentProcessResponse
     */

    @POST
    @Path("/Payment")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final UnlockPaymentProcessResponse paymentProcessRequest(
            UnlockPaymentProcessRequest unlockPaymentProcessRequest) {

        UnlockLogUtil.endPointInfo(UnlockConstants.PAYMENT_CONTROLLER,
                "paymentProcessRequest", UnlockConstants.REQUEST,
                unlockPaymentProcessRequest);
        String reqId = null;
        UnlockPaymentProcessResponse unlockPaymentProcessResponse = null;
        try {
            message = JAXRSUtils.getCurrentMessage();
            String csrfToken = null;
            if (null != message) {
            csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
            reqId = ":IP:" + this.getRemoteIp(message,UnlockConstants.PAYMENT_CONTROLLER,"paymentProcessRequest");   
            }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {
                List<ErrorDetail> errorList = paymentValidator
                        .validate(unlockPaymentProcessRequest);
                if (errorList.size() > UnlockConstants.ZERO) {
                    if (null == unlockPaymentProcessRequest) {
                        unlockPaymentProcessRequest = new UnlockPaymentProcessRequest();
                    }
                    unlockPaymentProcessResponse = (UnlockPaymentProcessResponse) paymentValidator
                            .getValidationResponse(unlockPaymentProcessRequest,
                                    errorList);
                    return unlockPaymentProcessResponse;
                }

                // Call the payment service to verify the process the payment
                unlockPaymentProcessResponse = paymentService
                        .paymentProcessRequest(unlockPaymentProcessRequest);
            } else {
                if (unlockPaymentProcessResponse == null) {
                    unlockPaymentProcessResponse = new UnlockPaymentProcessResponse();
                }
                // Preparing the error response
                unlockPaymentProcessResponse = (UnlockPaymentProcessResponse) responseHandler
                        .setInvalidResponse(unlockPaymentProcessResponse,UnlockConstants.ERROR_INTERNAL_STATUS_0013 + reqId + " Invalid CSRF Token ");
            }
        } catch (UnlockServiceException e) {
            UnlockLogUtil.errorInfo(UnlockConstants.PAYMENT_CONTROLLER,
                    "paymentProcessRequest", "[Exception caught: Class "
                            + UnlockConstants.PAYMENT_CONTROLLER
                            + " : method : " + "paymentProcessRequest" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (unlockPaymentProcessResponse == null) {
                unlockPaymentProcessResponse = new UnlockPaymentProcessResponse();
            }
            // Preparing the error response
            unlockPaymentProcessResponse = (UnlockPaymentProcessResponse) responseHandler
                    .handleResponse(unlockPaymentProcessResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0014 + reqId);
        } catch (Exception e) {
            UnlockLogUtil.errorInfo(UnlockConstants.PAYMENT_CONTROLLER,
                    "paymentProcessRequest", "[Exception caught: Class "
                            + UnlockConstants.PAYMENT_CONTROLLER
                            + " : method : " + "paymentProcessRequest" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (unlockPaymentProcessResponse == null) {
                unlockPaymentProcessResponse = new UnlockPaymentProcessResponse();
            }
            // Preparing the error response
            unlockPaymentProcessResponse = (UnlockPaymentProcessResponse) responseHandler
                    .handleResponse(unlockPaymentProcessResponse, e,UnlockConstants.ERROR_INTERNAL_STATUS_0015 + reqId);
        }

        UnlockLogUtil.endPointInfo(UnlockConstants.PAYMENT_CONTROLLER,
                "paymentProcessRequest", UnlockConstants.RESPONSE,
                unlockPaymentProcessResponse);

        return unlockPaymentProcessResponse;
    }

    /**
     * @return the paymentService
     */
    public final PaymentService getPaymentService() {
        return paymentService;
    }

    /**
     * @param paymentServices
     *            the paymentServices to set
     */
    public final void setPaymentService(final PaymentService paymentServices) {
        this.paymentService = paymentServices;
    }

    /**
     * @return the paymentValidator
     */
    public final UnlockValidator getPaymentValidator() {
        return paymentValidator;
    }

    /**
     * @param paymentValidator
     *            the paymentValidator to set
     */
    public final void setPaymentValidator(UnlockValidator paymentValidator) {
        this.paymentValidator = paymentValidator;
    }

    /**
     * @param responseHandler
     *            the responseHandler to set
     */
    public void setResponseHandler(UnlockResponseHandler responseHandler) {
        this.responseHandler = responseHandler;
    }
    
    /**
     * @return
     */
    private String getRemoteIp(Message message,String className,String methodName) {
        String remoteIPAddress;
        HttpServletRequest request = (HttpServletRequest)message.get("HTTP.REQUEST");
        
        if (request == null){
            UnlockLogUtil.errorInfo(className,
                    methodName, UnlockConstants.REQUEST,
            "request is null from message! ");
        }
        remoteIPAddress = request.getHeader("X-Real-IP");
        if (remoteIPAddress == null) {
            String ips = request.getHeader("X-Forwarded-For");
            if (ips != null) {
                remoteIPAddress = ips.split(",")[0];
            }
            else {
                 remoteIPAddress = request.getRemoteAddr();
            }
        }
        return remoteIPAddress;
    }
}
