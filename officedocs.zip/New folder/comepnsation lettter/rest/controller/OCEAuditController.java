package com.att.unlock.rest.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.interceptor.InInterceptors;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;

import com.att.det.sl.logginginfo.server.LoggingInfoServiceImpl;
import com.att.det.sl.logginginfo.shared.service.LoggingInfoService;
import com.att.det.sl.shared.context.SvcExecContext;
import com.att.det.sl.shared.context.SvcExecContextFactory;
import com.att.det.sl.shared.exception.ServiceException;
import com.att.det.sl.shared.to.LoggingInfoDetailsRequestTO;
import com.att.det.sl.shared.to.LoggingInfoDetailsResponseTO;
import com.att.unlock.api.OrderService;
import com.att.unlock.api.vo.UnlockOCEAuditRequestDO;
import com.att.unlock.base.util.UnlockCryptoUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.rest.validator.UnlockValidator;
import com.google.gson.Gson;

/**
 * <b>Name:</b> OrderController. <b>Purpose:</b>This class is designed as a
 * controller for unlock order submit request and unlock order lookup.
 *
 * @author VS00343711
 */

@CrossOriginResourceSharing(allowAllOrigins = true, allowCredentials = true, maxAge = UnlockConstants.MAX_AGE, allowHeaders = { })
@InInterceptors(interceptors = { "com.att.unlock.rest.common.CSRFTokenInterceptor" })
@Path("/OCEAudit")
public class OCEAuditController {

    /**
     * OrderService Service.
     */
    private OrderService orderService;

    /**
     * UnlockValidator Validator.
     */
    private UnlockValidator orderValidator;

    private UnlockResponseHandler responseHandler;

    /**
     * Message to handle csrf token.
     */
    private Message message;

    /**
     * <b>Name:</b> unlockOrderRequest. <b>Purpose:</b>This method used to
     * submit unlock order request.
     *
     * @param unlockOrderRequest
     *            as UnlockOrderRequest
     * @return UnlockOrderResponse
     */

    public OCEAuditController() {
    }
   
    /**
     * <b>Name:</b> verifyEmail. <b>Purpose:</b>This method is used for Email Verification Flow
     *
     * @param UnlockOCEVerifyEmailRequest
     *           
     * @return UnlockOCEVerifyEmailResponse
     */
   
    @POST
    @Path("/Audit")
    @Produces(MediaType.TEXT_PLAIN)
    @Consumes(MediaType.APPLICATION_JSON)
    public final String audit(UnlockOCEAuditRequestDO unlockOCEAuditOrder) {
        boolean isAuthenticated = isUserAuthenticated(unlockOCEAuditOrder);
        String errorMsg = null;
        String errorCode = null;
        List<LoggingInfoDetailsResponseTO> loggingDetailsList = null;
        StringBuilder builder = null;

        if (isAuthenticated) {
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");      
        
            if (null != unlockOCEAuditOrder.getStartDate() && null != unlockOCEAuditOrder.getEndDate()) {
                try {
                    Date fromDate = formatter.parse(unlockOCEAuditOrder.getStartDate());
                    Date toDate = formatter.parse(unlockOCEAuditOrder.getEndDate());
                    int startTime=unlockOCEAuditOrder.getStartTime();
                    int endTime=unlockOCEAuditOrder.getEndTime();
                    LoggingInfoDetailsRequestTO detailsTO = new LoggingInfoDetailsRequestTO();
                    detailsTO.setFromDate(fromDate);
                    detailsTO.setToDate(toDate);
                    detailsTO.setHourFrom(startTime);
                    detailsTO.setHourTo(endTime);
                    LoggingInfoService infoService = new LoggingInfoServiceImpl();
                    loggingDetailsList = infoService.getLoggingInfo(getAPIClusterContext(), detailsTO);
    
                    builder = buildAuditResponse(loggingDetailsList);
                
                
                } catch (ParseException pe ) {
                    errorMsg = "Invalid Input.";
                    errorCode = "INVALID_01";
                    builder = buildErrorResponse(errorMsg, errorCode);
                            
                } catch (ServiceException e) {
                    errorMsg = "Getting Exception while fetching record.";
                    errorCode = "INVALID_02";
                    builder = buildErrorResponse(errorMsg, errorCode);
    
                }
            } else {
                errorMsg = "Invalid Input.";
                errorCode = "INVALID_01";
                builder = buildErrorResponse( errorMsg, errorCode);
            }
        } else {
            errorMsg = "User Not Authenticated.";
            errorCode = "INVALID_02";
            builder = buildErrorResponse( errorMsg, errorCode);
        }
      
        if (builder != null) {
            return builder.toString();
        } else {
            return null;
        }
    }

    private StringBuilder buildErrorResponse(String errorCode, String errorMsg) {
        String errorMap = buildStatusMap(errorCode, errorMsg);
        StringBuilder builder = new StringBuilder();
        builder.append(errorMap);
        return builder;
    }
   
    private String buildStatusMap(String statusCode, String statusMsg) {
        Map<String,String> statusResponse = new HashMap<String, String>();
        statusResponse.put("statusCode",statusCode);
        statusResponse.put("statusMessage", statusMsg);
        //Converting the map to Json
        Gson gson = new Gson();
        String statusMapToJson = gson.toJson(statusResponse);
        
        return statusMapToJson;
    }

    public StringBuilder buildAuditResponse(List<LoggingInfoDetailsResponseTO> 
        loggingDetailsList) {
        StringBuilder builder = new StringBuilder();        
        builder.append("{ \"AuditData\" : [ ");
        if (loggingDetailsList != null && !loggingDetailsList.isEmpty()) {
            for (LoggingInfoDetailsResponseTO auditResponseTO : loggingDetailsList) {
                builder.append(auditResponseTO.getJsonString());
                builder.append(",");
            }
        }
        String successMap = buildStatusMap("0", "Success");
        builder.append(successMap);
        builder.append("] }");

        return builder;
    }
        
    private boolean isUserAuthenticated(UnlockOCEAuditRequestDO unlockOCEAuditOrder) {
    	boolean result = false;
    	String password = null;
    	String userName = unlockOCEAuditOrder.getUserName();
    	String encryptedPassword = unlockOCEAuditOrder.getPassword();
    	if (null != encryptedPassword) {
    	password = UnlockCryptoUtil.decrypt(encryptedPassword);
    	}
    	if (( UnlockConstants.API_USER_NAME.equals(userName)
    	&& ( UnlockConstants.API_PASSWORD.equals(password)))) {
    	result = true;
    	} else {
    	result = false;
    	}
    	return result;
    	}

    /**
     * @return the orderService
     */
    public final OrderService getOrderService() {
        return orderService;
    }
    /**
     * @param orderServicee
     *            the orderService to set
     */
    public final void setOrderService(final OrderService orderServicee) {
        orderService = orderServicee;
    }

    /**
     * @return the orderValidator
     */
    public final UnlockValidator getOrderValidator() {
        return orderValidator;
    }

    /**
     * @param orderValidatorr
     *            the orderValidator to set
     */
    public final void setOrderValidator(final UnlockValidator orderValidatorr) {
        orderValidator = orderValidatorr;
    }

    /**
     * @return the responseHandler
     */
    public UnlockResponseHandler getResponseHandler() {
        return responseHandler;
    }

    /**
     * @param responseHandler
     *            the responseHandler to set
     */
    public void setResponseHandler(UnlockResponseHandler responseHandler) {
        this.responseHandler = responseHandler;
    }
    
  
       private String getIPAddress(HttpServletRequest servletRequest) {
        String remoteIPAddress = servletRequest.getHeader("X-Real-IP");
          if (remoteIPAddress == null) {
              String ips = servletRequest.getHeader("X-Forwarded-For");
              if (ips != null) {
                  remoteIPAddress = ips.split(",")[0];
              }
              else {
                   remoteIPAddress = servletRequest.getRemoteAddr();
              }
          }
        return remoteIPAddress;
    }
    
   public SvcExecContext  getAPIClusterContext()  {
        return SvcExecContextFactory.createContext("API_CLUSTER");
    }
    
}
