package com.att.unlock.rest.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.interceptor.InInterceptors;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;

import com.att.unlock.api.IMEIService;
import com.att.unlock.api.common.UnlockServiceException;
import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.ImeiLookupRequest;
import com.att.unlock.api.vo.ImeiSearchResponse;
import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.rest.validator.UnlockValidator;

/**
 * <b>Name:</b> IMEIController. <b>Purpose:</b>This class is designed as a
 * controller for lookupIMEI service for searching the IMEI for make and model.
 *
 * @author
 */

@CrossOriginResourceSharing(allowAllOrigins = true, allowCredentials = true, maxAge = UnlockConstants.MAX_AGE, allowHeaders = { })
@InInterceptors(interceptors = { "com.att.unlock.rest.common.CSRFTokenInterceptor" })
@Path("/UnlockUtility/ocelookupimei")
public class OCEIMEIController {

    /**
     * IMEI Service.
     */
    private IMEIService imeiService;

    /**
     * IMEI Validator.
     */
    private UnlockValidator imeiValidator;

    /**
     * IMEI ResponseHandler.
     */
    private UnlockResponseHandler responseHandler;

    /**
     * Message to handle csrf token.
     */
    private Message message;


    /**
     * <b>Name:</b> lookUpIMEI. <b>Purpose:</b>This method is used for
     * lookupIMEI service for searching the IMEI for make and model.
     *
     * @param imeiLookupRequest
     *            as ImeiLookupRequest
     * @return ImeiSearchResponse
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final ImeiSearchResponse lookUpIMEI(
            ImeiLookupRequest imeiLookupRequest) {
        ImeiSearchResponse imeiSearchResponse = null;
        UnlockLogUtil.endPointInfo(this.getClass().getName(), "lookUpIMEI", "Security Defect fixed");
        UnlockLogUtil.endPointInfo(UnlockConstants.IMEI_CONTROLLER,
                "lookUpIMEI", UnlockConstants.REQUEST);
        
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.IMEI_CONTROLLER,
                "lookUpIMEI", UnlockConstants.REQUEST, imeiLookupRequest);
        try {
             message = JAXRSUtils.getCurrentMessage();
             String csrfToken = null;
             if (null != message) {
             csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);
             }
            if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {
                // Request Validation
                List<ErrorDetail> errorList = imeiValidator
                        .validate(imeiLookupRequest);
                if (errorList.size() > UnlockConstants.ZERO) {
                    if (null == imeiLookupRequest) {
                        imeiLookupRequest = new ImeiLookupRequest();
                    }
                    imeiSearchResponse = (ImeiSearchResponse) imeiValidator
                            .getValidationResponse(imeiLookupRequest, errorList);
                    return imeiSearchResponse;
                }
                // Calling Service for getting the IMEI details
                imeiSearchResponse = imeiService.lookUpIMEI(imeiLookupRequest);
            } else {
                if (imeiSearchResponse == null) {
                    imeiSearchResponse = new ImeiSearchResponse();
                }
                // Preparing the error response
                imeiSearchResponse = (ImeiSearchResponse) responseHandler.
                        setInvalidResponse(imeiSearchResponse);


            }
        } catch (UnlockServiceException e) {
            UnlockLogUtil.errorInfo(UnlockConstants.IMEI_CONTROLLER,
                    "lookUpIMEI", "[Exception caught: Class "
                            + UnlockConstants.IMEI_CONTROLLER + " : method : "
                            + "lookUpIMEI" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (imeiSearchResponse == null) {
                imeiSearchResponse = new ImeiSearchResponse();
            }
            // Preparing the error response
            imeiSearchResponse = (ImeiSearchResponse) responseHandler
                    .handleResponse(imeiSearchResponse, e);
        } catch (Exception e) {
            UnlockLogUtil.errorInfo(UnlockConstants.IMEI_CONTROLLER,
                    "lookUpIMEI", "[Exception caught: Class "
                            + UnlockConstants.IMEI_CONTROLLER + " : method : "
                            + "lookUpIMEI" + "]",
                    UnlockExceptionUtil.generateStackTraceString(e));
            if (imeiSearchResponse == null) {
                imeiSearchResponse = new ImeiSearchResponse();
            }
            // Preparing the error response
            imeiSearchResponse = (ImeiSearchResponse) responseHandler
                    .handleResponse(imeiSearchResponse, e);
        }

        // logging the response
        UnlockLogUtil.endPointInfo(UnlockConstants.IMEI_CONTROLLER,
                "lookUpIMEI", UnlockConstants.RESPONSE);
        
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.IMEI_CONTROLLER,
                "lookUpIMEI", UnlockConstants.RESPONSE, imeiSearchResponse);
        // returning the response to UI
        return imeiSearchResponse;
    }

    /**
     * @return the imeiService
     */

    public final IMEIService getImeiService() {
        return imeiService;
    }

    /**
     * @param imeiServicee
     *            the imeiService to set
     */

    public final void setImeiService(final IMEIService imeiServicee) {
        imeiService = imeiServicee;
    }

    /**
     * @return the imeiValidator
     */
    public final UnlockValidator getImeiValidator() {
        return imeiValidator;
    }

    /**
     * @param imeiValidatorr
     *            the imeiValidator to set
     */
    public final void setImeiValidator(final UnlockValidator imeiValidatorr) {
        imeiValidator = imeiValidatorr;
    }

    /**
     * @return the responseHandler
     */
    public UnlockResponseHandler getResponseHandler() {
        return responseHandler;
    }

    /**
     * @param responseHandler
     *            the responseHandler to set
     */
    public void setResponseHandler(UnlockResponseHandler responseHandler) {
        this.responseHandler = responseHandler;
    }

}
