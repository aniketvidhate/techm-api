package com.att.unlock.rest.controller;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;

import org.apache.cxf.interceptor.InInterceptors;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;
import org.apache.cxf.transport.http.Headers;

import com.att.det.sl.device.shared.to.IMEILookupRequestTO;
import com.att.det.sl.fraud.shared.service.FraudService;
import com.att.det.sl.shared.context.SvcExecContext;
import com.att.det.sl.shared.context.SvcExecContextFactory;
import com.att.det.sl.shared.exception.ServiceException;
import com.att.det.sl.shared.service.factory.ServiceFactory;
import com.att.unlock.api.OrderService;
import com.att.unlock.api.common.UnlockServiceException;
import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.UnlockOCEVerifyEmailRequest;
import com.att.unlock.api.vo.UnlockOCEVerifyEmailResponse;
import com.att.unlock.api.vo.OrderFlowRequestDO;
import com.att.unlock.api.vo.OrderFlowResponseDO;
import com.att.unlock.api.vo.ServiceStatus;
import com.att.unlock.api.vo.UnlockOrderDetail;
import com.att.unlock.api.vo.UnlockOrderRequest; 
import com.att.unlock.api.vo.UnlockOrderResponse;
import com.att.unlock.api.vo.UnlockOrderStatusRequest;
import com.att.unlock.api.vo.UnlockOrderStatusResponse;
import com.att.unlock.api.vo.UnlockValidateEmailRequest;
import com.att.unlock.api.vo.UnlockValidateEmailResponse;
import com.att.unlock.api.vo.UnlockVerifyEmailRequest;
import com.att.unlock.api.vo.UnlockVerifyEmailResponse;
import com.att.unlock.api.vo.ValidationErrors;
import com.att.unlock.base.util.UnlockBaseConstants;
import com.att.unlock.base.util.UnlockCollectionUtil;
import com.att.unlock.base.util.UnlockCryptoUtil;
import com.att.unlock.base.util.UnlockExceptionUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.rest.validator.OCEOrderValidator;
import com.att.unlock.rest.validator.OCEUnlockValidator;
import com.att.unlock.rest.validator.UnlockValidator;
import com.google.gson.Gson;

/**
 * <b>Name:</b> OrderController. <b>Purpose:</b>This class is designed as a
 * controller for unlock order submit request and unlock order lookup.
 *
 * @author VS00343711
 */

@CrossOriginResourceSharing(allowAllOrigins = true, allowCredentials = true, maxAge = UnlockConstants.MAX_AGE, allowHeaders = { })
@InInterceptors(interceptors = { "com.att.unlock.rest.common.CSRFTokenInterceptor" })
@Path("/OCEUnlockOrder")
public class OCEOrderController {

    /**
     * OrderService Service.
     */
    private OrderService orderService;

    /**
     * UnlockValidator Validator.
     */
    private UnlockValidator orderValidator;

    private UnlockResponseHandler responseHandler;
    
    /**
     * <b>Name:</b> unlockOrderRequest. <b>Purpose:</b>This method used to
     * submit unlock order request.
     *
     * @param unlockOrderRequest
     *            as UnlockOrderRequest
     * @return UnlockOrderResponse
     */

    public OCEOrderController() {
    }
   
    /**
     * <b>Name:</b> verifyEmail. <b>Purpose:</b>This method is used for Email Verification Flow
     *
     * @param UnlockOCEVerifyEmailRequest
     *           
     * @return UnlockOCEVerifyEmailResponse
     */
   
    @POST
    @Path("/Verify/VerifyEmail")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final UnlockOCEVerifyEmailResponse verifyEmail(
            UnlockOCEVerifyEmailRequest unlockOCEVerifyEmailRequest) {
        UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                "verifyEmail", UnlockConstants.REQUEST);
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.EMAIL_CONTROLLER,
                "verifyEmail", UnlockConstants.REQUEST
                        + unlockOCEVerifyEmailRequest);
        UnlockOCEVerifyEmailResponse emailResponse=null;
        Message message = JAXRSUtils.getCurrentMessage();
       String csrfToken = null;
    // String remoteIPAddress = null;
     if (null != message) {
     csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);            
     UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
             "OrderFlowRequestDO", "csrfToken:" + csrfToken);
   
 }
     if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {              

         emailResponse = orderService.emailConfirmation(unlockOCEVerifyEmailRequest); //email confirmation module triggered
     }else {

         //csrf token is invalid
           UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                   "unlockOrderRequest", "csrf token is Invalid");
           
              if (emailResponse == null) {
                  emailResponse = new UnlockOCEVerifyEmailResponse();
              }
              // Preparing the error response
              ErrorDetail currentError=new ErrorDetail();
              currentError.setErrorCode(UnlockConstants.INVALID_OCE_TOKEN_ERROR_CODE);
              currentError.setErrorDescription(UnlockConstants.INVALID_OCE_TOKEN_ERROR_DESC);
                              List<ErrorDetail> errorList=new ArrayList<ErrorDetail>();
              errorList.add(currentError);
              ValidationErrors validationErrors=new ValidationErrors();
              validationErrors.setErrorList(errorList);
              emailResponse.setValidationErrors(validationErrors);
              
     }
              UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                      "unlockOrderRequest", UnlockConstants.RESPONSE);
              UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                      "unlockOrderRequest", UnlockConstants.RESPONSE
                              + emailResponse.toString());
     
        return emailResponse;
    }
    
  

    
    /**
     * @return the orderService
     */
    public final OrderService getOrderService() {
        return orderService;
    }
    /**
     * @param orderServicee
     *            the orderService to set
     */
    public final void setOrderService(final OrderService orderServicee) {
        orderService = orderServicee;
    }

    /**
     * @return the orderValidator
     */
    public final UnlockValidator getOrderValidator() {
        return orderValidator;
    }

    /**
     * @param orderValidatorr
     *            the orderValidator to set
     */
    public final void setOrderValidator(final UnlockValidator orderValidatorr) {
        orderValidator = orderValidatorr;
    }

    /**
     * @return the responseHandler
     */
    public UnlockResponseHandler getResponseHandler() {
        return responseHandler;
    }

    /**
     * @param responseHandler
     *            the responseHandler to set
     */
    public void setResponseHandler(UnlockResponseHandler responseHandler) {
        this.responseHandler = responseHandler;
    }
    
  
    /**
     * This controller method is responsible for the processing of order through different flow for OCE framework
     * @param orderFlowRequestDO
     * @return OrderFlowResponseDO
     */
   
    @POST
    @Path("/orderFlow")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final OrderFlowResponseDO orderflow(
            OrderFlowRequestDO orderFlowRequestDO) {
        OrderFlowResponseDO responseDO = null;
        Message message = JAXRSUtils.getCurrentMessage();
        String csrfToken = null;
       // String remoteIPAddress = null;
       if (null != message) {
           //csrfToken = (String) message.get(UnlockConstants.CSRF_TOKEN);            
           UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                   "OrderFlowRequestDO", "csrfToken:" + csrfToken);
       }
        
       if (!UnlockStringUtil.isEquals(csrfToken, UnlockConstants.IN_VALID)) {              
           HttpServletRequest servletRequest = (HttpServletRequest)message.get("HTTP.REQUEST");
            //Accessing the csrf token id and setting it in orderFlowRequestDO
           List<String> csrfs=Headers
                   .getSetProtocolHeaders(message).get("OWASP-CSRFTOKEN");
           if(!UnlockCollectionUtil.isEmptyList(csrfs)){
               orderFlowRequestDO.setCsrfToken(csrfs.get(0));
           } else {
               orderFlowRequestDO.setCsrfToken(null);
           }
           UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                    "OrderFlowRequestDO", "csrfToken:" + csrfToken);
         //getIPAddress(servletRequest);
           if (null != csrfs.get(0))  {
       try{
        //logging instructions
           UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                "orderFlowRequestDO", UnlockConstants.REQUEST + "name");
   
           UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
               "orderFlowRequestDO", UnlockConstants.REQUEST,
               orderFlowRequestDO);
           OCEUnlockValidator oceUnlockValidator = new OCEOrderValidator();
           List<ErrorDetail> errorList = oceUnlockValidator.validate(orderFlowRequestDO);
           if (errorList.size() > UnlockConstants.ZERO) {
               UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                   "orderFlowRequestDO", "errorList.size():" + errorList.size());
           if (responseDO == null) {
               responseDO = new OrderFlowResponseDO();
           }
           ValidationErrors validationErrors=new ValidationErrors();
           validationErrors.setErrorList(errorList);
           responseDO.setValidationErrors(validationErrors);
           } else {
               //((HttpServletRequest)message.get(AbstractHTTPDestination.HTTP_REQUEST)).getSession(true).setAttribute("DSquare", "1234");
               //end of logging instructions
               // All order flow will be handled by this Method, based on flow - current screen flow will be discussed.
               //setting csrf token
           
           switch(orderFlowRequestDO.getCurrentFlow()){
                   case UnlockBaseConstants.ACCOUNT_DETAILS_FLOW:
                       orderFlowRequestDO.setIpAddress(getIPAddress(servletRequest));
            
                       responseDO=orderService.accountDetailsFlowImpl(orderFlowRequestDO);
                       break;
                   case UnlockBaseConstants.IMEI_VERIFICATION_FLOW:
                       responseDO= orderService.imeiVerificationFlowImpl(orderFlowRequestDO);
                       createEncryptedIMEI(orderFlowRequestDO, responseDO);
                       break;
                   case UnlockBaseConstants.USER_INFORMATION_VALIDATION_FLOW:
                       responseDO=orderService.userInformationValidationImpl(orderFlowRequestDO);
                       break;
        
                   case UnlockBaseConstants.ORDER_SUBMISSION_FLOW:
                       orderFlowRequestDO.setIpAddress(getIPAddress(servletRequest));

                       responseDO=orderService.orderSubmissionImpl(orderFlowRequestDO);
                       break;
                   case UnlockBaseConstants.NON_ATT_ORDER_VALIDATION_FLOW:
                       responseDO=orderService.nonATTOrderValidationFlow(orderFlowRequestDO);
                       break;
                       /*case UnlockBaseConstants.MILITARY_FILE_UPLOAD:
                     orderFlowRequestDO.setIpAddress(getIPAddress(servletRequest));
                       responseDO=orderService.fileUpload(orderFlowRequestDO);
                    break;*/
                   default:
                       break;
                   } 
           }
       } 
            catch(Exception e) {
                UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                        "unlockOrderRequest", "uncaught exception");
                
                   if (responseDO == null) {
                       responseDO = new OrderFlowResponseDO();
                   }
                   responseDO.setCurrentFlow(orderFlowRequestDO.getCurrentFlow());
                   // Preparing the error response
                   ErrorDetail errorDetail = orderService.getTechnicalException();
                   List<ErrorDetail> errorList=new ArrayList<ErrorDetail>();
                   errorList.add(errorDetail);
                   ValidationErrors validationErrors=new ValidationErrors();
                   validationErrors.setErrorList(errorList);
                   responseDO.setValidationErrors(validationErrors);
           
            } }
           } else {
               //csrf token is invalid
               UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                      "unlockOrderRequest", "csrf token is Invalid");
                 
               if (responseDO == null) {
                    responseDO = new OrderFlowResponseDO();
               }
               responseDO.setCurrentFlow(orderFlowRequestDO.getCurrentFlow());
               // Preparing the error response
               ErrorDetail currentError=new ErrorDetail();
               currentError.setErrorCode(UnlockConstants.INVALID_OCE_TOKEN_ERROR_CODE);
               currentError.setErrorDescription(UnlockConstants.INVALID_OCE_TOKEN_ERROR_DESC);
               List<ErrorDetail> errorList=new ArrayList<ErrorDetail>();
               errorList.add(currentError);
               ValidationErrors validationErrors=new ValidationErrors();
               validationErrors.setErrorList(errorList);
               responseDO.setValidationErrors(validationErrors);
                    
           }
        UnlockLogUtil.endPointInfo(UnlockConstants.ORDER_CONTROLLER,
                "unlockOrderRequest", UnlockConstants.RESPONSE);
        UnlockLogUtil.endPointDebugInfo(UnlockConstants.ORDER_CONTROLLER,
                "unlockOrderRequest", UnlockConstants.RESPONSE
                        + responseDO.toString());
        if(null != orderFlowRequestDO.getCsrfToken() && !orderFlowRequestDO.getCsrfToken().isEmpty())
        {
        	orderService.invokeLoggingService(orderFlowRequestDO,responseDO);
        }
        return responseDO;

    }
    
    private void createEncryptedIMEI(OrderFlowRequestDO orderFlowRequestDO,
            OrderFlowResponseDO responseDO) throws
            InvalidKeyException, IllegalBlockSizeException, 
            BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, IOException {
        String imeiRefId = null;
        if(null != orderFlowRequestDO.getImei() || !orderFlowRequestDO.getImei().isEmpty())
        {
             imeiRefId = UnlockCryptoUtil.encrypt(orderFlowRequestDO.getImei()); 
             responseDO.setImeiRefId(imeiRefId);
        }
        
    }

    @POST
    @Path("/redirectOCEWorkFlow")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public final boolean isOCEWorkFlow(){
        UUID csrfToken=UUID.randomUUID();
        boolean result=orderService.serviceHandler(csrfToken.toString());
    
        return result;
            
}
   
    
    //Arpita Changes for the Accessories json
    
/*    @POST
    @Path("/retrieveAccessories")
    @Produces(MediaType.TEXT_PLAIN)
    @Consumes(MediaType.APPLICATION_JSON)
    public final String retrieveAccessories(OrderFlowRequestDO orderFlowRequestDO) {
       
    	String listToJson = null;
    	Gson gson = new Gson();
    	IMEILookupRequestTO imeirequest = new IMEILookupRequestTO();
        imeirequest.setImei(orderFlowRequestDO.getImei());
        
        
    	FraudService fraudService = ServiceFactory.getFraudService();
    	try {
			List<RecommendationBySKUResponseTO> accessories = fraudService.
					getRecommendationBySKU(getAPIClusterContext(), imeirequest);
			
			listToJson = gson.toJson(accessories);
		} catch (ServiceException e) {
			Map<String, String> errorMap = new HashMap<String, String>();
			errorMap.put("INVALID_05", "No Accessories Found");
			listToJson = gson.toJson(errorMap);
		}
    	return listToJson;
    }
*/
    
    public SvcExecContext  getAPIClusterContext()  {
        return SvcExecContextFactory.createContext("API_CLUSTER");
    }
    
    
    private String getIPAddress(HttpServletRequest servletRequest) {
        String remoteIPAddress = servletRequest.getHeader("X-Real-IP");
          if (remoteIPAddress == null) {
              String ips = servletRequest.getHeader("X-Forwarded-For");
              if (ips != null) {
                  remoteIPAddress = ips.split(",")[0];
              }
              else {
                   remoteIPAddress = servletRequest.getRemoteAddr();
              }
          }
        return remoteIPAddress;
    }
    
    
    public OrderFlowResponseDO setInvalidResponse(OrderFlowResponseDO orderFlowResponseDO,Exception e) {

        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);
        switch (orderFlowResponseDO.getCurrentFlow()) {
        case UnlockBaseConstants.ACCOUNT_DETAILS_FLOW:
        case UnlockBaseConstants.IMEI_VERIFICATION_FLOW:
        case UnlockBaseConstants.USER_INFORMATION_VALIDATION_FLOW:
            UnlockOrderResponse unlockOrderResponse = new UnlockOrderResponse();
            UnlockOrderDetail unlockOrderDetail = new UnlockOrderDetail();
            unlockOrderDetail
                    .setErrorCode(UnlockConstants.INVALID_OCE_TOKEN_ERROR_CODE);
            unlockOrderDetail
                    .setErrorDescription(UnlockConstants.INVALID_OCE_TOKEN_ERROR_DESC);
            unlockOrderDetail.setOrderNumber(UnlockConstants.BLANK);
            unlockOrderResponse.setUnlockOrderDetail(unlockOrderDetail);
            unlockOrderResponse.setServiceStatus(serviceStatus);
            break;
            
          
        default: 
            UnlockOrderStatusResponse unlockOrderStatusResponse = new UnlockOrderStatusResponse();
            ErrorDetail errorDetail = new ErrorDetail();
            errorDetail.setErrorCode(UnlockConstants.INVALID_OCE_TOKEN_ERROR_CODE);
            errorDetail
                    .setErrorDescription(UnlockConstants.INVALID_OCE_TOKEN_ERROR_DESC);
            unlockOrderStatusResponse.setErrorDetail(errorDetail);
           unlockOrderStatusResponse.setServiceStatus(serviceStatus);
        }
            return orderFlowResponseDO;

        }
    
    
}
