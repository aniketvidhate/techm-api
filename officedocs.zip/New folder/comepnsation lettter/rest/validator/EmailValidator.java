package com.att.unlock.rest.validator;

import java.util.ArrayList;
import java.util.List;

import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.OrderDetail;
import com.att.unlock.api.vo.ResendEmailNotificationRequest;
import com.att.unlock.api.vo.ResendEmailNotificationResponse;
import com.att.unlock.api.vo.ServiceStatus;
import com.att.unlock.api.vo.UnlockBaseVO;
import com.att.unlock.api.vo.UnlockOrderDetail;
import com.att.unlock.api.vo.UnlockValidateEmailRequest;
import com.att.unlock.api.vo.UnlockValidateEmailResponse;
import com.att.unlock.api.vo.UnlockVerifyEmailRequest;
import com.att.unlock.api.vo.UnlockVerifyEmailResponse;
import com.att.unlock.api.vo.ValidationErrors;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.rest.common.UnlockValidatorUtil;

/**
 * <b>Name:</b> EmailValidator. <b>Purpose:</b>This class is designed for
 * validation.
 *
 * @author SS00349933
 */
public class EmailValidator implements UnlockValidator, UnlockResponseHandler {

    /**
     * <b>Name:</b> validate. <b>Purpose:</b>This method is used to Validating
     * the request object object getting from UI.
     *
     * @param baseVO
     *            as UnlockBaseVO
     * @return List
     */
    @Override
    public List<ErrorDetail> validate(final UnlockBaseVO baseVO) {
        UnlockLogUtil.serviceInfo(UnlockConstants.EMAIL_VALIDATOR, "validate",
                "[Start: Class " + UnlockConstants.EMAIL_VALIDATOR
                        + " : Method : " + "validate" + "]");

        List<ErrorDetail> errorList = new ArrayList<ErrorDetail>();

        if (null == baseVO) {
            errorList.add(setError());
            return errorList;
        }

        if (!validateForSpecialCharacter(baseVO)) {
            errorList.add(setError());
            return errorList;
        }

        if (baseVO instanceof UnlockValidateEmailRequest) {
            UnlockValidateEmailRequest unlockValidateEmailRequest = (UnlockValidateEmailRequest) baseVO;

            if (UnlockStringUtil
                    .isEmpty(unlockValidateEmailRequest.getDomain())) {
                errorList.add(setError());
            }
        } else if (baseVO instanceof UnlockVerifyEmailRequest) {
            UnlockVerifyEmailRequest unlockValidateEmailRequest = (UnlockVerifyEmailRequest) baseVO;

            if (UnlockStringUtil.isEmpty(unlockValidateEmailRequest
                    .getRequestId())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(unlockValidateEmailRequest
                    .getTransactionId())) {
                errorList.add(setError());
            }
        } else if (baseVO instanceof ResendEmailNotificationRequest) {

            ResendEmailNotificationRequest resendEmailNotificationRequest = (ResendEmailNotificationRequest) baseVO;

            if (UnlockStringUtil.isEmpty(resendEmailNotificationRequest
                    .getOrderDetail().getOrderNumber())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(resendEmailNotificationRequest
                    .getOrderDetail().getImei())) {
                errorList.add(setError());
            } else if (resendEmailNotificationRequest.getOrderDetail()
                    .getImei().length() != 15) {
                errorList.add(setError());
            }

        }
        UnlockLogUtil.serviceInfo(UnlockConstants.EMAIL_VALIDATOR, "validate",
                "[End: Class " + UnlockConstants.EMAIL_VALIDATOR
                        + " : Method : " + "validate" + "]");
        return errorList;

    }


    /**
     *
     * @param baseVO
     * @return
     */
    private boolean validateForSpecialCharacter(final UnlockBaseVO baseVO) {

        boolean isValid = true;
        if (baseVO instanceof UnlockValidateEmailRequest) {

            UnlockValidateEmailRequest unlockValidateEmailRequest = (UnlockValidateEmailRequest) baseVO;

            if (UnlockStringUtil.isNotEmpty(unlockValidateEmailRequest.getDomain()) &&
                    UnlockValidatorUtil.containsSpecialCharacter(unlockValidateEmailRequest.getDomain())) {

                isValid = false;
            }
        } else if (baseVO instanceof UnlockVerifyEmailRequest) {
            UnlockVerifyEmailRequest unlockValidateEmailRequest = (UnlockVerifyEmailRequest) baseVO;

            if (UnlockStringUtil.isNotEmpty(unlockValidateEmailRequest.getRequestId()) &&
                    UnlockValidatorUtil.containsSpecialCharacter(unlockValidateEmailRequest.getRequestId())) {

                isValid = false;
            } else if (UnlockStringUtil.isNotEmpty(unlockValidateEmailRequest.getTransactionId()) &&
                    UnlockValidatorUtil.containsSpecialCharacter(unlockValidateEmailRequest.getTransactionId())) {

                isValid = false;
            }
        } else if (baseVO instanceof ResendEmailNotificationRequest) {
            ResendEmailNotificationRequest resendEmailNotificationRequest = (ResendEmailNotificationRequest) baseVO;
            OrderDetail orderDetail = resendEmailNotificationRequest.getOrderDetail();

            if (UnlockStringUtil.isNotEmpty(orderDetail.getImei()) &&
                    UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getImei())) {

                isValid = false;
            } else if (UnlockStringUtil.isNotEmpty(orderDetail.getOrderNumber()) &&
                    UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getOrderNumber())) {

                isValid = false;
            } else if (UnlockStringUtil.isNotEmpty(orderDetail.getUnlockStatus()) &&
                    UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getUnlockStatus())) {

                isValid = false;
            } else if (UnlockStringUtil.isNotEmpty(orderDetail.getUnlockSubStatus()) &&
                    UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getUnlockSubStatus())) {

                isValid = false;
            }
        }

        return isValid;
    }


    /**
     * <b>Name:</b> getValidationResponse. <b>Purpose:</b>This Method for
     * generating the response against the validation failure.
     *
     * @param baseVO
     *            as UnlockBaseVO
     * @param errorList
     *            as List
     * @return UnlockBaseVO
     */
    @Override
    public UnlockBaseVO getValidationResponse(final UnlockBaseVO baseVO,
            List<ErrorDetail> errorList) {
        UnlockLogUtil.serviceInfo(UnlockConstants.EMAIL_VALIDATOR,
                "getValidationResponse", "[Start: Class "
                        + UnlockConstants.EMAIL_VALIDATOR + " : Method : "
                        + "getValidationResponse" + "]");
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);

        if (baseVO instanceof UnlockValidateEmailRequest) {
            UnlockValidateEmailResponse unlockValidateEmailResponse = new UnlockValidateEmailResponse();
            unlockValidateEmailResponse.setServiceStatus(serviceStatus);
            ErrorDetail errordetail = new ErrorDetail();
            errordetail.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
            errordetail.setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);
            unlockValidateEmailResponse.setErrordetail(errordetail);
            if (null != errorList) {
                ValidationErrors validationErrors = new ValidationErrors();
                validationErrors.setErrorList(errorList);
                unlockValidateEmailResponse
                        .setValidationErrors(validationErrors);
            }
            return unlockValidateEmailResponse;
        } else if (baseVO instanceof UnlockVerifyEmailRequest) {
            UnlockVerifyEmailResponse unlockVerifyEmailResponse = new UnlockVerifyEmailResponse();
            unlockVerifyEmailResponse.setServiceStatus(serviceStatus);
            if (null != errorList) {
                ValidationErrors validationErrors = new ValidationErrors();
                validationErrors.setErrorList(errorList);
                unlockVerifyEmailResponse.setValidationErrors(validationErrors);
            }
            return unlockVerifyEmailResponse;
        } else {
            ResendEmailNotificationResponse resendEmailNotificationResponse = new ResendEmailNotificationResponse();
            resendEmailNotificationResponse.setServiceStatus(serviceStatus);
            if (null != errorList) {
                ValidationErrors validationErrors = new ValidationErrors();
                validationErrors.setErrorList(errorList);
                resendEmailNotificationResponse
                        .setValidationErrors(validationErrors);
            }
            return resendEmailNotificationResponse;
        }

    }

    /**
     * This method is used to set the error detail
     * @return ErrorDetail
     */
    public ErrorDetail setError() {
        ErrorDetail errorDetail = new ErrorDetail();
        errorDetail.setErrorCode(UnlockConstants.SYSTEM_ERROR_CODE);
        errorDetail.setErrorDescription(UnlockConstants.SYSTEM_ERROR_MESSAGE);
        return errorDetail;
    }

    /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception, String rcDetailInternal) {
        //Previous impl was losing exception info, pass it on
        //the set method will decide if its appropriate to send to FE or just log
        
        //Add passed in detail and exception message
        if (rcDetailInternal == null){
            
            if (exception != null)
            {
                rcDetailInternal="Exception:"; //TODO: Put this in a constant
                //log the stacktrace in debug
                //Which specific exception ?
                rcDetailInternal+=exception.getMessage();
            }
        }
        
        return setInvalidResponse(baseVO, rcDetailInternal);
    }
    
    /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception) {
        //Previous impl was losing exception info, pass it on
       
        return handleResponse(baseVO, exception,null);
    }

    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO) {
        return setInvalidResponse(baseVO, null);
        
    }
    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO, String pRootCauseDetail) {
        //Log RC detail along with ip to be able to tie it to the request
        UnlockLogUtil.errorInfo(UnlockConstants.EMAIL_VALIDATOR,
                        "setInvalidResponse", pRootCauseDetail, "");
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);

        ErrorDetail errordetail = new ErrorDetail();
        errordetail.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
        errordetail.setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);

        if (baseVO instanceof UnlockValidateEmailResponse) {
            UnlockValidateEmailResponse unlockValidateEmailResponse = new UnlockValidateEmailResponse();
            unlockValidateEmailResponse.setServiceStatus(serviceStatus);
            unlockValidateEmailResponse.setErrordetail(errordetail);

            return unlockValidateEmailResponse;
        } else if (baseVO instanceof UnlockVerifyEmailResponse) {
            UnlockVerifyEmailResponse unlockVerifyEmailResponse = new UnlockVerifyEmailResponse();
            UnlockOrderDetail unlockOrderDetail = new UnlockOrderDetail();
            unlockOrderDetail.setOrderNumber(UnlockConstants.BLANK);
            unlockOrderDetail.setUnlockStatus(UnlockConstants.BLANK);
            unlockOrderDetail.setUnlockSubStatus(UnlockConstants.BLANK);
            unlockOrderDetail.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
            unlockOrderDetail.setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);
            unlockVerifyEmailResponse.setServiceStatus(serviceStatus);
            unlockVerifyEmailResponse.setUnlockOrderDetail(unlockOrderDetail);

            return unlockVerifyEmailResponse;
        } else {
            ResendEmailNotificationResponse resendEmailNotificationResponse = new ResendEmailNotificationResponse();
            resendEmailNotificationResponse.setErrorDetail(errordetail);
            resendEmailNotificationResponse.setServiceStatus(serviceStatus);

            return resendEmailNotificationResponse;
        }
    }
}
