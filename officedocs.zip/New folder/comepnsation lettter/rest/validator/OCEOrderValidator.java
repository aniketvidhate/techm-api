package com.att.unlock.rest.validator;

import java.util.ArrayList;
import java.util.List;

import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.OrderFlowRequestDO;
import com.att.unlock.base.util.UnlockBaseConstants;
import com.att.unlock.base.util.UnlockCryptoUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;

/**
 * This class contains the validation check for all the front end fields
 * 
 * @author NS00362871
 *  
 */
public class OCEOrderValidator implements OCEUnlockValidator {
    
    @Override
    public List<ErrorDetail> validate(OrderFlowRequestDO orderFlowRequestDO) {

        UnlockLogUtil.serviceInfo("OCEOrderValidator", "validate",
                "[Start: Class " + "OCEOrderValidator" + " : Method : "
                        + "validate" + "]");
        List<ErrorDetail> errorList = new ArrayList<ErrorDetail>();

        //Null checks for captchaId, csrf token, capchaRefId 
        if (orderFlowRequestDO.getCaptcha() == null ) {    
            
            errorList.add(setError("SEC_UNLOCK_CAPTCHA_TAMPER_EVENT",
                    "The Captcha data is not present in the incoming data."));
            
        } else if (orderFlowRequestDO.getCaptcha().getCaptchaRefId() == null || 
                   orderFlowRequestDO.getCaptcha().getCaptchaRefId().isEmpty()) {
            
            errorList.add(setError("SEC_UNLOCK_CAPTCHA_TAMPER_EVENT",
                    "The encrypted Captcha value is not present in the incoming data"));
            
        } else  if(orderFlowRequestDO.getCaptcha().getCaptchaId() == null || 
               orderFlowRequestDO.getCaptcha().getCaptchaId().isEmpty()) {
            
            errorList.add(setError("SEC_UNLOCK_CAPTCHA_TAMPER_EVENT",
                    "The captcha tampered Event. The plaintext captcha data ID is not set by the incoming request"));
        } 
        
        else if (!orderFlowRequestDO.getCurrentFlow().equalsIgnoreCase("IMEI_VERIFICATION_FLOW")){
          if (orderFlowRequestDO.getCaptcha().getCaptchaResponse() == null || orderFlowRequestDO.getCaptcha().getCaptchaResponse().isEmpty()) {

          errorList.add(setError("SEC_UNLOCK_CAPTCHA_RESPONSE_TAMPER_EVENT",
                                     "The captcha Response tampered Event. The captcha response is not set by the incoming request"));

        } 
        }
        else {
            String decCaptchaRefID = UnlockCryptoUtil.decrypt(orderFlowRequestDO.getCaptcha().getCaptchaRefId());
            performCaptchaRefIDValidation(decCaptchaRefID, orderFlowRequestDO, errorList);
        }
        
        if (orderFlowRequestDO != null) {
            switch (orderFlowRequestDO.getCurrentFlow()) {

            case UnlockBaseConstants.ACCOUNT_DETAILS_FLOW:
                // account details validations
                errorList = accountDetailsValidation(orderFlowRequestDO,
                        errorList);
                break;

            case UnlockBaseConstants.USER_INFORMATION_VALIDATION_FLOW:
                // user information validation
                errorList = userInformationValidation(orderFlowRequestDO,
                        errorList);
                break;

            case UnlockBaseConstants.IMEI_VERIFICATION_FLOW:
                // imei verification flow validation
                errorList = imeiVerificationValidation(orderFlowRequestDO,
                        errorList);
                break;

            case UnlockBaseConstants.NON_ATT_ORDER_VALIDATION_FLOW:
                // non att flow validation
                // IMEI validation
                errorList = imeiVerificationValidation(orderFlowRequestDO,
                        errorList);

				// Make and Model Validation
				if (errorList.isEmpty()) {
					errorList = makeAndModelVerification(orderFlowRequestDO,
							errorList);
				}
				  performIMEIValidation(orderFlowRequestDO, errorList);
	              performMakeValidation(orderFlowRequestDO, errorList);
	              performModelValidation(orderFlowRequestDO, errorList);
				// Captcha Validation
				if (errorList.isEmpty()) {
					errorList = captchaValidation(orderFlowRequestDO, errorList);
				}
				break;

            case UnlockBaseConstants.ORDER_SUBMISSION_FLOW:
                // firstname and last name validation
                errorList = nameValidation(orderFlowRequestDO, errorList);
                // email validation
                if (errorList.isEmpty()) {
                errorList = emailValidation(orderFlowRequestDO, errorList);
                   }
                performIMEIValidation(orderFlowRequestDO, errorList);
                performMakeValidation(orderFlowRequestDO, errorList);
                performModelValidation(orderFlowRequestDO, errorList);
             // IMEI validation
				if (errorList.isEmpty()) {
				errorList = imeiVerificationValidation(orderFlowRequestDO,
						errorList);
				}
				// Make and Model Validation
				if (errorList.isEmpty()) {
					errorList = makeAndModelVerification(orderFlowRequestDO,
							errorList);
				}

                break;
            }
        }
        UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR, "validate",
                "[End: Class " + UnlockConstants.ORDER_VALIDATOR
                        + " : Method : " + "validate" + "]");
        return errorList;
    }
    
    private void performIMEIValidation(OrderFlowRequestDO orderFlowRequestDO,
            List<ErrorDetail> errorList) {
        
        if(orderFlowRequestDO.getImei() == null || orderFlowRequestDO.getImei().isEmpty())
        {
             errorList.add(setError("SEC_UNLOCK_IMEI_TAMPER_EVENT",
                     "The IMEI data is not present in the incoming data."));
             
        } else if (orderFlowRequestDO.getImeiRefId() == null || orderFlowRequestDO.getImeiRefId().isEmpty()) {
            
            errorList.add(setError("SEC_UNLOCK_IMEI_TAMPER_EVENT",
                    "The encrypted IMEI value is not present in the incoming data"));
        } else {
            String decImeiRefID = UnlockCryptoUtil.decrypt(orderFlowRequestDO.getImeiRefId());
            performImeiRefIDValidation(decImeiRefID, orderFlowRequestDO, errorList);
        }
        
    }

    private void performImeiRefIDValidation(String decImeiRefID,
            OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
        
        if(!decImeiRefID.equalsIgnoreCase(orderFlowRequestDO.getImei()))
        {
            errorList.add(setError("SEC_UNLOCK_IMEI_TAMPER_EVENT",
                    "The encrypted IMEI value does not match with the incoming IMEI"));
        }
        
    }
    
    
    private void performMakeValidation(OrderFlowRequestDO orderFlowRequestDO,
            List<ErrorDetail> errorList) {
        
        if(orderFlowRequestDO.getMake() == null || orderFlowRequestDO.getMake().isEmpty())
        {
             errorList.add(setError("SEC_UNLOCK_Make_TAMPER_EVENT",
                     "The Make data is not present in the incoming data."));
             
        } else if (orderFlowRequestDO.getMakeRefId() == null || orderFlowRequestDO.getMakeRefId().isEmpty()) {
            
            errorList.add(setError("SEC_UNLOCK_Make_TAMPER_EVENT",
                    "The encrypted MAKE value is not present in the incoming data"));
        } else {
            String decMakeRefID = UnlockCryptoUtil.decrypt(orderFlowRequestDO.getMakeRefId());
            performMakeRefIDValidation(decMakeRefID, orderFlowRequestDO, errorList);
        }
        
    }

    
    private void performMakeRefIDValidation(String decMakeRefID,
            OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
        
        if(!decMakeRefID.equalsIgnoreCase(orderFlowRequestDO.getMake()))
        {
            errorList.add(setError("SEC_UNLOCK_Make_TAMPER_EVENT",
                    "The encrypted Make value does not match with the incoming Make"));
        }
        
    }
    
    
    
    private void performModelValidation(OrderFlowRequestDO orderFlowRequestDO,
            List<ErrorDetail> errorList) {
        
        if(orderFlowRequestDO.getModel() == null || orderFlowRequestDO.getModel().isEmpty())
        {
             errorList.add(setError("SEC_UNLOCK_Model_TAMPER_EVENT",
                     "The Model data is not present in the incoming data."));
             
        } else if (orderFlowRequestDO.getModelRefId() == null || orderFlowRequestDO.getModelRefId().isEmpty()) {
            
            errorList.add(setError("SEC_UNLOCK_Model_TAMPER_EVENT",
                    "The encrypted Model value is not present in the incoming data"));
        } else {
            String decModelRefID = UnlockCryptoUtil.decrypt(orderFlowRequestDO.getModelRefId());
            performModelRefIDValidation(decModelRefID, orderFlowRequestDO, errorList);
        }
        
    }

    
    private void performModelRefIDValidation(String decModelRefID,
            OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
        
        if(!decModelRefID.equalsIgnoreCase(orderFlowRequestDO.getModel()))
        {
            errorList.add(setError("SEC_UNLOCK_Model_TAMPER_EVENT",
                    "The encrypted Model value does not match with the incoming Model"));
        }
        
    }
    
    /**
     * Perform the check of the captcha ID and csrf token with the Captch Reference Id.
     * @param decCaptchaRefID
     * @param requestDO
     * @param errorList
     */
    private void performCaptchaRefIDValidation(String decCaptchaRefID, 
            OrderFlowRequestDO requestDO, List<ErrorDetail> errorList) {
        boolean errorEvent = false;
        String errCode = "SEC_CAPTCHA_TAMPER_EVENT";
        String errMsg = null;
        
        String[] sessionTokAndCaptchaID = decCaptchaRefID.split("~");
        
        // Weird Data, tampered by user.
        if (sessionTokAndCaptchaID.length != 2) {
            errorEvent = true;
            errMsg = "The captcha tampered Event. The encrypted Captacha refID from incoming request is tampered";
        }
        
        if (!errorEvent && requestDO.getCsrfToken() == null || requestDO.getCsrfToken().isEmpty()) {
            errorEvent = true;
            errMsg = "The captcha tampered Event. CSRF token is empty.";
        }

        //Invalid CSRF Token, user modified this value.
        if (!errorEvent && !sessionTokAndCaptchaID[0].equals(requestDO.getCsrfToken())) {
            errorEvent = true;
            errMsg = "The captcha tampered Event. The CSRFToken from encrypted value does not match with the CSRFToken";
        }        

        if (!errorEvent && (!sessionTokAndCaptchaID[1].equals(requestDO.getCaptcha().getCaptchaId()))) {
            errorEvent = true;
            errMsg = "The captcha tampered Event. The user entered captcha ID does not match with the encrypted value.";
        }

        if (errorEvent) {
            errorList.add(setError(errCode, errMsg));
        }
    }
    
    
    /**
     * Account Details like ctn,firstname,lastname Validations
     * 
     * @param orderFlowRequestDO
     * @param errorList
     * @return
     */
    private List<ErrorDetail> accountDetailsValidation(
            OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
        // CTN Empty Check
        if (UnlockStringUtil.isEmpty(orderFlowRequestDO.getCtn())) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_CTNREQUIRED,
                    UnlockConstants.ERROR_DESCRIPTION_CTNREQUIRED));
        }
        // CTN Length Check
        if (UnlockStringUtil.isNotEmpty(orderFlowRequestDO.getCtn())
                && orderFlowRequestDO.getCtn().length() != UnlockConstants.TEN) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_CTNLENGTH,
                    UnlockConstants.ERROR_DESCRIPTION_CTNLENGTH));
        }

        // Name Validation
        errorList = nameValidation(orderFlowRequestDO, errorList);

        // Captcha Empty Check
        errorList = captchaValidation(orderFlowRequestDO, errorList);
        return errorList;
    }

    /**
     * Name Validation
     * 
     * @param orderFlowRequestDO
     * @param errorList
     */
    private List<ErrorDetail> nameValidation(
            OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
        // First Name Empty Check
        if (UnlockStringUtil.isEmpty(orderFlowRequestDO.getFirstName())) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_FIRSTNAMEREQUIRED,
                    UnlockConstants.ERROR_DESCRIPTION_FIRSTNAMEREQUIRED));
        }
        // Last Name Empty Check
        if (UnlockStringUtil.isEmpty(orderFlowRequestDO.getLastName())) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_LASTNAMEREQUIRED,
                    UnlockConstants.ERROR_DESCRIPTION_LASTNAMEREQUIRED));
        }

        return errorList;
    }

    /**
     * Captcha Empty Check Validation
     * 
     * @param orderFlowRequestDO
     * @param errorList
     * @return
     */
    private List<ErrorDetail> captchaValidation(
            OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
        if (null == orderFlowRequestDO.getCaptcha()) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_CAPTCHAREQUIRED,
                    UnlockConstants.ERROR_DESCRIPTION_CAPTCHAREQUIRED));
        }
        return errorList;
    }

    /**
     * User Information Validations
     * 
     * @param orderFlowRequestDO
     * @param errorList
     * @return
     */
    private List<ErrorDetail> userInformationValidation(
            OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
        
        if (orderFlowRequestDO.isCruCustomer()) {
            // Business Name Empty Check
            if (UnlockStringUtil.isEmpty(orderFlowRequestDO
                    .getBusinessAccountName())) {
                errorList.add(setError(UnlockConstants.ERROR_CODE_BUSINESSNAMEREQUIRED,
                        UnlockConstants.ERROR_DESCRIPTION_BUSINESSNAMEREQUIRED));
            }

            // Business Account Number empty check
            if (UnlockStringUtil.isEmpty(orderFlowRequestDO
                    .getBillingAccountNo())) {
                errorList.add(setError(
                        UnlockConstants.ERROR_CODE_BUSINESSACCOUNTNUMBERREQUIRED,
                        UnlockConstants.ERROR_DESCRIPTION_BUSINESSACCOUNTNUMBERREQUIRED));
            }

            // Business Account Number length check
            if (UnlockStringUtil.isNotEmpty(orderFlowRequestDO
                    .getBillingAccountNo())
                    && orderFlowRequestDO.getBillingAccountNo().length() != UnlockConstants.FOUR) {
                errorList.add(setError(UnlockConstants.ERROR_CODE_BUSINESSACCOUNTNUMBERLENGTH,
                        UnlockConstants.ERROR_DESCRIPTION_BUSINESSACCOUNTNUMBERLENGTH));
            }
        }
        // email validation
        errorList = emailValidation(orderFlowRequestDO, errorList);
        /*
        //SSN empty check
        if (UnlockStringUtil.isEmpty(orderFlowRequestDO.getLastFourSSN())) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_SSNREQUIRED,
                    UnlockConstants.ERROR_DESCRIPTION_SSNREQUIRED));
        } 
        //SSN length check
        if (UnlockStringUtil.isNotEmpty(orderFlowRequestDO
                .getLastFourSSN())
                && orderFlowRequestDO.getLastFourSSN().length() != UnlockConstants.FOUR) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_SSNLENGTH,
                    UnlockConstants.ERROR_DESCRIPTION_SSNLENGTH));
        }
         */
        return errorList;
    }

    /**
     * Email Validation
     * 
     * @param orderFlowRequestDO
     * @param errorList
     * @return
     */
    private List<ErrorDetail> emailValidation(
            OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
        // EMail Empty Check
        if (UnlockStringUtil.isEmpty(orderFlowRequestDO.getEmail())) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_EMAILREQUIRED,
                    UnlockConstants.ERROR_DESCRIPTION_EMAILREQUIRED));
        }

        // EMail Pattern Check
        if (UnlockStringUtil.isNotEmpty(orderFlowRequestDO.getEmail())
                && !orderFlowRequestDO.getEmail().matches(UnlockConstants.EMAIL_REGEX)) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_EMAILVALID,
                    UnlockConstants.ERROR_DESCRIPTION_EMAILVALID));
        }

        return errorList;
    }

    /**
     * Imei Verification flow Validation
     * 
     * @param orderFlowRequestDO
     * @param errorList
     */
    private List<ErrorDetail> imeiVerificationValidation(
            OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
        // IMEI empty check
        if (UnlockStringUtil.isEmpty(orderFlowRequestDO.getImei())) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_IMEIREQUIRED,
                    UnlockConstants.ERROR_DESCRIPTION_IMEIREQUIRED));
        }

        // IMEI length check
        if (UnlockStringUtil.isNotEmpty(orderFlowRequestDO.getImei())
                && orderFlowRequestDO.getImei().length() != UnlockConstants.FIFTEEN) {
            errorList.add(setError(UnlockConstants.ERROR_CODE_IMEILENGTH,
                    UnlockConstants.ERROR_DESCRIPTION_IMEILENGTH));
        }

        return errorList;
    }

    
    /**
	 * make and Model Verification flow Validation
	 * 
	 * @param orderFlowRequestDO
	 * @param errorList
	 */
	private List<ErrorDetail> makeAndModelVerification(
			OrderFlowRequestDO orderFlowRequestDO, List<ErrorDetail> errorList) {
		// MAKE AND MODEL empty check
		if (UnlockStringUtil.isEmpty(orderFlowRequestDO.getMake())
				|| UnlockStringUtil.isEmpty(orderFlowRequestDO.getModel())) {
			errorList.add(setError(
					UnlockConstants.ERROR_CODE_MAKEANDMODELREQUIRED,
					UnlockConstants.ERROR_DESCRIPTION_MAKEANDMODELREQUIRED));
		}
		return errorList;
	}


    /**
     * Setting the error code and error message
     * 
     * @param errorCode
     * @param errorMessage
     * @return
     */
    public ErrorDetail setError(String errorCode, String errorMessage) {
        ErrorDetail errorDetail = new ErrorDetail();
        errorDetail.setErrorCode(errorCode);
        errorDetail.setErrorDescription(errorMessage);
        return errorDetail;
    }
    
}
