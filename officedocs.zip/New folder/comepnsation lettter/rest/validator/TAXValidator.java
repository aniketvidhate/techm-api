package com.att.unlock.rest.validator;

import java.util.ArrayList;
import java.util.List;

import com.att.unlock.api.vo.CalculateTaxRequest;
import com.att.unlock.api.vo.CalculateTaxResponse;
import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.ServiceStatus;
import com.att.unlock.api.vo.TaxDetail;
import com.att.unlock.api.vo.UnlockBaseVO;
import com.att.unlock.api.vo.ValidationErrors;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;

/**
 * <b>Name:</b> TAXValidator. <b>Purpose:</b>This class is designed for Tax
 * validation.
 *
 * @author SS00349933
 */
public class TAXValidator implements UnlockValidator, UnlockResponseHandler {

    /**
     * <b>Name:</b> validate. <b>Purpose:</b>This method is used to Validating
     * the request object object getting from UI.
     *
     * @param baseVO
     *            as UnlockBaseVO
     * @return List
     */
    @Override
    public List<ErrorDetail> validate(final UnlockBaseVO baseVO) {
        UnlockLogUtil.serviceInfo(UnlockConstants.TAX_VALIDATOR, "validate",
                "[Start: Class " + UnlockConstants.TAX_VALIDATOR
                        + " : Method : " + "validate" + "]");
        List<ErrorDetail> errorList = new ArrayList<ErrorDetail>();

        if (baseVO == null) {
            errorList.add(setError());
            return errorList;
        }

        CalculateTaxRequest calculateTaxRequest = (CalculateTaxRequest) baseVO;

        if (UnlockStringUtil.isEmpty(calculateTaxRequest.getChargeAmount())) {
            errorList.add(setError());
        } else if (UnlockStringUtil.isEmpty(calculateTaxRequest
                .getAddressLine1())) {
            errorList.add(setError());
        } else if (UnlockStringUtil.isEmpty(calculateTaxRequest.getCity())) {
            errorList.add(setError());
        } else if (UnlockStringUtil.isEmpty(calculateTaxRequest.getState())) {
            errorList.add(setError());
        } else if (UnlockStringUtil.isEmpty(calculateTaxRequest.getZipCode())) {
            errorList.add(setError());
        }
        UnlockLogUtil.serviceInfo(UnlockConstants.TAX_VALIDATOR, "validate",
                "[End: Class " + UnlockConstants.TAX_VALIDATOR + " : Method : "
                        + "validate" + "]");
        return errorList;

    }

    /**
     * This method is used to set error code and description, in case of
     * validation failure
     *
     * @return ErrorDetail
     */
    public ErrorDetail setError() {
        ErrorDetail errorDetail = new ErrorDetail();
        errorDetail.setErrorCode(UnlockConstants.SYSTEM_ERROR_CODE);
        errorDetail.setErrorDescription(UnlockConstants.SYSTEM_ERROR_MESSAGE);
        return errorDetail;
    }

    /**
     * <b>Name:</b> getValidationResponse. <b>Purpose:</b>This Method for
     * generating the response against the validation failure.
     *
     * @param baseVO
     *            as UnlockBaseVO
     * @return UnlockBaseVO
     */
    @Override
    public final UnlockBaseVO getValidationResponse(final UnlockBaseVO baseVO,
            List<ErrorDetail> errorList) {
        UnlockLogUtil.serviceInfo(UnlockConstants.TAX_VALIDATOR,
                "getValidationResponse", "[Start: Class "
                        + UnlockConstants.TAX_VALIDATOR + " : Method : "
                        + "getValidationResponse" + "]");
        // Creating the response object
        CalculateTaxResponse calcTaxResponse = new CalculateTaxResponse();
        ServiceStatus serviceStatus = new ServiceStatus();
        TaxDetail taxDetail = new TaxDetail();
        List<TaxDetail> taxDetailList = new ArrayList<TaxDetail>();

        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);

        taxDetail.setGeoCode(UnlockConstants.BLANK);
        taxDetail.setTaxAuthority(UnlockConstants.BLANK);
        taxDetail.setTaxType(UnlockConstants.BLANK);
        taxDetail.setTaxAmount(UnlockConstants.BLANK);
        taxDetailList.add(taxDetail);

        ValidationErrors validationErrors = new ValidationErrors();
        validationErrors.setErrorList(errorList);

        calcTaxResponse.setTaxDetail(taxDetailList);
        calcTaxResponse.setServiceStatus(serviceStatus);
        calcTaxResponse.setValidationErrors(validationErrors);
        calcTaxResponse.setTotalTax(UnlockConstants.BLANK);
        UnlockLogUtil.serviceInfo(UnlockConstants.TAX_VALIDATOR,
                "getValidationResponse", "[End: Class "
                        + UnlockConstants.TAX_VALIDATOR + " : Method : "
                        + "getValidationResponse" + "]");

        return calcTaxResponse;
    }

    /**
      /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception, String rcDetailInternal) {
        //Previous impl was losing exception info, pass it on
        //the set method will decide if its appropriate to send to FE or just log
        
        //Add passed in detail and exception message
        if (rcDetailInternal == null){
            
            if (exception != null)
            {
                rcDetailInternal="Exception:"; //TODO: Put this in a constant
                //log the stacktrace in debug
                //Which specific exception ?
                rcDetailInternal+=exception.getMessage();
            }
        }
        
        return setInvalidResponse(baseVO, rcDetailInternal);
    }
    
    /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception) {
        //Previous impl was losing exception info, pass it on
       
        return handleResponse(baseVO, exception,null);
    }

    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO) {
        return setInvalidResponse(baseVO, null);
        
    }
    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO, String pRootCauseDetail) {
        //Log RC detail along with ip to be able to tie it to the request
        UnlockLogUtil.errorInfo(UnlockConstants.TAX_VALIDATOR,
                        "setInvalidResponse", pRootCauseDetail, "");

        CalculateTaxResponse calcTaxResponse = new CalculateTaxResponse();
        TaxDetail taxDetail = new TaxDetail();
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);
        List<TaxDetail> taxDetailList = new ArrayList<TaxDetail>();
        taxDetail.setGeoCode(UnlockConstants.BLANK);
        taxDetail.setTaxAuthority(UnlockConstants.BLANK);
        taxDetail.setTaxType(UnlockConstants.BLANK);
        taxDetail.setTaxAmount(UnlockConstants.BLANK);
        taxDetailList.add(taxDetail);
        calcTaxResponse.setTaxDetail(taxDetailList);
        calcTaxResponse.setServiceStatus(serviceStatus);
        calcTaxResponse.setTotalTax(UnlockConstants.BLANK);
        return calcTaxResponse;
    }

}
