package com.att.unlock.rest.validator;

import java.util.List;

import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.UnlockBaseVO;

/**
 * <b>Name:</b> UnlockValidator.
 * <b>Purpose:</b>This interface is designed for validation.
 * @author SS00349933
 */
public interface UnlockValidator {

    /**
     * <b>Name:</b> validate.
     * <b>Purpose:</b>This method is used to
     * Validating the request object object getting from UI.
     * @param baseVO as UnlockBaseVO
     * @return list
     */
    List<ErrorDetail> validate(UnlockBaseVO baseVO);

    /**
     * <b>Name:</b> getValidationResponse.
     * <b>Purpose:</b>This Method for
     * generating the response against the validation failure.
     * @param baseVO as UnlockBaseVO
     * @param errorList as List containing the ErrorDetails
     * @return UnlockBaseVO
     */
    UnlockBaseVO getValidationResponse(UnlockBaseVO baseVO, List<ErrorDetail> errorList);

}
