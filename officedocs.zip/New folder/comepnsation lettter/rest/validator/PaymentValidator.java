package com.att.unlock.rest.validator;

import java.util.ArrayList;
import java.util.List;

import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.ErrorInfo;
import com.att.unlock.api.vo.ServiceStatus;
import com.att.unlock.api.vo.UnLockVerifyPaymentDetailRequest;
import com.att.unlock.api.vo.UnLockVerifyPaymentDetailResponse;
import com.att.unlock.api.vo.UnlockBaseVO;
import com.att.unlock.api.vo.UnlockOrderDetail;
import com.att.unlock.api.vo.UnlockPaymentProcessRequest;
import com.att.unlock.api.vo.UnlockPaymentProcessResponse;
import com.att.unlock.api.vo.ValidationErrors;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;

/**
 * <b>Name:</b> PaymentValidator. <b>Purpose:</b>This class is designed for
 * validation.
 *
 * @author SS00349933
 */
public class PaymentValidator implements UnlockValidator, UnlockResponseHandler {

    /**
     * <b>Name:</b> validate. <b>Purpose:</b>This method is used to Validating
     * the request object object getting from UI.
     *
     * @param baseVO
     *            as UnlockBaseVO
     * @return boolean
     */
    @Override
    public final List<ErrorDetail> validate(final UnlockBaseVO baseVO) {
        UnlockLogUtil.serviceInfo(UnlockConstants.PAYMENT_VALIDATOR,
                "validate", "[Start: Class "
                        + UnlockConstants.PAYMENT_VALIDATOR
                        + " : Method : " + "validate" + "]");
        List<ErrorDetail> errorList = new ArrayList<ErrorDetail>();

        if (null == baseVO) {
            errorList.add(setError());
            return errorList;
        }

        if (baseVO instanceof UnLockVerifyPaymentDetailRequest) {
            UnLockVerifyPaymentDetailRequest paymentRequest = (UnLockVerifyPaymentDetailRequest) baseVO;

            if (UnlockStringUtil.isEmpty(paymentRequest.getRequestId())) {
                // Object is Invalid
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(paymentRequest
                    .getTransactionId())) {
                // Object is Invalid
                errorList.add(setError());
            }
        } else {

            UnlockPaymentProcessRequest processRequest = (UnlockPaymentProcessRequest) baseVO;
            if (UnlockStringUtil.isEmpty(processRequest.getOrderDetail()
                    .getOrderNumber())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getOrderDetail()
                    .getImei())) {
                errorList.add(setError());
            } else if (processRequest.getOrderDetail().getImei().length() != 15) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getOrderDetail()
                    .getFirstName())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getOrderDetail()
                    .getLastName())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getCardInfo().getPaymentMethod())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getCardInfo().getNameOnCard())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getCardInfo().getCardNumber())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getCardInfo().getExpirationDate())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getCardInfo().getSecurityCode())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getBillingAddress().getAddressLine1())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getBillingAddress().getCity())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getBillingAddress().getState())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getBillingAddress().getZipCode())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getCharges().getUnlockFee())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getCharges().getTotalPayment())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getCharges().getGeoCode())) {
                errorList.add(setError());
            } else if (UnlockStringUtil.isEmpty(processRequest.getPaymentDetail()
                    .getCharges().getPaymentToken())) {
                errorList.add(setError());
            }

        }
        // Object not valid
        UnlockLogUtil.serviceInfo(UnlockConstants.PAYMENT_VALIDATOR,
                "validate", "[End: Class "
                        + UnlockConstants.PAYMENT_VALIDATOR
                        + " : Method : " + "validate" + "]");
        return errorList;
    }

    /**
     * <b>Name:</b> getValidationResponse. <b>Purpose:</b>This Method for
     * generating the response against the validation failure.
     *
     * @param baseVO
     *            as UnlockBaseVO
     * @return UnlockBaseVO
     */
    @Override
    public final UnlockBaseVO getValidationResponse(UnlockBaseVO baseVO,
            List<ErrorDetail> errorList) {
        UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR,
                "getValidationResponse", "[Start: Class "
                        + UnlockConstants.ORDER_VALIDATOR
                        + " : Method : " + "getValidationResponse" + "]");
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);

        if (baseVO instanceof UnLockVerifyPaymentDetailRequest) {
            UnLockVerifyPaymentDetailResponse verifyPaymentResponse = new UnLockVerifyPaymentDetailResponse();
            UnlockOrderDetail unlockOrderDetail = new UnlockOrderDetail();
            unlockOrderDetail.setOrderNumber(UnlockConstants.BLANK);
            unlockOrderDetail.setImei(UnlockConstants.BLANK);
            unlockOrderDetail.setUnlockStatus(UnlockConstants.BLANK);
            unlockOrderDetail.setUnlockSubStatus(UnlockConstants.BLANK);
            unlockOrderDetail.setErrorCode(UnlockConstants.BLANK);
            unlockOrderDetail.setErrorDescription(UnlockConstants.BLANK);

            verifyPaymentResponse.setUnlockOrderDetail(unlockOrderDetail);
            verifyPaymentResponse.setServiceStatus(serviceStatus);

            ValidationErrors validationErrors = new ValidationErrors();
            validationErrors.setErrorList(errorList);
            verifyPaymentResponse.setValidationErrors(validationErrors);

            return verifyPaymentResponse;

        } else {
            UnlockPaymentProcessResponse paymentProcessResponse = new UnlockPaymentProcessResponse();

            UnlockOrderDetail unlockOrderDetail = new UnlockOrderDetail();
            unlockOrderDetail.setImei(UnlockConstants.BLANK);
            unlockOrderDetail.setOrderNumber(UnlockConstants.BLANK);
            unlockOrderDetail.setPaymentDateTime(UnlockConstants.BLANK);

            paymentProcessResponse.setUnlockOrderDetail(unlockOrderDetail);
            paymentProcessResponse.setServiceStatus(serviceStatus);

            ValidationErrors validationErrors = new ValidationErrors();
            validationErrors.setErrorList(errorList);
            paymentProcessResponse.setValidationErrors(validationErrors);

            return paymentProcessResponse;
        }

    }

    /**
     * This method is used to set the error detail
     * @return ErrorDetail
     */
    public ErrorDetail setError() {
        ErrorDetail errorDetail = new ErrorDetail();
        errorDetail.setErrorCode(UnlockConstants.SYSTEM_ERROR_CODE);
        errorDetail.setErrorDescription(UnlockConstants.SYSTEM_ERROR_MESSAGE);
        return errorDetail;
    }

    /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception, String rcDetailInternal) {
        //Previous impl was losing exception info, pass it on
        //the set method will decide if its appropriate to send to FE or just log
        
        //Add passed in detail and exception message
        if (rcDetailInternal == null){
            
            if (exception != null)
            {
                rcDetailInternal="Exception:"; //TODO: Put this in a constant
                //log the stacktrace in debug
                //Which specific exception ?
                rcDetailInternal+=exception.getMessage();
            }
        }
        
        return setInvalidResponse(baseVO, rcDetailInternal);
    }
    
    /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception) {
        //Previous impl was losing exception info, pass it on
       
        return handleResponse(baseVO, exception,null);
    }

    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO) {
        return setInvalidResponse(baseVO, null);
        
    }
    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO, String pRootCauseDetail) {
        //Log RC detail along with ip to be able to tie it to the request
        UnlockLogUtil.errorInfo(UnlockConstants.PAYMENT_VALIDATOR,
                        "setInvalidResponse", pRootCauseDetail, "");

        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);

        if (baseVO instanceof UnLockVerifyPaymentDetailResponse) {
            UnLockVerifyPaymentDetailResponse verifyPaymentResponse = new UnLockVerifyPaymentDetailResponse();
            UnlockOrderDetail unlockOrderDetail = new UnlockOrderDetail();
            unlockOrderDetail.setOrderNumber(UnlockConstants.BLANK);
            unlockOrderDetail.setImei(UnlockConstants.BLANK);
            unlockOrderDetail.setMake(UnlockConstants.BLANK);
            unlockOrderDetail.setModel(UnlockConstants.BLANK);
            unlockOrderDetail.setUnlockStatus(UnlockConstants.BLANK);
            unlockOrderDetail.setUnlockSubStatus(UnlockConstants.BLANK);
            unlockOrderDetail.setPaymentToken(UnlockConstants.BLANK);
            unlockOrderDetail.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
            unlockOrderDetail.setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);
            verifyPaymentResponse.setUnlockOrderDetail(unlockOrderDetail);
            verifyPaymentResponse.setServiceStatus(serviceStatus);
            return verifyPaymentResponse;

        } else {
            UnlockPaymentProcessResponse paymentProcessResponse = new UnlockPaymentProcessResponse();

            UnlockOrderDetail unlockOrderDetail = new UnlockOrderDetail();
            unlockOrderDetail.setImei(UnlockConstants.BLANK);
            unlockOrderDetail.setOrderNumber(UnlockConstants.BLANK);
            unlockOrderDetail.setPaymentDateTime(UnlockConstants.BLANK);
            unlockOrderDetail.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
            unlockOrderDetail.setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);
            ErrorInfo errorInfo = new ErrorInfo();
            errorInfo.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
            errorInfo.setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);
            paymentProcessResponse.setErrorInfo(errorInfo);
            paymentProcessResponse.setUnlockOrderDetail(unlockOrderDetail);
            paymentProcessResponse.setServiceStatus(serviceStatus);

            return paymentProcessResponse;
        }


    }
}
