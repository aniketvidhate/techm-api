package com.att.unlock.rest.validator;

import java.util.List;

import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.OrderFlowRequestDO;

public interface OCEUnlockValidator {
    
    /**
     * 
     * @param orderFlowRequestDO
     * @param csrfToken 
     * @return
     */
    List<ErrorDetail> validate(OrderFlowRequestDO orderFlowRequestDO);

}
