package com.att.unlock.rest.validator;

import java.util.ArrayList;
import java.util.List;

import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.ImeiDetail;
import com.att.unlock.api.vo.ImeiLookupRequest;
import com.att.unlock.api.vo.ImeiSearchResponse;
import com.att.unlock.api.vo.ServiceStatus;
import com.att.unlock.api.vo.UnlockBaseVO;
import com.att.unlock.api.vo.ValidationErrors;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.rest.common.UnlockValidatorUtil;

/**
 * <b>Name:</b> IMEIValidator. <b>Purpose:</b>This class is designed for
 * validation.
 *
 * @author SS00349933
 */

public class IMEIValidator implements UnlockValidator, UnlockResponseHandler {

    /**
     *
     *
     */
    private static final int FIFTEEN = 15;

    /**
     * <b>Name:</b> validate. <b>Purpose:</b>This method is used to Validating
     * the request object object getting from UI.
     *
     * @param baseVO
     *            as UnlockBaseVO
     * @return List
     */
    @Override
    public List<ErrorDetail> validate(final UnlockBaseVO baseVO) {
        UnlockLogUtil.serviceInfo(UnlockConstants.IMEI_VALIDATOR,
                 "validate", "[Start: Class "
                         + UnlockConstants.IMEI_VALIDATOR
                         + " : Method : " + "validate" + "]");
        List<ErrorDetail> errorList = new ArrayList<ErrorDetail>();

        if (null == baseVO) {
            errorList.add(setError());
            return errorList;
        }

        if (!validateForSpecialCharacter(baseVO)) {
            errorList.add(setError());
            return errorList;
        }

        ImeiLookupRequest imeiLookupRequest = (ImeiLookupRequest) baseVO;
        if (UnlockStringUtil.isEmpty(imeiLookupRequest.getImei())) {
            errorList.add(setError());
        } else if (imeiLookupRequest.getImei().length() != FIFTEEN) {
            errorList.add(setError());
        }
        UnlockLogUtil.serviceInfo(UnlockConstants.IMEI_VALIDATOR,
                "validate", "[End: Class "
                        + UnlockConstants.IMEI_VALIDATOR
                        + " : Method : " + "validate" + "]");
        return errorList;
    }

    /**
     *
     * @param baseVO
     * @return
     */
    private boolean validateForSpecialCharacter(final UnlockBaseVO baseVO) {

        boolean isValid = true;
        ImeiLookupRequest imeiLookupRequest = (ImeiLookupRequest) baseVO;
        if (UnlockStringUtil.isNotEmpty(imeiLookupRequest.getImei()) &&
                UnlockValidatorUtil.containsSpecialCharacter(imeiLookupRequest.getImei())) {

            isValid = false;
        }
        return isValid;
    }

    /**
     * Sending the validation error response
     */

    /**
     * <b>Name:</b> getValidationResponse. <b>Purpose:</b>This Method for
     * generating the response against the validation failure.
     *
     * @param baseVO
     *            UnlockBaseVO
     * @return ImeiSearchResponse
     */
    @Override
    public ImeiSearchResponse getValidationResponse(final UnlockBaseVO baseVO,
            List<ErrorDetail> errorList) {
        UnlockLogUtil.serviceInfo(UnlockConstants.IMEI_VALIDATOR,
                 "getValidationResponse", "[Start: Class "
                         + UnlockConstants.IMEI_VALIDATOR
                         + " : Method : " + "getValidationResponse" + "]");
        // Creating the response object
        ImeiSearchResponse imeiSearchResponse = new ImeiSearchResponse();
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);

        imeiSearchResponse.setServiceStatus(serviceStatus);
        // if request is not null populate some values from it
        ImeiLookupRequest imeiLookupRequest = (ImeiLookupRequest) baseVO;

        ImeiDetail imeiDetail = new ImeiDetail();
        
        if ((baseVO != null)) {
                if (!UnlockValidatorUtil.containsSpecialCharacter(imeiLookupRequest.getImei())) {
                        imeiDetail.setImei(imeiLookupRequest.getImei());
                } else {
                        imeiDetail.setImei((UnlockConstants.BLANK)); 
                }       
        } else {
            imeiDetail.setImei(UnlockConstants.BLANK);
        }
        imeiDetail.setMake(UnlockConstants.BLANK);
        imeiDetail.setModel(UnlockConstants.BLANK);
        imeiDetail.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
        imeiDetail.setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);

        imeiSearchResponse.setImeiDetail(imeiDetail);
        ValidationErrors validationErrors = new ValidationErrors();
        validationErrors.setErrorList(errorList);
        imeiSearchResponse.setValidationErrors(validationErrors);
        // Returning response with validation errors
        UnlockLogUtil.serviceInfo(UnlockConstants.IMEI_VALIDATOR,
                "getValidationResponse", "[End: Class "
                        + UnlockConstants.IMEI_VALIDATOR
                        + " : Method : " + "getValidationResponse" + "]");
        return imeiSearchResponse;
    }

    /**
     * This method is used to set the error detail
     * @return ErrorDetail
     */
    public ErrorDetail setError() {
        ErrorDetail errorDetail = new ErrorDetail();
        errorDetail.setErrorCode(UnlockConstants.SYSTEM_ERROR_CODE);
        errorDetail.setErrorDescription(UnlockConstants.SYSTEM_ERROR_MESSAGE);
        return errorDetail;
    }

   /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception, String rcDetailInternal) {
        //Previous impl was losing exception info, pass it on
        //the set method will decide if its appropriate to send to FE or just log
        
        //Add passed in detail and exception message
        if (rcDetailInternal == null){
            
            if (exception != null)
            {
                rcDetailInternal="Exception:"; //TODO: Put this in a constant
                //log the stacktrace in debug
                //Which specific exception ?
                rcDetailInternal+=exception.getMessage();
            }
        }
        
        return setInvalidResponse(baseVO, rcDetailInternal);
    }
    
    /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception) {
        //Previous impl was losing exception info, pass it on
       
        return handleResponse(baseVO, exception,null);
    }

    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO) {
        return setInvalidResponse(baseVO, null);
        
    }
    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO, String pRootCauseDetail) {
        //Log RC detail along with ip to be able to tie it to the request
        UnlockLogUtil.errorInfo(UnlockConstants.IMEI_VALIDATOR,
                        "setInvalidResponse", pRootCauseDetail, "");
        ImeiSearchResponse imeiSearchResponse = new ImeiSearchResponse();
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);
        imeiSearchResponse.setServiceStatus(serviceStatus);
        ImeiDetail imeiDetail = new ImeiDetail();
        imeiDetail.setImei(UnlockConstants.BLANK);
        imeiDetail.setMake(UnlockConstants.BLANK);
        imeiDetail.setModel(UnlockConstants.BLANK);
        imeiDetail.setErrorCode(UnlockConstants.BLANK);
        imeiDetail.setErrorDescription(UnlockConstants.BLANK);
        imeiSearchResponse.setImeiDetail(imeiDetail);
        return imeiSearchResponse;
    }
}
