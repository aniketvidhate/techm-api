package com.att.unlock.rest.validator;

import java.util.ArrayList;
import java.util.List;

import com.att.unlock.api.vo.Captcha;
import com.att.unlock.api.vo.ErrorDetail;
import com.att.unlock.api.vo.OCEUnlockOrderStatusDO;
import com.att.unlock.api.vo.OrderDetail;
import com.att.unlock.api.vo.ServiceStatus;
import com.att.unlock.api.vo.UnlockBaseVO;
import com.att.unlock.api.vo.UnlockOrderDetail;
import com.att.unlock.api.vo.UnlockOrderRequest;
import com.att.unlock.api.vo.UnlockOrderResponse;
import com.att.unlock.api.vo.UnlockOrderStatusRequest;
import com.att.unlock.api.vo.UnlockOrderStatusResponse;
import com.att.unlock.api.vo.ValidationErrors;
import com.att.unlock.base.util.UnlockBeanUtil;
import com.att.unlock.base.util.UnlockLogUtil;
import com.att.unlock.base.util.UnlockStringUtil;
import com.att.unlock.rest.common.UnlockConstants;
import com.att.unlock.rest.common.UnlockResponseHandler;
import com.att.unlock.rest.common.UnlockValidatorUtil;

/**
 * <b>Name:</b> OrderValidator\ <b>Purpose:</b>This class is designed for
 * validation.
 *
 * @author SS00349933
 */
public class OrderValidator implements UnlockValidator, UnlockResponseHandler {


    /**
     * <b>Name:</b> validate. <b>Purpose:</b>This method is used to Validating
     * the request object object getting from UI.
     *
     * @param baseVO
     *            as UnlockBaseVO
     * @return List
     */
    @Override
    public List<ErrorDetail> validate(final UnlockBaseVO baseVO) {
        UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR, "validate",
                "[Start: Class " + UnlockConstants.ORDER_VALIDATOR
                        + " : Method : " + "validate" + "]");
        List<ErrorDetail> errorList = new ArrayList<ErrorDetail>();
        if (baseVO == null) {

            errorList.add(setError());
            return errorList;
        }

        if (!validateForSpecialCharacter(baseVO)) {
            errorList.add(setError());
            return errorList;
        }

        if (baseVO instanceof UnlockOrderRequest) {
            
            UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR, "validate",
                    "[Start: Class " + UnlockConstants.ORDER_VALIDATOR
                            + "baseVO instanceof UnlockOrderRequest");     

            UnlockOrderRequest unlockOrderRequest = (UnlockOrderRequest) baseVO;
            if (null != unlockOrderRequest.getOrderDetail()) {
                OrderDetail orderDeatil = unlockOrderRequest.getOrderDetail();

                if (UnlockStringUtil.isEquals(UnlockBeanUtil.getTcAcceptCheck(), "true"))
                {
                     if (!UnlockStringUtil.isEquals(orderDeatil.getTcAccepted(), "true"))
                     {
                           errorList.add(setError());
                           return errorList;
                     }
                }


                if (UnlockStringUtil.isEmpty(orderDeatil.getCustomerType())) {

                    errorList.add(setError());

                }

                else if (UnlockStringUtil.isNotEmpty(orderDeatil.getCtn())
                        && !(orderDeatil.getCtn()
                                .equalsIgnoreCase(UnlockConstants.NON_ATT_CUSTOMER))
                        && UnlockStringUtil.isEmpty(orderDeatil.getCtn())) {
                    errorList.add(setError());

                } else if (UnlockStringUtil.isNotEmpty(orderDeatil.getCtn())
                        && !(orderDeatil.getCtn()
                                .equalsIgnoreCase(UnlockConstants.NON_ATT_CUSTOMER))
                        && orderDeatil.getCtn().length() != UnlockConstants.TEN) {
                    errorList.add(setError());

                } else if (UnlockStringUtil.isEmpty(orderDeatil.getImei())) {

                    errorList.add(setError());
                } else if (UnlockStringUtil.isNotEmpty(orderDeatil.getImei())
                        && orderDeatil.getImei().length() != UnlockConstants.FIFTEEN) {

                    errorList.add(setError());
                } else if (UnlockStringUtil.isEmpty(orderDeatil.getFirstName())) {

                    errorList.add(setError());
                } else if (UnlockStringUtil.isEmpty(orderDeatil.getLastName())) {

                    errorList.add(setError());
                }

                else if (UnlockStringUtil
                        .isEmpty(orderDeatil.getEmailAddress())) {

                    errorList.add(setError());
                } else if (UnlockStringUtil.isNotEmpty(orderDeatil
                        .getLastFourSSN())
                        && !(orderDeatil.getLastFourSSN().equalsIgnoreCase(
                                UnlockConstants.NON_ATT_CUSTOMER) || orderDeatil
                                .getLastFourSSN().equalsIgnoreCase(
                                        UnlockConstants.GO_PHONE))
                        && UnlockStringUtil.isEmpty(orderDeatil
                                .getLastFourSSN())) {

                    errorList.add(setError());

                } else if (UnlockStringUtil.isNotEmpty(orderDeatil
                        .getAccountPassCode())
                        && !(orderDeatil.getAccountPassCode().equalsIgnoreCase(
                                UnlockConstants.NON_ATT_CUSTOMER) || orderDeatil
                                .getAccountPassCode().equalsIgnoreCase(
                                        UnlockConstants.GO_PHONE))
                        && UnlockStringUtil.isEmpty(orderDeatil
                                .getAccountPassCode())) {

                    errorList.add(setError());

                } else if (UnlockStringUtil.isEmpty(orderDeatil.getBrowserID())) {

                    errorList.add(setError());

                }

            } else {
                errorList.add(setError());
            }

            if (null != unlockOrderRequest.getCaptcha()) {
                 UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR, "validate",
                         "[Start: Class " + UnlockConstants.ORDER_VALIDATOR
                                 + "unlockOrderRequest.getCaptcha() is null..."); 
                
                Captcha captcha = unlockOrderRequest.getCaptcha();
                if (UnlockStringUtil.isNotEmpty(captcha.getCaptchaId())) {
                    UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR, "validate",
                            "[Start: Class " + UnlockConstants.ORDER_VALIDATOR
                                    + "Inside If block..getting Captcha Id null...");     
                    if (UnlockStringUtil.isEmpty(captcha.getCaptchaType())) {

                        errorList.add(setError());

                    } else if (UnlockStringUtil.isEmpty(captcha
                            .getCaptchaResponse())) {

                        errorList.add(setError());
                    }
                } 
                //QC#10899, Incase captcha id is null
                else {
                    UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR, "validate",
                            "[Start: Class " + UnlockConstants.ORDER_VALIDATOR
                                    + "Inside else block...");     
                    errorList.add(setError());
                }
            } else {
                errorList.add(setError());
            }

        } else if (baseVO instanceof UnlockOrderStatusRequest) {
            UnlockOrderStatusRequest unlockOrderStatusRequest = (UnlockOrderStatusRequest) baseVO;

            if (null != unlockOrderStatusRequest.getOrderDetail()) {
                OrderDetail orderDeatil = unlockOrderStatusRequest
                        .getOrderDetail();

                if (UnlockStringUtil.isEmpty(orderDeatil.getImei())) {

                    errorList.add(setError());
                } else if (UnlockStringUtil.isNotEmpty(orderDeatil.getImei())
                        && orderDeatil.getImei().length() != UnlockConstants.FIFTEEN) {

                    errorList.add(setError());
                } else if (UnlockStringUtil.isEmpty(orderDeatil
                        .getOrderNumber())) {

                    errorList.add(setError());
                }

            } else {
                errorList.add(setError());
            }
        }
        UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR, "validate",
                "[End: Class " + UnlockConstants.ORDER_VALIDATOR
                        + " : Method : " + "validate" + "]");
        return errorList;

    }


    /**
     *
     * @param baseVO
     * @return
     */
    private boolean validateForSpecialCharacter(final UnlockBaseVO baseVO) {

        boolean isValid = true;
        if (baseVO instanceof UnlockOrderRequest) {

            UnlockOrderRequest unlockOrderRequest = (UnlockOrderRequest) baseVO;
            if (null != unlockOrderRequest.getOrderDetail()) {
                OrderDetail orderDetail = unlockOrderRequest.getOrderDetail();

                if (UnlockStringUtil.isNotEmpty(orderDetail.getFirstName()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getFirstName())) {

                        isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getLastName()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getLastName())) {

                        isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getImei()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getImei())) {

                        isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getCtn()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getCtn())) {

                        isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getLastFourSSN()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getLastFourSSN())) {

                    isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getAccountPassCode()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getAccountPassCode())) {

                    isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getEmailAddress()) &&
                        !UnlockValidatorUtil.isValidEmail(orderDetail.getEmailAddress())) {

                    isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getCustomerType()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getCustomerType())) {

                    isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getActiveMilitary())) {
                    if (UnlockStringUtil.isNotEmpty(orderDetail.getCustomerType()) &&
                            UnlockConstants.NON_CUSTOMER.equals((orderDetail.getCustomerType()))) {
                        //If customer type is non-customer then set ActiveMilitary as NULL
                        orderDetail.setActiveMilitary(null);
                    } else if (UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getActiveMilitary())) {
                        
                        isValid = false;
                    }
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getSource()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getSource())) {

                        isValid = false;
                }

            }
            if (isValid && null != unlockOrderRequest.getCaptcha()) {
                Captcha captcha = unlockOrderRequest.getCaptcha();

                if (UnlockStringUtil.isNotEmpty(captcha.getCaptchaType()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(captcha.getCaptchaType())) {

                        isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(captcha.getCaptchaId()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(captcha.getCaptchaId())) {

                        isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(captcha.getCaptchaResponse()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(captcha.getCaptchaResponse())) {

                        isValid = false;
                }
            }

        } else if (baseVO instanceof UnlockOrderStatusRequest) {
            UnlockOrderStatusRequest unlockOrderStatusRequest = (UnlockOrderStatusRequest) baseVO;

            if (null != unlockOrderStatusRequest.getOrderDetail()) {
                OrderDetail orderDetail = unlockOrderStatusRequest
                        .getOrderDetail();

                if (UnlockStringUtil.isNotEmpty(orderDetail.getImei()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getImei())) {

                        isValid = false;
                } else if (UnlockStringUtil.isNotEmpty(orderDetail.getOrderNumber()) &&
                        UnlockValidatorUtil.containsSpecialCharacter(orderDetail.getOrderNumber())) {

                        isValid = false;
                }
            }
        }

        return isValid;
    }


    /**
     * This method is used to set error code and description, in case of
     * validation failure
     *
     * @return ErrorDetail
     */
    public ErrorDetail setError() {
        ErrorDetail errorDetail = new ErrorDetail();
        errorDetail.setErrorCode(UnlockConstants.SYSTEM_ERROR_CODE);
        errorDetail.setErrorDescription(UnlockConstants.SYSTEM_ERROR_MESSAGE);
        return errorDetail;
    }

    /**
     * <b>Name:</b> getValidationResponse. <b>Purpose:</b>This Method for
     * generating the response against the validation failure.
     *
     * @param baseVO
     *            as UnlockBaseVO
     * @return UnlockBaseVO
     */
    @Override
    public UnlockBaseVO getValidationResponse(UnlockBaseVO baseVO,
            List<ErrorDetail> errorList) {
        UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR,
                "getValidationResponse", "[Start: Class "
                        + UnlockConstants.ORDER_VALIDATOR + " : Method : "
                        + "getValidationResponse" + "]");
        ServiceStatus serviceStatus = new ServiceStatus();
        serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
        serviceStatus.setDescription(UnlockConstants.FAILURE);

        if (baseVO instanceof UnlockOrderRequest) {
            UnlockOrderResponse unlockOrderResponse = new UnlockOrderResponse();

            UnlockOrderDetail unlockOrderDetail = new UnlockOrderDetail();
            unlockOrderDetail.setOrderNumber("");
            unlockOrderDetail.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
            unlockOrderDetail.setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);

            ValidationErrors validationErrors = new ValidationErrors();
            //Added for QC#40632
            if (errorList != null  && errorList.isEmpty()) {
                UnlockLogUtil.serviceInfo(UnlockConstants.ORDER_VALIDATOR,
                        "getValidationResponse", "inside if block, getting list empty");
                
                errorList.add(setError());
            }
            validationErrors.setErrorList(errorList);

            unlockOrderResponse.setUnlockOrderDetail(unlockOrderDetail);
            unlockOrderResponse.setServiceStatus(serviceStatus);
            unlockOrderResponse.setValidationErrors(validationErrors);

            return unlockOrderResponse;

        } else {

            UnlockOrderStatusResponse unlockOrderStatusResponse = new UnlockOrderStatusResponse();

            ErrorDetail errorDetail = new ErrorDetail();
            errorDetail.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
            errorDetail.setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);

            ValidationErrors validationErrors = new ValidationErrors();
            validationErrors.setErrorList(errorList);

            unlockOrderStatusResponse.setErrorDetail(errorDetail);
            unlockOrderStatusResponse.setServiceStatus(serviceStatus);
            unlockOrderStatusResponse.setValidationErrors(validationErrors);

            return unlockOrderStatusResponse;

        }

    }

    
    /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception, String rcDetailInternal) {
        //Previous impl was losing exception info, pass it on
        //the set method will decide if its appropriate to send to FE or just log
        
        //Add passed in detail and exception message
        if (rcDetailInternal == null){
            
            if (exception != null)
            {
                rcDetailInternal="Exception:"; //TODO: Put this in a constant
                //log the stacktrace in debug
                //Which specific exception ?
                rcDetailInternal+=exception.getMessage();
            }
        }
        
        return setInvalidResponse(baseVO, rcDetailInternal);
    }
    
    /**
     * This method is used to set the status in case of exception
     */
    public UnlockBaseVO handleResponse(final UnlockBaseVO baseVO,
            final Exception exception) {
        //Previous impl was losing exception info, pass it on
       
        return handleResponse(baseVO, exception,null);
    }

    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO) {
        return setInvalidResponse(baseVO, null);
       
    }
    
    /**
     * This method is used to set the response in case of invalid token
     */
    @Override
    public UnlockBaseVO setInvalidResponse(UnlockBaseVO baseVO, String pRootCauseDetail) {
        //Log RC detail along with ip to be able to tie it to the request
        UnlockLogUtil.errorInfo(UnlockConstants.ORDER_VALIDATOR,
                        "setInvalidResponse", pRootCauseDetail, "");
        if (baseVO instanceof OCEUnlockOrderStatusDO) {
            OCEUnlockOrderStatusDO OCEStatusDO=new OCEUnlockOrderStatusDO();
            ValidationErrors errors=new ValidationErrors();
            List<ErrorDetail> errorList=new ArrayList<ErrorDetail>();
            ErrorDetail currentError=new ErrorDetail();
            currentError.setErrorCode(UnlockConstants.INVALID_OCE_TOKEN_ERROR_CODE);
            currentError.setErrorDescription(UnlockConstants.INVALID_OCE_TOKEN_ERROR_DESC);
            errorList.add(currentError);
            errors.setErrorList(errorList);
            OCEStatusDO.setValidationErrors(errors);
            return OCEStatusDO;
        }
        else if (baseVO instanceof UnlockOrderResponse) {
             ServiceStatus serviceStatus = new ServiceStatus();
             serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
             serviceStatus.setDescription(UnlockConstants.FAILURE);

            UnlockOrderResponse unlockOrderResponse = new UnlockOrderResponse();
            UnlockOrderDetail unlockOrderDetail = new UnlockOrderDetail();
            unlockOrderDetail
                    .setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
            unlockOrderDetail
                    .setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);
            unlockOrderDetail.setOrderNumber(UnlockConstants.BLANK);
            unlockOrderResponse.setUnlockOrderDetail(unlockOrderDetail);
            unlockOrderResponse.setServiceStatus(serviceStatus);

            return unlockOrderResponse;
        } else {
             ServiceStatus serviceStatus = new ServiceStatus();
             serviceStatus.setCode(UnlockConstants.STATUS_CODE_TWO);
             serviceStatus.setDescription(UnlockConstants.FAILURE);

            UnlockOrderStatusResponse unlockOrderStatusResponse = new UnlockOrderStatusResponse();
            ErrorDetail errorDetail = new ErrorDetail();
            errorDetail.setErrorCode(UnlockConstants.INVALID_TOKEN_ERROR_CODE);
            errorDetail
                    .setErrorDescription(UnlockConstants.INVALID_TOKEN_ERROR_DESC);
            unlockOrderStatusResponse.setErrorDetail(errorDetail);
            unlockOrderStatusResponse.setServiceStatus(serviceStatus);
            return unlockOrderStatusResponse;

        }
        
    }
    


}
