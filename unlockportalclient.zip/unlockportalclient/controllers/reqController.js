/**
  * @Author 		:- Aniket Vidhate (av0041) /   
  * modified by		:- Nulufer (nd295j)
  * Date			:- 12-7-2015
  * File name 		:- reqController.js
  */

unlockPortal.controller('reqController', function($scope, $http, $rootScope, $location, $cookies, $window, services) {
	window.scrollTo(0,0);
	angular.element("#pageheader").css('display','block');	//show header after coming back from status page
	angular.element(".hrBorder").show();
	angular.element("#unlockrequest").hide();
	angular.element("#IRUCRUHeader").hide();
	$rootScope.commonError = false;
	$rootScope.isLanguageSelectedEnglish = true;
	
     $scope.fetchCookieByName = function(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
   }
	$scope.getEnglishContent = function(){
         var jsonURL = '';
        if(typeof GE5P != 'undefined'){
           if(GE5P.ge5p_localLanguage == 'en_US'){
             jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
          }else if(GE5P.ge5p_localLanguage == 'es_US'){
              jsonURL = "/deviceunlock/json/es/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
           }
        }else{
            var valueCookie = $scope.fetchCookieByName('GNSESS');
			var isMobile = window.navigator.userAgent.toLowerCase().indexOf('mobile') != -1 ? true : false;
      if(typeof valueCookie == "string" && typeof valueCookie != 'undefined' && $.trim(valueCookie) != "" && !isMobile){
         var getStoredCookieObj = eval('(' + valueCookie + ')');
         if(getStoredCookieObj.LOCALE == 'en_US'){
            jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
         }else if(getStoredCookieObj.LOCALE == 'es_US'){
            jsonURL = "/deviceunlock/json/es/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
         }else{
             jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish 
         }
      }else{
		    if(localStorage.getItem('userLang') == null || localStorage.getItem('userLang') == undefined){
            jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
			}else if(localStorage.getItem('userLang') == "es"){
				jsonURL = "/deviceunlock/json/es/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
			}else{
				jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
			}
       } 
        }
      
        if(jsonURL.indexOf("/es/") > -1){
        	$rootScope.isLanguageSelectedEnglish = false; 
        }
      
		services.getStatus(jsonURL)
		.success(function(jsonData) {
			$rootScope.data = jsonData.unlockPortalLabelAndErrorObj[0];
			$('#pageheader .title').text($rootScope.data.unlockPortalPageHeaderTitle);
		});
	}
	
	$scope.getEnglishContent();

    $scope.continuetounlock = function(){
        openLoader();
        //post call start	
        $http({
            method: 'POST',
            url: unlockApiUrl.sitecheck,
			data:{}
        }).success(function(checkSite) {
            closeLoader();
            if(checkSite =="true"){
				$location.path('/unlockstep1');
            }
        }).error(function(data, status, headers, config) {
            closeLoader();
            $location.path('/');
        });	
        //post call ends
        
    }//function end
	
	closeLoader();  //close loader when coming from forms
});