/**
* @Author 		:- Aniket Vidhate (av0041)   
* Date			:- 12-7-2015
* File name 	:- unlock_step3_controller.js
*/

//Unlock Step 3 Controller - S
unlockPortal.controller('step3Ctrl', ['$scope', '$rootScope', '$http', 'services','tooltipUtility', '$sce', '$window', '$location', function($scope, $rootScope, $http, services,tooltipUtility, $sce, $window, $location){
    //To smothen the User experience we want the loader till UI gets ready
    openLoader();
	angular.element("#firstPageHeader").show();

    $scope.IMEIEntered = "";
    $scope.isVaild = false;
    $scope.imeiValidErr = false;

    $("#newOrderSeparator, #newOrder, #headercru").removeClass("divShow").addClass("divHide");
    
    //checking cookies while accesing unlock request page
    if (sessionStorage.getItem("hasReadTerms") == 'yes' && sessionStorage.getItem("agreeCheckedBox") == 'yes' 
    && $rootScope.unlockStep2Resp !== undefined && $rootScope.unlockStep2Resp.orderFlowResponseDO.validationErrors === undefined) {
        //user can access unlock request page

        
        
        /*if($rootScope.isReadAndAgreeTermsAndCondition === undefined || $rootScope.isReadAndAgreeTermsAndCondition === false){
        console.log("Terms & condition has been not agreed trying to access step3");
        window.location = "#/unlock";
        window.scrollTo(0, 0);
        }else{*/
        //$rootScope.isOrderProcessedSuccessfully = false;
        
        //if($rootScope.isOrderProcessedSuccessfully === true){
        //window.location = "#/unlock";
        //}
        
        
        
        if($rootScope.imei_usr !== undefined && $rootScope.imei_usr !== ""){
            $scope.imei = $rootScope.imei_usr;
            $scope.make = "";
            $scope.model = "";
            $rootScope.commonError = false;
            $scope.commonErrorMsgs = "";
            var error8047step3 = false;
            if($scope.imei == undefined || $scope.imei == "" || $scope.imei.length < 15){
                if($scope.imei.length < 15){
                    $scope.imeiLengthErr = true;
                }
                $scope.isVaild = false;
                
            }else{
                
                openLoader();
                
                unlockStep3IMEICheckRequest = {
                    
                    "orderFlowRequestDO": {
                        
                        "attCustomer" : $rootScope.custType,
                        "military" 	  : $rootScope.militaryPersnl,
                        "currentFlow" : "IMEI_VERIFICATION_FLOW",
                        "ctn" 		  : $rootScope.attwrlsno_usr,
                        "imei"		  : $scope.imei,
                        "captcha"	  : {
                                            "captchaType":$rootScope.CaptchaType,
                                            "captchaId":$rootScope.challenge,
                                            "captchaResponse":$rootScope.recaptcha_response_field,
                                            "captchaRefId":$rootScope.captchaRefId
                                    	},
                        //"ipAddress"	  : myip,
                        "browserId"	  : browserId

                    }
                    
                }
                
                
                //Post call to validate screen 3 IMEI data and prefiling make & model or else to show error
				//$http.get("/etc/demo/ULS_8047_error_status")
                services.postService(url.unlockStepPostURL, unlockStep3IMEICheckRequest)
                .success(function(jsonrRespData) {

                	$rootScope.commonError = false;
                    $rootScope.unlockStep3ATTIMEIResp = jsonrRespData;
//                    $scope.errorsArray = [];
//                    $scope.serverErrorsArray = [];
                    
                    if(jsonrRespData.orderFlowResponseDO.validationErrors !== undefined){
                        
                        var validationErrors = jsonrRespData.orderFlowResponseDO.validationErrors.errorList;
                        
                        $scope.commonErrorMsgs = "";
                        //console.log("****==== "+$scope.errorsArray.length);
                        $.each( validationErrors, function( key, value ) {
                            //console.log("key "+key+" value "+value);
                            
                            if(value.errorCode === undefined){
                                if(key ==="errorCode" && value == "ULS_8023"){
                                   // console.log("validate imei number");
                                	$rootScope.commonError = false;
                                    $scope.imeiValidErr = true;
                                    
                                }
								else if(key ==="errorCode" && value == "ULS_8047"){
                                    //console.log("validate imei number");
									$rootScope.commonError = true;
                                    //error8047 = true;
                                    //$scope.errorsArray.push(value);
									$rootScope.error = validationErrors.errorDescription;
//                                    $scope.serverErrorsArray.push(validationErrors.errorDescription);
                                }
                                else{
                                    if(key !=="errorDescription" ){
                                    	$rootScope.commonError = true;
                                        if(value == "ULS_8033" || value == "ULS_8017"){
                                           $scope.blackListIMEIErr = true;
                                        }
//                                        $scope.errorsArray.push(value);
                                        $rootScope.error = $rootScope.data[value];
                                    }
                                }
                            }else{
                            	$rootScope.commonError = true;
                                //console.log("errorCode ==>"+value.errorCode);
                                //console.log("errorCode ==>"+value.errorDescription);
                                if((value.errorCode).substring(0, 4) === "ULF_"){
//                                    $scope.serverErrorsArray.push(value.errorDescription +" (errorCode."+value.errorCode+")");
                                	$rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                }else{
//                                    $scope.errorsArray.push(value.errorCode);
                                	$rootScope.error = $rootScope.data[value.errorCode];
                                }
                                
                            }
                        });
                        

                        closeLoader();
                        $scope.make = "";
                        $scope.model = "";
                        window.scrollTo(0, 0);
                        $scope.isVaild = false;

                    }else{
                        $scope.make = jsonrRespData.orderFlowResponseDO.make;
                        $scope.model = jsonrRespData.orderFlowResponseDO.model;
						$rootScope.attimeiRefId = jsonrRespData.orderFlowResponseDO.imeiRefId;
						$rootScope.makeRefId = jsonrRespData.orderFlowResponseDO.makeRefId;
						$rootScope.modelRefId = jsonrRespData.orderFlowResponseDO.modelRefId;
                        $scope.isVaild = true;
                        $scope.imeiValidErr = false;
                        closeLoader();
                        
                    }
                    
                }).error(function(data, status, headers, config) {
                    closeLoader();
                    $scope.isVaild = false;
                    $rootScope.commonError = true;
//                    $scope.errorsArray = [];
//                    $scope.errorsArray.push("ULP_0000");
                    $rootScope.error = $rootScope.data.ULP_0000;
                    window.scrollTo(0, 0);
                    
                });
            }
        }//End of if
        
        
        //On focus event -S
        $scope.onFocusImei = function(){
            $scope.IMEIEntered = $scope.imei;
            $scope.imeiErrorMsg = "";
            $scope.imeiError = false;
            $scope.imeiReqErr = false;
            $scope.imeiLengthErr = false;
            $scope.imeiValidErr = false;
            $scope.blackListIMEIErr = false;

        };
        
        //On keyUp events
        $scope.getIMEIOnKeyEvent = function(keyEvent) {
            //console.log("getIMEIOnKeyEvent function called");
            if($scope.imei != undefined || $scope.imei != ""){
                if($scope.imei.length < 15){
                    $scope.isVaild = false;
                }
            }
        }

	$scope.showTooltip = function(obj){
		   tooltipUtility.show(obj);
	 }
	$scope.hideTooltip = function(obj){
	  tooltipUtility.hide(obj);
	}
        
        //On Blur Events -S
        $scope.getImei = function(){
            //console.log("getImei function called"+$scope.imei);
            $scope.make = "";
            $scope.model = "";
            $rootScope.commonError = false;
            $scope.commonErrorMsgs = "";
            var error8047step3 = false;
            if($scope.imei == undefined || $scope.imei == "" || $scope.imei.length < 15){
                validationImeiNo();
                $scope.isVaild = false;
                $rootScope.imei_usr = $scope.imei;
                // $scope.make = "";
                //$scope.model = "";
            }else{
                $rootScope.imei_usr = $scope.imei;
                //console.log("$scope.IMEIEntered  ==> "+$scope.IMEIEntered + "$scope.imei ==> "+$scope.imei);
                if(($scope.make === "" && $scope.model === "") || 
                   ($scope.IMEIEntered !== "" && $scope.IMEIEntered !== $scope.imei )){
                    
                    
                    openLoader();
                    
                    unlockStep3IMEICheckRequest = {
                        
                        "orderFlowRequestDO": {
                            
                            "attCustomer" : $rootScope.custType,
                            "military" 	  : $rootScope.militaryPersnl,
                            "currentFlow" : "IMEI_VERIFICATION_FLOW",
                            "ctn"		  : $rootScope.attwrlsno_usr,
                            "imei"		  : $scope.imei,
                            "captcha"	  : {
                                                "captchaType":$rootScope.CaptchaType,
                                                "captchaId":$rootScope.challenge,
                                                "captchaResponse":$rootScope.recaptcha_response_field,
                                                "captchaRefId":$rootScope.captchaRefId
                                            },
                            //"ipAddress"	  : myip,
                        	"browserId"	  : browserId
                            
                        }
                         
                    }
                    
                    
                    //Post call to validate screen 3 IMEI data and prefiling make & model or else to show error
					//$http.get("/etc/demo/ULS_8047_error_status")
                    services.postService(url.unlockStepPostURL, unlockStep3IMEICheckRequest)
                    .success(function(jsonrRespData) {

                    	$rootScope.commonError = false;
                        $rootScope.unlockStep3ATTIMEIResp = jsonrRespData;
                        $scope.errorsArray = [];
                        $scope.serverErrorsArray = [];
                        
                        if(jsonrRespData.orderFlowResponseDO.validationErrors !== undefined){

                            var validationErrors = jsonrRespData.orderFlowResponseDO.validationErrors.errorList;
                            
                            $scope.commonErrorMsgs = "";
                            //console.log("****==== "+$scope.errorsArray.length);
                            $.each( validationErrors, function( key, value ) {
                                //console.log("key "+key+" value "+value);
                                
                                if(value.errorCode === undefined){
                                    if(key ==="errorCode" && value == "ULS_8023"){
                                        //console.log("validate imei number");
                                    	$rootScope.commonError = false;
                                        $scope.imeiValidErr = true;
                                        
                                    }
                                    else if(key ==="errorCode" && value == "ULS_8047"){
                                        //console.log("validate imei number");
                                    	$rootScope.commonError = true;
                                        //error8047 = true;
                                        //$scope.errorsArray.push(value);
//                                        $scope.serverErrorsArray.push(validationErrors.errorDescription);
                                    	$rootScope.error = validationErrors.errorDescription;
                                    }
                                    else if(value.substring(0, 4) === "ULF_"){
                                    	$rootScope.commonError = true;
//                                        $scope.serverErrorsArray.push(validationErrors.errorDescription +" (errorCode."+value+")");
                                    	$rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                    }
                                    else{
                                        if(key !=="errorDescription" ){
                                        	$rootScope.commonError = true;
                                            if(value == "ULS_8033" || value == "ULS_8017"){
                                               $scope.blackListIMEIErr = true;
                                            }
//                                            $scope.errorsArray.push(value);
                                            $rootScope.error = $rootScope.data[value];
                                        }
                                    }
                                }else{
                                	$rootScope.commonError = true;
                                    //console.log("errorCode ==>"+value.errorCode);
                                   // console.log("errorCode ==>"+value.errorDescription);
                                    if((value.errorCode).substring(0, 4) === "ULF_"){
//                                        $scope.serverErrorsArray.push(value.errorDescription +" (errorCode."+value.errorCode+")");
                                    	$rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                    }else{
                                    	$rootScope.error = $rootScope.data[value.errorCode];
//                                        $scope.errorsArray.push(value.errorCode);
                                    }

                                }
                            });

                            closeLoader();
                            $scope.make = "";
                            $scope.model = "";
                            window.scrollTo(0, 0);
                            $scope.isVaild = false;
                            
                        }else{
                            $scope.make = jsonrRespData.orderFlowResponseDO.make;
                            $scope.model = jsonrRespData.orderFlowResponseDO.model;
							$rootScope.makeRefId = jsonrRespData.orderFlowResponseDO.makeRefId;
							$rootScope.modelRefId = jsonrRespData.orderFlowResponseDO.modelRefId;
                            $scope.attimeiRefId = jsonrRespData.orderFlowResponseDO.imeiRefId;
                            $scope.isVaild = true;
                            $scope.imeiValidErr = false;

                            setTimeout(function(){
                                closeLoader();
                              focusField("submitbutton");
                            }, 100);


                            
                        }
                        
                    }).error(function(data, status, headers, config) {
                        closeLoader();
                        $scope.isVaild = false;
                        $rootScope.commonError = true;
//                        $scope.errorsArray = [];
//                        $scope.errorsArray.push("ULP_0000");
                        $rootScope.error = $rootScope.data.ULP_0000;
                        window.scrollTo(0, 0);
                        
                    });   
                }  
            }
        };
        
        
       
        
        
        //Back button logic - S
        $scope.unlockStep3_back = function()
        {
            //console.log("step3 back button called => ");
            $location.path('unlockstep2').replace();
        }
        //Back button logic - E
        
        
        //Submit button logic -S
        $scope.unlockStep3 = function()
        {
            //console.log("step3 submit button called => ");
            if($scope.imei == undefined || $scope.imei == ""){
                validationImeiNo();
            }else{
                
                openLoader();
                
                unlockOrderATTSumbitRequest = {
                    
                    "orderFlowRequestDO": {
                        
                        "attCustomer" 			:	$rootScope.custType,
                        "military"	  			:	$rootScope.militaryPersnl,
                        "currentFlow" 			:	"ORDER_SUBMISSION_FLOW",
                        "ctn" 		  			:	$rootScope.attwrlsno_usr,
                        "firstName"   			:	$rootScope.fname_usr,
                        "lastName" 	  			:	$rootScope.lname_usr,
                        "email"		  			:	$rootScope.emailAddress_usr,
                        "captcha"	  			: 	{
                                                            "captchaType":$rootScope.CaptchaType,
                                                            "captchaId":$rootScope.challenge,
                                                            "captchaResponse":$rootScope.recaptcha_response_field,
                                                            "captchaRefId":$rootScope.captchaRefId
                                                     },
                        "imei"		  			:	$scope.imei,
                        "imeiRefId"				:   $scope.attimeiRefId,
                        "make" 		  			:	$scope.make,
                        "model"       			:	$scope.model,
						"makeRefId" 			: $rootScope.makeRefId,
						"modelRefId"			: $rootScope.modelRefId,
                        "accountType" 			:	$rootScope.unlockStep1Resp.orderFlowResponseDO.accountType,
                        "cruCustomer"			: 	$rootScope.unlockStep1Resp.orderFlowResponseDO.accountType === "CRU"? true : false, 
                        "fileUploadUrl"			:	"",
                        //"ipAddress"	  		: 	myip,
                        "langId"	 	  		:	GE5P.ge5p_localLanguage === undefined || GE5P.ge5p_localLanguage.toLowerCase() === "en-us" ? "en_US" : GE5P.ge5p_localLanguage,
                        "browserId"	  			: 	browserId

                    }
                    
                }

                //IE Fix for blank json values send -S
                if($rootScope.ssn_usr !== undefined && $rootScope.ssn_usr !== ""){
                    
                    unlockOrderATTSumbitRequest.orderFlowRequestDO.lastFourSSN = $rootScope.ssn_usr;
                }
                
                if($rootScope.attPass_usr !== undefined && $rootScope.attPass_usr !== ""){
                    
                    unlockOrderATTSumbitRequest.orderFlowRequestDO.passCode = $rootScope.attPass_usr;
                }
                
                if($rootScope.billingName_usr !== undefined && $rootScope.billingName_usr !== ""){
                    
                    unlockOrderATTSumbitRequest.orderFlowRequestDO.businessAccountName = $rootScope.billingName_usr;
                }
                
                if($rootScope.billingNo_usr !== undefined && $rootScope.billingNo_usr !== ""){
                    
                    unlockOrderATTSumbitRequest.orderFlowRequestDO.billingAccountNo = $rootScope.billingNo_usr;
                }
                
                if($rootScope.simno_usr !== undefined && $rootScope.simno_usr !== ""){
                    
                    unlockOrderATTSumbitRequest.orderFlowRequestDO.lastFourDigitSimCard = $rootScope.simno_usr;
                }
                //IE Fix for blank json values send -E
                
                //Post call to validate screen 3 data and submitting the request
				//$http.get('/etc/demo/ULS_8047_error_status.json')
                services.postService(url.unlockStepPostURL, unlockOrderATTSumbitRequest)
                .success(function(jsonrRespData) {

                	$rootScope.commonError = false;
                    $rootScope.unlockSubmitResp = jsonrRespData;
                    $scope.errorsArray = [];
                    $scope.serverErrorsArray = [];
                    
                    if(jsonrRespData.orderFlowResponseDO.validationErrors !== undefined){
                                                
                        var validationErrors = jsonrRespData.orderFlowResponseDO.validationErrors.errorList;
                        if(window.innerWidth < 1024)
						{
							angular.element("#firstPageHeader").hide();
						}
                        $scope.commonErrorMsgs = "";

                        //error ULS_8018 change
                        if(jsonrRespData.orderFlowResponseDO.requestNo !== undefined){
                            $rootScope.requestNumber = jsonrRespData.orderFlowResponseDO.requestNo;
                        }
                        else{
                            $rootScope.requestNumber = "";
                        }

                       // console.log("****==== "+$scope.errorsArray.length);
                        $.each( validationErrors, function( key, value ) {
                            //console.log("key "+key+" value "+value);
                            
                            if(value.errorCode === undefined){
                                if(key ==="errorCode"){
                                    if( value === 'SLE_INVALID_INPUT' || value === 'SLE_System Exception' || value === 'SLE_BACKEND_APP' || value === 'ULS_3001'){
                                        //Do nothing				
                                    }else{
                                        if(value === "ULP_8035" || value === "ULP_8017" || value === "ULP_8036" || value === "ULP_8037"){
                                            $scope.blackListIMEIErr = true;
//                                            $scope.errorsArray.push(value);
                                            $rootScope.error = $rootScope.data[value];
                                        }else if(value.substring(0, 4) === "ULF_"){
                                        	$rootScope.commonError = true;
//                                            $scope.serverErrorsArray.push(validationErrors.errorDescription +" (errorCode."+value+")");
                                        	$rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                        }
                                        else{
                                        	$rootScope.commonError = true;
//                                            $scope.errorsArray.push(value);
                                        	$rootScope.error = $rootScope.data[value];
                                        }

                                    }
                                }
                            }else{
                            	$rootScope.commonError = true;
                                //console.log("errorCode ==>"+value.errorCode);
                                //console.log("errorCode ==>"+value.errorDescription);
                                if((value.errorCode).substring(0, 4) === "ULF_"){
//                                    $scope.serverErrorsArray.push(value.errorDescription +" (errorCode."+value.errorCode+")");
                                	$rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                }else{
                                	$rootScope.error = $rootScope.data[value.errorCode];
//                                    $scope.errorsArray.push(value.errorCode);

                                }
                                
                            }

                        });
                        
                        //closing loader on server error
                        closeLoader();
                        
                        if($scope.errorsArray.length > 0){
                            window.scrollTo(0, 0);
                            $scope.isVaild = false;
                        }else{
                            $location.path('error').replace();
                        }
                        
                    }else{
                        $location.path('thankyou').replace();
                        //closeLoader();
                    }
                    
                }).error(function(data, status, headers, config) {
                    closeLoader();
                    $rootScope.commonError = true;
//                    $scope.errorsArray = [];
//                    $scope.errorsArray.push("ULP_0000");
                    $rootScope.error = $rootScope.data.ULP_0000;
                    window.scrollTo(0, 0);
                    $scope.isVaild = false;
                });
            }
            
            
        }	
        //Submit button logic -E
        

        //check validation for IMEI no
        function validationImeiNo(){
            if($scope.imei == undefined || $scope.imei == ""){
                $scope.imeiReqErr = true;
            }else if($scope.imei.length < 15){
                $scope.imeiLengthErr = true;
            }

        }
        
        
        //Popover tooltip -S
        $("#attIMEITip").tooltip({
            html : true, 
            title: function() {
                
                return $('#popoverATTIMEI').html();
            }
        });
        //Popover tooltip -E
        
        //To smothen the User experience we want the loader till UI gets ready
        closeLoader();

    } else {
        //redirecting user to portal entry page
        //$window.location.href = '/#';
		$location.path('/deviceunlock/#').replace();
    }

}]);
//Unlock Step 3 Controller - E
