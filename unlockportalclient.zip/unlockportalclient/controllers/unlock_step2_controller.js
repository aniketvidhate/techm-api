/**
* @Author 		:- Aniket Vidhate (av0041)   
* Date			:- 12-7-2015
* File name 	:- unlock_step2_controller.js
*/

//Unlock Step 2 Controller - S
unlockPortal.controller('step2Ctrl', ['$scope','$rootScope', '$http', 'services','tooltipUtility', '$sce', '$window', '$location', function($scope,$rootScope, $http, services,tooltipUtility, $sce, $window, $location){
    //To smothen the User experience we want the loader till UI gets ready
    openLoader();
	window.scrollTo(0, 0);

    $scope.isValidEmail = true;
    $scope.isVaild = false;
    $scope.isIRU = true;
    $scope.isGoPhone = false;
    $scope.isCRU = false; 
    $scope.ssnValidErr = false;
    $scope.attemptExceeds = false;
    $scope.countFalseAttemptOfSSN = 0;
    $scope.countFalseAttemptOfPasscode = 0;
    $scope.countFalseAttemptOfBAN = 0;
    $scope.ssnValidationFlag = true;

    $("#newOrderSeparator, #newOrder, #headercru").removeClass("divShow").addClass("divHide");
	angular.element("#firstPageHeader").show();

    //checking cookies while accesing unlock request page
    if (sessionStorage.getItem("hasReadTerms") == 'yes' && sessionStorage.getItem("agreeCheckedBox") == 'yes' 
    && $rootScope.unlockStep1Resp !== undefined && $rootScope.unlockStep1Resp.orderFlowResponseDO.validationErrors === undefined) {
        //user can access unlock request page
        
        $("#allRequired").removeClass("divShow").addClass("divHide");
        $("#someRequired").removeClass("divHide").addClass("divShow");
        
        //To show the values on back button
        if($rootScope.militaryPersnl == true){
            $scope.militaryPersonnel = true;
            //console.log("military_persnlRadioImg is yes");
            $("#non_military_persnlRadioImg").removeClass("radioBtnClickedImg");
            $("#non_military_persnlRadioImg").addClass("radioBtnImg");
            $("#military_persnlRadioImg").removeClass("radioBtnImg");
            $("#military_persnlRadioImg").addClass("radioBtnClickedImg");
        }else if($rootScope.militaryPersnl == false){
            $scope.militaryPersonnel = false;
            //console.log("military_persnlRadioImg is no");
            $("#military_persnlRadioImg").removeClass("radioBtnClickedImg");
            $("#non_military_persnlRadioImg").addClass("radioBtnClickedImg");
        }else{
            $scope.militaryPersonnel = false;
            $("#military_persnlRadioImg").removeClass("radioBtnClickedImg");
            $("#non_military_persnlRadioImg").addClass("radioBtnClickedImg");
        }
        
        if($rootScope.unlockStep1Resp.orderFlowResponseDO !== undefined){
            if($rootScope.unlockStep1Resp.orderFlowResponseDO.accountType !== undefined){
                if($rootScope.unlockStep1Resp.orderFlowResponseDO.accountType === "IRU")
                {
                    $scope.isIRU = true;
                    $scope.isGoPhone = false;
                    $scope.isCRU = false;
                    
                }else if($rootScope.unlockStep1Resp.orderFlowResponseDO.accountType === "GOPHONE")
                {
                    $scope.isIRU = false;
                    $scope.isGoPhone = true;
                    $scope.isCRU = false;
                    
                }else if($rootScope.unlockStep1Resp.orderFlowResponseDO.accountType === "CRU")
                {
                    $scope.isIRU = false;
                    $scope.isGoPhone = false;
                    $scope.isCRU = true;
                    
                }
            }
            
            if($rootScope.unlockStep1Resp.orderFlowResponseDO.ssnValidation !== undefined && $rootScope.unlockStep1Resp.orderFlowResponseDO.ssnValidation == false){
                $scope.ssnValidationFlag = false;
            }
        }
        
        
        if($rootScope.attwrlsno_usr != undefined && $rootScope.fname_usr != undefined && $rootScope.lname_usr != undefined){
            $scope.attwrlsno = $rootScope.attwrlsno_usr;
            $scope.fname = $rootScope.fname_usr;
            $scope.lname = $rootScope.lname_usr;
        }
        
        
        //CRU prefilled - S
        if($rootScope.billingName_usr != undefined && $rootScope.billingName_usr != ""){
            $scope.billingName = $rootScope.billingName_usr;
        }
        
        if($rootScope.billingNo_usr != undefined && $rootScope.billingNo_usr != ""){
            $scope.billingNo = $rootScope.billingNo_usr;
        }
        
        if($rootScope.simno_usr != undefined && $rootScope.simno_usr != ""){
            $scope.simno = $rootScope.simno_usr;
        }
        //CRU prefilled - E
        
        
        if($rootScope.emailAddress_usr != undefined && $rootScope.emailAddress_usr !== ""){
            $scope.emailAddress = $rootScope.emailAddress_usr;
            
            if($scope.emailAddress === undefined || $scope.emailAddress === ""){
                validationEmailAddress(); 
            }else{
                
                $scope.isValidEmail = IsEmail($scope.emailAddress);

                if($scope.isValidEmail === true){
                    $scope.isVaild = true;

                }else{
                    $scope.isVaild = false;
                }
            }
        }
        
        
        
        $scope.fileUploadWindow = function(id){
            //console.log("sdadsadsa");
            $("#fileInputBtn").click();
        }
        
        
        $scope.getMilitaryPers = function(){
            
            //console.log("getMilitaryPers function called"+$scope.militaryPersonnel);
            $rootScope.militaryPersnl = $scope.militaryPersonnel;
            
        };
        
        
        //On focus Events -S
        $scope.onFocusSSNNo = function(){
            //console.log("onFocusSSNNo function called"+$scope.ssn);
            $scope.ssnReqErr = false; 
            $scope.ssnLengthErr = false;
            $scope.ssnServerErr = false; 
            
        };

	$scope.showTooltip = function(obj){
		   tooltipUtility.show(obj);
	 }
	$scope.hideTooltip = function(obj){
	  tooltipUtility.hide(obj);
	}
        
        
        $scope.onFocusEmail = function(){
            //console.log("onFocusSSNNo function called"+$scope.emailAddress);
            $scope.isValidEmail = true; 
            $scope.emailReqErr = false; 
            $scope.secureDoaminErr = false;
            $scope.blackListEmail = false;
            
        };
        
        
        $scope.onFocusPasscode = function(){
            //console.log("onFocusPasscode function called"+$scope.attPass);
            $scope.attPasscodeReqErr = false;      
            $scope.attPasscodeLengthErr = false; 
            $scope.attPasscodeServerErr = false; 
            
        };
        
        
        $scope.onFocusBillingName = function(){
            //console.log("onFocusBillingName function called"+$scope.billingName);
            $scope.billingAcntNameReqErr = false; 
        };
        
        
        $scope.onFocusBillingNo = function(){
            //console.log("onFocusBillingNo function called"+$scope.billingNo);
            $scope.billingAcntNoReqErr = false; 
            $scope.billingAcntNoLengthErr = false;
            $scope.billingAcntNoServerErr = false;
        };
        
        
        $scope.onFocusLastSIM = function(){
            //console.log("onFocusLastSIM function called"+$scope.simno);
            $scope.simReqErr = false;  
            $scope.simLengthErr = false;
            $scope.simServerErr = false;
        };
        //On focus Events -E
        
        
        //On Blur Events -S
        $scope.getEmailAddr = function(){
            //console.log("getEmailAddr function called"+$scope.emailAddress);
            $rootScope.emailAddress_usr = $scope.emailAddress;
            
            
            if($scope.emailAddress === undefined || $scope.emailAddress === ""){
                validationEmailAddress(); 
            }else{
                
                $scope.isValidEmail = IsEmail($scope.emailAddress);
                

                if($scope.isValidEmail === true){
                    //$scope.isVaild = true;
                    isAllDataValid();
                    //setTimeout(function(){
                    /*openLoader();
                    emailFlag = false;
                    var domain = $scope.emailAddress.slice(($scope.emailAddress.indexOf('@')) + 1, $scope.emailAddress.lastIndexOf('.'));
                    
                    emailJson = {
                    "unlockValidateEmailRequest": {
                    "domain": domain
                    }
                    };
                    
                    //Post call to validate email domain is secure or else to show error
                    services.postService(url.emailSecureDomain, emailJson)
                    .success(function(jsonrRespData) {
                    
                    $scope.commonError = false;
                    $rootScope.unlockSecureDomainResp = jsonrRespData;
                    
                    if (jsonrRespData.unlockValidateEmailResponse.serviceStatus.code == 0) {
                    $scope.isSecureDomain = true;
                    closeLoader();
                    
                    
                    }else if (jsonrRespData.unlockValidateEmailResponse.serviceStatus.code == 1 
                    || jsonrRespData.unlockValidateEmailResponse.errordetail !== undefined) {
                    
                    var validationErrors = jsonrRespData.unlockValidateEmailResponse.errordetail;
                    
                    $scope.isSecureDomain = false;
                    $scope.secureDoaminErr = true;
                    closeLoader();
                    $scope.isVaild = false;
                    }
                    
                    isAllDataValid();
                    
                    }).error(function(data, status, headers, config) {
                    closeLoader();
                    $scope.isSecureDomain = false;
                    $scope.commonError = true;
                    $scope.errorsArray = [];
                    $scope.errorsArray.push("ULP_0000");
                    window.scrollTo(0, 0);
                    $scope.isVaild = false;
                    });
                    */
                    // },200)
                }else{
                    $scope.isVaild = false;
                }
            }
        };
        
        
        $scope.getLastSSN = function(){
            //console.log("getLastSSN function called"+ $scope.ssn);
            if($scope.ssn === undefined || $scope.ssn.length < 4){
                validationSSNNo();
            }
            $rootScope.ssn_usr = $scope.ssn;
            isAllDataValid();
        };
        
        
        //CRU validations -S
        $scope.getBillingName = function(){
            //console.log("getBillingName function called"+ $scope.billingName);
            
            validationBillingName();
            
            $rootScope.billingName_usr = $scope.billingName;
            isAllDataValid();
        };
        
        
        $scope.getBillingNo = function(){
            //console.log("getBillingNo function called"+ $scope.billingNo);
            if($scope.billingNo === undefined || $scope.billingNo.length < 4){
                validationBillingNo();
            }
            $rootScope.billingNo_usr = $scope.billingNo;
            isAllDataValid();
        };
        
        
        $scope.getLastSIM = function(){
            //console.log("getLastSIM function called"+ $scope.simno);
            if($scope.simno === undefined || $scope.simno.length < 4){
                validationSIMNo(); 
            }
            $rootScope.simno_usr = $scope.simno;
            isAllDataValid();
        };
        //CRU validations -E
        
        
        $scope.getATTPass = function(){
            //console.log("getATTPass function called"+$scope.attPass);
            /* OG-5018
			if($scope.ssnValidationFlag === false || ($scope.attPass !== undefined 
               && $scope.attPass !== "" && $scope.attPass.length < 4)){ */
			if($scope.attPass !== undefined && $scope.attPass !== "" && $scope.attPass.length < 4){
                validationATTPasscode();
            }else{
				isAllDataValid();
			}
            $rootScope.attPass_usr = $scope.attPass;
        };
        //On Blur Events -E
        
        
        //On keyUp events -S
        $scope.getLastSSNOnKeyEvent = function(keyEvent) {
            
            isAllDataValid();
        }
        
        
        $scope.getEmailAddrOnKeyEvent = function(keyEvent) {

            isAllDataValid();
        }
        
        
        $scope.getATTPasscodeOnKeyEvent = function(keyEvent) {
            
            if($scope.attPass !== undefined && $scope.attPass != ""){
                if(testWhite($scope.attPass) === true){
                    $scope.attPass = "";
                    // }else if($scope.ssnValidationFlag == false){
                }else{
                    isAllDataValid();
                }
            }else{
                isAllDataValid();
            }
        }
        

        $scope.getBillingNameOnKeyEvent = function(keyEvent) {
            $scope.billingAcntNameReqErr = false;
            if($scope.billingName !== undefined && $scope.billingName != ""){
                if(testWhite($scope.billingName) === true){
                    $scope.billingName = "";
                    $scope.billingAcntNameReqErr = true;
                }else{
                    /*if(!isSpecialCharInString($scope.billingName)){
                        isAllDataValid();
                    }else{
                        $scope.billingName = "";
                    }*/
                    isAllDataValid();
                }
            }else{
                isAllDataValid();
            }
        }
        
        
        $scope.getBillingNoOnKeyEvent = function(keyEvent) {
            
            isAllDataValid();
        }
        
        
        $scope.getLastSIMOnKeyEvent = function(keyEvent) {
            
            isAllDataValid();
        }
        //On keyUp events -E
        
        //restricing the user after unsucussfull 3 attempts- S
        $scope.restrictUserToProceed = function() {
            
            $scope.errorsArray.push("ULS_8025");
            $scope.attemptExceeds = true;
            $(".radio-inline").addClass("cursorDisable");
            
            
            if($rootScope.custType !== undefined){
                $rootScope.custType = undefined;
            }
            
            
            if($rootScope.attwrlsno_usr !== undefined){
                $rootScope.attwrlsno_usr = undefined;
            }
            
            
            if($rootScope.fname_usr !== undefined){
                $rootScope.fname_usr = undefined;
            }
            
            
            if($rootScope.lname_usr !== undefined){
                $rootScope.lname_usr = undefined;
            }
            
            
            if($rootScope.imei_nonatt_usr !== undefined){
                $rootScope.imei_nonatt_usr = undefined;
            }
            
            
            if($rootScope.nonAttMake_usr !== undefined){
                $rootScope.nonAttMake_usr = undefined;
            }
            
            
            if($rootScope.nonAttModel_usr !== undefined){
                $rootScope.nonAttModel_usr = undefined;
            }
            
            
            if($rootScope.unlockStep1Resp !== undefined){
                $rootScope.unlockStep1Resp = undefined;
            }
            
            
            if($rootScope.unlockStep1NonATTResp !== undefined){
                $rootScope.unlockStep1NonATTResp = undefined;
            }
            
            
            if($rootScope.unlockStep1NonATTIMEIResp !== undefined){
                $rootScope.unlockStep1NonATTIMEIResp = undefined;
            }
            
            
            if($rootScope.emailAddress_usr !== undefined){
                $rootScope.emailAddress_usr = undefined;
            }
            
            
            if($rootScope.ssn_usr !== undefined){
                $rootScope.ssn_usr = undefined;
            }
            
            
            if($rootScope.attPass_usr !== undefined){
                $rootScope.attPass_usr = undefined;
            }
            
            
            if($rootScope.militaryPersnl !== undefined){
                $rootScope.militaryPersnl = undefined;
            }
            
            
            if($rootScope.billingName_usr !== undefined){
                $rootScope.billingName_usr = undefined;
            }
            
            
            if($rootScope.billingNo_usr !== undefined){
                $rootScope.billingNo_usr = undefined;
            }
            
            
            if($rootScope.simno_usr !== undefined){
                $rootScope.simno_usr = undefined;
            }
            
            
            if($rootScope.unlockSecureDomainResp !== undefined){
                $rootScope.unlockSecureDomainResp = undefined;
            }
            
            
            if($rootScope.unlockStep2Resp !== undefined){
                $rootScope.unlockStep2Resp = undefined;
            }
            
            
            if($rootScope.imei_usr !== undefined){
                $rootScope.imei_usr = undefined;
            }
            
            
            if($rootScope.unlockStep3ATTIMEIResp !== undefined){
                $rootScope.unlockStep3ATTIMEIResp = undefined;
            }
            
            
            if($rootScope.unlockSubmitResp !== undefined){
                $rootScope.unlockSubmitResp = undefined;
            }
            
            
            if($rootScope.nonAttFname_usr !== undefined){
                $rootScope.nonAttFname_usr = undefined;
            }
            
            
            if($rootScope.nonAttLname_usr !== undefined){
                $rootScope.nonAttLname_usr = undefined;
            }
            
            
            if($rootScope.nonAttWirelessNo_usr !== undefined){
                $rootScope.nonAttWirelessNo_usr = undefined;
            }
            
            
            if($rootScope.nonAttEmailAddress_usr !== undefined){
                $rootScope.nonAttEmailAddress_usr = undefined;
            }
            
            
            if($rootScope.unlockSecureNonAttDomainResp !== undefined){
                $rootScope.unlockSecureNonAttDomainResp = undefined;
            }
            
            
            if($rootScope.unlockNonATTSubmitResp !== undefined){
                $rootScope.unlockNonATTSubmitResp = undefined;
            }
            
            
            //setting cookies for user acknowledgement
            if (typeof(Storage) != "undefined") {
                sessionStorage.setItem("hasReadTerms", "no");
                sessionStorage.setItem("agreeCheckedBox", "no");
            }
            
            
            
        }
        //restricing the user after unsucussfull 3 attempts- E
        
        
        //Back button logic
        $scope.unlockStep2_back = function()
        {
            //console.log("step2 back button called => ");
            $location.path('unlockstep1').replace();
        }	
        
        
        //Next button logic
        $scope.unlockStep2 = function()
        {
            //console.log("step2 next button called => ");
            
            $scope.isValidEmail = IsEmail($scope.emailAddress);
            
            if($scope.isIRU === true && $scope.ssnValidationFlag == true && ($scope.ssn === undefined || $scope.ssn === "" || $scope.ssn.length < 4)){
                
                validationSSNNo();
                
            }
			/*OG-5018
			else if($scope.isIRU === true && $scope.ssnValidationFlag == false && ($scope.attPass === undefined || $scope.attPass === "" || $scope.attPass.length < 4)){
			*/
            else if($scope.isIRU === true && $scope.ssnValidationFlag == false && ($scope.attPass !== undefined && $scope.attPass !== "" && $scope.attPass.length > 0 && $scope.attPass.length < 4)){
                validationATTPasscode();
                
            }else if($scope.isCRU === true && ($scope.billingName === undefined || $scope.billingName === "" 
                     || $scope.billingNo === undefined || $scope.billingNo === "" || $scope.billingNo.length < 4 )){
             /*
             	SIM No field is not required as a part of new requirement 22/3/16 
             	|| $scope.simno === undefined || $scope.simno === "" || $scope.simno.length < 4)){ 
             */

                validationBillingName();
                validationBillingNo();
                //validationSIMNo();
                
            }else{
                
                
                $rootScope.emailAddress_usr = $scope.emailAddress;
                $rootScope.ssn_usr = $scope.ssn;
                $rootScope.militaryPersnl =	$scope.militaryPersonnel;
                $rootScope.attPass_usr = $scope.attPass;
                $rootScope.billingName_usr = $scope.billingName;
                $rootScope.billingNo_usr = $scope.billingNo;
                $rootScope.simno_usr = $scope.simno;
                
                /*
                    Note: after clicking on Next button it will first verify the secure domain check and if domain is secure then it will proceed to 3rd screen
                    otherwise it will show secure domain error message & it will prevent the non att order submision
                */

                openLoader();
                //emailFlag = false;
                var domain = $scope.emailAddress.slice(($scope.emailAddress.indexOf('@')) + 1, $scope.emailAddress.lastIndexOf('.'));
                
                emailJson = {
                    "unlockValidateEmailRequest": {
                        "domain": domain
                    }
                };
                
                //Post call to validate email domain is secure or else to show error
				services.postService(url.emailSecureDomain, emailJson)
                .success(function(jsonrRespData) {
                    
                	$rootScope.commonError = false;
                    $rootScope.unlockSecureDomainResp = jsonrRespData;
                    
                    if (jsonrRespData.unlockValidateEmailResponse.serviceStatus.code == 0) {

                        if($scope.isIRU === true){

                            unlockStep2Request = {
                                
                                "orderFlowRequestDO": {
                                    
                                    "attCustomer" 		: $rootScope.custType,
                                    "currentFlow" 		: "USER_INFORMATION_VALIDATION_FLOW",
                                    "military" 		  	: $scope.militaryPersonnel,
                                    "ctn" 			  	: $scope.attwrlsno,
                                    "firstName"   		: $scope.fname,
                                    "lastName"  	  	: $scope.lname,
                                    "email"  	     	: $scope.emailAddress,
									"captcha"	  		: {
															"captchaType":$rootScope.CaptchaType,
															"captchaId":$rootScope.challenge,
															"captchaResponse":$rootScope.recaptcha_response_field,
															"captchaRefId":$rootScope.captchaRefId
														},
                                    //"lastFourSSN" 		: $scope.ssn,
                                    "passCode"			: $scope.attPass,
                                    "accountType" 		: $rootScope.unlockStep1Resp.orderFlowResponseDO.accountType,
                                    "cruCustomer"		: false,
                                    //"ipAddress"	  	: myip,
                                    "langId"	 	    : GE5P.ge5p_localLanguage === undefined || GE5P.ge5p_localLanguage.toLowerCase() === "en-us" ? "en_US" : GE5P.ge5p_localLanguage,
                                    "browserId"	  		: browserId
                                    
                                }
                                
                                
                            }

                            /*
                            	For IRU previously SSN was mandatary field but later AT&T removed SSN feild and passcode became mandatory
                            	$scope.ssnValidationFlag set through karaf property if true then ssn became mandatory. 
                            	if false then feild is hiddedn from UI and Passcode is became madatory in this case.
                                This below condition is kept to run previous functionality as well if in future it needed.
                                we just need to set falg to true from karaf.
                            */

                            if($scope.ssnValidationFlag === true){
                                unlockStep2Request.orderFlowRequestDO.lastFourSSN = $scope.ssn;
                            }
                            
                        }
                        else if($scope.isGoPhone === true){
                            
                            unlockStep2Request = {
                                
                                "orderFlowRequestDO": {
                                    
                                    "attCustomer" 		: $rootScope.custType,
                                    "currentFlow" 		: "USER_INFORMATION_VALIDATION_FLOW",
                                    "military" 		  	: false,
                                    "ctn" 			  	: $scope.attwrlsno,
                                    "firstName"   		: $scope.fname,
                                    "lastName"  	  	: $scope.lname,
                                    "email"  	     	: $scope.emailAddress,
									"captcha"	  		: {
															"captchaType":$rootScope.CaptchaType,
															"captchaId":$rootScope.challenge,
															"captchaResponse":$rootScope.recaptcha_response_field,
															"captchaRefId":$rootScope.captchaRefId
														},
                                    "passCode"			: "",//$scope.attPass,
                                    "accountType" 		: $rootScope.unlockStep1Resp.orderFlowResponseDO.accountType,
                                    "cruCustomer"		: false,
                                    //"ipAddress"	  	: myip,
                                    "langId"	 	    : GE5P.ge5p_localLanguage === undefined || GE5P.ge5p_localLanguage.toLowerCase() === "en-us" ? "en_US" : GE5P.ge5p_localLanguage,
                                    "browserId"	  		: browserId
                                    
                                }
                                
                                
                            }
                            
                            
                        }else if($scope.isCRU === true){
                            
                            unlockStep2Request = {
                                
                                "orderFlowRequestDO": {
                                    
                                    "attCustomer" 			: $rootScope.custType,
                                    "currentFlow" 			: "USER_INFORMATION_VALIDATION_FLOW",
                                    "military" 		  		: $scope.militaryPersonnel,
                                    "ctn" 			  		: $scope.attwrlsno,
                                    "firstName"   			: $scope.fname,
                                    "lastName"  	  		: $scope.lname,
                                    "email"  	     		: $scope.emailAddress,
									"captcha"	  			: {
                                                                "captchaType":$rootScope.CaptchaType,
                                                                "captchaId":$rootScope.challenge,
                                                                "captchaResponse":$rootScope.recaptcha_response_field,
                                                                "captchaRefId":$rootScope.captchaRefId
                                                            },
                                    "businessAccountName" 	: $scope.billingName,
                                    "billingAccountNo"		: $scope.billingNo,
                                    //"lastFourDigitSimCard"	: $scope.simno, //SIM No field is not required as a part of new requirement 22/3/16 
                                    "passCode"				: $scope.attPass,
                                    "accountType" 			: $rootScope.unlockStep1Resp.orderFlowResponseDO.accountType,
                                    "cruCustomer"			: true,
                                    //"ipAddress"	  		: myip,
                                    "langId"	 	        : GE5P.ge5p_localLanguage === undefined || GE5P.ge5p_localLanguage.toLowerCase() === "en-us" ? "en_US" : GE5P.ge5p_localLanguage,
                                    "browserId"	  			: browserId
                                }
                                
                                
                            }
                        }


                        //Post call to validate screen 2 data and decision making
                        //$http.get("/etc/demo/ULS_8047_error_status.json")
                        services.postService(url.unlockStepPostURL, unlockStep2Request)
                        .success(function(jsonrRespData) {
                            
                        	$rootScope.commonError = false;
                            $rootScope.unlockStep2Resp = jsonrRespData;
                          //  $scope.errorsArray = [];
                           // $scope.serverErrorsArray = [];
                            
                            if(jsonrRespData.orderFlowResponseDO.validationErrors !== undefined){
                                
                                var validationErrors = jsonrRespData.orderFlowResponseDO.validationErrors.errorList;
                                if(window.innerWidth < 1024)
								{
									angular.element("#firstPageHeader").hide();
								}
                                $rootScope.commonError = true;
                                $scope.commonErrorMsgs = "";
                                //console.log("****==== "+$scope.errorsArray.length);
                                $.each( validationErrors, function( key, value ) {
                                    //console.log("key "+key+" value "+value);
                                    
                                    if(value.errorCode === undefined){
                                        if(key ==="errorCode"){
                                            
                                            
                                            if(value == "ULS_8003"){
                                                //console.log("validate ssn number");
                                                $scope.countFalseAttemptOfSSN = $scope.countFalseAttemptOfSSN + 1;
                                                $scope.ssn = "";
                                                $scope.attPass = "";
                                                
                                                if($scope.countFalseAttemptOfSSN == 4){
                                                    $scope.restrictUserToProceed();
                                                    
                                                }else{
//                                                    $scope.errorsArray.push(value);
                                                	$rootScope.error = $rootScope.data[value];
                                                    $scope.ssnServerErr = true;
                                                    
                                                }
                                            }
                                            else if(value == "ULS_8019"){
                                                //console.log("validate billing number code");
                                                $scope.countFalseAttemptOfBAN = $scope.countFalseAttemptOfBAN + 1;
                                                $scope.billingNo = "";
                                                $scope.simno = "";
                                                $scope.attPass = "";
                                                
                                                if($scope.countFalseAttemptOfBAN == 4){
                                                    
                                                    $scope.restrictUserToProceed();
                                                }else{
//                                                    $scope.errorsArray.push(value);
                                                	$rootScope.error = $rootScope.data[value];
                                                    $scope.billingAcntNoServerErr = true;
                                                    $scope.simServerErr = true;
                                                }
                                                
                                            }
                                            else if(value == "ULS_8002"){
                                                //console.log("validate pass code");
                                                $scope.countFalseAttemptOfPasscode = $scope.countFalseAttemptOfPasscode + 1;
                                                $scope.ssn = "";
                                                $scope.attPass = "";
                                                
                                                if($scope.countFalseAttemptOfPasscode == 4){
                                                    
                                                    $scope.restrictUserToProceed();
                                                }else{

                                                    //reset passcode link not available for CRU data
                                                    if($scope.isCRU === true){
                                                    	$rootScope.error = $rootScope.data.ULS8002;
//                                                        $scope.errorsArray.push("ULS8002");
                                                        $scope.attPasscodeServerErr = true;
                                                    }
                                                    else{
//                                                        $scope.errorsArray.push(value);
                                                    	$rootScope.error = $rootScope.data[value];
                                                        $scope.attPasscodeServerErr = true;
														if($scope.ssnValidationFlag === false){
															$scope.enableNextButton = true;
														}
                                                    }
                                                    
                                                }
                                            }
                                            else if(value.substring(0, 4) === "ULF_"){
//                                                $scope.serverErrorsArray.push(validationErrors.errorDescription +" (errorCode."+value+")");
                                            	$rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                            }
                                            else{
                                                if(value == "ULS_8034"){
                                                    $scope.blackListEmail = true;
                                                } 
//                                                $scope.errorsArray.push(value);
                                                $rootScope.error = $rootScope.data[value];
                                            }
                                            
                                        }
                                    }else{
                                        
                                        //console.log("errorCode ==>"+value.errorCode);
                                        //console.log("errorCode ==>"+value.errorDescription);
                                        if((value.errorCode).substring(0, 4) === "ULF_"){
//                                            $scope.serverErrorsArray.push(value.errorDescription +" (errorCode."+value.errorCode+")");
                                        	$rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                        }else{
//                                            $scope.errorsArray.push(value.errorCode);
                                        	$rootScope.error = $rootScope.data[value.errorCode];
                                        }

                                    }
                                });
                                
                                closeLoader();
                                window.scrollTo(0, 0);
                                if($scope.ssnValidationFlag === false && $scope.enableNextButton === true && $scope.countFalseAttemptOfPasscode < 4){
                                    $scope.isVaild = true;
                                }else{
                                    $scope.isVaild = false;
                                }
                                
                            }else{
                                $location.path('unlockstep3').replace();
                                //closeLoader();
                            }

                        }).error(function(data, status, headers, config) {
                            closeLoader();
                            $rootScope.commonError = true;
//                            $scope.errorsArray = [];
//                            $scope.errorsArray.push("ULP_0000");
                            $rootScope.error = $rootScope.data.ULP_0000;
                            $scope.isVaild = false;
                            window.scrollTo(0, 0);
                            
                        });
                        
                        
                        
                        
                    }else if (jsonrRespData.unlockValidateEmailResponse.serviceStatus.code == 1 
                              || jsonrRespData.unlockValidateEmailResponse.errordetail !== undefined) {
                        
                        var validationErrors = jsonrRespData.unlockValidateEmailResponse.errordetail;
                        
                        $scope.secureDoaminErr = true;
                        closeLoader();
                        $scope.isVaild = false;
                    }
                    
                    //isAllDataValid();
                    
                }).error(function(data, status, headers, config) {
                    closeLoader();
                    $rootScope.commonError = true;
//                    $scope.errorsArray = [];
//                    $scope.errorsArray.push("ULP_0000");
                    $rootScope.error = $rootScope.data.ULP_0000;
                    window.scrollTo(0, 0);
                    $scope.isVaild = false;
                });

            }
            
        }	
        
        
        //check validation for ssn no
        function validationSSNNo(){
            if($scope.ssn == undefined || $scope.ssn == ""){
                $scope.ssnReqErr = true; 
            }else if($scope.ssn.length < 4){
                $scope.ssnLengthErr = true;
            }
            
        }
        
        function validationATTPasscode(){
            /* OG-5018
			if($scope.ssnValidationFlag === false && ($scope.attPass == undefined || $scope.attPass == "")){
                $scope.attPasscodeReqErr = true; 
                $scope.isVaild = false;
            }else  */
			if($scope.attPass != undefined && $scope.attPass != "" && $scope.attPass.length < 4){
                $scope.attPasscodeLengthErr = true;
                $scope.isVaild = false;
            }
            
        }
        
        
        function validationBillingName(){
            if($scope.billingName == undefined || $scope.billingName == ""){
                $scope.billingAcntNameReqErr = true;
            }
        }
        
        
        function validationBillingNo(){
            if($scope.billingNo == undefined || $scope.billingNo == ""){
                $scope.billingAcntNoReqErr = true;  
            }else if($scope.billingNo.length < 4){
                $scope.billingAcntNoLengthErr = true;
            }
            
        }
        
        
        function validationSIMNo(){
            if($scope.simno == undefined || $scope.simno == ""){
                $scope.simReqErr = true;  
            }else if($scope.simno.length < 4){
                $scope.simLengthErr = true;
            }
            
        }
        
        
        function validationEmailAddress(){
            if($scope.emailAddress == undefined || $scope.emailAddress == ""){
                $scope.emailReqErr = true; 
                $scope.isVaild = false;
            }
            
        }
        
        
        //Enable Next button if required field data is entered
        function isAllDataValid(){
            
            if($scope.emailAddress !== undefined){
                if($scope.emailAddress !== "" && IsEmail($scope.emailAddress)){
                    if($scope.isIRU === true){
                        if($scope.ssnValidationFlag === true && $scope.ssn !== undefined && $scope.ssn !== "" && $scope.ssn.length === 4 ){
                            if($scope.attPass !== undefined && $scope.attPass !== "" && $scope.attPass.length < 4 ){
                                $scope.isVaild = false;
                            }else{
                                $scope.isVaild = true;
                            }
                        }/*OG-5018
						else if($scope.ssnValidationFlag === false && $scope.attPass !== undefined && $scope.attPass !== "" && $scope.attPass.length >= 4 ){
						*/
						else if($scope.ssnValidationFlag === false && (($scope.attPass !== undefined && $scope.attPass !== "" && $scope.attPass.length >= 4) 
                            || ($scope.attPass === undefined || $scope.attPass === "" || $scope.attPass.length === 0))){
                            $scope.isVaild = true;
                        }else{
                            $scope.isVaild = false;
                        }
                        
                    }else if($scope.isGoPhone === true){
                        
                        if($scope.attPass !== undefined && $scope.attPass !== "" && $scope.attPass.length < 4 ){
                            $scope.isVaild = false;
                        }else{
                            $scope.isVaild = true;
                        }
                        
                    }else if($scope.isCRU === true && $scope.billingName !== undefined && $scope.billingName !== "" 
                             && $scope.billingNo !== undefined && $scope.billingNo !== "" && $scope.billingNo.length === 4 ){
                             /*
                             SIM No field is not required as a part of new requirement 22/3/16 
                             && $scope.simno !== undefined && $scope.simno !== "" && $scope.simno.length === 4 ){
                             */

                        if($scope.attPass !== undefined && $scope.attPass !== "" && $scope.attPass.length < 4 ){
                            $scope.isVaild = false;
                        }else{
                            $scope.isVaild = true;
                        }
                        
                    }else{
                        $scope.isVaild = false;
                    }
                }else{
                    $scope.isVaild = false;
                }
            }else{
                $scope.isVaild = false;
            }
            
            //console.log("end isAllDataValid ==> "+$scope.isVaild);
        }
        
        
        //Radio button image toggle on hover in and hover out -S
        $("#military_persnlRadioImg,#non_military_persnlRadioImg").hover(function(){
            if($scope.selectedCustomerErr != true){
                var id = this.id;
                var classes = $("#"+id).attr("class").split(' ');
                $.each(classes, function(i, c) {
                    if (c.indexOf("radioBtnImg") == 0) {
                        $("#"+id).addClass("radioBtnHoverImg");
                    }else if(c.indexOf("radioBtnClickedImg") == 0){
                        $("#"+id).addClass("radioBtnClickedHoverImg");
                    }
                });
                
                
            }
        }, function(){
            //MouseOut event
            if($scope.selectedCustomerErr != true){
                var id = this.id;
                var classes = $("#"+id).attr("class").split(' ');
                $.each(classes, function(i, c) {
                    if (c.indexOf("radioBtnImg") == 0) {
                        $("#"+id).removeClass("radioBtnHoverImg");
                    }else if(c.indexOf("radioBtnClickedImg") == 0){
                        $("#"+id).removeClass("radioBtnClickedHoverImg");
                    }
                });
                
                
            }
        })
        //Radio button image toggle on hover in and hover out -E	
        
        
       
        
        
        //browse file -S
        $("#browseFile").click(function(){
            $("#selectFile").trigger('click');
            $("#selectFile").change(function(){
                //console.log("file : ",$scope.myFile);
                $scope.uploadFile();
            });
        });
        
        var validFormats=['jpeg','jpg','png','pdf','doc','docx'];
        $scope.uploadFile = function(){
            $scope.file = $scope.myFile;
            var ext = $scope.file.name.substring($scope.file.name.lastIndexOf('.') + 1).toLowerCase();   
            var isValid= validFormats.indexOf(ext) !== -1;
            
            if(isValid){
                /* console.log('file is ' );
                console.dir($scope.file);
                console.log("name  : ",$scope.file.name);*/
                
                //file upload table display
                $scope.fileUploadFlag = false;
                
                var uploadUrl = "/fileUpload";
                var fd = new FormData();
                fd.append('file', $scope.file);
                
                //$rootScope.fileUploadUrl = null;
                
                $http.post(uploadUrl, fd, {
                    transformRequest: angular.identity,
                    headers: {'Content-Type': undefined}
                })
                .success(function(){
                    //console.log("success");
                    $scope.fileUploadFlag = true;
                })
                .error(function(){
                    //console.log("error");
                    $scope.fileUploadFlag = true;	
                });
            }
            else{
                //console.log("Please enter a valid format");
                alert("Enter a valid format");
            }
            
        };
        
        
        //delete file function
        $scope.deleteFile = function(){
            $scope.file = "";
            $scope.fileUploadFlag = false;
        };
        
        //browse file -E
        
        //To smothen the User experience we want the loader till UI gets ready
        closeLoader();
        
    } else {
        //redirecting user to portal entry page
        //$window.location.href = '/#';
		$location.path('/deviceunlock/#').replace();
    }
    
}]);
//Unlock Step 2 Controller - E


function customizeWindow(url) {
    window.open("https://www.att.com/"+url, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes,top=70, left=190, width=970, height=460");
}


//Radio button image toggle on clicked -S
function militaryRadioClicked(obj){
    //console.log("militaryRadioClicked fn");

    
    $("#"+obj.id+"RadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
    $("#"+obj.id+"RadioImg").addClass("radioBtnClickedImg");	
    
    if(obj.id == "military_persnl"){
        $("#non_military_persnlRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
        $("#non_military_persnlRadioImg").addClass("radioBtnImg");
        //$("#militaryDiv").removeClass("divHide").addClass("divShow");
    }else if(obj.id == "non_military_persnl"){
        $("#military_persnlRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
        $("#military_persnlRadioImg").addClass("radioBtnImg");
        //$("#militaryDiv").removeClass("divShow").addClass("divHide");
    }
    
};
//Radio button image toggle on clicked -E


unlockPortal.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);