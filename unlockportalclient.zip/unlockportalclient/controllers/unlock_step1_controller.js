 /**
  * @Author 		:- Aniket Vidhate (av0041)   
  * Date			:- 12-7-2015
  * File name 	:- unlock_step1_controller.js
  */
 //Unlock Step 1 Controller - S
 unlockPortal.controller('step1Ctrl', ['$scope', '$rootScope', '$http', 'services','tooltipUtility', '$sce', '$modal', '$window', '$location', function($scope, $rootScope, $http, services,tooltipUtility, $sce, $modal, $window, $location) {
     angular.element("#IRUCRUHeader").hide();
     //To smothen the User experience we want the loader till UI gets ready
     openLoader();

	 /*$scope.getEnglishContent = function() {
		var jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json";
		services.getStatus(jsonURL)
			.success(function(jsonData) {
					$rootScope.data = jsonData.unlockPortalLabelAndErrorObj[0];
			 });
	}*/
	$scope.fetchCookieByName = function(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length,c.length);
        }
    }
    return "";
   }
	$scope.getEnglishContent = function(){
         var jsonURL = '';
        if(typeof GE5P != 'undefined'){
           if(GE5P.ge5p_localLanguage == 'en_US'){
             jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
          }else if(GE5P.ge5p_localLanguage == 'es_US'){
              jsonURL = "/deviceunlock/json/es/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
           }
        }else{
            var valueCookie = $scope.fetchCookieByName('GNSESS');
			var isMobile = window.navigator.userAgent.toLowerCase().indexOf('mobile') != -1 ? true : false;
      if(typeof valueCookie == "string" && typeof valueCookie != 'undefined' && $.trim(valueCookie) != "" && !isMobile){
         var getStoredCookieObj = eval('(' + valueCookie + ')');
         if(getStoredCookieObj.LOCALE == 'en_US'){
            jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
         }else if(getStoredCookieObj.LOCALE == 'es_US'){
            jsonURL = "/deviceunlock/json/es/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
         }else{
             jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish 
         }
      }else{
		    if(localStorage.getItem('userLang') == null || localStorage.getItem('userLang') == undefined){
            jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
			}else if(localStorage.getItem('userLang') == "es"){
				jsonURL = "/deviceunlock/json/es/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
			}else{
				jsonURL = "/deviceunlock/json/en/unlock_portal_label_and_error.json"; //if en-us, then use Eng url, else if es-us then use spanish
			}
       } 
        }
		services.getStatus(jsonURL)
		.success(function(jsonData) {
			$rootScope.data = jsonData.unlockPortalLabelAndErrorObj[0];
			$('#pageheader .title').text($rootScope.data.unlockPortalPageHeaderTitle);
		});
	}
	
	 if($rootScope.data === undefined){
		 $scope.getEnglishContent();
	 }
	

     $scope.isVaild = false;
     $scope.checked = false;
     $scope.isValidIEMI = false;
     $scope.nonAttImeiPresentErr = false;
     $scope.selectedCustomer = true;
     $scope.attWrlsValidServerErr = false;
     $scope.captchaServerErr = false;
     $rootScope.ie8 = false;

     if (isIE() == 8) {
         $rootScope.ie8 = true;
     }

     $rootScope.commonError = false;

     //console.log("ie8 flag"+$rootScope.ie8);

     $("#newOrderSeparator, #newOrder, #headercru").removeClass("divShow").addClass("divHide");

     //checking cookies while accesing unlock request page
     //if (sessionStorage.getItem("hasReadTerms") == 'yes' && sessionStorage.getItem("agreeCheckedBox") == 'yes') {
     //user can access unlock request page



     /*if($rootScope.isReadAndAgreeTermsAndCondition === undefined || $rootScope.isReadAndAgreeTermsAndCondition === false){
     //console.log("Terms & condition has been not agreed trying to access step1");
     window.location = "#/unlock";
     window.scrollTo(0, 0);
     }*/


     //To show the values on back button -S
     if ($rootScope.custType == true) {
         $scope.selectedCustomer = $rootScope.custType;
         $("#notatt_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
         $("#notatt_custRadioImg").addClass("radioBtnImg");
         $("#att_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
         $("#att_custRadioImg").addClass("radioBtnClickedImg");
         $("#attDiv").removeClass("divHide").addClass("divShow");
         $("#nonAttDiv").removeClass("divShow").addClass("divHide");
     } else if ($rootScope.custType == false) {
         $scope.selectedCustomer = $rootScope.custType;
         $("#notatt_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
         $("#notatt_custRadioImg").addClass("radioBtnClickedImg");
         $("#att_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
         $("#att_custRadioImg").addClass("radioBtnImg");
         $("#nonAttDiv").removeClass("divHide").addClass("divShow");
         $("#attDiv").removeClass("divShow").addClass("divHide");
     } else {
         $scope.selectedCustomer = true;
     }


     if ($rootScope.attwrlsno_usr != undefined && $rootScope.fname_usr != undefined && $rootScope.lname_usr != undefined) {
         $scope.attwrlsno = $rootScope.attwrlsno_usr;
         $scope.fname = $rootScope.fname_usr;
         $scope.lname = $rootScope.lname_usr;
     }
     //To show the values on back button -E


     //Non-ATT flow -S
     if ($rootScope.imei_nonatt_usr != undefined) {
         $scope.nonAttImei = $rootScope.imei_nonatt_usr;
         $scope.nonAttMake = $rootScope.nonAttMake_usr;
         $scope.nonAttModel = $rootScope.nonAttModel_usr;
         $scope.isValidIEMI = true;
     }


     //On focus event
     $scope.onFocusImei = function() {
         $scope.nonAttImeiErrorMsgs = "";
         $scope.nonAttImeiError = false;
         $scope.nonAttImeiReqErr = false;
         $scope.nonAttImeiLengthErr = false;
         $scope.nonAttImeiPresentErr = false;
         $scope.nonAttBlackListIMEIErr = false;
     };

	$scope.showTooltip = function(obj){
		   tooltipUtility.show(obj);
	 }
	$scope.hideTooltip = function(obj){
	  tooltipUtility.hide(obj);
	}


     //On Blur Events 
     $scope.getImei = function() {
         //console.log("getImei function called"+$scope.imei);
         //cleanUpfunction();
         $scope.IMEIReqValidaion();

     };

     //On keyUp events -S
     $scope.getImeiOnKeyEvent = function(keyEvent) {
             //console.log("getImeiOnKeyEvent function called");
             if ($scope.nonAttImei != undefined || $scope.nonAttImei != "") {
                 if ($scope.nonAttImei.length < 15) {
                     $scope.isVaild = false;
                 }
             }
         }
         //Non-ATT flow - E


     //Next button Logic goes here-S
     $scope.unlockStep1 = function() {
         $rootScope.commonError = false;
         if ($scope.selectedCustomer == undefined) {
             $scope.selectedCustomerErr = true;
             $("#att_custRadioImg,#notatt_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg");
             $("#att_custRadioImg,#notatt_custRadioImg").addClass("radioBtnErrorImg");

         }



         if ($scope.selectedCustomer == true) { //At&T Flow

             if ($scope.attwrlsno == undefined || $scope.attwrlsno < 10) {
                 validationAttWrlsNo();
             }

             if ($scope.fname == undefined) {
                 validationFirstName();
             }

             if ($scope.lname == undefined) {
                 validationLastName();
             }

             if ($scope.attwrlsno != undefined && $scope.fname != undefined && $scope.lname != undefined && $scope.selectedCustomer != undefined) {
                 /*console.log("Att wireless no => "+$scope.attwrlsno);
                 console.log("first name => "+$scope.fname);
                 console.log("last name => "+$scope.lname);*/

                 $rootScope.custType = $scope.selectedCustomer;
                 $rootScope.attwrlsno_usr = $scope.attwrlsno;
                 $rootScope.fname_usr = $scope.fname;
                 $rootScope.lname_usr = $scope.lname;
                 $rootScope.recaptcha_response_field = $scope.recaptcha_response_field.toLowerCase();
                 openLoader();

                 //console.log("$scope.challenge"+$scope.challenge+ " $scope.CaptchaType"+$scope.CaptchaType);
                 unlockStep1Request = {

                     "orderFlowRequestDO": {
                         "attCustomer": $scope.selectedCustomer,
                         "currentFlow": "ACCOUNT_DETAILS_FLOW",
                         "ctn": $scope.attwrlsno,
                         "firstName": $scope.fname,
                         "lastName": $scope.lname,
                         "captcha": {
                             "captchaType": $rootScope.CaptchaType,
                             "captchaId": $rootScope.challenge,
                             "captchaResponse": $rootScope.recaptcha_response_field,
                             "captchaRefId": $rootScope.captchaRefId
                         },
                         //"ipAddress"	  : myip,
                         "langId": GE5P.ge5p_localLanguage === undefined || GE5P.ge5p_localLanguage.toLowerCase() === "en-us" ? "en_US" : GE5P.ge5p_localLanguage,
                         "browserId": browserId

                     }


                 }



                 //Post call to validate screen 1 AT&T data and decision making
                 //$http.get("/etc/demo/step1response.json")
                 services.postService(url.unlockStepPostURL, unlockStep1Request)
                     .success(function(jsonCapImgData) {

                         $rootScope.commonError = false;
                         $rootScope.unlockStep1Resp = jsonCapImgData;
                         // $scope.errorsArray = [];
                         // $scope.serverErrorsArray = [];

                         if (jsonCapImgData.orderFlowResponseDO.validationErrors !== undefined) {
                             var validationErrors = jsonCapImgData.orderFlowResponseDO.validationErrors.errorList;						
                             $scope.commonErrorMsgs = "";
                             $.each(validationErrors, function(key, value) {
                                 if (value.errorCode === undefined) {
                                     if (key === "errorCode") {
                                         $rootScope.commonError = false;
                                         if (value == "ULP_2004") {
                                             $scope.attWrlsValidServerErr = true;
											 //angular.element("#wirelessNo").focus();
                                         } else {
                                             $rootScope.commonError = true;
                                             if (value === "ULP_1019") {
                                                 $scope.captchaServerErr = true;
                                                 if ($scope.CaptchaType === "image") {
                                                     $rootScope.error = $rootScope.data.ULP_1019;
                                                 } else if ($scope.CaptchaType === "audio") {
                                                     $rootScope.error = $rootScope.data.ULS_8024;
                                                 }
                                             } else if (value === "ULS_8044") {
                                                 $scope.lastNameServerErr = true;
                                                 $rootScope.error = $rootScope.data[value];
                                             } else if (value.substring(0, 4) === "ULF_") {
                                                 $rootScope.commonError = true;
                                                 $rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                             } else {
                                                 $rootScope.error = $rootScope.data[value];
                                             }
                                             window.scrollTo(0, 0);
                                         }
                                     }
                                 } else {
                                     $rootScope.commonError = true;
                                     if ((value.errorCode).substring(0, 4) === "ULF_") {
                                         $rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                     } else {
                                         $rootScope.error = $rootScope.data[value.errorCode];
                                     }

                                     window.scrollTo(0, 0);
                                 }
                                 if(window.innerWidth < 1024)
									{
										angular.element("#firstPageHeader").hide();
									}
                             });


                             closeLoader();
                             //console.log("**** "+$scope.errorsArray.length);


                             if ($scope.CaptchaType === "image") {
                                 // fetch the captcha new image
                                 $scope.callImageCaptcha();
                             } else if ($scope.CaptchaType === "audio") {
                                 // fetch the captcha new audio 
                                 $scope.callAudioCaptcha();
                             }

                             $scope.recaptcha_response_field = "";
                             $scope.isVaild = false;

                             //console.log("**** "+$scope.errorsArray.length);
                         } else {

                             $location.path('unlockstep2').replace();
                             closeLoader();
                         }

                     }).error(function(data, status, headers, config) {
                         closeLoader();
                         $rootScope.commonError = true;
                         $scope.isVaild = false;
                         window.scrollTo(0, 0);
                         if ($scope.CaptchaType === "image") {
                             // fetch the captcha new image
                             $scope.callImageCaptcha();
                         } else if ($scope.CaptchaType === "audio") {
                             // fetch the captcha new audio 
                             $scope.callAudioCaptcha();
                         }
                         $scope.recaptcha_response_field = "";
                         //$scope.errorsArray = [];
                         //$scope.errorsArray.push("ULP_0000");

                         $rootScope.error = $rootScope.data.ULP_0000;

                     });


             }
         } else if ($scope.selectedCustomer == false) { //Non At&T Flow

             if ($scope.nonAttImei == undefined || $scope.nonAttImei == "" || $scope.nonAttImei.length < 15) {
                 validationImeiNo();
             } else {
                 $rootScope.imei_nonatt_usr = $scope.nonAttImei;
                 $rootScope.nonAttMake_usr = $scope.nonAttMake;
                 $rootScope.nonAttModel_usr = $scope.nonAttModel;
                 $rootScope.recaptcha_response_field = $scope.recaptcha_response_field.toLowerCase();
                 openLoader();

                 unlockStep1NonAttRequest = {

                     "orderFlowRequestDO": {
                         "attCustomer": $scope.selectedCustomer,
                         "currentFlow": "NON_ATT_ORDER_VALIDATION_FLOW",
                         "imei": $scope.nonAttImei,
                         "make": $scope.nonAttMake,
                         "model": $scope.nonAttModel,
						 "imeiRefId": $rootScope.imeiRefId,
						 "makeRefId" : $rootScope.makeRefId,
						 "modelRefId": $rootScope.modelRefId,
                         "captcha": {
                             "captchaType": $rootScope.CaptchaType,
                             "captchaId": $rootScope.challenge,
                             "captchaResponse": $rootScope.recaptcha_response_field,
                             "captchaRefId": $rootScope.captchaRefId
                         },
                         //"ipAddress"	  : myip,
                         "langId": GE5P.ge5p_localLanguage === undefined || GE5P.ge5p_localLanguage.toLowerCase() === "en-us" ? "en_US" : GE5P.ge5p_localLanguage,
                         "browserId": browserId

                     }


                 }


                 //console.log("unlockStep1NonAttRequest "+unlockStep1NonAttRequest);
                 //Post call to validate screen 1 non AT&T data and decision making
                 services.postService(url.unlockStepPostURL, unlockStep1NonAttRequest)
                     .success(function(jsonCapImgData) {

                         $rootScope.commonError = false;
                         $rootScope.unlockStep1NonATTResp = jsonCapImgData;
                         //$scope.errorsArray = [];
                         //$scope.serverErrorsArray = [];

                         if (jsonCapImgData.orderFlowResponseDO.validationErrors !== undefined) {

                             var validationErrors = jsonCapImgData.orderFlowResponseDO.validationErrors.errorList;
							 if(window.innerWidth < 1024)
							{
								angular.element("#firstPageHeader").hide();
							}
                             $scope.commonErrorMsgs = "";
                             //console.log("****==== "+$scope.errorsArray.length);
                             $.each(validationErrors, function(key, value) {
                                 //console.log("key "+key+" value "+value);

                                 if (value.errorCode === undefined) {
                                     if (key === "errorCode") {
                                         $rootScope.commonError = false;

                                         if (value == "ULS_8023") {
                                             //console.log("validate imei number");
                                             $scope.nonAttImeiPresentErr = true;

                                         } else {
                                             if (value === "ULP_1019") {
                                                 $scope.captchaServerErr = true;
                                                 $rootScope.commonError = true;
                                                 if ($scope.CaptchaType === "image") {
                                                     $rootScope.error = $rootScope.data.ULP_1019;
                                                 } else if ($scope.CaptchaType === "audio") {
                                                     $rootScope.error = $rootScope.data.ULS_8024;
                                                 }
                                                 window.scrollTo(0, 0);
                                             } else if (value === "ULP_8035" || value === "ULP_8017" || value === "ULP_8036" || value === "ULP_8037") {
                                                 $scope.nonAttBlackListIMEIErr = true;
                                                 $rootScope.error = $rootScope.data[value];
                                             } else if (value.substring(0, 4) === "ULF_") {
                                                 $rootScope.commonError = true;
                                                 $rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                                 window.scrollTo(0, 0);
                                             } else {
                                                 $rootScope.commonError = true;
                                                 $rootScope.error = $rootScope.data[value];
                                                 window.scrollTo(0, 0);
                                             }


                                         }
                                     }
                                 } else {
                                     $rootScope.commonError = true;
                                     // console.log("errorCode ==>"+value.errorCode);
                                     //console.log("errorCode ==>"+value.errorDescription);
                                     if ((value.errorCode).substring(0, 4) === "ULF_") {
                                         $rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                     } else {
                                         $rootScope.error = $rootScope.data[value.errorCode];
                                     }

                                 }
                             });

                             closeLoader();
                             //console.log("**** "+$scope.errorsArray.length);
                             window.scrollTo(0, 0);

                             if ($scope.CaptchaType === "image") {
                                 // fetch the captcha new image
                                 $scope.callImageCaptcha();
                             } else if ($scope.CaptchaType === "audio") {
                                 // fetch the captcha new audio 
                                 $scope.callAudioCaptcha();
                             }
                             $scope.recaptcha_response_field = "";
                             $scope.isVaild = false;
                             //console.log("**** "+$scope.errorsArray.length);
                         } else {

                             $location.path('nonattunlock').replace();
                             //closeLoader();
                         }

                     }).error(function(data, status, headers, config) {
                         closeLoader();
                         $rootScope.commonError = true;
                         $scope.isVaild = false;
                         window.scrollTo(0, 0);
                         if ($scope.CaptchaType === "image") {
                             // fetch the captcha new image
                             $scope.callImageCaptcha();
                         } else if ($scope.CaptchaType === "audio") {
                             // fetch the captcha new audio 
                             $scope.callAudioCaptcha();
                         }
                         $scope.recaptcha_response_field = "";
                         //                         $scope.errorsArray = [];
                         //                         $scope.errorsArray.push("ULP_0000");
                         $rootScope.error = $rootScope.data.ULP_0000;

                     });
             }
         }

     };
     //Next button Logic goes here-E


     //Back button Logic -S
     $scope.unlockStep1_back = function() {
         //console.log("unlockStep1_back called");
         //window.location = "/deviceunlock/#";
    	 $location.path('/deviceunlock/#').replace();
         //window.scrollTo(0, 0);
     };
     //Back button Logic -E


     


     //IMEI request validation check -S
     $scope.IMEIReqValidaion = function() {
         $scope.nonAttMake = "";
         $scope.nonAttModel = "";
         $rootScope.commonError = false;
         $scope.commonErrorMsgs = "";

         if ($scope.nonAttImei == undefined || $scope.nonAttImei == "" || $scope.nonAttImei.length < 15) {
             validationImeiNo();
             //$scope.nonAttMake = "";
             // $scope.nonAttModel = "";
             $scope.isValidIEMI = false;
             isAllDataValid();
         } else {
             $rootScope.imei_nonatt_usr = $scope.nonAttImei;

             //console.log("$scope.IMEIEntered  ==> "+$scope.IMEIEntered + "$scope.nonAttImei ==> "+$scope.nonAttImei);

             if (($scope.nonAttMake === "" && $scope.nonAttModel === "") ||
                 ($scope.IMEIEntered !== "" && $scope.IMEIEntered !== $scope.nonAttImei)) {
                 openLoader();


                 unlockStep1IMEICheckRequest = {

                     "orderFlowRequestDO": {

                         "attCustomer": $scope.selectedCustomer,
                         "military": false,
                         "currentFlow": "IMEI_VERIFICATION_FLOW",
                         "ctn": "",
                         "imei": $scope.nonAttImei,
                         "captcha": {
                             "captchaType": $rootScope.CaptchaType,
                             "captchaId": $rootScope.challenge,
                             "captchaResponse": $rootScope.recaptcha_response_field,
                             "captchaRefId": $rootScope.captchaRefId
                         },
                         //"ipAddress"   : myip,
                         "browserId": browserId
                     }

                 }

                 //Post call to validate screen 1 Non Att IMEI data and prefiling make & model or else to show error
                 //$http.get("/etc/demo/ULS_8047_error_status.json")
                 services.postService(url.unlockStepPostURL, unlockStep1IMEICheckRequest)
                     .success(function(jsonrRespData) {

                         $rootScope.commonError = false;
                         $rootScope.unlockStep1NonATTIMEIResp = jsonrRespData;
                         // $scope.errorsArray = [];
                         //$scope.serverErrorsArray = [];

                         if (jsonrRespData.orderFlowResponseDO.validationErrors !== undefined) {

                             var validationErrors = jsonrRespData.orderFlowResponseDO.validationErrors.errorList;


                             $scope.commonErrorMsgs = "";
                             //console.log("****==== "+$scope.errorsArray.length);
                             $.each(validationErrors, function(key, value) {
                                 //console.log("key "+key+" value "+value);

                                 if (value.errorCode === undefined) {
                                     if (key === "errorCode" && value == "ULS_8023") {
                                         //console.log("validate imei number");
                                         $rootScope.commonError = false;
                                         $scope.nonAttImeiPresentErr = true;

                                     } else if (key === "errorCode" && value == "ULS_8047") {
                                         //console.log("validate imei number");
                                         $rootScope.commonError = true;
                                         //error8047 = true;
                                         //$scope.errorsArray.push(value);
                                         $rootScope.error = validationErrors.errorDescription;
                                         //$scope.serverErrorsArray.push(validationErrors.errorDescription);
                                     } else {
                                         if (key !== "errorDescription") {
                                             $rootScope.commonError = true;
                                             if (value == "ULS_8033" || value == "ULS_8017") {
                                                 $scope.nonAttBlackListIMEIErr = true;
                                             }
                                             //$scope.errorsArray.push(value);
                                             $rootScope.error = $rootScope.data[value];
                                         }
                                     }


                                 } else {
                                     $rootScope.commonError = true;
                                     //console.log("errorCode ==>"+value.errorCode);
                                     //console.log("errorCode ==>"+value.errorDescription);
                                     if ((value.errorCode).substring(0, 4) === "ULF_") {
                                         $rootScope.error = $rootScope.error + (validationErrors.errorDescription + " (errorCode." + value + ") ");
                                     } else {
                                         $rootScope.error = $rootScope.data[value.errorCode];
                                     }

                                 }
                             });


                             window.scrollTo(0, 0);
                             $scope.isVaild = false;
                             $scope.isValidIEMI = false;

                         } else {
                             $scope.nonAttMake = jsonrRespData.orderFlowResponseDO.make;
                             $scope.nonAttModel = jsonrRespData.orderFlowResponseDO.model;
                             $scope.IMEIEntered = $scope.nonAttImei;
                             $rootScope.imeiRefId = jsonrRespData.orderFlowResponseDO.imeiRefId;
							 $rootScope.makeRefId = jsonrRespData.orderFlowResponseDO.makeRefId;
							 $rootScope.modelRefId = jsonrRespData.orderFlowResponseDO.modelRefId;
                             $scope.isValidIEMI = true;
                             $scope.nonAttImeiPresentErr = false;
                             isAllDataValid();
                         }
                         closeLoader();
                     }).error(function(data, status, headers, config) {
                         closeLoader();
                         $scope.isVaild = false;
                         $scope.isValidIEMI = false;
                         $rootScope.commonError = true;
                         //                         $scope.errorsArray = [];
                         //                         $scope.errorsArray.push("ULP_0000");
                         $rootScope.error = $rootScope.data.ULP_0000;
                     });

             }
         }
     };


     $scope.customerType = function() {

         //console.log("customerType function called"+$scope.selectedCustomer);
         $rootScope.custType = $scope.selectedCustomer;
         $scope.selectedCustomerErr = false;

         isAllDataValid();
     };


     //On focus event -S
     $scope.onFocusAttWrlsNo = function() {
         //var attWrlsNo = angular.copy($scope.attwrlsno);
         $scope.attWrlsNoReqErr = false;
         $scope.attWrlsLengthWErr = false;
         $scope.attWrlsValidErr = false;
         $scope.attWrlsValidServerErr = false;
     };


     $scope.onFocusFirstName = function() {
         $scope.firstNameReqErr = false;
     };


     $scope.onFocusLastName = function() {
         $scope.lastNameReqErr = false;
         $scope.lastNameServerErr = false;
     };


     $scope.onFocusCaptchaText = function() {
         $scope.captchaReqErr = false;
         $scope.captchaServerErr = false;
     };
     //On focus event -E


     //On Blur Events -S
     $scope.getAttWrlsNo = function() {
         //console.log("$scope.attwrlsno  "+$scope.attwrlsno + "  "+$rootScope.attwrlsno_usr);
         //cleanUpfunction();
         validationAttWrlsNo();
         isAllDataValid();

     };


     $scope.getFirstName = function() {
         //console.log("getFirstName function called"+ $scope.fname + "  "+ $rootScope.fname_usr);
         //$rootScope.fname_usr = $scope.fname;
         validationFirstName();
         isAllDataValid();
     };


     $scope.getLastName = function() {
         //console.log("getLastName function called"+ $scope.lname + "   "+$rootScope.lname_usr);
         //$rootScope.lname_usr = $scope.lname;

         validationLastName();
         isAllDataValid();
     };


     $scope.getCaptchaText = function() {
         //console.log("getCaptchaText function called"+ $scope.recaptcha_response_field);
         if ($scope.recaptcha_response_field === undefined || $scope.recaptcha_response_field === "") {
             $scope.captchaReqErr = true;
         } else {
             isAllDataValid();
         }

     };
     //On Blur Events -E


     //On keyUp events -S
     $scope.getCaptchaTxtOnKeyEvent = function(keyEvent) {
         //console.log("getCaptchaTxtOnKeyEvent function called");
         isAllDataValid();
     }


     $scope.getAttWrlsNoOnKeyEvent = function(keyEvent) {
         //console.log("getAttWrlsNoOnKeyEvent function called");
         //console.log(keyEvent);
         if ($scope.attwrlsno !== undefined && $scope.attwrlsno != "") {
             if (testWhite($scope.attwrlsno) === true) {
                 $scope.attwrlsno = "";
                 $scope.attWrlsNoReqErr = true;

             } else {
                 if (isValidWrlsNo($scope.attwrlsno)) {
                     isAllDataValid();
                 } else {
                     $scope.attwrlsno = "";

                 }
             }
         } else {
             isAllDataValid();
         }
     }


     $scope.getFirstNameOnKeyEvent = function(keyEvent) {
         //console.log("getFirstNameOnKeyEvent function called"+keyEvent);
         $scope.firstNameReqErr = false;
         //console.log("$scope.fname white space "+$scope.fname+"   ==>   "+testWhite($scope.fname));
         if ($scope.fname !== undefined && $scope.fname != "") {
             if (testWhite($scope.fname) === true) {
                 $scope.fname = "";
                 $scope.firstNameReqErr = true;

             } else {
                 if (!isSpecialCharInString($scope.fname)) {
                     isAllDataValid();
                 } else {
                     $scope.fname = "";

                 }
             }
         } else {
             isAllDataValid();
         }
     }


     $scope.getLastNameOnKeyEvent = function(keyEvent) {
             //console.log("getLastNameOnKeyEvent function called");
             //console.log("$scope.lname white space "+$scope.lname+"   ==>   "+testWhite($scope.lname));
             $scope.lastNameReqErr = false;
             if ($scope.lname !== undefined && $scope.lname != "") {
                 if (testWhite($scope.lname) === true) {
                     $scope.lname = "";
                     $scope.lastNameReqErr = true;
                 } else {
                     //Removing special charater from last name as per business requirement 10/5/2016
                     /*if(!isSpecialCharInString($scope.lname)){
                         isAllDataValid();
                     }else{
                         $scope.lname = "";
                     }*/
                     isAllDataValid();
                 }
             } else {
                 isAllDataValid();
             }
         }
         //On keyUp events -E


     $scope.focusRadio = function(id) {
         $("#" + id).attr('checked', true);
         $scope.selectedCustomer = true;
         $rootScope.custType = $scope.selectedCustomer;
         $("#att_custRadioImg").removeClass("radioBtnImg").addClass("radioBtnClickedImg");
         $("#attDiv").removeClass("divHide").addClass("divShow");
         $("#nonAttDiv").removeClass("divShow").addClass("divHide");
         $("#notatt_custRadioImg").removeClass("radioBtnClickedImg").addClass("radioBtnImg");
     }

     $scope.$watch("checked", function() {
         isAllDataValid();
         if ($scope.checked) {
             sessionStorage.setItem("hasReadTerms", "yes");
             sessionStorage.setItem("agreeCheckedBox", "yes");
         } else {
             sessionStorage.removeItem("hasReadTerms");
             sessionStorage.removeItem("agreeCheckedBox");
         }
     });

     //Enable Next button if required feild data is entered
     function isAllDataValid() {
         //console.log("isAllDataValid ==> "+$scope.recaptcha_challenge_field);
         if ($scope.selectedCustomer === true) {
             if ($scope.attwrlsno !== undefined && $scope.fname !== undefined &&
                 $scope.lname !== undefined && $scope.recaptcha_response_field !== undefined && $scope.checked) {
                 if ($scope.attwrlsno !== "" && $scope.attwrlsno.length === 10 && $scope.attWrlsValidServerErr === false &&
                     $scope.fname !== "" && $scope.lname !== "" && $scope.recaptcha_response_field !== "" && $scope.checked) {
                     $scope.isVaild = true;
                 } else {
                     $scope.isVaild = false;
                 }
             } else {

                 $scope.isVaild = false;
             }
         } else {
             if ($scope.recaptcha_response_field !== undefined && $scope.recaptcha_response_field !== "" && $scope.isValidIEMI === true && $scope.checked) {
                 $scope.isVaild = true;
             } else {
                 $scope.isVaild = false;
             }

         }
         //console.log("end isAllDataValid ==> "+$scope.isVaild);
     }


     //check validation for att wireless no
     function validationAttWrlsNo() {
         if ($scope.attwrlsno == undefined || $scope.attwrlsno == "") {
             $scope.attWrlsNoReqErr = true;
         } else if ($scope.attwrlsno.length < 10) {
             $scope.attWrlsLengthWErr = true;
         }

     }


     //check validation for first name
     function validationFirstName() {
         if ($scope.fname == undefined || $scope.fname == "") {
             $scope.firstNameReqErr = true;
         }
     }


     //check validation for last name
     function validationLastName() {
         if ($scope.lname == undefined || $scope.lname == "") {
             $scope.lastNameReqErr = true;
         }
     }



     //Captcha Code -S



     imageCaptchaJson = {
         "imageCaptchaRequest": {
             "captchaType": "image"
         }
     };


     // function to call the Image Captcha API
     $scope.callImageCaptcha = function() {
         $scope.capDisable = true;
         $scope.rePlay = false;
         $rootScope.CaptchaType = "image";

         if ($rootScope.recaptcha_response_field !== undefined) {
             $rootScope.recaptcha_response_field = undefined;
         }

         openLoader();
         services.postService(url.imageCaptchaImage, imageCaptchaJson)
             .success(function(jsonCapImgData) {
                 if (jsonCapImgData.imageCaptchaResponse.serviceStatus.code == 0) {
                     $rootScope.capImg = 'data:image/jpeg;base64,' + jsonCapImgData.imageCaptchaResponse.captchaDetail.captchaChallenge;
                     $rootScope.challenge = jsonCapImgData.imageCaptchaResponse.captchaDetail.captchaID;
                     $rootScope.captchaRefId = jsonCapImgData.imageCaptchaResponse.captchaDetail.captchaRefId;
                     $("#recaptcha_challenge_image").attr("src", "data:image/jpeg;base64," + jsonCapImgData.imageCaptchaResponse.captchaDetail.captchaChallenge);
                     $scope.capRequired = true;
                 } else {
                     $scope.capRequired = false;
                 }
                 $scope.capDisable = false;
                 if ($scope.capToggleClicked) {
                     $scope.capToggleClicked = false;
                     jQuery(document.getElementById("recaptcha_reload_btn")).focus();
                 }
                 closeLoader();
             }).error(function(data, status, headers, config) {
                 $scope.capDisable = false;
                 $scope.capRequired = false;
                 $rootScope.commonError = true;
                 window.scrollTo(0, 0);
                 //                 $scope.errorsArray = [];
                 //                 $scope.errorsArray.push("ULP_0000");
                 $rootScope.error = $rootScope.data.ULP_0000;
                 closeLoader();
                 $scope.isVaild = false;

             });
     }


     audioCaptchaJson = {
         "audioCaptchaRequest": {
             "captchaType": "audio"
         }
     };


     // function to call the Audio Captcha API
     $scope.callAudioCaptcha = function() {
         $scope.capDisable = true;
         $scope.rePlay = true;
         $rootScope.CaptchaType = "audio";
         $scope.tokenVal = document.getElementById("tokenID").value;

         if ($rootScope.recaptcha_response_field !== undefined) {
             $rootScope.recaptcha_response_field = undefined;
         }

         //$scope.tokenVal = "";
         openLoader();

         services.postService(url.audioCaptchaImage, audioCaptchaJson)
             .success(function(jsonCapAudData) {

                 $scope.capImg = "";

                 if (jsonCapAudData.audioCaptchaResponse.serviceStatus.code == 0) {
                     $rootScope.challenge = jsonCapAudData.audioCaptchaResponse.captchaDetail.captchaID;
                     $rootScope.captchaRefId = jsonCapAudData.audioCaptchaResponse.captchaDetail.captchaRefId;
                     // GET CALL for AudioCaptcha

                     /*if (testIE!=undefined && testIE){
                         //$scope.audio.src = "";
                         //$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal; 
                         //$scope.tokenVal = document.getElementById("tokenID").value ;
                         var audioUrl = "http:" + "//" + window.location.hostname + unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal;
                         window.location.assign(audioUrl);
                         //$scope.audio.src = "https://tst31.stage.att.com/apis/deviceunlock/unlockCaptcha/sound" + "/" + $scope.challenge;
                         //$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge+"?OWASP_CSRFTOKEN="+$scope.tokenVal;
                         //$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + '?random=' + new Date().getTime();
                         //document.all.sound.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge;
                         
                     } else { */
                     $scope.audio.src = "data:audio/wav;base64," + jsonCapAudData.audioCaptchaResponse.captchaDetail.captchaChallenge;
                     $scope.audio.play();
                     //}

                     $scope.apiError = false;
                     $scope.capRequired = true;
                 } else {
                     $scope.capRequired = false;
                 }
                 $scope.capDisable = false;
                 if ($scope.capToggleClicked) {
                     $scope.capToggleClicked = false;
                     jQuery(document.getElementById("recaptcha_reload_btn")).focus();
                 }
                 closeLoader();
             }).error(function(data, status, headers, config) {
                 $scope.capDisable = false;
                 $scope.capRequired = false;
                 $rootScope.commonError = true;
                 closeLoader();
                 //                 $scope.errorsArray = [];
                 //                 $scope.errorsArray.push("ULP_0000");
                 $rootScope.error = $rootScope.data.ULP_0000;
                 window.scrollTo(0, 0);
                 $scope.isVaild = false;
             });
     }


     $scope.rePlayFunc = function() {
         /* if (testIE!=undefined && testIE){
              //$scope.audio.src = $sce.trustAsResourceUrl(unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge);
              //$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal;
              var audioUrl = "http:" + "//" + window.location.hostname + unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal;
              window.location.assign(audioUrl);
          } else {*/
         $scope.audio.play();
         // }
     }


     // toggle between audio and image captcha on clik of button
     $scope.capToggle = function(capToggleVar) {
         $scope.capToggleClicked = true;
         if (!$scope.capDisable) //to disable toggling untill response for first call has not been received
         {
             $scope.recaptcha_response_field = "";
             if (capToggleVar == "audio") {
                 $("#recaptcha_switch_audio_btn").removeClass("capToggleAudio").addClass("capToggleClass");
                 $("#recaptcha_switch_img_btn").removeClass("capToggleClass").addClass("capToggleVisual");
                 $scope.capToggleAudio = true;
                 $scope.capToggleVisual = false;
                 $scope.callAudioCaptcha();


             } else {
                 $("#recaptcha_switch_img_btn").removeClass("capToggleVisual").addClass("capToggleClass");
                 $("#recaptcha_switch_audio_btn").removeClass("capToggleClass").addClass("capToggleAudio");
                 /*if (testIE!=undefined && testIE){
                     //$scope.audio.src = "";
                 } else {*/
                 $scope.audio.pause();
                 // }
                 $scope.capToggleAudio = false;
                 $scope.capToggleVisual = true;
                 $scope.callImageCaptcha();
                 $scope.audioToggle = false;
                 //reCaptchaPlayAgain					
             }
         }
     }


     // refresh audio or image captcha on click of refresh button based on the user's current choice 
     $scope.capRefresh = function() {
         if (!$scope.capDisable) //to disable toggling untill response for first call has not been received
         {
             $scope.recaptcha_response_field = "";
             if ($scope.capToggleAudio) {
                 //if (navigator.appName == "Microsoft Internet Explorer") {
                 /*if (testIE!=undefined && testIE){
                     //$scope.audio.src = "";
                 } else {*/
                 $scope.audio.pause();
                 // }
                 $scope.callAudioCaptcha();
             } else {
                 $scope.callImageCaptcha();
             }
         }
     }


     // fetch the captcha image onLoad of page
     $scope.callImageCaptcha();


     /*if (testIE!=undefined && testIE){
         //$scope.audio = document.getElementById("bgSoundFrame");
     }else{*/
     $scope.audio = document.createElement('audio');
     $scope.audio.src = '';
     // }


     // function to set required property of textfields dynamically on the basis of radiobutton selected
     $scope.req = function(fld) {

             if ($scope.radio == null || $scope.radio == "") {
                 return false;
             }
         }
         //Captcha code -E

     //Tooltip Code



     //Radio button image toggle on hover in and hover out -S
     $("#att_custRadioImg,#notatt_custRadioImg").hover(function() {
             if ($scope.selectedCustomerErr != true) {
                 var id = this.id;
                 var classes = $("#" + id).attr("class").split(' ');
                 $.each(classes, function(i, c) {
                     if (c.indexOf("radioBtnImg") == 0) {
                         $("#" + id).addClass("radioBtnHoverImg");
                     } else if (c.indexOf("radioBtnClickedImg") == 0) {
                         $("#" + id).addClass("radioBtnClickedHoverImg");
                     }
                 });


             }
         }, function() {
             //MouseOut event
             if ($scope.selectedCustomerErr != true) {
                 var id = this.id;
                 var classes = $("#" + id).attr("class").split(' ');
                 $.each(classes, function(i, c) {
                     if (c.indexOf("radioBtnImg") == 0) {
                         $("#" + id).removeClass("radioBtnHoverImg");
                     } else if (c.indexOf("radioBtnClickedImg") == 0) {
                         $("#" + id).removeClass("radioBtnClickedHoverImg");
                     }
                 });


             }
         })
         //Radio button image toggle on hover in and hover out -E


     //check validation for IMEI no -S
     function validationImeiNo() {


         if ($scope.nonAttImei == undefined || $scope.nonAttImei == "") {
             $scope.nonAttImeiReqErr = true;
             $scope.nonAttImei = "";
         } else if ($scope.nonAttImei.length < 15) {
             $scope.nonAttImeiLengthErr = true;
         }

     }
     //check validation for IMEI no -E

     /*} else {
         //redirecting user to portal entry page
         $window.location.href = '/deviceunlock/#/';
     }*/


     var cleanUpfunction = function() {

         //clearing scope variables on first page
         if ($scope.fname !== undefined) {
             $scope.fname = undefined;
         }
         if ($scope.lname !== undefined) {
             $scope.lname = undefined;
         }

         //clearing imei and ctn for att and nonatt cust
         if ($rootScope.custType == true) {
             $scope.nonAttImei = undefined;
             $scope.nonAttMake = undefined;
             $scope.nonAttModel = undefined;
         } else if ($rootScope.custType == false) {
             $scope.attwrlsno = undefined;
             $scope.fname = undefined;
             $scope.lname = undefined;
         }

         //Clearing out all rootscope variables -S
         /*if($rootScope.custType !== undefined){
         $rootScope.custType = undefined;
         }*/


         if ($rootScope.attwrlsno_usr !== undefined) {
             $rootScope.attwrlsno_usr = undefined;
         }


         if ($rootScope.fname_usr !== undefined) {
             $rootScope.fname_usr = undefined;
         }


         if ($rootScope.lname_usr !== undefined) {
             $rootScope.lname_usr = undefined;
         }


         if ($rootScope.imei_nonatt_usr !== undefined) {
             $rootScope.imei_nonatt_usr = undefined;
         }


         if ($rootScope.nonAttMake_usr !== undefined) {
             $rootScope.nonAttMake_usr = undefined;
         }


         if ($rootScope.nonAttModel_usr !== undefined) {
             $rootScope.nonAttModel_usr = undefined;
         }

         if ($rootScope.recaptcha_response_field !== undefined) {
             $rootScope.recaptcha_response_field = undefined;
         }

         if ($rootScope.unlockStep1Resp !== undefined) {
             $rootScope.unlockStep1Resp = undefined;
         }


         if ($rootScope.unlockStep1NonATTResp !== undefined) {
             $rootScope.unlockStep1NonATTResp = undefined;
         }


         if ($rootScope.unlockStep1NonATTIMEIResp !== undefined) {
             $rootScope.unlockStep1NonATTIMEIResp = undefined;
         }


         if ($rootScope.emailAddress_usr !== undefined) {
             $rootScope.emailAddress_usr = undefined;
         }


         if ($rootScope.ssn_usr !== undefined) {
             $rootScope.ssn_usr = undefined;
         }


         if ($rootScope.attPass_usr !== undefined) {
             $rootScope.attPass_usr = undefined;
         }


         if ($rootScope.militaryPersnl !== undefined) {
             $rootScope.militaryPersnl = undefined;
         }


         if ($rootScope.billingName_usr !== undefined) {
             $rootScope.billingName_usr = undefined;
         }


         if ($rootScope.billingNo_usr !== undefined) {
             $rootScope.billingNo_usr = undefined;
         }


         if ($rootScope.simno_usr !== undefined) {
             $rootScope.simno_usr = undefined;
         }


         if ($rootScope.unlockSecureDomainResp !== undefined) {
             $rootScope.unlockSecureDomainResp = undefined;
         }


         if ($rootScope.unlockStep2Resp !== undefined) {
             $rootScope.unlockStep2Resp = undefined;
         }


         if ($rootScope.imei_usr !== undefined) {
             $rootScope.imei_usr = undefined;
         }


         if ($rootScope.unlockStep3ATTIMEIResp !== undefined) {
             $rootScope.unlockStep3ATTIMEIResp = undefined;
         }


         if ($rootScope.unlockSubmitResp !== undefined) {
             $rootScope.unlockSubmitResp = undefined;
         }


         if ($rootScope.nonAttFname_usr !== undefined) {
             $rootScope.nonAttFname_usr = undefined;
         }


         if ($rootScope.nonAttLname_usr !== undefined) {
             $rootScope.nonAttLname_usr = undefined;
         }


         if ($rootScope.nonAttWirelessNo_usr !== undefined) {
             $rootScope.nonAttWirelessNo_usr = undefined;
         }


         if ($rootScope.nonAttEmailAddress_usr !== undefined) {
             $rootScope.nonAttEmailAddress_usr = undefined;
         }


         if ($rootScope.unlockSecureNonAttDomainResp !== undefined) {
             $rootScope.unlockSecureNonAttDomainResp = undefined;
         }


         if ($rootScope.unlockNonATTSubmitResp !== undefined) {
             $rootScope.unlockNonATTSubmitResp = undefined;
         }
     }

     //nulufer start
     $scope.eligibilityReqsModalOpen = function(event) {
         event.preventDefault();
         $modal.open({
             templateUrl: '/deviceunlock/html/modal/eligibilityRequirementsModal.html',
             controller: 'modalController',
             scope: $scope
         });
     }; //end of modal opening function
     //nulufer end
 }]);
 //Unlock Step 1 Controller - E
 /*modal controller start-nulufer*/
 unlockPortal.controller('modalController', ['$scope', '$modalInstance', '$window', 'services', function($scope, $modalInstance, $window, services) {
	$scope.close = function() {
         $modalInstance.close();
     };

     $scope.cancel = function() {
         $modalInstance.dismiss();
     };
 }]);
 /*modal controller end-nulufer*/

 //Radio button image toggle on clicked -S
 function custRadioClicked(obj) {

     $("#" + obj.id + "RadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
     $("#" + obj.id + "RadioImg").addClass("radioBtnClickedImg");

     if (obj.id == "att_cust") {
         $("#notatt_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
         $("#notatt_custRadioImg").addClass("radioBtnImg");
         $("#attDiv").removeClass("divHide").addClass("divShow");
         $("#nonAttDiv").removeClass("divShow").addClass("divHide");
         //$("#someRequired").removeClass("divShow").addClass("divHide");
         //$("#allRequired").removeClass("divHide").addClass("divShow");
     } else if (obj.id == "notatt_cust") {
         $("#att_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
         $("#att_custRadioImg").addClass("radioBtnImg");
         $("#nonAttDiv").removeClass("divHide").addClass("divShow");
         $("#attDiv").removeClass("divShow").addClass("divHide");
         //$("#allRequired").removeClass("divShow").addClass("divHide");
         //$("#someRequired").removeClass("divHide").addClass("divShow");
     }
 };
 //Radio button image toggle on clicked -E



 //Valid Number will always ensure that input field can only accepts numeric (integer) values
 unlockPortal.directive('validNumber', function() {
     return {
         require: '?ngModel',
         link: function(scope, element, attrs, ngModelCtrl) {
             if (!ngModelCtrl) {
                 return;
             }

             ngModelCtrl.$parsers.push(function(val) {
                 var clean = val.replace(/[^0-9]+/g, '');
                 if (val !== clean) {
                     ngModelCtrl.$setViewValue(clean);
                     ngModelCtrl.$render();
                 }
                 return clean;
             });

             element.bind('keypress', function(event) {
                 if (event.which === 32 || event.keyCode === 32) {
                     event.preventDefault();
                 }
             });
         }
     };
 });




 //Preventing cut, copy and paste the values from the input textboxes
 unlockPortal.directive('stopccp', function() {
     return {
         scope: {},
         link: function(scope, element) {
             element.on('cut copy paste', function(event) {
                 event.preventDefault();
             });
         }
     };
 });



 //Validations
 //For Wireless Number textbox to block O and 1 at index 0
 function checkFirstChar(ev, key, txt) {
     //var len=txt.value.slice(0, txt.selectionStart).length;
     if (getCursorPos(txt) == 0) {
         //return (ev.ctrlKey || ev.altKey || (49 < key && key < 58 && ev.shiftKey == false) || (97 < key && key < 106) || (key == 8) || (key == 9) || (key > 34 && key < 40) || (key == 46));
         return (ev.ctrlKey || ev.altKey || (49 < key && key < 58 && ev.shiftKey == false) || (97 < key && key < 106) || (key == 8) || (key > 34 && key < 40) || (key == 46));
     } else {
         //return (ev.ctrlKey || ev.altKey || (47 < key && key < 58 && ev.shiftKey == false) || (95 < key && key < 106) || (key == 8) || (key == 9) || (key > 34 && key < 40) || (key == 46));
         return (ev.ctrlKey || ev.altKey || (47 < key && key < 58 && ev.shiftKey == false) || (95 < key && key < 106) || (key == 8) || (key > 34 && key < 40) || (key == 46));
     }

 }


 // To get the Cursor position in Wireless Number Field
 function getCursorPos(txt) {

     // IE Support
     if (document.selection) {

         // Set focus on the element
         txt.focus();

         // To get cursor position, get empty selection range
         var sel = document.selection.createRange();

         // Move selection start to 0 position
         sel.moveStart('character', -txt.value.length);

         // The caret position is selection length
         return sel.text.length;

     } else {

         var len = txt.value.slice(0, txt.selectionStart).length
         return len;
     }

 }


 function webtrendsPageHitCapture(pageName, dcsuri) {
     //dcsMultiTrack('DCS.dcssip', 'www.att.com', 'DCS.dcsref', window.location.href, 'DCS.dcsuri', dcsuri, 'DCS.dcsua', navigator.userAgent, 'browserid', navigator.appCodeName, 'DCSext.wtPN', pageName);
 }


 function webtrendsLinkCapture(pageName, dcsuri, linkName, linkLoc) {
     //dcsMultiTrack('DCS.dcssip', 'www.att.com', 'DCS.dcsref', window.location.href, 'DCS.dcsuri', dcsuri, 'DCS.dcsua', navigator.userAgent, 'browserid', navigator.appCodeName, 'DCSext.wtPN', pageName, 'DCSext.wtLinkName', linkName, 'DCSext.wtLinkLoc', linkLoc, 'DCSext.wtNoHit', '1');
 }


 //To show the spinner and overlay
 function openLoader() {
     $("#loader").removeClass("divHide").addClass("divShow");
 }


 //To hide the spinner and overlay
 function closeLoader() {
     $("#loader").removeClass("divShow").addClass("divHide");

 }


 //To check the spaces entered in the input string
 function testWhite(x) {
     var white = new RegExp(/^\s$/);
     return white.test(x.charAt(0));
 }


 //To focus the input field
 function focusField(id) {
     $("#" + id).focus();
 }


 //To check valid email address
 function IsEmail(email) {
     var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     return regex.test(email);
 }


 //To Check the spacial charater in the string
 function isSpecialCharInString(charEnterd) {
     if (/^[a-zA-Z0-9- ]*$/.test(charEnterd) == false) {
         return true;
     }
     return false;
 }

 //function to eliminate 0 and 1 at the begining of wireless number
 function isValidWrlsNo(testChar) {
     if (testChar.charAt(0) === '0' || testChar.charAt(0) === '1') {
         return false;
     }
     return true;
 }


 //To Detect the IE browser version
 function isIE() {
     //var myNav = navigator.userAgent.toLowerCase();
     //return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;
     if (window.ActiveXObject === undefined) return null;
     if (!document.querySelector) return 7;
     if ((!document.addEventListener) || (document.documentMode == 8)) return 8;
     if (!window.atob) return 9;
     if (!document.__proto__) return 10;
     if (!!(navigator.userAgent.match(/Trident/) && navigator.userAgent.match(/rv[ :]11/))) return 11;
     return 0;

 }