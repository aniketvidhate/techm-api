/**
 * @Author 		:- Aniket Vidhate (av0041)   
 * Date			:- 12-7-2015
 * File name 	:- services.js
 */

unlockPortal.factory('services', function($http) {

    var respAPI = {};

   respAPI.postService = function(url, dataJson) {
		return $http({
            method: 'POST',
            url: url,
            data: dataJson
        });
    }




    //code for status
    respAPI.getStatus = function(url){
		//console.log("url in service => ",url);
        return $http.get(url);
    };



    /*
	//To check the ATT wireless no. for fraud activity
    respAPI.FraudulentCheckService = function(attWirelessNo) {
		console.log("attWirelessNo ** ==>"+attWirelessNo);
        return $http.get('/etc/demo/FraudulentCustomer.json');
    }

	//To check the IMEI no. for exists in the list
	respAPI.IMEICheckService = function(imeiReq) {
		console.log("imeiReq ** ==>"+imeiReq);
      return $http.get('/etc/demo/IMEILookup.json', imeiReq);
      /* var a= $http({
            method: 'POST',
            url: 'D:\project\IRU_Unlock_V\V2\IRU_Unlock_Portal\IRU_Unlock_Portal\data\IMEILookup.json',
            data: { imeiReq:imeiReq }

        });
        alert("hello"+a.IMEI);
        return a;*/

    /*}

    //To get the captcha image
    respAPI.captchaGetService = function() {
      return $http.get('http://10.5.74.73:8181/apis/deviceunlock/unlockCaptcha/image/1');
    }
*/


	return respAPI;
  });

unlockPortal.factory('tooltipUtility',function(){
    var tooltip = {};
    
    tooltip.show = function(obj){
		var tootlTipRefs = $(obj.target).closest('.form-group').find('.help_tip');
        if(window.innerWidth<=767){
           // on mobile
            tootlTipRefs.css({display:'block'});
         }else{
             if( $(obj.target).attr('id') == "nonAttImg"){
                tootlTipRefs.css({display:'block',position : 'fixed',top : $(obj.target).offset().top - $(window).scrollTop() - 111 + 'px', left : $(obj.target).offset().left - 100  + 'px'});
             }else{
               tootlTipRefs.css({display:'block',position : 'fixed',top : $(obj.target).offset().top - $(obj.target).closest('.form-group').find('.help_tip').height() - $(window).scrollTop() - 32 + 'px', left : $(obj.target).offset().left - 100  + 'px'});
            }
            var isMobile = window.navigator.userAgent.toLowerCase().indexOf('mobile') != -1 ? true : false;
			
			if(isMobile){				
				$(window).scroll(function(){
					if($(tootlTipRefs).is(':visible')){
					 //tootlTipRefs.css({top:$(obj.target).offset().top - $(obj.target).closest('.form-group').find('.help_tip').height() - $(this).scrollTop() - 32 + 'px'});
					   tootlTipRefs.css({display:'none'});
					}
				});							
			}
         } 
        
    }
    tooltip.hide = function(obj){       
       $(obj.target).closest('.form-group').find('.help_tip').css({display:'none'});	    	   
    }
return tooltip;
});

unlockPortal.factory('cookieUtility',function(){
    var cookieValueObject = {};
    
    cookieValueObject.getCookieValue = function(cname){
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for(var i = 0; i <ca.length; i++) {
		  var c = ca[i];
		  while (c.charAt(0)==' ') {
		    c = c.substring(1);
		  }
		  if (c.indexOf(name) == 0) {
		    return c.substring(name.length,c.length);
		  }
		 }
		    return "";         
    }
    
return cookieValueObject;
});

unlockPortal.factory('openWindow',['cookieUtility',function(cookieUtility){
    var openWin = {};
    
    openWin.showNewWindow = function(url){
		     var windowURL = "https://www.att.com/";
        if(typeof GE5P != 'undefined'){
           if(GE5P.ge5p_localLanguage == 'es_US'){
             windowURL = windowURL + "es-us/"; 
           }
        }else{
            var valueCookie = cookieUtility.getCookieValue('GNSESS');
      if(typeof valueCookie == "string" && typeof valueCookie != 'undefined' && $.trim(valueCookie) != ""){
         var getStoredCookieObj = eval('(' + valueCookie + ')');
         if(getStoredCookieObj.LOCALE == 'es_US'){
             windowURL = windowURL + "es-us/"; 
         }
      }else{
		    if(localStorage.getItem('userLang') == "es"){
				 windowURL = windowURL + "es-us/"; 
			}
       } 
        }
    window.open(windowURL + url, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes,top=70, left=190, width=970, height=460");    
    }
    
return openWin;
}]);