/**********************************
 *
 *	PROD12-11266 - Combine TESLA css & js to reduce the number of HTTP requests & improve performance globally
 *  File Name: ge5p_3rdparty.js
 *	Includes 3rd party js functions to support TESLA Next Gen Global Nav/Footer
 *  Included Files: jQuery JSONP Core Plugin 2.4.0
 *  Created on 3/26/2014 by Robert Butler rb205p
 *  Updated on 7/23/2014 by Erik Rygg er698h  (removed all plugins except JSONP...for use with WBFC project)
 *  Consumer Digital IT Solutions
 *  Developer: Robert J. Butler rb205p@att.com
 *	JS Supports scripts/tesla1.2.0_CD/ge5p_combined.js
 **********************************/
 /*! Versions
1.0.0 - Initial Release
1.1.0 - Combined css for performance
1.2.0 - Isolate all css to global nav elements only
1.2.0_CD - CD = Cross Domain JSONP functionality added for IE8 & IE9
*/

//
// Per direction from FET architecture, for WBFC project, removed all plugins except JSONP Core Plugin 2.4.0
//

/*!
 * jQuery JSONP Core Plugin 2.4.0 (2012-08-21) | MIT Licensed
 */
(function(e){function t(){}function n(e){C=[e]}function r(e,t,n){return e&&e.apply(t.context||t,n)}function i(e){return/\?/.test(e)?"&":"?"}function O(c){function Y(e){if(!(z++)){W();j&&(T[I]={s:[e]});D&&(e=D.apply(c,[e]));r(O,c,[e,b,c]);r(_,c,[c,b])}}function Z(e){if(!(z++)){W();j&&e!=w&&(T[I]=e);r(M,c,[c,e]);r(_,c,[c,e])}}c=e.extend({},k,c);var O=c.success,M=c.error,_=c.complete,D=c.dataFilter,P=c.callbackParameter,H=c.callback,B=c.cache,j=c.pageCache,F=c.charset,I=c.url,q=c.data,R=c.timeout,U,z=0,W=t,X,V,J,K,Q,G;S&&S(function(e){e.done(O).fail(M);O=e.resolve;M=e.reject}).promise(c);c.abort=function(){!(z++)&&W()};if(r(c.beforeSend,c,[c])===!1||z){return c}I=I||u;q=q?typeof q=="string"?q:e.param(q,c.traditional):u;I+=q?i(I)+q:u;P&&(I+=i(I)+encodeURIComponent(P)+"=?");!B&&!j&&(I+=i(I)+"_"+(new Date).getTime()+"=");I=I.replace(/=\?(&|$)/,"="+H+"$1");if(j&&(U=T[I])){U.s?Y(U.s[0]):Z(U)}else{E[H]=n;K=e(y)[0];K.id=l+N++;if(F){K[o]=F}L&&L.version()<11.6?(Q=e(y)[0]).text="document.getElementById('"+K.id+"')."+p+"()":K[s]=s;if(A){K.htmlFor=K.id;K.event=h}K[d]=K[p]=K[v]=function(e){if(!K[m]||!/i/.test(K[m])){try{K[h]&&K[h]()}catch(t){}e=C;C=0;e?Y(e[0]):Z(a)}};K.src=I;W=function(e){G&&clearTimeout(G);K[v]=K[d]=K[p]=null;x[g](K);Q&&x[g](Q)};x[f](K,J=x.firstChild);Q&&x[f](Q,J);G=R>0&&setTimeout(function(){Z(w)},R)}return c}var s="async",o="charset",u="",a="error",f="insertBefore",l="_jqjsp",c="on",h=c+"click",p=c+a,d=c+"load",v=c+"readystatechange",m="readyState",g="removeChild",y="<script>",b="success",w="timeout",E=window,S=e.Deferred,x=e("head")[0]||document.documentElement,T={},N=0,C,k={callback:l,url:location.href},L=E.opera,A=!!e("<div>").html("<!--[if IE]><i><![endif]-->").find("i").length;O.setup=function(t){e.extend(k,t)};e.jsonp=O})(jQuery);