﻿/**********************************
 *
 *	US9639 - Next Gen/Single Code base WebService
 *  US7204 - NextGen/Single Code Base Tracer Bullet
 *  File: ge5p_zone1_2_7_search.js
 *	Includes functions for site navigation and CATO/accessibility
 *  Created on 8/12/2013
 *  Updated on 3/25/2014 by Robert Butler
 *  Consumer Digital IT Solutions
 *  Developer: Robert J. Butler rb205p@att.com
 *	JS Dependent on /scripts/tesla1.0.0/jquery-1.9.1.min.js, /scripts/tesla1.0.0/jquery-ui-1.9.1.min.js
 **********************************/
jQuery.noConflict();
jQuery.support.cors = true;

var GE5P = {
	/*  BINDS  */
	Init: function () {
		//Setup function - used for general jQuery events
		GE5P.setup();
		jQuery(window).scroll(GE5P.closeSegUtilNav); // Zone 1
		jQuery('body').on('click', GE5P.bodyReset);
		/* Zone 1 Events */
		jQuery('#ge5p_z1').on('keydown', 'a', GE5P.keyboardSegUtilNavAction);
		/* Language Drop Down - Not Android */
		if(!GE5P.ge5p_UA_isAndroid) {
			jQuery('#ge5p_z1').on('click', '#ge5p_z1-language-drop-down-link', GE5P.toggleSegUtilLangNav);
		}
		jQuery('#ge5p_z1').on('mouseenter', 'a', GE5P.showSegUtilNav);
		/* Change Language */
        jQuery('#ge5p_z1').on('click', '#ge5p_z1-change-language', GE5P.changeLanguage);
		/* Zone 1 Events */
		if(GE5P.ge5p_UA_isAndroid) {
			jQuery('body').on('touchend', GE5P.bodyReset);
			jQuery('#ge5p_z1').on('touchend', 'a', GE5P.toggleSegUtilNav);
			jQuery('#ge5p_z1').on('touchend', '#ge5p_z1-change-language', GE5P.changeLanguage);
		} else {
			jQuery('body').on('touchend', GE5P.bodyReset);
			// Original jQuery('.ge5p_z1-has-submenu').live('touchstart', 'a', GE5P.toggleSegUtilNav);
			jQuery('#ge5p_z1').on('touchstart', '.ge5p_z1-drop-down', GE5P.toggleSegUtilNav);
			jQuery('#ge5p_z1').on('touchstart', '#ge5p_z1-change-language', GE5P.changeLanguage);
		}
		/* Primary Nav Elements - Primary (.ge5p_z2-primary-nav-el), Secondary (.ge5p_z2-secondary-nav-el), Tertiary (ge5p_z2-tertiary-nav-el)
		 * Primary Elements binds to - Touchstart (tablet), Hover (desktop), Focus (desktop)
		 */
		 /* Zone 2 Events */
		if(GE5P.ge5p_UA_isAndroid) {
			jQuery('#ge5p_z2').on('touchend', '.ge5p_z2-primary-nav-el', GE5P.primaryNavActionTouch);
			jQuery('#ge5p_z2').on('touchend', '.ge5p_z2-secondary-nav-el', GE5P.secondaryNavActionTouch);
			jQuery('#ge5p_z2').on('touchend', '#searchForm button', GE5P.validateSearchForm);
		} else {
			jQuery('#ge5p_z2').on('touchstart', '.ge5p_z2-primary-nav-el', GE5P.primaryNavActionTouch);
			jQuery('#ge5p_z2').on('touchstart', '.ge5p_z2-secondary-nav-el', GE5P.secondaryNavActionTouch);
			jQuery('#ge5p_z2').on('touchstart', '#searchForm button', GE5P.validateSearchForm);
		}
		jQuery('#ge5p_z2').on('keydown', '#ge5p_z2-zipcode-inner a', GE5P.keyboardUserInfo);
		jQuery('#ge5p_z2').on('mouseenter mouseleave', '.ge5p_z2-primary-nav-el', GE5P.primaryNavActionHover);
		jQuery('#ge5p_z2').on('focusin', '.ge5p_z2-primary-nav-el', GE5P.primaryNavActionFocus);
		jQuery('#ge5p_z2').on('mouseenter mouseleave', '.ge5p_z2-secondary-nav-el', GE5P.secondaryNavActionHover);
		jQuery('#ge5p_z2').on('keydown', '#ge5p_z2-nav-bar a', GE5P.keyboardPrimaryNavBar);
		/* Search Form */
		jQuery('#ge5p_z2').on('click', '#searchForm button', GE5P.validateSearchForm);
		/* Search Form Keydown */
		jQuery('#ge5p_z2').on('keydown', '#search', GE5P.keyboardGNSearchBox);
	},
	/*	VAR UNDEFINED SECTION  */
	ge5p_supportsTouch: undefined,
	ge5p_dropDownSetTimeout: undefined,
	ge5p_newWindowText: undefined,
	heightPrimaryNavClosed: undefined,
	heightPrimaryNavTray: undefined,
	heightPrimaryNavOpen: undefined,
	heightPrimaryNavTraySecondaryNavTray: undefined,
	heightPrimaryNavSecondaryNavOpen: undefined,
	heightSecondaryNavTray: undefined,
	heightPrimaryNavBarSecondaryNavTray: undefined,
	heightTertiaryNavOpen: undefined,
	overrideKeys: undefined,
	keyCodePrimaryNav: undefined,
	navServiceJSON: undefined,
	ge5p_userCityVar: undefined,
	ge5p_userStateVar: undefined,
	ge5p_userZipCodeVar: undefined,
	ge5p_GNSESSuserGroups: undefined,
	ge5p_localLanguage: undefined,
	ge5p_changeLanguageURLVar: undefined,
	ge5p_linkLogOutURL: undefined,
	ge5p_requestURL: undefined,
	ge5p_primary_nav: undefined,
	ge5p_is_user_authenticated: undefined,
	ge5p_secTrayDivMaxHeight: undefined,
	ge5p_is_msie: undefined,
	ge5p_is_msie8: undefined,
	ge5p_is_msie9: undefined,
	ge5p_is_msie10: undefined,
	ge5p_UA: undefined,
	ge5p_UA_isAndroid: undefined,
	ge5p_userFirstName: undefined,
	ge5p_navSerHost: undefined,
	ge5p_theFirstVisibleIndex: undefined,
	ge5p_globalNavDefaultPrimaryActive: undefined,
	ge5p_globalNavDefaultSecondaryActive: undefined,
	ge5p_globalNavDefaultLocaleActive: undefined,
	ge5p_globalNavDefaultLocaleActiveSet: undefined,

	/*	SETUP SECTION  */
	//Setup function - used for general jQuery events
	setup: function () {
		// Browser Checking and setting JS Vars
		GE5P.ge5p_UA = navigator.userAgent.toLowerCase();
		// Check for IE Browser
		GE5P.ge5p_is_msie = /msie/.test(GE5P.ge5p_UA);
		// Check for IE8 or IE9 or IE10
		GE5P.ge5p_is_msie8 = /8.0/.test(GE5P.ge5p_UA);
		GE5P.ge5p_is_msie9 = /9.0/.test(GE5P.ge5p_UA);
		GE5P.ge5p_is_msie10 = /10.0/.test(GE5P.ge5p_UA);
		/// Check if Agent is Android
		GE5P.ge5p_UA_isAndroid = /android/.test(GE5P.ge5p_UA);
		// Page JS Vars
		if (typeof globalNavDefaultSelections != 'undefined') {
			if (typeof globalNavDefaultSelections.primary == 'undefined') {
				GE5P.ge5p_globalNavDefaultPrimaryActive = '';
			} else {
				GE5P.ge5p_globalNavDefaultPrimaryActive = globalNavDefaultSelections.primary;
			}
			if (typeof globalNavDefaultSelections.secondary == 'undefined') {
				GE5P.ge5p_globalNavDefaultSecondaryActive = '';
			} else {
				GE5P.ge5p_globalNavDefaultSecondaryActive = globalNavDefaultSelections.secondary;
			}
			if (typeof globalNavDefaultSelections.locale == 'undefined') {
				GE5P.ge5p_globalNavDefaultLocaleActive = '';
			} else {
				GE5P.ge5p_globalNavDefaultLocaleActive = globalNavDefaultSelections.locale;
			}
			if (typeof globalNavDefaultSelections.languageChangeLink == 'undefined') {
				GE5P.ge5p_globalNavDefaultLanguageChangeLink = true;
			} else {
				GE5P.ge5p_globalNavDefaultLanguageChangeLink = globalNavDefaultSelections.languageChangeLink;
			}
		} else {
			GE5P.ge5p_globalNavDefaultPrimaryActive = '';
			GE5P.ge5p_globalNavDefaultSecondaryActive = '';
			GE5P.ge5p_globalNavDefaultLocaleActive = '';
			GE5P.ge5p_globalNavDefaultLanguageChangeLink = true;
		}
		jQuery('nav').mouseleave(function(event) {
			$this = jQuery(event.target);
			// Check if Language DD is open, if so leave it open
			if(jQuery('.ge5p_z1-language-drop-down > div.ge5p_z1-menu').is(':visible')) {
			} else {
				GE5P.closeSegUtilNav();
				jQuery('.ge5p_z2-nav-item, .ge5p_z2-nav-bar-subnav li').removeClass('active');
				jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
				GE5P.closePrimaryNavTrays();
			}
			// Check if there are default Primary & Secondary Default elements - then show
			if(GE5P.ge5p_globalNavDefaultPrimaryActive.length > 0) {
				// Show the active Primary nav element
				$thisPrimaryActive = jQuery('.ge5p_z2-primary-nav-el.ge5p_z2-default-primary-active');
				$thisPrimaryActive.parent().addClass('active');
				$thisPrimaryActive.next().show();
				$thisPrimaryActive.attr('aria-expanded','true').attr('aria-selected','true');
				// Tray 1 height is Primary Nav Height + Primary Nav li.active
				var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
				// Increase height of PrimaryNav to show tray
				GE5P.animatePrimaryTray(heightTray1Open);
			}
		});
		// Check if Page has set Locale variable
		if(GE5P.ge5p_globalNavDefaultLocaleActive.length > 0) {
			GE5P.ge5p_localLanguage = GE5P.ge5p_globalNavDefaultLocaleActive;
			GE5P.ge5p_globalNavDefaultLocaleActiveSet = true;
		} else {
			GE5P.ge5p_globalNavDefaultLocaleActiveSet = false;
		}
		// Checking for Locale Var in GNSESS, colam
		// 1. Page
		// 2. GNSESS COOKIE
		// 3. COLAM (colam_ctn)
		// 4. Default		
		if(jQuery.cookie("GNSESS")) {
			// GNSESS Cookie Exists
			jQuery.cookie.json = true;
			// Try/Catch GNSESS cookie incase of malformed json structure
			try {
				var ge5p_GNSESSvalueCookie = jQuery.cookie('GNSESS');
				if(typeof ge5p_GNSESSvalueCookie == "object"){
					ge5p_GNSESSvalueCookie = JSON.stringify(ge5p_GNSESSvalueCookie);
				}
				// Turn cookie string into a json object
				var jdata = jQuery.parseJSON(ge5p_GNSESSvalueCookie);
	            GE5P.ge5p_is_user_authenticated = false;
				// Override cookie with page locale var
				if(!GE5P.ge5p_globalNavDefaultLocaleActiveSet) {
					GE5P.ge5p_localLanguage = jdata.LOCALE;
				}
				if(jdata.UG) {
					if(jdata.UG.length > 0) {
						var ug_groups = '';
						jQuery.each(jdata.UG, function(key, value) {
							// Check if user is authenticated
							if(value == 'Auth') {
								GE5P.ge5p_is_user_authenticated = true;
							}
							ug_groups += value+'|';
						});
						GE5P.ge5p_GNSESSuserGroups = '&userGroups='+ug_groups;
					} else {
						GE5P.ge5p_GNSESSuserGroups = '';
					}
				} else {
					GE5P.ge5p_GNSESSuserGroups = '';
				}
				if(jdata.FN) {
					if(jdata.FN.length > 0) {
						GE5P.ge5p_userFirstName = jdata.FN;
					}
				}
			} catch(err) {
				//console.log('The Global Navigation Script encountered a malformed GNSESS cookie. Error:'+err);
				// Check if there is an existing COLAM cookie
				if(jQuery.cookie("colam_ctn")) {
					jQuery.cookie.json = true;
					var ge5p_COLAMvalueCookie = jQuery.cookie('colam_ctn');
					if(typeof ge5p_COLAMvalueCookie == "object"){
						ge5p_COLAMvalueCookie = JSON.stringify(ge5p_COLAMvalueCookie);
					}
					var GNSESSObj = jQuery.parseJSON(ge5p_COLAMvalueCookie);
					var newObj = {};
					jQuery.each(GNSESSObj, function(key, val){
					   newObj[key] = GNSESSObj[key];
					});
					jQuery.cookie.raw=true;
					jQuery.cookie('GNSESS', newObj, {
						domain: '.att.com',
						path: '/'
					});
					GE5P.ge5p_is_user_authenticated = false;
					ge5pZ2_valueCookieArr = ge5p_COLAMvalueCookie.split(';');
					// Override cookie with page locale var
					if(!GE5P.ge5p_globalNavDefaultLocaleActiveSet) {
						jQuery.each(ge5pZ2_valueCookieArr, function (key, value) {
							if(value.indexOf('l=') != -1) {
								// Found language var and value
								GE5P.ge5p_localLanguage = jQuery.trim(value.split('=')[1]);
							}
						});
					}
					GE5P.ge5p_GNSESSuserGroups = '';
				} else {
					// Create New GNSESS Cookie with Default values
					jQuery.cookie.json = true;
					var cookieObj = {};
					var ugarray=["Unauth"];
					if (typeof GE5P.ge5p_localLanguage == 'undefined') {
						GE5P.ge5p_localLanguage = "en_US";
					}
					var locale = GE5P.ge5p_localLanguage;
					var ska=["1","jsp"];
					cookieObj['UG'] = ugarray;
					cookieObj['LOCALE'] = locale;
					cookieObj['SKA'] = ska;
					// Write cookie using jQuery Cookie Plugin
					jQuery.cookie.raw=true;
					jQuery.cookie('GNSESS', cookieObj, {
						domain: '.att.com',
						path: '/'
					});
					GE5P.ge5p_is_user_authenticated = false;
				}
			}
		} else {
			// Now check for colam_ctn cookie
			if(jQuery.cookie("colam_ctn")) {
				var ge5p_COLAMvalueCookie = jQuery.cookie('colam_ctn');
				GE5P.ge5p_is_user_authenticated = false;
				// Turn cookie string into a json object
				ge5pZ2_valueCookieArr = ge5p_COLAMvalueCookie.split(';');
				// Override cookie with page locale var
				if(!GE5P.ge5p_globalNavDefaultLocaleActiveSet) {
					jQuery.each(ge5pZ2_valueCookieArr, function (key, value) {
						if(value.indexOf('l=') != -1) {
							// Found language var and value
							GE5P.ge5p_localLanguage = jQuery.trim(value.split('=')[1]);

						}
					});
				}
				GE5P.ge5p_GNSESSuserGroups = '';
			} else {
				// GNSESS Cookie or colam_ctn Cookie Does Not Exist
				// Override cookie with page locale var
				if(!GE5P.ge5p_globalNavDefaultLocaleActiveSet) {
					GE5P.ge5p_localLanguage = 'en_US';
				}
				GE5P.ge5p_GNSESSuserGroups = '';
				GE5P.ge5p_is_user_authenticated = false;
			}
		}
		GE5P.ge5p_newWindowText = "This link will open a new window";
		GE5P.ge5p_dropDownSetTimeout = 50;
		if (typeof ge5p_userCity == 'undefined') {
			GE5P.ge5p_userCityVar = '';
		} else {
			if(ge5p_userCity.indexOf("$")>=0){
				GE5P.ge5p_userCityVar = '';
			} else {
				GE5P.ge5p_userCityVar = ge5p_userCity;
			}
		}
		if (typeof ge5p_userState == 'undefined') {
			GE5P.ge5p_userStateVar = '';
		} else {
			if(ge5p_userState.indexOf("$")>=0){
				GE5P.ge5p_userStateVar = '';
			} else {
				GE5P.ge5p_userStateVar = ge5p_userState;
			}
		}
		if (typeof ge5p_userZip == 'undefined') {
			GE5P.ge5p_userZipCodeVar = '';
		} else {
			if(ge5p_userZip.indexOf("$")>=0){
				GE5P.ge5p_userZipCodeVar = '';
			} else {
				GE5P.ge5p_userZipCodeVar = ge5p_userZip;
			}
		}
		if (typeof ge5p_changeLanguageURL == 'undefined') {
			GE5P.ge5p_changeLanguageURLVar = '';
		} else {
			GE5P.ge5p_changeLanguageURLVar = ge5p_changeLanguageURL;
		}
		if (typeof ge5p_linkLogOutURL == 'undefined') {
			GE5P.ge5p_linkLogOutURLVar = '';
		} else {
			GE5P.ge5p_linkLogOutURLVar = ge5p_linkLogOutURL;
		}
		if (typeof ge5p_requestURL == 'undefined') {
			GE5P.ge5p_requestURLVar = window.location.href;
		} else {
			if(ge5p_requestURL == '') {
				GE5P.ge5p_requestURLVar = window.location.href;
			} else {
				GE5P.ge5p_requestURLVar = ge5p_requestURL;
			}
		}
		if (typeof ge5p_changeLocale == 'undefined') {
			GE5P.ge5p_changeLocaleVar = '';
		} else {
			GE5P.ge5p_changeLocaleVar = ge5p_changeLocale;
		}
		if (typeof ge5p_requestURI == 'undefined') {
			GE5P.ge5p_requestURIVar = '';
		} else {
			GE5P.ge5p_requestURIVar = ge5p_requestURI;
		}
		if (typeof ge5p_queryString == 'undefined') {
			GE5P.ge5p_queryStringVar = '';
		} else {
			GE5P.ge5p_queryStringVar = ge5p_queryString;
		}
		if(GE5P.ge5p_localLanguage) {
			if (GE5P.ge5p_localLanguage.length > 0) {
				// There is a Locale cookie value
				if (GE5P.ge5p_localLanguage == GE5P.ge5p_changeLocaleVar) {
					if (GE5P.ge5p_changeLanguageURLVar != (GE5P.ge5p_requestURIVar+'?'+GE5P.ge5p_queryStringVar)) {
						window.location.href = GE5P.ge5p_changeLanguageURLVar;
					}
				}
			}
		}
		// Last check for nav service vars to make sure it fires
		if (typeof GE5P.ge5p_GNSESSuserGroups == 'undefined') {
			GE5P.ge5p_GNSESSuserGroups = '';
		}
		// Nav Service Host URL
		GE5P.ge5p_navSerHost = '//www.att.com/';
		/* Navigation Service Z1, Z2, Z7 JSON */
        var navServiceUrl = GE5P.ge5p_navSerHost+'navservice/navservlet?locale='+GE5P.ge5p_localLanguage+'&isNextGen=Y'+GE5P.ge5p_GNSESSuserGroups;
		GE5P.nextGenGlobalNav(navServiceUrl);
		/* Function to check if window supports
		 * touch devices
		**/
		if ('ontouchstart' in window) {
            //iOS & android
            GE5P.ge5p_supportsTouch = true;
        } else if(window.navigator.msPointerEnabled) {
            //Win8
            GE5P.ge5p_supportsTouch = true;
        }
		/* Function to add console.log to non supported browsers
		 * On Hold for testing
		if ( typeof(console) === "undefined" ) {
			console = {};
			console.log = function() {};
		}
		**/
		/*******************************************
		 *          ZONE 2 SETUP FUNCTIONS
		 *******************************************/

		/********** END ZONE 2 SETUP ********/

		/* Function to add ipad class
		 * Note: We are using jQuery 1.5.2 - It is ok to use .browser with this version
		 * But if version is upgraded, need to refactor
		**/
		jQuery.extend(jQuery.browser,{SafariMobile : navigator.userAgent.toLowerCase().match(/iP(hone|ad)/i)});
		if(!!jQuery.browser.SafariMobile){jQuery("body").addClass("ipad")}
	}, // End of Setup
	/*****************************************************************
	 *
	 * ATT Global Experience Next Gen Functions
	 *
	 *****************************************************************/
	 /* Function to get json response from nav service
	 **/
	nextGenGlobalNav: function(navServiceUrl) {
		jQuery.getJSON( navServiceUrl, function() {
			// Success in returning Nav service response
			/* Function for reporting - NOTE the new ge5p pre-pended CLASSES & IDs
			**/
			var reporting_ready = window.reporting_ready || new jQuery.Deferred();
			jQuery.when(reporting_ready).then(function (reporting) {
				reporting.capture([
					{selector: '#ge5p_z1-global-nav-container a', type: 'wtparam', name: 'wtLinkName'},
					{selector: '#ge5p_z1-global-nav-container a', type: 'wtparam', name: 'wtLinkLoc', value: 'GLBN_GM'},
					{selector: '#ge5p_z1-global-nav-container a', type: 'wtlink', name: '', params: 'wtLinkName,wtLinkLoc', trigger: 'mousedown'},
					{selector: '#ge5p_z2-primary-nav a', type: 'wtparam', name: 'wtLinkName'},
					{selector: '#ge5p_z2-primary-nav a', type: 'wtparam', name: 'wtLinkLoc', value: 'GLBN'},
					{selector: '#ge5p_z2-primary-nav a', type: 'wtlink', name: '', params: 'wtLinkName,wtLinkLoc', trigger: 'mousedown'},
					{selector: '#ge5p_z2-user-info a', type: 'wtparam', name: 'wtLinkName'},
					{selector: '#ge5p_z2-user-info a', type: 'wtparam', name: 'wtLinkLoc', value: 'GLBN_AN'},
					{selector: '#ge5p_z2-user-info a', type: 'wtlink', name: '', params: 'wtLinkName,wtLinkLoc', trigger: 'mousedown'},
					{selector: '#ge5p_z7 a', type: 'wtparam', name: 'wtLinkName'},
					{selector: '#ge5p_z7 a', type: 'wtparam', name: 'wtLinkLoc', value: 'GLBN_FTR'},
					{selector: '#ge5p_z7 a', type: 'wtlink', name: '', params: 'wtLinkName,wtLinkLoc', trigger: 'mousedown'},
					{selector: 'form#searchForm', type: 'wtmeta', name: 'wtAutoSuggestInd', deferred: true,
						value: function() {
							return jQuery('#autoSuggestBox:isvisible').length ? 'Y' : 'N';
						}
					}
				]);
			});
			//global autosuggest code
			var client_id = 1;
			function split( val ) {
				return val.split( /,\s*?/ );
			}
		})
		.done(function( data ) {
			// Append Zone 1 Seg Util menu containers to DOM
			jQuery('#ge5p_z1').html('<div id=\"ge5p_z1-global-nav-container\" class=\"container\"><ul id=\"ge5p_z1-nav-left-seg\" class=\"ge5p_z1-nav-left-seg\" aria-owns=\"\" role=\"tree\"></ul><ul id=\"ge5p_z1-nav-right-seg\" class=\"ge5p_z1-nav-right-seg\"aria-owns=\"\" role=\"tree\"></ul></div>');
			// Append Zone 2 Primary menu containers to DOM
			jQuery('#ge5p_z2').html('<div class=\"row-fluid\"><div id=\"ge5p_z2-user-info\"><div class=\"ge5p_z2-zipcode-outer\"><div id=\"ge5p_z2-zipcode-inner\" class=\"ge5p_z2-zipcode-inner\"><span id=\"ge5p_z2-zipcode-hi\"></span><span><a id=\"ge5p_z2-zipcode-firstname\" tabindex=\"20\"></a></span><span id=\"ge5p_z2-zipcode-welcome\"></span><span id=\"ge5p_z2-zipcode-welcomeback\"></span><span><a id=\"ge5p_z2-zipcode-register\" href=\"#\" tabindex=\"20\" class=\"ge5p_z2-zipcode-register\">Register</a></span><span id=\"ge5p_z2-zipcode-city\"></span><span id=\"ge5p_z2-zipcode-state\"></span><span id=\"ge5p_z2-zipcode-zip\"></span><span><a href=\"#\" class=\"ge5p_z2-zipcode-enter\" id=\"ge5p_z2-zipcode-enter\" tabindex=\"20\"></a></span><span><a id=\"ge5p_z2-zipcode-change\" href=\"#\" class=\"ge5p_z2-zipcode-change\" tabindex=\"20\">Change</a></span></div><a id=\"ge5p_z2-user-auth\" class=\"ge5p_z2-user-auth\" href=\"#\" tabindex=\"20\"><img id=\"ge5p_z2-user-auth-button\" alt=\"\" src=\"#\"></a></div></div></div><div id=\"ge5p_z2-primary-nav-wrapper\" class=\"row-fluid\"><nav id=\"ge5p_z2-primary-nav\"><ul id=\"ge5p_z2-nav-bar\" aria-owns=\"\" role=\"tree\" aria-label=\"Primary Navigation Bar\"></ul></nav></div>');
			// Append Zone 7 Footer link container to DOM
			jQuery('#ge5p_z7').html('<div id="ge5p_z7-brand-elements" class="ge5p_z7-brand-elements row-fluid"><ul id="ge5p_z7-brand-elements-holder"></ul></div><div class="row-fluid"><hr class="ge5p-fancy-line"></div><div id="ge5p_z7-key-links" class="ge5p_z7-key-links row-fluid"><h2 class="hidden-spoken" id="ge5p_z7-key-links-heading">ATandT Key Links</h2><ul id="ge5p_z7-key-links-holder" aria-describedby="ge5p_z7-key-links-heading" role="menubar" class="text-left"></ul></div><div id="ge5p_z7-copyright-legal" class="ge5p_z7-copyright-legal row-fluid"><div class="text-left"><p><a href="http://www.att.com/gen/privacy-policy?pid=2587">&copy; 2014 AT&amp;T Intellectual Property</a>. All rights reserved. AT&amp;T, the AT&amp;T logo and all other AT&amp;T marks contained herein are trademarks of AT&amp;T Intellectual Property and/or AT&amp;T affiliated companies. AT&amp;T 36USC220506</p></div></div><div id="ge5p_z7-partners-affiliates-awards" class="ge5p_z7-partners-affiliates-awards row-fluid"><ul></ul></div>');
			// Primary Nav Element
			GE5P.ge5p_primary_nav = jQuery('#ge5p_z2-primary-nav');
			// Height of Primary Nav all Trays Closed
			GE5P.heightPrimaryNavClosed = jQuery('#ge5p_z2-primary-nav').height();
			// Listen for primary nav clicks - so you will not close the menu if the html is clicked
			jQuery('#ge5p_z2-primary-nav').not('a').on('touchstart click', function(event){
				event.stopPropagation();
			});
			jQuery.each(data, function (index, element) {
				// Split nav element
				var navZone = element.nav_position.split('_')[1]; // Ex z1
				// Check for Zone 1 Nav
				if(navZone == 'z1') {
					// Returned is the Left or the Right Seg
					// Check what Seg is returned
					if(element.nav_position == 'ge5p_z1_1') {
						// Left Seg Menu returned - "z1_1"
						var ul_aria_owns = "";
						jQuery.each(element.children, function (key, value) {
							// Check if there is a menu or regular link
							if(value.children.length > 0) {
								var li = jQuery('<li class=\"ge5p_z1-tab ge5p_z1-has-submenu\"><a aria-selected=\"false\" aria-expanded=\"false\" aria-setsize="'+value.children.length+'" tabindex="10" role=\"treeitem\" class=\"ge5p_z1-drop-down\" aria-level=\"1\"></a><div class=\"ge5p_z1-menu\"><ul aria-owns=\"\" role=\"group\"></ul></div></li>');
								// Append li to ul seg menu
								jQuery('#ge5p_z1-nav-left-seg').append(li);
								// Anchor Tag Data
								jQuery("a",li).html(value.displayName);
								jQuery("a",li).attr("href", value.url);
								jQuery("a",li).attr("id", value.id);
								jQuery("a",li).attr("aria-label", value.displayName);
								jQuery("ul",li).addClass(value.id);
								var urlID = "ge5p_z1_1_"+key;
								jQuery("ul",li).attr("id",urlID);
								jQuery("a",li).attr("aria-owns",urlID);
								jQuery("#"+urlID).attr("aria-labelledby",value.id); //new
								if(value.hiddenText.length > 0) {
									// There is an hidden text element
									jQuery("a",li).append('<span class=\"hidden-spoken\">'+value.hiddenText+'</span>');
								}
								if(GE5P.ge5p_supportsTouch) {
									// // Touch Device so add hidden-spoken
									jQuery("a",li).append('<span class=\"hidden-spoken\"></span>');
								}
								// Check if this links open in a new window
								if(value.windowLocation == 'Y') {
									// Link opens in new window
									jQuery("a",li).attr("target", "_blank");
									var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-w\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
									jQuery("a",li).append(iconNewWindow);
								}
								if (ul_aria_owns.length > 0) {
									ul_aria_owns = ul_aria_owns+" "+value.id;
								} else {
									ul_aria_owns = value.id;
								}
								// Menu Data
								var aria_owns = "";
								var aria_posinset = 0;
								jQuery.each(value.children, function(x, subnavlinks) {
									var ul = jQuery('.'+value.id);
									aria_posinset = aria_posinset + 1;
									var li2 = jQuery('<li class=\"ge5p_z1-menuitem\"><a tabindex=\"10\" role=\"treeitem\" aria-label=\"'+subnavlinks.displayName+'\" aria-setsize=\"'+value.children.length+'\" aria-posinset=\"'+aria_posinset+'\" aria-level=\"2\"></a></li>');
									ul.append(li2);
									jQuery("a",li2).html(subnavlinks.displayName);
									jQuery("a",li2).attr("id", subnavlinks.id);
									jQuery("a",li2).attr("href", subnavlinks.url);
									if(subnavlinks.hiddenText.length > 0) {
										// There is an hidden text element
										jQuery("a",li2).append('<span class=\"hidden-spoken\">'+subnavlinks.hiddenText+'</span>');
									}
									if(GE5P.ge5p_supportsTouch) {
										// Touch Device so add hidden-spoken
										jQuery("a",li2).append('<span class=\"hidden-spoken\"></span>');
									}
									if(subnavlinks.windowLocation == 'Y') {
										// Link opens in new window
										jQuery("a",li2).attr("target", "_blank");
										var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-w\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
										jQuery("a",li2).append(iconNewWindow);
									}
									if (aria_owns.length > 0) {
										aria_owns = aria_owns+" "+subnavlinks.id;
									} else {
										aria_owns = subnavlinks.id;
									}
								});
								jQuery('#'+urlID).attr('aria-owns',aria_owns);
							} else {
								// Regular Link
								var li = jQuery('<li class=\"ge5p_z1-tab\"><a aria-label=\"'+value.displayName+'\" role=\"treeitem\" aria-setsize=\"'+value.children.length+'\" aria-posinset=\"'+key+'\" aria-level=\"1\" tabindex=\"10\"></a></li>');
								// Append li to ul seg menu
								jQuery('#ge5p_z1-nav-left-seg').append(li);
								// Add Display Text to a
								jQuery("a",li).html(value.displayName);
								jQuery("a",li).attr("href", value.url);
								jQuery("a",li).attr("id", value.id);
								if(GE5P.ge5p_supportsTouch) {
									// Touch Device so add hidden-spoken
									jQuery("a",li).append('<span class=\"hidden-spoken\"></span>');
								}
								// Check if this links open in a new window
								if(value.windowLocation == 'Y') {
									// Link opens in new window
									jQuery("a",li).attr("target", "_blank");
									var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-w\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
									jQuery("a",li).append(iconNewWindow);
								}
								if(value.hiddenText.length > 0) {
									// There is an hidden text element
									jQuery("a",li).append('<span class=\"hidden-spoken\">'+value.hiddenText+'</span>');
								}
								if (ul_aria_owns.length > 0) {
									ul_aria_owns = ul_aria_owns+" "+value.id;
								} else {
									ul_aria_owns = value.id;
								}
							}
						});
						var li_skip = jQuery('<li class=\"ge5p_z1-tab ge5p_z1-skip-navigation\"><a tabindex=\"1\" href=\"#wrapper\" id=\"ge5p_z1-skip-navigation-link\" class=\"ge5p_z1-skip-navigation-link\" aria-label=\"Skip Navigation\" role=\"treeitem\" tabindex=\"10\" aria-posinset=\"1\" aria-level=\"1\">Skip Navigation</a></li>');
						// Append li to ul seg menu
						jQuery('#ge5p_z1-nav-left-seg').append(li_skip);
						ul_aria_owns = ul_aria_owns+" ge5p_z1-skip-navigation-link";
						jQuery('#ge5p_z1-nav-left-seg').attr('aria-owns',ul_aria_owns);
					}
					if(element.nav_position == 'ge5p_z1_2') {
						// Right Seg Menu returned
						var ul_right_aria_owns = "";
						jQuery.each(element.children, function (key, value) {
							// Check if this is the Language Link
							if(value.displayName == 'Language' || value.displayName == 'Idioma') {
								var li = jQuery('<li class=\"ge5p_z1-tab ge5p_z1-has-submenu ge5p_z1-language-drop-down\"><a id=\"ge5p_z1-language-drop-down-link" class=\"ge5p_z1-language-drop-down ge5p_z1-drop-down\" aria-selected=\"false\" aria-expanded=\"false\" aria-setsize="'+value.children.length+'" tabindex=\"10\" role=\"treeitem\" aria-level=\"1\"></a><div class=\"ge5p_z1-menu\"><ul class=\"ge5p_z1-language_submenu\" role=\"group\"></ul></div></li>');
								// Append li to ul seg menu
								jQuery('#ge5p_z1-nav-right-seg').append(li);
								// Anchor Tag Data
								jQuery("a",li).html(value.displayName);
								jQuery("a",li).attr("href", 'javascript:void(0)');
								jQuery("a",li).attr("aria-label", value.displayName);
								jQuery("ul",li).addClass(value.id);
								var urlID = "ge5p_z1_1_"+key;
								jQuery("ul",li).attr("id",urlID);
								jQuery("a",li).attr("aria-owns",urlID);
								// Check if this links open in a new window
								if(value.windowLocation == 'Y') {
									// Link opens in new window
									jQuery("a",li).attr("target", "_blank");
									var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-w\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
									jQuery("a",li).append(iconNewWindow);
								}
								if(value.hiddenText.length > 0) {
									// There is an hidden text element
									jQuery("a",li).append('<span class=\"hidden-spoken\">'+value.hiddenText+'</span>');
								}
								if(GE5P.ge5p_supportsTouch) {
									// // Touch Device so add hidden-spoken
									jQuery("a",li).append('<span class=\"hidden-spoken\"></span>');
								}
								if (ul_right_aria_owns.length > 0) {
									ul_right_aria_owns = ul_right_aria_owns+" "+value.id;
								} else {
									ul_right_aria_owns = value.id;
								}
								var aria_owns = "";
								var aria_posinset = 0;
								// Menu Data
								//var lastID = value.children.length - 1;
								jQuery.each(value.children, function(x, subnavlinks) {
									var ul = jQuery('.'+value.id);
									aria_posinset = aria_posinset + 1;
									var li2 = jQuery('<li class=\"ge5p_z1-menuitem\"><a tabindex=\"10\" aria-label=\"'+subnavlinks.displayName+'\" role=\"treeitem\" aria-setsize=\"'+value.children.length+'\" aria-posinset=\"'+aria_posinset+'\" aria-level=\"2\"></a></li>');
									ul.append(li2);
									jQuery("a",li2).html(subnavlinks.displayName);
									jQuery("a",li2).attr("id", subnavlinks.id);
									jQuery("a",li2).attr("href", subnavlinks.url);
									if(subnavlinks.hiddenText.length > 0) {
										// There is an hidden text element
										jQuery("a",li2).append('<span class=\"hidden-spoken\">'+subnavlinks.hiddenText+'</span>');
									}
									if(GE5P.ge5p_supportsTouch) {
										// // Touch Device so add hidden-spoken
										jQuery("a",li2).append('<span class=\"hidden-spoken\"></span>');
									}
									if(subnavlinks.windowLocation == 'Y') {
										// Link opens in new window
										jQuery("a",li2).attr("target", "_blank");
										var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-w\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
										jQuery("a",li2).append(iconNewWindow);
									}
									if (aria_owns.length > 0) {
										aria_owns = aria_owns+" "+subnavlinks.id;
									} else {
										aria_owns = subnavlinks.id;
									}
								});
								jQuery('#'+urlID).attr('aria-owns',aria_owns);
								// Check if the Language Tab is to be shown as set in the Page Global Vars
								if(GE5P.ge5p_globalNavDefaultLanguageChangeLink) {
									// Add Change URL link
									jQuery('.ge5p_z1-language_submenu li').first().find('a').attr('href',GE5P.ge5p_changeLanguageURLVar);
									jQuery('.ge5p_z1-language_submenu li').first().find('a').attr('id','ge5p_z1-change-language');
									// Add Change language Locale if exists in GNSESS cookie
									if(jQuery.cookie("GNSESS")) {
										// Cookie exists so check for locale info in cookie
										jQuery('.ge5p_z1-language_submenu li').first().find('a').addClass(GE5P.ge5p_localLanguage);
									} else {
										// Cookie does not exist so add default class of en_US
										jQuery('.ge5p_z1-language_submenu li').first().find('a').addClass('en_US');
									}
								} else {
									// Hide Link
									jQuery('.ge5p_z1-language_submenu li').first().find('a').hide();
								}
							} else {
								// Check if there is a menu or regular link
								if(value.children.length > 0) {
									var li = jQuery('<li class=\"ge5p_z1-tab\"><a aria-selected=\"false\" aria-expanded=\"false\" aria-setsize="'+value.children.length+'" tabindex=\"10\" aria-posinset=\"'+aria_posinset+'\" role=\"treeitem\" class=\"ge5p_z1-drop-down\" aria-level=\"1\"></a><div class=\"ge5p_z1-menu\"><ul role=\"group\"></ul></div></li>');
									// Append li to ul seg menu
									jQuery('#ge5p_z1-nav-right-seg').append(li);
									// Anchor Tag Data
									jQuery("a",li).html(value.displayName);
									jQuery("a",li).attr("href", value.url);
									jQuery("a",li).attr("id", value.id);
									jQuery("ul",li).addClass(value.id);
									// Check if this links open in a new window
									if(value.windowLocation == 'Y') {
										// Link opens in new window
										jQuery("a",li).attr("target", "_blank");
										var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-w\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
										jQuery("a",li).append(iconNewWindow);
									}
									if(value.hiddenText.length > 0) {
										// There is an hidden text element
										jQuery("a",li).append('<span class=\"hidden-spoken\">'+value.hiddenText+'</span>');
									}
									if(GE5P.ge5p_supportsTouch) {
										// // Touch Device so add hidden-spoken
										jQuery("a",li).append('<span class=\"hidden-spoken\"></span>');
									}
									if (ul_right_aria_owns.length > 0) {
										ul_right_aria_owns = ul_right_aria_owns+" "+value.id;
									} else {
										ul_right_aria_owns = value.id;
									}
									// Menu Data
									var aria_posinset = 0;
									jQuery.each(value.children, function(x, subnavlinks) {
										var ul = jQuery('.'+value.id);
										aria_posinset = aria_posinset + 1;
										var li2 = jQuery('<li class=\"ge5p_z1-menuitem\"><a tabindex=\"10\" aria-label=\"'+subnavlinks.displayName+'\" role=\"treeitem\" aria-setsize=\"'+value.children.length+'\" aria-posinset=\"'+aria_posinset+'\" aria-level=\"2\"></a></li>');
										ul.append(li2);
										jQuery("a",li2).html(subnavlinks.displayName);
										jQuery("a",li2).attr("id", subnavlinks.id);
										jQuery("a",li2).attr("href", subnavlinks.url);
										if(subnavlinks.hiddenText.length > 0) {
											// There is an hidden text element
											jQuery("a",li2).append('<span class=\"hidden-spoken\">'+subnavlinks.hiddenText+'</span>');
										}
										if(GE5P.ge5p_supportsTouch) {
											// // Touch Device so add hidden-spoken
											jQuery("a",li2).append('<span class=\"hidden-spoken\"></span>');
										}
										if(subnavlinks.windowLocation == 'Y') {
											// Link opens in new window
											jQuery("a",li2).attr("target", "_blank");
											var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-w\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
											jQuery("a",li2).append(iconNewWindow);
										}
										if (aria_owns.length > 0) {
											aria_owns = aria_owns+" "+subnavlinks.id;
										} else {
											aria_owns = subnavlinks.id;
										}
									});
									jQuery('#'+urlID).attr('aria-owns',aria_owns);
								} else {
									// Regular Link
									var li = jQuery('<li class=\"ge5p_z1-tab\"><a aria-label=\"'+value.displayName+'\" role=\"treeitem\" tabindex=\"10\" aria-setsize=\"'+value.children.length+'\" aria-posinset=\"'+key+'\" aria-level=\"1\"></a></li>');
									// Append li to ul seg menu
									jQuery('#ge5p_z1-nav-right-seg').append(li);
									// Add Display Text to a
									jQuery("a",li).html(value.displayName);
									jQuery("a",li).attr("href", value.url);
									jQuery("a",li).attr("id", value.id);
									if(value.hiddenText.length > 0) {
										// There is an hidden text element
										jQuery("a",li).append('<span class=\"hidden-spoken\">'+value.hiddenText+'</span>');
									}
									if(GE5P.ge5p_supportsTouch) {
										// // Touch Device so add hidden-spoken
										jQuery("a",li).append('<span class=\"hidden-spoken\"></span>');
									}
									// Check if this links open in a new window
									if(value.windowLocation == 'Y') {
										// Link opens in new window
										jQuery("a",li).attr("target", "_blank");
										var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-w\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
										jQuery("a",li).append(iconNewWindow);
									}
									if (ul_right_aria_owns.length > 0) {
										ul_right_aria_owns = ul_right_aria_owns+" "+value.id;
									} else {
										ul_right_aria_owns = value.id;
									}
								}
							}
						});
						jQuery('#ge5p_z1-nav-right-seg').attr('aria-owns',ul_right_aria_owns);
					}
					if(element.nav_position == 'ge5p_z1_3') {
						// Miscellaneous items - Search, Register, Change, EnterZIP, Login, WelcometoATT
						jQuery.each(element.children, function (key, value) {
							switch(value.actionType) {
								case "Search":
									setTimeout(function(){
										jQuery('#searchForm').attr('action',value.url);
										// Search Box Autocomplete Bind
										GE5P.searchAutocomplete();
										/* Search Form */
										jQuery('#searchForm').submit(GE5P.validateSearchForm);
									}, 500);
									break;
								case "Register":
									setTimeout(function(){
										jQuery('#ge5p_z2-zipcode-register').attr('href',value.url);
										jQuery('#ge5p_z2-zipcode-register').text(value.displayName);
										if(jQuery.cookie("GNSESS")){
										} else {
											if(!GE5P.ge5p_is_user_authenticated){
												jQuery('#ge5p_z2-zipcode-register').show();
											}
										}
									}, 500);
									break;
								case "Change":
									setTimeout(function(){
										jQuery('#ge5p_z2-zipcode-change').attr('href',value.url+GE5P.ge5p_requestURLVar);
										if(jQuery('#ge5p_z2-zipcode-city').text().length > 0 || jQuery('#ge5p_z2-zipcode-state').text().length > 0 || jQuery('#ge5p_z2-zipcode-zip').text().length > 0) {
											jQuery('#ge5p_z2-zipcode-change').show();
										}
									}, 500);
									break;
								case "EnterZIP":
									jQuery('#ge5p_z2-zipcode-enter').attr('href',value.url+GE5P.ge5p_requestURLVar);
									jQuery('#ge5p_z2-zipcode-enter').text(value.displayName);
									break;
								case "Login":
									jQuery('#ge5p_z2-user-auth-button').attr('src',value.image);
									if(value.hiddenText) {
										if(value.hiddenText > 0) {
											jQuery('#ge5p_z2-user-auth-button').attr('alt',value.hiddenText);
											jQuery('#ge5p_z2-user-auth').append('<span class=\"hidden-spoken\">'+value.hiddenText+'</span>');
										} else {
											jQuery('#ge5p_z2-user-auth-button').attr('alt','Log In Button');
											jQuery('#ge5p_z2-user-auth').append('<span class=\"hidden-spoken\">Log In Button</span>');
										}
									} else {
										jQuery('#ge5p_z2-user-auth-button').attr('alt','Log In Button');
										jQuery('#ge5p_z2-user-auth').append('<span class=\"hidden-spoken\">Log In Button</span>');
									}
									jQuery('#ge5p_z2-user-auth').attr('href',value.url);
									break;
								case "Logout":
									jQuery('#ge5p_z2-user-auth-button').attr('src',value.image);
									if (GE5P.ge5p_linkLogOutURLVar) {
										if (GE5P.ge5p_linkLogOutURLVar.length > 0) {
											jQuery('#ge5p_z2-user-auth').attr('href',GE5P.ge5p_linkLogOutURLVar);
										} else {
											jQuery('#ge5p_z2-user-auth').attr('href',value.url);
										}
									}
									if(value.hiddenText) {
										if(value.hiddenText > 0) {
											jQuery('#ge5p_z2-user-auth-button').attr('alt',value.hiddenText);
											jQuery('#ge5p_z2-user-auth').append('<span class=\"hidden-spoken\">'+value.hiddenText+'</span>');
										} else {
											jQuery('#ge5p_z2-user-auth-button').attr('alt','Log Out Button');
											jQuery('#ge5p_z2-user-auth').append('<span class=\"hidden-spoken\">Log Out Button</span>');
										}
									} else {
										jQuery('#ge5p_z2-user-auth-button').attr('alt','Log Out Button');
										jQuery('#ge5p_z2-user-auth').append('<span class=\"hidden-spoken\">Log Out Button</span>');
									}
									break;
								case "WelcometoATT":
									setTimeout(function(){
										jQuery('#ge5p_z2-zipcode-welcome').text(value.displayName);
										if(jQuery.cookie("GNSESS")){
											// Returning User
											if(!GE5P.ge5p_is_user_authenticated){
												jQuery('#ge5p_z2-zipcode-welcome').show();
												jQuery('#ge5p_z2-zipcode-register').show();
											}
										}
									}, 500);
									break;
								case "WelcomeBack":
									setTimeout(function(){
										jQuery('#ge5p_z2-zipcode-welcomeback').text(value.displayName);
										if(jQuery.cookie("GNSESS")){
											// Returning User
											if(GE5P.ge5p_is_user_authenticated){
												jQuery('#ge5p_z2-zipcode-welcomeback').show();
											}
										}
									}, 500);
									break;
								case "Hi":
									setTimeout(function(){
										jQuery('#ge5p_z2-zipcode-hi').text(value.displayName);
										if(jQuery.cookie("GNSESS")){
											// Returning User
											if(GE5P.ge5p_is_user_authenticated == true){
												jQuery('#ge5p_z2-zipcode-hi').show();
											}
										}
									}, 500);
									break;
								case "FN":
									setTimeout(function(){
										if(jQuery.cookie("GNSESS")){
											// Returning User
											if(GE5P.ge5p_is_user_authenticated){
												// User Returning & auth - add name/url
												if(GE5P.ge5p_userFirstName) {
													if(GE5P.ge5p_userFirstName.length > 0) {
														jQuery('#ge5p_z2-zipcode-firstname').text(GE5P.ge5p_userFirstName);
													}
												} else {
													if(value.displayName) {
														jQuery('#ge5p_z2-zipcode-firstname').text(value.displayName);
													} else {
														jQuery('#ge5p_z2-zipcode-firstname').text('Placeholder First Name');
														jQuery('#ge5p_z2-zipcode-firstname').css('text-indent','-9999px');
														jQuery('#ge5p_z2-zipcode-firstname').attr('href',"http://www.att.com");
														jQuery('#ge5p_z2-zipcode-firstname').hide();
													}
												}
												if(value.url){
													jQuery('#ge5p_z2-zipcode-firstname').attr('href',value.url);
												} else {
													jQuery('#ge5p_z2-zipcode-firstname').attr('href',"http://www.att.com");
												}
												jQuery('#ge5p_z2-zipcode-firstname').css('text-indent','inherit');
												jQuery('#ge5p_z2-zipcode-firstname').show();
											} else {
												// User Returning but not auth - hide name/url
												jQuery('#ge5p_z2-zipcode-firstname').text('Placeholder First Name');
												jQuery('#ge5p_z2-zipcode-firstname').css('text-indent','-9999px');
												jQuery('#ge5p_z2-zipcode-firstname').attr('href',"http://www.att.com");
												jQuery('#ge5p_z2-zipcode-firstname').hide();
											}
										} else {
											// New User
											jQuery('#ge5p_z2-zipcode-firstname').text('Placeholder First Name');
											jQuery('#ge5p_z2-zipcode-firstname').css('text-indent','-9999px');
											jQuery('#ge5p_z2-zipcode-firstname').attr('href',"http://www.att.com");
											jQuery('#ge5p_z2-zipcode-firstname').hide();
										}
									}, 500);
									break;
							}
						});
					}
				}
				if(navZone == 'z2') {
					// Zone 2 Nav
					// AT&T has three Primary Links
					// ge5p_z2_1 - Shop
					// ge5p_z2_2 - myAT&T
					// ge5p_z2_3 - Support

					if(element.nav_position == 'ge5p_z2_1') {
						// Add Logo to ul
						var ge5p_z2_logo = jQuery('<li id=\"primaryLogo\" class=\"ge5p_z2-primaryLogo\"><a class=\"ge5p_z2-primary-nav-el\" title=\"AT&amp;T Home Page Link\" alt=\"AT&amp;T Home Page Link\" href=\"http://www.att.com\" tabindex=\"20\" role=\"treeitem\" aria-setsize=\"4\" aria-level=\"1\" aria-posinset=\"1\">AT&amp;T<span class=\"hidden-spoken\">AT&amp;T Home Page Link</span></a></li>');
						jQuery('#ge5p_z2-nav-bar').append(ge5p_z2_logo);
						// Shop
						var liSec1 = jQuery('<li class=\"ge5p_z2-nav-item\" role=\"presentation\"><a id=\"'+element.id+'\" class=\"ge5p_z2-primary-nav-el\" tabindex=\"20\" aria-label=\"'+element.displayName+'\" role=\"treeitem\" aria-setsize=\"4\" aria-level=\"1\" aria-posinset=\"2\" aria-selected=\"false\" aria-expanded=\"false\" aria-owns=\"\" href=\"'+element.url+'\">'+element.displayName+'</a><ul aria-owns=\"\" role=\"group\" class=\"ge5p_z2-nav-bar-subnav\"></ul></li>');
						// Append li to ul seg menu
						jQuery('#ge5p_z2-nav-bar').append(liSec1);
						jQuery("ul",liSec1).addClass('sub-'+element.id);
						var ulID = "ge5p_z2_1_1";
						jQuery("ul",liSec1).attr("id",ulID);
						jQuery("a",liSec1).attr("aria-owns",ulID);
						if(element.windowLocation == 'Y') {
							// Link opens in new window
							jQuery("a",liSec1).attr("target", "_blank");
						}
						if(GE5P.ge5p_supportsTouch) {
							// // Touch Device so add hidden-spoken
							jQuery("a",liSec1).append('<span class=\"hidden-spoken\"></span>');
						}
						// Check if Menu Item is Active from Page
						if(element.code == GE5P.ge5p_globalNavDefaultPrimaryActive) {
							// This Primary item is active
							GE5P.closeSegUtilNav();
							// Tray open
							// Tray 1 = Primary Tray Open
							// Tray 2 = Secondary Tray Open
							// Remove "active" from all li's
							jQuery('.ge5p_z2-nav-item').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							// Add class "active" to li to turn background white
							jQuery("#"+element.id).parent().addClass('active');
							jQuery("#"+element.id).attr('aria-expanded','true').attr('aria-selected','true');
							// Tray 1 height is Primary Nav Height + Primary Nav li.active
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							// Increase height of PrimaryNav to show tray
							GE5P.animatePrimaryTray(heightTray1Open);
							jQuery("#"+element.id).addClass('ge5p_z2-default-primary-active');
						}
						// Menu Data
						var aria_owns = "";
						var aria_posinset = 0;
						jQuery.each(element.children, function(x, subnavlinks) {
							var ul2 = jQuery('.sub-'+element.id);
							aria_posinset = aria_posinset + 1;
							var subNavLinkID = subnavlinks.id;
							var liTer1 = jQuery('<li class=\"'+subNavLinkID+'\" role=\"presentation\"><a class=\"ge5p_z2-secondary-nav-el\" tabindex=\"20\" aria-label=\"'+subnavlinks.displayName+'\" role=\"treeitem\" aria-setsize=\"'+element.children.length+'\" aria-posinset=\"'+aria_posinset+'\" aria-level=\"2\"></a></li>');
							ul2.append(liTer1);
							jQuery("a",liTer1).html(subnavlinks.displayName);
							jQuery("a",liTer1).attr("id", subNavLinkID);
							jQuery("a",liTer1).attr("href", subnavlinks.url);
							// Check if this links open in a new window
							if(subnavlinks.windowLocation == 'Y') {
								// Link opens in new window
								jQuery("a",liTer1).attr("target", "_blank");
								var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
								jQuery("a",liTer1).append(iconNewWindow);
							}
							if(GE5P.ge5p_supportsTouch) {
								// // Touch Device so add hidden-spoken
								jQuery("a",liTer1).append('<span class=\"hidden-spoken\"></span>');
							}
							if (aria_owns.length > 0) {
								aria_owns = aria_owns+" "+subnavlinks.id;
							} else {
								aria_owns = subnavlinks.id;
							}
							// Check if link has a tertiary level
							if(subnavlinks.children.length > 0) {
								jQuery('#'+subNavLinkID).addClass('ge5p_z2-nav-bar-subnav-has-tray');
								var liSecNav = jQuery('.'+subNavLinkID);
								var liTer2 = jQuery('<div class=\"tray\"></div>');
								liSecNav.append(liTer2);
								var aria_ownsTeir = "";
								var aria_posinsetTeir = 0;
								var ulIDTeir;
								jQuery.each(subnavlinks.children, function(a, header) {
									var ulIDTeir = "ge5p_z2_1_1_"+a;
									if(header.isHead) {
										liSecNav.find('.tray').append('<div id=\"'+header.id+'\"><h3>'+header.displayName+'</h3><ul id=\"'+ulIDTeir+'\"></ul></div>');
										GE5P.trayColumnID = jQuery('#'+header.id);
									} else {
										if (GE5P.trayColumnID) {
											aria_posinsetTeir = aria_posinsetTeir + 1;
											GE5P.trayColumnID.find('ul').append('<li role=\"presentation\"><a id=\"'+header.id+'\" class=\"navTertiaryLink\" tabindex=\"20\" href=\"'+header.url+'\" aria-label=\"'+header.displayName+'\" role=\"treeitem\" aria-setsize=\"'+subnavlinks.children.length+'\" aria-posinset=\"'+aria_posinsetTeir+'\" aria-level=\"3\">'+header.displayName+'</a></li>');
											if(header.windowLocation == 'Y') {
												// Link opens in new window
												jQuery('#'+header.id).attr("target", "_blank");
												var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
												jQuery('#'+header.id).append(iconNewWindow);
											}
										}
									}
									if (aria_ownsTeir.length > 0) {
										aria_ownsTeir = aria_ownsTeir+" "+header.id;
									} else {
										aria_ownsTeir = header.id;
									}
								});
								jQuery('#'+ulIDTeir).attr('aria-owns',aria_ownsTeir);
							}
							// Check if Secondary Menu Item is Active from Page
							if(subnavlinks.code == GE5P.ge5p_globalNavDefaultSecondaryActive) {
								//subNavLinkID
								if(subnavlinks.children.length > 0) {
									// We have a Tray so display
									jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
									jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
									jQuery('#'+subNavLinkID).addClass('ge5p_z2-default-secondary-active');
								} else {
									// Regular link in the Secondary menu so close the Tray
									jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
									jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
									jQuery('#'+subNavLinkID).parent().addClass('active');
									var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
									GE5P.animatePrimaryTray(heightTray1Open);
								}
							}
						});
						jQuery('#'+ulID).attr('aria-owns',aria_owns);
					}  // End Shop
					if(element.nav_position == 'ge5p_z2_2') {
						// myat&t
						var liSec2 = jQuery('<li class=\"ge5p_z2-nav-item\" role=\"presentation\"><a id=\"'+element.id+'\" class=\"ge5p_z2-primary-nav-el\" tabindex=\"20\" aria-label=\"'+element.displayName+'\" role=\"treeitem\" aria-setsize=\"4\" aria-level=\"1\" aria-posinset=\"2\" aria-selected=\"false\" aria-expanded=\"false\" aria-owns=\"\" href=\"'+element.url+'\">'+element.displayName+'</a><ul aria-owns=\"\" role=\"group\" class=\"ge5p_z2-nav-bar-subnav\"></ul></li>');
						// Append li to ul seg menu
						jQuery('#ge5p_z2-nav-bar').append(liSec2);
						jQuery("ul",liSec2).addClass('sub-'+element.id);
						var ulID = "ge5p_z2_1_2";
						jQuery("ul",liSec2).attr("id",ulID);
						jQuery("a",liSec2).attr("aria-owns",ulID);
						if(element.windowLocation == 'Y') {
							// Link opens in new window
							jQuery("a",liSec2).attr("target", "_blank");
							var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
							jQuery("a",liSec2).append(iconNewWindow);
						}
						if(GE5P.ge5p_supportsTouch) {
							// // Touch Device so add hidden-spoken
							jQuery("a",liSec2).append('<span class=\"hidden-spoken\"></span>');
						}
						// Check if Menu Item is Active from Page
						if(element.code == GE5P.ge5p_globalNavDefaultPrimaryActive) {
							// This Primary item is active
							GE5P.closeSegUtilNav();
							// Tray open
							// Tray 1 = Primary Tray Open
							// Tray 2 = Secondary Tray Open
							// Remove "active" from all li's
							jQuery('.ge5p_z2-nav-item').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							// Add class "active" to li to turn background white
							jQuery("#"+element.id).parent().addClass('active');
							jQuery("#"+element.id).attr('aria-expanded','true').attr('aria-selected','true');
							// Tray 1 height is Primary Nav Height + Primary Nav li.active
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							// Increase height of PrimaryNav to show tray
							GE5P.animatePrimaryTray(heightTray1Open);
							jQuery("#"+element.id).addClass('ge5p_z2-default-primary-active');
						}
						// Menu Data
						var aria_owns = "";
						var aria_posinset = 0;
						jQuery.each(element.children, function(x, subnavlinks) {
							var ul2 = jQuery('.sub-'+element.id);
							aria_posinset = aria_posinset + 1;
							var subNavLinkID = subnavlinks.id;
							var liTer1 = jQuery('<li class=\"'+subNavLinkID+'\" role=\"presentation\"><a class=\"ge5p_z2-secondary-nav-el\" tabindex=\"20\" aria-label=\"'+subnavlinks.displayName+'\" role=\"treeitem\" aria-setsize=\"'+element.children.length+'\" aria-posinset=\"'+aria_posinset+'\" aria-level=\"2\"></a></li>');
							ul2.append(liTer1);
							jQuery("a",liTer1).html(subnavlinks.displayName);
							jQuery("a",liTer1).attr("id", subnavlinks.id);
							jQuery("a",liTer1).attr("href", subnavlinks.url);
							// Check if this links open in a new window
							if(subnavlinks.windowLocation == 'Y') {
								// Link opens in new window
								jQuery("a",liTer1).attr("target", "_blank");
								var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
								jQuery("a",liTer1).append(iconNewWindow);
							}
							if(GE5P.ge5p_supportsTouch) {
								// // Touch Device so add hidden-spoken
								jQuery("a",liTer1).append('<span class=\"hidden-spoken\"></span>');
							}
							if (aria_owns.length > 0) {
								aria_owns = aria_owns+" "+subnavlinks.id;
							} else {
								aria_owns = subnavlinks.id;
							}
							// Check if link has a tertiary level
							if(subnavlinks.children.length > 0) {
								jQuery('#'+subNavLinkID).addClass('ge5p_z2-nav-bar-subnav-has-tray');
								var liSecNav = jQuery('.'+subNavLinkID);
								var liTer2 = jQuery('<div class=\"tray\"></div>');
								liSecNav.append(liTer2);
								var aria_ownsTeir = "";
								var aria_posinsetTeir = 0;
								var ulIDTeir;
								jQuery.each(subnavlinks.children, function(a, header) {
									var ulIDTeir = "ge5p_z2_1_1_"+a;
									if(header.isHead) {
										liSecNav.find('.tray').append('<div id=\"'+header.id+'\"><h3>'+header.displayName+'</h3><ul id=\"'+ulIDTeir+'\"></ul></div>');
										GE5P.trayColumnID = jQuery('#'+header.id);
									} else {
										if (GE5P.trayColumnID) {
											aria_posinsetTeir = aria_posinsetTeir + 1;
											GE5P.trayColumnID.find('ul').append('<li role=\"presentation\"><a id=\"'+header.id+'\" class=\"navTertiaryLink\" tabindex=\"20\" href=\"'+header.url+'\" aria-label=\"'+header.displayName+'\" role=\"treeitem\" aria-setsize=\"'+subnavlinks.children.length+'\" aria-posinset=\"'+aria_posinsetTeir+'\" aria-level=\"3\">'+header.displayName+'</a></li>');
											if(header.windowLocation == 'Y') {
												// Link opens in new window
												jQuery('#'+header.id).attr("target", "_blank");
												var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
												jQuery('#'+header.id).append(iconNewWindow);
											}
										}
									}
									if (aria_ownsTeir.length > 0) {
										aria_ownsTeir = aria_ownsTeir+" "+header.id;
									} else {
										aria_ownsTeir = header.id;
									}
								});
								jQuery('#'+ulIDTeir).attr('aria-owns',aria_ownsTeir);
							}
							// Check if Secondary Menu Item is Active from Page
							if(subnavlinks.code == GE5P.ge5p_globalNavDefaultSecondaryActive) {
								//subNavLinkID
								if(subnavlinks.children.length > 0) {
									// We have a Tray so display
									jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
									jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
									jQuery('#'+subNavLinkID).addClass('ge5p_z2-default-secondary-active');
								} else {
									// Regular link in the Secondary menu so close the Tray
									jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
									jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
									jQuery('#'+subNavLinkID).parent().addClass('active');
									var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
									GE5P.animatePrimaryTray(heightTray1Open);
								}
							}
						});
						jQuery('#'+ulID).attr('aria-owns',aria_owns);
					} // End myAT&T
					if(element.nav_position == 'ge5p_z2_3') {
						// Support
						var liSec3 = jQuery('<li class=\"ge5p_z2-nav-item\"><a id=\"'+element.id+'\" class=\"ge5p_z2-primary-nav-el\" tabindex=\"20\" aria-label=\"'+element.displayName+'\" role=\"treeitem\" aria-setsize=\"4\" aria-level=\"1\" aria-posinset=\"2\" aria-selected=\"false\" aria-expanded=\"false\" aria-owns=\"\" href=\"'+element.url+'\">'+element.displayName+'</a><ul aria-owns=\"\" role=\"group\" class=\"ge5p_z2-nav-bar-subnav\"></ul></li>');
						// Append li to ul seg menu
						jQuery('#ge5p_z2-nav-bar').append(liSec3);
						jQuery("ul",liSec3).addClass('sub-'+element.id);
						var ulID = "ge5p_z2_1_3";
						jQuery("ul",liSec3).attr("id",ulID);
						jQuery("a",liSec3).attr("aria-owns",ulID);
						if(element.windowLocation == 'Y') {
							// Link opens in new window
							jQuery("a",liSec3).attr("target", "_blank");
							var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
							jQuery("a",liSec3).append(iconNewWindow);
						}
						if(GE5P.ge5p_supportsTouch) {
							// // Touch Device so add hidden-spoken
							jQuery("a",liSec3).append('<span class=\"hidden-spoken\"></span>');
						}
						// Check if Menu Item is Active from Page
						if(element.code == GE5P.ge5p_globalNavDefaultPrimaryActive) {
							// This Primary item is active
							GE5P.closeSegUtilNav();
							// Tray open
							// Tray 1 = Primary Tray Open
							// Tray 2 = Secondary Tray Open
							// Remove "active" from all li's
							jQuery('.ge5p_z2-nav-item').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							// Add class "active" to li to turn background white
							jQuery("#"+element.id).parent().addClass('active');
							jQuery("#"+element.id).attr('aria-expanded','true').attr('aria-selected','true');
							// Tray 1 height is Primary Nav Height + Primary Nav li.active
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							// Increase height of PrimaryNav to show tray
							GE5P.animatePrimaryTray(heightTray1Open);
							jQuery("#"+element.id).addClass('ge5p_z2-default-primary-active');
						}
						// Menu Data
						var aria_owns = "";
						var aria_posinset = 0;
						jQuery.each(element.children, function(x, subnavlinks) {
							var ul2 = jQuery('.sub-'+element.id);
							aria_posinset = aria_posinset + 1;
							var subNavLinkID = subnavlinks.id;
							var liTer1 = jQuery('<li class=\"'+subNavLinkID+'\" role=\"presentation\"><a class=\"ge5p_z2-secondary-nav-el\" tabindex=\"20\" aria-label=\"'+subnavlinks.displayName+'\" role=\"treeitem\" aria-setsize=\"'+element.children.length+'\" aria-posinset=\"'+aria_posinset+'\" aria-level=\"2\"></a></li>');
							ul2.append(liTer1);
							jQuery("a",liTer1).html(subnavlinks.displayName);
							jQuery("a",liTer1).attr("id", subnavlinks.id);
							jQuery("a",liTer1).attr("href", subnavlinks.url);
							// Check if this links open in a new window
							if(subnavlinks.windowLocation == 'Y') {
								// Link opens in new window
								jQuery("a",liTer1).attr("target", "_blank");
								var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
								jQuery("a",liTer1).append(iconNewWindow);
							}
							if(GE5P.ge5p_supportsTouch) {
								// // Touch Device so add hidden-spoken
								jQuery("a",liTer1).append('<span class=\"hidden-spoken\"></span>');
							}
							if (aria_owns.length > 0) {
								aria_owns = aria_owns+" "+subnavlinks.id;
							} else {
								aria_owns = subnavlinks.id;
							}
							// Check if link has a tertiary level
							if(subnavlinks.children.length > 0) {
								jQuery('#'+subNavLinkID).addClass('ge5p_z2-nav-bar-subnav-has-tray');
								var liSecNav = jQuery('.'+subNavLinkID);
								var liTer2 = jQuery('<div class=\"tray\"></div>');
								liSecNav.append(liTer2);
								var aria_ownsTeir = "";
								var aria_posinsetTeir = 0;
								var ulIDTeir;
								jQuery.each(subnavlinks.children, function(a, header) {
									var ulIDTeir = "ge5p_z2_1_1_"+a;
									if(header.isHead) {
										liSecNav.find('.tray').append('<div id=\"'+header.id+'\"><h3>'+header.displayName+'</h3><ul id=\"'+ulIDTeir+'\"></ul></div>');
										GE5P.trayColumnID = jQuery('#'+header.id);
									} else {
										if (GE5P.trayColumnID) {
											aria_posinsetTeir = aria_posinsetTeir + 1;
											GE5P.trayColumnID.find('ul').append('<li role=\"presentation\"><a id=\"'+header.id+'\" class=\"navTertiaryLink\" tabindex=\"20\" href=\"'+header.url+'\" aria-label=\"'+header.displayName+'\" role=\"treeitem\" aria-setsize=\"'+subnavlinks.children.length+'\" aria-posinset=\"'+aria_posinsetTeir+'\" aria-level=\"3\">'+header.displayName+'</a></li>');
											if(header.windowLocation == 'Y') {
												// Link opens in new window
												jQuery('#'+header.id).attr("target", "_blank");
												var iconNewWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
												jQuery('#'+header.id).append(iconNewWindow);
											}
										}
									}
									if (aria_ownsTeir.length > 0) {
										aria_ownsTeir = aria_ownsTeir+" "+header.id;
									} else {
										aria_ownsTeir = header.id;
									}
								});
								jQuery('#'+ulIDTeir).attr('aria-owns',aria_ownsTeir);
							}
							// Check if Secondary Menu Item is Active from Page
							if(subnavlinks.code == GE5P.ge5p_globalNavDefaultSecondaryActive) {
								//subNavLinkID
								if(subnavlinks.children.length > 0) {
									// We have a Tray so display
									jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
									jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
									jQuery('#'+subNavLinkID).addClass('ge5p_z2-default-secondary-active');
								} else {
									// Regular link in the Secondary menu so close the Tray
									jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
									jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
									jQuery('#'+subNavLinkID).parent().addClass('active');
									var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
									GE5P.animatePrimaryTray(heightTray1Open);
								}
							}
						});
						jQuery('#'+ulID).attr('aria-owns',aria_owns);
						var searchForm = '<li id=\"primary_Search\"><form action=\"\" name="searchForm" id="searchForm" method="get">'
							+ '  <fieldset> '
							+ '	  <input type="hidden" value="HOME" name="App_ID"> '
							+ '	  <input type="hidden" value="FALSE" name="autoSuggest"> '
							+ '	  <input type="hidden" value="FALSE" id="tabPressed" name="tabPressed"> '
							+ '	  <input type="text" title="Search" class="span3 ask_a_question_box ui-autocomplete-input" id="search" name="q" placeholder="Search" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true"> '
							+ '	  <input type="submit" class="cssIcon-search" value="Search Submit Button" alt="Search Submit Button">'
							+ '	  <div class="autoSuggest" id="autoSuggestBox"></div>'
							+ '  </fieldset> '
							+ '</form></li> ';
						jQuery('#ge5p_z2-nav-bar').append(searchForm);
						// Close Primary Nav Trays if the search box has focus
						// We have a Placeholder "Search" attribute in the Search input box
						// We check if the browser supports this feature (not IE)
						if (Modernizr.input.placeholder) {
							// Placeholder text should already be visible!
						} else {
							// no placeholder support :(
							// fall back to a scripted solution
							jQuery('#search').val('Search');
						}
						if(GE5P.ge5p_localLanguage) {
							if(GE5P.ge5p_localLanguage == 'en_US' || GE5P.ge5p_localLanguage == 'en' || GE5P.ge5p_localLanguage == 'en-US') {
								// Change Search placeholder to english
								jQuery('#search').attr('placeholder', 'Search');
							} else {
								// Change Search placeholder to spanish
								jQuery('#search').attr('placeholder', 'Buscar');
							}
						} else {
							// Change Search placeholder to english
							jQuery('#search').attr('placeholder', 'Search');
						}
					}// End Support
				}// End Zone 2 Menu
				if(navZone == 'z7') {
					// Expected four sections - ge5p_z7_1, ge5p_z7_2, ge5p_z7_3, ge5p_z7_4
					if(element.nav_position == 'ge5p_z7_1') {
						// Branding Elements
						jQuery.each(element.children, function(key, value) {
							var liz7_1 = jQuery('<li role=\"presentation\"><p><a tabindex=\"0\"></a></p></li>');
							jQuery('#ge5p_z7-brand-elements-holder').append(liz7_1);
							jQuery("a",liz7_1).attr("href", value.url);
							jQuery("a",liz7_1).attr("id", value.id);
							// Check if display name is att.com or .net - adjust globe image
							if (value.displayName.split('.')[1] == 'com') {
								jQuery("a",liz7_1).append('<img width=\"133px\" height=\"24px\" alt=\"'+value.additionalLabel+'\" src=\"//www.att.com/media/att/2011/global/nav/en_US/logoATTdotcom.png\">');
								jQuery("p",liz7_1).attr('class','ge5p_z7-dotCom');
							}
							if (value.displayName.split('.')[1] == 'net') {
								jQuery("a",liz7_1).append('<img width=\"173px\" height=\"21px\" alt=\"'+value.additionalLabel+'\" src=\"//www.att.com/media/att/2011/global/nav/en_US/logoATTdotnet.png\">');
								jQuery("p",liz7_1).attr('class','ge5p_z7-dotNet');
							}
							if(value.hiddenText.length > 0) {
								// There is an hidden text element
								jQuery("a",liz7_1).append('<span class=\"hidden-spoken\">'+value.hiddenText+'</span>');
							}
                            if(value.windowLocation == 'Y') {
								// Link opens in new window
								jQuery("a",liz7_1).attr("target", "_blank");
								var newWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
								jQuery("a",liz7_1).append(newWindow);
							}
						});
					}
					if(element.nav_position == 'ge5p_z7_2') {
						// Link Farm/Key Links
						jQuery.each(element.children, function(key, value) {
							var liz7_2 = jQuery('<li role=\"presentation\"><a role=\"menuitem\" tabindex=\"0\"></a></li>');
							jQuery('#ge5p_z7-key-links-holder').append(liz7_2);
							jQuery("a",liz7_2).text(value.displayName);
							jQuery("a",liz7_2).attr("href", value.url);
							jQuery("a",liz7_2).attr("id", value.id);
							if(value.windowLocation == 'Y') {
								// Link opens in new window
								jQuery("a",liz7_2).attr("target", "_blank");
								var newWindow = jQuery('<i class=\"cssIcon-open-window-b\"></i><span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
								jQuery("a",liz7_2).append(newWindow);
							}
							if(value.additionalLabel.length > 0) {
								// There is an additional Label
								jQuery("a",liz7_2).after(' '+value.additionalLabel+' ');
							}
							if(value.hiddenText.length > 0) {
								// There is an hidden text element
								jQuery("a",liz7_2).append('<span class=\"hidden-spoken\">'+value.hiddenText+'</span>');
							}
						});
					}
					if(element.nav_position == 'ge5p_z7_3') {
						// Copyright
						var copyrightVal = jQuery('#ge5p_z7-copyright-legal');
						copyrightVal.empty();
						jQuery.each(element.children, function(key, value) {
							var liz7_3 = jQuery('<div class=\"text-left\"><p><a tabindex=\"0\"></a> <span></span><p></div>');
							copyrightVal.append(liz7_3);
							jQuery("span",liz7_3).html(value.additionalLabel);
							jQuery("a",liz7_3).html(value.displayName);
							jQuery("a",liz7_3).append('<span class=\"hidden-spoken\">'+value.displayName+' link. '+GE5P.ge5p_newWindowText+' '+value.hiddenText+'</span>');
							jQuery("a",liz7_3).attr("href", value.url);
							jQuery("a",liz7_3).attr("id", value.id);
						});
					}
					if(element.nav_position == 'ge5p_z7_4') {
						// Partners
						jQuery.each(element.children, function(key, value) {
							var liz7_4 = jQuery('<li><a tabindex=\"0\"></a></li>');
							// Append li to ul partners
							jQuery('#ge5p_z7-partners-affiliates-awards ul').append(liz7_4);
							// Anchor Tag Data
							jQuery("a",liz7_4).html('<img src=\"'+value.image+'\" alt=\"'+value.displayName+'\"/><span class=\"hidden-spoken\">'+value.displayName+' link. '+value.hiddenText+'</span>');
							jQuery("a",liz7_4).attr("href", value.url);
							jQuery("a",liz7_4).attr("id", value.id);
							//jQuery("a",liz7_4).append('');
							//jQuery("img."+value.displayName).attr("src", value.image);
							//jQuery("img."+value.displayName).attr("alt", value.displayName);
							if(value.windowLocation == 'Y') {
								// Link opens in new window
								jQuery("a",liz7_4).attr("target", "_blank");
								var newWindow = jQuery('<span class=\"hidden-spoken\">'+GE5P.ge5p_newWindowText+'</span>');
								jQuery("a",liz7_4).append(newWindow);
							}
						});
					}
				} // End Zone 7 Menu
			}); // End each
			// Add Zip Code/Login information
			GE5P.userInfoData();
			// Remove Right Side Border in Tray for IE8
			if(GE5P.ge5p_is_msie8) {
				jQuery('#ge5p_z2-nav-bar .ge5p_z2-nav-bar-subnav .tray > div:last-child').css('border-right','medium none');
			}
			setTimeout(function(){
				var userInfoSpans = jQuery('#ge5p_z2-zipcode-inner').find('span');
				jQuery.each(userInfoSpans, function(key, value) {
					if (jQuery.trim(jQuery(this).html()).length > 0 ) {
						if(jQuery(this).children('a').is(':visible')) {
							GE5P.ge5p_theFirstVisibleIndex = key;
					        return false;
						}
					}
				});
				if(GE5P.ge5p_UA_isAndroid) {
					// Add ARIA roles/values to android devices
					GE5P.androidCatoAria();
				}
			}, 800);
		})
		.fail(function( jqxhr, textStatus, error ) {
			var err = textStatus + ', ' + error;
			//console.log( "Global Nav Service Request Failed: " + err);
		});
	},
	/* Function to reset the Body JS elements including ARIA attributes
	 * once the body is clicked and all the menu dropdowns are closed
	 **/
	bodyReset: function(event) {
		if(jQuery('.ge5p_z1-drop-down').hasClass('active') || jQuery('.ge5p_z2-nav-item').hasClass('active') || jQuery('.ge5p_z2-secondary-nav-el').parent().hasClass('active')) {
			$this = jQuery(event.target);
			/* Check if this was on a Z1 element */
			if($this.hasClass('ge5p_z1-drop-down') || $this.parents().hasClass('ge5p_z1-menu') || $this.parent().hasClass('ge5p_z1-tab')) {

			} else {
				if(jQuery('.ge5p_z1-language-drop-down > div.ge5p_z1-menu').is(':visible')) {
					// Check if this is a click event Lang sub menu is open
					if(event.type == 'click' || event.type == 'touchstart' || event.type == 'touchend') {
						GE5P.closeSegUtilNav();
					}
				} else {
					GE5P.closeSegUtilNav();
				}
			}
			/* Check if this was on a Z2 element */
			if($this.hasClass('ge5p_z2-primary-nav-el') || $this.hasClass('ge5p_z2-secondary-nav-el') || $this.parents().hasClass('ge5p_z2-nav-bar-subnav')) {
				// On Primary Item
			} else {
				GE5P.closePrimaryNavTrays();
				// Check if there are default Primary & Secondary Default elements - then show
				if(GE5P.ge5p_globalNavDefaultPrimaryActive.length > 0) {
					// Show the active Primary nav element
					$thisPrimaryActive = jQuery('.ge5p_z2-primary-nav-el.ge5p_z2-default-primary-active');
					$thisPrimaryActive.parent().addClass('active');
					$thisPrimaryActive.next().show();
					$thisPrimaryActive.attr('aria-expanded','true').attr('aria-selected','true');
					// Tray 1 height is Primary Nav Height + Primary Nav li.active
					var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
					// Increase height of PrimaryNav to show tray
					GE5P.animatePrimaryTray(heightTray1Open);
				}
			}
			if(GE5P.ge5p_supportsTouch) {
				// // Touch Device so add hidden-spoken
				jQuery('span.hidden-spoken').text('');
			}
			event.stopImmediatePropagation();
		}
	},
	/* Function to set the ARIA attributes once a main
	 * menu item with a sub menu is clicked
	 **/
	ariaEventSegUtilNav: function(event) {
		$this = jQuery(event.target);
		// Reset other Seg Util Nav ARIA attributes
		//jQuery('.ge5p_z1-menu ul').attr('aria-expanded', 'false').attr('aria-hidden', 'true');
		var x = setTimeout(function(){
			//$this.next().find('ul').attr('aria-expanded', 'true').attr('aria-hidden', 'false');
		}, GE5P.ge5p_dropDownSetTimeout);
	},
	/********************/
	/* Zone 1 Functions */
	/********************/
	/* Function to associate the key event
	 * with a Seg Util Nav
	 **/
	keyboardSegUtilNavAction: function(event) {
		$this = jQuery(event.target);
		$thisID = $this.attr('id');
		var keyCodeSegUtilNav = event.which;
		if (keyCodeSegUtilNav === 9 && event.shiftKey) {
			 if ($this.parent().hasClass('ge5p_z1-tab')) {
                 // Main menu item
                 jQuery('.ge5p_z1-drop-down').removeClass('active');
                 jQuery('.ge5p_z1-menu').hide();
                 setTimeout(function() {
                     $thisFocus = jQuery('#ge5p_z1-global-nav-container a:focus');
                     if ($thisFocus.hasClass('ge5p_z1-drop-down')) {
                         // Title element
                         // Check if Active - if so, move to Sub Menu
                         if ($thisFocus.parent().hasClass('active')) {
                             // Move to first sub menu item
                             $thisFocus.next().addClass('active').show();
                             $thisFocus.next().find('a').first().focus();
                         } else {
                            // First, remove "active" from all elements
                             jQuery('.ge5p_z1-drop-down').removeClass('active');
                             jQuery('.ge5p_z1-menu').hide();
                             // Add class "active" to a and menu to turn background white
                             $thisFocus.addClass('active');
                             $thisFocus.parent().find('div.ge5p_z1-menu').show();
                             // Reset ARIA
                             jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
                             $thisFocus.attr('aria-selected', 'true').attr('aria-expanded', 'true');
                         }
                     }
                 }, GE5P.ge5p_dropDownSetTimeout);
             }

		} else {
			switch(keyCodeSegUtilNav) {
				case 9: // Tab Key
					GE5P.ge5pZ1_navigate(event,'tab');
				break;
				case 13: // Enter key
					GE5P.ge5pZ1_navigate(event,'enter');
				break;
				case 38: // Up Arrow
					GE5P.ge5pZ1_navigate(event,'up');
				break;
				case 40: // Down Arrow
					GE5P.ge5pZ1_navigate(event,'down');
				break;
				case 32: // Space bar
				break;
				case 27: // Escape key
					GE5P.ge5pZ1_navigate(event,'escape');
					// Check if any menu items are open, if so, close
					GE5P.closeSegUtilNav();
				break;
			}
		}
	},
	/* Function to listen to keyboard action on Global Nav
	 **/
	ge5pZ1_navigate: function(event,direction) {
		$this = jQuery(event.target);
		$thisID = $this.attr('id');
		key = event.which;
		switch(direction) {
			case 'tab':
				setTimeout(function() {
					$thisFocus = jQuery('#ge5p_z1-global-nav-container a:focus');
					// Check if Title link or Sub Menu
					if ($thisFocus.hasClass('ge5p_z1-drop-down')) {
						// Title element
						// First, remove "active" from all elements
						jQuery('.ge5p_z1-drop-down').removeClass('active');
						jQuery('.ge5p_z1-menu').hide();
						// Add class "active" to a and menu to turn background white
						$thisFocus.addClass('active');
						$thisFocus.parent().find('div.ge5p_z1-menu').show();
						// Reset ARIA
						//jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
						jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
						$thisFocus.attr('aria-selected', 'true').attr('aria-expanded', 'true');
					} else {
						// Check for Regular Title Link
						if ($thisFocus.parent().hasClass('ge5p_z1-tab')) {
							jQuery('.ge5p_z1-drop-down').removeClass('active');
							jQuery('.ge5p_z1-menu').hide();
							// Reset ARIA
							jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
						} else {
							// Submenu link
							// Check if inside Language sub menu
							if ($this.parent().parent().hasClass('ge5p_z1-language_submenu')) {
								$thisIndex = $this.parent().index();
								$thisAllIndex = $this.parent().parent().find('li').length;
								$thisAllIndex = $thisAllIndex - 2;
								if ($thisIndex <= $thisAllIndex) {
									// Keep going
								} else {
									// End of Language link so close
									jQuery('.ge5p_z1-drop-down').removeClass('active');
									jQuery('.ge5p_z1-menu').hide();
									// Reset ARIA
									jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
								}
							} else {
							}
						}
					}
				}, GE5P.ge5p_dropDownSetTimeout);
				break;
			case 'enter':
				// No code needed
				break;
			case 'up':
				event.preventDefault();
				setTimeout(function() {
					$thisFocus = jQuery('#ge5p_z1-global-nav-container a:focus');
					if ($thisFocus.hasClass('ge5p_z1-drop-down')) {
						// Title, so do nothing
					}
					if($this.parent().hasClass('ge5p_z1-menuitem')) {
						$thisIndex = $this.parent().index();
						$thisAllIndex = $this.parent().parent().find('li').length;
						$thisAllIndex = $thisAllIndex - 1;
						if ($thisIndex == 0) {
							// Wrap around to bottom
							$this.parent().parent().find('a').last().focus();
							event.preventDefault();
						} else {
							// Check if there is a divider hr
							if ($this.parent().prev().find('hr').length) {
								// hr divider prev prev
								$this.parent().prev().prev().find('a').focus();
							} else {
								// Continue up sub menu
								$this.parent().prev().find('a').first().focus();
								event.preventDefault();
							}
						}
					}
				}, GE5P.ge5p_dropDownSetTimeout);
				break;
			case 'down':
				event.preventDefault();
				setTimeout(function() {
					$thisFocus = jQuery('#ge5p_z1-global-nav-container a:focus');
					// Check if Title link or Sub Menu
					if ($thisFocus.hasClass('ge5p_z1-drop-down')) {
						// Title, so move to first element in sub menu
						$thisFocus.next().find('a').first().focus();
					} else {
						// Check if this is a Menu Item
						if($this.parent().hasClass('ge5p_z1-menuitem')) {
							// Menu visible - check Index
							$thisIndex = $this.parent().index();
							$thisAllIndex = $this.parent().parent().find('li').length;
							$thisAllIndex = $thisAllIndex - 1;
							if($thisIndex < $thisAllIndex) {
								// Check if there is a divider hr
								if($this.parent().next().find('hr').length) {
									// hr divider next next
									$this.parent().next().next().find('a').focus();
								} else {
									$this.parent().next().find('a').focus();
								}
								event.preventDefault();
							} else {
								// loop back arround
								$this.parent().parent().find('a').first().focus();
								event.preventDefault();
							}
						}
					}
				}, GE5P.ge5p_dropDownSetTimeout);
				break;
		}
    },
	showSegUtilNav: function(event) {
		$this = jQuery(event.target);
		if ($this.hasClass('ge5p_z1-language-drop-down') || $this.parent().hasClass('ge5p_z1-menuitem')) {
		} else {
			jQuery('.ge5p_z1-drop-down').removeClass('active');
			jQuery('.ge5p_z1-menu').hide();
			jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
			// show menu
			$this.addClass('active');
			$this.next().addClass('active').show();
			$this.attr('aria-selected', 'true').attr('aria-expanded', 'true');
			if(GE5P.ge5p_supportsTouch) {
				// // Touch Device so add hidden-spoken
				$this.parent().find('span.hidden-spoken').text('Selected Menu Expanded');
			}
			event.preventDefault();
		}
	},
	toggleSegUtilNav: function(event) {
		$this = jQuery(event.target);
		GE5P.closePrimaryNavTrays();
		//event.stopPropagation();
        //event.preventDefault();
		// Check if menu title is active
		if($this.hasClass('ge5p_z1-language-drop-down')) {
			// Language Menu touched
			if ($this.hasClass('active')) {
				// Lang menu open
				$this.removeClass('active');
				$this.next().removeClass('active').hide();
				jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
				if(GE5P.ge5p_supportsTouch) {
					// // Touch Device so add hidden-spoken
					$this.parent().find('span.hidden-spoken').text('');
				}
			} else {
				// Lang menu closed, so open
				jQuery('.ge5p_z1-drop-down').removeClass('active');
				jQuery('.ge5p_z1-menu').hide();
				$this.addClass('active');
				$this.next().addClass('active').show();
				jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
				$this.attr('aria-selected', 'true').attr('aria-expanded', 'true');
				if(GE5P.ge5p_supportsTouch) {
					// // Touch Device so add hidden-spoken
					$this.parent().find('span.hidden-spoken').text('Selected Menu Expanded');
				}
			}
			return false;
		} else {
			// Other Menu

			if ($this.hasClass('active')) {
				// Continue to link
				$thisHREF = $this.arrt('href');
				$thisBlank = $this.attr('target');
				if($thisBlank) {
					window.open($thisHREF, '_blank');
				} else {
					window.location.href = $thisHREF;
				}
			} else {
				// Clear all sub menus
				jQuery('.ge5p_z1-drop-down').removeClass('active');
				jQuery('.ge5p_z1-menu').hide();
				// Open new sub menu
				$this.addClass('active');
				$this.next().addClass('active').show();
				jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
				$this.attr('aria-selected', 'true').attr('aria-expanded', 'true');
				if(GE5P.ge5p_supportsTouch) {
					// // Touch Device so add hidden-spoken
					$this.parent().find('span.hidden-spoken').text('Selected Menu Expanded');
				}
				return false;
			}
		}
	},
	toggleSegUtilLangNav: function(event) {
		$this = jQuery(event.target);
		if ($this.hasClass('active')) {
			// Lang menu open
			$this.removeClass('active');
			$this.next().removeClass('active').hide();
			jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
			if(GE5P.ge5p_supportsTouch) {
				// // Touch Device so add hidden-spoken
				$this.parent().find('span.hidden-spoken').text('');
			}
			event.preventDefault();
		} else {
			// Lang menu closed, so open
			jQuery('.ge5p_z1-drop-down').removeClass('active');
			jQuery('.ge5p_z1-menu').hide();
			$this.addClass('active');
			$this.next().addClass('active').show();
			jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
			$this.attr('aria-selected', 'true').attr('aria-expanded', 'true');
			if(GE5P.ge5p_supportsTouch) {
				// // Touch Device so add hidden-spoken
				$this.parent().find('span.hidden-spoken').text('Selected Menu Expanded');
			}
			event.preventDefault();
		}
		return false;
	},
	closeSegUtilNav: function() {
		jQuery('.ge5p_z1-drop-down').removeClass('active');
		jQuery('.ge5p_z1-menu').hide();
		jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
		if(GE5P.ge5p_supportsTouch) {
			// // Touch Device so add hidden-spoken
			jQuery('span.hidden-spoken').text('');
		}
	},
	/* ZONE 2 JS */
	keyboardUserInfo: function(event) {
		var $this = jQuery(event.target);
		var keyCodeUserInfo = event.which;
		$thisIndex = $this.parent(':visible').index();
		if (keyCodeUserInfo === 9 && event.shiftKey) {
			if($thisIndex == GE5P.ge5p_theFirstVisibleIndex) {
				event.preventDefault();
				// Reset Seg Menu
				jQuery('.ge5p_z1-drop-down').removeClass('active');
				jQuery('.ge5p_z1-menu').hide();
				jQuery('.ge5p_z1-drop-down').attr('aria-selected', 'false').attr('aria-expanded', 'false');
				// Open Language sub menu
				jQuery('#ge5p_z1-language-drop-down-link').addClass('active');
				jQuery('#ge5p_z1-language-drop-down-link').next().addClass('active').show();
				jQuery('#ge5p_z1-language-drop-down-link').attr('aria-selected', 'true').attr('aria-expanded', 'true');
				jQuery('#ge5p_z1-language-drop-down-link').focus();
			}
		}
	},
	primaryNavActionHover: function(event) {
		event.preventDefault();
		$this = jQuery(event.target); // Ensures lowest element in DOM was clicked - anchor tag
		if($this.parent().hasClass('ge5p_z2-primaryLogo')) {
			GE5P.closePrimaryNavTrays();
			return true;
		} else {
			if($this.parent().hasClass('active')) {
				// Follow to the URL of the link
				return true;
			} else {
				// Close Seg/Util Nav
				GE5P.closeSegUtilNav();
				// Tray open
				// Tray 1 = Primary Tray Open
				// Tray 2 = Secondary Tray Open
				// Remove "active" from all li's
				jQuery('.ge5p_z2-nav-item').removeClass('active');
				jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
				jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
				// Add class "active" to li to turn background white
				$this.parent().addClass('active');
				$this.attr('aria-expanded','true').attr('aria-selected','true');
				// Tray 1 height is Primary Nav Height + Primary Nav li.active
				var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
				// Increase height of PrimaryNav to show tray
				GE5P.animatePrimaryTray(heightTray1Open);
				return false;
			}
		}
	},
	primaryNavActionTouch: function(event) {
		$this = jQuery(event.target); // Ensures lowest element in DOM was clicked - anchor tag
		if($this.parent().hasClass('ge5p_z2-primaryLogo')) {
			GE5P.closePrimaryNavTrays();
			return true;
		} else {
			event.preventDefault();
			if($this.parent().hasClass('active')) {
				// Follow to the URL of the link
				$thisHREF = $this.attr('href');
				$thisBlank = $this.attr('target');
				if($thisBlank) {
					window.open($thisHREF, '_blank');
				} else {
					window.location.href = $thisHREF;
				}
			} else {
				// Close Seg/Util Nav
				GE5P.closeSegUtilNav();
				// Tray open
				// Tray 1 = Primary Tray Open
				// Tray 2 = Secondary Tray Open
				// Remove "active" from all li's
				jQuery('.ge5p_z2-nav-item').removeClass('active');
				jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
				jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
				// Add class "active" to li to turn background white
				$this.parent().addClass('active');
				$this.attr('aria-expanded','true').attr('aria-selected','true');
				if(GE5P.ge5p_supportsTouch) {
					// // Touch Device so add hidden-spoken
					$this.parent().find('span.hidden-spoken').text('Selected Menu Expanded');
				}
				// Tray 1 height is Primary Nav Height + Primary Nav li.active
				var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
				// Increase height of PrimaryNav to show tray
				GE5P.animatePrimaryTray(heightTray1Open);
				return false;
			}
		}
	},
	primaryNavActionFocus: function(event) {
		event.preventDefault();
		$this = jQuery(event.target); // Ensures lowest element in DOM was clicked - anchor tag
		if($this.parent().hasClass('ge5p_z2-primaryLogo')) {
			GE5P.closePrimaryNavTrays();
			return true;
		} else {
			// Close Seg/Util Nav
			GE5P.closeSegUtilNav();
			// Tray open
			// Tray 1 = Primary Tray Open
			// Tray 2 = Secondary Tray Open
			// Remove "active" from all li's
			jQuery('.ge5p_z2-nav-item').removeClass('active');
			jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
			jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
			// Add class "active" to li to turn background white
			$this.parent().addClass('active');
			$this.attr('aria-expanded','true').attr('aria-selected','true');
			// Tray 1 height is Primary Nav Height + Primary Nav li.active
			var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
			// Increase height of PrimaryNav to show tray
			GE5P.animatePrimaryTray(heightTray1Open);
			return false;
		}
	},
	secondaryNavActionHover: function(event) {
		event.preventDefault();
		GE5P.secondaryNavActionFocus(event);
	},
	secondaryNavActionTouch: function(event) {
		event.preventDefault();
		$this = jQuery(event.target); // Ensures lowest element in DOM was clicked - anchor tag
		// Check if the Secondary Menu has a Tray
		if($this.hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
			// Check to see if the Tray is already open, if so, follow to url
			if($this.next().hasClass('active')) {
				// Follow to the URL of the link
				$thisHREF = $this.attr('href');
				$thisBlank = $this.attr('target');
				if($thisBlank) {
					window.open($thisHREF, '_blank');
				} else {
					window.location.href = $thisHREF;
				}
			} else {
				jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
				jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
				$this.parent().addClass('active');
				$this.next().addClass('active').show();
				if(GE5P.ge5p_supportsTouch) {
					// // Touch Device so add hidden-spoken
					$this.parent().find('span.hidden-spoken').text('Selected Menu Expanded');
				}
				var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
				var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
				GE5P.animatePrimaryTray(heightTray2Open);
			}
		} else {
			// Follow to the URL of the link
			$thisHREF = $this.attr('href');
			window.location.href = $thisHREF;
		}
	},
	secondaryNavActionFocus: function(event) {
		event.preventDefault();
		var heightOfActiveTray = 0;
		$this = jQuery(event.target); // Ensures lowest element in DOM was clicked - anchor tag
		// Check if the Secondary Menu has a Tray
		if($this.hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
			// We have a Tray so display
			jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
			jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
			$this.parent().addClass('active');
			$this.next().addClass('active').show();
			var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
			var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
			if(GE5P.ge5p_is_msie8) {
				heightTray2Open = heightTray2Open + 1;
			}
			GE5P.animatePrimaryTray(heightTray2Open);
			//Make all column divs the height of tray
			heightOfActiveTray = jQuery('.tray.active').height();
			jQuery('.ge5p_z2-nav-bar-subnav').find('div.tray.active div').each(function(){
				jQuery(this).innerHeight(heightOfActiveTray);
			});
		} else {
			// Regular link in the Secondary menu so close the Tray
			jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
			jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
			$this.parent().addClass('active');
			var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
			GE5P.animatePrimaryTray(heightTray1Open);
		}
	},
	openPrimaryNavTray: function(event) {
		$this = jQuery(event.target);
		// Check if Tray is open
		if(jQuery('.ge5p_z2-nav-item').hasClass('active')) {
			// Secondary Menu Already Open
			jQuery('.ge5p_z2-nav-item').removeClass('active');
			// Add class "active" to li to turn background white
			$this.parent().addClass('active');
			$this.attr('aria-expanded','true').attr('aria-selected','true');
			// Then Open Secondary Nav Tray
			// Element is a Primary Nav so just open Sec Nav Tray if there is one
			$this.next().find('a').first().focus();
				$thisFocus = jQuery('.ge5p_z2-nav-bar-subnav a:focus');
				$thisFocus.next().addClass('active').show();
				$thisFocus.parent().addClass('active');
				jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
				$thisFocus.attr('aria-expanded','true').attr('aria-selected','true');
				var heightOfActiveTray = jQuery('.ge5p_z2-nav-bar-subnav div.tray.active').height();
				var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
				var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
				if(GE5P.ge5p_is_msie8) {
					heightTray2Open = heightTray2Open + 1;
				}
				GE5P.animatePrimaryTray(heightTray2Open);
				event.preventDefault();
		} else {
			if($this.parent().hasClass('ge5p_z2-primaryLogo')) {
				// Logo - so do nothing
			} else {
				// Not open so lets open it
				$this.parent().addClass('active');
				GE5P.heightPrimaryNavTray = jQuery('#ge5p_z2-nav-bar').find('li.active').height();
				GE5P.heightPrimaryNavOpen = GE5P.heightPrimaryNavClosed + GE5P.heightPrimaryNavTray;
				// Increase height of PrimaryNav to show tray
				GE5P.animatePrimaryTray(GE5P.heightPrimaryNavOpen);
				$this.attr('aria-expanded','true').attr('aria-selected','true');
				event.preventDefault();
			}
		}
	},
	openSecondaryNavTray: function(event,status) {
		$this = jQuery(event.target);
		// Check if the event is from a Primary or Secondary element
		if($this.hasClass('ge5p_z2-primary-nav-el')) {
			// Element is a Primary Nav so just open Sec Nav Tray if there is one
			$this.next().find('a').first().focus();
			jQuery('.ge5p_z2-nav-bar-subnav').find('a:focus').next().addClass('active').show();
			$this.next().find('a:focus').parent().addClass('active');
			jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
			var heightOfActiveTray = jQuery('.ge5p_z2-nav-bar-subnav div.tray.active').height();
			var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
			var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
			if(GE5P.ge5p_is_msie8) {
				heightTray2Open = heightTray2Open + 1;
			}
			GE5P.animatePrimaryTray(heightTray2Open);
			$this.next().find('a:focus').attr('aria-expanded','true').attr('aria-selected','true');
		} else {
			if($this.hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
				if(status == 'tab') {
					jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
					$this.attr('aria-expanded','true').attr('aria-selected','true');
				} else {
					jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
					jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
					$this.parent().addClass('active');
					// We have a Tray so display
					$this.next().addClass('active').show();
					var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
					var heightTray2Open = heightTray1Open + jQuery('.tray.active').height();
					//var heightTray2Open = heightTray1Open + heightOfActiveTray;
					if(GE5P.ge5p_is_msie8) {
						heightTray2Open = heightTray2Open + 1;
					}
					GE5P.animatePrimaryTray(heightTray2Open);
					//Make all column divs the height of tray
					var heightOfActiveTray = jQuery('.tray.active').height();
					if(GE5P.ge5p_is_msie8) {
						heightOfActiveTray = heightOfActiveTray - 1;
					}
					jQuery('.ge5p_z2-nav-bar-subnav').find('div.tray.active div').each(function(){
						jQuery(this).height(heightOfActiveTray);
					});
				}
			} else {
				// Regular link in the Secondary menu so close the Tray
				jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
				jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
				var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
				GE5P.animatePrimaryTray(heightTray1Open);
				jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
			}
		}
	},
	closePrimaryNavTrays: function() {
		GE5P.closeSecondaryNavTray();
		// Decrease height of PrimaryNav original size
		GE5P.animatePrimaryTray(GE5P.heightPrimaryNavClosed);
		jQuery('.ge5p_z2-nav-item').removeClass('active');
		jQuery('.ge5p_z2-primary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
		// Check if there are default Primary & Secondary Default elements - then show
	},
	closeSecondaryNavTray: function() {
		var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
		// Increase height of PrimaryNav to show tray
		GE5P.animatePrimaryTray(heightTray1Open);
		jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
		jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
		jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
	},
	/* Function to adjust height of Primary Nav depending on elements
	 **/
	animatePrimaryTray: function(height) {
		// Assign Primary nav element
		jQuery('#ge5p_z2-primary-nav').css('height', height);
		jQuery('#ge5p_z2-nav-bar li').css('height','auto');
		jQuery('.ge5p_z2-nav-bar-subnav li div.tray').css('height','auto');
	},
	/* Function to associate the key event
	 * with a Primary, Secondary and Tertiary Menus
	 **/
	keyboardPrimaryNavBar: function(event) {
		$this = jQuery(event.target);
		GE5P.keyCodePrimaryNav = event.which;
		if (GE5P.keyCodePrimaryNav === 9 && event.shiftKey) {
            // Treat Shift+Tab as reverse Tab
            $thisIndex = $this.parent().index();
            $thisAllIndex = $this.parent().parent().find('li').length;
            $thisAllIndex = $thisAllIndex - 1;
			// Check if on Primary Nav
            if($this.hasClass('ge5p_z2-primary-nav-el')) {
                // Inside Primary Nav - Either Logo/Shop/myAT&T/Support
                // Check if this is the First element
                if($thisIndex == 0) {
                    // Send focus to Login button
                    jQuery('#ge5p_z2-user-auth').focus();
                    event.preventDefault();
                } else if ($thisIndex == 1) {
                    // Send focus to Logo
                    jQuery('#primaryLogo').find('a').focus();
                    event.preventDefault();
                } else {
                    // Move to Previous Primary nav element
                    // Then down to the Secondary Tray and focus on last element
                    $this.parent().prev().find('a').focus();
                    jQuery('.ge5p_z2-secondary-nav-el').parent('.active').find('li').last().find('a').focus();
                    event.preventDefault();
                }
            }
            // Check if this is the Secondary Nav
			if($this.hasClass('ge5p_z2-secondary-nav-el')) {
				// Move focus to its Primary nav element if on first Secondary element
                if($thisIndex == 0) {
                    // First Secondary Tray element
					jQuery('.ge5p_z2-nav-item.active').find('a').first().focus();
					event.preventDefault();
                } else {
					// Check if Prev Secondary nav element has a tray
					if($this.parent().prev().find('a').hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
						jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
						jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
						$this.parent().prev().addClass('active');
						$this.parent().prev().find('div.tray').addClass('active').show();
						var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
						var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
						GE5P.animatePrimaryTray(heightTray2Open);
						$this.parent().prev().find('div > div:last-child').find('a').focus();
						event.preventDefault();
					}
				}
			}
            // Check if this is a Tertiary Nav
			if($this.hasClass('navTertiaryLink')) {
				$thisIndex = $this.parent().index(); // like 2
				$thisAllIndex = $this.parent().parent().find('li').length; // Like 5 links
				$thisAllIndex = $thisAllIndex - 1; // Adjust for index
				$thisDivIndex = $this.parentsUntil('.tray').closest('div').index();
				$tertiaryDivsIndex = $this.parents('div.tray').find('div').length; // This could be like 5 divs
				$tertiaryDivsIndex = $tertiaryDivsIndex - 1;
				if($thisIndex == 0) {
					if($thisDivIndex == 0) {
						// At beginning Div
						jQuery('ul.ge5p_z2-nav-bar-subnav').find('li.active').find('a').first().focus();
						event.preventDefault();
					} else {
						// Move to previous Div and focus on first element
						$this.parentsUntil('.tray').closest('div').prev().find('a').last().focus();
						event.preventDefault();
					}
				} else {
					// Move up an element
					$this.parent().prev().find('a').focus();
					event.preventDefault();
				}
			}
		} else {
			switch(GE5P.keyCodePrimaryNav) {
				case 9: // Tab Key
					GE5P.ge5pZ2_navigate(event,'tab');
				break;
				case 13: // Enter key
					GE5P.ge5pZ2_navigate(event,'enter');
				break;
				case 37: // Left Arrow
					GE5P.ge5pZ2_navigate(event,'left');
					event.preventDefault();
					event.stopPropagation();
					return false;
				case 38: // Up Arrow
					GE5P.ge5pZ2_navigate(event,'up');
					event.preventDefault();
					event.stopPropagation();
					return false;
				break;
				case 39: // Right Arrow
					GE5P.ge5pZ2_navigate(event,'right');
					event.preventDefault();
					event.stopPropagation();
					return false;
				case 40: // Down Arrow
					GE5P.ge5pZ2_navigate(event,'down');
					event.preventDefault();
					event.stopPropagation();
					return false;
				break;
				case 32: // Space bar
					GE5P.ge5pZ2_navigate(event,'space');
					event.preventDefault();
					event.stopPropagation();
					return false;
				break;
				case 27: // Escape key
					GE5P.ge5pZ2_navigate(event,'escape');
					event.preventDefault();
					event.stopPropagation();
				break;
			}
		}
	},
	/* Function for Primary, Secondary and Tertiary Menu
	 * keyboard events
	 **/
	ge5pZ2_navigate: function(event,direction) {
		$this = jQuery(event.target);
		$thisID = $this.attr('id');
		switch(direction) {
			case 'tab':
				// If Primary nav
				if($this.hasClass('ge5p_z2-primary-nav-el')) {
					GE5P.openPrimaryNavTray(event);
				}
				// If Secondary nav
				if($this.hasClass('ge5p_z2-secondary-nav-el')) {
					var status = 'tab';
					GE5P.openSecondaryNavTray(event,status);
				}
				if($this.hasClass('navTertiaryLink')) {
					$tertiaryDivsIndex = $this.parents('div.tray').find('div').length; // This could be like 5 divs
					$tertiaryDivsIndex = $tertiaryDivsIndex - 1;
					$thisIndex = $this.parent().index(); // Index we are currently at in the ul - like 0/1/2 etc.
					$thisDivIndex = $this.parentsUntil('.tray').closest('div').index();
					$tertiaryLength = $this.parent().parent().find('li').length; // This could be like 5 links
					$tertiaryLength = $tertiaryLength - 1;
					$primaryNavAllIndex = jQuery('#ge5p_z2-nav-bar > li').length - 2; // Because of Logo & Search - should be 3
					$primaryNavActiveIndex = jQuery('#ge5p_z2-nav-bar').find('li.active').index();
					if($thisIndex < $tertiaryLength) {
						$this.parent().next().find('a').focus();
						event.preventDefault();
					} else {
						// Ran out of Menu - check if there is another ul section or move up
						if($thisDivIndex < $tertiaryDivsIndex) {
							//$this.parent().parent().parent().next().find('a').first().focus();
							$this.parentsUntil('.tray').closest('div').next().find('a').first().focus();
							event.preventDefault();
						} else {
							// Ran out of divs, so check if there are more Secondary Nav elements
							// or send to Primary
							$thisAllIndex = $this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li').length; // like 8 links
							$thisAllIndex = $thisAllIndex - 1; // Adjust for 0 based index
							// Index of the Secondary element in the list
							$thisSecIndex = $this.parents('.ge5p_z2-nav-bar-subnav').find('li.active').index();
							// Check the elements location in the list
							if($thisSecIndex < $thisAllIndex) {
								// There is a next Secondary Nav element like "Bundles"
								$this.parent().parent().parent().parent().parent().next().find('a').first().focus();
								$this.parent().parent().parent().parent().parent().removeClass('active');
								$thisFocus = jQuery('.ge5p_z2-nav-bar-subnav a:focus');
								jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
								$thisFocus.parent().addClass('active');
								$thisFocus.parent().find('div.tray').addClass('active').show();
								var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
								var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
								if(GE5P.ge5p_is_msie8) {
									heightTray2Open = heightTray2Open + 1;
								}
								GE5P.animatePrimaryTray(heightTray2Open);
								event.preventDefault();
							} else {
								// Check if there are no more Primary Nav Tabs left to activate
								if($primaryNavActiveIndex < $primaryNavAllIndex) {
									// Up to Primary
									jQuery('#ge5p_z2-nav-bar').find('li.active').next().find('a').focus();
									jQuery('#ge5p_z2-nav-bar').find('li.active').next().addClass('active');
									event.preventDefault();
								} else {
									// Focus on search
									jQuery('#search').focus();
									event.preventDefault();
								}
							}
						}
					}
				}
				break;
			case 'escape':
				//If at Tertiary level
				if($this.hasClass('navTertiaryLink')) {
					// Move focus to its Primary Nav Element
					jQuery('.ge5p_z2-nav-item.active').find('a').first().focus();
					event.preventDefault();
					GE5P.closeSecondaryNavTrays();
				}
				break;
			case 'enter':
				// If Primary nav
				if($this.hasClass('ge5p_z2-primary-nav-el')) {
					if($this.parent().hasClass('ge5p_z2-primaryLogo')) {
						return true;
					} else {
						// Check if Primary menu is open, if so, close
						if(jQuery('.ge5p_z2-nav-bar-subnav').is(':visible')) {
							// Close
							return true;
						} else {
							event.preventDefault();
							// Open Primary Tray
							GE5P.openPrimaryNavTray(event);
						}
					}
				}
				if($this.hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
					return true;
				}
				// If Tertiary Nav
				if($this.hasClass('navTertiaryLink')) {
					return true;
				}
				break;
			case 'left':
				event.preventDefault();
				// If Primary nav
				if($this.hasClass('ge5p_z2-primary-nav-el')) {
					$thisIndex = $this.parent().index();
					$primaryNavAllIndex = jQuery('#ge5p_z2-nav-bar > li').length - 2; // Because of Logo & Search - should be 3
					if($thisIndex == 1) {
						jQuery('#ge5p_z2-nav-bar li').last().prev().find('a').first().focus();
					} else {
						$this.parent().prev().find('a').first().focus();
					}
				}
				// If Secondary Nav
				if($this.hasClass('ge5p_z2-secondary-nav-el')) {
					$thisIndex = $this.parent().index();
					$thisAllIndex = $this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li').length;
					$thisAllIndex = $thisAllIndex - 1;
					if($thisIndex == 0) {
						$this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li:last-child').find('a').first().focus();
						if($this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li:last-child a:focus').hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							$this.parent().last().addClass('active');
							// We have a Tray so display
							$this.parent().last().find('a:focus').next().addClass('active').show();
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
							GE5P.animatePrimaryTray(heightTray2Open);
							//Make all column divs the height of tray
							var heightOfActiveTray = jQuery('.ge5p_z2-nav-bar-subnav div.tray.active').height();
							jQuery('.ge5p_z2-nav-bar-subnav').find('div.tray.active div').each(function(){
								jQuery(this).height(heightOfActiveTray);
							});
							jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
							$this.parent().last().find('a:focus').attr('aria-expanded','true').attr('aria-selected','true');
						} else {
							// Regular link in the Secondary menu so close the Tray
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							GE5P.animatePrimaryTray(heightTray1Open);
							jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
							$this.parent().last().find('a:focus').attr('aria-expanded','false').attr('aria-selected','true');
						}
					} else {
						$this.parent().prev().find('a').first().focus();
						if($this.parent().prev().find('a:focus').hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							$this.parent().prev().addClass('active');
							// We have a Tray so display
							$this.parent().prev().find('a:focus').next().addClass('active').show();
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
							GE5P.animatePrimaryTray(heightTray2Open);
							//Make all column divs the height of tray
							var heightOfActiveTray = jQuery('.ge5p_z2-nav-bar-subnav div.tray.active').height();
							jQuery('.ge5p_z2-nav-bar-subnav').find('div.tray.active div').each(function(){
								jQuery(this).height(heightOfActiveTray);
							});
							jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
							$this.parent().prev().find('a:focus').attr('aria-expanded','true').attr('aria-selected','true');
						} else {
							// Regular link in the Secondary menu so close the Tray
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							GE5P.animatePrimaryTray(heightTray1Open);
							jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
							$this.parent().prev().find('a:focus').attr('aria-expanded','false').attr('aria-selected','true');
						}
					}
				}
				// If Tertiary Nav
				if($this.hasClass('navTertiaryLink')) {
					$tertiaryDivsIndex = $this.parents('div.tray').find('div').length; // This could be like 5 divs
					$tertiaryDivsIndex = $tertiaryDivsIndex - 1;
					$thisIndex = $this.parent().index(); // Index we are currently at in the ul - like 0/1/2 etc.
					$thisDivIndex = $this.parentsUntil('.tray').closest('div').index();
					$tertiaryLength = $this.parent().parent().find('li').length; // This could be like 5 links
					$tertiaryLength = $tertiaryLength - 1;
					$primaryNavAllIndex = jQuery('#ge5p_z2-nav-bar > li').length - 2; // Because of Logo & Search - should be 3
					$primaryNavActiveIndex = jQuery('#ge5p_z2-nav-bar').find('li.active').index();
					if($thisIndex == 0) {
						if($thisDivIndex == 0) {
							// At the first element of the first div, move focus to last div last element
							$this.parents('div.tray').find('div').last().find('a').last().focus();
						} else {
							$this.parent().parent().parent().prev().find('a').last().focus();
						}
					} else {
						$this.parent().prev().find('a').first().focus();
					}
				}
				break;
			case 'right':
				event.preventDefault();
				if($this.hasClass('ge5p_z2-primary-nav-el')) {
					$thisIndex = $this.parent().index();
					$primaryNavAllIndex = jQuery('#ge5p_z2-nav-bar > li').length - 2; // Because of Logo & Search - should be 3
					if($thisIndex == $primaryNavAllIndex) {
						jQuery('#ge5p_z2-nav-bar li').first().next().find('a').first().focus();
					} else {
						$this.parent().next().find('a').first().focus();
					}
				}
				// If Secondary Nav
				if($this.hasClass('ge5p_z2-secondary-nav-el')) {
					$thisIndex = $this.parent().index();
					$thisAllIndex = $this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li').length;
					$thisAllIndex = $thisAllIndex - 1;
					if($thisIndex == $thisAllIndex) {
						$this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li:first-child').find('a').first().focus();
						// Check if next parent has a tray
						if($this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li:first-child a:focus').hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							$thisNEXT = $this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li:first-child a:focus');
							$thisNEXT.parent().addClass('active');

							// We have a Tray so display
							$thisNEXT.next().addClass('active').show();
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
							GE5P.animatePrimaryTray(heightTray2Open);
							//Make all column divs the height of tray
							var heightOfActiveTray = jQuery('.ge5p_z2-nav-bar-subnav div.tray.active').height();
							jQuery('.ge5p_z2-nav-bar-subnav').find('div.tray.active div').each(function(){
								jQuery(this).height(heightOfActiveTray);
							});
							jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
							$this.attr('aria-expanded','true').attr('aria-selected','true');
						} else {
							// Regular link in the Secondary menu so close the Tray
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							GE5P.animatePrimaryTray(heightTray1Open);
							jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
							$this.attr('aria-expanded','false').attr('aria-selected','true');
						}
					} else {
						$this.parent().next().find('a').first().focus();
						$thisNEXT = $this.parent().next().find('a:focus');
						// Check if next parent has a tray
						if($this.parent().next().find('a:focus').hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							$thisNEXT.parent().addClass('active');

							// We have a Tray so display
							$thisNEXT.next().addClass('active').show();
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
							if(GE5P.ge5p_is_msie8) {
								heightTray2Open = heightTray2Open + 1;
							}
							GE5P.animatePrimaryTray(heightTray2Open);
							//Make all column divs the height of tray
							var heightOfActiveTray = jQuery('.ge5p_z2-nav-bar-subnav div.tray.active').height();
							jQuery('.ge5p_z2-nav-bar-subnav').find('div.tray.active div').each(function(){
								jQuery(this).height(heightOfActiveTray);
							});
							jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
							$thisNEXT.attr('aria-expanded','true').attr('aria-selected','true');
						} else {
							// Regular link in the Secondary menu so close the Tray
							jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
							jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
							var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
							GE5P.animatePrimaryTray(heightTray1Open);
							jQuery('.ge5p_z2-secondary-nav-el').attr('aria-expanded','false').attr('aria-selected','false');
							$this.attr('aria-expanded','false').attr('aria-selected','true');
						}
					}
				}
				// If Tertiary Nav
				if($this.hasClass('navTertiaryLink')) {
					$tertiaryDivsIndex = $this.parents('div.tray').find('div').length; // This could be like 5 divs
					$tertiaryDivsIndex = $tertiaryDivsIndex - 1;
					$thisIndex = $this.parent().index(); // Index we are currently at in the ul - like 0/1/2 etc.
					$thisDivIndex = $this.parentsUntil('.tray').closest('div').index();
					$tertiaryLength = $this.parent().parent().find('li').length; // This could be like 5 links
					$tertiaryLength = $tertiaryLength - 1;
					$primaryNavAllIndex = jQuery('#ge5p_z2-nav-bar > li').length - 2; // Because of Logo & Search - should be 3
					$primaryNavActiveIndex = jQuery('#ge5p_z2-nav-bar').find('li.active').index();
					if($thisIndex < $tertiaryLength) {
						if($thisDivIndex < $tertiaryDivsIndex) {
							$this.parent().next().find('a').first().focus();
						} else {
							if($thisIndex < $tertiaryLength) {
								$this.parent().next().find('a').first().focus();
							} else {
								$this.parents('div.tray').find('div').first().find('a').first().focus();
							}
						}
					} else {
						if($thisDivIndex < $tertiaryDivsIndex) {
							$this.parent().parent().parent().next().find('a').first().focus();
						} else {
							$this.parents('div.tray').find('div').first().find('a').first().focus();
						}
					}
				}
				break;
			case 'down':
				// Check if this is Primary level
				if($this.parent().hasClass('ge5p_z2-nav-item')) {
					// Check if Primary is active
					if($this.parent().hasClass('active')) {
						// If yes, move to First Secondary Nav element
						$this.next().find('a').first().focus();
						$this.next().find('a').first().parent().addClass('active');
						GE5P.openSecondaryNavTray(event);
						event.preventDefault();
					} else {
						// Primary Menu is not active and Secondary Tray is not open
						GE5P.openPrimaryNavTray(event);
					}
				}
				// Check if this is the Secondary level
				if($this.hasClass('ge5p_z2-secondary-nav-el')) {
					// This Elements Index (place in the list);
					$thisIndex = $this.parent().index();
					// All Elements in the list (length)
					$thisAllIndex = $this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li').length;
					$thisAllIndex = $thisAllIndex - 1;

					// Check if Secondary Title is active
					if($this.parent().hasClass('active')) {
						// If yes, move to Tertiary Element
						// Check if this is the first
						GE5P.openSecondaryNavTray(event);
						$this.next().find('a').first().focus();
					} else {
						// If not, open Secondary
						// Check if link has Secondary Tray
						if($this.hasClass('ge5p_z2-nav-bar-subnav-has-tray')) {
							GE5P.openSecondaryNavTray(event);
							$this.next().find('a').first().focus();
						} else {
							// Check if this is the last element
							if($thisIndex < $thisAllIndex) {
								// Move to next element in Secondary Nav
								$this.parent().next().find('a').focus();
							} else {
								// Reached the end of the Secondary Nav Elements
								// Move up DOM to Primary Level
								jQuery('#ge5p_z2-nav-bar').find('li.active').next().find('a').first().focus();
							}
						}
					}
				}
				// Check if this is the Tertiary level
				if($this.hasClass('navTertiaryLink')) {
					$tertiaryDivsIndex = $this.parents('div.tray').find('div').length; // This could be like 5 divs
					$tertiaryDivsIndex = $tertiaryDivsIndex - 1;
					$thisIndex = $this.parent().index(); // Index we are currently at in the ul - like 0/1/2 etc.
					$thisDivIndex = $this.parentsUntil('.tray').closest('div').index();
					$tertiaryLength = $this.parent().parent().find('li').length; // This could be like 5 links
					$tertiaryLength = $tertiaryLength - 1;
					$primaryNavAllIndex = jQuery('#ge5p_z2-nav-bar > li').length - 2; // Because of Logo & Search - should be 3
					$primaryNavActiveIndex = jQuery('#ge5p_z2-nav-bar').find('li.active').index();

					if($thisIndex < $tertiaryLength) {
						$this.parent().next().find('a').focus();
					} else {
						// Ran out of Menu - check if there is another ul section or move up
						if($thisDivIndex < $tertiaryDivsIndex) {
							//$this.parent().parent().parent().next().find('a').first().focus();
							$this.parentsUntil('.tray').closest('div').next().find('a').first().focus();
						} else {
							// Ran out of divs, so check if there are more Secondary Nav elements
							// or send to Primary
							$thisAllIndex = $this.parents('.ge5p_z2-nav-item.active').find('.ge5p_z2-nav-bar-subnav > li').length; // like 8 links
							$thisAllIndex = $thisAllIndex - 1; // Adjust for 0 based index
							// Index of the Secondary element in the list
							$thisSecIndex = $this.parents('.ge5p_z2-nav-bar-subnav').find('li.active').index();
							// Check the elements location in the list
							if($thisSecIndex < $thisAllIndex) {
								// There is a next element
								jQuery('ul.ge5p_z2-nav-bar-subnav').find('li.active').next().find('a').focus();
								GE5P.openSecondaryNavTray(event);

							} else {
								// Check if there are no more Primary Nav Tabs left to activate
								if($primaryNavActiveIndex < $primaryNavAllIndex) {
									// Up to Primary
									jQuery('#ge5p_z2-nav-bar').find('li.active').next().find('a').focus();
									jQuery('#ge5p_z2-nav-bar').find('li.active').next().addClass('active');
								} else {
									// Focus on search
									jQuery('#search').focus();
								}
							}
						}
					}
				}
				break;
			case 'up':
				// Check if Primary Level
				if($this.parent().hasClass('ge5p_z2-nav-item')) {
					// Check if Primary is active
					if($this.parent().hasClass('active')) {
						// Close the Primary Nav Tray
						//GE5P.closePrimaryNavTrays(); KEEP OPEN
					}
				}
				// Check if Secondary Level
				if($this.hasClass('ge5p_z2-secondary-nav-el')) {
                    // Find Secondary Tray element and focus on
					jQuery('.ge5p_z2-nav-item.active').find('a').first().focus();
					event.preventDefault();
                }
				// Check if Tertiary Level
				if($this.hasClass('navTertiaryLink')) {
					$thisIndex = $this.parent().index(); // like 2
					$thisAllIndex = $this.parent().parent().find('li').length; // Like 5 links
					$thisAllIndex = $thisAllIndex - 1; // Adjust for index
					$thisDivIndex = $this.parentsUntil('.tray').closest('div').index();
					$tertiaryDivsIndex = $this.parents('div.tray').find('div').length; // This could be like 5 divs
					$tertiaryDivsIndex = $tertiaryDivsIndex - 1;
					if($thisIndex == 0) {
						if($thisDivIndex == 0) {
							// At beginning Div
							jQuery('ul.ge5p_z2-nav-bar-subnav').find('li.active').find('a').first().focus();
							event.preventDefault();
							//GE5P.closeSecondaryNavTray(); KEEP OPEN

						} else {
							// Move to previous Div and focus on first element
							$this.parentsUntil('.tray').closest('div').prev().find('a').last().focus();
							event.preventDefault();
						}
					} else {
						// Move up an element
						$this.parent().prev().find('a').focus();
						event.preventDefault();
					}
				}
				break;
		}
	},
	/* USER INFO DATA FUNCTION */
	/* Function to collect and display user info including zip and register info
	**/
	userInfoData: function() {
		// Find Cookie info
		// Look up attPersistantLocalization cookie on user system
		// Remove cookie json
		jQuery.cookie.json = false;
		if(jQuery.cookie("attPersistantLocalization")) { //attPersistantLocalization
			var ge5pZ2_valueCookie = jQuery.cookie('attPersistantLocalization');
			ge5pZ2_valueCookieArr = ge5pZ2_valueCookie.split('|');
			// State = arr 3, City = arr 4, Zip = arr 6
			// City
			var ge5pZ2_zipCode_City = jQuery.trim(ge5pZ2_valueCookieArr[4]).split('=')[1];
			// State
			var ge5pZ2_zipCode_State = GE5P.ge5p_z2_getStateAbbreviationByName(jQuery.trim(ge5pZ2_valueCookieArr[3]).split('=')[1]);
			// Zip
			var ge5pZ2_zipCode_Zip = jQuery.trim(ge5pZ2_valueCookieArr[6]).split('=')[1];
			// Change values in Zone 2 Zip Code block
			jQuery('#ge5p_z2-zipcode-city').html(ge5pZ2_zipCode_City +', ');
			jQuery('#ge5p_z2-zipcode-state').html(ge5pZ2_zipCode_State);
			jQuery('#ge5p_z2-zipcode-zip').html(ge5pZ2_zipCode_Zip);
			jQuery('.ge5p_z2-zipcode-enter').hide();
			jQuery('.ge5p_z2-zipcode-change').show();
			jQuery('#ge5p_z2-zipcode-city').show();
			jQuery('#ge5p_z2-zipcode-state').show();
			jQuery('#ge5p_z2-zipcode-zip').show();
		} else {
			// attPersistantLocalization is not found, so check for
			// server vars that contain the Akamai data
			if(GE5P.ge5p_userCityVar || GE5P.ge5p_userStateVar || GE5P.ge5p_userZipCodeVar) {
				if(GE5P.ge5p_userCityVar.length > 0 || GE5P.ge5p_userStateVar.length > 0 || GE5P.ge5p_userZipCodeVar.length > 0) {
					jQuery('.ge5p_z2-zipcode-enter').hide();
					jQuery('.ge5p_z2-zipcode-change').show();
					jQuery('#ge5p_z2-zipcode-city').show();
					jQuery('#ge5p_z2-zipcode-state').show();
					jQuery('#ge5p_z2-zipcode-zip').show();
				} else {
					jQuery('.ge5p_z2-zipcode-enter').show();
				}
			} else {
				jQuery('.ge5p_z2-zipcode-enter').show();
			}
			if(GE5P.ge5p_userCityVar) {
				if(GE5P.ge5p_userCityVar.length > 0) {
					jQuery('#ge5p_z2-zipcode-city').text(GE5P.ge5p_userCityVar +', ');
					jQuery('#ge5p_z2-zipcode-city').show();
				}
			}
			if(GE5P.ge5p_userStateVar) {
				if(GE5P.ge5p_userStateVar.length > 0) {
					jQuery('#ge5p_z2-zipcode-state').text(GE5P.ge5p_userStateVar);
					jQuery('#ge5p_z2-zipcode-state').show();
				}
			}
			if(GE5P.ge5p_userZipCodeVar) {
				if(GE5P.ge5p_userZipCodeVar.length > 0) {
					jQuery('#ge5p_z2-zipcode-zip').html(' '+GE5P.ge5p_userZipCodeVar);
					jQuery('#ge5p_z2-zipcode-zip').show();
				}
			}
		}
		/* Dynamic styles if elements exist */
		//State
		if(jQuery('#ge5p_z2-zipcode-state').text().length > 0) {
			jQuery('#ge5p_z2-zipcode-state').css('padding-right', '5px');
		}
	},
	/* STATE ABBREVIATION FUNCTION */
	/* Function to change long state name into short abbreviation
	**/
	ge5p_z2_getStateAbbreviationByName: function(state){
		var $state = state;
		if ($state=="Alaska"){ return "AK"; }
		if ($state=="Alabama"){ return "AL"; }
		if ($state=="Arkansas"){ return "AR"; }
		if ($state=="Arizona"){ return "AZ"; }
		if ($state=="California"){ return "CA"; }
		if ($state=="Colorado"){ return "CO"; }
		if ($state=="Connecticut"){ return "CT"; }
		if ($state=="District of Columbia"){ return "DC"; }
		if ($state=="Delaware"){ return "DE"; }
		if ($state=="Florida"){ return "FL"; }
		if ($state=="Georgia"){ return "GA"; }
		if ($state=="Hawaii"){ return "HI"; }
		if ($state=="Iowa"){ return "IA"; }
		if ($state=="Idaho"){ return "ID"; }
		if ($state=="Illinois"){ return "IL"; }
		if ($state=="Indiana"){ return "IN"; }
		if ($state=="Kansas"){ return "KS"; }
		if ($state=="Kentucky"){ return "KY"; }
		if ($state=="Louisiana"){ return "LA"; }
		if ($state=="Massachusetts"){ return "MA"; }
		if ($state=="Maryland"){ return "MD"; }
		if ($state=="Maine"){ return "ME"; }
		if ($state=="Michigan"){ return "MI"; }
		if ($state=="Minnesota"){ return "MN"; }
		if ($state=="Missouri"){ return "MO"; }
		if ($state=="Mississippi"){ return "MS"; }
		if ($state=="Montana"){ return "MT"; }
		if ($state=="North Carolin"){ return "NCa"; }
		if ($state=="North Dakota"){ return "ND"; }
		if ($state=="Nebraska"){ return "NE"; }
		if ($state=="New Hampshire"){ return "NH"; }
		if ($state=="New Jersey"){ return "NJ"; }
		if ($state=="New Mexico"){ return "NM"; }
		if ($state=="Nevada"){ return "NV"; }
		if ($state=="New York"){ return "NY"; }
		if ($state=="Ohio"){ return "OH"; }
		if ($state=="Oklahoma"){ return "OK"; }
		if ($state=="Oregon"){ return "OR"; }
		if ($state=="Pennsylvania"){ return "PA"; }
		if ($state=="Rhode Island"){ return "RI"; }
		if ($state=="South Carolina"){ return "SC"; }
		if ($state=="South Dakota"){ return "SD"; }
		if ($state=="Tennessee"){ return "TN"; }
		if ($state=="Texas"){ return "TX"; }
		if ($state=="Utah"){ return "UT"; }
		if ($state=="Virginia"){ return "VA"; }
		if ($state=="Vermont"){ return "VT"; }
		if ($state=="Washington"){ return "WA"; }
		if ($state=="Wisconsin"){ return "WI"; }
		if ($state=="West Virginia"){ return "WV"; }
		if ($state=="Wyoming"){ return "WY"; }
	},
	androidCatoAria: function(event) {
		setTimeout(function(){
			/* Add Accessibility attributes */
			/* Global - Seg/Util Nav */
			jQuery('#ge5p_z1-nav-left-seg').attr('role','menubar');
			jQuery('#ge5p_z1-nav-right-seg').attr('role','menubar');
			jQuery('#ge5p_z1-nav-left-seg li').attr('role','presentation');
			jQuery('#ge5p_z1-nav-right-seg li').attr('role','presentation');
			jQuery('.ge5p_z1-drop-down').attr('role','button').attr('aria-haspopup','true');
			jQuery('.ge5p_z1-menu ul').attr('role','menu').attr('aria-expanded','false').attr('aria-hidden','true');
			jQuery('.ge5p_z1-menu ul li').attr('role','presentation');
			jQuery('.ge5p_z1-menu ul li a').attr('role','menuitem').attr('tabindex','0');
		}, 1000);
	},
	/* SEARCH SHIFT-TAB FUNCTION */
	/* Function to set focus on Support element off shift tab from #search
	**/
	keyboardGNSearchBox: function(event) {
		$this = jQuery(event.target);
		$thisID = $this.attr('id');
        keyCodePrimaryNav = event.which;
		if (keyCodePrimaryNav === 9 && event.shiftKey) {
            // Treat Shift+Tab as reverse Tab
			jQuery('.ge5p_z2-nav-bar-subnav li').removeClass('active');
			jQuery('.ge5p_z2-nav-bar-subnav li').find('div.tray').removeClass('active').hide();
			var $priSearch = $this.parents('#primary_Search');
			$priSearch.prev().addClass('active');
			$priSearch.prev().find('div.tray').addClass('active').show();
			jQuery('div.tray.active').parent().last().addClass('active');
			$priSearch.prev().find('div > div:last-child').find('a').focus();
			var heightTray1Open = GE5P.heightPrimaryNavClosed + jQuery('#ge5p_z2-nav-bar li.active').height();
			var heightTray2Open = heightTray1Open + jQuery('.ge5p_z2-nav-bar-subnav li div.tray.active').height();
			GE5P.animatePrimaryTray(heightTray2Open);
			event.preventDefault();
		}
	},
	/* SEARCH VALIDATEE FUNCTION */
	/* Function to validate value in Primary nav search
	**/
	validateSearchForm: function(event) {
		$this = jQuery(this);
		$searchVal = jQuery('#search').val();
		if($searchVal.toLowerCase() == 'search' || $searchVal.toLowerCase() == 'buscar' || $searchVal == '') {
			alert('Please enter at least one keyword in the Search box.');
			jQuery('#search').focus();
			event.preventDefault();
		}
		else{
			return;
		}
	},
	/* SEARCH AUTOCOMPLETE FUNCTION */
	/* Function to show autocomplete suggestion box for Primary nav search
	**/
	searchAutocomplete: function() {
		//global autosuggest code
		var client_id = 1;
		var isValidChar = /^[a-zA-Z0-9\,.#&'\- ]{1,}$/, initVal = "", self, srch = jQuery('#search'); //new to handle spanish
		var srch = jQuery('#search');
		var srchForm = jQuery('#searchForm');
		srch.focus(function(){
			//Close menus
			GE5P.closeSegUtilNav();
			GE5P.closePrimaryNavTrays();
			self = jQuery(this);
			if(self.val().toLowerCase() == 'search'){
				self.val('');
				return initVal = "Search"; //new to handle spanish
			}
			else if(self.val().toLowerCase() == 'buscar'){ //new to handle spanish
				self.val('');
				return initVal = "Buscar";
			}
		});
		srch.blur(function(){
			self = jQuery(this);
			var searchStr = self.val();
			searchStr = searchStr.replace(/\s+/g, ' ');
			self.val(jQuery.trim(searchStr));
			if(!isValidChar.test(searchStr)){
				self.val(initVal); //new to handle Spanish
			}
		});

		var autoSuggestBox = jQuery("#autoSuggestBox");
		var ui_autocomplete = jQuery(".ui-autocomplete");
		var srch = jQuery("#search");
		var asState = jQuery('input[name="autoSuggest"]');

		asState.val("FALSE"); //set hidden field to false as default until autosuggest is utilized and changes to TRUE in the select property below.

		jQuery("#search").autocomplete({
			appendTo:"#autoSuggestBox",
			delay: 0,
			minLength: 1,
			open: function(event, ui) {
				autoSuggestBox.show();
				ui_autocomplete.css({"top":"0px","left":"0px","overflow":"auto"});
			},
			close: function(event, ui) {
				autoSuggestBox.hide();
			},
			position: { my : "left top", at: "left top", of:"#autoSuggestBox", collision: "fit"},
			select: function(event, ui) {
				srch.val(ui.item.value);
				asState.val("TRUE");
				srchForm.submit();
			},
			source: function(request, response) {
				jQuery.ajax({
					url: "//www.att.com/global-search/gs_autosuggest.jsp?q=" + srch.val() + "&callback=insertAutoSuggestions",
					dataType: "jsonp",
					jsonpCallback: "insertAutoSuggestions",
					success: function(data) {
						var ra = [];
						if(data.length == 0) {
							jQuery("#autoSuggestBox").hide();
							return false;
						} else {
							jQuery.each(data, function(raindex, raval){
								ra[raindex] = {"label": raval["short"], "value": raval["short"]};
							});
							response(ra);
						}
					}
				});
			}
		});
	},
	changeLanguage: function(event) {
		$this = jQuery(event.target);
		var rurl = jQuery.url(GE5P.ge5p_requestURLVar); // Using jQuery purl plugin
		var file = rurl.attr('file'); // Returns file name ex. wireless.html
		var requesturl = $this.attr('href');
		//GE5P.ge5p_changeLanguageURLVar
		if(jQuery('.ge5p_z1-language_submenu li').first().find('a').hasClass('en_US')) {
			var locale = 'es_US';
			var lan = 'es/';
		} else {
			var locale = 'en_US';
			var lan = '/';
		}
		if(jQuery.cookie("GNSESS")) {
			// Cookie exists so update
			GE5P.updateGNSESSCookie(locale,requesturl);
		} else {
			// Create new GNSESS cookie
			GE5P.createGNSESSCookie(locale,requesturl);
		}
		event.preventDefault();
		return false;
	},
	createGNSESSCookie: function(locale,requesturl) {
		jQuery.cookie.json = true;
		var cookieObj = {};
		var ugarray=["Unauth"];
		var ska=["1","jsp"];
		cookieObj['UG'] = ugarray;
		cookieObj['LOCALE'] = locale;
		cookieObj['SKA'] = ska;
		// Write cookie using jQuery Cookie Plugin
		jQuery.cookie.raw=true;
		jQuery.cookie('GNSESS', cookieObj, {
			domain: '.att.com',
			path: '/'
		});
		window.location.href = requesturl;
	},
	updateGNSESSCookie: function(locale,requesturl) {
		jQuery.cookie.json = true;
		var valueCookie = jQuery.cookie('GNSESS')
		if(typeof valueCookie == "object"){
			valueCookie = JSON.stringify(valueCookie);
		}
		var GNSESSObj = jQuery.parseJSON(valueCookie);
		var newObj = {};
		jQuery.each(GNSESSObj, function(key, val){
		   newObj[key] = GNSESSObj[key];
		   if(key == 'LOCALE' && val == 'en_US'){
			   newObj[key]='es_US';
		   } else if(key == 'LOCALE' && val == 'es_US'){
			   newObj[key]='en_US';
		   }
		});
		jQuery.cookie.raw=true;
		jQuery.cookie('GNSESS', newObj, {
			domain: '.att.com',
			path: '/'
		});
		window.location.href = requesturl;
	}
} // End GE5P Var

/* Confirm Document is in ready state
 * before firing init function */
var tid = setInterval( function () {
    if ( document.readyState !== 'complete' ) return;
    clearInterval( tid );
    jQuery(document).ready(function() {
		/*********************************
		 *
		 *  US18190 - Segmentation/Utilities Bar -
		 *  Accessibility compliant - current production
		 *  Created on 8/12/2013
		 *  Consumer Digital IT Solutions - rb205p
		 *  Initialize GE5P var
		 *  THIS IS REQUIRED for global navigation to function
		 *
		 **********************************/
		GE5P.Init();
		if(!GE5P.ge5p_is_msie8) {
			document.head = typeof document.head != "object" ? document.getElementsByTagName("head")[0] : document.head;
			jQuery("link").each(function(key,value) {
				var styleLink = value.href;
				if (styleLink.toLowerCase().indexOf("ge5p_global_ie.css") >= 0) {
					jQuery(this).attr('disabled', 'disabled');
					jQuery(this).remove();
				}
			});
		}
	});
}, 100 );

/*!
 * jQuery Cookie Plugin v1.3.1
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2013 Klaus Hartl
 * Released under the MIT license
*/
(function(a,b,c){function e(a){return a}function f(a){return g(decodeURIComponent(a.replace(d," ")))}function g(a){return 0===a.indexOf('"')&&(a=a.slice(1,-1).replace(/\\"/g,'"').replace(/\\\\/g,"\\")),a}function h(a){return i.json?JSON.parse(a):a}var d=/\+/g,i=a.cookie=function(d,g,j){if(g!==c){if(j=a.extend({},i.defaults,j),null===g&&(j.expires=-1),"number"==typeof j.expires){var k=j.expires,l=j.expires=new Date;l.setDate(l.getDate()+k)}return g=i.json?JSON.stringify(g):g+"",b.cookie=[encodeURIComponent(d),"=",i.raw?g:encodeURIComponent(g),j.expires?"; expires="+j.expires.toUTCString():"",j.path?"; path="+j.path:"",j.domain?"; domain="+j.domain:"",j.secure?"; secure":""].join("")}for(var m=i.raw?e:f,n=b.cookie.split("; "),o=d?null:{},p=0,q=n.length;q>p;p++){var r=n[p].split("="),s=m(r.shift()),t=m(r.join("="));if(d&&d===s){o=h(t);break}d||(o[s]=h(t))}return o};i.defaults={},a.removeCookie=function(b,c){return null!==a.cookie(b)?(a.cookie(b,null,c),!0):!1}})(jQuery,document);

/*
 * Purl (A JavaScript URL parser) v2.3.1
 * Developed and maintanined by Mark Perkins, mark@allmarkedup.com
 * Source repository: https://github.com/allmarkedup/jQuery-URL-Parser
 * Licensed under an MIT-style license. See https://github.com/allmarkedup/jQuery-URL-Parser/blob/master/LICENSE for details.
 */
(function(factory){if(typeof define==='function'&&define.amd){define(factory)}else{window.purl=factory()}})(function(){var tag2attr={a:'href',img:'src',form:'action',base:'href',script:'src',iframe:'src',link:'href',embed:'src',object:'data'},key=['source','protocol','authority','userInfo','user','password','host','port','relative','path','directory','file','query','fragment'],aliases={'anchor':'fragment'},parser={strict:/^(?:([^:\/?#]+):)?(?:\/\/((?:(([^:@]*):?([^:@]*))?@)?([^:\/?#]*)(?::(\d*))?))?((((?:[^?#\/]*\/)*)([^?#]*))(?:\?([^#]*))?(?:#(.*))?)/,loose:/^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*):?([^:@]*))?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/},isint=/^[0-9]+$/;function parseUri(url,strictMode){var str=decodeURI(url),res=parser[strictMode||false?'strict':'loose'].exec(str),uri={attr:{},param:{},seg:{}},i=14;while(i--){uri.attr[key[i]]=res[i]||''}uri.param['query']=parseString(uri.attr['query']);uri.param['fragment']=parseString(uri.attr['fragment']);uri.seg['path']=uri.attr.path.replace(/^\/+|\/+$/g,'').split('/');uri.seg['fragment']=uri.attr.fragment.replace(/^\/+|\/+$/g,'').split('/');uri.attr['base']=uri.attr.host?(uri.attr.protocol?uri.attr.protocol+'://'+uri.attr.host:uri.attr.host)+(uri.attr.port?':'+uri.attr.port:''):'';return uri}function getAttrName(elm){var tn=elm.tagName;if(typeof tn!=='undefined')return tag2attr[tn.toLowerCase()];return tn}function promote(parent,key){if(parent[key].length===0)return parent[key]={};var t={};for(var i in parent[key])t[i]=parent[key][i];parent[key]=t;return t}function parse(parts,parent,key,val){var part=parts.shift();if(!part){if(isArray(parent[key])){parent[key].push(val)}else if('object'==typeof parent[key]){parent[key]=val}else if('undefined'==typeof parent[key]){parent[key]=val}else{parent[key]=[parent[key],val]}}else{var obj=parent[key]=parent[key]||[];if(']'==part){if(isArray(obj)){if(''!==val)obj.push(val)}else if('object'==typeof obj){obj[keys(obj).length]=val}else{obj=parent[key]=[parent[key],val]}}else if(~part.indexOf(']')){part=part.substr(0,part.length-1);if(!isint.test(part)&&isArray(obj))obj=promote(parent,key);parse(parts,obj,part,val)}else{if(!isint.test(part)&&isArray(obj))obj=promote(parent,key);parse(parts,obj,part,val)}}}function merge(parent,key,val){if(~key.indexOf(']')){var parts=key.split('[');parse(parts,parent,'base',val)}else{if(!isint.test(key)&&isArray(parent.base)){var t={};for(var k in parent.base)t[k]=parent.base[k];parent.base=t}if(key!==''){set(parent.base,key,val)}}return parent}function parseString(str){return reduce(String(str).split(/&|;/),function(ret,pair){try{pair=decodeURIComponent(pair.replace(/\+/g,' '))}catch(e){}var eql=pair.indexOf('='),brace=lastBraceInKey(pair),key=pair.substr(0,brace||eql),val=pair.substr(brace||eql,pair.length);val=val.substr(val.indexOf('=')+1,val.length);if(key===''){key=pair;val=''}return merge(ret,key,val)},{base:{}}).base}function set(obj,key,val){var v=obj[key];if(typeof v==='undefined'){obj[key]=val}else if(isArray(v)){v.push(val)}else{obj[key]=[v,val]}}function lastBraceInKey(str){var len=str.length,brace,c;for(var i=0;i<len;++i){c=str[i];if(']'==c)brace=false;if('['==c)brace=true;if('='==c&&!brace)return i}}function reduce(obj,accumulator){var i=0,l=obj.length>>0,curr=arguments[2];while(i<l){if(i in obj)curr=accumulator.call(undefined,curr,obj[i],i,obj);++i}return curr}function isArray(vArg){return Object.prototype.toString.call(vArg)==="[object Array]"}function keys(obj){var key_array=[];for(var prop in obj){if(obj.hasOwnProperty(prop))key_array.push(prop)}return key_array}function purl(url,strictMode){if(arguments.length===1&&url===true){strictMode=true;url=undefined}strictMode=strictMode||false;url=url||window.location.toString();return{data:parseUri(url,strictMode),attr:function(attr){attr=aliases[attr]||attr;return typeof attr!=='undefined'?this.data.attr[attr]:this.data.attr},param:function(param){return typeof param!=='undefined'?this.data.param.query[param]:this.data.param.query},fparam:function(param){return typeof param!=='undefined'?this.data.param.fragment[param]:this.data.param.fragment},segment:function(seg){if(typeof seg==='undefined'){return this.data.seg.path}else{seg=seg<0?this.data.seg.path.length+seg:seg-1;return this.data.seg.path[seg]}},fsegment:function(seg){if(typeof seg==='undefined'){return this.data.seg.fragment}else{seg=seg<0?this.data.seg.fragment.length+seg:seg-1;return this.data.seg.fragment[seg]}}}}purl.jQuery=function($){if($!=null){$.fn.url=function(strictMode){var url='';if(this.length){url=$(this).attr(getAttrName(this[0]))||''}return purl(url,strictMode)};$.url=purl}};purl.jQuery(window.jQuery);return purl});