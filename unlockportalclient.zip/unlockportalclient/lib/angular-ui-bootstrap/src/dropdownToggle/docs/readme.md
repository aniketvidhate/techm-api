
DropdownToggle is a simple directive which will toggle a dropdown link on click.  Simply put it on the `<a>` tag of the toggler-element, and it will find the nearest dropdown menu and toggle it when the `<a dropdown-toggle>` is clicked.
