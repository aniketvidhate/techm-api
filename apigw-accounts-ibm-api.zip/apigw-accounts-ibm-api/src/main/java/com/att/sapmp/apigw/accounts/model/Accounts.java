package com.att.sapmp.apigw.accounts.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class Accounts {

	private Map<Object, Object> account;

	public Map<Object, Object> getAccounts() {
		return account;
	}

	public void setAccounts(Map<Object, Object> account) {
		this.account = account;

	}

}
