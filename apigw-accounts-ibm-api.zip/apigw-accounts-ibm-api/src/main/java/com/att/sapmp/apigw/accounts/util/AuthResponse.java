package com.att.sapmp.apigw.accounts.util;

import java.util.Map;


public class AuthResponse {
	
	private Map<Object, Object> authResponse;
	
	public Map<Object, Object> getAuthResponse() {
		return authResponse;
	}

	public void setAuthResponse(Map<Object, Object> authResponse) {
		this.authResponse = authResponse;
	}

}
