package com.att.sapmp.apigw.accounts.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class CreateTenantAccountResp {
	
	Map<Object, Object> account;

	public Map<Object, Object> getAccont() {
		return account;
	}

	public void setAccount(Map<Object, Object> account) {
		this.account = account;
	}
	

}
