package com.att.sapmp.apigw.accounts.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "searchaccount")
@Produces({ MediaType.APPLICATION_JSON })
public interface InquireAccountsRestService {

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Returns Accounts based on input searchCriteria",
			notes = "InquireAccounts API will call MDM Vendor to get the accounts details "
					+ "Client can specify required searchCriteria in input. "
					+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
					+ "All failures would be logged for reporting purpose. "
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void getAccounts(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode, @DefaultValue("{\"emmAccountId\":\"231232\",\"accountName\":\"ABCorp\",\"productCode\":\"IBMMass360Trial121334\",\"pageSize\":\"50\",\"pageNumber\":\"1\"}")@QueryParam("searchcriteria") String searchcriteria );
	
}