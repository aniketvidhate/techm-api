package com.att.sapmp.apigw.accounts.service.rs;


import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;

@AjscService
public class InquireAccountsRestServiceImpl implements InquireAccountsRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InquireAccountsRestServiceImpl.class);

	public InquireAccountsRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@GET 
	@Path("/")
	public void getAccounts(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode, @DefaultValue("{\"emmAccountId\":\"231232\",\"accountName\":\"ABCorp\",\"productCode\":\"IBMMass360Trial121334\",\"pageSize\":\"50\",\"pageNumber\":\"1\"}")@QueryParam("searchcriteria") String searchcriteria ) {	
		log.info("Received request in InquireAccounts API. searchcriteria="+searchcriteria);
	}

}
