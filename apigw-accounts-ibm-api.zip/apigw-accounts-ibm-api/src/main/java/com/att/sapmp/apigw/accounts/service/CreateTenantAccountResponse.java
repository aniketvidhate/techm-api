package com.att.sapmp.apigw.accounts.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.model.CreateTenantAccountResp;
import com.att.sapmp.apigw.accounts.util.CommonDefs;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;

/**
 * @author av0041
 *
 */
@Component
public class CreateTenantAccountResponse {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateTenantAccountResponse.class);

	public final void handleResponse(Exchange e) throws ApigwException {

		CreateTenantAccountResp createAccountRes = (CreateTenantAccountResp) e.getIn().getBody();

		JSONObject createAccountJsonRes = new JSONObject();
		Map<String, Object> hmCreateAccountJsonRes = new HashMap<>();
		Map hmAccount = null;
		if (createAccountRes != null) {

			hmAccount = createAccountRes.getAccont();

			// log.info("Response from MDM Create account API " + hmAccount);

			if (hmAccount != null && !hmAccount.isEmpty() && !hmAccount.containsKey(CErrorDefs.ERROR_CODE)) {
				Integer billingId = (Integer) hmAccount.get(CommonDefs.BILLING_ID);
				hmCreateAccountJsonRes.put(CommonDefs.ACCOUNT_NAME, hmAccount.get(CommonDefs.ACCOUNT_NAME));
				if (billingId != null && !String.valueOf(billingId).trim().isEmpty()) {
					hmCreateAccountJsonRes.put(CommonDefs.EMM_ACCOUNT_ID, hmAccount.get(CommonDefs.BILLING_ID));
					createAccountJsonRes.put(CommonDefs.ACCOUNT, hmCreateAccountJsonRes);
					e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CErrorDefs.Created);
				} else {
					e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CErrorDefs.OK);
					e.getOut().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
					e.getOut().setHeader(CommonDefs.DESCRIPTION,
							CErrorDefs.ERROR_CODE_4002_DESCRIPTION + hmAccount.get(CommonDefs.DESCRIPTION));
					createAccountJsonRes.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
					createAccountJsonRes.put(CommonDefs.DESCRIPTION,
							CErrorDefs.ERROR_CODE_4002_DESCRIPTION + hmAccount.get(CommonDefs.DESCRIPTION));
				}
			}

		}

		if (hmCreateAccountJsonRes.isEmpty()) {

			String stStatusCode = String.valueOf(e.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE));
			String vendorErrorMsg = "";

			if (stStatusCode.equals(CErrorDefs.OK)) {
				if (hmAccount != null && hmAccount.containsKey(CErrorDefs.ERROR_MESSAGE)) {
					vendorErrorMsg = (String) hmAccount.get(CErrorDefs.ERROR_MESSAGE);
				}
				e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CErrorDefs.OK);
				e.getOut().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
				e.getOut().setHeader(CommonDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4002_DESCRIPTION + vendorErrorMsg);

				createAccountJsonRes.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);

				createAccountJsonRes.put(CommonDefs.DESCRIPTION,
						CErrorDefs.ERROR_CODE_4002_DESCRIPTION + vendorErrorMsg);
			} else {
				e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_500);
				createAccountJsonRes.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
				createAccountJsonRes.put(CommonDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4002_DESCRIPTION);
			}
		}
		
		log.info("Response from CreateTenantAccount API " + createAccountJsonRes);

		// retry to create account if user already exists.
		if (createAccountJsonRes.has(CErrorDefs.ERROR_CODE)) {
			String description = (String) createAccountJsonRes.get(CommonDefs.DESCRIPTION);
			createAccountRetry(e, description);
		} else {
			e.removeProperty(CommonDefs.CREATE_ACCOUNT_RETRY);
		}

		e.getOut().setBody(createAccountJsonRes);

	}
	
	/**
	 * Retrying to create account if accountName already present at IBM MDM.
	 * To support OCE requirement to re-enroll the account.
	 */

	private void createAccountRetry(Exchange e, String description) {
		String createAccountRetry = (String) e.getProperty(CommonDefs.CREATE_ACCOUNT_RETRY);
		if (StringUtils.isEmpty(createAccountRetry) && description != null
				&& (description.contains(CommonDefs.USER_EXISTS) || description.contains(CommonDefs.CUSTOMER_EXISTS))) {
			e.getOut().setHeaders(e.getIn().getHeaders());
			HashMap<String, Object> hmCreateTenantAccnt = (HashMap<String, Object>) e
					.getProperty(CommonDefs.CREATE_ACCOUNT_MAP);
			String accountName = (String) hmCreateTenantAccnt.get(CommonDefs.ACCOUNT_NAME);

			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			String date = dateFormat.format(new Date());

			// Adding timestamp to accountName for retry.
			hmCreateTenantAccnt.put(CommonDefs.ACCOUNT_NAME, accountName + CommonDefs.UNDERSCORE + date);

			VelocityContext velocityContext = new VelocityContext(hmCreateTenantAccnt);
			e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
			e.setProperty(CommonDefs.CREATE_ACCOUNT_RETRY, CommonDefs.Y);
			log.info("Retrying to create account with accountName = "
					+ hmCreateTenantAccnt.get(CommonDefs.ACCOUNT_NAME));

		} else {
			e.removeProperty(CommonDefs.CREATE_ACCOUNT_RETRY);
		}

	}

}
