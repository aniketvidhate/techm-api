package com.att.sapmp.apigw.accounts.util;

public class CommonDefs {

	public static final String BILLING_ID = "billingId";
	public static final String ACCOUNT_PASS_PHRASE = "AccountPassPhrase";
	public static final String USER_NAME = "userName";
	public static final String AUTH_TOKEN = "authToken";
	public static final String EXPIRATION_TIME = "expirationTime";

	public static final String PARTNER_ACCOUNT = "partnerAccount";
	public static final String[] NON_ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductcode",
			"accountpassphrase" };
	public static final String[] ACCOUNT_HEADERS = { "authorization", "trackingid", "emmproductCode" };

	public static final String SEARCH_CRITERIA = "searchcriteria";
	public static final String EMM_ACCOUNT_ID = "emmAccountId";
	public static final String TENANT_ACCOUNT_ID = "tenantAccountId";
	public static final String IBM_URL = "IBMUrl";

	// Constants for Accounts APIs
	public static final String ACCOUNT = "account";
	public static final String ACCOUNTS = "accounts";
	public static final String ACCOUNT_STATUS = "accountStatus";
	public static final String CAMEL_HTTP_RESPONSE_CODE = "CamelHttpResponseCode";
	public static final String CAMEL_HTTP_URL = "CamelHttpUrl";
	public static final String EMM_PRODUCT_CODE = "emmproductcode";
	public static final String TRACKING_ID = "trackingid";
	public static final String RESPONSE_ACCEPT_CODE = "202";
	public static final String IBM_CREATE_USER_URL = "IBMCreateUserUrl";
	public static final String STATUS = "status";
	public static final String RESPONSE_CREATED_CODE = "201";

	public static final String Y = "Y";
	public static final String N = "N";
	public static final String DESCRIPTION = "description";
	public static final String PRODUCT_CODE = "productCode";
	public static final String EMMP_PRODUCT_CODE = "EMMProductCode";
	public static final String ORIGIONAL_BODY = "origionalBody";
	public static final String ERROR_CODE_STR = "errorCode";
	public static final String MESSAGE = "message";
	public static final String AUTHORIZATION = "Authorization";
	public static final String ACCOUNT_NAME = "accountName";
	public static final String RESPONSE_SUCCESS_CODE = "200";
	public static final String SUCCESS_CODE = "Success";
	public static final String UNDERSCORE = "_";

	public static final String RESPONSE_SUCCESS_MSG = "SUCCESS";
	public static final String PARTNER_BILLING_ID = "partnerBillingId";

	public static final String USER_EXISTS = "Username already exists";
	public static final String CUSTOMER_EXISTS = "customer already exists";
	public static final String CREATE_ACCOUNT_MAP = "createAccountMap";
	public static final String CREATE_ACCOUNT_RETRY = "createAccountRetry";

}
