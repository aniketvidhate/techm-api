package com.att.sapmp.apigw.accounts.service;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.service.BaseProcessor;
import com.att.sapmp.apigw.accounts.util.CommonDefs;
import com.att.sapmp.apigw.accounts.util.CommonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author av0041
 *
 */
@Component
public class CreateTenantAccountRequest extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateTenantAccountRequest.class);

	@Value("${ibm.create.tenant.account.url}")
	private String createTenantUrl;

	@Value("${ibm.partner.billing.id}")
	private String partnerBillingId;
	
	@Autowired
	private CommonUtil commonUtil;

	public final void execute(Exchange e) throws ApigwException {

		String createTenantAccntFinalURL = "";

		String postReq = (String) (e.getIn().getBody());

		String emmProductCode = (String) (e.getIn().getHeader(CommonDefs.EMMP_PRODUCT_CODE));
				
		commonUtil.logJSON("Received request payload in CreateTenantAccountRequest", postReq);

		if (StringUtils.isEmpty(postReq)) {

			throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CErrorDefs.ERROR_CODE_1002_DESCRIPTION);

		}

		// create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		// convert json string to object
		Map<String, Object> hmCreateTenantAccnt = null;
		try {
			hmCreateTenantAccnt = objectMapper.readValue(postReq, HashMap.class);


		hmCreateTenantAccnt.put(CommonDefs.PARTNER_BILLING_ID, partnerBillingId);
		hmCreateTenantAccnt.put(CommonDefs.EMMP_PRODUCT_CODE, emmProductCode);
			
		String stAccountName = (String) hmCreateTenantAccnt.get(CommonDefs.ACCOUNT_NAME);
		if (!StringUtils.isEmpty(stAccountName)){
			stAccountName = URLEncoder.encode(stAccountName, "UTF-8");
			hmCreateTenantAccnt.put(CommonDefs.ACCOUNT_NAME, stAccountName);
		}
		createTenantAccntFinalURL = createTenantUrl + "/" + partnerBillingId;

		log.info("Setting Header IBMCreateTenantAccountUrl=" + createTenantAccntFinalURL);
		e.getOut().setHeader("IBMCreateTenantAccountUrl", createTenantAccntFinalURL);
		VelocityContext velocityContext = new VelocityContext(hmCreateTenantAccnt);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		e.getOut().setHeader(CommonDefs.BILLING_ID, partnerBillingId);
		
		e.setProperty(CommonDefs.CREATE_ACCOUNT_MAP, hmCreateTenantAccnt);
		
		} catch (Exception ex) {
			log.debug("Exception occurred while processing post request: " + ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}

	}
		

}