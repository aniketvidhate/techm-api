package com.att.sapmp.apigw.accounts.service.rs;


import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.model.CreateAccount;

import io.swagger.annotations.ApiParam;

@AjscService
public class CreateaTenantAccountRestServiceImpl implements CreateaTenantAccountRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateaTenantAccountRestServiceImpl.class);
	

	public CreateaTenantAccountRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@POST 
	public void createTenantAccount(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@ApiParam(value = "Create Account Request Object", required = true) @RequestBody CreateAccount createAccount) {	
		log.info("Received request in CreateaTenantAccountRestServiceImpl API");
		
	}

}
