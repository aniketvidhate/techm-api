package com.att.sapmp.apigw.accounts.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.model.Accounts;
import com.att.sapmp.apigw.accounts.util.CommonDefs;

/**
 * @author pg238s
 *
 */
@Component
public class InquireAccountResponseProcessor {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InquireAccountResponseProcessor.class);
	
	
	public final void handleExpireAccountResponse(Exchange e) throws ApigwException {
		
		String respBody = e.getIn().getBody(String.class);
		log.info("Received response in handleExpireAccountResponse method:: "+respBody);
		e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		
	}


	public final void handleResponse(Exchange e) throws ApigwException {
		Map<String, Object> hmResponseParam = InitializationService.getResponseparammap();
		Accounts oDev = (Accounts) e.getIn().getBody();
		
		HashMap<String, Object> hmAccountsResponse = populateMetaData(oDev);
		
		ArrayList<HashMap<String, Object>> alAccount = new ArrayList<>();
		HashMap<String, Object> hmSingleAccount = null;
		Object oAccounts = oDev.getAccounts().get(CommonDefs.ACCOUNT);
		if (oAccounts instanceof ArrayList) {
			ArrayList<HashMap<String , Object>> alAccountsList = (ArrayList<HashMap<String , Object>>) oAccounts;
			log.info("Response from MDM Vendor:: "+alAccountsList);
			String emmAccountId = (String) (e.getIn().getHeader(CommonDefs.EMM_ACCOUNT_ID));
			if (!StringUtils.isEmpty(emmAccountId)) {
				hmSingleAccount = processByEmmAccountId(emmAccountId , hmResponseParam, alAccountsList);
				if (hmSingleAccount != null && !hmSingleAccount.isEmpty()) {
					hmAccountsResponse.put(CommonDefs.ACCOUNT, hmSingleAccount);
				}
			} else {
				for (HashMap<String, Object> hmAccount : alAccountsList) {
					hmSingleAccount = populateSingleAccount(hmResponseParam, hmAccount);
					alAccount.add(hmSingleAccount);
				}
				hmAccountsResponse.put(CommonDefs.ACCOUNT, alAccount);
			}
		} else if (oAccounts instanceof HashMap) {
			HashMap<String, Object> hmAccount = (HashMap<String, Object>) oAccounts;
			log.info("Response from MDM Vendor :: "+hmAccount);
			hmSingleAccount = populateSingleAccount(hmResponseParam, hmAccount);
			hmAccountsResponse.put(CommonDefs.ACCOUNT, hmSingleAccount);
		}
		
		JSONObject jsonAccounts = new JSONObject();
		jsonAccounts.put(CommonDefs.ACCOUNTS, hmAccountsResponse);

		log.info("Response from InquireAccounts API "+jsonAccounts);
		e.getOut().setBody(jsonAccounts);

	}


	private HashMap<String, Object> populateSingleAccount(Map<String, Object> hmResponseParam,
			HashMap<String, Object> hmAccount) {
		HashMap<String, Object> hmSingleAccount;
		Iterator<String> itResponse = hmResponseParam.keySet().iterator();
		hmSingleAccount = new HashMap<>();
		while (itResponse.hasNext()) {
			String stKey = itResponse.next();
			if (hmAccount.containsKey(stKey)) {
				hmSingleAccount.put((String) hmResponseParam.get(stKey), hmAccount.get(stKey));
			}
		}
		populateAccountStatus(hmSingleAccount);
		return hmSingleAccount;
	}


	private HashMap<String, Object> populateMetaData(Accounts oDev) {
		Object count = oDev.getAccounts().get("count");
		Object pageNumber = oDev.getAccounts().get("pageNumber");
		Object pageSize = oDev.getAccounts().get("pageSize");
		HashMap<String, Object> metaMap = new HashMap<>();
		metaMap.put("count", count);
		metaMap.put("pageNumber", pageNumber);
		metaMap.put("pageSize", pageSize);
		
		HashMap<String, Object> hmAccountsResponse = new HashMap<>();
		hmAccountsResponse.put("metaData", metaMap);
		return hmAccountsResponse;
	}


	private void populateAccountStatus(HashMap<String, Object> hmSingleAccount) {
		if(hmSingleAccount.get(CommonDefs.ACCOUNT_STATUS) != null) {
			String status = (String)hmSingleAccount.get(CommonDefs.ACCOUNT_STATUS);
			if(!StringUtils.isEmpty(status)) {
				if("Expired".equals(status)) {
					hmSingleAccount.put(CommonDefs.ACCOUNT_STATUS, "InActive");
				}
				else if("Customer".equals(status) || "Trial".equals(status) ){
					hmSingleAccount.put(CommonDefs.ACCOUNT_STATUS, "Active");
					
				}
			}					
		}
	}
	
	private HashMap<String, Object> processByEmmAccountId(String emmAccountId, Map<String, Object> hmResponseParam,
			ArrayList<HashMap<String, Object>> alAccountsList) {
		Iterator<String> itResponse = hmResponseParam.keySet().iterator();
		HashMap<String, Object>  hmSingleAccount = new HashMap<>();
		HashMap<String, Object>  hmEmmAccount = null;
		for (HashMap<String, Object> hmAccount : alAccountsList) {
			Integer iBillingId = (Integer) hmAccount.get(CommonDefs.BILLING_ID);
			if(iBillingId != null && (String.valueOf(iBillingId).equals(emmAccountId))){
				hmEmmAccount = hmAccount;
				break;
			}
		}
		
		if (hmEmmAccount != null && !hmEmmAccount.isEmpty()) {
			while (itResponse.hasNext()) {
				String stKey = itResponse.next();
				if (hmEmmAccount.containsKey(stKey)) {
					hmSingleAccount.put((String) hmResponseParam.get(stKey), hmEmmAccount.get(stKey));
				}
			}
			populateAccountStatus(hmSingleAccount);
		}
		return hmSingleAccount;
	}


}
