package com.att.sapmp.apigw.accounts.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.service.BaseProcessor;

/**
 * @author pg238s
 *
 */
@Component
public class ExpireAccountRequestProcessor extends BaseProcessor{

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ExpireAccountRequestProcessor.class);
	
	@Value("${ibm.expire.account.url}")
	private String expireAccountUrl;
	
	@Value("${ibm.partner.billing.id}")
	private String partnerBillingId;
	
	@Autowired
	private InitializationService is;	
	
	public final void execute(Exchange e) throws ApigwException {	
		log.info("Invoking initializeExpireAccountHeader");
		
		log.info("Setting Header IBMUrl=" + expireAccountUrl);
		String stBillingId = is.getBillingId();
		String stPartnerBillingId= partnerBillingId;
		HashMap<String, Object> hmExpire = new HashMap<>();
		hmExpire.put("billingId", stBillingId);
		
		if(stBillingId == null || stBillingId.isEmpty()){
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "Billing Id is null in input");
		}
		
		e.getOut().setHeader("IBMUrl", expireAccountUrl + "/" + stPartnerBillingId);
		
		VelocityContext velocityContext = new VelocityContext(hmExpire);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		e.getOut().setHeader("billingId", stPartnerBillingId);

	}
}