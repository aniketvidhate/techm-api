package com.att.sapmp.apigw.accounts.service;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.ApigwException;
import com.att.sapmp.apigw.accounts.util.CommonDefs;

/**
 * @author pg238s
 *
 */
@Component
public class ExpireAccountResponseProcessor {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ExpireAccountResponseProcessor.class);
	
	
	public final void handleExpireAccountResponse(Exchange e) throws ApigwException {
		
		String respBody = e.getIn().getBody(String.class);
		log.info("Received response in handleExpireAccountResponse method:: "+respBody);
		if (respBody != null && respBody.contains(CommonDefs.ERROR_CODE_STR)) {
			e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
			e.getOut().setBody(respBody);
		} else {
			e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		}
		
		
	}
}
