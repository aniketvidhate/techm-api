package com.att.sapmp.apigw.accounts.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "/expireaccount")
@Produces({ MediaType.APPLICATION_JSON })
public interface ExpireAccountRestService {

	@DELETE
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Sets the status of account to expired",
			notes = "The account is marked as expired and all the devices under account are de-enrolled."
					+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
					+ "All failures would be logged for reporting purpose. "
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void expireAccount(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "TrackingId") String trackingId,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@PathParam("billingId") String billingId);
	
}