package com.att.sapmp.apigw.accounts.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.apache.commons.lang.math.RandomUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

/**
 * 
 * @author sm7993
 *
 */

public class TestCreateAccount extends TestBase{
	
	@Value("${test.fan}")
	private String fan;
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.accountNamePrefix}")
	private String accountNamePrefix;
	
	@Value("${test.partner.billing.id}")
	protected String partnerBillingId;	
	
	@Value("${test.ibm.inquire.account.basePath}")
	protected String inquireBasePath;
	
	@Value("${test.ibm.create.account.basePath}")
	protected String createBasePath;
			
	@Override
	protected void replaceTokensInRequest() throws Exception {
		int accountSuffix = RandomUtils.nextInt(1000);
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{fan\\}", fan);	
        requestJson = requestJson.replaceAll("\\$\\{accountName\\}", accountNamePrefix + String.valueOf(accountSuffix));	
	}

	@Override
	protected String getBasePath() {
		return createBasePath;
	}
	
	@Test
	public void testGivenCreateNewAccountWhenRequiredFieldsAreNotPassedThenAccountIsNotCreatedAndReturnInvalidRequestError() throws Exception {
		headers.remove("trackingid");
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("E1002"), containsString("description")));
	}

	@Test
	public void testGivenCreateNewAccountWhenRequiredFieldsArePassedThenAccountIsCreatedAndResponseContainsAccountIdAndUserName() throws Exception {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());	
		assertThat(responseBody, allOf(containsString("errorCode"),containsString("description")));			
	}

	@Test
	public void testGivenCreateNewAccountWhenRequiredFieldsArePassedThenAccountIsCreatedAndEmmAccountNameIsEqualToPartnerBillingIdAndEmmProductIdAndAccountName() throws Exception {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());		
		JSONObject jsonObject = new JSONObject(requestJson);
		String accountNameRequest = (String)jsonObject.get("accountName");
		executeGet(inquireBasePath);
		JSONObject postResJSON = new JSONObject(responseBody);
		JSONObject accounts = (JSONObject)postResJSON.get("accounts");
		JSONArray account = accounts.getJSONArray("account");
		JSONObject firstElement = account.getJSONObject(0);
		String accountNameResponse = (String)firstElement.get("accountName");
		String constructedAccountName = partnerBillingId + headers.get("emmproductcode") + accountNameRequest;
		assertEquals(constructedAccountName, accountNameResponse);
	}
	
	//@Test
	//Needs manual testing as the adminUserName is not returned in the createUser or inquireAccount response
	public void testGivenCreateNewAccountWhenAccountIsCreatedThenUserNameSuffixIsAccountEmailPrefix() {
	}

	@Test
	public void testGivenCreateNewAccountWhenExistingAccountNameIsUsedThenAccountIsNotCreatedAndResponseContainsAccountExistsError() {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("E4002"), containsString("description")));
	}

	//@Test 
	//Needs to be manually tested as it is not feasible to check for account notification and access to IBM portal in testcase
	public void testGivenCreateFreeIBMMaaS360AccountWhenAccountIsCreatedThenNoNotificationSentToAccountAdminAndNoAccessToIBMPortal() {
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenCreateAccountIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenCreateAccountIsAttemptedAndRequiredFieldsArePassesThenTransactionSucceeds() {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
}
