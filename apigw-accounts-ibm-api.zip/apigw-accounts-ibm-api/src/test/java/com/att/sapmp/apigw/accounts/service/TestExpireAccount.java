package com.att.sapmp.apigw.accounts.service;

import static org.junit.Assert.assertEquals;

import org.apache.commons.lang.math.RandomUtils;
import org.json.JSONObject;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

public class TestExpireAccount extends TestBase{

	//Given_Preconditions_When_StateUnderTest_Then_ExpectedBehavior: This approach is based on naming convention developed as part of Behavior-Driven Development (BDD). 
	//The idea is to break down the tests into three part such that one could come up with preconditions, state under test and expected behavior to be written in above format. 
	//Following is how tests in first example would read like if named using this technique:

	@Value("${test.fan}")
	private String fan;
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.accountNamePrefix}")
	private String accountNamePrefix;
	
	@Value("${test.ibm.expire.account.basepath}")
	protected String expireBasePath;
	
	@Value("${test.ibm.create.account.basePath}")
	protected String createBasePath;
			
	@Override
	protected void replaceTokensInRequest() throws Exception {
		int accountSuffix = RandomUtils.nextInt(1000);
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{fan\\}", fan);	
        requestJson = requestJson.replaceAll("\\$\\{accountName\\}", accountNamePrefix + String.valueOf(accountSuffix));	
	}

	@Override
	protected String getBasePath() {
		return expireBasePath;
	}
	
	
	@Test
	public void testGivenExpireAccountWhenRequiredFieldsAreNotPassedThenReturnInvalidRequestError() throws Exception{
		headers.remove("trackingid");
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testGivenExpireAccountExistsAndActiveWhenRequiredFieldsArePassedThenAccountIsExpired() throws Exception {
		executePost(createBasePath);
		JSONObject jsonObject = new JSONObject(responseBody);
		executeDelete(expireBasePath,String.valueOf(((JSONObject)jsonObject.get("account")).get("emmAccountId")));
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		assertEquals(responseBody,null);
	}
	
	@Test
	public void testGivenExpireAccountWhenAccountExistsAndIsInActiveAndRequiredFieldsArePassedThenExpireAccountFails() throws Exception {	
		executeDelete(expireBasePath,"6962287");
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}
	
	@Test
	public void testGivenExpireAccountWhenAccountNotExistsAndRequiredFieldsArePassedThenExpireAccountFails() throws Exception {
		executeDelete(expireBasePath,"231232");
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
	}
	
	@Test
	public void testGivenAuthTokenIsInvalidWhenExpireAccountIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenExpireAccountIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception {
		executePost(createBasePath);
		JSONObject jsonObject = new JSONObject(responseBody);
		executeDelete(expireBasePath,String.valueOf(((JSONObject)jsonObject.get("account")).get("emmAccountId")));
		assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
		assertEquals(responseBody,null);	
	}
}
