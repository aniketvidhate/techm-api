package com.att.sapmp.apigw.accounts.service;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.Application;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:application-test.properties")
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
public class AccountsIntegrationTest {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(AccountsIntegrationTest.class);

	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	@Autowired
	private TestRestTemplate template;

	HttpHeaders headers = null;

	@Before
	public void setUp() throws Exception {

		headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
		headers.set("accountpassphrase", "0120006789");
		headers.set("trackingid", "12345");
		headers.set("emmproductcode", "IBMMASS");

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateAccount() throws Exception {

		String body = "{\"fan\": \"0120006789\",\"accountName\": \"ATTCRU\",\"email\": \"account-admin@att.com\",\"productCode\": \"IBMMass360Trial121334\",\"password\":\"0120006789\"}";

		HttpEntity<String> entity = new HttpEntity<String>(body, headers);
		ResponseEntity<String> response = template.exchange("/accounts/createaccount", HttpMethod.POST, entity,
				String.class);

		log.info("Response:" + response.getBody());
		//assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testInquireAccount() throws Exception {

		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		String queryParam = "{\"accountName\":\"0120006789\"}";
		ResponseEntity<String> response = template.exchange("/accounts?searchcriteria={queryParam}", HttpMethod.GET,
				entity, String.class, queryParam);

		log.info("Response:" + response.getBody());
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testExpireAccount() throws Exception {

		HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		ResponseEntity<String> response = template.exchange("/accounts/30060694", HttpMethod.DELETE, entity,
				String.class);

		log.info("Response:" + response.getBody());
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
}
