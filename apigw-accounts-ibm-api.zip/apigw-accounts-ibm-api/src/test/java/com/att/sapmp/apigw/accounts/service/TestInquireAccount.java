package com.att.sapmp.apigw.accounts.service;

import static org.junit.Assert.assertEquals;

import org.apache.commons.lang.math.RandomUtils;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class TestInquireAccount extends TestBase{
	
	//Given_Preconditions_When_StateUnderTest_Then_ExpectedBehavior: This approach is based on naming convention developed as part of Behavior-Driven Development (BDD). 
	//The idea is to break down the tests into three part such that one could come up with preconditions, state under test and expected behavior to be written in above format. 
	//Following is how tests in first example would read like if named using this technique:

	@Value("${test.fan}")
	private String fan;
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.accountNamePrefix}")
	private String accountNamePrefix;
	
	@Value("${ibm.partner.billing.id}")
	protected String partnerBillingId;
	
	@Value("${test.ibm.inquire.account.basePath}")
	protected String inquireBasePath;
	
	@Override
	protected void replaceTokensInRequest() throws Exception {
		int accountSuffix = RandomUtils.nextInt(1000);
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
        requestJson = requestJson.replaceAll("\\$\\{fan\\}", fan);	
        requestJson = requestJson.replaceAll("\\$\\{accountName\\}", accountNamePrefix + String.valueOf(accountSuffix));	
	}

	@Override
	protected String getBasePath() {
		return inquireBasePath;
	}
	
	@Test 
	public void testGivenInquireAccountWhenRequiredFieldsAreNotPassedThenReturnInvalidRequestError() throws Exception {
		executeGet();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testGivenInquireAccountExistsWhenSearchCriteriaContainsEmmAccountIdThenMatchingAccountDetailsIsReturned() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireAccountsExistWhenSearchCriteriaContainsEmmProductCodeThenAllAccountsWithMatchingEmmProductCodeIsReturned() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireAccountsExistWhenSearchCriteriaContainsPartialAccountNameThenAllAccountsWithMatchingAccountNameIsReturned() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireAccountWhenSearchCriteriaHasPageSizeAndPageNumberThenReponseConfinesToPageSizeAndPageNumberValues() throws Exception{
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}	

	@Test
	public void testGivenAuthTokenIsInvalidWhenInquireAccountIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception {
		headers.set("authorization", "Basic 123");
		executeGet();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenInquireAccountIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
}
