var paymentApp = angular.module('paymentApp', ['ngRoute', 'ngSanitize']);


paymentApp.config(function($routeProvider) {

    $routeProvider

    // route for the home page
        .when('/', {
            templateUrl: unlockTemplateUrl.systemError,
            controller: 'initialController'
        })
        .when('/paymentcontent', {
            templateUrl: unlockTemplateUrl.paymentContent,
            controller: 'AController'
        })
        .when('/paymentthankyou', {
            templateUrl: unlockTemplateUrl.paymentThankyou,
            controller: 'successController'
        })
        .when('/paymentlinkexpired', {
            templateUrl: unlockTemplateUrl.paymentLinkExpired,
            controller: 'linkExpController'
        })
        .when('/paymentcancelled', {
            templateUrl: unlockTemplateUrl.paymentCancelled,
            controller: 'paymentCancelledController'
        })
        .when('/systemerror', {
            templateUrl: unlockTemplateUrl.systemError,
            controller: 'systemErrorController'
        })
        .when('/paymentsessiontimeout', {
            templateUrl: unlockTemplateUrl.paymentSessionTimeOut,
            controller: 'paymentSessionTimeOutController'
        })
        .otherwise({
            redirectTo: '/'
        });

});


paymentApp.run(function($rootScope, $route, $location) {
    $rootScope.$on('$locationChangeStart', function(ev, next, current) {
        //Setting page name value from edd doc
        var wtPN = "";
        if ($location.path().indexOf('/paymentcontent') == '0') {
            wtPN = "Device Unlock Portal Payment Pg";
        }
        if ($location.path().indexOf('/paymentthankyou') == '0') {
            wtPN = "Device Unlock Portal Payment Receipt Pg";
        }
        if ($location.path().indexOf('/paymentlinkexpired') == '0') {
            wtPN = "Device Unlock Portal Payment Link Expired Pg";
        }
        if ($location.path().indexOf('/paymentcancelled') == '0') {
            wtPN = "Device Unlock Payment Cancelled  Pg";
        }
        if ($location.path().indexOf('/paymentsessiontimeout') == '0') {
            wtPN = "Device Unlock Portal Payment Session Timeout Pg";
        }
        if ($location.path().indexOf('/systemerror') == '0') {
            wtPN = "Device Unlock Portal System Error Pg";
        }

        //Calling web trends function at page load
        webtrendsPageHitCapture(wtPN, current);

        //checking url on location change start
        if ($location.path().indexOf('/paymentcontent') == '0' || $location.path().indexOf('/paymentthankyou') == '0' || $location.path().indexOf('/paymentlinkexpired') == '0' || $location.path().indexOf('/paymentcancelled') == '0' || $location.path().indexOf('/systemerror') == '0' || $location.path().indexOf('/paymentsessiontimeout') == '0') {
            //check if the user has hit the URL directly
            if (sessionStorage.getItem("validRequest") == 'true') {
                // allow access to the page
            } else {
                //redirecting user to portal entry page
                window.location.href = "index.html";
            }
        }
    });
    // delete session variable so as to redirect if user does page refresh
    sessionStorage.setItem("validRequest", "false");
});



/* Fix for placeholder for IE */
jQuery(window).load(function() {
    jQuery("#nameOnCard").val(jQuery("#nameOnCard").attr("placehold"));
    jQuery("#cardNum").val(jQuery("#cardNum").attr("placehold"));
    jQuery("#address_2").val(jQuery("#address_2").attr("placehold"));
});



paymentApp.controller('initialController', function($scope, $sce, $rootScope, $http, $location) {

    $scope.displaySysError = false;

    var searchString = window.location.search.substring(1),
        i, value, parameters = searchString.split("&");

    for (i = 0; i < parameters.length; i++) {
        value = parameters[i].split("=");
        if (value[0] == 'requestId') {
            var reqId = value[1];
        } else if (value[0] == 'transactionId') {
            var tranId = value[1];
        }
    }

    // redirect to portal entry if either reqId or tranId are null/empty
    if ((reqId != null && tranId != null) && (reqId != "" && tranId != "")) {

        openModal();

        initialJson = {
            "unLockVerifyPaymentDetailRequest": {
                "requestId": reqId,
                "transactionId": tranId
            }
        };

        $http({
            method: 'POST',
            url: unlockApiUrl.verifyPaymentDetail,
            data:  initialJson

        }).success(function(responsedata) {

            closeModal();

            // request is set to valid
            if (typeof(Storage) != "undefined") {
                sessionStorage.setItem("validRequest", "true");
            }

            if (responsedata.unLockVerifyPaymentDetailResponse.serviceStatus.code == 0) {

                if (responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.unlockStatus == "PENDING" && responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.unlockSubStatus == "PAYMENT_NEEDED") {

                    $rootScope.orderNumber = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.orderNumber;
                    $rootScope.imei = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.imei;
                    $rootScope.paymentToken = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.paymentToken;
                    $rootScope.ctnToken = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.ctn;
                    $rootScope.marketToken = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.market;
                    $rootScope.submarketToken = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.submarket;
					$rootScope.firstNameToken = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.firstName;
                    $rootScope.lastNameToken = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.lastName;

                    $location.path('/paymentcontent');

                } else if (responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.unlockStatus == "CANCELED" &&
                    responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.unlockSubStatus == "PAYMENT_FAILED") {

                    $rootScope.paymentCancelMsg = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.errorDescription;
                    $location.path('/paymentcancelled');

                } else {

                    $rootScope.errorLinkExpMsg = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.errorDescription;
                    $location.path('/paymentlinkexpired');
                }

            } else if (responsedata.unLockVerifyPaymentDetailResponse.serviceStatus.code == 1) {

                $rootScope.errorLinkExpMsg = responsedata.unLockVerifyPaymentDetailResponse.unlockOrderDetail.errorDescription;
                $location.path('/paymentlinkexpired');


            } else {

                $location.path('/systemerror');

            }

        }).error(function(responsedata) {

            closeModal();

            // request is set to valid
            if (typeof(Storage) != "undefined") {
                sessionStorage.setItem("validRequest", "true");
            }

            $location.path('/systemerror');
        });

    } else {

        // reqId or transId is empty - bogus request
        // redirecting user to portal entry page
        window.location.href = "index.html";
    }

});

paymentApp.controller('successController', function($scope, $rootScope, $location) {
    $scope.wirelessNumFlag = true;
    $scope.name = $rootScope.name;
    $scope.imei = $rootScope.imei;
    $scope.ctn = $rootScope.ctn;
    $scope.orderNumber = $rootScope.orderNumber;
    $scope.total_Payment = $rootScope.total_Payment;
    $scope.paymentDate = $rootScope.paymentDate;
    $scope.paymentTime = $rootScope.paymentTime;
    if ($scope.ctn == "" || $scope.ctn == null)
        $scope.wirelessNumFlag = false;
    //$scope.$apply();

});


paymentApp.controller('paymentCancelledController', function($scope, $rootScope, $location) {
    // $scope.OrderNumber=$rootScope.OrderNumber;
    $scope.paymentCancelMsg = $rootScope.paymentCancelMsg;
    $scope.displaySysError = false;

});


paymentApp.controller('linkExpController', function($scope, $rootScope, $location) {
    $scope.errorLinkExpMsg = $rootScope.errorLinkExpMsg;
    $scope.displaySysError = false;

});


paymentApp.controller('systemErrorController', function($scope, $rootScope, $location) {
    $scope.displaySysError = true;

});


paymentApp.controller('paymentSessionTimeOutController', function($scope, $rootScope, $location) {
    $scope.timeOutErrorMsg = $rootScope.timeOutErrorMsg;
    $scope.displaySysError = false;

});


paymentApp.controller('AController', function($scope, $sce, $rootScope, $http, $location) {

    $scope.displaySysError = false;

    $scope.orderNumber = $rootScope.orderNumber;
    $scope.imei = $rootScope.imei;
    $scope.paymentToken = $rootScope.paymentToken;
    //$scope.$apply();

    $scope.addressFlag = '';
    $scope.serviceTax = "--.--";
    $scope.totalTax = "10.00";
    $scope.type = "Credit";

    // Radio button validation starts    

    $scope.validateDebitRadio = function() {
        $scope.type = $scope.paymentForm.cardType.$viewValue;
    }

    $scope.validateCreditRadio = function() {
            $scope.type = "Credit";
        }
        // Radio button validation ends

    // fetch json to get validation messages
    $http({
        method: 'GET',
        url: dictJsonUrl
    }).success(function(errorResponsedata) {
        $scope.nameErrorMsg = errorResponsedata['ULP_1020'];
        //$scope.nameErrorMsg = errorResponsedata['ULP_1020'];
        $scope.cardNullerrorMsg = errorResponsedata['ULP_1021'];
        $scope.cardNumerrorMsg = errorResponsedata['ULP_1022'];
        $scope.expDateErrorMsg = errorResponsedata['ULP_1023'];
        $scope.secNumerrorMsg = errorResponsedata['ULP_1024'];
        $scope.address1errorMsg = errorResponsedata['ULP_1025'];
        $scope.cityerrorMsg = errorResponsedata['ULP_1026'];
        $scope.stateerrorMsg = errorResponsedata['ULP_1027'];
        $scope.zipCodeerrorMsg = errorResponsedata['ULP_1028'];
    });

    // OnFocus Call starts 

    $scope.fieldFocus = function(val, fld) {
        if (fld == 'nameOnCardFocus') {
            $scope.nameOnCardFocus = val;
            var inputnameoncard = $scope.paymentForm.name_card.$viewValue;
            if (typeof(inputnameoncard) != "undefined") {
                if (val == false) {

                    if (inputnameoncard.length > 0) {
                        // in case name on card is not empty
                        $scope.nameerror = false;

                    }

                    if (inputnameoncard.length == 0) {
                        // in case name on card length is zero
                        $scope.nameerror = true;

                    }
                    if ($scope.nameerror != true) {
                        // When page loads and No error message is active
                        $scope.nameerror = false;
                    }
                    if (/[^0-9A-Za-z ]/.test(inputnameoncard)) {
                        // in case it is not a valid name on card
                        $scope.nameerror = true;

                    }



                }
            }
        }

        if (fld == 'cardNumFocus') {
            $scope.cardNumFocus = val;
            var inputcardNumber = $scope.paymentForm.card_number.$viewValue;
            if (typeof(inputcardNumber) != "undefined") {
                if (val == false) {

                    if (inputcardNumber.length > 0) {
                        // in case inputcardNumber is not empty
                        $scope.cardNumerr = false;
                        $scope.cardNumerror = false;
                        $scope.cardNullerror = false;


                    }

                    if (inputcardNumber.length == 0) {
                        // in case imei length is zero
                        $scope.cardNumerr = true;
                        $scope.cardNullerror = true;
                        $scope.cardNumerror = false;

                    }
                    if ($scope.cardNumerr != true) {
                        $scope.cardNumerr = false;
                        $scope.cardNumerror = false;
                        $scope.cardNullerror = false;
                    }
                    if (/[^0-9]/.test(inputcardNumber)) {
                        // in case it is not a numeric value
                        $scope.cardNumerr = true;
                        $scope.cardNumerror = true;
                        $scope.cardNullerror = false;

                    }



                }
            }
        }

        if (fld == 'securityCodeFocus') {
            $scope.securityCodeFocus = val;
            var secCode = $scope.paymentForm.Security_code.$viewValue;
            if (typeof(secCode) != "undefined") {
                if (val == false) {

                    if (secCode.length > 0) {
                        // in case securityCode is less than 4 digits
                        $scope.secNumerror = false;

                    }

                    if (secCode.length == 0) {
                        // in case securityCode length is zero
                        $scope.secNumerror = true;

                    }

                    if ($scope.secNumerror != true) {
                        // When page loads and No error message is active
                        $scope.secNumerror = false;


                    }
                    if (/[^0-9]/.test(secCode)) {
                        // in case securityCode is not a numeric value
                        $scope.secNumerror = true;

                    }

                }
            }
        }

        if (fld == 'add1Focus') {
            $scope.add1Focus = val;
            $scope.address1error = '';
            $scope.addPrevious = $scope.paymentForm.address_line_1.$viewValue;
        }

        if (fld == 'add2Focus') {
            $scope.add2Focus = val;
        }

        if (fld == 'cityFocus') {
            $scope.cityFocus = val;
            $scope.cityerror = '';
            $scope.cityPrevious = $scope.paymentForm.City.$viewValue;
        }

        if (fld == 'zipCodeFocus') {
            $scope.zipCodeFocus = val;
            $scope.zipCodeerror = '';

        }

        if (fld == 'stateFocus') {
            $scope.statePrevious = $scope.paymentForm.states.$viewValue;
        }


        // Fix for IE8
        jQuery(".app-container").addClass("abc").removeClass("abc");
    }



    // OnFocus Call ends 

    //ng-keydown & ng-keyup name on card field 
    $scope.nameonCardValidate = function() {

        var inputnameoncard = $scope.paymentForm.name_card.$viewValue;
        if (typeof(inputnameoncard) != "undefined") {
            if (inputnameoncard.length > 0) {
                $scope.nameerror = false;

            } else {
                $scope.nameerror = true;

            }
        }

        // Fix for IE8
        jQuery(".app-container").addClass("abc").removeClass("abc");


    }


    //ng-keydown & ng-keyup card number field
    $scope.cardNumValidate = function() {

        var inputcardNumber = $scope.paymentForm.card_number.$viewValue;
        if (typeof(inputcardNumber) != "undefined") {
            if (inputcardNumber.length > 0) {
                $scope.cardNumerr = false;
                $scope.cardNumerror = false;
                $scope.cardNullerror = false;

            } else {
                $scope.cardNullerror = true;
                $scope.cardNumerr = true;
                $scope.cardNumerror = false;

            }
        }

        // Fix for IE8
        jQuery(".app-container").addClass("abc").removeClass("abc");


    }


    //ng-keydown & ng-keyup securityCode field

    $scope.securityCodeValidate = function() {

        var secCode = $scope.paymentForm.Security_code.$viewValue;
        if (typeof(secCode) != "undefined") {
            if (secCode.length > 0) {
                $scope.secNumerror = false;

            } else {
                $scope.secNumerror = true;


            }
        }

        // Fix for IE8
        jQuery(".app-container").addClass("abc").removeClass("abc");


    }


    //ng-keydown & ng-keyup address1 field

    $scope.address1validate = function() {

        var address1 = $scope.paymentForm.address_line_1.$viewValue;
        if (typeof(address1) != "undefined") {
            if (address1.length > 0) {
                $scope.address1error = false;

            } else {
                $scope.address1error = true;


            }
        }

        // Fix for IE8
        jQuery(".app-container").addClass("abc").removeClass("abc");

    }


    //////////////////City Validation on keydown and Key up///////////////

    //ng-keydown & ng-keyup city field

    $scope.cityvalidate = function() {

        var city1 = $scope.paymentForm.City.$viewValue;
        if (typeof(city1) != "undefined") {
            if (city1.length > 0) {
                $scope.cityerror = false;

            } else {
                $scope.cityerror = true;


            }
        }

        // Fix for IE8
        jQuery(".app-container").addClass("abc").removeClass("abc");

    }


    //////////////////////////////////////////////////////////////////////


    //////////////////ZIP Code Validation on keydown and Key up///////////////

    //ng-keydown & ng-keyup zipcode field

    $scope.zipcodevalidate = function() {

        var zipcode = $scope.paymentForm.Zip_Codes.$viewValue;
        if (typeof(zipcode) != "undefined") {
            if (zipcode.length > 0) {
                $scope.zipCodeerror = false;

            } else {
                $scope.zipCodeerror = true;


            }
        }

        // Fix for IE8
        jQuery(".app-container").addClass("abc").removeClass("abc");

    }

    //////////////////////////////////////////////////////////////////////

    // OnSubmit call starts

    $scope.continueForm = function(isValid) {

            $scope.maxAttemptError = false;
            $scope.cardValidationError = false;
            $scope.systemError = false;

            if (isValid) {

                if ($scope.addressFlag) {

                    $scope.calTax();
                }


                $scope.isDisabled = true;
                initialJson = {
                    "unlockPaymentProcessRequest": {
                        "orderDetail": {
                            "orderNumber": $scope.orderNumber,
                            "imei": $scope.imei,
                            "ctn": $scope.ctnToken  ,
                            "market": $scope.marketToken ,
                            "submarket" : $scope.submarketToken ,
                            "firstName" : $scope.firstNameToken ,
                            "lastName"  : $scope.lastNameToken 
                        },
                        "paymentDetail": {
                            "cardInfo": {
                                "paymentMethod": $scope.type,
                                "nameOnCard": $scope.nameCard,
                                "cardNumber": $scope.cardNumber,
                                "expirationDate": $scope.expMonth + $scope.expYear,
                                "securityCode": $scope.secCode
                            },
                            "billingAddress": {
                                "addressLine1": $scope.address1,
                                "addressLine2": $scope.address2,
                                "city": $scope.city1,
                                "state": $scope.states,
                                "zipCode": $scope.zipCode
                            },
                            "charges": {
                                "totalPayment": $scope.totalTax,
                                "paymentToken": $scope.paymentToken,
                                "geoCode"     : $scope.geoCode
                            },
                            "taxDetail": $scope.taxArray
                        }
                    }
                };

                var dcsuri = '/paymentcontent';
                var wtStatusFlag = '1';
                var wtStatusCode = '0';
				var wtEvent = 'myATT_DeviceUnlock_Payment_SUB';

                $http({
                    method: 'POST',
                    url: unlockApiUrl.paymentProcess,
                    data:  initialJson

                }).success(function(responsedata) {

            		// request is set to valid
            		if (typeof(Storage) != "undefined") {
                        sessionStorage.setItem("validRequest", "true");
           			}

                    if (responsedata.unlockPaymentProcessResponse.serviceStatus.code == 0) {

                        // server side validation passed
                        $rootScope.name = $scope.paymentForm.name_card.$viewValue; //replace
                        $rootScope.imei = responsedata.unlockPaymentProcessResponse.unlockOrderDetail.imei;
                        $rootScope.ctn = responsedata.unlockPaymentProcessResponse.unlockOrderDetail.ctn;
                        $rootScope.orderNumber = responsedata.unlockPaymentProcessResponse.unlockOrderDetail.orderNumber;
                        $rootScope.total_Payment = $scope.totalTax; //replace
                        var paymentDateTime = responsedata.unlockPaymentProcessResponse.unlockOrderDetail.paymentDateTime;
                        $rootScope.paymentDate = paymentDateTime.substring(0, 10);
                        $rootScope.paymentTime = paymentDateTime.substring(11, 17);

                        //Setting session variable for thank you page access outside manage
                        sessionStorage.isPaymentStatusPage = "yes";
                        dcsuri = '/paymentthankyou';
                        wtStatusFlag = '1';
                        wtStatusCode = '0';
						wtEvent = 'myATT_DeviceUnlock_Payment_SUB';
                        $location.path('/paymentthankyou');

                    } else if (responsedata.unlockPaymentProcessResponse.serviceStatus.code == 1) {

                        // request is set to valid
                        $scope.isDisabled = false;

                        wtStatusFlag = '0';
                        wtStatusCode = responsedata.unlockPaymentProcessResponse.errorInfo.errorCode;
						wtEvent = 'myATT_DeviceUnlock_Error_SUB';

                        if (responsedata.unlockPaymentProcessResponse.errorInfo.errorCode == "ULP_2010") { // grayout

                            $scope.maxAttemptError = true;

                            $scope.cardValidationError = false;
                            $scope.systemError = false;
                            $scope.apiError = false;

                            $scope.maxAttemptErrorMsg = responsedata.unlockPaymentProcessResponse.errorInfo.errorDescription;

                        } else if (responsedata.unlockPaymentProcessResponse.errorInfo.errorCode == "ULP_2011") { // timed out
                            //$scope.timeOutError = true;
                            $rootScope.timeOutErrorMsg = responsedata.unlockPaymentProcessResponse.errorInfo.errorDescription;
                            dcsuri = '/paymentsessiontimeout';
                            $location.path('/paymentsessiontimeout');

                        } else { // don't gray out
                            // error - payment failed (card details wrong)
                            // display validation error on top

                            $scope.cardValidationError = true;

                            $scope.maxAttemptError = false;
                            $scope.systemError = false;
                            $scope.apiError = false;

                            $scope.cardErrorMsg = responsedata.unlockPaymentProcessResponse.errorInfo.errorDescription;
                        }

                    } else { // code is 2

                        // request is set to valid
                        $scope.isDisabled = false;

                        $scope.systemError = true;

                        $scope.maxAttemptError = false;
                        $scope.apiError = false;
                        $scope.cardValidationError = false;

                        $scope.sysErrorMessage = responsedata.unlockPaymentProcessResponse.errorInfo.errorDescription;

                        wtStatusFlag = '0';
                        wtStatusCode = responsedata.unlockPaymentProcessResponse.errorInfo.errorCode;
						wtEvent = 'myATT_DeviceUnlock_Error_SUB';

                    }

                    //action event ---For Web Trends **
                    dcsMultiTrack('DCS.dcssip', 'www.att.com', 'DCS.dcsref', window.location.href, 'DCS.dcsuri', dcsuri,  'DCS.dcsua', navigator.userAgent, 'browserid', navigator.appCodeName, 'DCSext.wtPN', 'Device Unlock Portal Payment Pg', 'DCSext.wtEvent', wtEvent, 'DCSext.wtSuccessFlag', wtStatusFlag, 'DCSext.wtStatusCode', wtStatusCode, 'DCSext.wtNoHit', '1', 'DCSext.wtPmtMethod', $scope.type);



                }).error(function(responsedata) {
                    $scope.isDisabled = false;

                    // request is set to valid
                    if (typeof(Storage) != "undefined") {
                        sessionStorage.setItem("validRequest", "true");
                    }

                    $scope.apiError = true;

                    $scope.cardValidationError = false;
                    $scope.maxAttemptError = false;
                    $scope.systemError = false;

                });

                //if ends

            } else {

                // Invalid scenario

                //Name on Card
                $scope.nameCard = $scope.paymentForm.name_card.$viewValue;

                if ($scope.nameCard == "" || $scope.nameCard == null) {
                    $scope.nameerror = true;
                } else if (/[^0-9a-zA-z ]/.test($scope.nameCard)) {
                    $scope.nameerror = true;
                }

                //Card Number
                $scope.cardNumber = $scope.paymentForm.card_number.$viewValue;

                if ($scope.cardNumber == "" || $scope.cardNumber == null) {
                    $scope.cardNullerror = true;
                    $scope.cardNumerr = true;
                    $scope.cardNumerror = false;
                } else if (/[^0-9]/.test($scope.cardNumber)) {
                    $scope.cardNumerror = true;
                    $scope.cardNumerr = true;
                    $scope.cardNullerror = false;
                }

                //Security Code
                $scope.secCode = $scope.paymentForm.Security_code.$viewValue;

                if ($scope.secCode == "" || $scope.secCode == null) {
                    $scope.secNumerror = true;
                } else if (/[^0-9]/.test($scope.secCode)) {
                    $scope.secNumerror = true;
                }

                //Expiration Date validation

                $scope.expDateerror = '';
                var expMonth = $scope.paymentForm.expiration_date_mnth.$viewValue;
                var expYear = $scope.paymentForm.expiration_date_year.$viewValue;
                var today = new Date();
                var currentMonth = today.getMonth() + 1;
                var currentYear = today.getFullYear();

                if (expMonth == null || expMonth == "" || expYear == null || expYear == "") {
                    $scope.expDateerror = true;
                } else if (expMonth < currentMonth && expYear <= currentYear) {
                    $scope.expDateerror = true;
                }

                //Address 1 validation

                $scope.address1 = $scope.paymentForm.address_line_1.$viewValue;

                if ($scope.address1 == "" || $scope.address1 == null) {
                    $scope.address1error = true;
                } else if (/[^0-9a-zA-Z ]/.test($scope.address1)) {
                    $scope.address1error = true;
                } else {
                    if ($scope.taxFlag) {
                        if ($scope.addPrevious != $scope.address1 && $scope.addPrevious != null)
                            $scope.calTax();
                        $scope.addressFlag = true;
                    }
                }

                //City validation

                $scope.city1 = $scope.paymentForm.City.$viewValue;

                if ($scope.city1 == "" || $scope.city1 == null) {
                    $scope.cityerror = true;
                } else if (/[^0-9a-zA-Z ]/.test($scope.city1)) {
                    $scope.cityerror = true;
                } else {
                    if ($scope.taxFlag) {
                        if ($scope.cityPrevious != $scope.city1 && $scope.cityPrevious != null)
                            $scope.calTax();
                        $scope.addressFlag = true;
                    }
                }

                //State Validation

                $scope.states = $scope.paymentForm.states.$viewValue;
                $scope.stateerror = '';

                if ($scope.states == null || $scope.states == "") {
                    $scope.stateerror = true;
                } else {
                    if ($scope.taxFlag) {
                        if ($scope.statePrevious != $scope.states && $scope.statePrevious != null)
                            $scope.calTax();
                        $scope.addressFlag = true;
                    }
                }

                //Zip Code Validation

                $scope.serviceTax = "--.--";
                $scope.totalTax = "10.00";
                var ZipCodeFlag = true;
                $scope.taxFlag = '';
                var zipCode = $scope.paymentForm.Zip_Codes.$viewValue;

                if (zipCode == "" || zipCode == null) {
                    $scope.zipCodeerror = true;
                    ZipCodeFlag = false;
                } else if (zipCode.length < 5) {
                    $scope.zipCodeerror = true;
                    ZipCodeFlag = false;
                }

                // why call calTax over here?
                //if (ZipCodeFlag)
                //  $scope.calTax();

                //API Error
                $scope.apiError = false;
            }


            // Fix for IE8
            jQuery(".app-container").addClass("abc").removeClass("abc");


        }
        // OnSubmit Call ends    



    //Expiration Date validation starts

    $scope.verifyExpDate = function() {
        $scope.expDateerror = '';
        var expMonth = $scope.paymentForm.expiration_date_mnth.$viewValue;
        var today = new Date();
        var currentMonth = today.getMonth() + 1;

        if (expMonth == null || expMonth == "") {
            $scope.expDateerror = true;
        }

        if ($scope.yearSelected) {
            var expYear = $scope.paymentForm.expiration_date_year.$viewValue;
            var currentYear = today.getFullYear();

            if (expMonth < currentMonth && expYear <= currentYear) {
                $scope.expDateerror = true;
            }
        }

    }

    //Expiration Date validation ends



    //Expiration Year validation starts

    $scope.verifyExpYear = function() {
        $scope.expDateerror = '';
        var expMonth = $scope.paymentForm.expiration_date_mnth.$viewValue;
        var expYear = $scope.paymentForm.expiration_date_year.$viewValue;
        var today = new Date();
        var currentMonth = today.getMonth() + 1;
        var currentYear = today.getFullYear();

        if (expMonth == null || expMonth == "" || expYear == null || expYear == "") {
            $scope.expDateerror = true;
        } else if (expMonth < currentMonth && expYear <= currentYear) {
            $scope.expDateerror = true;
        }

        $scope.yearSelected = true;
    }

    //Expiration Year validation ends


    // Address 1 validation starts

    $scope.verifyAddress1 = function() {
            $scope.add1Focus = false;
            $scope.address1 = $scope.paymentForm.address_line_1.$viewValue;

            if ($scope.address1 == "" || $scope.address1 == null) {
                $scope.address1error = true;
            } else if (/[^0-9a-zA-Z ]/.test($scope.address1)) {
                $scope.address1error = true;
            } else {
                if ($scope.taxFlag) {
                    if ($scope.addPrevious != $scope.address1 && $scope.addPrevious != null)
                        $scope.calTax();
                    $scope.addressFlag = true;
                }
            }
        }
        // Address 1 validation ends

    // City Field validation starts

    $scope.verifyCity = function() {
            $scope.cityFocus = false;
            $scope.city1 = $scope.paymentForm.City.$viewValue;

            if ($scope.city1 == "" || $scope.city1 == null) {
                $scope.cityerror = true;
            } else if (/[^0-9a-zA-Z ]/.test($scope.city1)) {
                $scope.cityerror = true;
            } else {
                if ($scope.taxFlag) {
                    if ($scope.cityPrevious != $scope.city1 && $scope.cityPrevious != null)
                        $scope.calTax();
                    $scope.addressFlag = true;
                }
            }
        }
        // City Field validation ends

    //state validation starts

    $scope.verifyState = function() {
            $scope.states = $scope.paymentForm.states.$viewValue;
            $scope.stateerror = '';

            if ($scope.states == null || $scope.states == "") {
                $scope.stateerror = true;
            } else {
                if ($scope.taxFlag) {
                    if ($scope.statePrevious != $scope.states && $scope.statePrevious != null)
                        $scope.calTax();
                    $scope.addressFlag = true;
                }
            }
        }
        //state validation ends

    // ZipCode Verification starts

    $scope.verifyZipCode = function() {
            $scope.zipCodeFocus = false;
            $scope.serviceTax = "--.--";
            $scope.totalTax = "10.00";
            var ZipCodeFlag = true;
            $scope.taxFlag = '';
            var zipCode = $scope.paymentForm.Zip_Codes.$viewValue;

            if (zipCode == "" || zipCode == null) {
                $scope.zipCodeerror = true;
                ZipCodeFlag = false;
            } else if (zipCode.length < 5) {
                $scope.zipCodeerror = true;
                ZipCodeFlag = false;
            }
            if (ZipCodeFlag)
                $scope.calTax();
        }
        // ZipCode Verification ends

    // Tax Calculation Starts

    $scope.calTax = function() {

            $scope.serviceTax = "--.--";
            $scope.totalTax = "10.00";

            initialJson = {
                "calculateTaxRequest": {
                    "chargeAmount": "10.00" ,
                    "addressLine1": $scope.address1,
                    "addressLine2": $scope.address2,
                    "city": $scope.city1,
                    "state": $scope.states,
                    "zipCode": $scope.zipCode
                }
            };
            $http({
                method: 'POST',
                url: unlockApiUrl.calculateTax,
                data:  initialJson

            }).success(function(resdata) {
                if (resdata.calculateTaxResponse.serviceStatus.code == 0) {

                    $scope.serviceTax = resdata.calculateTaxResponse.totalTax;
                    $scope.taxArray = resdata.calculateTaxResponse.taxDetail;
                    $scope.geoCode = resdata.calculateTaxResponse.geoCode;                   

                    /*
                    $scope.taxType = resdata.calculateTaxResponse.taxDetail.taxType;
                    $scope.taxAuthority = resdata.calculateTaxResponse.taxDetail.taxAuthority;
                    $scope.geoCode = resdata.calculateTaxResponse.taxDetail.geoCode;*/

                    $scope.totalTax = parseFloat($scope.serviceTax) + parseFloat($scope.totalTax);
                    $scope.taxFlag = true;

                } else {

                    $scope.systemError = true;
                    $scope.apiError = false;
                    $scope.maxAttemptError = false;
                    $scope.cardValidationError = false;

                    $scope.sysErrorMessage = resdata.calculateTaxResponse.errorDescription;
                }

            }).error(function(resdata) {

                $scope.apiError = true;
                $scope.maxAttemptError = false;
                $scope.cardValidationError = false;
                $scope.systemError = false;
            });
        }
        // Tax Calculation ends

});