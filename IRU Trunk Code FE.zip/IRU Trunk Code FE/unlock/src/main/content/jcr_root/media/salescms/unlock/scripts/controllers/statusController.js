/*
statusController.js: This is being used in the deviceunlockstatus page. The function of this controller is to provide the unlock status to the users 
when they enters a valid imei number and request/order number and hit submit button. Two controllers are used here namely AController and statusController.
These two controller handles the functioning of the page.
*/
var orderStatusApp = angular.module('orderStatusApp', ['ngRoute', 'ngSanitize']);

orderStatusApp.config(function($routeProvider, $locationProvider) {
    $routeProvider

    // route for the home page and subsequest response pages
        .when('/', {
            templateUrl: unlockTemplateUrl.deviceUnlockStatusContent,
            controller: 'AController'
        })
        .when('/requestinprogress', {
            templateUrl: unlockTemplateUrl.requestInProgress,
            controller: 'statusController'
        })
        .when('/requestdenied', {
            templateUrl: unlockTemplateUrl.requestDenied,
            controller: 'statusController'
        })
        .when('/requestcancelled', {
            templateUrl: unlockTemplateUrl.requestCancelled,
            controller: 'statusController'
        })
        .when('/requestcompleted', {
            templateUrl: unlockTemplateUrl.requestCompleted,
            controller: 'statusController'
        })
        .when('/irequestcompleted', {
            templateUrl: unlockTemplateUrl.iRequestCompleted,
            controller: 'statusController'
        })
        .otherwise({
            redirectTo: '/'
        });
});


orderStatusApp.run(function($rootScope, $route, $location) {
    window.scrollTo(0, 0);
    $rootScope.$on('$locationChangeStart', function(ev, next, current) {
        //Setting page name value form edd doc
        var wtPN = "";
        if ($location.path().indexOf('/') == '0') {
            wtPN = "Device Unlock Portal Status Entry Pg";
        }
        if ($location.path().indexOf('/requestinprogress') == '0') {
            wtPN = "Device Unlock Portal Status In Progress Pg";
        }
        if ($location.path().indexOf('/requestdenied') == '0') {
            wtPN = "Device Unlock Portal Status Denied Pg";
        }
        if ($location.path().indexOf('/requestcancelled') == '0') {
            wtPN = "Device Unlock Portal Status Canceled Pg";
        }
        if ($location.path().indexOf('/requestcompleted') == '0') {
            wtPN = "Device Unlock Portal Status Completed Pg";
        }
        if ($location.path().indexOf('/irequestcompleted') == '0') {
            wtPN = "Device Unlock Portal Status Completed Pg";
        }

        //Calling web trends function at page load
        webtrendsPageHitCapture(wtPN, current);


        //checking url on location change start
        if ($location.path().indexOf('/requestinprogress') == '0' || $location.path().indexOf('/requestdenied') == '0' || $location.path().indexOf('/requestcancelled') == '0' || $location.path().indexOf('/requestcompleted') == '0' || $location.path().indexOf('/irequestcompleted') == '0') {
            var msg = sessionStorage.isValidUnlockStatusPage;
            //checking session while accesing unlock request page
            if (msg == "yes") {
                //user can access unlock request page
                //disable session
                sessionStorage.isValidUnlockStatusPage = "no";
            } else {
                //redirecting user to portal entry page
                window.location.href = "index.html";
            }
        } else {

        }
    });
});

/* Fix for placeholder for IE 
jQuery(window).load(function() {
    jQuery("#Request_Number").val(jQuery("#Request_Number").attr("placehold"));
    jQuery("#IMEI_Number").val(jQuery("#IMEI_Number").attr("placehold"));
});*/


orderStatusApp.controller('statusController', function($scope, $rootScope, $sce, $location, $http) {
    window.scrollTo(0, 0);
    $scope.emailtext = ''; //variable to bind the response when API Fails to send email
    $scope.showEmailLink = true; //for displaying email text


    // code below binds response of API to status page
    $scope.header = $rootScope.header;
    $scope.leadingMessage = $rootScope.leadingMessage;
    if ($rootScope.systemMessage != "") {
        $scope.systemHtmlData = $rootScope.systemMessage;

        $scope.$watch("systemHtmlData", function(newValue) {
            $scope.systemMessage = $sce.trustAsHtml(newValue);
        });
        $scope.systemMsgView = true;
    }

    if (($rootScope.targetView == "irequestcompleted") || ($rootScope.targetView == "requestcompleted")) {
        $scope.instructionHtmlData = $rootScope.instructionMessage;

        $scope.$watch("instructionHtmlData", function(newValue) {
            $scope.instructionMessage = $sce.trustAsHtml(newValue);
        });

    }

    if ($rootScope.unlockCode != "") {
        $scope.unlockCodeView = true;

        if ($rootScope.unlockCode == null) {
            $scope.unlockCode = "";
        } else {
            $scope.unlockCode = "<strong><u>" + $rootScope.unlockCode + "</u></strong>";
        }
    }

    $scope.trailingHtmlData = $rootScope.trailingMessage;

    $scope.$watch("trailingHtmlData", function(newValue) {
        $scope.trailingMessage = $sce.trustAsHtml(newValue);
    });
    $scope.unlockStatus = $rootScope.unlockStatus;
    $scope.unlockSubstatus = $rootScope.orderSubstatus;
    $scope.orderNumber = $rootScope.orderNumber;
    $scope.imeiNo = $rootScope.imeiNo;
    $scope.orderSubmitted = $rootScope.orderSubmitted;

    emailJSON = {
        "resendEmailNotificationRequest": {
            "orderDetail": {
                "orderNumber": $scope.orderNumber,
                "imei": $scope.imeiNo,
                "unlockStatus": $scope.unlockStatus,
                "unlockSubStatus": $scope.unlockSubstatus
            }
        }
    };


    // API call when user clicks the Email me this info link
    $scope.emailInfo = function() {

        $http({
                method: 'POST',
                url: unlockApiUrl.resendEmail,
                data: emailJSON
            }).success(function(emailresponsedata) {

                if (emailresponsedata.resendEmailNotificationResponse.serviceStatus.code == 0) {
                    //If email sent Successfully

                    $scope.showEmailLink = false;
                    $scope.emailsuccess = true;

                } else if ((emailresponsedata.resendEmailNotificationResponse.serviceStatus.code == 1) || (emailresponsedata.resendEmailNotificationResponse.serviceStatus.code == 2)) {
                    //in case of Partial Failure and Failure
                    $scope.showEmailLink = false;
                    $scope.emailtext = emailresponsedata.resendEmailNotificationResponse.errorDetail.errorDescription;
                    $scope.emailfailure = true;
                } else {
                    $scope.showEmailLink = false;
                    $scope.emailapifailure = true;
                }

            })
            .error(function(emailresponsedata) {
                $scope.showEmailLink = false;
                $scope.emailapifailure = true;
            });


    }


    $scope.webtrendsStatusLinkCapture = function(dcsuri, linkName) {
        var pageName = "";
        var linkLoc = "";
        if (dcsuri == "/requestdenied") {
            pageName = "Device Unlock Portal Status Denied Pg";
            linkLoc = "UnlockDevice_DeviceUnlockPortalStatusDeniedPg_Body";
        }
        if (dcsuri == "/requestinprogress") {
            pageName = "Device Unlock Portal Status In Progress Pg";
            linkLoc = "UnlockDevice_DeviceUnlockPortalStatusInProgressPg_Body";
        }
        if (dcsuri == "/requestcancelled") {
            pageName = "Device Unlock Portal Status Canceled Pg";
            linkLoc = "UnlockDevice_DeviceUnlockPortalStatusCanceledPg_Body";
        }
        if ((dcsuri == "/requestcompleted") || (dcsuri == "/irequestcompleted")) {
            pageName = "Device Unlock Portal Status Completed Pg";
            linkLoc = "UnlockDevice_DeviceUnlockPortalStatusCompletedPg_Body";
        }
        dcsMultiTrack('DCS.dcssip', 'www.att.com', 'DCS.dcsref', window.location.href, 'DCS.dcsuri', dcsuri, 'DCS.dcsua', navigator.userAgent, 'browserid', navigator.appCodeName, 'DCSext.wtPN', pageName, 'DCSext.wtLinkName', linkName, 'DCSext.wtLinkLoc', linkLoc, 'DCSext.wtNoHit', '1');
    }

    $scope.customizeStatusWindow = function(url) {
        window.open(url, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes,top=70, left=190, width=970, height=460");
    }

});



orderStatusApp.controller('AController', function($scope, $http, $rootScope, $location) {
    window.scrollTo(0, 0);

    // To dispay the error divs after page load
    jQuery("#imeiNumberimeierrorDiv").css("display", "block");
    jQuery("#imeiNumberInvalidimeierrorDiv").css("display", "block");
    jQuery("#requestNumberReqnoerrorDiv").css("display", "block");
    jQuery("#requestNumberInvalidDiv").css("display", "block");


    //fetch json to get validation messages
    $http({
            method: 'GET',
            url: dictJsonUrl
        })
        .success(function(errorresponsedata) {

            $scope.imeiReqField = errorresponsedata['USP_1001'];
            $scope.invalidimeiReqField = errorresponsedata['USP_1002'];

            $scope.reqnoReqField = errorresponsedata['USP_1003'];
            $scope.invalidreqnoReqField = errorresponsedata['USP_1004'];

            $scope.imeierr = false;
            $scope.imeierror = false;
            $scope.invalidimeierror = false;

            $scope.reqnoerror = false;
            $scope.reqerr = false;
            $scope.invalidreqnoerror = false;
        })
        .error(function(errorresponsedata) {
            $scope.status = 'error';
            $scope.apiError = true;

        });


    // Variable Initialization 
    $scope.leadMessage;
    $scope.sysMessage;
    $scope.trailMessage;
    $scope.keySpecs;



    //on focus event of textbox
    $scope.fieldFocus = function(val, fld) {
        var inputImei = $scope.statusForm.imeinumber.$viewValue;
        var inputRequestno = $scope.statusForm.reqnumber.$viewValue;
        var imeiPlacehold = jQuery("#IMEI_Number").attr("placehold");
        var requestNumPlacehold = jQuery("#Request_Number").attr("placehold");

        if (typeof(inputImei) != "undefined") {
            if (fld == 'imeiFocus') {
                $scope.imeiFocus = val;
                if (val == false && inputImei != imeiPlacehold) {

                    if (inputImei.length > 0 && inputImei.length < 15) {
                        // in case imei is less than 15 digits
                        $scope.imeierr = true;
                        $scope.invalidimeierror = true;
                        $scope.imeierror = false;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;


                    }

                    if (inputImei.length == 0) {
                        // in case imei length is zero
                        $scope.imeierr = true;
                        $scope.imeierror = true;
                        $scope.invalidimeierror = false;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;

                    }
                    if ($scope.imeierr != true) {
                        $scope.imeierr = false;
                        $scope.imeierror = false;
                        $scope.invalidimeierror = false;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;
                    }
                    if (/[^0-9]/.test(inputImei)) {
                        // in case it is not a numeric value
                        $scope.imeierr = true;
                        $scope.invalidimeierror = true;
                        $scope.imeierror = false;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;

                    }



                }
            }
        }
        if (typeof(inputRequestno) != "undefined") {
            if (fld == 'reqnoFocus') {

                $scope.reqnoFocus = val;

                if (val == false && inputRequestno != requestNumPlacehold) {


                    if (inputRequestno.length == 0) {
                        // in case length of Request no is Zero

                        $scope.reqerr = true;
                        $scope.reqnoerror = true;
                        $scope.invalidreqnoerror = false;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;
                    }
                    if ($scope.reqerr != true) {
                        $scope.reqerr = false;
                        $scope.reqnoerror = false;
                        $scope.invalidreqnoerror = false;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;
                    }

                    if (/[^0-9]/.test(inputRequestno)) {
                        // In case its not a Numeric value
                        $scope.reqerr = true;
                        $scope.reqnoerror = false;
                        $scope.invalidreqnoerror = true;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;

                    }

                }

            }

        }

        // Fix for IE8
        if (document.all && document.querySelector && !document.addEventListener) {
            jQuery(".app-container").addClass("abc").removeClass("abc");
        }
    }

    //textbox validation

    //ng-keydown & ng-keyup imei field
    $scope.imeiValidate = function() {

        var inputImei = $scope.statusForm.imeinumber.$viewValue;

        if (typeof(inputImei) != "undefined") {
            if (inputImei.length > 0) {
                $scope.imeierror = false;
                $scope.imeierr = false;
                $scope.invalidimeierror = false;

                $scope.status = '';
                $scope.commonError = false;

                $scope.apiError = false;

            } else {

                $scope.imeierror = true;
                $scope.imeierr = true;
                $scope.invalidimeierror = false;

                $scope.status = '';
                $scope.commonError = false;
                $scope.apiError = false;

            }

        }

        // Fix for IE8
        if (document.all && document.querySelector && !document.addEventListener) {
            jQuery(".app-container").addClass("abc").removeClass("abc");
        }

    }


    //ng-keydown & ng-keyup request field
    $scope.reqValidate = function() {

        var inputRequestno = $scope.statusForm.reqnumber.$viewValue;

        if (typeof(inputRequestno) != "undefined") {
            if (inputRequestno.length > 0) {
                $scope.reqnoerror = false;
                $scope.reqerr = false;
                $scope.invalidreqnoerror = false;

                $scope.status = '';
                $scope.commonError = false;
                $scope.apiError = false;

            } else {
                $scope.reqnoerror = true;
                $scope.reqerr = true;
                $scope.invalidreqnoerror = false;

                $scope.status = '';
                $scope.commonError = false;
                $scope.apiError = false;

            }
        }

        // Fix for IE8
        if (document.all && document.querySelector && !document.addEventListener) {
            jQuery(".app-container").addClass("abc").removeClass("abc");
        }


    }


    // Base64 decoding
    var Base64 = {

        _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

        encode: function(input) {
            var output = "";
            var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
            var i = 0;

            input = Base64._utf8_encode(input);

            while (i < input.length) {

                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);

                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;

                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }

                output = output + this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

            }

            return output;
        },


        decode: function(input) {
            var output = "";
            var chr1, chr2, chr3;
            var enc1, enc2, enc3, enc4;
            var i = 0;

            input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

            while (i < input.length) {

                enc1 = this._keyStr.indexOf(input.charAt(i++));
                enc2 = this._keyStr.indexOf(input.charAt(i++));
                enc3 = this._keyStr.indexOf(input.charAt(i++));
                enc4 = this._keyStr.indexOf(input.charAt(i++));

                chr1 = (enc1 << 2) | (enc2 >> 4);
                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                chr3 = ((enc3 & 3) << 6) | enc4;

                output = output + String.fromCharCode(chr1);

                if (enc3 != 64) {
                    output = output + String.fromCharCode(chr2);
                }
                if (enc4 != 64) {
                    output = output + String.fromCharCode(chr3);
                }

            }

            output = Base64._utf8_decode(output);

            return output;
        },

        _utf8_encode: function(string) {
            string = string.replace(/\r\n/g, "\n");
            var utftext = "";

            for (var n = 0; n < string.length; n++) {

                var c = string.charCodeAt(n);

                if (c < 128) {
                    utftext += String.fromCharCode(c);
                } else if ((c > 127) && (c < 2048)) {
                    utftext += String.fromCharCode((c >> 6) | 192);
                    utftext += String.fromCharCode((c & 63) | 128);
                } else {
                    utftext += String.fromCharCode((c >> 12) | 224);
                    utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
            }

            return utftext;
        },

        _utf8_decode: function(utftext) {
            var string = "";
            var i = 0;
            var c = c1 = c2 = 0;

            while (i < utftext.length) {

                c = utftext.charCodeAt(i);

                if (c < 128) {
                    string += String.fromCharCode(c);
                    i++;
                } else if ((c > 191) && (c < 224)) {
                    c2 = utftext.charCodeAt(i + 1);
                    string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                    i += 2;
                } else {
                    c2 = utftext.charCodeAt(i + 1);
                    c3 = utftext.charCodeAt(i + 2);
                    string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                    i += 3;
                }
            }

            return string;
        }

    }


    //On Form Submit
    $scope.continueForm = function(isValid) {

            $scope.status = '';
            $scope.commonError = false;

            $scope.imeierr = false;
            $scope.reqerr = false;

            $scope.invalidimeierror = false;
            $scope.invalidreqnoerror = false;

            $scope.imeierror = false; // to display imei error ng-class variable        
            $scope.reqnoerror = false; // to display request number error ng-class variable

            //$scope.imeiReqField =false;    // to display client side error message for imei number from dict.json
            //$scope.reqnoReqField=false;    // to display client side error message for request number from dict.json

            if (isValid) {
                openModal();
                $scope.isDisabled = true;
                initialJson = {
                    "unlockOrderStatusRequest": {
                        "orderDetail": {
                            "orderNumber": $scope.reqno,
                            "imei": $scope.imei
                        }
                    }
                };

                //CALLING WEBTRENDS

                var dcsuri = "";
                var wtStatusFlag = '1';
                var wtStatusCode = '0';
                var wtEvent = 'myATT_DeviceUnlock_StatusCheck_SUB';

                $http({
                        method: 'POST',
                        url: unlockApiUrl.orderStatus,
                        data: initialJson

                    }).success(function(responsedata) {
                        closeModal();

                        // server side validation passed
                        if (responsedata.unlockOrderStatusResponse.serviceStatus.code == 0 && responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode == "") {

                            if (typeof(responsedata.unlockOrderStatusResponse.view) != "undefined") {
                                if ((typeof(responsedata.unlockOrderStatusResponse.view.targetView) != "undefined")) {

                                    // In case of success response and when unlock code is empty. It handles the following status responses: denied,cancelled,inprogress,Request Completed for Iphone

                                    $scope.keySpecs = responsedata.unlockOrderStatusResponse.view.specification.key;


                                    for (i = 0; i < $scope.keySpecs.length; i++) {
                                        if ($scope.keySpecs[i].id == "leadingMessage") {
                                            $scope.leadMessage = $scope.keySpecs[i].text;
                                        }
                                        if ($scope.keySpecs[i].id == "systemMessage") {
                                            $scope.sysMessage = $scope.keySpecs[i].text;
                                        }
                                        if ($scope.keySpecs[i].id == "trailingMessage") {
                                            $scope.trailMessage = $scope.keySpecs[i].text;
                                        }
                                    }

                                    // rootScope to pass date to statusController after binding data from API response

                                    $rootScope.header = responsedata.unlockOrderStatusResponse.view.header;
                                    $rootScope.leadingMessage = $scope.leadMessage;
                                    $rootScope.systemMessage = $scope.sysMessage;
                                    $rootScope.imeiNo = responsedata.unlockOrderStatusResponse.unlockOrderDetail.imei;
                                    $rootScope.unlockCode = '';
                                    $rootScope.trailingMessage = $scope.trailMessage;
                                    $rootScope.unlockStatus = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockStatus;
                                    $rootScope.orderSubstatus = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockSubStatus;
                                    $rootScope.orderNumber = responsedata.unlockOrderStatusResponse.unlockOrderDetail.orderNumber;
                                    $rootScope.orderSubmitted = responsedata.unlockOrderStatusResponse.unlockOrderDetail.activityLog.orderSubmitted;

                                    //Variables passed to statusController For Complete Status 
                                    $rootScope.instructionMessage = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockDetail.instruction;
                                    $rootScope.targetView = responsedata.unlockOrderStatusResponse.view.targetView;


                                    //variables passed to webtrend action event
                                    dcsuri = '/' + $rootScope.targetView;

                                    wtStatusFlag = '1';
                                    wtStatusCode = '0';
                                    wtEvent = 'myATT_DeviceUnlock_StatusCheck_SUB';


                                    //Setting session variable for outside access maintainance
                                    sessionStorage.isValidUnlockStatusPage = "yes";

                                    //Identifies route based on the targetView response and displays the correspondong page
                                    $location.path('/' + responsedata.unlockOrderStatusResponse.view.targetView);


                                } else {

                                    // error - targetView is empty
                                    $scope.isDisabled = false;
                                    $scope.status = 'error';
                                    $scope.apiError = true;
                                    $scope.commonError = false;
                                }

                            } else {

                                // error - view is empty
                                $scope.isDisabled = false;
                                $scope.status = 'error';
                                $scope.apiError = true;
                                $scope.commonError = false;
                            }

                        } else if (responsedata.unlockOrderStatusResponse.serviceStatus.code == 0 && responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode != "") {						
						
                            //In case of success response and when unlock code is not empty. It handles the Request Completed status for Smartphones

                            if (typeof(responsedata.unlockOrderStatusResponse.view) != "undefined") {
                                if ((typeof(responsedata.unlockOrderStatusResponse.view.targetView) != "undefined")) {

                                    $scope.keySpecs = responsedata.unlockOrderStatusResponse.view.specification.key;
                                    for (i = 0; i < $scope.keySpecs.length; i++) {
                                        if ($scope.keySpecs[i].id == "leadingMessage") {
                                            $scope.leadMessage = $scope.keySpecs[i].text;
                                        }
                                        if ($scope.keySpecs[i].id == "systemMessage") {
                                            $scope.sysMessage = $scope.keySpecs[i].text;
                                        }
                                        if ($scope.keySpecs[i].id == "trailingMessage") {
                                            $scope.trailMessage = $scope.keySpecs[i].text;
                                        }
                                    }

                                    // rootScope to pass date to statusController after binding data from API response

                                    $rootScope.header = responsedata.unlockOrderStatusResponse.view.header;
                                    $rootScope.leadingMessage = $scope.leadMessage;
                                    $rootScope.systemMessage = $scope.sysMessage;
                                    $rootScope.imeiNo = responsedata.unlockOrderStatusResponse.unlockOrderDetail.imei;
                                    $rootScope.trailingMessage = $scope.trailMessage;
                                    $rootScope.unlockStatus = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockStatus;
                                    $rootScope.orderSubstatus = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockSubStatus;
                                    $rootScope.orderNumber = responsedata.unlockOrderStatusResponse.unlockOrderDetail.orderNumber;
                                    $rootScope.orderSubmitted = responsedata.unlockOrderStatusResponse.unlockOrderDetail.activityLog.orderSubmitted;
									
									// Decoding unlockCode (API sends in the Base64 encoded version as a resolution to defect #10189
									if (typeof responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode != "number") {
										$rootScope.unlockCode = Base64.decode(responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode);
									} else {
										$rootScope.unlockCode = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockCode;
									}
									
                                    //Variables passed to statusController For Complete Status
                                    $rootScope.instructionMessage = responsedata.unlockOrderStatusResponse.unlockOrderDetail.unlockDetail.instruction;
                                    $rootScope.targetView = responsedata.unlockOrderStatusResponse.view.targetView;


                                    //variables passed to webtrend action event
                                    dcsuri = '/' + $rootScope.targetView;
                                    wtStatusFlag = '1';
                                    wtStatusCode = '0';
                                    wtEvent = 'myATT_DeviceUnlock_StatusCheck_SUB';


                                    //Setting session variable for outside access maintainance
                                    sessionStorage.isValidUnlockStatusPage = "yes";

                                    //Identifies route based on the targetView response and displaus the correspondong page
                                    $location.path('/' + responsedata.unlockOrderStatusResponse.view.targetView);

                                } else {

                                    // error - targetView is empty
                                    $scope.isDisabled = false;
                                    $scope.status = 'error';
                                    $scope.apiError = true;
                                    $scope.commonError = false;
                                }

                            } else {

                                // error - view is empty
                                $scope.isDisabled = false;
                                $scope.status = 'error';
                                $scope.apiError = true;
                                $scope.commonError = false;

                            }

                        } else if (responsedata.unlockOrderStatusResponse.serviceStatus.code == 1) {
                            //In Case of Partial failure response from API

                            $scope.isDisabled = false;
                            $scope.status = 'error';
                            $scope.commonError = true;
                            $scope.apiError = false;
                            $scope.error = responsedata.unlockOrderStatusResponse.errorDetail.errorDescription;
                            //variables passed to webtrend action event
                            dcsuri = '/';
                            wtStatusFlag = '0';
                            wtStatusCode = responsedata.unlockOrderStatusResponse.errorDetail.errorCode;
                            wtEvent = 'myATT_DeviceUnlock_Error_SUB';
                        } else if (responsedata.unlockOrderStatusResponse.serviceStatus.code == 2) {
                            //In case of Failure response from API

                            $scope.isDisabled = false;
                            $scope.status = 'error';
                            $scope.commonError = true;
                            $scope.apiError = false;
                            $scope.error = responsedata.unlockOrderStatusResponse.errorDetail.errorDescription;

                            //variables passed to webtrend action event
                            dcsuri = '/';
                            wtStatusFlag = '0';
                            wtStatusCode = responsedata.unlockOrderStatusResponse.errorDetail.errorCode;
                            wtEvent = 'myATT_DeviceUnlock_Error_SUB';

                        } else {
                            //  fails to retrive json data(display status based on error)
                            $scope.isDisabled = false;
                            $scope.status = 'error';
                            $scope.apiError = true;
                            $scope.commonError = false;
                            //variables passed to webtrend action event
                            dcsuri = '/';
                            //wtStatusFlag = '0';
                            //wtStatusCode = '1';
                            //wtEvent = 'myATT_DeviceUnlock_Error_SUB';

                        }
                        //action event ---For Web Trends **
                        dcsMultiTrack('DCS.dcssip', 'www.att.com', 'DCS.dcsref', window.location.href, 'DCS.dcsuri', dcsuri, 'DCS.dcsua', navigator.userAgent, 'browserid', navigator.appCodeName, 'DCSext.wtPN', 'Device Unlock Portal Status Entry Pg', 'DCSext.wtEvent', wtEvent, 'DCSext.wtSuccessFlag', wtStatusFlag, 'DCSext.wtStatusCode', wtStatusCode, 'DCSext.wtNoHit', '1', 'DCSext.wtIMEI', $scope.imei);

                    })
                    .error(function(responsedata) {
                        closeModal();
                        $scope.isDisabled = false;
                        $scope.status = 'error';
                        $scope.apiError = true;
                        $scope.commonError = false;
                    });

            } //if ends
            else {
                // client side validation failure


                var inputImei = $scope.statusForm.imeinumber.$viewValue;
                var inputRequestno = $scope.statusForm.reqnumber.$viewValue;

                var imeiPlacehold = jQuery("#IMEI_Number").attr("placehold");
                var requestNumPlacehold = jQuery("#Request_Number").attr("placehold");

                //IMEI Validation
                if (inputImei == "" || inputImei == null) {
                    // in case fiels is empty
                    $scope.imeierror = true;
                    $scope.imeierr = true;
                    $scope.invalidimeierror = false;

                    $scope.status = '';
                    $scope.commonError = false;
                    $scope.apiError = false;
                } else if (inputImei == imeiPlacehold) {
                    // in case fiels is empty
                    $scope.imeierror = true;
                    $scope.imeierr = true;
                    $scope.invalidimeierror = false;

                    $scope.status = '';
                    $scope.commonError = false;
                    $scope.apiError = false;
                } else {
                    if (/[^0-9]/.test(inputImei)) {
                        // in case it is not a numeric value
                        $scope.imeierror = false;
                        $scope.imeierr = true;
                        $scope.invalidimeierror = true;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;
                    }

                    if (inputImei.length < 15) {
                        // in case imei is less than 15 digits
                        $scope.imeierror = false;
                        $scope.imeierr = true;
                        $scope.invalidimeierror = true;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;
                    }

                }

                // REQUEST FIeld
                if (inputRequestno == "" || inputRequestno == null) {
                    //in case request number is blank
                    $scope.reqnoerror = true;
                    $scope.reqerr = true;
                    $scope.invalidreqnoerror = false;

                    $scope.status = '';
                    $scope.commonError = false;
                    $scope.apiError = false;

                } else if (inputRequestno == requestNumPlacehold) {
                    //in case request number is blank
                    $scope.reqnoerror = true;
                    $scope.reqerr = true;
                    $scope.invalidreqnoerror = false;

                    $scope.status = '';
                    $scope.commonError = false;
                    $scope.apiError = false;

                } else {

                    if (/[^0-9]/.test(inputRequestno)) {
                        // In case its not a Numeric value
                        $scope.reqnoerror = false;
                        $scope.reqerr = true;
                        $scope.invalidreqnoerror = true;

                        $scope.status = '';
                        $scope.commonError = false;
                        $scope.apiError = false;
                    }
                }

            } //Else ends




            // Fix for IE8
            if (document.all && document.querySelector && !document.addEventListener) {
                jQuery(".app-container").addClass("abc").removeClass("abc");
            }

        } // continueForm ends

}).directive('placehold', function() {
    return {
        restrict: 'A',
        require: 'ngModel',


        link: function(scope, element, attr, ctrl) {

            var value;

            var placehold = function() {
                element.val(attr.placehold)
            };
            var unplacehold = function() {
                element.val('');
            };

            scope.$watch(attr.ngModel, function(val) {
                value = val || '';
            });

            element.bind('focus', function() {
                // if(value == '') unplacehold();


            });

            element.bind('blur', function() {
                if (element.val() == '') placehold();
            });

            ctrl.$formatters.unshift(function(val) {

                if (!val) {
                    placehold();
                    value = '';
                    return attr.placehold;
                }
                return val;
            });
        }
    };
});