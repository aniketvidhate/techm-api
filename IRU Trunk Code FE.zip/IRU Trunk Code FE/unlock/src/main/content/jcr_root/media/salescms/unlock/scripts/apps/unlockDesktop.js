// Function responsible for all color box Modals
function openColorBox(divid, accessibilityParam) {
    var divhtml = $("#" + divid).html();

    if (divid == "viewRemoteButtonGuide") {
        jQuery.colorbox({
            iframe: false,
            height: 'auto',
            maxHeight: 500,
            width: 800,
            scrolling: false,
            reposition: false,
            html: divhtml,
            onComplete: function() {
                jQuery("#colorbox,#cboxWrapper,#cboxContent,#cboxLoadedContent,.jspContainer").height(jQuery("#cboxContent .inlineModalContent img").height() + 100);
                jQuery("#cboxContent").height(jQuery("#cboxContent .inlineModalContent img").height() + 60);
                jQuery(".jspVerticalBar").empty(jQuery("#cboxContent .inlineModalContent img").height());
                jQuery(".modalContent").css('max-height', '552px');
            },
            onClosed: function() {
                jQuery(accessibilityParam).focus();
            }
        });
    } else if (divid == "cancelPaymentModal") {
        $.colorbox({
            iframe: false,
            escKey: false,
            overlayClose: false,
            scrolling: false,
            html: divhtml,

            onComplete: function() {
                jQuery("#cboxContent .inlineModalContent").width(jQuery("#cboxContent .modalContent").width());
                jQuery("#cboxContent .inlineModalContent").height(jQuery("#cboxContent .modalContent").height());
            },
            onClosed: function() {
                jQuery(accessibilityParam).focus();
            }
        });
    } else {
        jQuery.colorbox({
            iframe: false,
            //height: 790,
            //maxHeight: 650,
            //width: 796,
            scrolling: false,
            html: divhtml,
            onComplete: function() {
                jQuery("#cboxContent .inlineModalContent").width(jQuery("#cboxContent .modalContent").width());
                jQuery("#cboxContent .inlineModalContent").height(jQuery("#cboxContent .modalContent").height());
                //jQuery(".modalContent").css('max-height', '700px');
            },
            onClosed: function() {
                jQuery(accessibilityParam).focus();
            }
        });
    }
    return false;
}

//function for unlockrequestform to change form fields on the basis of radiobutton selected
function hideDiv(radio_btn) {

    var radio_btn_name = document.getElementsByName(radio_btn.name);
    document.getElementById('at&t_number').style.display = (radio_btn_name[3].checked) ? 'none' : 'block';
    document.getElementById('first_name').style.display = (radio_btn_name[2].checked || radio_btn_name[3].checked) ? 'none' : 'block';
    document.getElementById('last_name').style.display = (radio_btn_name[2].checked || radio_btn_name[3].checked) ? 'none' : 'block';
    document.getElementById('ssn_4digits').style.display = (radio_btn_name[2].checked || radio_btn_name[3].checked) ? 'none' : 'block';
    document.getElementById('at&t_passcode').style.display = (radio_btn_name[2].checked || radio_btn_name[3].checked) ? 'none' : 'block';
    document.getElementById('military_radio').style.display = (radio_btn_name[0].checked) ? 'block' : 'none';
    document.getElementById('firstName').style.display = (radio_btn_name[2].checked || radio_btn_name[3].checked) ? 'block' : 'none';
    document.getElementById('lastName').style.display = (radio_btn_name[2].checked || radio_btn_name[3].checked) ? 'block' : 'none';
}


function cancelPayment() {
    if (typeof(Storage) !== "undefined") {
        sessionStorage.pStatus = "true";
    } else {
        return false;
    }

}


function customizeWindow(url) {
    window.open(url, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes,top=70, left=190, width=970, height=460");
}


function webtrendsPageHitCapture(pageName, dcsuri) {
    dcsMultiTrack('DCS.dcssip', 'www.att.com', 'DCS.dcsref', window.location.href, 'DCS.dcsuri', dcsuri, 'DCS.dcsua', navigator.userAgent, 'browserid', navigator.appCodeName, 'DCSext.wtPN', pageName);
}


function webtrendsLinkCapture(pageName, dcsuri, linkName, linkLoc) {
    dcsMultiTrack('DCS.dcssip', 'www.att.com', 'DCS.dcsref', window.location.href, 'DCS.dcsuri', dcsuri, 'DCS.dcsua', navigator.userAgent, 'browserid', navigator.appCodeName, 'DCSext.wtPN', pageName, 'DCSext.wtLinkName', linkName, 'DCSext.wtLinkLoc', linkLoc, 'DCSext.wtNoHit', '1');
}


function openModal() {
		document.getElementById('modal').style.display = 'block';
		document.getElementById('fade').style.display = 'block';
}

function closeModal() {
	document.getElementById('modal').style.display = 'none';
	document.getElementById('fade').style.display = 'none';
}

//For Wireless Number textbox to block O and 1 at index 0
function checkFirstChar(ev, key, txt) {


    //var len=txt.value.slice(0, txt.selectionStart).length;
    if (getCursorPos(txt) == 0) {
        return (ev.ctrlKey || ev.altKey || (49 < key && key < 58 && ev.shiftKey == false) || (97 < key && key < 106) || (key == 8) || (key == 9) || (key > 34 && key < 40) || (key == 46));
    } else {
        return (ev.ctrlKey || ev.altKey || (47 < key && key < 58 && ev.shiftKey == false) || (95 < key && key < 106) || (key == 8) || (key == 9) || (key > 34 && key < 40) || (key == 46));
    }

}
// To get the Cursor position in Wireless Number Field
function getCursorPos(txt) {

    // IE Support
    if (document.selection) {

        // Set focus on the element
        txt.focus();

        // To get cursor position, get empty selection range
        var sel = document.selection.createRange();

        // Move selection start to 0 position
        sel.moveStart('character', -txt.value.length);

        // The caret position is selection length
        return sel.text.length;

    } else {

        var len = txt.value.slice(0, txt.selectionStart).length
        return len;
    }

}
