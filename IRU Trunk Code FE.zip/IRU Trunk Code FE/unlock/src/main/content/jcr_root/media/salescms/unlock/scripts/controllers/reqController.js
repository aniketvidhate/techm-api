var portalEntryApp = angular.module('portalEntryApp', ['ngRoute', 'ngCookies', 'ngSanitize']);

portalEntryApp.config(function($routeProvider) {

    $routeProvider

    // route for the home page
        .when('/', {
            templateUrl: unlockTemplateUrl.portalEntryPage,
            controller: 'ackController'
        })
        .when('/unlockrequest', {
            templateUrl: unlockTemplateUrl.unlockRequestContent,
            controller: 'reqController'
        })
        .when('/requestthank', {
            templateUrl: unlockTemplateUrl.unlockRequestThankYou,
            controller: 'thankController'
        })
        .otherwise({
            redirectTo: '/'
        });
});



portalEntryApp.run(function($rootScope, $route, $location, $cookieStore, $cookies) {
	window.scrollTo(0,0);
    $rootScope.$on('$locationChangeStart', function(ev, next, current) {
        //Setting page name value form edd doc
        var wtPN = "";
        if ($location.path().indexOf('/') == '0') {
            wtPN = "Consumer Device Unlock Portal Pg";
        }
        if ($location.path().indexOf('/unlockrequest') == '0') {
            wtPN = "Device Unlock Portal Information Pg";
        }
        if ($location.path().indexOf('/requestthank') == '0') {
            wtPN = "Device Unlock Portal Thank You Pg";
        }

        //Calling web trends function at page load
        webtrendsPageHitCapture(wtPN, current);


        //checking url on location change start
        if ($location.path().indexOf('/unlockrequest') == '0') {

            //checking cookies while accesing unlock request page
            if (sessionStorage.getItem("hasReadTerms") == 'yes') {
                //user can access unlock request page
            } else {
                //redirecting user to portal entry page
                $location.path('/');
            }

        } else if ($location.path().indexOf('/requestthank') == '0') {

            //checking session while accesing unlock request page
            if (sessionStorage.isvalidthankPage == "yes") {
                //user can access unlock request page
                sessionStorage.isvalidthankPage = "no";
                // delete sessionStorage.isvalidthankPage;
            } else {
                //redirecting user to portal entry page
                $location.path('/');
            }
        }
    });
});


/* Fix for placeholder for IE 
jQuery(window).load(function() {
    jQuery("#wirelessNo").val(jQuery("#wirelessNo").attr("placehold"));
    jQuery("#IMEI_Number").val(jQuery("#IMEI_Number").attr("placehold"));
    jQuery("#AHFirstName").val(jQuery("#AHFirstName").attr("placehold"));
    jQuery("#AHLastName").val(jQuery("#AHLastName").attr("placehold"));
    jQuery("#Text1").val(jQuery("#Text1").attr("placehold"));
    jQuery("#Text2").val(jQuery("#Text2").attr("placehold"));
    jQuery("#SSN").val(jQuery("#SSN").attr("placehold"));
    jQuery("#ATT_Account_Passcode").val(jQuery("#ATT_Account_Passcode").attr("placehold"));
    jQuery("#Email_PAddress").val(jQuery("#Email_PAddress").attr("placehold"));
});
*/



portalEntryApp.controller('ackController', function($window, $scope, $http, $rootScope, $location, $cookies) {
	window.scrollTo(0,0);
    //Checking html5 compatibility with browser
    if (typeof(Storage) !== "undefined") {
        //Checking variable value in session is true
        if (sessionStorage.pStatus == "true") {
            //Enable ng-show
            $scope.paymentStatus = "true";
            //Removing variable from session for always
            sessionStorage.removeItem("pStatus");
        }
    } else {
        $scope.paymentStatus = "false";
    }
	
	$scope.removeErr = function(e)
    {
        if (e.checked)
        {$rootScope.agreeCheckErr=false;}
        else
        {$rootScope.agreeCheckErr=true;}
    }

    $scope.saveData = function(pageName, dcsuri, linkName, linkLoc) {
        //$rootScope.agreeCheckValue=false;
        openModal();
        //post call start	
        // AOTS : 000000220418539 :  Device Unlock: Spanish page looping - added parameter in post call
        $http({
            method: 'POST',
            url: unlockApiUrl.sitecheck,
            data:{}
        }).success(function(checkSite) {

            //setting cookies for user acknowledgement
        if (typeof(Storage) != "undefined") {
            sessionStorage.setItem("hasReadTerms", "yes");
            sessionStorage.setItem("agreeCheckedBox", "no");
        }
        // to let user navigate to requestinfo page only after checking the checkbox
        if (document.getElementById("agree").checked)
        {
            //$rootScope.agreeCheckValue=true;
            sessionStorage.setItem("agreeCheckedBox", "yes");
            webtrendsLinkCapture(pageName, dcsuri, linkName, linkLoc);  //Calling web tends function
            closeModal();
            if(checkSite =="true"){
                $window.location.href = '/deviceunlock/request/#/unlockstep1';
            }else{
                $location.path('/unlockrequest');
            }
        }
        else{
            closeModal();
            $location.path('/');
        }
        }).error(function(data, status, headers, config) {
           closeModal();
            $location.path('/');
        });	
        //post call ends





    }
});


portalEntryApp.controller('thankController', function($scope, $sce, $rootScope, $location) {
	window.scrollTo(0,0);
    $scope.reqNumber = "<strong>" + $rootScope.UnlockReqNumber + "</strong>";
    //$scope.$apply();
});


portalEntryApp.controller('reqController', function($scope, $http, $rootScope, $location, $cookies, $window) {
	window.scrollTo(0,0);
	$window.location.href = '/deviceunlock/request/#/unlockstep1'; 
	
		jQuery("#wirelessNumberAlertDiv").css("display", "block");
        jQuery("#testWireNull").css("display", "block");
        jQuery("#testWireSize").css("display", "block");
        jQuery("#testImeiNull").css("display", "block");
        jQuery("#testImeiSize").css("display", "block");
        jQuery("#testFirstName").css("display", "block");
        jQuery("#testLastName").css("display", "block");
        jQuery("#testFirstNonATT").css("display", "block");
        jQuery("#testLastNonATT").css("display", "block");
        jQuery("#testSsnNull").css("display", "block");
        jQuery("#testSsnSize").css("display", "block");
        jQuery("#testEmailNull").css("display", "block");
        jQuery("#testEmailPat").css("display", "block");
		jQuery("#testEmailDomain").css("display", "block");
        jQuery("#testMilitary").css("display", "block");
        jQuery("#testCapNull").css("display", "block");
        jQuery("#testCapInvalid").css("display", "block");
    	jQuery("#testCommonError").css("display", "block");
        jQuery("#testAlreadyUnlockError").css("display", "block");
		jQuery("#testApiError").css("display", "block");
		jQuery("#testDictJsonError").css("display", "block");
		
		
    // fetch json to get validation messages
    $http({
        method: 'GET',
        url: dictJsonUrl
    }).success(function(jsonData) {
		$scope.sysErrMsgVal = true;
        $scope.cuType = jsonData['ULP_1001'];
        $scope.wireNullMsg = jsonData['ULP_1002'];
        $scope.wireSizeMsg = jsonData['ULP_1003'];
        $scope.imeiNullMsg = jsonData['ULP_1004'];
        $scope.imeiSizeMsg = jsonData['ULP_1006'];
        $scope.emailNullMsg = jsonData['ULP_1008'];
        $scope.emailPatMsg = jsonData['ULP_1009'];
        $scope.emailDomainMsg = jsonData['ULP_1010'];
        $scope.accFNameMsg = jsonData['ULP_1011'];
        $scope.accLNameMsg = jsonData['ULP_1013'];
        $scope.fNameMsg = jsonData['ULP_1012'];
        $scope.lNameMsg = jsonData['ULP_1014'];
        $scope.ssnNullMsg = jsonData['ULP_1015'];
        $scope.ssnSizeMsg = jsonData['ULP_1016'];
        $scope.miliNullMsg = jsonData['ULP_1017'];
        $scope.capNullMsg = jsonData['ULP_1018'];
        $scope.sysErrMsg = jsonData['ULS_3001'];
        $scope.alreadyUnlockMsg = jsonData['ULP_1030'];

        $scope.commonError = false;
        $scope.custtType = false;
        $scope.wireNull = false;
        $scope.wireSize = false;
        $scope.imeiNull = false;
        $scope.imeiSsize = false;
        $scope.emailNull = false;
        $scope.emailPat = false;
        $scope.emailDomain = false;
        $scope.accFNamecond = false;
        $scope.accLNamecond = false;
        $scope.fNamecond = false;
        $scope.lNamecond = false;
        $scope.miliNull = false;
        $scope.ssnNull = false;
        $scope.ssnSize = false;

        $scope.custtTypeErr = false;
        $scope.wireErr = false;
        $scope.imeiErr = false;
        $scope.emailErr = false;
        $scope.miliErr = false;
        $scope.ssnErr = false;

        // captcha variables 
        $scope.capToggleAudio = false;
        $scope.capToggleVisual = true;
		 window.scrollTo(0,0);   

    }).error(function(data, status, headers, config) {
	    window.scrollTo(0,0);   
        $scope.dictJsonError = true;
        $scope.sysErrMsgVal = false;
        $scope.alreadyUnlockError = false;
        $scope.commonError = false;

    });


    imageCaptchaJson = {
        "imageCaptchaRequest": {
            "captchaType": "image"
        }
    };


    // function to call the Image Captcha API
    $scope.callImageCaptcha = function() {
		$scope.capDisable= true;
		$scope.rePlay=false;
        $scope.CaptchaType = "image";
		
        $http({
            method: 'POST',
            url: unlockApiUrl.imageCaptchaUrl,
            data: imageCaptchaJson
        }).success(function(jsonCapImgData) {
            if (jsonCapImgData.imageCaptchaResponse.serviceStatus.code == 0) {
                $scope.capImg = 'data:image/jpeg;base64,' + jsonCapImgData.imageCaptchaResponse.captchaDetail.captchaChallenge;
                $scope.challenge = jsonCapImgData.imageCaptchaResponse.captchaDetail.captchaID;
                $scope.capRequired = true;
            } else {
               $scope.capRequired = false ;
            }
			$scope.capDisable= false;
			if($scope.capToggleClicked) {
				$scope.capToggleClicked=false;
				jQuery(document.getElementById("recaptcha_reload_btn")).focus();
			}
        }).error(function(data, status, headers, config) {
			 $scope.capDisable  = false;
			 $scope.capRequired = false;
        });
    }


    audioCaptchaJson = {
        "audioCaptchaRequest": {
            "captchaType": "audio"
        }
    };


   // function to call the Audio Captcha API
    $scope.callAudioCaptcha = function() {
		$scope.capDisable= true;
		$scope.rePlay=true;
        $scope.CaptchaType = "audio";
		$scope.tokenVal = document.getElementById("tokenID").value ;
				
        $http({
            method: 'POST',
            url: unlockApiUrl.audioCaptchaUrl,
            data: audioCaptchaJson
        }).success(function(jsonCapAudData) {

			$scope.capImg = "";
			if (jsonCapAudData.audioCaptchaResponse.serviceStatus.code == 0) {
                $scope.challenge = jsonCapAudData.audioCaptchaResponse.captchaDetail.captchaID;

                // GET CALL for AudioCaptcha

				if (testIE!=undefined && testIE){
           			//$scope.audio.src = "";
					//$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal; 
					
					var audioUrl = "http:" + "//" + window.location.hostname + unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal;
					window.location.assign(audioUrl);
					//$scope.audio.src = "https://tst31.stage.att.com/apis/deviceunlock/unlockCaptcha/sound" + "/" + $scope.challenge;
					//$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge+"?OWASP_CSRFTOKEN="+$scope.tokenVal;
            		//$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + '?random=' + new Date().getTime();
           			//document.all.sound.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge;
					
                } else { 
         			$scope.audio.src = "data:audio/wav;base64," + jsonCapAudData.audioCaptchaResponse.captchaDetail.captchaChallenge;
					$scope.audio.play();
         		}

                $scope.apiError = false;
                $scope.capRequired = true;
			}
			else {
                $scope.capRequired = false ;
            }
			$scope.capDisable= false;
			if($scope.capToggleClicked) {
				$scope.capToggleClicked=false;
				jQuery(document.getElementById("recaptcha_reload_btn")).focus();
			}
        }).error(function(data, status, headers, config) {
			$scope.capDisable  = false;
			$scope.capRequired = false ;
        }); 
    }

     $scope.rePlayFunc = function() {
         if (testIE!=undefined && testIE){
            //$scope.audio.src = $sce.trustAsResourceUrl(unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge);
			//$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal;
        	 var audioUrl = "http:" + "//" + window.location.hostname + unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal;
				window.location.assign(audioUrl);
         } else {
			$scope.audio.play();
         }
	 }


    // toggle between audio and image captcha on clik of button
    $scope.capToggle = function(capToggleVar) {
    	$scope.capToggleClicked=true;
		if (! $scope.capDisable)   //to disable toggling untill response for first call has not been received
        {
			$scope.recaptcha_response_field="";
			if (capToggleVar == "audio") {
				$scope.capToggleAudio = true;
				$scope.capToggleVisual = false;
				$scope.callAudioCaptcha();
			} else {
				if (testIE!=undefined && testIE){
					//$scope.audio.src = "";
				} else {
					$scope.audio.pause();
				}
				$scope.capToggleAudio = false;
				$scope.capToggleVisual = true;
				$scope.callImageCaptcha();
			}
		}	
	}
	

    // refresh audio or image captcha on click of refresh button based on the user's current choice 
    $scope.capRefresh = function() {
		if (! $scope.capDisable)  //to disable toggling untill response for first call has not been received
        {
			$scope.recaptcha_response_field="";
			if ($scope.capToggleAudio) {
				//if (navigator.appName == "Microsoft Internet Explorer") {
				if (testIE!=undefined && testIE){
					//$scope.audio.src = "";
				} else {
					$scope.audio.pause();
				}
				$scope.callAudioCaptcha();
			} else { 
				$scope.callImageCaptcha();
			}
		}
    }

    // fetch the captcha image onLoad of page
    $scope.callImageCaptcha();
	
   if (testIE!=undefined && testIE){
    	//$scope.audio = document.getElementById("bgSoundFrame");
    }else{
        $scope.audio = document.createElement('audio');
        $scope.audio.src = '';
    }


    // function to set required property of textfields dynamically on the basis of radiobutton selected
    $scope.req = function(fld) {

        if ($scope.radio == "current" && (fld == "miliyes" || fld == "milino")) {
            return true;
        }
        if (($scope.radio == "previous" || $scope.radio == "gophone" || $scope.radio == "nonatt") && (fld == "miliyes" || fld == "milino")) {
            return false;
        }

        if (($scope.radio == "current" || $scope.radio == "previous") && (fld == "wire" || fld == "accfname" || fld == "acclname" || fld == "ssn")) {
            return true;
        }
        if (($scope.radio == "current" || $scope.radio == "previous") && (fld == "fname" || fld == "lname")) {
            return false;
        }

        if ($scope.radio == "gophone" && (fld == "fname" || fld == "lname" || fld == "wire")) {
            return true;
        }
        if (($scope.radio == "gophone") && (fld == "accfname" || fld == "acclname" || fld == "ssn")) {
            return false;
        }

        if ($scope.radio == "nonatt" && (fld == "fname" || fld == "lname")) {
            return true;
        }
        if (($scope.radio == "nonatt") && (fld == "wire" || fld == "accfname" || fld == "acclname" || fld == "ssn")) {
            return false;
        }
        if (fld == "capFld") {
            if ($scope.capRequired)
                return true;
            else
                return false;
        }


        if ($scope.radio == null || $scope.radio == "") {
            return false;
        }
    }

    // function to stop user from submitting the form if the imei number or email field is invalid as per API response
    $scope.sysval = function(sysfld) {

        if (sysfld == "brandfield" && ($scope.model == "" || $scope.model == null) && !($scope.imeiErrCode == "NO")) {
            return true;
        } else if (sysfld == "brandfield" && !($scope.model == "" || $scope.model == null)) {
            return false;
        }

        if (sysfld == "emailfield" && $scope.emailErrMsg == "true") {
            return true;
        } else if (sysfld == "emailfield" && ($scope.emailErrMsg == "" || $scope.emailErrMsg == null)) {
            return false;
        }


    }

    // function to get the value of radiobutton selected 
    $scope.newValue = function(inputtype) {
        $scope.radio = inputtype;
        $scope.custtTypeErr = false;
        $scope.custtType = false;

        if (inputtype == "current") {
            $scope.currchecked = true;
            $scope.prevchecked = false;
            $scope.gochecked = false;
            $scope.nonattchecked = false;
        }

        if (inputtype == "previous") {
            $scope.prevchecked = true;
            $scope.currchecked = false;
            $scope.gochecked = false;
            $scope.nonattchecked = false;
        }

        if (inputtype == "gophone") {
            $scope.gochecked = true;
            $scope.currchecked = false;
            $scope.prevchecked = false;
            $scope.nonattchecked = false;
        }

        if (inputtype == "nonatt") {
            $scope.nonattchecked = true;
            $scope.currchecked = false;
            $scope.prevchecked = false;
            $scope.gochecked = false;
        }

    }


    $scope.newMiliValue = function(miliType) {
        $scope.miliErr = false;
        $scope.miliNull = false;

        if (miliType == "yes") {
            $scope.miliYesChecked = true;
            $scope.miliNoChecked = false;
        }

        if (miliType == "no") {
            $scope.miliNoChecked = true;
            $scope.miliYesChecked = false;
        }

    }


    $scope.fieldFocus = function(val, fld) {

		var wirelessPlacehold=jQuery("#wirelessNo").attr("placehold");
    	var imeiNumPlacehold=jQuery("#IMEI_Number").attr("placehold");
    	var ahFirstNamePlacehold=jQuery("#AHFirstName").attr("placehold");
    	var ahLastNamePlacehold=jQuery("#AHLastName").attr("placehold");
    	var text1Placehold=jQuery("#Text1").attr("placehold");
    	var text2Placehold=jQuery("#Text2").attr("placehold");
    	var ssnPlacehold=jQuery("#SSN").attr("placehold");
    	var attPasscodePlacehold=jQuery("#ATT_Account_Passcode").attr("placehold");
    	var emailAddressPlacehold=jQuery("#Email_PAddress").attr("placehold");
		var capResponsePlacehold=jQuery("#recaptcha_response_field").attr("placehold");
		
		
		 if (fld == 'radioCurrent') {
            $scope.radioCurrent = val;
         }
        if (fld == 'radioPrevious') {
            $scope.radioPrevious = val;
         }
        if (fld == 'radioGoPhone') {
            $scope.radioGoPhone = val;
         }
        if (fld == 'radioNonCustomer') {
            $scope.radioNonCustomer = val;
         }
        if (fld == 'radioYes') {
            $scope.radioYes = val;
         }
        if (fld == 'radioNo') {
            $scope.radioNo = val;
         }


        if (fld == 'capFocus') {
            $scope.capFocus = val;
            $scope.capInvalid = false;
            var inputCap = $scope.requestInfoForm.recaptcha_response_field.$viewValue;
            if (typeof(inputCap) != "undefined" && $scope.capRequired) {
                if (val == false && inputCap !=capResponsePlacehold) {
                    if (inputCap == "" || inputCap == null) {
                        $scope.capNull = true;
                        $scope.capErr = true;
                        $scope.capInvalid = false;
                    }
                }
            }
        }
		
		
		
        if (fld == 'wireFocus') {
            $scope.wireFocus = val;
            var inputwirelessNum = $scope.requestInfoForm.wirelessNum.$viewValue;
            if (typeof(inputwirelessNum) != "undefined") {
                if (val == false && inputwirelessNum !=wirelessPlacehold) {
					
					if(inputwirelessNum.charAt(0)=='0' || inputwirelessNum.charAt(0)=='1'){
					// in case the first character is either 0 or 1
                        $scope.wireErr = true;
                        $scope.wireNull = false;
                        $scope.wireSize = true;
                    }
					
                    if (inputwirelessNum.length > 0 && inputwirelessNum.length < 10) {
                        // in case wireless Number is less than 10 digits
                        $scope.wireErr = true;
                        $scope.wireSize = true;
                        $scope.wireNull = false;


                    }

                    if (inputwirelessNum.length == 0) {
                        // in case wireless number length is zero
                        $scope.wireErr = true;
                        $scope.wireNull = true;
                        $scope.wireSize = false;

                    }
                    if ($scope.wireErr != true) {
                        // When page loads and No error message is active
                        $scope.wireErr = false;
                        $scope.wireNull = false;
                        $scope.wireSize = false;
                    }
                    if (/[^0-9]/.test(inputwirelessNum)) {
                        // in case it is not a numeric value
                        $scope.wireErr = true;
                        $scope.wireSize = true;
                        $scope.wireNull = false;

                    }
                }
            }

        }

        if (fld == 'imeiFocus') {

            $scope.imeiFocus = val;
            var inputImei = $scope.requestInfoForm.imeinumber.$viewValue;

            if (typeof(inputImei) != "undefined") {
                if (val == false && inputImei !=imeiNumPlacehold) {

                    if (inputImei.length > 0 && inputImei.length < 15) {
                        // in case imei is less than 15 digits
                        $scope.imeiErr = true;
                        $scope.imeiSsize = true;
                        $scope.imeiNull = false;


                    }

                    if (inputImei.length == 0) {
                        // in case imei length is zero
                        $scope.imeiErr = true;
                        $scope.imeiNull = true;
                        $scope.imeiSsize = false;

                    }
                    if ($scope.imeiErr != true) {
                        $scope.imeiErr = false;
                        $scope.imeiNull = false;
                        $scope.imeiSsize = false;
                    }
                    if (/[^0-9]/.test(inputImei)) {
                        // in case it is not a numeric value
                        $scope.imeiErr = true;
                        $scope.imeiSsize = true;
                        $scope.imeiNull = false;
					}
                }

            }

        }

        if (fld == 'accFnameFocus') {

            $scope.accFnameFocus = val;
			if (!val)
            {  jQuery("#AHFirstName").val($scope.requestInfoForm.accFirstName.$viewValue.replace(/[ ]{2,}/gi, " ").replace(/(\s*$)/gi, "")); }

            var inputaccFirstName = $scope.requestInfoForm.accFirstName.$viewValue;
            if (typeof(inputaccFirstName) != "undefined") {
                if (val == false && inputaccFirstName !=ahFirstNamePlacehold) {

                    if (inputaccFirstName.length > 0) {
                        // in case acc First name (current radio button)
                        $scope.accFNamecond = false;

                    }

                    if (inputaccFirstName.length == 0) {
                        // in case acc First name length is zero
                        $scope.accFNamecond = true;

                    }
                    if ($scope.accFNamecond != true) {
                        // When page loads and No error message is active
                        $scope.accFNamecond = false;
                    }
                    if (/[^-0-9A-Za-z\s]/.test(inputaccFirstName)) {
                        // in case it is not a valid acc First name
                        $scope.accFNamecond = true;

                    }
                }
            }

        }

        if (fld == 'accLnameFocus') {
            $scope.accLnameFocus = val;
			 if (!val)
            {  jQuery("#AHLastName").val($scope.requestInfoForm.accLastName.$viewValue.replace(/[ ]{2,}/gi, " ").replace(/(\s*$)/gi, "")); }

            var inputaccLastName = $scope.requestInfoForm.accLastName.$viewValue;

            if (typeof(inputaccLastName) != "undefined") {
                if (val == false && inputaccLastName !=ahLastNamePlacehold) {

                    if (inputaccLastName.length > 0) {
                        // in case acc Last name (current radio button)
                        $scope.accLNamecond = false;

                    }

                    if (inputaccLastName.length == 0) {
                        // in case acc Last name length is zero
                        $scope.accLNamecond = true;

                    }
                    if ($scope.accLNamecond != true) {
                        // When page loads and No error message is active
                        $scope.accLNamecond = false;
                    }
                    if (/[^-0-9A-Za-z\s]/.test(inputaccLastName)) {
                        // in case it is not a valid acc Last name
                        $scope.accLNamecond = true;

                    }
                }

            }

        }

        if (fld == 'fNameFocus') {
            $scope.fNameFocus = val;
			 if (!val)
            {  jQuery("#Text1").val($scope.requestInfoForm.firstName.$viewValue.replace(/[ ]{2,}/gi, " ").replace(/(\s*$)/gi, "")); }

            var inputfirstName = $scope.requestInfoForm.firstName.$viewValue;
            if (typeof(inputfirstName) != "undefined") {
                if (val == false && inputfirstName !=text1Placehold) {

                    if (inputfirstName.length > 0) {
                        // in case acc First name (Non ATT radio button)
                        $scope.fNamecond = false;

                    }

                    if (inputfirstName.length == 0) {
                        // in case acc First name length is zero (Non ATT radio button)
                        $scope.fNamecond = true;

                    }
                    if ($scope.fNamecond != true) {
                        // When page loads and No error message is active
                        $scope.fNamecond = false;
                    }
                    if (/[^-0-9A-Za-z\s]/.test(inputfirstName)) {
                        // in case it is not a valid acc First name(Non ATT radio button)
                        $scope.fNamecond = true;

                    }
                }
            }

        }

        if (fld == 'lNameFocus') {
            $scope.lNameFocus = val;
			 if (!val)
            {  jQuery("#Text2").val($scope.requestInfoForm.lastName.$viewValue.replace(/[ ]{2,}/gi, " ").replace(/(\s*$)/gi, "")); }

            var inputlastName = $scope.requestInfoForm.lastName.$viewValue;

            if (typeof(inputlastName) != "undefined") {
                if (val == false && inputlastName !=text2Placehold) {

                    if (inputlastName.length > 0) {
                        // in case acc Last name (Non ATT radio button)
                        $scope.lNamecond = false;

                    }

                    if (inputlastName.length == 0) {
                        // in case acc Last name length is zero (Non ATT radio button)
                        $scope.lNamecond = true;

                    }
                    if ($scope.lNamecond != true) {
                        // When page loads and No error message is active
                        $scope.lNamecond = false;
                    }
                    if (/[^-0-9A-Za-z\s]/.test(inputlastName)) {
                        // in case it is not a valid acc Last name (Non ATT radio button)
                        $scope.lNamecond = true;

                    }

                }
            }

        }

        if (fld == 'ssnFocus') {
            $scope.ssnFocus = val;

            var accSsn = $scope.requestInfoForm.SSNDig.$viewValue;

            if (typeof(accSsn) != "undefined") {
                if (val == false && accSsn !=ssnPlacehold) {

                    if (accSsn.length > 0 && accSsn.length < 4) {
                        // in case ssn Number is less than 4 digits
                        $scope.ssnErr = true;
                        $scope.ssnSize = true;
                        $scope.ssnNull = false;
                    }

                    if (accSsn.length == 0) {
                        // in case ssn length is zero
                        $scope.ssnErr = true;
                        $scope.ssnNull = true;
                        $scope.ssnSize = false;

                    }
                    if ($scope.ssnErr != true) {
                        // When page loads and No error message is active
                        $scope.ssnErr = false;
                        $scope.ssnNull = false;
                        $scope.ssnSize = false;

                    }
                    if (/[^0-9]/.test(accSsn)) {
                        // in case ssn is not a numeric value
                        $scope.ssnErr = true;
                        $scope.ssnSize = true;
                        $scope.ssnNull = false;
                    }

                }

            }

        }

        if (fld == 'pcodeFocus') {
            $scope.pcodeFocus = val;

        }

        if (fld == 'emailFocus') {
            $scope.emailFocus = val;

        }

		// Fix for IE8
		if (document.all && document.querySelector && !document.addEventListener) {
		   jQuery(".app-container").addClass("abc").removeClass("abc");
		}


    }

    //textbox validation


    //ng-keydown &  ng-keyup captcha field
    $scope.capValidate = function() {
        var inputCap = $scope.requestInfoForm.recaptcha_response_field.$viewValue;
        if (typeof(inputCap) != "undefined") {
            if (inputCap.length > 0 || !$scope.capRequired) {
                $scope.capNull = false;
                $scope.capErr = false;
            } else {
                $scope.capNull = true;
                $scope.capErr = true;
                $scope.capInvalid = false;
            }
        }
    }


    //ng-keydown wireless field

    //ng-keydown & ng-keyup wireless field
    $scope.wireValidate = function() {

        var inputwirelessNum = $scope.requestInfoForm.wirelessNum.$viewValue;

        if (typeof(inputwirelessNum) != "undefined") {
            if (inputwirelessNum.length > 0) {
                $scope.wireNull = false;
                $scope.wireErr = false;
                $scope.wireSize = false;
            } else {
                $scope.wireNull = true;
                $scope.wireErr = true;
                $scope.wireSize = false;

            }
        }

		// Fix for IE8
		if (document.all && document.querySelector && !document.addEventListener) {
		   jQuery(".app-container").addClass("abc").removeClass("abc");
		}



    }



    //////////////////////IMEI Key down and Keyup /////////////

    //ng-keydown & ng-keyup imei field
    $scope.imeiValidate = function() {

        var inputImei = $scope.requestInfoForm.imeinumber.$viewValue;

        if (typeof(inputImei) != "undefined") {
            if (inputImei.length > 0) {
                $scope.imeiNull = false;
                $scope.imeiErr = false;
                $scope.imeiSsize = false;
            } else {
                $scope.imeiNull = true;
                $scope.imeiErr = true;
                $scope.imeiSsize = false;
            }
        }

		// Fix for IE8
		if (document.all && document.querySelector && !document.addEventListener) {
		   jQuery(".app-container").addClass("abc").removeClass("abc");
		}


    }

    ////////////////////////////////////////////////////////////

    //ng-keydown & ng-keyup acc first Name field (current radio button)
    $scope.accFnameValidate = function() {
		if (( $scope.requestInfoForm.accFirstName.$viewValue != jQuery("#AHFirstName").attr("placehold") ) && ( $scope.requestInfoForm.accFirstName.$viewValue.length == 0))
	    {
            jQuery("#AHFirstName").val($scope.requestInfoForm.accFirstName.$viewValue.replace(/(^\s*)/,""));
        }
        var inputaccFirstName = $scope.requestInfoForm.accFirstName.$viewValue;

        if (typeof(inputaccFirstName) != "undefined") {
            if (inputaccFirstName.length > 0) {
                $scope.accFNamecond = false;

            } else {

                $scope.accFNamecond = true;
            }

        }




		// Fix for IE8
		if (document.all && document.querySelector && !document.addEventListener) {
		   jQuery(".app-container").addClass("abc").removeClass("abc");
		}


    }


    //ng-keydown & ng-keyup acc Last Name field (current radio button)
    $scope.accLnameValidate = function() {
		 if (( $scope.requestInfoForm.accLastName.$viewValue != jQuery("#AHLastName").attr("placehold") ) && ( $scope.requestInfoForm.accLastName.$viewValue.length == 0))
	    {
            jQuery("#AHLastName").val($scope.requestInfoForm.accLastName.$viewValue.replace(/(^\s*)/,""));
        }
        var inputaccLastName = $scope.requestInfoForm.accLastName.$viewValue;

        if (typeof(inputaccLastName) != "undefined") {
            if (inputaccLastName.length > 0) {
                $scope.accLNamecond = false;

            } else {
                $scope.accLNamecond = true;

            }

        }

		// Fix for IE8
		if (document.all && document.querySelector && !document.addEventListener) {
		   jQuery(".app-container").addClass("abc").removeClass("abc");
		}


    }


    //ng-keydown & ng-keyup first Name field (Non ATT radio button)
    $scope.fNameValidate = function() {
		 if (( $scope.requestInfoForm.firstName.$viewValue != jQuery("#Text1").attr("placehold") ) && ( $scope.requestInfoForm.firstName.$viewValue.length == 0))
	    {
            jQuery("#Text1").val($scope.requestInfoForm.firstName.$viewValue.replace(/(^\s*)/,""));
        }
        var inputfirstName = $scope.requestInfoForm.firstName.$viewValue;

        if (typeof(inputfirstName) != "undefined") {
            if (inputfirstName.length > 0) {
                $scope.fNamecond = false;

            } else {
                $scope.fNamecond = true;

            }

        }

		// Fix for IE8
		if (document.all && document.querySelector && !document.addEventListener) {
		   jQuery(".app-container").addClass("abc").removeClass("abc");
		}

    }


    //ng-keydown & ng-keyupLast Name field (Non ATT radio button)

    $scope.lNameValidate = function() {
		 if (( $scope.requestInfoForm.lastName.$viewValue != jQuery("#Text2").attr("placehold") ) && ( $scope.requestInfoForm.lastName.$viewValue.length == 0))
	    {
            jQuery("#Text2").val($scope.requestInfoForm.lastName.$viewValue.replace(/(^\s*)/,""));
        }
        var inputlastName = $scope.requestInfoForm.lastName.$viewValue;

        if (typeof(inputlastName) != "undefined") {
            if (inputlastName.length > 0) {
                $scope.lNamecond = false;

            } else {
                $scope.lNamecond = true;

            }

        }

 		// Fix for IE8
		if (document.all && document.querySelector && !document.addEventListener) {
		   jQuery(".app-container").addClass("abc").removeClass("abc");
		}

    }


    //ng-keydown & ng-keyup ssn field
    $scope.ssnValidate = function() {

        var accSsn = $scope.requestInfoForm.SSNDig.$viewValue;

        if (typeof(accSsn) != "undefined") {
            if (accSsn.length > 0) {
                $scope.ssnNull = false;
                $scope.ssnErr = false;
                $scope.ssnSize = false;

            } else {
                $scope.ssnNull = true;
                $scope.ssnErr = true;
                $scope.ssnSize = false;
            }

        }

		// Fix for IE8
		if (document.all && document.querySelector && !document.addEventListener) {
		   jQuery(".app-container").addClass("abc").removeClass("abc");
		}
    }


    //ng-keydown & ng-keyup email field
    $scope.emailValidate = function() {

        var inputemail = $scope.requestInfoForm.email.$viewValue;

        if (typeof(inputemail) != "undefined") {
            if (inputemail.length > 0) {
                $scope.emailNull = false;
                $scope.emailErr = false;
                $scope.emailPat = false;
                $scope.emailDomain = false;
            } else {
                $scope.emailNull = true;
                $scope.emailErr = true;
                $scope.emailPat = false;
                $scope.emailDomain = false;

            }
        }

		// Fix for IE8
		if (document.all && document.querySelector && !document.addEventListener) {
		   jQuery(".app-container").addClass("abc").removeClass("abc");
			
		}

    }


    //On Form Submit
    $scope.continueForm = function(isValid) {
		 
		 //  code to invalidate the form in case any fields - wireless no, first name , last name or SSN is empty
         if ($scope.requestInfoForm.cType.$viewValue != 'Non-Customer' )
		{
            if ($scope.requestInfoForm.wirelessNum.$viewValue == jQuery("#wirelessNo").attr("placehold")) 
            {
				 isValid = false;
				 
            }
        }

	      if ($scope.requestInfoForm.cType.$viewValue == 'Current' || $scope.requestInfoForm.cType.$viewValue == 'Previous')
        {
            if  (($scope.requestInfoForm.SSNDig.$viewValue  == jQuery("#SSN").attr("placehold")) || ($scope.requestInfoForm.accFirstName.$viewValue  == jQuery("#AHFirstName").attr("placehold")) || ($scope.requestInfoForm.accLastName.$viewValue  == jQuery("#AHLastName").attr("placehold")) )
            {	
				isValid = false;
				
            }
        }

		  if ($scope.requestInfoForm.cType.$viewValue == 'GoPhone' || $scope.requestInfoForm.cType.$viewValue == 'Non-Customer')
        {
            if  (($scope.requestInfoForm.firstName.$viewValue  == jQuery("#Text1").attr("placehold"))   || ($scope.requestInfoForm.lastName.$viewValue  == jQuery("#Text2").attr("placehold")) )
            {
				isValid = false;
				
            }
        }
		
		 if (!($scope.requestInfoForm.cType.$viewValue == "" || $scope.requestInfoForm.cType.$viewValue == null ))
        {
			if  (($scope.requestInfoForm.imeinumber.$viewValue  == jQuery("#IMEI_Number").attr("placehold")) ||  ($scope.requestInfoForm.email.$viewValue  == jQuery("#Email_PAddress").attr("placehold"))  )
            {
				isValid = false;
				
            }
        }
		if($scope.MakeModelIpad)
		{
			isValid = false;
		}
		var wireval = $scope.requestInfoForm.wirelessNum.$viewValue;
		if (wireval.charAt(0) == '0' || wireval.charAt(0) == '1') {
			isValid = false;
		}

            // actions if the form is valid on click of submit button
            if (isValid) {
            	try {
                    console.log("Language : " + GE5P.ge5p_localLanguage);
				} catch (e) {}
                var lang = "English";
                if(typeof(GE5P.ge5p_localLanguage) != "undefined") {
                	if(GE5P.ge5p_localLanguage=="en_US") {
                		lang = "English";
                	} else if(GE5P.ge5p_localLanguage=="es_US") {
                		lang = "Spanish";
                	}
                }
				else{
					lang = "English";	
				}
				
				openModal();
				var inputtype = $scope.requestInfoForm.cType.$viewValue;
                $scope.custtype = $scope.requestInfoForm.cType.$viewValue;
                var inputwirelessNum ;
                var inputssn ;
                var inputFirstName ;
                var inputLastName ;
                var inputemilitary ;
                var inputeMilitaryVal ;
                var inputpCode ;
                var inputBrand ;
                var inputModel ;

                $scope.commonError = false;

                if (inputtype != "Non-Customer") {
                    inputwirelessNum = $scope.requestInfoForm.wirelessNum.$viewValue;
                }

                var inputImei = $scope.requestInfoForm.imeinumber.$viewValue;

                if ($scope.model != null && $scope.model != "") {
					inputBrand = $scope.model;
                	inputModel = $scope.phnModel;
                }

                if (inputtype == "Current" || inputtype == "Previous") {
                    inputFirstName = $scope.requestInfoForm.accFirstName.$viewValue;
                    inputLastName = $scope.requestInfoForm.accLastName.$viewValue;
                    inputssn = $scope.requestInfoForm.SSNDig.$viewValue;
					
					// populate passcode field only when entered
                    inputpCode = $scope.aPCode;
                }

                if (inputtype == "GoPhone" || inputtype == "Non-Customer") {
                    inputFirstName = $scope.requestInfoForm.firstName.$viewValue;
                    inputLastName = $scope.requestInfoForm.lastName.$viewValue;
                }

                if (inputtype == "Current") {
                    inputemilitary = $scope.requestInfoForm.military_personal.$viewValue;
                     if (inputemilitary=="yes")
						inputeMilitaryVal="Y";
                     else{
                    	 inputeMilitaryVal="N"; 
                     }
 						
                }

                var inputemail = $scope.requestInfoForm.email.$viewValue;
                var browserId = navigator.userAgent;

                var capId = $scope.challenge;
                var capType = $scope.CaptchaType;
                var capResponse = $scope.requestInfoForm.recaptcha_response_field.$viewValue;
                
                var tcValue = false ;
				if (sessionStorage.getItem("agreeCheckedBox") == 'yes')
                { tcValue= true; }
				//if ($rootScope.agreeCheckValue)
				//{tcValue = true;}

				
                // alert('customer type :'+inputtype+'  wireless: '+inputwirelessNum+'  imei :  '+inputImei+'  brand: '+inputBrand+'  military : '+inputemilitary);

				if (inputtype == "Non-Customer") {
					initialJson = {
						"unlockOrderRequest" : {
							"language" : lang,
							"orderDetail" : {
								"customerType" : inputtype,
								"ctn" : inputwirelessNum,
								"imei" : inputImei,
								"make" : inputBrand,
								"model" : inputModel,
								"firstName" : inputFirstName,
								"lastName" : inputLastName,
								"emailAddress" : inputemail,
								"lastFourSSN" : inputssn,
								"accountPassCode" : inputpCode,
								"browserID" : browserId,
								"source" : "ATT",
								"tcAccepted" : tcValue
							},
							"captcha" : {
								"captchaType" : capType,
								"captchaId" : capId,
								"captchaResponse" : capResponse
							}
						}
					};
				} else {
					initialJson = {
						"unlockOrderRequest" : {
							"language" : lang,
							"orderDetail" : {
								"customerType" : inputtype,
								"ctn" : inputwirelessNum,
								"imei" : inputImei,
								"make" : inputBrand,
								"model" : inputModel,
								"firstName" : inputFirstName,
								"lastName" : inputLastName,
								"emailAddress" : inputemail,
								"lastFourSSN" : inputssn,
								"accountPassCode" : inputpCode,
								"activeMilitary" : inputeMilitaryVal,
								"browserID" : browserId,
								"source" : "ATT",
								"tcAccepted" : tcValue
							},
							"captcha" : {
								"captchaType" : capType,
								"captchaId" : capId,
								"captchaResponse" : capResponse
							}
						}
					};
				}


				
                //Calling webtrends function
                var wtActiveMilitaryFlag = "";
                var dcsuri = '/unlockrequest';
				var wtEvent = 'myATT_DeviceUnlock_Information_SUB';
                var wtStatusFlag = '1';
                var wtStatusCode = '0';

                if (inputemilitary == "no") {
                    wtActiveMilitaryFlag = "N";
                } else if (inputtype == "yes") {
                    wtActiveMilitaryFlag = "Y";
                }

				$scope.isDisabled = true;
                // sending all form data in form of json to API and getting response in return
                $http({
                        method: 'POST',
                        url: unlockApiUrl.unlockOrder,
                        data: initialJson
                    }).success(function(jsonDataz) {
						closeModal();
                        if (jsonDataz.unlockOrderResponse.serviceStatus.code == 0) {

                            //Setting session variable
                            sessionStorage.isvalidthankPage = "yes";
                            dcsuri = '/requestthank';
							wtEvent = 'myATT_DeviceUnlock_Information_SUB';
                            wtStatusFlag = '1';
                            wtStatusCode = '0';
                            $location.path('/requestthank');
                            $rootScope.UnlockReqNumber = jsonDataz.unlockOrderResponse.unlockOrderDetail.orderNumber;


                        } else if (jsonDataz.unlockOrderResponse.serviceStatus.code == 1) {

                            $scope.isDisabled = false;
                            $scope.capInvalidMsg = jsonDataz.unlockOrderResponse.unlockOrderDetail.errorDescription;
							wtEvent = 'myATT_DeviceUnlock_Error_SUB';
                            wtStatusFlag = '0';
                            wtStatusCode = jsonDataz.unlockOrderResponse.unlockOrderDetail.errorCode;
                            $scope.capInvalid = true;
                            $scope.capErr = true;

                            // Call Image Captcha again
                            $scope.callImageCaptcha();
							$scope.recaptcha_response_field="";
                            $scope.capToggleAudio = false;
                            $scope.capToggleVisual = true;
                            $scope.CaptchaType = "image";


                        } else {

                            $scope.isDisabled = false;
                            $scope.errorMsg = jsonDataz.unlockOrderResponse.unlockOrderDetail.errorDescription;
                            $scope.commonError = true;

                            $scope.alreadyUnlockError = false;
                            $scope.dictJsonError=false;
                            $scope.apiError = false;

                            wtEvent = 'myATT_DeviceUnlock_Error_SUB';
							wtStatusFlag = '0';
							wtStatusCode = jsonDataz.unlockOrderResponse.unlockOrderDetail.errorCode;
							
							$scope.callImageCaptcha();
							$scope.recaptcha_response_field="";
							$scope.capToggleAudio = false;
							$scope.capToggleVisual = true;
							$scope.CaptchaType = "image";
                        }
                        //action event ---For Web Trends **
                         dcsMultiTrack('DCS.dcssip', 'www.att.com', 'DCS.dcsref', window.location.href, 'DCS.dcsuri', dcsuri, 'DCS.dcsua', navigator.userAgent, 'browserid', navigator.userAgent, 'DCSext.wtPN', 'Device Unlock Portal Information Pg', 'DCSext.wtEvent', wtEvent, 'DCSext.wtSuccessFlag', wtStatusFlag, 'DCSext.wtStatusCode', wtStatusCode, 'DCSext.wtNoHit', '1', 'DCSext.wtSelectedCustType', inputtype, 'DCSext.wtCTN', inputwirelessNum, 'DCSext.wtIMEI', inputImei, 'DCSext.wtDeviceMake', inputBrand, 'DCSext.wtDeviceModel', $scope.phnModel, 'DCSext.wtActiveMilitaryFlag', wtActiveMilitaryFlag);


                    })
                    .error(function(jsonDataz) {
						closeModal();
                        if ($scope.sysErrMsgVal){
						$scope.dictJsonError=false;
                        $scope.apiError = true;
                    }
                    else{
                        $scope.dictJsonError=true;
						$scope.apiError = false;
                    }
                        $scope.isDisabled = false;
                        $scope.commonError = false;
                        $scope.alreadyUnlockError = false;
						$scope.callImageCaptcha();
						$scope.recaptcha_response_field="";
                        $scope.capToggleAudio = false;
                        $scope.capToggleVisual = true;
                        $scope.CaptchaType = "image";

                    });
            } //if ends
            else {
                // client side validation failure
				
                var type = $scope.requestInfoForm.cType.$viewValue;
                var inputImei = $scope.requestInfoForm.imeinumber.$viewValue;
                var accSsn = $scope.requestInfoForm.SSNDig.$viewValue;
                var inputemail = $scope.requestInfoForm.email.$viewValue;
                var inputaccFirstName = $scope.requestInfoForm.accFirstName.$viewValue;
                var inputaccLastName = $scope.requestInfoForm.accLastName.$viewValue;
                var inputfirstName = $scope.requestInfoForm.firstName.$viewValue;
                var inputlastName = $scope.requestInfoForm.lastName.$viewValue;
                var inputwirelessNum = $scope.requestInfoForm.wirelessNum.$viewValue;
                var miliselect = $scope.requestInfoForm.military_personal.$viewValue;
                var capResponse = $scope.requestInfoForm.recaptcha_response_field.$viewValue;

                var EMAIL_REGEXP = /^[a-zA-Z0-9_](\.?[a-zA-Z0-9_-])*@([0-9a-zA-Z][-\w]*\.)+[a-zA-Z]{2,9}$/

                var wirelessPlacehold=jQuery("#wirelessNo").attr("placehold");
				var imeiNumPlacehold=jQuery("#IMEI_Number").attr("placehold");
				var ahFirstNamePlacehold=jQuery("#AHFirstName").attr("placehold");
				var ahLastNamePlacehold=jQuery("#AHLastName").attr("placehold");
				var text1Placehold=jQuery("#Text1").attr("placehold");
				var text2Placehold=jQuery("#Text2").attr("placehold");
				var ssnPlacehold=jQuery("#SSN").attr("placehold");
				var emailAddressPlacehold=jQuery("#Email_PAddress").attr("placehold");
				var capResponsePlacehold=jQuery("#recaptcha_response_field").attr("placehold");

                $scope.custtType = false;
                $scope.wireNull = false;
                $scope.wireSize = false;
                $scope.imeiNull = false;
                $scope.imeiSsize = false;
                $scope.emailNull = false;
                $scope.emailPat = false;
                $scope.emailDomain = false;
                $scope.accFNamecond = false;
                $scope.accLNamecond = false;
                $scope.fNamecond = false;
                $scope.lNamecond = false;
                $scope.miliNull = false;
                $scope.ssnNull = false;
                $scope.ssnSize = false;

                $scope.custtTypeErr = false;
                $scope.wireErr = false;
                $scope.imeiErr = false;
                $scope.emailErr = false;
                $scope.miliErr = false;
                $scope.ssnErr = false;

                if (!(($scope.model == "" || $scope.model == null) && !($scope.imeiErrCode == "NO"))) {
                    $scope.commonError = false;
                    $scope.apiError = false; 
					$scope.dictJsonError=false;
                }


                //Customer Type
                if (type == "" || type == null) {
                    $scope.custtType = true;
                    $scope.custtTypeErr = true;
                }



                if (!(type == "" || type == null)) {
                    //IMEI Number
                    if (inputImei == "" || inputImei == null || inputImei == imeiNumPlacehold) {
                        $scope.imeiNull = true;
                        $scope.imeiErr = true;
                    } else {
                        if (inputImei.length < 15) {
                            $scope.imeiSsize = true;
                            $scope.imeiErr = true;
                        }
                        if (($scope.model == "" || $scope.model == null) && !($scope.imeiErrCode == "NO")) {
                            $scope.imeiErr = true;
                        }
                        if (/[^0-9]/.test(inputImei)) {
                            $scope.imeiSsize = true;
                            $scope.imeiErr = true;
                        }
                    }


                    //Email empty Validation
                    if (inputemail == "" || inputemail == null || inputemail == emailAddressPlacehold) {
                        $scope.emailNull = true;
                        $scope.emailErr = true;
                    } else {
                        if (!(EMAIL_REGEXP.test(inputemail))) {
                            $scope.emailPat = true;
                            $scope.emailErr = true;
                        }
                        if ($scope.emailErrMsg == "true") {
                            $scope.emailDomain = true;
                            $scope.emailErr = true;
                        }
                    }


                    //Captcha empty Validation
                    if ($scope.capRequired){
                    if (capResponse == "" || capResponse == null || capResponse==capResponsePlacehold) {
                        $scope.capNull = true;
                        $scope.capErr = true;
                    }
                }
                }



                if (type == "Current" || type == "Previous" || type == "GoPhone") {
                    //wireless number
                    if (inputwirelessNum == "" || inputwirelessNum == null || inputwirelessNum==wirelessPlacehold) {
                        $scope.wireNull = true;
                        $scope.wireErr = true;
                    } else if (inputwirelessNum.length < 10) {
                        $scope.wireSize = true;
                        $scope.wireErr = true;
                    } else if (/[^0-9]/.test(inputwirelessNum)) {
                        $scope.wireSize = true;
                        $scope.wireErr = true;
                    } else if (inputwirelessNum.charAt(0)=='0' || inputwirelessNum.charAt(0)=='1') {
                        $scope.wireSize = true;
                        $scope.wireErr = true;					
					}
                }


                if ((type == "Current") && (miliselect == "" || miliselect == null)) {
                    //military radiobutton
                    $scope.miliNull = true;
                    $scope.miliErr = true;
                }


                if (type == "Current" || type == "Previous") {
                    // AccFirstName 
                    if (inputaccFirstName == "" || inputaccFirstName == null || inputaccFirstName==ahFirstNamePlacehold) {
                        $scope.accFNamecond = true;
                    } else if (/[^-0-9A-Za-z\s]/.test(inputaccFirstName)) {
                        $scope.accFNamecond = true;
                    }


                    // AccLastName 
                    if (inputaccLastName == "" || inputaccLastName == null || inputaccLastName==ahLastNamePlacehold) {
                        $scope.accLNamecond = true;
                    } else if (/[^-0-9A-Za-z\s]/.test(inputaccLastName)) {
                        $scope.accLNamecond = true;
                    }



                    // SSN Number
                    if (accSsn == "" || accSsn == null || accSsn==ssnPlacehold) {
                        $scope.ssnNull = true;
                        $scope.ssnErr = true;
                    } else if (accSsn.length < 4) {
                        $scope.ssnSize = true;
                        $scope.ssnErr = true;
                    } else if (/[^0-9]/.test(accSsn)) {
                        $scope.ssnSize = true;
                        $scope.ssnErr = true;
                    }


                }

                if (type == "GoPhone" || type == "Non-Customer") {

                    // FirstName 
                    if (inputfirstName == "" || inputfirstName == null || inputfirstName==text1Placehold) {
                        $scope.fNamecond = true;
                    } else if (/[^-0-9A-Za-z\s]/.test(inputfirstName)) {
                        $scope.fNamecond = true;
                    }

                    // LastName 
                    if (inputlastName == "" || inputlastName == null || inputlastName==text2Placehold) {
                        $scope.lNamecond = true;
                    } else if (/[^-0-9A-Za-z\s]/.test(inputlastName)) {
                        $scope.lNamecond = true;
                    }
                }
            }


            // Fix for IE8
			if (document.all && document.querySelector && !document.addEventListener) {
               jQuery(".app-container").addClass("abc").removeClass("abc");
                
			}


        } // continueForm ends




    // function for imei validations and API call at tab out of IMEi field
    $scope.imeiSize = function() {
			//FIX For IE8
			if (document.all && document.querySelector && !document.addEventListener) {
               jQuery(".app-container").addClass("abc").removeClass("abc");
            }
			
            $scope.apiError = false;

            $scope.imeiFocus = false;
            $scope.commonError = false;
        	var imeiNumPlacehold=jQuery("#IMEI_Number").attr("placehold");
            var inputImeiSize = $scope.requestInfoForm.imeinumber.$viewValue;
            var msg = '';
            var valid = 'true';
            var getJsonData = '';
            var make = '';
            $scope.model = "";
            $scope.phnModel = "";
            $scope.imeiNull = false;
            $scope.imeiSsize = false;
            $scope.imeiErr = false;
            $scope.isDisabled = false;
			$scope.MakeModelIpad=false;
            $scope.alreadyUnlockError = false;
			
			if (inputImeiSize == "" || inputImeiSize == null || inputImeiSize==imeiNumPlacehold) {
                $scope.imeiNull = true;
                $scope.imeiErr = true;
                valid = 'false';
            } else if (inputImeiSize.length < 15) {
                $scope.imeiSsize = true;
                $scope.imeiErr = true;
                valid = 'false';
            } else if (/[^0-9]/.test(inputImeiSize)) {
                $scope.imeiSsize = true;
                $scope.imeiErr = true;
                valid = 'false';
            }

            if (valid == 'true') {
                imeiJson = {
                    "imeiLookupRequest": {
                        "imei": inputImeiSize
                    }
                };

                $http({
                    method: 'POST',
                    url: unlockApiUrl.imei,
                    data: imeiJson
                }).success(function(jsonDataImei) {
					
                    if (jsonDataImei.imeiSearchResponse.serviceStatus.code == 0) {
                        $scope.model = jsonDataImei.imeiSearchResponse.imeiDetail.make;
                        $scope.phnModel = jsonDataImei.imeiSearchResponse.imeiDetail.model;
                        $scope.brand = $scope.model + '/' + $scope.phnModel;
						
                        if (($scope.model.toUpperCase() == 'IPHONE' && $scope.phnModel.toUpperCase() == 'IPAD') || ($scope.model.toUpperCase() == 'APPLE' && ($scope.phnModel.toUpperCase().indexOf('IPAD') > -1))) {
                            msg = $scope.alreadyUnlockMsg;
							$scope.alreadyUnlockError = true;
							$scope.MakeModelIpad=true;
                            $scope.commonError = false;
                            $scope.apiError = false;

                            $scope.errorMsg = msg;
                            $scope.imeiErr = true;
                            $scope.isDisabled = true;
                        }
						
                    } else if (jsonDataImei.imeiSearchResponse.serviceStatus.code == 1) {
                        msg = jsonDataImei.imeiSearchResponse.imeiDetail.errorDescription;
						
						$scope.brand = '';
						
                        $scope.commonError = true;

                        $scope.apiError = false;
                        $scope.alreadyUnlockError = false;

                        $scope.errorMsg = msg;
                        $scope.imeiErr = true;
                        $scope.isDisabled = true;
                    } else {

                        $scope.imeiErrCode = "NO";

                    }

                }).error(function(data, status, headers, config) {
                    $scope.imeiErr = false;

                    $scope.imeiErrCode = "NO";
                   /* if ($scope.sysErrMsgVal){
						$scope.dictJsonError=false;
                        $scope.apiError = true;
                    }
                    else
                    {
                        $scope.dictJsonError=true;
						$scope.apiError = false;
                    }

                    $scope.alreadyUnlockError = false;
                    $scope.commonError = false;*/
                });
            } else {
                $scope.brand = '';
            }
        } // imeiSize ends here




    // function for email validations and API call at tab out of email field
    $scope.emailValid = function() {
            //FIX For IE8
			if (document.all && document.querySelector && !document.addEventListener) {
               jQuery(".app-container").addClass("abc").removeClass("abc");
            }
			
			$scope.emailFocus = false;
            $scope.apiError = false;
			var emailAddressPlacehold=jQuery("#Email_PAddress").attr("placehold");
            var inputemail = $scope.requestInfoForm.email.$viewValue;
            var valid = "true";
            var erroremailmsg = '';
            var j = 0;
            var z = 0;
            var EMAIL_REGEXP = /^[a-zA-Z0-9_](\.?[a-zA-Z0-9_-])*@([0-9a-zA-Z][-\w]*\.)+[a-zA-Z]{2,9}$/

            $scope.commonErrorEmail = false;
            $scope.errorMsgs = '';
            $scope.emailNull = false;
            $scope.emailPat = false;
            $scope.emailDomain = false;
            $scope.emailErrMsg = "";
            $scope.emailErr = false;

            if (inputemail == "" || inputemail == null || inputemail==emailAddressPlacehold) {
                valid = "false";
                $scope.emailNull = true;
                $scope.emailErr = true;
            } else if (!(EMAIL_REGEXP.test(inputemail))) {
                valid = "false";
                $scope.emailPat = true;
                $scope.emailErr = true;
            }


            if (valid == "true") {
                var domain = inputemail.slice((inputemail.indexOf('@')) + 1, inputemail.lastIndexOf('.'));

                emailJson = {
                    "unlockValidateEmailRequest": {
                        "domain": domain
                    }
                };

                $http({
                    method: 'POST',
                    url: unlockApiUrl.emailValidation,
                    data: emailJson
                }).success(function(jsonDataEmail) {

                    if (jsonDataEmail.unlockValidateEmailResponse.serviceStatus.code == 1) {
                        $scope.emailErrMsg = "true";
                        $scope.emailDomain = true;
                        $scope.emailErr = true;
                    }
                }).error(function(jsonDataEmail) {
                    $scope.emailErr = false;
					if ($scope.sysErrMsgVal){
						$scope.dictJsonError=false;
                        $scope.apiError = true;
                    }
                    else
                    {
                        $scope.dictJsonError=true;
						$scope.apiError = false;
                    }
                    $scope.commonError = false;
                    $scope.alreadyUnlockError = false;
                });
            }
        } //emailValid ends here

}).directive('placehold', function() {
  return {
    restrict: 'A',
    require: 'ngModel',


    link: function(scope, element, attr, ctrl) {      
      
      var value;
      
      var placehold = function () {
          element.val(attr.placehold)
      };
      var unplacehold = function () {
          element.val('');
      };
      
      scope.$watch(attr.ngModel, function (val) {
        value = val || '';
      });

      element.bind('focus', function () {
         // if(value == '') unplacehold();


      });
      
      element.bind('blur', function () {
         if (element.val() == '') placehold();
      });
      
      ctrl.$formatters.unshift(function (val) {

        if (!val) {
          placehold();
          value = '';
          return attr.placehold;
        }
        return val;
      });
    }
  };
});