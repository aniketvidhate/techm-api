var emailApp = angular.module('emailApp', ['ngRoute', 'ngSanitize']);


emailApp.config(function ($routeProvider, $locationProvider) {

    $routeProvider
    // route for the blank page of email confirmation
        .when('/', {
            templateUrl: unlockTemplateUrl.defaultEmail,
            controller: 'emailController'
        })
        //route for email thank you page
        .when('/emailverificationsuccess', {
            templateUrl: unlockTemplateUrl.emailThankYou,
            controller: 'emailSuccessController'
        })
        //route for link expired page
        .when('/linkexpired', {
            templateUrl: unlockTemplateUrl.emailLinkExpired,
            controller: 'emailLinkExpiredController'
        })
        //route for system error page
        .when('/systemerror', {
            templateUrl: unlockTemplateUrl.systemError,
            controller: 'emailSystemErrorController'
        })
        //route for system error page
        .otherwise({
            templateUrl: unlockTemplateUrl.systemError,
            controller: 'emailSystemErrorController'
        });
});



/**
 * @Author 		:- Reema Rao (rr512r) / Aniket Vidhate (av0041)
 * Date			:- 22-2-2016
 * File name 	:- emailController.js
 */

emailApp.controller('emailController', function ($scope, $rootScope, $sce, $http, $location,$window) {
	window.scrollTo(0,0);
    $scope.displaySysError = false;

    openModal();

    //searching  the requestId and transactionId from the URL
    var searchString = window.location.search.substring(1),
        i, value, parameters = searchString.split("&");
    for (i = 0; i < parameters.length; i++) {
        value = parameters[i].split("=");
        if (value[0] == 'requestId') {
            var reqId = value[1];
        } else if (value[0] == 'transactionId') {
            var tranId = value[1];
        }
        else if(value[0] == 'validationId'){
            var validId = value[1];
        }
        
    }

    $rootScope.statusOce = false;

    // redirect to portal entry if either reqId or tranId are null/empty
    //this if section removed for global nav issue

    //if reqId and validId then IRU Unlock block - S
     if((reqId != null && validId != null) && (reqId != "" && validId != "")){
        /*
        	IE 10 & IE 11 Patch for "#/" is not working for redirection & angular-js controller is not detected.
        	http://blogs.msdn.com/b/ieinternals/archive/2011/05/17/url-fragments-and-redirects-anchor-hash-missing.aspx
		*/
        //if((navigator.appVersion.indexOf("MSIE 10") !== -1) || (navigator.userAgent.indexOf("Trident") !== -1 && navigator.userAgent.indexOf("rv:11") !== -1)){

            //openModal();

            initialJson = {
                "unlockOCEVerifyEmailRequest": {
                    "requestId": reqId,
                    "validationId": validId
                }
            };

            
            //$http.get("/etc/demo/linkexpiredemail.json")
            $http({
                method: 'POST',
                url: unlockApiUrl.oceVerifyEmail,
                data: initialJson

            })
            .success(function (jsonResp) {
                
                //console.log("success response");
                //console.log("Response : ",jsonResp);

				$location.search('requestId',null);
                $location.search('validationId',null);

                // request is set to valid
                if (typeof (Storage) != "undefined") {
                    sessionStorage.setItem("validRequest", "true");
                }

                
                if(jsonResp.unlockOCEVerifyEmailResponse.validationErrors == undefined || jsonResp.unlockOCEVerifyEmailResponse.validationErrors == "" || jsonResp.unlockOCEVerifyEmailResponse.validationErrors == null){

                    //console.log("email_confirmed");
                    $rootScope.OrderNumber = jsonResp.unlockOCEVerifyEmailResponse.orderNumber;
                    $rootScope.statusOce = true;
                    //console.log("ordernumber : ",$rootScope.OrderNumber);
                    
                    $location.path('/emailverificationsuccess').replace();

                }
                else if(jsonResp.unlockOCEVerifyEmailResponse.validationErrors != undefined || jsonResp.unlockOCEVerifyEmailResponse.validationErrors != null){

                    if(jsonResp.unlockOCEVerifyEmailResponse.validationErrors.errorList.errorCode == "ULP_2006"){
                        
                        //console.log("ULP_2006 link expired");

                        $rootScope.nullDescription = true;

                        $location.path('/linkexpired').replace();

                    }
                    else{

                        //console.log("validation system error");

                        $location.path('/systemerror').replace();
                    }
                    
                }
                else{

                    //console.log("validation system error"); 
                    $location.path('/systemerror').replace();
                }
                
                 //closeModal();
            }).error(function(data){

				$location.search('requestId',null);
                $location.search('validationId',null);

                 closeModal();

                //console.log("error response");
                // request is set to valid
                if (typeof (Storage) != "undefined") {
                    sessionStorage.setItem("validRequest", "true");
                }

                $location.path('/systemerror').replace();

            });  

      /*  }
        else{

            $window.location.href = '/deviceunlock/request/#/email?reqId='+reqId+'&validId='+validId;
        }*/
        
    }
    //if reqId and validId then IRU Unlock block - E
    else {
        
        // reqId or transId is empty - bogus request
        // redirecting user to portal entry page
        window.location.href = "index.html";

    }


});


emailApp.controller('emailSuccessController', function ($scope, $http, $location) {
	window.scrollTo(0,0);
    // do nothing redirect to email success page
    $scope.displaySysError = false;
     $("#portalLinkEntry").removeClass("displayN").addClass("displayB");
    closeModal();

});


emailApp.controller('emailLinkExpiredController', function ($scope, $http, $location) {
	window.scrollTo(0,0);
    // do nothing redirect to email success page
    $scope.displaySysError = false;
	closeModal();
});


emailApp.controller('emailSystemErrorController', function ($scope, $http, $location) {
	window.scrollTo(0,0);
    // do nothing redirect to System Error Page
    $scope.displaySysError = true;
	closeModal();
});
