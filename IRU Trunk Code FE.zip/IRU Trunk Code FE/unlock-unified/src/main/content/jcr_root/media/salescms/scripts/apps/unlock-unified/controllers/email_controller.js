/**
 * @Author 		:- Reema Rao (rr512r) / Aniket Vidhate (av0041)
 * Date			:- 01-10-2015
 * File name 	:- email_controller.js
 */


unlockPortal.controller('emailController',['$scope','$rootScope','$http','$location','services','$window', function ($scope, $rootScope, $http, $location,services,$window) {

	window.scrollTo(0,0);

	//console.log("OCE request");

    $("#newOrderSeparator, #newOrder, #headercru").removeClass("divShow").addClass("divHide");
    
    if((window.location.href.indexOf('?') == -1) || (window.location.href.indexOf('&') == -1)){
        //console.log("invalid url");
		$location.path('/error');
    }

	var searchStr = window.location.href.split("?");
    //console.log("searchStr : "+searchStr[1]);

    var parameter = searchStr[1].split("&");
    //console.log("parameter : "+parameter);

    var otherId = [];

    for(var i=0; i < parameter.length; i++){
		var value = parameter[i].split("=");
        if(value[0] == 'reqId'){
			var reqId = value[1];
            otherId[i] = value[i];
        }
        else if(value[0] == 'validId'){
			var validId = value[1];
            otherId[i] = value[i];
        }
        else{
			otherId[i] = value[i];

        }
    }
    //console.log("reqid : "+reqId+" validId : "+validId);

    if ((reqId != null && validId != null) && (reqId != "" && validId != "")) {

        openLoader();

        initialJson = {
            "unlockOCEVerifyEmailRequest": {
                "requestId": reqId,
                "validationId": validId
            }
        };

		//console.log("url : ",url.OCEverifyEmail);

        //$http.get("/etc/demo/emailLinkExpired.json")
		services.postService(url.OCEverifyEmail,initialJson)
        .success(function(jsonResp){

            $location.search('reqId',null);
            $location.search('validId',null);
            if(otherId != undefined){
                for(var i=0;i<otherId.length;i++){
            		$location.search(otherId[i],null);
                }
            }
            //console.log("success response");
            //console.log("Response : ",jsonResp);

            if(jsonResp.unlockOCEVerifyEmailResponse.validationErrors == undefined || jsonResp.unlockOCEVerifyEmailResponse.validationErrors == ""){

                    //console.log("email_confirmed");
                    $rootScope.OrderNumber = jsonResp.unlockOCEVerifyEmailResponse.orderNumber;
                    //console.log("ordernumber : ",$rootScope.OrderNumber);

                    $location.path('/emailconfirmationsuccess').replace(); 

            }
            else if(jsonResp.unlockOCEVerifyEmailResponse.validationErrors != undefined){

                if(jsonResp.unlockOCEVerifyEmailResponse.validationErrors.errorList.errorCode == "ULP_2006"){

					//console.log("ULP_2006 link expired");

                    $location.path('/emaillinkexpired').replace();
                }
                else{

                    //console.log("validation system error");
                    sessionStorage.setItem('errorPage','yes');

               		$location.path('/error').replace();
                }

            }

			closeLoader();

        }).error(function(data){

           	$location.search('reqId',null);
           	$location.search('validId',null);
            if(otherId != undefined){
                for(var i=0;i<otherId.length;i++){
            		$location.search(otherId[i],null);
                }
            }

            closeLoader();

            //console.log("error response");
            sessionStorage.setItem('errorPage','yes');

            $location.path('/error').replace();


        });


    } else {

        $location.search('reqId',null);
        $location.search('validId',null);
        if(otherId != undefined){
            for(var i=0;i<otherId.length;i++){
                $location.search(otherId[i],null);
            }
        }

        //console.log("redirecting...");
        sessionStorage.setItem('errorPage','yes');

        $location.path('/error').replace();

    }

}]);


unlockPortal.controller('emailSuccessController',['$scope','$rootScope','$http','$location','services','$window', function ($scope, $rootScope, $http, $location,services,$window) {

    //console.log("emailSuccessController controller");

     $("#newOrderSeparator").removeClass("divShow").addClass("divHide");

}]);

unlockPortal.controller('emailLinkExpiredController',['$scope','$rootScope','$http','$location','services','$window', function ($scope, $rootScope, $http, $location,services,$window) {

    //console.log("emailLinkExpiredController controller");

    $("#newOrderSeparator").removeClass("divShow").addClass("divHide");

    
}]);