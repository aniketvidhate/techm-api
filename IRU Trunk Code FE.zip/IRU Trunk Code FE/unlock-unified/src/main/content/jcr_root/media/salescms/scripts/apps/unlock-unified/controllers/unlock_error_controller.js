/**
 * @Author 		:- Aniket Vidhate (av0041)   
 * Date			:- 26-7-2015
 * File name 	:- unlock_error_controller.js
 */

//Unlock Error Controller - S
unlockPortal.controller('errorCtrl', ['$scope', '$rootScope', '$http', 'services', '$sce', '$window', '$location', function($scope, $rootScope, $http, services, $sce, $window, $location){

	//console.log("in error controller");
    
    //To smothen the User experience we want the loader till UI gets ready
    openLoader();

	$("#headercru").removeClass("divShow").addClass("divHide");

    //checking cookies while accesing unlock request page
    if ((sessionStorage.getItem("hasReadTerms") == 'yes' && sessionStorage.getItem("agreeCheckedBox") == 'yes')||(sessionStorage.getItem("errorPage") == 'yes')) {
        //user can access unlock request page
 		//To smothen the User experience we want the loader till UI gets ready
        closeLoader();
    } else {
        //redirecting user to portal entry page
        $window.location.href = '/deviceunlock/#/';

    }
    

    //$rootScope.$emit("logout");
    
   // $rootScope.$on("logout", function(){

	//Clearing out all rootscope variables -S
        if($rootScope.custType !== undefined){
            $rootScope.custType = undefined;
        }


		if($rootScope.attwrlsno_usr !== undefined){
            $rootScope.attwrlsno_usr = undefined;
        }


        if($rootScope.fname_usr !== undefined){
            $rootScope.fname_usr = undefined;
        }


        if($rootScope.lname_usr !== undefined){
            $rootScope.lname_usr = undefined;
        }
		
		if($rootScope.recaptcha_response_field !== undefined){
			$rootScope.recaptcha_response_field = undefined;
		}

		if($rootScope.imei_nonatt_usr !== undefined){
            $rootScope.imei_nonatt_usr = undefined;
        }


		if($rootScope.nonAttMake_usr !== undefined){
            $rootScope.nonAttMake_usr = undefined;
        }

		
		if($rootScope.nonAttModel_usr !== undefined){
            $rootScope.nonAttModel_usr = undefined;
        }


		if($rootScope.unlockStep1Resp !== undefined){
            $rootScope.unlockStep1Resp = undefined;
        }

		
		if($rootScope.unlockStep1NonATTResp !== undefined){
            $rootScope.unlockStep1NonATTResp = undefined;
        }


		if($rootScope.unlockStep1NonATTIMEIResp !== undefined){
            $rootScope.unlockStep1NonATTIMEIResp = undefined;
        }

		
        if($rootScope.emailAddress_usr !== undefined){
            $rootScope.emailAddress_usr = undefined;
        }


        if($rootScope.ssn_usr !== undefined){
            $rootScope.ssn_usr = undefined;
        }


        if($rootScope.attPass_usr !== undefined){
            $rootScope.attPass_usr = undefined;
        }


        if($rootScope.militaryPersnl !== undefined){
            $rootScope.militaryPersnl = undefined;
        }


		if($rootScope.billingName_usr !== undefined){
            $rootScope.billingName_usr = undefined;
        }

		
		if($rootScope.billingNo_usr !== undefined){
            $rootScope.billingNo_usr = undefined;
        }

		
		if($rootScope.simno_usr !== undefined){
            $rootScope.simno_usr = undefined;
        }

		
		if($rootScope.unlockSecureDomainResp !== undefined){
            $rootScope.unlockSecureDomainResp = undefined;
        }


		if($rootScope.unlockStep2Resp !== undefined){
            $rootScope.unlockStep2Resp = undefined;
        }

		
        if($rootScope.imei_usr !== undefined){
            $rootScope.imei_usr = undefined;
        }


        if($rootScope.unlockStep3ATTIMEIResp !== undefined){
            $rootScope.unlockStep3ATTIMEIResp = undefined;
        }


		if($rootScope.unlockSubmitResp !== undefined){
            $rootScope.unlockSubmitResp = undefined;
        }

       
		if($rootScope.nonAttFname_usr !== undefined){
            $rootScope.nonAttFname_usr = undefined;
        }

		
		if($rootScope.nonAttLname_usr !== undefined){
            $rootScope.nonAttLname_usr = undefined;
        }

		
		if($rootScope.nonAttWirelessNo_usr !== undefined){
            $rootScope.nonAttWirelessNo_usr = undefined;
        }


		if($rootScope.nonAttEmailAddress_usr !== undefined){
            $rootScope.nonAttEmailAddress_usr = undefined;
        }

		
		if($rootScope.unlockSecureNonAttDomainResp !== undefined){
            $rootScope.unlockSecureNonAttDomainResp = undefined;
        }

        
		if($rootScope.unlockNonATTSubmitResp !== undefined){
            $rootScope.unlockNonATTSubmitResp = undefined;
        }


        //setting cookies for user acknowledgement
        if (typeof(Storage) != "undefined") {
            sessionStorage.setItem("hasReadTerms", "no");
            sessionStorage.setItem("agreeCheckedBox", "no");
            sessionStorage.setItem("errorPage","no");
        }

	//Clearing out all rootscope variables -E
    //});


}]);
//Unlock Error Controller - E





