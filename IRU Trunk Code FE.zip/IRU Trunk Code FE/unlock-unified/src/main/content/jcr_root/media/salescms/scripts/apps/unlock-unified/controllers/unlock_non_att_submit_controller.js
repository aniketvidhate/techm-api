/**
* @Author 		:- Aniket Vidhate (av0041)   
* Date			:- 12-7-2015
* File name 	:- unlock_non_att_submit_controller.js
*/

//Unlock Step 2 Non AT&T Controller - S
unlockPortal.controller('nonAttCtrl', ['$scope', '$rootScope', 'services','$sce', '$window', '$location', '$http', function($scope, $rootScope, services, $sce, $window, $location,$http){
    //console.log("in non att submit controller");
    
	//To smothen the User experience we want the loader till UI gets ready
    openLoader();

    $scope.isValidEmail = true;
    $scope.isVaild = false;

    $("#newOrderSeparator, #newOrder, #headercru").removeClass("divShow").addClass("divHide");
    
    //checking cookies while accesing unlock request page
    if (sessionStorage.getItem("hasReadTerms") == 'yes' && sessionStorage.getItem("agreeCheckedBox") == 'yes' 
    && $rootScope.unlockStep1NonATTResp !== undefined && $rootScope.unlockStep1NonATTResp.validationErrors === undefined) {
        //user can access unlock request page
        
        


        /*if($rootScope.isReadAndAgreeTermsAndCondition === undefined || $rootScope.isReadAndAgreeTermsAndCondition === false){
        console.log("Terms & condition has been not agreed trying to access nonatt submit");
        window.location = "#/unlock";
        window.scrollTo(0, 0);
        }else{*/
        
        $("#allRequired").removeClass("divShow").addClass("divHide");
        $("#someRequired").removeClass("divHide").addClass("divShow");
        
        
        if($rootScope.nonAttFname_usr != undefined){
            $scope.nonAttFname = $rootScope.nonAttFname_usr;
        }
        

        if($rootScope.nonAttLname_usr != undefined){
            $scope.nonAttLname = $rootScope.nonAttLname_usr;
        }
        
        
        if($rootScope.nonAttWirelessNo_usr != undefined){
            $scope.nonAttWirelessNo = $rootScope.nonAttWirelessNo_usr;
        }
        
        
        if($rootScope.nonAttEmailAddress_usr != undefined){
            $scope.nonAttEmailAddress = $rootScope.nonAttEmailAddress_usr;
            
            $scope.isValidEmail = IsEmail($scope.nonAttEmailAddress);
            //console.log("$scope.isValidEmail =>"+$scope.isValidEmail);
            
            if($scope.nonAttEmailAddress === undefined || $scope.nonAttEmailAddress === ""){
                validationNonAttEmailAddress(); 
            }else{
                $rootScope.nonAttEmailAddress_usr = $scope.nonAttEmailAddress;
                
                if($scope.isValidEmail === true){
                    $scope.isVaild = true;

                }else{
                    $scope.isVaild = false;
                }
            }
        }
        

        //On focus event -S
        $scope.onFocusNonAttFirstName = function(){
            $scope.nonAttFirstNameReqErr = false;
            
        };
        
        
        $scope.onFocusNonAttLastName = function(){
            $scope.nonAttLastNameReqErr = false;
            
        };
        
        
        $scope.onFocusNonAttWrlsNo = function(){
            $scope.nonAttWrlsNoReqErr = false;
            $scope.nonAttWrlsLengthWErr = false;
        };
        
        
        $scope.onFocusNonAttEmail = function(){
            $scope.isValidEmail = true; 
            $scope.secureDoaminErr = false;
            $scope.nonAttEmailReqErr = false
            $scope.nonAttBlackListEmail = false;

        };
        //On focus event -E
        
        
        //On Blur Events -S
        $scope.getNonAttFirstName = function(){
            //console.log("getNonAttFirstName  "+$scope.nonAttFname + "  "+$rootScope.nonAttFname_usr);
            
            validationNonAttFirstName();
            $rootScope.nonAttFname_usr = $scope.nonAttFname;
            isAllDataValid();
            
        };
        
        
        $scope.getNonAttLastName = function(){
            //console.log("getNonAttLastName  "+$scope.nonAttLname + "  "+$rootScope.nonAttLname_usr);
            
            validationNonAttLastName();
            $rootScope.nonAttLname_usr = $scope.nonAttLname;
            isAllDataValid();
            
        };
        
        
        $scope.getNonAttWrlsNo = function(){
            //console.log("getNonAttWrlsNo  "+$scope.nonAttWirelessNo + "  "+$rootScope.nonAttWirelessNo_usr);
            
            validationNonAttWrlsNo();
            $rootScope.nonAttWirelessNo_usr = $scope.nonAttWirelessNo;
            //isAllDataValid();
            
        };
        
        
        $scope.getNonAttEmailAddr = function(){
            //console.log("getNonAttEmailAddr  "+$scope.nonAttEmailAddress + "  "+$rootScope.nonAttEmailAddress_usr);
            
            
            if($scope.nonAttEmailAddress === undefined || $scope.nonAttEmailAddress === ""){
                validationNonAttEmailAddress(); 
            }else{
                //console.log("getNonAttEmailAddr else part");
                isAllDataValid();
                $rootScope.nonAttEmailAddress_usr = $scope.nonAttEmailAddress;
                
                $scope.isValidEmail = IsEmail($scope.nonAttEmailAddress);
                //console.log("$scope.isValidEmail =>"+$scope.isValidEmail);

                if($scope.isValidEmail === true){
                    $scope.isVaild = true;

                }else{
                    $scope.isVaild = false;
                }
            }
            
        };
        //On Blur Events -E
        
        
        //On keyUp events -S
        $scope.getNonAttFirstNameOnKeyEvent = function(keyEvent) {
            //console.log("getNonAttFirstNameOnKeyEvent function called");
            if($scope.nonAttFname !== undefined && $scope.nonAttFname != ""){
                if(testWhite($scope.nonAttFname) === true){
                    $scope.nonAttFname = "";
                    $scope.nonAttFirstNameReqErr = true;
                }
                else{
                    if(!isSpecialCharInString($scope.nonAttFname)){
                        isAllDataValid();
                    }else{
                        $scope.nonAttFname = "";
                    }
                }
            }
            else{
                isAllDataValid();
            }
        }
        
        
        $scope.getNonAttLastNameOnKeyEvent = function(keyEvent) {
            //console.log("getNonAttLastNameOnKeyEvent function called");
            if($scope.nonAttLname !== undefined && $scope.nonAttLname != ""){
                if(testWhite($scope.nonAttLname) === true){
                    $scope.nonAttLname = "";
                    $scope.nonAttLastNameReqErr = true;
                }
                else{
                    if(!isSpecialCharInString($scope.nonAttLname)){
                        isAllDataValid();
                    }else{
                        $scope.nonAttLname = "";
                    }
                }
            }
            else{
                isAllDataValid();
            }
        }


        $scope.getNonAttWrlsNoKeyupEvent = function(keyEvent){

            if($scope.nonAttWirelessNo !== undefined){
                    if($scope.nonAttWirelessNo.charAt(0) === '0' || $scope.nonAttWirelessNo.charAt(0) === '1')
                        $scope.nonAttWirelessNo = $scope.nonAttWirelessNo.slice(1);
               }
        }
        
        
        $scope.getNonAttEmailAddrOnKeyEvent = function(keyEvent) {
            //console.log("getNonAttEmailAddrOnKeyEvent function called");
            isAllDataValid();
        }
        //On keyUp events -E
        
        
        //check validation for first name
        function validationNonAttFirstName(){
            if($scope.nonAttFname == undefined || $scope.nonAttFname == ""){
                $scope.nonAttFirstNameReqErr = true;
                $scope.isVaild = false;
            }
        }
        
        
        //check validation for last name
        function validationNonAttLastName(){
            if($scope.nonAttLname == undefined || $scope.nonAttLname == ""){
                $scope.nonAttLastNameReqErr = true;
                $scope.isVaild = false;
            }
        }
        
        
        //check validation for att wireless no
        function validationNonAttWrlsNo(){
            if($scope.nonAttWirelessNo !== undefined && $scope.nonAttWirelessNo !== "" && $scope.nonAttWirelessNo.length < 10){
                $scope.nonAttWrlsLengthWErr = true;
                $scope.isVaild = false;
                
            }else{
                if($scope.nonAttWirelessNo !== undefined && $scope.nonAttWirelessNo !== "" && ($scope.nonAttWirelessNo.substring(0,3) === "800" || $scope.nonAttWirelessNo.substring(0,3) === "888")){
                    $scope.nonAttWrlsLengthWErr = true;
                    $scope.isVaild = false;
                }else{
                    isAllDataValid();
                }
            }
            
        }
        
        
        function validationNonAttEmailAddress(){
            if($scope.nonAttEmailAddress == undefined || $scope.nonAttEmailAddress == ""){
                $scope.nonAttEmailReqErr = true; 
                $scope.isVaild = false;
            }
            
        }
        
        
        //Enable Submit button if required feild data is entered
        function isAllDataValid(){
            //console.log("isAllDataValid ==> ");
            
            if($scope.nonAttFname !== undefined && $scope.nonAttLname !== undefined 
               && $scope.nonAttEmailAddress !== undefined){
                if($scope.nonAttFname !== "" && $scope.nonAttLname !== "" ){ 
                    if($scope.nonAttEmailAddress !== "" && IsEmail($scope.nonAttEmailAddress)){
                        $scope.isVaild = true;
                    }else{
                        $scope.isVaild = false;
                    }
                }else{
                    $scope.isVaild = false;
                }
            }else{
                $scope.isVaild = false;
            }
            
            //console.log("end isAllDataValid ==> "+$scope.isVaild);
        }
        
        
        //Back button logic - S
        $scope.nonAttUnlockBack = function()
        {
            //console.log("non att back button called => ");
            window.location = "#/unlockstep1/";
        }
        //Back button logic - E

        
        //Submit button logic -S
        $scope.nonAttunlockSubmit = function()
        {
            /*
                Note: after clicking on submit button it will first verify the secure domain check and if domain is secure then it will submit the request
                otherwise it will show secure domain error message & it will prevent the non att order submision
            */

            openLoader();

            //Secure domain check
            var domain = $scope.nonAttEmailAddress.slice(($scope.nonAttEmailAddress.indexOf('@')) + 1, $scope.nonAttEmailAddress.lastIndexOf('.'));
            
            emailJson = {
                "unlockValidateEmailRequest": {
                    "domain": domain
                }
            };
            
            //Post call to validate email domain is secure or else to show error
			services.postService(url.emailSecureDomain, emailJson)
            .success(function(jsonrRespData) {
                
                $scope.commonError = false;
                $rootScope.unlockSecureNonAttDomainResp = jsonrRespData;
                
                if (jsonrRespData.unlockValidateEmailResponse.serviceStatus.code == 0) {//Enter domain is Secured

                    //Non AT&T order submission
                    unlockOrderNonATTSumbitRequest = {
                        
                        "orderFlowRequestDO": {
                            
                            "attCustomer" : $rootScope.custType,
                            "currentFlow" : "ORDER_SUBMISSION_FLOW",
                            "ctn" 		  : $scope.nonAttWirelessNo,
                            "firstName"   : $scope.nonAttFname,
                            "lastName" 	  : $scope.nonAttLname,
                            "email"       : $scope.nonAttEmailAddress,
							"captcha"	  : {
                                                "captchaType":$rootScope.CaptchaType,
                                                "captchaId":$rootScope.challenge,
                                                "captchaResponse":$rootScope.recaptcha_response_field,
                                                "captchaRefId":$rootScope.captchaRefId
                                            },
                            "imei"		  : $rootScope.imei_nonatt_usr,
                            "imeiRefId"	  : $rootScope.imeiRefId,
                            "make"        : $rootScope.nonAttMake_usr,
                            "model"       : $rootScope.nonAttModel_usr,
                            "lastFourSSN" : "",
                            "passCode"    : "",
                            "military"    : false,
                            //"ipAddress"	  : myip,
                            "langId"	  :	GE5P.ge5p_localLanguage === undefined || GE5P.ge5p_localLanguage.toLowerCase() === "en-us" ? "en_US" : GE5P.ge5p_localLanguage,
                            "browserId"	  : browserId
                            
                        }
                        
                    }
                    
                    
                    //Post call to validate screen 3 data and submitting the request
                    //$http.get('/etc/demo/ULS_8047_error_status.json')
                    services.postService(url.unlockStepPostURL, unlockOrderNonATTSumbitRequest)
                    .success(function(jsonrRespData) {
                        
                        $rootScope.unlockSubmitResp = jsonrRespData;
                        $scope.errorsArray = [];
                        $scope.serverErrorsArray = [];
                        
                        if(jsonrRespData.orderFlowResponseDO.validationErrors !== undefined){
                            
                            var validationErrors = jsonrRespData.orderFlowResponseDO.validationErrors.errorList;
                            
                            $scope.commonErrorMsgs = "";
                            
                            //error ULS_8018 change
                            if(jsonrRespData.orderFlowResponseDO.requestNo !== undefined){
                                $rootScope.requestNumber = jsonrRespData.orderFlowResponseDO.requestNo;
                            }
                            else{
                                $rootScope.requestNumber = "";
                            }
                            
                            //console.log("****==== "+$scope.errorsArray.length);
                            $.each( validationErrors, function( key, value ) {
                                //console.log("key "+key+" value "+value);
                                
                                if(value.errorCode === undefined){
                                    if(key ==="errorCode"){
                                        if( value === 'SLE_INVALID_INPUT' || value === 'SLE_System Exception' || value === 'SLE_BACKEND_APP' || value === 'ULS_3001'){
                                            //Do nothing				
                                        }
                                        else{
                                            $scope.commonError = true;

                                            if(value == "ULS_8034"){
                                                $scope.nonAttBlackListEmail = true;
                                                $scope.errorsArray.push(value);
                                            }else if(value.substring(0, 4) === "ULF_"){
                                                $scope.serverErrorsArray.push(validationErrors.errorDescription +" (errorCode."+value+")");
                                            }else{
												$scope.errorsArray.push(value);
                                            }
                                        }
                                    }
                                }else{
                                    $scope.commonError = true;
                                    //console.log("errorCode ==>"+value.errorCode);
                                    //console.log("errorCode ==>"+value.errorDescription);
                                    if((value.errorCode).substring(0, 4) === "ULF_"){
                                        $scope.serverErrorsArray.push(value.errorDescription +" (errorCode."+value.errorCode+")");
                                    }else{
                                        $scope.errorsArray.push(value.errorCode);
                                    }
                                    
                                }
                            });
                            
                            closeLoader();
                            
                            if($scope.errorsArray.length > 0){
                                window.scrollTo(0, 0);
                                $scope.isVaild = false;
                            }else{
                                $location.path('error').replace();
                            }
                            
                        }else{
							//Fix for Non-att Thank you page displayed as CRU
                            $rootScope.unlockStep1Resp = undefined;
                            closeLoader();
                            //console.log("orderId in nonatt : ",$rootScope.unlockSubmitResp.orderFlowResponseDO.orderId);
                            $location.path('thankyou').replace();
                        }
                        
                    }).error(function(data, status, headers, config) {
                        closeLoader();
                        $scope.commonError = true;
                        $scope.isVaild = false;
                        $scope.errorsArray = [];
                        $scope.errorsArray.push("ULP_0000");
                        window.scrollTo(0, 0);
                    });
                    
                    
                }else if (jsonrRespData.unlockValidateEmailResponse.serviceStatus.code == 1 
                          || jsonrRespData.unlockValidateEmailResponse.errordetail !== undefined) {
                    
                    var validationErrors = jsonrRespData.unlockValidateEmailResponse.errordetail;
                    
                    $scope.secureDoaminErr = true;
                    $scope.isVaild = false;
                    closeLoader();
                    
                }
                
                //isAllDataValid();
                
            }).error(function(data, status, headers, config) {
                closeLoader();
                $scope.commonError = true;
                $scope.isVaild = false;
                $scope.errorsArray = [];
                $scope.errorsArray.push("ULP_0000");
                window.scrollTo(0, 0);
                
            });
                 
        }	
        //Submit button logic -E
        
        
        //tooltip - S
        $( document ).ready(function() {
            
            $( ".help_tooltip" ).mouseover(function(event) {
                //var offset = $(this).offset();
                var position = $(this).position();
                var offsetBottom = position.bottom - 50;
                var offsetTop = position.top;
                var offsetLeft = position.left - 130;
                
                var windowH = window.innerHeight;
                var windowW = window.innerWidth;
                
                var divH = $( ".help_tip" ).innerHeight();
                var divW = $( ".help_tip" ).innerWidth();
                
                // alert(position.top);
                $('.help_tip').css('top', offsetTop - divH - 50);
                $('.help_tip').css('left', offsetLeft);
                //   alert("windowH : "+windowH+" windowW : "+windowW);
                //   alert("divH : "+divH+" divW : "+divW);
                
                //$('.help_tip').removeClass("tooltipMrgBtm");
                //$('.help_tip').removeClass("tooltipMrgTopnonAtt");
                //$('.help_tip').addClass("tooltipMrgTop");
                
                var clientX = event.clientX;
                var clientY = event.clientY;
                //   alert("clientX : "+clientX+" clientY : "+clientY);

                var remainHB = windowH - clientY;
                
                //  alert("remainHB : "+remainHB);
                
                if(clientY < divH+100){
                    $('.help_tip').css('top', offsetTop);
                    $('.help_tip').css('bottom', offsetBottom);
                    
                    //$('.help_tip').removeClass("tooltipMrgTop");
                    //$('.help_tip').removeClass("tooltipMrgTopnonAtt");
                    //$('.help_tip').addClass("tooltipMrgBtm");
                }
                //$('.help_tip').css('color', '#000');
                
            });
            
        });
        //tooltip - E

        //To smothen the User experience we want the loader till UI gets ready
        closeLoader();

    } else {
        //redirecting user to portal entry page
        $window.location.href = '/deviceunlock/#/';
    }    

}]);
//Unlock Step 2 Non AT&T Controller - E
