/**
 * @Author 		:- Aniket Vidhate (av0041)   
 * Date			:- 12-7-2015
 * File name 	:- constant.js
 */

url = {


	//staging
	imageCaptchaImage : "/apis/deviceunlock/unlockCaptcha/image",
    audioCaptchaImage : "/apis/deviceunlock/unlockCaptcha/sound",
    unlockStepPostURL : "/apis/deviceunlock/OCEUnlockOrder/orderFlow",
    unlockStatusURL   : "/apis/deviceunlock/UnlockOrder/unlockOrderStatus",
    emailSecureDomain : "/apis/deviceunlock/UnlockUtility/Verify/ValidateEmail",
    OCEverifyEmail    : "/apis/deviceunlock/OCEUnlockOrder/Verify/VerifyEmail"




/*
    //Deepesh
    imageCaptchaImage : "http://INPUSCLP02846:8181/apis/deviceunlock/unlockCaptcha/image",
    audioCaptchaImage : "http://INPUSCLP02846:8181/apis/deviceunlock/unlockCaptcha/sound",
    unlockStepPostURL : "http://INPUSCLP02846:8181/apis/deviceunlock/OCEUnlockOrder/orderFlow",
    unlockStatusURL   : "http://INPUSCLP02846:8181/apis/deviceunlock/UnlockOrder/unlockOrderStatus",
	emailSecureDomain : "http://INPUSCLP02846:8181/apis/deviceunlock/UnlockUtility/Verify/ValidateEmail",
    OCEverifyEmail    : "http://INPUSCLP02846:8181/apis/deviceunlock/OCEUnlockOrder/Verify/VerifyEmail"
*/
/*

    //Aniket
    imageCaptchaImage : "http://INPUGSPC04830:8181/apis/deviceunlock/unlockCaptcha/image",
    audioCaptchaImage : "http://INPUGSPC04830:8181/apis/deviceunlock/unlockCaptcha/sound",
    unlockStepPostURL : "http://INPUGSPC04830:8181/apis/deviceunlock/OCEUnlockOrder/orderFlow",
    unlockStatusURL   : "http://INPUGSPC04830:8181/apis/deviceunlock/UnlockOrder/unlockOrderStatus",
    emailSecureDomain : "http://INPUGSPC04830:8181/apis/deviceunlock/UnlockUtility/Verify/ValidateEmail",
    OCEverifyEmail    : "http://INPUGSPC04830:8181/apis/deviceunlock/OCEUnlockOrder/Verify/VerifyEmail"
*/

}

