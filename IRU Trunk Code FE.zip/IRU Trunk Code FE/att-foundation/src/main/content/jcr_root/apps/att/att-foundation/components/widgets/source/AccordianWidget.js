/**
* @class MyClientLib.CustomPathFieldWidget
* @extends CQ.form.CompositeField
* This is a custom path field with a Link Text and a Link URL
* @param {Object} config the config object
*/
/**
* @class Ejst.CustomWidget
* @extends CQ.form.CompositeField
* This is a custom widget based on {@link CQ.form.CompositeField}.
* @constructor
* Creates a new CustomWidget.
* @param {Object} config The config object
*/

CQ.form.AccordianWidget = CQ.Ext.extend(CQ.form.CompositeField, {
	/**
	* @private
	* @type CQ.Ext.form.TextField
	*/
	hiddenField: null,
	/**
	* @private
	* @type CQ.Ext.form.TextField
	*/
	accordianTitle: null,
	/**
	* @private
	* @type CQ.form.RichText
	*/
	accordianDesc: null,

	constructor: function (config) {
		config = config || {};
		var defaults = {
		    "border": true,
		    "labelWidth": 80,
		    "layout": "form",
		    "padding": 10,
		}; 

		config = CQ.Util.applyDefaults(config, defaults);
		CQ.form.AccordianWidget.superclass.constructor.call(this, config);
	},
	initComponent: function () {

	    CQ.form.AccordianWidget.superclass.initComponent.call(this);
	    // Hidden field
	    this.hiddenField = new CQ.Ext.form.Hidden({
	         name: this.name
	    });
	    this.add(this.hiddenField);

	// Text TextField to enter Title
	    this.accordianTitle = new CQ.Ext.form.TextField({
	        cls: "customwidget-1",
	        maxLength: 300,
	        fieldLabel:'Title',
	        emptyText: "Accordian Title",
	        maxLengthText: "A maximum of 300 characters is allowed.",
	        width: 450,
	        allowBlank: true,
	        name : "item",
	        listeners: {
		        change: {
		        	scope: this,
				    fn: this.updateHidden
			    }
	        }
	    }); 
	    this.add(this.accordianTitle);

	// Link PathField to map a URL
	  this.accordianDesc = new CQ.form.RichText({
	        cls: "customwidget-2",
	        allowBlank: true,
	        fieldLabel:'Description',
	        emptyText: "Accordian Description",
	        width: 450,
	        listeners: {
		         change: {
		            scope: this,
		            fn: this.updateHidden
		        },
		        destroy: {
		            scope: this,
		            fn: this.descDestroy
		        }
	        }
	    });

	    this.add(this.accordianDesc);
	},

	processInit: function (path, record) { 
	    this.accordianTitle.processInit(path, record);
	    this.accordianDesc.processInit(path, record);
	},

	setValue: function (value) {
	    var link = JSON.parse(value);
	    this.accordianTitle.setValue(link.title);
	    this.accordianDesc.setValue(link.desc);
	},

	getValue: function () {
	    return this.getRawValue();
	},

	getRawValue: function () { 
	    var link = {
		    "desc": this.accordianDesc.getValue(),
		    "title": this.accordianTitle.getValue()
	    }; 
	    return JSON.stringify(link);
	},

	processValue: function(value) {        
        if ((value === undefined) || (value === null)) {
            value = "";
        }    
        // calling updateHidden() as change event not functioning for RTE widget
        this.updateHidden();
        return value;                  
    },

	updateHidden: function () {
		this.hiddenField.setValue(this.getValue());
	},

	descDestroy: function() {
	    this.accordianDesc.el.dom = {};
	}
});

CQ.Ext.reg("AccordianWidget", CQ.form.AccordianWidget);