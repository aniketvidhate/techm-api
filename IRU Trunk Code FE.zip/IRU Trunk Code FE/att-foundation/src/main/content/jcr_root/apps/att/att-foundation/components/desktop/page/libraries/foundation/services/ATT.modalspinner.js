(function () {
    'use strict';
	angular.module("ModalSpinner", [])
	
	.factory("spinner", ["$rootScope", "$q", "$log", function($rootScope, $q, $log) {
		return function() {
			var dfd = $q.defer(), 
				close = function() {
					$log.info($rootScope.attSpinnerNumResolved + "===" + $rootScope.attSpinnerPromises.length);
					if ($rootScope.attSpinnerNumResolved === $rootScope.attSpinnerPromises.length) {
						$rootScope.$broadcast("SPINNER_CLOSE");
					}
				};
			$rootScope.attSpinnerPromises.push(dfd.promise.then(function() {
				$rootScope.attSpinnerNumResolved++;
				$log.info("resolved spinner dfd"+$rootScope.attSpinnerPromises.length);
			}));
			
			$rootScope.attSpinnerDone = $q.all($rootScope.attSpinnerPromises);
			$rootScope.attSpinnerHolder.resolve();
			$rootScope.attSpinnerDone.then(function(){$log.info("resolved all spinner promises");}).then(close);
			return dfd;
		};
	}])
	
	.controller("ModalSpinnerCtrl", ["$scope", function($scope) {
		// PAR-302||WBFC Provide : Offers Page : Implement Progressive Loading 
        if(angular.element($('#offerTilesDiv')).length){
           $scope.isLoading = false;
           $scope.isOffersList = true;
        }
        else{ 
          $scope.isLoading = true;
          $scope.isOffersList = false;
        }
		function isLoading(val,page) {
           if(page=='offersPage'){
				$scope.isOffersList = val;
                $scope.isLoading = false;
                $scope.isPersonalInfo=false;
            }
             else if(page=='personalInfo') {
                $scope.isOffersList = false;
				$scope.isLoading = false;
                $scope.isPersonalInfo=val;
            } else {
                $scope.isPersonalInfo=false;
                $scope.isLoading=val;
				$scope.isOffersList = false;
            }
		}
		$scope.$on("SPINNER_OPEN", function() {
			angular.element("body").addClass("pageLoadStarted");
			isLoading(true,'other');
		});
		$scope.$on("SPINNER_CLOSE", function() {
			isLoading(false,'other');
			angular.element("body").removeClass("pageLoadStarted");
		});
        $scope.$on("SPINNER_OFFERS_OPEN", function() {
            $scope.isLoading = false;
			isLoading(true,'offersPage');
		});
         $scope.$on("SPINNER_OFFERS_CLOSE", function() {
            isLoading(false,'offersPage');
        });
        $scope.$on("SPINNER_OPEN_NEW", function() {
			isLoading(true,'personalInfo');
			angular.element("body").removeClass("pageLoadStarted");
		});
        $scope.$on("SPINNER_CLOSE_NEW", function() {
			isLoading(false,'personalInfo');
			angular.element("body").removeClass("pageLoadStarted");
		});
	}])
	
	.run(["$rootScope", "$q", "$log", function($rootScope,$q, $log) {
		var t, 
			close = function() {
				$log.info($rootScope.attSpinnerNumResolved + "===" + $rootScope.attSpinnerPromises.length);
				if ($rootScope.attSpinnerNumResolved === $rootScope.attSpinnerPromises.length) {
					$rootScope.$broadcast("SPINNER_CLOSE");
				}
			};
		$rootScope.attSpinnerHolder =  $q.defer();
		$rootScope.attSpinnerNumResolved = 0;
		$rootScope.attSpinnerPromises = [$rootScope.attSpinnerHolder.promise.then(function() {
			$rootScope.attSpinnerNumResolved++;
			$log.info("resolved spinner holder");
		})];
		$rootScope.attSpinnerDone = $q.all($rootScope.attSpinnerPromises);
		$rootScope.attSpinnerDone.then(function(){
			$log.info("resolved all spinner promises?");
		}).then(close);
		t = setTimeout(function() {$rootScope.$broadcast("SPINNER_CLOSE");}, 30000);
	}]);
	
})();