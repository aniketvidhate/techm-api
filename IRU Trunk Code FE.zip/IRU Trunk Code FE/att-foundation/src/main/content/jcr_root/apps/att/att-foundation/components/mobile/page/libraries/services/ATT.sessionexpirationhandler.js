(function(){
    'use strict';
	angular.module('SessionExpirationHandler', ['appConfig', 'attManager', 'ui.bootstrap']) 
	
	.factory("sessionExpire", function($rootScope, $modal, appInfo) {
		var services = {}, modalInstance, modalUrl;
        services.showExpireMessage = function(param) {
			if (param.sessionExpireType === 'expired') {
				if (modalInstance !== undefined) {
					modalInstance.close();
				}
			}
			if (appInfo.flowType === 'uvMobileCkav') {
				modalUrl = '/shopmobile/u-verse/availability/modal/sessionexpire.html';
			}
			modalInstance = $modal.open({
				templateUrl: modalUrl,
				controller: 'sessionExpireCtrl',
				resolve: {
					message: function() {
					  return param;
					}
				}
			});		
		};
		return services;
	})
	
	.run(function($rootScope, sessionExpire, $window) {
		$rootScope.$on('SESSION_EXPIRE', function(pEvent, pMessage) {
			sessionExpire.showExpireMessage(pMessage);
			$window.sessionStorage.setItem('sessionExpired',  true);
		});	
	})
	
	.controller('sessionExpireCtrl', function ($scope, $rootScope, $modalInstance, message, appInfo, attRedirect, $timeout,reporting, $window, httpATT, Env) {
		var showExpireWarning=2, showExpireMsg=4;
		
		$scope.message = message;

		$scope.idle = message.sessionExpireType == 'warning' ? showExpireWarning : showExpireMsg; 
		$scope.idleDuration = 3; 
		$scope.warningDuration = 1;
        /* 86017 session exipre popup reload issue */
        $scope.updateRedirection = function() {
            $window.sessionStorage.setItem('sessionExpired',  true);
        };
		
		$rootScope.$broadcast('SESSION_EXPIRE_MODAL_OPEN', '');
		
        $scope.setFocusWithId=function($event,elementId) {
			$timeout(function(){
				angular.element('#' + elementId)[0].focus();
			},0);
        };
		
		$scope.close = function () {
			$rootScope.$broadcast('SESSION_EXPIRE_MODAL_CLICK', {cancel:false, close:true}); 
			$modalInstance.close();
            $window.sessionStorage.setItem('sessionExpired',  false);
			if (appInfo.flowType === 'uvMobileCkav') {
				attRedirect("/shopmobile/u-verse/availability.html");
			}
		};

		$scope.cancel = function () {		
			var path = "/model/ecom/cart/CartSummaryService/getCartSummary";
			if (appInfo.flowType === 'uvMobileCkav') {
				path = "/mobile/ecom/salesmobile/MobileCartSummaryService/getCartSummary";
			}	
			$rootScope.$broadcast('SESSION_EXPIRE_MODAL_CLICK', {cancel:true, close:false});	
			httpATT.get(path).then(function () {
				Env.resetSessionExpire();
			});
            $window.sessionStorage.setItem('showCoupon',  false);
			$modalInstance.dismiss();
		};
		
	});
	
})();