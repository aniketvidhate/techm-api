/*
The purpose of this module is to keep the static jsons for loading various pages in the buyflow
JSONs can be accessed using a service instead of making an API call
JSONs need to be retrieved by using the key
File created as part of Gigapower Integration project, Initial development phase
*/
(function(){
	'use strict';
	angular.module('staticJsonRepo',[])
	.factory('jsonService',function($q, $http){
		var jsons = {
				"premierVsStandardComparisonData":{
				    "standardOfferid": "prod123456",
				    "premierOfferId": "prod123457",
				    "premierOfferPrice": "150",
				    "standardOfferPrice": "180",
				    "offerItems": [
				      {
				        "serviceType": "TV",
				        "description": "DirectTV Premier package with 250 channels..",
				        "serviceItems": [
				          {
				            "label": "Largest capacity total home dvr",
				            "inPremium": "true",
				            "inStandard": "true"
				          },
				          {
				            "label": "Longhorn network(TM)",
				            "inPremium": "true",
				            "inStandard": "true"
				          },
				          {
				            "label": "HD Service",
				            "inPremium": "true",
				            "inStandard": "false"
				          }
				        ]
				      },
				      {
				        "serviceType": "Internet",
				        "description": "Up to 1Gbps Internet",
				        "serviceItems": [
				          {
				            "label": "Requires internet preferences",
				            "inPremium": "true",
				            "inStandard": "false"
				          },
				          {
				            "label": "Inhome wifi equipment fee",
				            "inPremium": "true",
				            "inStandard": "false"
				          }
				        ]
				      },
				      {
				        "serviceType": "Voice",
				        "description": "200 Minutes",
				        "serviceItems": []
				      },
				      {
				        "serviceType": "Plus",
				        "description": "",
				        "serviceItems": [
				          {
				            "label": "Free XBox",
				            "inPremium": "true",
				            "inStandard": "false"
				          },
				          {
				            "label": "3 year price guarantee",
				            "inPremium": "true",
				            "inStandard": "true"
				          }
				        ]
				      }
				    ]
				  },
				"premierbundles" : {"data": {
					  "englishShopFilterOffers": {
						    "ShopFilterOffers-5": {
						      "filterDetails": {
						        "filterId": "F90006",
						        "name": "NFL Sunday Ticket - Intro",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 146.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "DIRECTV PREMIER All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV PREMIER All In Package",
						                "childSkuId": "dtvs100003",
						                "displayName": "PREMIER All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our top-of-the-line package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000058",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 124.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000007",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 114.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000006",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 34.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 109.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "12 Mbps",
						              "HSIAShortDisplayName": "Max",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max",
						              "description": "Up to 12 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Max is ideal for active Internet users. One dynamic IP address at up to 12.0 Mbps download. Max is perfect for active gamers, people who share photos, music lovers and other sophisticated Internet users who need speed. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv20030",
						              "displayName": "AT&T U-verse High Speed Internet Max",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for downloading music"
						                }
						              ],
						              "productId": "uv40057"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000005",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 104.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000004",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 156.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "DIRECTV PREMIER All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV PREMIER All In Package",
						                "childSkuId": "dtvs100003",
						                "displayName": "PREMIER All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our top-of-the-line package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000059",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 5
						    },
						    "ShopFilterOffers-4": {
						      "filterDetails": {
						        "filterId": "99995",
						        "name": "NFL Sunday Ticket",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-7": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 42,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 116.99,
						            "term": 9999,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20004",
						              "displayName": "AT&T U-verse High Speed Internet Elite All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uvh20004"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000032",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 97,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000033",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004",
						              "nc10005"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!",
						              "HBO/Cinemax included!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 109,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "DIRECTV PREMIER All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV PREMIER All In Package",
						                "childSkuId": "dtvs100003",
						                "displayName": "PREMIER All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our top-of-the-line package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "PREMIER All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000008",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 69,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 36.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 225,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-ULTIMATE",
						                "description": "DIRECTV ULTIMATE All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV ULTIMATE All In Package",
						                "childSkuId": "dtvs100002",
						                "displayName": "ULTIMATE All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The movie lover's package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "ULTIMATE All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000007",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 42,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 69.99,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20004",
						              "displayName": "AT&T U-verse High Speed Internet Elite All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uvh20004"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 27.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 205,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-XTRA",
						                "description": "DIRECTV XTRA All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV XTRA All In Package",
						                "childSkuId": "dtvs100001",
						                "displayName": "XTRA All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100001",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our most popular package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "XTRA All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000004",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 59,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 36.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 225,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-ULTIMATE",
						                "description": "DIRECTV ULTIMATE All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV ULTIMATE All In Package",
						                "childSkuId": "dtvs100002",
						                "displayName": "ULTIMATE All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The movie lover's package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "ULTIMATE All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000006",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 50,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 27.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 205,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-XTRA",
						                "description": "DIRECTV XTRA All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV XTRA All In Package",
						                "childSkuId": "dtvs100001",
						                "displayName": "XTRA All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100001",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our most popular package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "XTRA All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000005",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004",
						              "nc10005"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!",
						              "HBO/Cinemax included!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "DIRECTV PREMIER All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV PREMIER All In Package",
						                "childSkuId": "dtvs100003",
						                "displayName": "PREMIER All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our top-of-the-line package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "PREMIER All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000009",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 4
						    },
						    "ShopFilterOffers-7": {
						      "filterDetails": {
						        "filterId": "I90003",
						        "name": "NFL Sunday Ticket - Standard Intro",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 120.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 70.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 150,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-CHOICE",
						                "description": "CHOICE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The package that beats cable",
						                "childSkuId": "dtvs200003",
						                "displayName": "CHOICE",
						                "IncludedFlags": [],
						                "productId": "dtvp200003",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "CHOICE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000125",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 110.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 70.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 150,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-CHOICE",
						                "description": "CHOICE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The package that beats cable",
						                "childSkuId": "dtvs200003",
						                "displayName": "CHOICE",
						                "IncludedFlags": [],
						                "productId": "dtvp200003",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "CHOICE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000124",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 196.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "PREMIER Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our top-of-the-line package",
						                "childSkuId": "dtvs200006",
						                "displayName": "PREMIER",
						                "IncludedFlags": [],
						                "productId": "dtvp200006",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000141",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 34.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 105.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "12 Mbps",
						              "HSIAShortDisplayName": "Max",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max",
						              "description": "Up to 12 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Max is ideal for active Internet users. One dynamic IP address at up to 12.0 Mbps download. Max is perfect for active gamers, people who share photos, music lovers and other sophisticated Internet users who need speed. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv20030",
						              "displayName": "AT&T U-verse High Speed Internet Max",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for downloading music"
						                }
						              ],
						              "productId": "uv40057"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 70.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 150,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-CHOICE",
						                "description": "CHOICE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The package that beats cable",
						                "childSkuId": "dtvs200003",
						                "displayName": "CHOICE",
						                "IncludedFlags": [],
						                "productId": "dtvp200003",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "CHOICE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000123",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 100.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 70.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 150,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-CHOICE",
						                "description": "CHOICE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The package that beats cable",
						                "childSkuId": "dtvs200003",
						                "displayName": "CHOICE",
						                "IncludedFlags": [],
						                "productId": "dtvp200003",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "CHOICE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000122",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 206.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "PREMIER Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our top-of-the-line package",
						                "childSkuId": "dtvs200006",
						                "displayName": "PREMIER",
						                "IncludedFlags": [],
						                "productId": "dtvp200006",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000142",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 7
						    },
						    "ShopFilterOffers-6": {
						      "filterDetails": {
						        "filterId": "I90001",
						        "name": "NFL Sunday Ticket -Standard",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 109,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 225,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-ULTIMATE",
						                "description": "ULTIMATE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The movie lover package",
						                "childSkuId": "dtvs200005",
						                "displayName": "ULTIMATE",
						                "IncludedFlags": [],
						                "productId": "dtvp200005",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "ULTIMATE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000029",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 100,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 77.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 205,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-XTRA",
						                "description": "XTRA Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our most popular package",
						                "childSkuId": "dtvs200004",
						                "displayName": "XTRA",
						                "IncludedFlags": [],
						                "productId": "dtvp200004",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "XTRA",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000028",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 94,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 71.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 230,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-MAS-ULTRA",
						                "description": "MÁS ULTRA Package",
						                "prodLosgId": "dtv",
						                "longDescription": "More channels, movies and sports",
						                "childSkuId": "dtvs200015",
						                "displayName": "MÁS ULTRA",
						                "IncludedFlags": [],
						                "productId": "dtvp200015",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "MÁS ULTRA",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000037",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 169,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "PREMIER Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our top-of-the-line package",
						                "childSkuId": "dtvs200006",
						                "displayName": "PREMIER",
						                "IncludedFlags": [],
						                "productId": "dtvp200006",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000032",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 159,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 320,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-LO-MAXIMO",
						                "description": "LO MAXIMO Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The movie lover’s package",
						                "childSkuId": "dtvs200016",
						                "displayName": "LO MAXIMO",
						                "IncludedFlags": [],
						                "productId": "dtvp200016",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "LO MAXIMO",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000039",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 159,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "PREMIER Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our top-of-the-line package",
						                "childSkuId": "dtvs200006",
						                "displayName": "PREMIER",
						                "IncludedFlags": [],
						                "productId": "dtvp200006",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000031",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 225,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-ULTIMATE",
						                "description": "ULTIMATE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The movie lover package",
						                "childSkuId": "dtvs200005",
						                "displayName": "ULTIMATE",
						                "IncludedFlags": [],
						                "productId": "dtvp200005",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "ULTIMATE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000030",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 104,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 71.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 230,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-MAS-ULTRA",
						                "description": "MÁS ULTRA Package",
						                "prodLosgId": "dtv",
						                "longDescription": "More channels, movies and sports",
						                "childSkuId": "dtvs200015",
						                "displayName": "MÁS ULTRA",
						                "IncludedFlags": [],
						                "productId": "dtvp200015",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "MÁS ULTRA",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000038",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 169,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 320,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-LO-MAXIMO",
						                "description": "LO MAXIMO Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The movie lover’s package",
						                "childSkuId": "dtvs200016",
						                "displayName": "LO MAXIMO",
						                "IncludedFlags": [],
						                "productId": "dtvp200016",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "LO MAXIMO",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000040",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 6
						    },
						    "ShopFilterOffers-1": {
						      "filterDetails": {
						        "filterId": "1100001",
						        "name": "Special Offers for AT&T Wireless Customers",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 186.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450",
						                "description": "Over 550 channels and apps including HD premium channels for more movies, sports and original series",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U300 Package, plus HBO® and Cinemax® packages, The Sports Package, and more.",
						                "childSkuId": "uv120001",
						                "displayName": "AT&T U-verse U450",
						                "IncludedFlags": [],
						                "productId": "uv230002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190676",
						              "totalChannels": 550,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 127
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 154.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 470 channels and apps, The Movie Package, digital music and more",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U200 Package, plus The Movie Package - STARZ®, ENCORE®, SHOWTIME®, and more!",
						                "childSkuId": "uv30010",
						                "displayName": "AT&T U-verse U300",
						                "IncludedFlags": [],
						                "productId": "uv50013",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190672",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 95
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 139.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190668",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 134.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 470 channels and apps, The Movie Package, digital music and more",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U200 Package, plus The Movie Package - STARZ®, ENCORE®, SHOWTIME®, and more!",
						                "childSkuId": "uv30010",
						                "displayName": "AT&T U-verse U300",
						                "IncludedFlags": [],
						                "productId": "uv50013",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190670",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 95
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 94.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "Over 200 channels and apps including local programing",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-family channel line-up, including family-focused and local programming",
						                "childSkuId": "uv40004",
						                "displayName": "AT&T U-verse U-family",
						                "IncludedFlags": [],
						                "productId": "uv60004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190677",
						              "totalChannels": 200,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 65
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 124.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "Over 200 channels and apps including local programing",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-family channel line-up, including family-focused and local programming",
						                "childSkuId": "uv40004",
						                "displayName": "AT&T U-verse U-family",
						                "IncludedFlags": [],
						                "productId": "uv60004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190663",
						              "totalChannels": 200,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 65
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190666",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 109.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190664",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 166.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450",
						                "description": "Over 550 channels and apps including HD premium channels for more movies, sports and original series",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U300 Package, plus HBO® and Cinemax® packages, The Sports Package, and more.",
						                "childSkuId": "uv120001",
						                "displayName": "AT&T U-verse U450",
						                "IncludedFlags": [],
						                "productId": "uv230002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190674",
						              "totalChannels": 550,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 127
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 1
						    },
						    "ShopFilterOffers-0": {
						      "filterDetails": {
						        "filterId": "1100008",
						        "name": "Recommended For You",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700006",
						              "700009"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes <b>NFL and MLB Networks</b> plus <b>NBA TV</b> ",
						              "Includes more movies (<b>Showtime&#174; Unlimited, Starz&#174;, Encore&#174;, and more</b>), sports, and music channels than U200"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 154.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 470 channels and apps, The Movie Package, digital music and more",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U200 Package, plus The Movie Package - STARZ®, ENCORE®, SHOWTIME®, and more!",
						                "childSkuId": "uv30010",
						                "displayName": "AT&T U-verse U300",
						                "IncludedFlags": [],
						                "productId": "uv50013",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8040273",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 95
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700010",
						              "700007"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes everything in U-family , more news channels (<b>FOX</b>), and sports channels (<b>ESPN</b>)",
						              "More educational channels (<b>Animal planet, Discovery</b>) and kids channels (<b>Disney, Nickelodeon</b>)"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020301",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "200002"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Includes HBO® & Amazon Prime",
						            "additionalBundleFeatures": [
						              "Includes HBO®/HBO GO®"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 74.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "500001",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-basic",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ubasic",
						                "description": "Over 20 Channels - Locals only",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-basic channel lineup, including local programming",
						                "childSkuId": "sku4180240",
						                "displayName": "AT&T U-verse U-basic",
						                "IncludedFlags": [],
						                "productId": "prod4140221",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 non-DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15. For new residential U-verse customers. 12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term. After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8150701",
						              "totalChannels": 20,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 19
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700006",
						              "700009"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes <b>NFL and MLB Networks</b> plus <b>NBA TV</b> ",
						              "Includes more movies (<b>Showtime&#174; Unlimited, Starz&#174;, Encore&#174;, and more</b>), sports, and music channels than U200"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 134.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 470 channels and apps, The Movie Package, digital music and more",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U200 Package, plus The Movie Package - STARZ®, ENCORE®, SHOWTIME®, and more!",
						                "childSkuId": "uv30010",
						                "displayName": "AT&T U-verse U300",
						                "IncludedFlags": [],
						                "productId": "uv50013",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020299",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 95
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700001",
						              "700004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "AT&T Wi-Fi Hot Spot access",
						              "Includes family-friendly channels (<b>Disney, Discovery, Sprout, Nick Jr.<b/>) "
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 94.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "Over 200 channels and apps including local programing",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-family channel line-up, including family-focused and local programming",
						                "childSkuId": "uv40004",
						                "displayName": "AT&T U-verse U-family",
						                "IncludedFlags": [],
						                "productId": "uv60004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020298",
						              "totalChannels": 200,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 65
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29,
						              "promoId": "23600082",
						              "displayName": "$29.00 off / 12mo.  1 yr term required. Other charges apply"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 105,
						            "lightGigRedirect": true,
						            "voipOfferPrice": 0,
						            "price": 185,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "1 Gbps",
						              "HSIAShortDisplayName": "Internet 1000",
						              "imageName": "ATT-Uverse-High-Speed-Internet-1G",
						              "description": "Up to 1 Gbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "AT&T U-verse High Speed Internet 1Gbps",
						              "childSkuId": "sku6980407",
						              "displayName": "AT&T U-verse High Speed Internet 1Gbps",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Our fastest speed ever for the ultimate online experience. Get super-fast streaming of movies and shows to all your devices at once."
						                }
						              ],
						              "productId": "prod7700245"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "U200TV + 1G",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "U200TV + 1G",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "<b> $150 U-verse with AT&T GigaPower Offer</b>: For res. customers in GigaPower areas  when ordered online at att.com. Price for U200 TV, and High Speed Internet 1Gbps. 1 year term req&#039;d. An ETF of up to $180 may apply if TV service is downgraded or disconnected before end of term. After 12 mos, std rates apply unless canceled by customer.  Must maintain qualifying services to receive advertised pricing. <b>AT&T Internet Preferences:</b> Requires customer to opt into AT&T Internet Preferences at time of original order. Go to att.com/InternetPreferences. If customer later opts out after service installation, std rates for service, equipment fees and other chrgs will apply. Offer ends  09/20/15. <br/><br/><b> AT&T U-verse</b>:  Credit restrictions may apply.  Promo pricing applies to service rates . Excl taxes, equip. fees and other chrgs, a $49 activation fee, federal regulatory video cost recovery chrg, city video cost recovery fees, and a Broadcast TV surcharge. Pricing, programming, features. sbj to change at any time without notice. <br/><br/><b> AT&T U-verse High Speed Internet 1Gbps</b>:  Internet speed claims represent maximum network service capability speeds. Actual customer speeds may vary and are not guaranteed. Actual speeds vary based on factors incl site traffic, content provider server capacity, internal network management factors, device capabilities and use of other U-verse services. Max speeds may not be realized if 2 or more HD shows viewed at same time. For more info, go to www.att.com/speed101.  Internet price incl 1TB of data/mo. $10 per addl 50GB. For more info, go to www.att.com/internet-usage. <br/><br/>Wi-Fi usage at home will count towards your High Speed Internet Service data plan. addl chrgs may apply for usage in excess of your data plan. <br/><br/>&#169; 2015 AT&T Intellectual Property. AT&T, the AT&T logo and all other AT&T marks contained herein are trademarks of AT&T Intellectual Property and/or AT&T affiliated companies. All rights reserved.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8210515",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false,
						              "isGigapowerOffer": true,
						              "optin": true,
						              "associatedOfferId": "prod8210515"
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29,
						              "promoId": "23600082",
						              "displayName": "$29.00 off / 12mo.  1 yr term required. Other charges apply"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 75,
						            "lightGigRedirect": true,
						            "voipOfferPrice": 0,
						            "price": 155,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "300 Mbps",
						              "HSIAShortDisplayName": "Internet 300",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia300",
						              "description": "Up to 300 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "AT&T U-verse High Speed Internet 300",
						              "childSkuId": "sku6880578",
						              "displayName": "AT&T U-verse High Speed Internet 300",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Blazing-fast downloads for superior streaming and high-performance gaming"
						                }
						              ],
						              "productId": "prod7610308"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "U200TV + 300M",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "U200TV + 300M",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "<b>$120 U-verse with AT&T GigaPower Offer</b>:  For res. customers in GigaPower areas when ordered online at att.com.   Price for U200 TV and High Speed Internet 300.   1 year term req&#039;d. An ETF of up to $180 may apply if TV service is downgraded or disconnected before end of term. After 12 mos, std rates apply unless canceled by customer.  Must maintain qualifying services to receive advertised pricing.  <b>AT&T Internet Preferences</b>:  Requires customer to opt into AT&T Internet Preferences at time of original order. Go to att.com/InternetPreferences. If customer later opts out after service installation, std rates for service, equipment fees and other chrgs will apply. Offer ends  09/20/15. <br/><br/><b>AT&T U-verse</b>:  Credit restrictions may apply.  Promo pricing applies to service rates . Excl taxes, equip. fees and other chrgs, a $49 activation fee, federal regulatory video cost recovery chrg, city video cost recovery fees, and a Broadcast TV surcharge. Pricing, programming, and features. sbj to change at any time without notice. <br/><br/><b>AT&T U-verse High Speed Internet 300</b>:  Internet speed claims represent maximum network service capability speeds. Actual customer speeds may vary and are not guaranteed. Actual speeds vary based on factors incl site traffic, content provider server capacity, internal network management factors, device capabilities and use of other U-verse services.  Max speeds may not be realized if 2 or more HD shows viewed at same time. For more info, go to www.att.com/speed101 . Internet price incl 500GB of data/mo. $10 per addl 50GB. For more info, go to www.att.com/internet-usage. <br/><br/>Wi-Fi usage at home will count towards your High Speed Internet Service data plan. addl chrgs may apply for usage in excess of your data plan. <br/><br/>&#169; 2015 AT&T Intellectual Property. AT&T, the AT&T logo and all other AT&T marks contained herein are trademarks of AT&T Intellectual Property and/or AT&T affiliated companies. All rights reserved.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8210511",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false,
						              "isGigapowerOffer": true,
						              "optin": true,
						              "associatedOfferId": "prod8210511"
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "200002"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Includes HBO® & Amazon Prime",
						            "additionalBundleFeatures": [
						              "Includes HBO®/HBO GO®"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 94.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "200001",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-basic",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ubasic",
						                "description": "Over 20 Channels - Locals only",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-basic channel lineup, including local programming",
						                "childSkuId": "sku4180240",
						                "displayName": "AT&T U-verse U-basic",
						                "IncludedFlags": [],
						                "productId": "prod4140221",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 non-DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers. 12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term. After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8200477",
						              "totalChannels": 20,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 19
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700008",
						              "700005"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "<b>HBO® and Cinemax®</b> included at no extra charge ($26/mo. value!)",
						              "Access to <b>over 225 HD</b> channels included ($10/mo. value!) "
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 166.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450",
						                "description": "Over 550 channels and apps including HD premium channels for more movies, sports and original series",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U300 Package, plus HBO® and Cinemax® packages, The Sports Package, and more.",
						                "childSkuId": "uv120001",
						                "displayName": "AT&T U-verse U450",
						                "IncludedFlags": [],
						                "productId": "uv230002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020302",
						              "totalChannels": 550,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 127
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 0
						    },
						    "ShopFilterOffers-3": {
						      "filterDetails": {
						        "filterId": "F90004",
						        "name": "Recommended For You - Intro",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 184.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 490 channels including premium channels, HD channels, sports, and much more.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10005",
						                "displayName": "AT&T U-verse TV U450 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10005",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000033",
						              "totalChannels": 490,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 125
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 152.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 420 channels, including The Movie Package, digital music, and more",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10004",
						                "displayName": "AT&T U-verse TV U300 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000023",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 103
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 112.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "The best family-oriented channels, including popular childrens programming, learning channels, home-living networks, and 38 digital Music Choice channels that cover multiple genres.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10002",
						                "displayName": "AT&T U-verse TV U-Family All In",
						                "IncludedFlags": [],
						                "productId": "uvip10002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000006",
						              "totalChannels": 140,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 73
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 157.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 310 of the most popular digital channels, local programming and music channels.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10003",
						                "displayName": "AT&T U-verse TV U200 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000016",
						              "totalChannels": 310,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 88
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 122.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "The best family-oriented channels, including popular childrens programming, learning channels, home-living networks, and 38 digital Music Choice channels that cover multiple genres.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10002",
						                "displayName": "AT&T U-verse TV U-Family All In",
						                "IncludedFlags": [],
						                "productId": "uvip10002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000007",
						              "totalChannels": 140,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 73
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 194.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 490 channels including premium channels, HD channels, sports, and much more.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10005",
						                "displayName": "AT&T U-verse TV U450 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10005",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000034",
						              "totalChannels": 490,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 125
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 162.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 420 channels, including The Movie Package, digital music, and more",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10004",
						                "displayName": "AT&T U-verse TV U300 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000024",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 103
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 147.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 310 of the most popular digital channels, local programming and music channels.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10003",
						                "displayName": "AT&T U-verse TV U200 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000015",
						              "totalChannels": 310,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 88
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 172.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 420 channels, including The Movie Package, digital music, and more",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10004",
						                "displayName": "AT&T U-verse TV U300 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000025",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 103
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 3
						    },
						    "ShopFilterOffers-2": {
						      "filterDetails": {
						        "filterId": "99991",
						        "name": "Recommended For You",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-1": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 135.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 420 channels, including The Movie Package, digital music, and more",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10004",
						                "displayName": "AT&T U-verse TV U300 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000015",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 103
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 120.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 310 of the most popular digital channels, local programming and music channels.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10003",
						                "displayName": "AT&T U-verse TV U200 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000012",
						              "totalChannels": 310,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 88
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-4": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 95.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "The best family-oriented channels, including popular childrens programming, learning channels, home-living networks, and 38 digital Music Choice channels that cover multiple genres.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10002",
						                "displayName": "AT&T U-verse TV U-Family All In",
						                "IncludedFlags": [],
						                "productId": "uvip10002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000009",
						              "totalChannels": 140,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 73
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 62.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-basic All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ubasic",
						                "description": "Get local and U-verse information channels for the lowest U-verse TV price.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10001",
						                "displayName": "AT&T U-verse TV U-Basic All In",
						                "IncludedFlags": [],
						                "productId": "uvip10001",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 non-DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000057",
						              "totalChannels": 20,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 40
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 157.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 490 channels including premium channels, HD channels, sports, and much more.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10005",
						                "displayName": "AT&T U-verse TV U450 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10005",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000018",
						              "totalChannels": 490,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 125
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 2
						    }
						  },
						  "wbfcResponse": {
						    "statusCode": 600,
						    "redirectURL": null,
						    "doRedirect": false,
						    "statusName": "Success"
						  },
						  "latinoShopFilterOffers": {
						    "ShopFilterOffers-1": {
						      "filterDetails": {
						        "filterId": "1100001",
						        "name": "Special Offers for AT&T Wireless Customers",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 166.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190711",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 134.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190710",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190712",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 144.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190718",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 129.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190714",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 196.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190724",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 176.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190722",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 149.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190716",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 164.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190720",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 1
						    },
						    "ShopFilterOffers-0": {
						      "filterDetails": {
						        "filterId": "1100008",
						        "name": "Recommended For You",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100002"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes HD"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 176.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020311",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 166.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190705",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 134.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190704",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 129.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020310",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020309",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100002"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes HD"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 196.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8040280",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 164.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8040279",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 149.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020312",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 144.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020308",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 0
						    },
						    "ShopFilterOffers-3": {
						      "filterDetails": {
						        "filterId": "F90004",
						        "name": "Recommended For You - Intro",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 184.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 540 channels including premium channels, HD channels, sports, and much more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10008",
						                "displayName": "AT&T U-verse TV U450 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10008",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000059",
						              "totalChannels": 540,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 135
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 162.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 470 channels, including The Movie Package, digital music, and more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10007",
						                "displayName": "AT&T U-verse TV U300 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000050",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 113
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 147.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino All In ",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 360 of the most popular digital channels, local programming and music channels. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10006",
						                "displayName": "AT&T U-verse TV U200 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10006",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000041",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 98
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 182.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 470 channels, including The Movie Package, digital music, and more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10007",
						                "displayName": "AT&T U-verse TV U300 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000052",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 113
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 167.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino All In ",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 360 of the most popular digital channels, local programming and music channels. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10006",
						                "displayName": "AT&T U-verse TV U200 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10006",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000043",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 98
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 194.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 540 channels including premium channels, HD channels, sports, and much more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10008",
						                "displayName": "AT&T U-verse TV U450 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10008",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000060",
						              "totalChannels": 540,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 135
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 172.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 470 channels, including The Movie Package, digital music, and more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10007",
						                "displayName": "AT&T U-verse TV U300 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000051",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 113
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 157.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino All In ",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 360 of the most popular digital channels, local programming and music channels. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10006",
						                "displayName": "AT&T U-verse TV U200 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10006",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000042",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 98
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 204.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 540 channels including premium channels, HD channels, sports, and much more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10008",
						                "displayName": "AT&T U-verse TV U450 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10008",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000061",
						              "totalChannels": 540,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 135
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 3
						    },
						    "ShopFilterOffers-2": {
						      "filterDetails": {
						        "filterId": "99991",
						        "name": "Recommended For You",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-1": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 145.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 470 channels, including The Movie Package, digital music, and more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10007",
						                "displayName": "AT&T U-verse TV U300 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000024",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 113
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 130.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino All In ",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 360 of the most popular digital channels, local programming and music channels. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10006",
						                "displayName": "AT&T U-verse TV U200 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10006",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000021",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 98
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-2": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 167.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 540 channels including premium channels, HD channels, sports, and much more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10008",
						                "displayName": "AT&T U-verse TV U450 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10008",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000027",
						              "totalChannels": 540,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 135
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 2
						    }
						  },
						  "wtPkgOfferDetails": "prod8020298~Override~~~1|prod8020308~Override~~~2|prod8020299~Override~~~3|prod8020309~Override~~~4|prod8020302~Default~~~5|prod8020310~Default~~~6|prod8040279~Default~~~7|prod8200477~Default~~~8|prod8040280~Default~~~9|prod8210515~Default~~~10|prod8210511~Default~~~11|prod8020301~Default~~~12|prod8020312~Default~~~13|prod8020311~Default~~~14|prod8150701~Default~~~15|prod8040273~Default~~~16|prod8190704~Default~~~17|prod8040272~Default~~~18|prod8190705~Default~~~19|prod8040274~Default~~~20|prod8020305~Default~~~21|prod8020300~Default~~~22|prod8200557~Default~~~23|prod8200558~Default~~~24|prod8190629~Default~~~25|prod8190631~Default~~~26|prod8190632~Default~~~27|prod8190633~Default~~~28|prod8190634~Default~~~29|prod8190714~Override~~~30|prod8190677~Override~~~31|prod8190718~Override~~~32|prod8190670~Override~~~33|prod8190674~Default~~~34|prod8190720~Default~~~35|prod8190664~Default~~~36|prod8190724~Default~~~37|prod8190666~Default~~~38|prod8190716~Default~~~39|prod8190663~Default~~~40|prod8190722~Default~~~41|prod8190668~Default~~~42|prod8190712~Default~~~43|prod8190710~Default~~~44|prod8190672~Default~~~45|prod8190711~Default~~~46|prod8190676~Default~~~47|prod8190661~Default~~~48|prod8200559~Default~~~49|prod8200560~Default~~~50|prod8190660~Default~~~51|prod8190657~Default~~~52|prod8190658~Default~~~53|prod8190659~Default~~~54|pncb2000018~Default~~~55|pncb2000027~Default~~~56|pncb2000015~Default~~~57|pncb2000024~Default~~~58|pncb2000021~Default~~~59|pncb2000012~Default~~~60|pncb2000009~Default~~~61|pncb2000057~Default~~~62|pncb4000025~Default~~~63|pncb4000052~Default~~~64|pncb4000016~Default~~~65|pncb4000061~Default~~~66|pncb4000007~Default~~~67|pncb4000034~Default~~~68|pncb4000043~Default~~~69|pncb4000024~Default~~~70|pncb4000051~Default~~~71|pncb4000015~Default~~~72|pncb4000060~Default~~~73|pncb4000006~Default~~~74|pncb4000033~Default~~~75|pncb4000042~Default~~~76|pncb4000023~Default~~~77|pncb4000050~Default~~~78|pncb4000059~Default~~~79|pncb4000014~Default~~~80|pncb4000005~Default~~~81|pncb4000032~Default~~~82|pncb4000041~Default~~~83|pncb4000022~Default~~~84|pncb4000058~Default~~~85|pncb4000013~Default~~~86|pncb4000004~Default~~~87|pncb4000031~Default~~~88|pncb4000040~Default~~~89|pncb4000049~Default~~~90|pncb4000021~Default~~~91|pncb4000057~Default~~~92|pncb4000012~Default~~~93|pncb4000030~Default~~~94|pncb4000039~Default~~~95|pncb4000048~Default~~~96|pncb4000029~Default~~~97|pncb4000020~Default~~~98|pncb4000056~Default~~~99|pncb4000011~Default~~~100|pncb4000038~Default~~~101|pncb4000047~Default~~~102|pncb1000009~Default~~~103|pncb1000008~Default~~~104|pncb1000007~Default~~~105|pncb1000006~Default~~~106|pncb1000005~Default~~~107|pncb1000004~Default~~~108|pncb1000033~Default~~~109|pncb1000032~Default~~~110|pncb5000059~Default~~~111|pncb5000007~Default~~~112|pncb5000058~Default~~~113|pncb5000006~Default~~~114|pncb5000005~Default~~~115|pncb5000004~Default~~~116|pncb6000032~Default~~~117|pncb6000040~Default~~~118|pncb6000039~Default~~~119|pncb6000031~Default~~~120|pncb6000038~Default~~~121|pncb6000030~Default~~~122|pncb6000037~Default~~~123|pncb6000029~Default~~~124|pncb6000028~Default~~~125|pncb6000035~Default~~~126|pncb6000027~Default~~~127|pncb6000034~Default~~~128|pncb6000026~Default~~~129|pncb6000033~Default~~~130|pncb6000025~Default~~~131|pncb6000024~Default~~~132|pncb6000023~Default~~~133|pncb6000022~Default~~~134|pncb6000021~Default~~~135|pncb6000125~Default~~~136|pncb6000142~Default~~~137|pncb6000124~Default~~~138|pncb6000141~Default~~~139|pncb6000123~Default~~~140|pncb6000122~Default~~~141"
						}
					},
				"standardbundles" : {"data": {
					  "englishShopFilterOffers": {
						    "ShopFilterOffers-5": {
						      "filterDetails": {
						        "filterId": "F90006",
						        "name": "NFL Sunday Ticket - Intro",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 146.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "DIRECTV PREMIER All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV PREMIER All In Package",
						                "childSkuId": "dtvs100003",
						                "displayName": "PREMIER All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our top-of-the-line package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000058",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 124.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000007",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 114.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000006",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 34.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 109.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "12 Mbps",
						              "HSIAShortDisplayName": "Max",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max",
						              "description": "Up to 12 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Max is ideal for active Internet users. One dynamic IP address at up to 12.0 Mbps download. Max is perfect for active gamers, people who share photos, music lovers and other sophisticated Internet users who need speed. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv20030",
						              "displayName": "AT&T U-verse High Speed Internet Max",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for downloading music"
						                }
						              ],
						              "productId": "uv40057"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000005",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 104.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000004",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 156.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "DIRECTV PREMIER All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV PREMIER All In Package",
						                "childSkuId": "dtvs100003",
						                "displayName": "PREMIER All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our top-of-the-line package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER All In",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb5000059",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 5
						    },
						    "ShopFilterOffers-4": {
						      "filterDetails": {
						        "filterId": "99995",
						        "name": "NFL Sunday Ticket",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-7": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 42,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 116.99,
						            "term": 9999,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20004",
						              "displayName": "AT&T U-verse High Speed Internet Elite All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uvh20004"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000032",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 97,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 74.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 130,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-SELECT",
						                "description": "DIRECTV SELECT All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV SELECT All In Package",
						                "childSkuId": "dtvs100007",
						                "displayName": "SELECT All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The entertainment you want"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "SELECT All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000033",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004",
						              "nc10005"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!",
						              "HBO/Cinemax included!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 109,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "DIRECTV PREMIER All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV PREMIER All In Package",
						                "childSkuId": "dtvs100003",
						                "displayName": "PREMIER All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our top-of-the-line package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "PREMIER All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000008",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 69,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 36.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 225,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-ULTIMATE",
						                "description": "DIRECTV ULTIMATE All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV ULTIMATE All In Package",
						                "childSkuId": "dtvs100002",
						                "displayName": "ULTIMATE All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The movie lover's package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "ULTIMATE All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000007",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 42,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 69.99,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20004",
						              "displayName": "AT&T U-verse High Speed Internet Elite All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uvh20004"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 27.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 205,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-XTRA",
						                "description": "DIRECTV XTRA All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV XTRA All In Package",
						                "childSkuId": "dtvs100001",
						                "displayName": "XTRA All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100001",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our most popular package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "XTRA All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000004",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 59,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 36.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 225,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-ULTIMATE",
						                "description": "DIRECTV ULTIMATE All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV ULTIMATE All In Package",
						                "childSkuId": "dtvs100002",
						                "displayName": "ULTIMATE All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "The movie lover's package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "ULTIMATE All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000006",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 50,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 27.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 205,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-XTRA",
						                "description": "DIRECTV XTRA All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV XTRA All In Package",
						                "childSkuId": "dtvs100001",
						                "displayName": "XTRA All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100001",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our most popular package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "XTRA All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000005",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 10,
						              "promoId": "uvncp10019",
						              "displayName": "EXTRA $10 off for 12 Months"
						            },
						            {
						              "amount": 40,
						              "promoId": "uvncp10001",
						              "displayName": "$40 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "nc10003",
						              "nc10004",
						              "nc10005"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Amazing NFL SUNDAY TICKET 2015",
						            "additionalBundleFeatures": [
						              "FREE NFL Sunday Ticket",
						              "FREE HBO/Cinemax for the first 3 months!",
						              "HBO/Cinemax included!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": "nc10001",
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "DIRECTV PREMIER All In Package",
						                "prodLosgId": "dtv",
						                "longDescription": "DIRECTV PREMIER All In Package",
						                "childSkuId": "dtvs100003",
						                "displayName": "PREMIER All In",
						                "IncludedFlags": [],
						                "productId": "dtvp100003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "Our top-of-the-line package"
						                  }
						                ]
						              },
						              "iptv": null,
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": "PREMIER All In",
						              "offerDetails": "DTV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb1000009",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 4
						    },
						    "ShopFilterOffers-7": {
						      "filterDetails": {
						        "filterId": "I90003",
						        "name": "NFL Sunday Ticket - Standard Intro",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 120.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 70.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 150,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-CHOICE",
						                "description": "CHOICE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The package that beats cable",
						                "childSkuId": "dtvs200003",
						                "displayName": "CHOICE",
						                "IncludedFlags": [],
						                "productId": "dtvp200003",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "CHOICE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000125",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 110.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 70.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 150,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-CHOICE",
						                "description": "CHOICE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The package that beats cable",
						                "childSkuId": "dtvs200003",
						                "displayName": "CHOICE",
						                "IncludedFlags": [],
						                "productId": "dtvp200003",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "CHOICE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000124",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 196.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "PREMIER Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our top-of-the-line package",
						                "childSkuId": "dtvs200006",
						                "displayName": "PREMIER",
						                "IncludedFlags": [],
						                "productId": "dtvp200006",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000141",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 34.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 105.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "12 Mbps",
						              "HSIAShortDisplayName": "Max",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max",
						              "description": "Up to 12 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Max is ideal for active Internet users. One dynamic IP address at up to 12.0 Mbps download. Max is perfect for active gamers, people who share photos, music lovers and other sophisticated Internet users who need speed. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv20030",
						              "displayName": "AT&T U-verse High Speed Internet Max",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for downloading music"
						                }
						              ],
						              "productId": "uv40057"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 70.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 150,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-CHOICE",
						                "description": "CHOICE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The package that beats cable",
						                "childSkuId": "dtvs200003",
						                "displayName": "CHOICE",
						                "IncludedFlags": [],
						                "productId": "dtvp200003",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "CHOICE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000123",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 100.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 70.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 150,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-CHOICE",
						                "description": "CHOICE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The package that beats cable",
						                "childSkuId": "dtvs200003",
						                "displayName": "CHOICE",
						                "IncludedFlags": [],
						                "productId": "dtvp200003",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "CHOICE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000122",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 206.49,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "PREMIER Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our top-of-the-line package",
						                "childSkuId": "dtvs200006",
						                "displayName": "PREMIER",
						                "IncludedFlags": [],
						                "productId": "dtvp200006",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000142",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 7
						    },
						    "ShopFilterOffers-6": {
						      "filterDetails": {
						        "filterId": "I90001",
						        "name": "NFL Sunday Ticket -Standard",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 109,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 225,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-ULTIMATE",
						                "description": "ULTIMATE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The movie lover package",
						                "childSkuId": "dtvs200005",
						                "displayName": "ULTIMATE",
						                "IncludedFlags": [],
						                "productId": "dtvp200005",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "ULTIMATE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000029",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 100,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 77.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 205,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-XTRA",
						                "description": "XTRA Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our most popular package",
						                "childSkuId": "dtvs200004",
						                "displayName": "XTRA",
						                "IncludedFlags": [],
						                "productId": "dtvp200004",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "XTRA",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000028",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 94,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 71.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 230,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-MAS-ULTRA",
						                "description": "MÁS ULTRA Package",
						                "prodLosgId": "dtv",
						                "longDescription": "More channels, movies and sports",
						                "childSkuId": "dtvs200015",
						                "displayName": "MÁS ULTRA",
						                "IncludedFlags": [],
						                "productId": "dtvp200015",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "MÁS ULTRA",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000037",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 169,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "PREMIER Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our top-of-the-line package",
						                "childSkuId": "dtvs200006",
						                "displayName": "PREMIER",
						                "IncludedFlags": [],
						                "productId": "dtvp200006",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000032",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 159,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 320,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-LO-MAXIMO",
						                "description": "LO MAXIMO Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The movie lover’s package",
						                "childSkuId": "dtvs200016",
						                "displayName": "LO MAXIMO",
						                "IncludedFlags": [],
						                "productId": "dtvp200016",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "LO MAXIMO",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000039",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 159,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 285,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-PREMIER",
						                "description": "PREMIER Package",
						                "prodLosgId": "dtv",
						                "longDescription": "Our top-of-the-line package",
						                "childSkuId": "dtvs200006",
						                "displayName": "PREMIER",
						                "IncludedFlags": [],
						                "productId": "dtvp200006",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "PREMIER",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000031",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 86.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 225,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-ULTIMATE",
						                "description": "ULTIMATE Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The movie lover package",
						                "childSkuId": "dtvs200005",
						                "displayName": "ULTIMATE",
						                "IncludedFlags": [],
						                "productId": "dtvp200005",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "ULTIMATE",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000030",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 104,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 71.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 230,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-MAS-ULTRA",
						                "description": "MÁS ULTRA Package",
						                "prodLosgId": "dtv",
						                "longDescription": "More channels, movies and sports",
						                "childSkuId": "dtvs200015",
						                "displayName": "MÁS ULTRA",
						                "IncludedFlags": [],
						                "productId": "dtvp200015",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "MÁS ULTRA",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000038",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 169,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 136.99,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": null,
						              "Description": "DTV & Internet",
						              "dtvTotalChannels": 320,
						              "offerShortDisplayName": "DTV & Internet",
						              "dtv": {
						                "imageName": "DTV-LO-MAXIMO",
						                "description": "LO MAXIMO Package",
						                "prodLosgId": "dtv",
						                "longDescription": "The movie lover’s package",
						                "childSkuId": "dtvs200016",
						                "displayName": "LO MAXIMO",
						                "IncludedFlags": [],
						                "productId": "dtvp200016",
						                "bestfor": []
						              },
						              "iptv": null,
						              "omsOfferId": "1",
						              "DTVShortDisplayName": "LO MAXIMO",
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb6000040",
						              "totalChannels": null,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 0
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 6
						    },
						    "ShopFilterOffers-1": {
						      "filterDetails": {
						        "filterId": "1100001",
						        "name": "Special Offers for AT&T Wireless Customers",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 186.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450",
						                "description": "Over 550 channels and apps including HD premium channels for more movies, sports and original series",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U300 Package, plus HBO® and Cinemax® packages, The Sports Package, and more.",
						                "childSkuId": "uv120001",
						                "displayName": "AT&T U-verse U450",
						                "IncludedFlags": [],
						                "productId": "uv230002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190676",
						              "totalChannels": 550,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 127
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 154.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 470 channels and apps, The Movie Package, digital music and more",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U200 Package, plus The Movie Package - STARZ®, ENCORE®, SHOWTIME®, and more!",
						                "childSkuId": "uv30010",
						                "displayName": "AT&T U-verse U300",
						                "IncludedFlags": [],
						                "productId": "uv50013",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190672",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 95
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 139.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190668",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 134.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 470 channels and apps, The Movie Package, digital music and more",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U200 Package, plus The Movie Package - STARZ®, ENCORE®, SHOWTIME®, and more!",
						                "childSkuId": "uv30010",
						                "displayName": "AT&T U-verse U300",
						                "IncludedFlags": [],
						                "productId": "uv50013",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190670",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 95
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 94.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "Over 200 channels and apps including local programing",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-family channel line-up, including family-focused and local programming",
						                "childSkuId": "uv40004",
						                "displayName": "AT&T U-verse U-family",
						                "IncludedFlags": [],
						                "productId": "uv60004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190677",
						              "totalChannels": 200,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 65
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 124.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "Over 200 channels and apps including local programing",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-family channel line-up, including family-focused and local programming",
						                "childSkuId": "uv40004",
						                "displayName": "AT&T U-verse U-family",
						                "IncludedFlags": [],
						                "productId": "uv60004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190663",
						              "totalChannels": 200,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 65
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190666",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 109.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190664",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 166.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450",
						                "description": "Over 550 channels and apps including HD premium channels for more movies, sports and original series",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U300 Package, plus HBO® and Cinemax® packages, The Sports Package, and more.",
						                "childSkuId": "uv120001",
						                "displayName": "AT&T U-verse U450",
						                "IncludedFlags": [],
						                "productId": "uv230002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190674",
						              "totalChannels": 550,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 127
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 1
						    },
						    "ShopFilterOffers-0": {
						      "filterDetails": {
						        "filterId": "1100008",
						        "name": "Recommended For You",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700006",
						              "700009"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes <b>NFL and MLB Networks</b> plus <b>NBA TV</b> ",
						              "Includes more movies (<b>Showtime&#174; Unlimited, Starz&#174;, Encore&#174;, and more</b>), sports, and music channels than U200"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 154.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 470 channels and apps, The Movie Package, digital music and more",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U200 Package, plus The Movie Package - STARZ®, ENCORE®, SHOWTIME®, and more!",
						                "childSkuId": "uv30010",
						                "displayName": "AT&T U-verse U300",
						                "IncludedFlags": [],
						                "productId": "uv50013",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8040273",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 95
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700010",
						              "700007"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes everything in U-family , more news channels (<b>FOX</b>), and sports channels (<b>ESPN</b>)",
						              "More educational channels (<b>Animal planet, Discovery</b>) and kids channels (<b>Disney, Nickelodeon</b>)"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020301",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "200002"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Includes HBO® & Amazon Prime",
						            "additionalBundleFeatures": [
						              "Includes HBO®/HBO GO®"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 74.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "500001",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-basic",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ubasic",
						                "description": "Over 20 Channels - Locals only",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-basic channel lineup, including local programming",
						                "childSkuId": "sku4180240",
						                "displayName": "AT&T U-verse U-basic",
						                "IncludedFlags": [],
						                "productId": "prod4140221",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 non-DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15. For new residential U-verse customers. 12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term. After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8150701",
						              "totalChannels": 20,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 19
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700006",
						              "700009"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes <b>NFL and MLB Networks</b> plus <b>NBA TV</b> ",
						              "Includes more movies (<b>Showtime&#174; Unlimited, Starz&#174;, Encore&#174;, and more</b>), sports, and music channels than U200"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 134.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 470 channels and apps, The Movie Package, digital music and more",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U200 Package, plus The Movie Package - STARZ®, ENCORE®, SHOWTIME®, and more!",
						                "childSkuId": "uv30010",
						                "displayName": "AT&T U-verse U300",
						                "IncludedFlags": [],
						                "productId": "uv50013",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020299",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 95
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700001",
						              "700004"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "AT&T Wi-Fi Hot Spot access",
						              "Includes family-friendly channels (<b>Disney, Discovery, Sprout, Nick Jr.<b/>) "
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 94.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "Over 200 channels and apps including local programing",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-family channel line-up, including family-focused and local programming",
						                "childSkuId": "uv40004",
						                "displayName": "AT&T U-verse U-family",
						                "IncludedFlags": [],
						                "productId": "uv60004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020298",
						              "totalChannels": 200,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 65
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29,
						              "promoId": "23600082",
						              "displayName": "$29.00 off / 12mo.  1 yr term required. Other charges apply"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 105,
						            "lightGigRedirect": true,
						            "voipOfferPrice": 0,
						            "price": 185,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "1 Gbps",
						              "HSIAShortDisplayName": "Internet 1000",
						              "imageName": "ATT-Uverse-High-Speed-Internet-1G",
						              "description": "Up to 1 Gbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "AT&T U-verse High Speed Internet 1Gbps",
						              "childSkuId": "sku6980407",
						              "displayName": "AT&T U-verse High Speed Internet 1Gbps",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Our fastest speed ever for the ultimate online experience. Get super-fast streaming of movies and shows to all your devices at once."
						                }
						              ],
						              "productId": "prod7700245"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "U200TV + 1G",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "U200TV + 1G",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "<b> $150 U-verse with AT&T GigaPower Offer</b>: For res. customers in GigaPower areas  when ordered online at att.com. Price for U200 TV, and High Speed Internet 1Gbps. 1 year term req&#039;d. An ETF of up to $180 may apply if TV service is downgraded or disconnected before end of term. After 12 mos, std rates apply unless canceled by customer.  Must maintain qualifying services to receive advertised pricing. <b>AT&T Internet Preferences:</b> Requires customer to opt into AT&T Internet Preferences at time of original order. Go to att.com/InternetPreferences. If customer later opts out after service installation, std rates for service, equipment fees and other chrgs will apply. Offer ends  09/20/15. <br/><br/><b> AT&T U-verse</b>:  Credit restrictions may apply.  Promo pricing applies to service rates . Excl taxes, equip. fees and other chrgs, a $49 activation fee, federal regulatory video cost recovery chrg, city video cost recovery fees, and a Broadcast TV surcharge. Pricing, programming, features. sbj to change at any time without notice. <br/><br/><b> AT&T U-verse High Speed Internet 1Gbps</b>:  Internet speed claims represent maximum network service capability speeds. Actual customer speeds may vary and are not guaranteed. Actual speeds vary based on factors incl site traffic, content provider server capacity, internal network management factors, device capabilities and use of other U-verse services. Max speeds may not be realized if 2 or more HD shows viewed at same time. For more info, go to www.att.com/speed101.  Internet price incl 1TB of data/mo. $10 per addl 50GB. For more info, go to www.att.com/internet-usage. <br/><br/>Wi-Fi usage at home will count towards your High Speed Internet Service data plan. addl chrgs may apply for usage in excess of your data plan. <br/><br/>&#169; 2015 AT&T Intellectual Property. AT&T, the AT&T logo and all other AT&T marks contained herein are trademarks of AT&T Intellectual Property and/or AT&T affiliated companies. All rights reserved.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8210515",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false,
						              "isGigapowerOffer": true,
						              "optin": false,
						              "associatedOfferId": "prod8210515"
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29,
						              "promoId": "23600082",
						              "displayName": "$29.00 off / 12mo.  1 yr term required. Other charges apply"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 75,
						            "lightGigRedirect": true,
						            "voipOfferPrice": 0,
						            "price": 155,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "300 Mbps",
						              "HSIAShortDisplayName": "Internet 300",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia300",
						              "description": "Up to 300 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "AT&T U-verse High Speed Internet 300",
						              "childSkuId": "sku6880578",
						              "displayName": "AT&T U-verse High Speed Internet 300",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Blazing-fast downloads for superior streaming and high-performance gaming"
						                }
						              ],
						              "productId": "prod7610308"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200",
						              "Description": "U200TV + 300M",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "U200TV + 300M",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 360 of the most popular channels and apps, local programing and digital music",
						                "prodLosgId": "iptv",
						                "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
						                "childSkuId": "uv110001",
						                "displayName": "AT&T U-verse U200",
						                "IncludedFlags": [],
						                "productId": "uv50012",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "<b>$120 U-verse with AT&T GigaPower Offer</b>:  For res. customers in GigaPower areas when ordered online at att.com.   Price for U200 TV and High Speed Internet 300.   1 year term req&#039;d. An ETF of up to $180 may apply if TV service is downgraded or disconnected before end of term. After 12 mos, std rates apply unless canceled by customer.  Must maintain qualifying services to receive advertised pricing.  <b>AT&T Internet Preferences</b>:  Requires customer to opt into AT&T Internet Preferences at time of original order. Go to att.com/InternetPreferences. If customer later opts out after service installation, std rates for service, equipment fees and other chrgs will apply. Offer ends  09/20/15. <br/><br/><b>AT&T U-verse</b>:  Credit restrictions may apply.  Promo pricing applies to service rates . Excl taxes, equip. fees and other chrgs, a $49 activation fee, federal regulatory video cost recovery chrg, city video cost recovery fees, and a Broadcast TV surcharge. Pricing, programming, and features. sbj to change at any time without notice. <br/><br/><b>AT&T U-verse High Speed Internet 300</b>:  Internet speed claims represent maximum network service capability speeds. Actual customer speeds may vary and are not guaranteed. Actual speeds vary based on factors incl site traffic, content provider server capacity, internal network management factors, device capabilities and use of other U-verse services.  Max speeds may not be realized if 2 or more HD shows viewed at same time. For more info, go to www.att.com/speed101 . Internet price incl 500GB of data/mo. $10 per addl 50GB. For more info, go to www.att.com/internet-usage. <br/><br/>Wi-Fi usage at home will count towards your High Speed Internet Service data plan. addl chrgs may apply for usage in excess of your data plan. <br/><br/>&#169; 2015 AT&T Intellectual Property. AT&T, the AT&T logo and all other AT&T marks contained herein are trademarks of AT&T Intellectual Property and/or AT&T affiliated companies. All rights reserved.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8210511",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": false,
						              "isGigapowerOffer": true,
						              "optin": false,
						              "associatedOfferId": "prod8210511"
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 80
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "200002"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Includes HBO® & Amazon Prime",
						            "additionalBundleFeatures": [
						              "Includes HBO®/HBO GO®"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 94.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "200001",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-basic",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ubasic",
						                "description": "Over 20 Channels - Locals only",
						                "prodLosgId": "iptv",
						                "longDescription": "View U-basic channel lineup, including local programming",
						                "childSkuId": "sku4180240",
						                "displayName": "AT&T U-verse U-basic",
						                "IncludedFlags": [],
						                "productId": "prod4140221",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 non-DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers. 12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term. After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8200477",
						              "totalChannels": 20,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 19
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "700008",
						              "700005"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "<b>HBO® and Cinemax®</b> included at no extra charge ($26/mo. value!)",
						              "Access to <b>over 225 HD</b> channels included ($10/mo. value!) "
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 166.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450",
						                "description": "Over 550 channels and apps including HD premium channels for more movies, sports and original series",
						                "prodLosgId": "iptv",
						                "longDescription": "Includes everything in the U300 Package, plus HBO® and Cinemax® packages, The Sports Package, and more.",
						                "childSkuId": "uv120001",
						                "displayName": "AT&T U-verse U450",
						                "IncludedFlags": [],
						                "productId": "uv230002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020302",
						              "totalChannels": 550,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 127
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 0
						    },
						    "ShopFilterOffers-3": {
						      "filterDetails": {
						        "filterId": "F90004",
						        "name": "Recommended For You - Intro",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 184.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 490 channels including premium channels, HD channels, sports, and much more.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10005",
						                "displayName": "AT&T U-verse TV U450 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10005",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000033",
						              "totalChannels": 490,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 125
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 152.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 420 channels, including The Movie Package, digital music, and more",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10004",
						                "displayName": "AT&T U-verse TV U300 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000023",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 103
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 112.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "The best family-oriented channels, including popular childrens programming, learning channels, home-living networks, and 38 digital Music Choice channels that cover multiple genres.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10002",
						                "displayName": "AT&T U-verse TV U-Family All In",
						                "IncludedFlags": [],
						                "productId": "uvip10002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000006",
						              "totalChannels": 140,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 73
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 157.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 310 of the most popular digital channels, local programming and music channels.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10003",
						                "displayName": "AT&T U-verse TV U200 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000016",
						              "totalChannels": 310,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 88
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 122.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "The best family-oriented channels, including popular childrens programming, learning channels, home-living networks, and 38 digital Music Choice channels that cover multiple genres.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10002",
						                "displayName": "AT&T U-verse TV U-Family All In",
						                "IncludedFlags": [],
						                "productId": "uvip10002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000007",
						              "totalChannels": 140,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 73
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 194.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 490 channels including premium channels, HD channels, sports, and much more.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10005",
						                "displayName": "AT&T U-verse TV U450 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10005",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000034",
						              "totalChannels": 490,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 125
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 162.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 420 channels, including The Movie Package, digital music, and more",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10004",
						                "displayName": "AT&T U-verse TV U300 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000024",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 103
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 147.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 310 of the most popular digital channels, local programming and music channels.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10003",
						                "displayName": "AT&T U-verse TV U200 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000015",
						              "totalChannels": 310,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 88
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 172.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 420 channels, including The Movie Package, digital music, and more",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10004",
						                "displayName": "AT&T U-verse TV U300 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000025",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 103
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 3
						    },
						    "ShopFilterOffers-2": {
						      "filterDetails": {
						        "filterId": "99991",
						        "name": "Recommended For You",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-1": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 135.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300",
						                "description": "Over 420 channels, including The Movie Package, digital music, and more",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10004",
						                "displayName": "AT&T U-verse TV U300 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10004",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000015",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 103
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 120.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200",
						                "description": "Over 310 of the most popular digital channels, local programming and music channels.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10003",
						                "displayName": "AT&T U-verse TV U200 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10003",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000012",
						              "totalChannels": 310,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 88
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-4": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 95.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-family All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ufamily",
						                "description": "The best family-oriented channels, including popular childrens programming, learning channels, home-living networks, and 38 digital Music Choice channels that cover multiple genres.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10002",
						                "displayName": "AT&T U-verse TV U-Family All In",
						                "IncludedFlags": [],
						                "productId": "uvip10002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000009",
						              "totalChannels": 140,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 73
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 22.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 62.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20007",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "uvh20007"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U-basic All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-Ubasic",
						                "description": "Get local and U-verse information channels for the lowest U-verse TV price.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10001",
						                "displayName": "AT&T U-verse TV U-Basic All In",
						                "IncludedFlags": [],
						                "productId": "uvip10001",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 non-DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000057",
						              "totalChannels": 20,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 40
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 157.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 490 channels including premium channels, HD channels, sports, and much more.",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10005",
						                "displayName": "AT&T U-verse TV U450 All In",
						                "IncludedFlags": [],
						                "productId": "uvip10005",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000018",
						              "totalChannels": 490,
						              "voip": null,
						              "islatinoOffer": false
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 125
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 2
						    }
						  },
						  "wbfcResponse": {
						    "statusCode": 600,
						    "redirectURL": null,
						    "doRedirect": false,
						    "statusName": "Success"
						  },
						  "latinoShopFilterOffers": {
						    "ShopFilterOffers-1": {
						      "filterDetails": {
						        "filterId": "1100001",
						        "name": "Special Offers for AT&T Wireless Customers",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 166.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190711",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 134.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190710",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190712",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 144.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190718",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 129.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190714",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 196.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190724",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 176.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190722",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 149.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190716",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 17.05,
						              "promoId": "22500034",
						              "displayName": "Internet Discount for 12 mos w/o Bundle"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "400017"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $300 Reward Card",
						            "additionalBundleFeatures": [
						              "The convenience of one bill"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.95,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 164.95,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "400003",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190720",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": true,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 1
						    },
						    "ShopFilterOffers-0": {
						      "filterDetails": {
						        "filterId": "1100008",
						        "name": "Recommended For You",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100002"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes HD"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 176.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020311",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 166.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190705",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 134.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8190704",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 129.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020310",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 29.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 119.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "6 Mbps",
						              "HSIAShortDisplayName": "Elite",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
						              "description": "Up to 6 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
						              "childSkuId": "uv20029",
						              "displayName": "AT&T U-verse High Speed Internet Elite",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for surfing the web and email"
						                }
						              ],
						              "productId": "uv40056"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020309",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100002"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Includes HD"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 196.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 590 channels, including local programming and HD channels.",
						                "prodLosgId": "iptv",
						                "longDescription": "U450 Latino has all the great programming in U450 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360269",
						                "displayName": "AT&T U-verse U450 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270279",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8040280",
						              "totalChannels": 590,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 137
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 164.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8040279",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 149.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 420 channels, including Paquete Español, sports, entertainment, and more.",
						                "prodLosgId": "iptv",
						                "longDescription": "View U200 Latino channel line-up, including Paquete Español, sports, and more",
						                "childSkuId": "uv30009",
						                "displayName": "AT&T U-verse U200 Latino",
						                "IncludedFlags": [],
						                "productId": "uv210002",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020312",
						              "totalChannels": 420,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 90
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 150,
						              "longDescription": "$150 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 06/20/15.",
						              "displayName": "Receive a <b>$150 Reward Card</b> for ordering online today",
						              "cashBackId": "16200001",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 150,
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Plus $250 Reward Card",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 39.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 144.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "18 Mbps",
						              "HSIAShortDisplayName": "Max Plus",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
						              "description": "Up to 18 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "uv90019",
						              "displayName": "AT&T U-verse High Speed Internet Max Plus",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for streaming HD videos"
						                }
						              ],
						              "productId": "uv180041"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "100012",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino",
						              "Description": "Internet & TV",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "Internet & TV",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 520 channels, including: The Movie Package, digital music and local programming",
						                "prodLosgId": "iptv",
						                "longDescription": "U300 Latino has all the great programming in U300 as well as the channels in Paquete Español in one combined core TV package.",
						                "childSkuId": "sku5360265",
						                "displayName": "AT&T U-verse U300 Latino",
						                "IncludedFlags": [],
						                "productId": "prod5270278",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": "Bundle Price offers ends 6/20/15.  For new residential U-verse customers.  12 month term required.  An early termination fee of up to $180 may apply if TV service is disconnected before end of term.  After 12 months, standard rates apply unless cancelled by customer. Must maintain qualifying services for continued receipt of credits.",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "prod8020308",
						              "totalChannels": 520,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 105
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 0
						    },
						    "ShopFilterOffers-3": {
						      "filterDetails": {
						        "filterId": "F90004",
						        "name": "Recommended For You - Intro",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-8": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 184.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 540 channels including premium channels, HD channels, sports, and much more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10008",
						                "displayName": "AT&T U-verse TV U450 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10008",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000059",
						              "totalChannels": 540,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 135
						          },
						          "shopOfferOrderingIndex": 8
						        },
						        "OfferItem-7": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 162.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 470 channels, including The Movie Package, digital music, and more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10007",
						                "displayName": "AT&T U-verse TV U300 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000050",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 113
						          },
						          "shopOfferOrderingIndex": 7
						        },
						        "OfferItem-6": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 49.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 147.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "24 Mbps",
						              "HSIAShortDisplayName": "Max Turbo",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
						              "description": "Up to 24 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku3910251",
						              "displayName": "AT&T U-verse High Speed Internet Max Turbo",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for watching online movies"
						                }
						              ],
						              "productId": "prod3880267"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino All In ",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 360 of the most popular digital channels, local programming and music channels. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10006",
						                "displayName": "AT&T U-verse TV U200 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10006",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000041",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 98
						          },
						          "shopOfferOrderingIndex": 6
						        },
						        "OfferItem-1": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 182.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 470 channels, including The Movie Package, digital music, and more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10007",
						                "displayName": "AT&T U-verse TV U300 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000052",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 113
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 167.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino All In ",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 360 of the most popular digital channels, local programming and music channels. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10006",
						                "displayName": "AT&T U-verse TV U200 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10006",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000043",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 98
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-5": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 194.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 540 channels including premium channels, HD channels, sports, and much more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10008",
						                "displayName": "AT&T U-verse TV U450 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10008",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000060",
						              "totalChannels": 540,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 135
						          },
						          "shopOfferOrderingIndex": 5
						        },
						        "OfferItem-4": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 172.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 470 channels, including The Movie Package, digital music, and more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10007",
						                "displayName": "AT&T U-verse TV U300 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000051",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 113
						          },
						          "shopOfferOrderingIndex": 4
						        },
						        "OfferItem-3": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 59.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 157.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "45 Mbps",
						              "HSIAShortDisplayName": "Power",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Power",
						              "description": "Up to 45 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku5330254",
						              "displayName": "AT&T U-verse High Speed Internet Power",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod5240247"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino All In ",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 360 of the most popular digital channels, local programming and music channels. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10006",
						                "displayName": "AT&T U-verse TV U200 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10006",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000042",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 98
						          },
						          "shopOfferOrderingIndex": 3
						        },
						        "OfferItem-2": {
						          "cashBackRewards": [
						            {
						              "amount": 50,
						              "longDescription": "$50 AT&T U-verse Reward Card available to new U-verse residential customers ordering Basic Internet or higher and get Reward Cards for bundles purchased online at att.com by 06/20/15.",
						              "displayName": "Receive a <b>$50 Reward Card</b> for ordering online today",
						              "cashBackId": "15300098",
						              "rewardType": "cashback"
						            }
						          ],
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [
						            {
						              "description": "$ 17.5 for 12 months",
						              "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
						              "displayName": "$ 17.5 for 12 months",
						              "repositoryId": "ncpp1000017",
						              "packageCode": "XprodN_HSIA_17"
						            }
						          ],
						          "cashBackRewardTotal": 50,
						          "offer": {
						            "additionalBundleFeatureIDs": [],
						            "ipUsageItemDetails": null,
						            "ribbonText": null,
						            "additionalBundleFeatures": [],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 69.5,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 204.5,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 75.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
						              "childSkuId": "sku6880584",
						              "displayName": "AT&T U-verse High Speed Internet 75",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "prod7610305"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": null,
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 540 channels including premium channels, HD channels, sports, and much more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10008",
						                "displayName": "AT&T U-verse TV U450 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10008",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "1",
						              "DTVShortDisplayName": null,
						              "offerDetails": null,
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb4000061",
						              "totalChannels": 540,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 135
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 3
						    },
						    "ShopFilterOffers-2": {
						      "filterDetails": {
						        "filterId": "99991",
						        "name": "Recommended For You",
						        "requireIPTV": true,
						        "requireVOIP": false,
						        "requireHSIA": true
						      },
						      "offerItems": {
						        "OfferItem-1": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 145.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U300 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U300-Latino",
						                "description": "Over 470 channels, including The Movie Package, digital music, and more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10007",
						                "displayName": "AT&T U-verse TV U300 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10007",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000024",
						              "totalChannels": 470,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 113
						          },
						          "shopOfferOrderingIndex": 1
						        },
						        "OfferItem-0": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 130.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U200 Latino All In ",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U200-Latino",
						                "description": "Over 360 of the most popular digital channels, local programming and music channels. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10006",
						                "displayName": "AT&T U-verse TV U200 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10006",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000021",
						              "totalChannels": 360,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 98
						          },
						          "shopOfferOrderingIndex": 0
						        },
						        "OfferItem-2": {
						          "appliedJBDPromotions": [],
						          "appliedBasicPromotions": [
						            {
						              "amount": 20,
						              "promoId": "uvncp10002",
						              "displayName": "$20 off TV for 12 months"
						            },
						            {
						              "amount": 29.99,
						              "promoId": "uvncp10003",
						              "displayName": "$29.99 off for 12 months"
						            }
						          ],
						          "appliedCPPromotions": [],
						          "offer": {
						            "additionalBundleFeatureIDs": [
						              "100001"
						            ],
						            "ipUsageItemDetails": null,
						            "ribbonText": "Awesome Streaming TV",
						            "additionalBundleFeatures": [
						              "Add HBO®/Cinemax® and the first three months are on us!"
						            ],
						            "IncludeSpec": null,
						            "itemStatus": null,
						            "hsiaOfferPrice": 32.01,
						            "lightGigRedirect": false,
						            "voipOfferPrice": 0,
						            "price": 167.01,
						            "term": 12,
						            "hsia": {
						              "downloadSpeed": "75 Mbps",
						              "HSIAShortDisplayName": "75 All In",
						              "imageName": "ATT-Uverse-High-Speed-Internet-Hsia75",
						              "description": "Up to 75 Mbps download",
						              "prodLosgId": "hsia",
						              "longDescription": null,
						              "childSkuId": "uvhs20009",
						              "displayName": "AT&T U-verse High Speed Internet 75 All In",
						              "bestforOffer": [
						                {
						                  "description": null,
						                  "displayName": "Best for connecting multiple devices"
						                }
						              ],
						              "productId": "uvh20009"
						            },
						            "lastViewed": false,
						            "dtvOfferPrice": 0,
						            "ribbonTextID": "nc10002",
						            "offerItem": {
						              "IPTVShortDisplayName": "U450 Latino All In",
						              "Description": "TV & Internet",
						              "dtvTotalChannels": null,
						              "offerShortDisplayName": "TV & Internet",
						              "dtv": null,
						              "iptv": {
						                "imageName": "ATT-Uverse-U450-Latino",
						                "description": "Over 540 channels including premium channels, HD channels, sports, and much more. Includes Latino Channels",
						                "prodLosgId": "iptv",
						                "longDescription": null,
						                "childSkuId": "uvips10008",
						                "displayName": "AT&T U-verse TV U450 Latino All In",
						                "IncludedFlags": [],
						                "productId": "uvip10008",
						                "bestfor": [
						                  {
						                    "description": null,
						                    "displayName": "1 DVR receiver included"
						                  }
						                ]
						              },
						              "omsOfferId": "2000450",
						              "DTVShortDisplayName": null,
						              "offerDetails": "TV & Internet",
						              "ribbon": [],
						              "VOIPShortDisplayName": null,
						              "offerId": "pncb2000027",
						              "totalChannels": 540,
						              "voip": null,
						              "islatinoOffer": true
						            },
						            "convergedOffer": false,
						            "inCart": false,
						            "iptvOfferPrice": 135
						          },
						          "shopOfferOrderingIndex": 2
						        }
						      },
						      "shopFilterOrderingIndex": 2
						    }
						  },
						  "wtPkgOfferDetails": "prod8020298~Override~~~1|prod8020308~Override~~~2|prod8020299~Override~~~3|prod8020309~Override~~~4|prod8020302~Default~~~5|prod8020310~Default~~~6|prod8040279~Default~~~7|prod8200477~Default~~~8|prod8040280~Default~~~9|prod8210515~Default~~~10|prod8210511~Default~~~11|prod8020301~Default~~~12|prod8020312~Default~~~13|prod8020311~Default~~~14|prod8150701~Default~~~15|prod8040273~Default~~~16|prod8190704~Default~~~17|prod8040272~Default~~~18|prod8190705~Default~~~19|prod8040274~Default~~~20|prod8020305~Default~~~21|prod8020300~Default~~~22|prod8200557~Default~~~23|prod8200558~Default~~~24|prod8190629~Default~~~25|prod8190631~Default~~~26|prod8190632~Default~~~27|prod8190633~Default~~~28|prod8190634~Default~~~29|prod8190714~Override~~~30|prod8190677~Override~~~31|prod8190718~Override~~~32|prod8190670~Override~~~33|prod8190674~Default~~~34|prod8190720~Default~~~35|prod8190664~Default~~~36|prod8190724~Default~~~37|prod8190666~Default~~~38|prod8190716~Default~~~39|prod8190663~Default~~~40|prod8190722~Default~~~41|prod8190668~Default~~~42|prod8190712~Default~~~43|prod8190710~Default~~~44|prod8190672~Default~~~45|prod8190711~Default~~~46|prod8190676~Default~~~47|prod8190661~Default~~~48|prod8200559~Default~~~49|prod8200560~Default~~~50|prod8190660~Default~~~51|prod8190657~Default~~~52|prod8190658~Default~~~53|prod8190659~Default~~~54|pncb2000018~Default~~~55|pncb2000027~Default~~~56|pncb2000015~Default~~~57|pncb2000024~Default~~~58|pncb2000021~Default~~~59|pncb2000012~Default~~~60|pncb2000009~Default~~~61|pncb2000057~Default~~~62|pncb4000025~Default~~~63|pncb4000052~Default~~~64|pncb4000016~Default~~~65|pncb4000061~Default~~~66|pncb4000007~Default~~~67|pncb4000034~Default~~~68|pncb4000043~Default~~~69|pncb4000024~Default~~~70|pncb4000051~Default~~~71|pncb4000015~Default~~~72|pncb4000060~Default~~~73|pncb4000006~Default~~~74|pncb4000033~Default~~~75|pncb4000042~Default~~~76|pncb4000023~Default~~~77|pncb4000050~Default~~~78|pncb4000059~Default~~~79|pncb4000014~Default~~~80|pncb4000005~Default~~~81|pncb4000032~Default~~~82|pncb4000041~Default~~~83|pncb4000022~Default~~~84|pncb4000058~Default~~~85|pncb4000013~Default~~~86|pncb4000004~Default~~~87|pncb4000031~Default~~~88|pncb4000040~Default~~~89|pncb4000049~Default~~~90|pncb4000021~Default~~~91|pncb4000057~Default~~~92|pncb4000012~Default~~~93|pncb4000030~Default~~~94|pncb4000039~Default~~~95|pncb4000048~Default~~~96|pncb4000029~Default~~~97|pncb4000020~Default~~~98|pncb4000056~Default~~~99|pncb4000011~Default~~~100|pncb4000038~Default~~~101|pncb4000047~Default~~~102|pncb1000009~Default~~~103|pncb1000008~Default~~~104|pncb1000007~Default~~~105|pncb1000006~Default~~~106|pncb1000005~Default~~~107|pncb1000004~Default~~~108|pncb1000033~Default~~~109|pncb1000032~Default~~~110|pncb5000059~Default~~~111|pncb5000007~Default~~~112|pncb5000058~Default~~~113|pncb5000006~Default~~~114|pncb5000005~Default~~~115|pncb5000004~Default~~~116|pncb6000032~Default~~~117|pncb6000040~Default~~~118|pncb6000039~Default~~~119|pncb6000031~Default~~~120|pncb6000038~Default~~~121|pncb6000030~Default~~~122|pncb6000037~Default~~~123|pncb6000029~Default~~~124|pncb6000028~Default~~~125|pncb6000035~Default~~~126|pncb6000027~Default~~~127|pncb6000034~Default~~~128|pncb6000026~Default~~~129|pncb6000033~Default~~~130|pncb6000025~Default~~~131|pncb6000024~Default~~~132|pncb6000023~Default~~~133|pncb6000022~Default~~~134|pncb6000021~Default~~~135|pncb6000125~Default~~~136|pncb6000142~Default~~~137|pncb6000124~Default~~~138|pncb6000141~Default~~~139|pncb6000123~Default~~~140|pncb6000122~Default~~~141"
						} 
					},
					"premierdetails" : {"data": {
						  "0": {
							    "appliedJBDPromotions": [
							      {
							        "amount": 10,
							        "promoId": "jbdp10002",
							        "displayName": "Combined Bill Discount"
							      }
							    ],
							    "appliedBasicPromotions": [
							      {
							        "amount": 29,
							        "promoId": "23600082",
							        "displayName": "$29.00 off / 12mo.  1 yr term required. Other charges apply"
							      }
							    ],
							    "appliedCPPromotions": [],
							    "offer": {
							      "ipUsageItemDetails": null,
							      "ribbonText": null,
							      "additionalBundleFeatures": [],
							      "ipUsageShortDisplayName": null,
							      "bundleRackRate": 214,
							      "hsiaDataPerMonth": "w/XX",
							      "usedpackage": null,
							      "price": 185,
							      "iptvApplicableSpec": [
							        " <ul><li>Total Home DVR included </ul>",
							        "<strong>Plan Features</strong> </br> <ul> <li>100% digital crystal-clear picture and sound  <li>Access to over 215 HD channels - and  growing<sup>1</sup> <li>Record up to 4 shows at once with Total Home DVR® </ul><br/><br/><sup>1</sup>HD: Access to HD service requires $10/mo. Over 215 HD channels available with upgrade to U450 and HD Premium Tier."
							      ],
							      "term": 12,
							      "hsiaAvailabileSpec": [],
							      "usedoffer": null,
							      "hsia": {
							        "downloadSpeed": "1 Gbps",
							        "HSIAShortDisplayName": "Internet 1000",
							        "imageName": "ATT-Uverse-High-Speed-Internet-1G",
							        "description": "Up to 1 Gbps download",
							        "prodLosgId": "hsia",
							        "longDescription": "AT&T U-verse High Speed Internet 1Gbps",
							        "childSkuId": "sku6980407",
							        "displayName": "AT&T U-verse High Speed Internet 1Gbps",
							        "bestforOffer": [
							          {
							            "description": null,
							            "displayName": "Our fastest speed ever for the ultimate online experience. Get super-fast streaming of movies and shows to all your devices at once."
							          }
							        ],
							        "productId": "prod7700245"
							      },
							      "voipAvailableSpec": null,
							      "offerItem": {
							        "IPTVShortDisplayName": "U200",
							        "Description": "U200TV + 1G",
							        "dtvTotalChannels": null,
							        "offerShortDisplayName": "U200TV + 1G",
							        "dtv": null,
							        "iptv": {
							          "imageName": "ATT-Uverse-U200",
							          "description": "Over 360 of the most popular channels and apps, local programing and digital music",
							          "prodLosgId": "iptv",
							          "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
							          "childSkuId": "uv110001",
							          "displayName": "AT&T U-verse U200",
							          "bestforOffer": [
							            {
							              "description": null,
							              "displayName": "1 DVR receiver included"
							            }
							          ],
							          "productId": "uv50012"
							        },
							        "omsOfferId": "1",
							        "DTVShortDisplayName": null,
							        "offerDetails": "<b> $150 U-verse with AT&T GigaPower Offer</b>: For res. customers in GigaPower areas  when ordered online at att.com. Price for U200 TV, and High Speed Internet 1Gbps. 1 year term req&#039;d. An ETF of up to $180 may apply if TV service is downgraded or disconnected before end of term. After 12 mos, std rates apply unless canceled by customer.  Must maintain qualifying services to receive advertised pricing. <b>AT&T Internet Preferences:</b> Requires customer to opt into AT&T Internet Preferences at time of original order. Go to att.com/InternetPreferences. If customer later opts out after service installation, std rates for service, equipment fees and other chrgs will apply. Offer ends  09/20/15. <br/><br/><b> AT&T U-verse</b>:  Credit restrictions may apply.  Promo pricing applies to service rates . Excl taxes, equip. fees and other chrgs, a $49 activation fee, federal regulatory video cost recovery chrg, city video cost recovery fees, and a Broadcast TV surcharge. Pricing, programming, features. sbj to change at any time without notice. <br/><br/><b> AT&T U-verse High Speed Internet 1Gbps</b>:  Internet speed claims represent maximum network service capability speeds. Actual customer speeds may vary and are not guaranteed. Actual speeds vary based on factors incl site traffic, content provider server capacity, internal network management factors, device capabilities and use of other U-verse services. Max speeds may not be realized if 2 or more HD shows viewed at same time. For more info, go to www.att.com/speed101.  Internet price incl 1TB of data/mo. $10 per addl 50GB. For more info, go to www.att.com/internet-usage. <br/><br/>Wi-Fi usage at home will count towards your High Speed Internet Service data plan. addl chrgs may apply for usage in excess of your data plan. <br/><br/>&#169; 2015 AT&T Intellectual Property. AT&T, the AT&T logo and all other AT&T marks contained herein are trademarks of AT&T Intellectual Property and/or AT&T affiliated companies. All rights reserved.",
							        "VOIPShortDisplayName": null,
							        "offerId": "prod8210515",
							        "totalChannels": 360,
							        "voip": null,
							        "isGigapowerOffer": true,
							        "optin": true,
							        "associatedOfferId": "prod8210516"
							      },
							      "inCart": false,
							      "convergedOffer": false,
							      "dtvApplicableSpec": null
							    }
							  },
							  "wbfcResponse": {
							    "statusCode": 600,
							    "redirectURL": null,
							    "doRedirect": false,
							    "statusName": "Success"
							  }
						}
					},
					"standarddetails": {
						"data": {
							  "0": {
								    "appliedJBDPromotions": [
								      {
								        "amount": 10,
								        "promoId": "jbdp10002",
								        "displayName": "Combined Bill Discount"
								      }
								    ],
								    "appliedBasicPromotions": [
								      {
								        "amount": 29,
								        "promoId": "23600082",
								        "displayName": "$29.00 off / 12mo.  1 yr term required. Other charges apply"
								      }
								    ],
								    "appliedCPPromotions": [],
								    "offer": {
								      "ipUsageItemDetails": null,
								      "ribbonText": null,
								      "additionalBundleFeatures": [],
								      "ipUsageShortDisplayName": null,
								      "bundleRackRate": 214,
								      "hsiaDataPerMonth": "w/XX",
								      "usedpackage": null,
								      "price": 185,
								      "iptvApplicableSpec": [
								        " <ul><li>Total Home DVR included </ul>",
								        "<strong>Plan Features</strong> </br> <ul> <li>100% digital crystal-clear picture and sound  <li>Access to over 215 HD channels - and  growing<sup>1</sup> <li>Record up to 4 shows at once with Total Home DVR® </ul><br/><br/><sup>1</sup>HD: Access to HD service requires $10/mo. Over 215 HD channels available with upgrade to U450 and HD Premium Tier."
								      ],
								      "term": 12,
								      "hsiaAvailabileSpec": [],
								      "usedoffer": null,
								      "hsia": {
								        "downloadSpeed": "1 Gbps",
								        "HSIAShortDisplayName": "Internet 1000",
								        "imageName": "ATT-Uverse-High-Speed-Internet-1G",
								        "description": "Up to 1 Gbps download",
								        "prodLosgId": "hsia",
								        "longDescription": "AT&T U-verse High Speed Internet 1Gbps",
								        "childSkuId": "sku6980407",
								        "displayName": "AT&T U-verse High Speed Internet 1Gbps",
								        "bestforOffer": [
								          {
								            "description": null,
								            "displayName": "Our fastest speed ever for the ultimate online experience. Get super-fast streaming of movies and shows to all your devices at once."
								          }
								        ],
								        "productId": "prod7700245"
								      },
								      "voipAvailableSpec": null,
								      "offerItem": {
								        "IPTVShortDisplayName": "U200",
								        "Description": "U200TV + 1G",
								        "dtvTotalChannels": null,
								        "offerShortDisplayName": "U200TV + 1G",
								        "dtv": null,
								        "iptv": {
								          "imageName": "ATT-Uverse-U200",
								          "description": "Over 360 of the most popular channels and apps, local programing and digital music",
								          "prodLosgId": "iptv",
								          "longDescription": "Over 360 of the best general entertainment digital channels available. Includes ESPN, USA Network, TNT, and much more!",
								          "childSkuId": "uv110001",
								          "displayName": "AT&T U-verse U200",
								          "bestforOffer": [
								            {
								              "description": null,
								              "displayName": "1 DVR receiver included"
								            }
								          ],
								          "productId": "uv50012"
								        },
								        "omsOfferId": "1",
								        "DTVShortDisplayName": null,
								        "offerDetails": "<b> $150 U-verse with AT&T GigaPower Offer</b>: For res. customers in GigaPower areas  when ordered online at att.com. Price for U200 TV, and High Speed Internet 1Gbps. 1 year term req&#039;d. An ETF of up to $180 may apply if TV service is downgraded or disconnected before end of term. After 12 mos, std rates apply unless canceled by customer.  Must maintain qualifying services to receive advertised pricing. <b>AT&T Internet Preferences:</b> Requires customer to opt into AT&T Internet Preferences at time of original order. Go to att.com/InternetPreferences. If customer later opts out after service installation, std rates for service, equipment fees and other chrgs will apply. Offer ends  09/20/15. <br/><br/><b> AT&T U-verse</b>:  Credit restrictions may apply.  Promo pricing applies to service rates . Excl taxes, equip. fees and other chrgs, a $49 activation fee, federal regulatory video cost recovery chrg, city video cost recovery fees, and a Broadcast TV surcharge. Pricing, programming, features. sbj to change at any time without notice. <br/><br/><b> AT&T U-verse High Speed Internet 1Gbps</b>:  Internet speed claims represent maximum network service capability speeds. Actual customer speeds may vary and are not guaranteed. Actual speeds vary based on factors incl site traffic, content provider server capacity, internal network management factors, device capabilities and use of other U-verse services. Max speeds may not be realized if 2 or more HD shows viewed at same time. For more info, go to www.att.com/speed101.  Internet price incl 1TB of data/mo. $10 per addl 50GB. For more info, go to www.att.com/internet-usage. <br/><br/>Wi-Fi usage at home will count towards your High Speed Internet Service data plan. addl chrgs may apply for usage in excess of your data plan. <br/><br/>&#169; 2015 AT&T Intellectual Property. AT&T, the AT&T logo and all other AT&T marks contained herein are trademarks of AT&T Intellectual Property and/or AT&T affiliated companies. All rights reserved.",
								        "VOIPShortDisplayName": null,
								        "offerId": "prod8210515",
								        "totalChannels": 360,
								        "voip": null,
								        "isGigapowerOffer": true,
								        "optin": false,
								        "associatedOfferId": "prod8210515"
								      },
								      "inCart": false,
								      "convergedOffer": false,
								      "dtvApplicableSpec": null
								    }
								  },
								  "wbfcResponse": {
								    "statusCode": 600,
								    "redirectURL": null,
								    "doRedirect": false,
								    "statusName": "Success"
								  }
							}
					}
		};
		var byobJson={
			    "0": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [],
			        "promotionalText": "Internet Discount for 12 mos w/o Bundle",
			        "appliedCPPTokenName": "Long-Term Savings",
			        "appliedCPPTokenId": "100002",
			        "appliedCPPromotions": [
			            {
			                "description": "$ 17.5 for 12 months",
			                "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
			                "displayName": "$ 17.5 for 12 months",
			                "repositoryId": "ncpp1000017",
			                "packageCode": "XprodN_HSIA_17"
			            }
			        ],
			        "appliedCPPPackageCode": "XprodN_HSIA_17",
			        "offerProducts": {
			            "isAllInHsiaOffer": false,
			            "lightGigRedirect": false,
			            "promotionSavings": 17.5,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 64.5,
			            "price": 64.5,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Power",
			                "imageName": "ATT-Uverse-High-Speed-Internet-1G",
			                "description": "Up to 45 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 45.0 Mbps download.  This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
			                "image": "ATT-Uverse-High-Speed-Internet-Power",
			                "childSkuId": "sku5330254",
			                "displayName": "AT&T U-verse High Speed Internet Power",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "prod5240247",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for connecting multiple devices"
			                    }
			                ]
			            },
			            "isGigapowerOffer": true,
			            "optin": true,
			            "associatedOfferId": "prod1234567",
			            "hsiaDownloadSpeed": "1 Gbps",
			            "inCart": false
			        }
			    },
			    "1": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [
			            {
			                "amount": 29.99,
			                "promoId": "uvncp10003",
			                "displayName": "$29.99 off for 12 months"
			            }
			        ],
			        "promotionalText": "$29.99 off for 12 months",
			        "appliedCPPromotions": [],
			        "offerProducts": {
			            "isAllInHsiaOffer": true,
			            "lightGigRedirect": false,
			            "promotionSavings": 29.99,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 32.01,
			            "price": 32.01,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Power All In",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Power",
			                "description": "Up to 45 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": null,
			                "image": "ATT-Uverse-High-Speed-Internet-Power",
			                "childSkuId": "uvhs20008",
			                "displayName": "AT&T U-verse High Speed Internet Power All In",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uvh20008",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for connecting multiple devices"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "45 Mbps",
			            "inCart": false
			        }
			    },
			    "2": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [],
			        "promotionalText": "Internet Discount for 12 mos w/o Bundle",
			        "appliedCPPTokenName": "Long-Term Savings",
			        "appliedCPPTokenId": "100002",
			        "appliedCPPromotions": [
			            {
			                "description": "$ 17.5 for 12 months",
			                "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
			                "displayName": "$ 17.5 for 12 months",
			                "repositoryId": "ncpp1000017",
			                "packageCode": "XprodN_HSIA_17"
			            }
			        ],
			        "appliedCPPPackageCode": "XprodN_HSIA_17",
			        "offerProducts": {
			            "isAllInHsiaOffer": false,
			            "lightGigRedirect": false,
			            "promotionSavings": 17.5,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 54.5,
			            "price": 54.5,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Max Turbo",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
			                "description": "Up to 24 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download.  This lightening fast speed is perfect for  video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
			                "image": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
			                "childSkuId": "sku3910251",
			                "displayName": "AT&T U-verse High Speed Internet Max Turbo",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "prod3880267",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for watching online movies"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "24 Mbps",
			            "inCart": false
			        }
			    },
			    "3": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [
			            {
			                "amount": 29.99,
			                "promoId": "uvncp10003",
			                "displayName": "$29.99 off for 12 months"
			            }
			        ],
			        "promotionalText": "$29.99 off for 12 months",
			        "appliedCPPromotions": [],
			        "offerProducts": {
			            "isAllInHsiaOffer": true,
			            "lightGigRedirect": false,
			            "promotionSavings": 29.99,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 22.01,
			            "price": 22.01,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Max Turbo All In",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
			                "description": "Up to 24 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": null,
			                "image": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
			                "childSkuId": "uvhs20007",
			                "displayName": "AT&T U-verse High Speed Internet Max Turbo All In",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uvh20007",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for watching online movies"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "24 Mbps",
			            "inCart": false
			        }
			    },
			    "4": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [],
			        "promotionalText": "Internet Discount for 12 mos w/o Bundle",
			        "appliedCPPTokenName": "Long-Term Savings",
			        "appliedCPPTokenId": "100002",
			        "appliedCPPromotions": [
			            {
			                "description": "$ 17.5 for 12 months",
			                "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
			                "displayName": "$ 17.5 for 12 months",
			                "repositoryId": "ncpp1000017",
			                "packageCode": "XprodN_HSIA_17"
			            }
			        ],
			        "appliedCPPPackageCode": "XprodN_HSIA_17",
			        "offerProducts": {
			            "isAllInHsiaOffer": false,
			            "lightGigRedirect": false,
			            "promotionSavings": 17.5,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 44.5,
			            "price": 44.5,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Max Plus",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
			                "description": "Up to 18 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": "This is serious speed for serious Internet Users.  One dynamic IP address at up to 18.0 Mbps download.   Perfect for downloading multimedia files like movies and music or uploading huge files. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
			                "image": "ATT-Uverse-High-Speed-Internet-Max-Plus",
			                "childSkuId": "uv90019",
			                "displayName": "AT&T U-verse High Speed Internet Max Plus",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uv180041",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for streaming HD videos"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "18 Mbps",
			            "inCart": false
			        }
			    },
			    "5": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [
			            {
			                "amount": 29.99,
			                "promoId": "uvncp10003",
			                "displayName": "$29.99 off for 12 months"
			            }
			        ],
			        "promotionalText": "$29.99 off for 12 months",
			        "appliedCPPromotions": [],
			        "offerProducts": {
			            "isAllInHsiaOffer": true,
			            "lightGigRedirect": false,
			            "promotionSavings": 29.99,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 22.01,
			            "price": 22.01,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Max Plus All In",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Max-Plus",
			                "description": "Up to 18 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": null,
			                "image": "ATT-Uverse-High-Speed-Internet-Max-Plus",
			                "childSkuId": "uvhs20006",
			                "displayName": "AT&T U-verse High Speed Internet Max Plus All In",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uvh20006",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for streaming HD videos"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "18 Mbps",
			            "inCart": false
			        }
			    },
			    "6": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [],
			        "promotionalText": "Internet Discount for 12 mos w/o Bundle",
			        "appliedCPPTokenName": "Long-Term Savings",
			        "appliedCPPTokenId": "100002",
			        "appliedCPPromotions": [
			            {
			                "description": "$ 17.5 for 12 months",
			                "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
			                "displayName": "$ 17.5 for 12 months",
			                "repositoryId": "ncpp1000017",
			                "packageCode": "XprodN_HSIA_17"
			            }
			        ],
			        "appliedCPPPackageCode": "XprodN_HSIA_17",
			        "offerProducts": {
			            "isAllInHsiaOffer": false,
			            "lightGigRedirect": false,
			            "promotionSavings": 17.5,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 39.5,
			            "price": 39.5,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Max",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Max",
			                "description": "Up to 12 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": "Max is ideal for active Internet users. One dynamic IP address at up to 12.0 Mbps download. Max is perfect for active gamers, people who share photos, music lovers and other sophisticated Internet users who need speed. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
			                "image": "ATT-Uverse-High-Speed-Internet-Max",
			                "childSkuId": "uv20030",
			                "displayName": "AT&T U-verse High Speed Internet Max",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uv40057",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for downloading music"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "12 Mbps",
			            "inCart": false
			        }
			    },
			    "7": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [
			            {
			                "amount": 29.99,
			                "promoId": "uvncp10003",
			                "displayName": "$29.99 off for 12 months"
			            }
			        ],
			        "promotionalText": "$29.99 off for 12 months",
			        "appliedCPPromotions": [],
			        "offerProducts": {
			            "isAllInHsiaOffer": true,
			            "lightGigRedirect": false,
			            "promotionSavings": 29.99,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 22.01,
			            "price": 22.01,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Max All In",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Max",
			                "description": "Up to 12 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": null,
			                "image": "ATT-Uverse-High-Speed-Internet-Max",
			                "childSkuId": "uvhs20005",
			                "displayName": "AT&T U-verse High Speed Internet Max All In",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uvh20005",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for downloading music"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "12 Mbps",
			            "inCart": false
			        }
			    },
			    "8": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [],
			        "promotionalText": "Internet Discount for 12 mos w/o Bundle",
			        "appliedCPPTokenName": "Long-Term Savings",
			        "appliedCPPTokenId": "100002",
			        "appliedCPPromotions": [
			            {
			                "description": "$ 17.5 for 12 months",
			                "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
			                "displayName": "$ 17.5 for 12 months",
			                "repositoryId": "ncpp1000017",
			                "packageCode": "XprodN_HSIA_17"
			            }
			        ],
			        "appliedCPPPackageCode": "XprodN_HSIA_17",
			        "offerProducts": {
			            "isAllInHsiaOffer": false,
			            "lightGigRedirect": false,
			            "promotionSavings": 17.5,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 34.5,
			            "price": 34.5,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Elite",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
			                "description": "Up to 6 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": "Elite is super fast with one dynamic IP address at up to 6.0 Mbps download.  Whether you're a gamer or a business owner, it's perfect for you, supporting multiple-users, high-resolution graphics, large attachment uploads, desktop video, and even hosting a website! No matter where you want to go with your Internet connection, Elite will get you there faster. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
			                "image": "ATT-Uverse-High-Speed-Internet-Elite",
			                "childSkuId": "uv20029",
			                "displayName": "AT&T U-verse High Speed Internet Elite",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uv40056",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for surfing the web and email"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "6 Mbps",
			            "inCart": false
			        }
			    },
			    "9": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [],
			        "appliedCPPromotions": [],
			        "offerProducts": {
			            "isAllInHsiaOffer": true,
			            "lightGigRedirect": false,
			            "promotionSavings": 0,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 42,
			            "price": 42,
			            "term": 9999,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Elite All In",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Elite",
			                "description": "Up to 6 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": null,
			                "image": "ATT-Uverse-High-Speed-Internet-Elite",
			                "childSkuId": "uvhs20004",
			                "displayName": "AT&T U-verse High Speed Internet Elite All In",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uvh20004",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for surfing the web and email"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "6 Mbps",
			            "inCart": false
			        }
			    },
			    "10": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [],
			        "promotionalText": "Internet Discount for 12 mos w/o Bundle",
			        "appliedCPPTokenName": "Long-Term Savings",
			        "appliedCPPTokenId": "100002",
			        "appliedCPPromotions": [
			            {
			                "description": "$ 17.5 for 12 months",
			                "longDescription": "Buy Now High speed Internet Intro, get $17.5 off /12 mo.",
			                "displayName": "$ 17.5 for 12 months",
			                "repositoryId": "ncpp1000017",
			                "packageCode": "XprodN_HSIA_17"
			            }
			        ],
			        "appliedCPPPackageCode": "XprodN_HSIA_17",
			        "offerProducts": {
			            "isAllInHsiaOffer": false,
			            "lightGigRedirect": false,
			            "promotionSavings": 17.5,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 29.5,
			            "price": 29.5,
			            "term": 12,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Pro",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Pro",
			                "description": "Up to 3 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": "Recommended for its low price and great speed! Designed for simultaneous web surfing, email, animation-rich commerce, audio and video streaming, gaming on demand, uploading and downloading large files, and other bandwidth intensive applications. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more from AT&T.",
			                "image": "ATT-Uverse-High-Speed-Internet-Pro",
			                "childSkuId": "uv20031",
			                "displayName": "AT&T U-verse High Speed Internet Pro",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uv40055",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for sharing information"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "3 Mbps",
			            "inCart": false
			        }
			    },
			    "11": {
			        "disableHSIAOfferForVOIPPlan": false,
			        "appliedBasicPromotions": [],
			        "appliedCPPromotions": [],
			        "offerProducts": {
			            "isAllInHsiaOffer": true,
			            "lightGigRedirect": false,
			            "promotionSavings": 0,
			            "ipUsageItemDetails": null,
			            "hsiaStartPrice": 42,
			            "price": 42,
			            "term": 9999,
			            "isLatinoProduct": null,
			            "itemStatus": null,
			            "productItem": {
			                "shortDisplayName": "Pro All In",
			                "imageName": "ATT-Uverse-High-Speed-Internet-Pro",
			                "description": "Up to 3 Mbps download",
			                "prodLosgId": "hsia",
			                "longDescription": null,
			                "image": "ATT-Uverse-High-Speed-Internet-Pro",
			                "childSkuId": "uvhs20003",
			                "displayName": "AT&T U-verse High Speed Internet Pro All In",
			                "chargeType": "mrc",
			                "IncludedFlags": [],
			                "productId": "uvh20003",
			                "bestfor": [
			                    {
			                        "description": null,
			                        "displayName": "Best for sharing information"
			                    }
			                ]
			            },
			            "hsiaDownloadSpeed": "3 Mbps",
			            "inCart": false
			        }
			    },
			    "wbfcResponse": {
			        "statusCode": 600,
			        "redirectURL": null,
			        "doRedirect": false,
			        "statusName": "Success"
			    }
			};
		var byobCompareModalJson={
				"offerItems": {
					"2": {
					"cashBackRewards": [{
					"amount": 350,
					"longDescription": "$350 AT&T U-verse Reward Card available to new U-verse residential customers for minimum purchase of U-Family TV, U-verse Internet Pro and any WLS. Offer ends 08/8/15.",
					"displayName": "$350 Reward Card for ordering online.",
					"cashBackId": "6700018",
					"rewardType": "cashback"
					}],
					"appliedBasicPromotions": [],
					"appliedCPPTokenName": "AT&T Promotion Cards",
					"appliedCPPTokenId": "100001",
					"appliedCPPromotions": [],
					"appliedCPPPackageCode": "XProd300Visa_09",
					"xppId": "prod5370270",
					"cashBackRewardTotal": 350,
					"offerProducts": {
					"DTVItem": null,
					"promotionSavings": 5,
					"price": 194,
					"term": 9999,
					"optin":false,
					"gigaPowerOffer":true,
					"associatedOfferId":"prod8210521",
					"HSIAItem": {
					"ipUsageItemDetails": null,
					"hsiaStartPrice": null,
					"imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
					"prodLosgId": "hsia",
					"image": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
					"bestfor": [{
					"description": null,
					"displayName": "Best for watching online movies"
					}],
					"productId": "prod3880267",
					"isAllInHsiaOffer": false,
					"shortDisplayName": "Max Turbo",
					"lightGigRedirect": null,
					"downloadSpeed": "24 Mbps",
					"description": "Up to 24 Mbps download",
					"longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download. This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
					"childSkuId": "sku3910251",
					"displayName": "AT&T U-verse High Speed Internet Max Turbo",
					"chargeType": "mrc"
					},
					"IPTVItem": {
					"imageName": "ATT-Uverse-U450",
					"iptvStartPrice": null,
					"prodLosgId": "iptv",
					"image": "ATT-Uverse-U450",
					"isAllInTvOffer": false,
					"bestfor": [{
					"description": null,
					"displayName": "1 DVR receiver included"
					}],
					"productId": "uv230002",
					"shortDisplayName": "U450",
					"description": "Over 550 channels and apps including HD premium channels for more movies, sports and original series",
					"longDescription": "Includes everything in the U300 Package, plus HBO³ and Cinemax³ packages, The Sports Package, and more.",
					"isLatinoProduct": false,
					"childSkuId": "uv120001",
					"displayName": "AT&T U-verse U450",
					"chargeType": "mrc",
					"totalChannels": 550
					},
					"inCart": true,
					"VOIPItem": null
					}
					},
					"1": {
					"cashBackRewards": [{
					"amount": 350,
					"longDescription": "$350 AT&T Visa³ Reward Card available to new U-verse residential customers for minimum purchase of U-family TV and U-verse Internet Pro online at att.com. Offer ends 08/8/15.",
					"displayName": "$350 Reward Card for ordering online.",
					"cashBackId": "16100006",
					"rewardType": "cashback"
					}],
					"appliedBasicPromotions": [],
					"appliedCPPTokenName": "AT&T Promotion Cards",
					"appliedCPPTokenId": "100001",
					"appliedCPPromotions": [],
					"appliedCPPPackageCode": "XProd200Visa_12",
					"xppId": "prod5370237",
					"cashBackRewardTotal": 350,
					"offerProducts": {
					"DTVItem": null,
					"promotionSavings": 5,
					"price": 194,
					"term": 9999,
					"optin":false,
					"gigaPowerOffer":false,
					"associatedOfferId":"prod8210521",
					"HSIAItem": {
					"ipUsageItemDetails": null,
					"hsiaStartPrice": null,
					"imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
					"prodLosgId": "hsia",
					"image": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
					"bestfor": [{
					"description": null,
					"displayName": "Best for watching online movies"
					}],
					"productId": "prod3880267",
					"isAllInHsiaOffer": false,
					"shortDisplayName": "Max Turbo",
					"lightGigRedirect": null,
					"downloadSpeed": "24 Mbps",
					"description": "Up to 24 Mbps download",
					"longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download. This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
					"childSkuId": "sku3910251",
					"displayName": "AT&T U-verse High Speed Internet Max Turbo",
					"chargeType": "mrc"
					},
					"IPTVItem": {
					"imageName": "ATT-Uverse-U450",
					"iptvStartPrice": null,
					"prodLosgId": "iptv",
					"image": "ATT-Uverse-U450",
					"isAllInTvOffer": false,
					"bestfor": [{
					"description": null,
					"displayName": "1 DVR receiver included"
					}],
					"productId": "uv230002",
					"shortDisplayName": "U450",
					"description": "Over 550 channels and apps including HD premium channels for more movies, sports and original series",
					"longDescription": "Includes everything in the U300 Package, plus HBO³ and Cinemax³ packages, The Sports Package, and more.",
					"isLatinoProduct": false,
					"childSkuId": "uv120001",
					"displayName": "AT&T U-verse U450",
					"chargeType": "mrc",
					"totalChannels": 550
					},
					"inCart": false,
					"VOIPItem": null
					}
					},
					"0": {
					"cashBackRewards": [{
					"amount": 150,
					"longDescription": "$150 AT&T Visa³ Reward Card available to new U-verse residential customers for minimum purchase of U-family TV online at att.com. Offer ends 08/8/15.",
					"displayName": "Receive a <b>$150 Reward Card<\/b> for ordering online today",
					"cashBackId": "16200001",
					"rewardType": "cashback"
					}],
					"appliedBasicPromotions": [],
					"appliedCPPTokenName": "Long-Term Savings",
					"appliedCPPTokenId": "100002",
					"appliedCPPromotions": [{
					"description": "$84.01 off 12 mo. - 1 yr term required. Other charges apply",
					"longDescription": "Double U450 Power, National, $84.01 off 12 mo.",
					"displayName": "$84.01 off 12 mo. - 1 yr term required. Other charges apply",
					"repositoryId": "prod8330378",
					"packageCode": "XProdDPRC_67"
					}],
					"appliedCPPPackageCode": "XProdDPRC_67",
					"xppId": "prod8330378",
					"cashBackRewardTotal": 150,
					"offerProducts": {
					"DTVItem": null,
					"promotionSavings": 89.01,
					"price": 109.99,
					"term": 12,
					"optin":false,
					"gigaPowerOffer":false,
					"associatedOfferId":"prod8210521",
					"HSIAItem": {
					"ipUsageItemDetails": null,
					"hsiaStartPrice": null,
					"imageName": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
					"prodLosgId": "hsia",
					"image": "ATT-Uverse-High-Speed-Internet-Max-Turbo",
					"bestfor": [{
					"description": null,
					"displayName": "Best for watching online movies"
					}],
					"productId": "prod3880267",
					"isAllInHsiaOffer": false,
					"shortDisplayName": "Max Turbo",
					"lightGigRedirect": null,
					"downloadSpeed": "24 Mbps",
					"description": "Up to 24 Mbps download",
					"longDescription": "This is AT&T's top of the line service for individuals who demand the best - one dynamic IP address at our highest speed available up to 24.0 Mbps download. This lightening fast speed is perfect for video conferencing and downloading movies and music or uploading huge files in a flash. In addition, you'll also enjoy: online photo and video storage, up to 10 additional email accounts, pop-up blocker, and much more.",
					"childSkuId": "sku3910251",
					"displayName": "AT&T U-verse High Speed Internet Max Turbo",
					"chargeType": "mrc"
					},
					"IPTVItem": {
					"imageName": "ATT-Uverse-U450",
					"iptvStartPrice": null,
					"prodLosgId": "iptv",
					"image": "ATT-Uverse-U450",
					"isAllInTvOffer": false,
					"bestfor": [{
					"description": null,
					"displayName": "1 DVR receiver included"
					}],
					"productId": "uv230002",
					"shortDisplayName": "U450",
					"description": "Over 550 channels and apps including HD premium channels for more movies, sports and original series",
					"longDescription": "Includes everything in the U300 Package, plus HBO³ and Cinemax³ packages, The Sports Package, and more.",
					"isLatinoProduct": false,
					"childSkuId": "uv120001",
					"displayName": "AT&T U-verse U450",
					"chargeType": "mrc",
					"totalChannels": 550
					},
					"inCart": false,
					"VOIPItem": null
					}
					}
					},
					"wbfcResponse": {
					"statusCode": 600,
					"serviceErrors": [],
					"inputErrors": {},
					"doRedirect": false,
					"redirectURL": null,
					"statusName": "Success"
					}
};
		var vDeferred;
		var jsonRep = function (){};
		jsonRep.get = function (key){
            vDeferred = $q.defer();
			if(jsons.hasOwnProperty(key)){
				vDeferred.resolve(jsons[key]);
			}else{
				vDeferred.reject ('{}')
			}
			return (vDeferred.promise);
		};
		jsonRep.getbyob = function (){
            vDeferred = $q.defer();
				vDeferred.resolve(byobJson);
				return (vDeferred.promise);
		};
		jsonRep.byobCompareModal = function (){
            vDeferred = $q.defer();
			vDeferred.resolve(byobCompareModalJson);
			return (vDeferred.promise);
		};
		return jsonRep;
	});
})();