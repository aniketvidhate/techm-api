(function () {
    'use strict';
	
    angular.module('threeUp', [])

    .controller('ThreeUpCtrl', ['$scope', '$window', function ($scope, $window) {

        if (($window.sessionStorage.getItem('companyName')) && ($window.sessionStorage.getItem('iRUFanNumber'))) {
            angular.element('#premierBanner').show();
            angular.element('#premierBanner').removeAttr('style');
            angular.element('#ge5p_z1').hide();
            angular.element('#ge5p_z2').hide();
            angular.element('.undernav').hide();
            angular.element('#ge5p_z7').hide();
            $scope.isWireless = true;
		}
    }]);
}());
	