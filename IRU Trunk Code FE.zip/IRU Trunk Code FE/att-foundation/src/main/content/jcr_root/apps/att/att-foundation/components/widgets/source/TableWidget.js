/**
* @class MyClientLib.CustomPathFieldWidget
* @extends CQ.form.CompositeField
* This is a custom path field with a Link Text and a Link URL
* @param {Object} config the config object
*/
/**
* @class Ejst.CustomWidget
* @extends CQ.form.CompositeField
* This is a custom widget based on {@link CQ.form.CompositeField}.
* @constructor
* Creates a new CustomWidget.
* @param {Object} config The config object
*/

CQ.form.TableWidget = CQ.Ext.extend(CQ.form.CompositeField, {
	/**
	* @private
	* @type CQ.Ext.form.TextField
	*/
	hiddenField: null,
	/**
	* @private
	* @type CQ.Ext.form.TextField
	*/
//	accordianTitle: null,
	featureType: null,
	columnOne: null,
	columnTwo: null,
	columnThree: null,
	columnFour: null,
	
	/**
	* @private
	* @type CQ.form.RichText
	*/
//	accordianDesc: null,

	constructor: function (config) {
		config = config || {};
		var defaults = {
		    "border": true,
		    "labelWidth": 80,
		    "layout": "form",
		    "padding": 10,
		}; 

		config = CQ.Util.applyDefaults(config, defaults);
		CQ.form.TableWidget.superclass.constructor.call(this, config);
	},
	initComponent: function () {

	    CQ.form.TableWidget.superclass.initComponent.call(this);
	    // Hidden field
	    this.hiddenField = new CQ.Ext.form.Hidden({
	         name: this.name
	    });
	    this.add(this.hiddenField);

	// Text TextField to enter Title
	 /*   this.accordianTitle = new CQ.Ext.form.TextField({
	        cls: "customwidget-1",
	        maxLength: 300,
	        fieldLabel:'Title',
	        emptyText: "Accordian Title",
	        maxLengthText: "A maximum of 300 characters is allowed.",
	        width: 450,
	        allowBlank: true,
	        name : "item",
	        listeners: {
		        change: {
		        	scope: this,
				    fn: this.updateHidden
			    }
	        }
	    }); 
	    this.add(this.accordianTitle);*/
	    
	 // Text field to enter feature name
	    this.featureType = new CQ.form.RichText({
	        cls: "customwidget-1",
	        allowBlank: false,
	        fieldLabel:'Feature Type',
	        emptyText: "Feature Type",
	        width: 450,
	        listeners: {
		         change: {
		            scope: this,
		            fn: this.updateHidden
		        },
		        destroy: {
		            scope: this,
		            fn: this.featureTypeDestroy
		        }
	        }
	    }); 
	    this.add(this.featureType);
	    
	    // Text field to enter columnOne value
	    this.columnOne = new CQ.form.RichText({
	        cls: "customwidget-2",
	        allowBlank: true,
	        fieldLabel:'Column One',
	        emptyText: "Column One Value",
	        width: 450,
	        listeners: {
		         change: {
		            scope: this,
		            fn: this.updateHidden
		        },
		        destroy: {
		            scope: this,
		            fn: this.columnOneDestroy
		        }
	        }
	    }); 
	    this.add(this.columnOne);
	    
	    // Text field to enter columnTwo value
	    this.columnTwo = new CQ.form.RichText({
	        cls: "customwidget-3",
	        allowBlank: true,
	        fieldLabel:'Column Two',
	        emptyText: "Column Two Value",
	        width: 450,
	        listeners: {
		         change: {
		            scope: this,
		            fn: this.updateHidden
		        },
		        destroy: {
		            scope: this,
		            fn: this.columnTwoDestroy
		        }
	        }
	    }); 
	    this.add(this.columnTwo);
	    
	 // Text field to enter columnThree value
	    this.columnThree = new CQ.form.RichText({
	        cls: "customwidget-4",
	        allowBlank: true,
	        fieldLabel:'Column Three',
	        emptyText: "Column Three Value",
	        width: 450,
	        listeners: {
		         change: {
		            scope: this,
		            fn: this.updateHidden
		        },
		        destroy: {
		            scope: this,
		            fn: this.columnThreeDestroy
		        }
	        }
	    }); 
	    this.add(this.columnThree);
	    
	 // Text field to enter columnFour value
	    this.columnFour = new CQ.form.RichText({
	        cls: "customwidget-5",
	        allowBlank: true,
	        fieldLabel:'Column Four',
	        emptyText: "Column Four Value",
	        width: 450,
	        listeners: {
		         change: {
		            scope: this,
		            fn: this.updateHidden
		        },
		        destroy: {
		            scope: this,
		            fn: this.columnFourDestroy
		        }
	        }
	    }); 
	    this.add(this.columnFour);

	// Link PathField to map a URL
	 /* this.accordianDesc = new CQ.form.RichText({
	        cls: "customwidget-2",
	        allowBlank: true,
	        fieldLabel:'Description',
	        emptyText: "Accordian Description",
	        width: 450,
	        listeners: {
		         change: {
		            scope: this,
		            fn: this.updateHidden
		        },
		        destroy: {
		            scope: this,
		            fn: this.descDestroy
		        }
	        }
	    });

	    this.add(this.accordianDesc);*/
	},

	processInit: function (path, record) { 
	  //  this.accordianTitle.processInit(path, record);
	    this.featureType.processInit(path, record);
	    this.columnOne.processInit(path, record);
	    this.columnTwo.processInit(path, record);
	    this.columnThree.processInit(path, record);
	    this.columnFour.processInit(path, record);
	   // this.accordianDesc.processInit(path, record);
	},

	setValue: function (value) {
	    var link = JSON.parse(value);
	   // this.accordianTitle.setValue(link.title);
	    this.featureType.setValue(link.feature);
	    this.columnOne.setValue(link.columnOne);
	    this.columnTwo.setValue(link.columnTwo);
	    this.columnThree.setValue(link.columnThree);
	    this.columnFour.setValue(link.columnFour);
	    //this.accordianDesc.setValue(link.desc);
	},

	getValue: function () {
	    return this.getRawValue();
	},

	getRawValue: function () { 
	    var link = {
	    	"feature": this.featureType.getValue(),
	    	"columnOne": this.columnOne.getValue(),
	    	"columnTwo": this.columnTwo.getValue(),
	    	"columnThree": this.columnThree.getValue(),
	    	"columnFour": this.columnFour.getValue()
		//    "desc": this.accordianDesc.getValue(),
		//    "title": this.accordianTitle.getValue()
	    }; 
	    return JSON.stringify(link);
	},

	processValue: function(value) {        
        if ((value === undefined) || (value === null)) {
            value = "";
        }    
        // calling updateHidden() as change event not functioning for RTE widget
        this.updateHidden();
        return value;                  
    },

	updateHidden: function () {
		this.hiddenField.setValue(this.getValue());
	},
	
	featureTypeDestroy: function() {
	    this.featureType.el.dom = {};
	},
	
	columnOneDestroy: function() {
	    this.columnOne.el.dom = {};
	},
	
	columnTwoDestroy: function() {
	    this.columnTwo.el.dom = {};
	},
	
	columnThreeDestroy: function() {
	    this.columnThree.el.dom = {};
	},

	columnFourDestroy: function() {
	    this.columnFour.el.dom = {};
	}
});

CQ.Ext.reg("TableWidget", CQ.form.TableWidget);