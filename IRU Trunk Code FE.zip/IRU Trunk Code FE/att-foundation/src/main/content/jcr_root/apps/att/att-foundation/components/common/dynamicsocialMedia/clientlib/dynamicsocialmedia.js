var dynamicSocialMedia = (function ($) { 
    'use strict'; 
    return function (meteorCampaignKey, size, socialmediatext, orientation, hideFbid, stick) { 
        if (stick !== "") {
			$('div.socialMedia.dynamicsocialMedia').addClass(stick);
		}
		$.cachedScript = function (url) { 
			 return $.ajax({
	                        url: url,
	                        cache: true,
	                        crossDomain: true,
	                        dataType: 'script'
	                    });
        }; 

        $.cachedScript('//cdnt.meteorsolutions.com/metsol.js') 
            .done(function () { 
 				 $.cachedScript('//cdnt.meteorsolutions.com/metshare.js')
	                       .done(function() {
								meteor.tracking.track(meteorCampaignKey, { 'url_storage_source': 'local_storage_only', 'hide_hash_fbid': hideFbid, 'query_string_tag_key': ['mtag', 'source'] });
								meteor.sharing.configure(meteorCampaignKey);
								meteor.orion.init();

	                           var ShareToolConfig = {
	                              'id': '1',
	                            'parentID': 'socialMedia',
                                  'size': size,
                                 'sites': socialmediatext,
                                'orientation': orientation 
	                           };
	                           meteor.sharing.superbar.init(ShareToolConfig);
	                       });
            }); 
    }; 
}(jQuery));
