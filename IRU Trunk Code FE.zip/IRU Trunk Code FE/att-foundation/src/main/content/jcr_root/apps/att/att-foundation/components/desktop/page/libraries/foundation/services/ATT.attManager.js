// This module is being used in all wbfc flows.
// Do not make any change to it until you talk to Tong or Brodie.
// Date - 10/08/2015
// Version - 1.1

(function(){
	'use strict';
	
	angular.module('attManager', ['ngCookies','appConfig', 'util'])
	
	.run(function($window, $rootScope) {
		function _backupStorage() {
			return {
				setItem: function(key, val) {
					if (key !== "setItem" && key !== "getItem" && key !== "clear" && key !== "removeItem" && key !== "key") {
						this[key] = val;
					}
				},
				getItem: function(key) {
					return this[key];
				},
				clear: function() {
					var prop;
					for (prop in this) {
						if (this.hasOwnProperty(prop) && prop !== "setItem" && prop !== "getItem" && prop !== "clear" && prop !== "removeItem" && prop !== "key") {
							delete this[prop];
						}
					}
				},
				removeItem: function(key) {
					if (this.hasOwnProperty(key) && key !== "setItem" && key !== "getItem" && key !== "clear" && key !== "removeItem" && key !== "key") {
						delete this[key];
					}
				},
				key: function(idx) {
					var i = 0, prop;
					for (prop in this) {
						if (this.hasOwnProperty(prop) && prop !== "setItem" && prop !== "getItem" && prop !== "clear" && prop !== "removeItem" && prop !== "key") {
							if (i === idx) {
								return prop;
							}
							i++;
						}
					}
				}
			};
		}
		
		if (typeof $window.sessionStorage === "undefined") {
			$window.sessionStorage = _backupStorage();
			$rootScope.backUpStorageUsed = true;
		}
		if (typeof $window.localStorage === "undefined") {
			$window.localStorage = _backupStorage();
		}
	})

	.factory("Env", function ($window, $http, $q, $interval, $log, $rootScope, $cookies, $timeout, rest, appInfo, getQueryParam) {
		var services = {}, 
			vFlowType = appInfo.flowType,
			vDomain = '//' + $window.location.host,
			vContextRoot = '/services/shop', 
			vSessionExpireMinutes = 31,
			vSessionExpireWarningMinutes = 25,
			getSessNumAlready=false, 
			vDeferred=[], 
			defIndex=0,
			vIntervalWarning=null,
			vIntervalExpired=null,
			vSessionVarName = 'sales_sessionNumber',
			vSessionExpireTime = "sales_sessionExpireTime",
			vLocale='', 
			vLocaleName = 'sales_locale',
			vSessConfRestUrl = "/model/atg/rest/SessionConfirmationActor/getSessionConfirmationNumber";

		if ((rest.contextRoot != '') && (rest.contextRoot != undefined)) {
			vContextRoot = rest.contextRoot;
		}
		if ((rest.domain != '') && (rest.domain != undefined)) {
			vDomain = rest.domain;
		}
		if (appInfo.sessConfRestUrl !== undefined) {
			vSessConfRestUrl = appInfo.sessConfRestUrl;
		}	
		if (document.location.host.indexOf('localhost') > -1 ) {
			if ((rest.localCORS != '') && (rest.localCORS != undefined)) {
				vDomain = rest.localCORS;
			}
		}		
		
		function clearSessionNumber () {
			$window.localStorage.removeItem(vSessionVarName);
			$window.sessionStorage.removeItem(vSessionVarName);
		}
			
		function getLocale () {
			var locale = ($window.location.href.indexOf('/es/') > -1 || $window.location.href.indexOf('/es-us/') > -1) ? 'es' : 'en';
			return locale;
		}

		function resolveAllPromise (pSessionNumber) {
			var vDefer = null;
			while (vDeferred.length > 0) {
				vDefer = vDeferred.pop();
				vDefer.resolve(pSessionNumber);
			}
		}
		
		function getSessionNumber () {
			var _ts = new Date().getTime(), vDefer, v_sessionNumber = $window.sessionStorage.getItem(vSessionVarName);
			if (getSessNumAlready) {
				vDefer = $q.defer();
				vDeferred.push(vDefer);
				return vDefer.promise;
			} else if (v_sessionNumber == undefined) {
				getSessNumAlready = true;
				if ($window.localStorage.getItem(vSessionVarName) != undefined && _ts < parseInt($window.localStorage.getItem(vSessionExpireTime)) && $window.localStorage.getItem("sales_UserId") === $cookies.SALES_USER_ID) {
					getSessNumAlready = false;
					v_sessionNumber = $window.localStorage.getItem(vSessionVarName);
					$window.sessionStorage.setItem(vSessionVarName, v_sessionNumber);
					$window.sessionStorage.setItem("tvStoredDetails",$window.localStorage.getItem("tvStoredDetails"));
					checkLocale(v_sessionNumber);
					setSessionExpire(_ts);
					vDefer = $q.defer();
					vDefer.resolve(v_sessionNumber);
					return (vDefer.promise);					
				} else if ($window.location.href.indexOf("_dynSessConf=") > -1) {
					v_sessionNumber = $window.location.href.split("_dynSessConf=")[1];
					$window.sessionStorage.setItem(vSessionVarName, v_sessionNumber);
					checkLocale(v_sessionNumber);
					setSessionExpire(_ts);
					vDefer = $q.defer();
					vDefer.resolve(v_sessionNumber);					
					return (vDefer.promise);
				} else {
					return $http.get(vDomain + vContextRoot + vSessConfRestUrl, {withCredentials:true, params:{'_': _ts}}) 
						.then(function (httpData) {
							v_sessionNumber = httpData.data.sessionConfirmationNumber;
							checkLocale(v_sessionNumber);
							if (v_sessionNumber != undefined) {
								$window.sessionStorage.setItem(vSessionVarName, v_sessionNumber);
								$window.localStorage.setItem(vSessionVarName, v_sessionNumber);
								$timeout(function() {
										$window.localStorage.setItem("sales_UserId", $cookies.SALES_USER_ID);
									}, 110);
							}
							resolveAllPromise(v_sessionNumber);
							getSessNumAlready = false;
							return v_sessionNumber;
						})
						['catch'](function(httpData) {
							getSessNumAlready = false;
							resolveAllPromise(v_sessionNumber);
							return v_sessionNumber;
						});
				}
			} else {
				checkLocale(v_sessionNumber);
				setSessionExpire(_ts);
				vDefer = $q.defer();
				vDefer.resolve(v_sessionNumber);
				return (vDefer.promise);
			}
		} // end of getSessionNumber
		
		function getNewSession () {
			$window.sessionStorage.clear();
			getSessionNumber().then(function (httpData) {
				//console.log('timer, new session number:' + httpData);
				if (httpData !== null) {
					setSessionExpire();
				}
			});
		}
		
		function sessionExpiredReach () {
			if(!($window.location.href.indexOf("/shop/myuverse/sidecart") > -1)){
				$window.sessionStorage.clear();
				
				// clearing cookies related to authentication
	        	document.cookie = 'TATS-SS-TokenID' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.att.com';
	        	document.cookie = 'tutG' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.att.com';
	        	document.cookie = 'TG-PD-ID' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.att.com';
	        	document.cookie = 'tAuthNState' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.att.com';
	        	document.cookie = 'TATS-SS-TokenID' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.stage.att.com';
	        	document.cookie = 'tutG' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.stage.att.com';
	        	document.cookie = 'TG-PD-ID' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.stage.att.com';
	        	document.cookie = 'tAuthNState' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.stage.att.com';
	        	
	        	// clearing cookies related to Check availability
	        	document.cookie = 'CAAddressId' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.att.com';
	        	document.cookie = 'CAAddressId' + '=;Path=/;expires=Thu, 01 Jan 1970 00:00:01 GMT;domain=.stage.att.com';
	        	
				if (vIntervalExpired !== null) {
					$interval.cancel(vIntervalExpired);
				}
				$rootScope.$broadcast('SESSION_EXPIRE', {sessionExpireType:'expired'});
			}
		}
		
		function sessionWarnningReach () {
			if(!($window.location.href.indexOf("/shop/myuverse/sidecart") > -1)){
				if (vIntervalWarning !== null) {
					$interval.cancel(vIntervalWarning);
				}
				$rootScope.$broadcast('SESSION_EXPIRE', {sessionExpireType:'warning'});
			}
		}
				
		function getMillisecond (pMinutes) {
			var MillisecondLeng = pMinutes * 1000 * 60;
			return MillisecondLeng;
		}
		
		function setSessionExpire (_ts) {
			_ts = _ts || new Date().getTime();
			if (vIntervalWarning !== null) {
				$interval.cancel(vIntervalWarning);
			}
			if (vIntervalExpired !== null) {
				$interval.cancel(vIntervalExpired);
			}

			vIntervalWarning = $interval(sessionWarnningReach, getMillisecond(vSessionExpireWarningMinutes));
			vIntervalExpired = $interval(sessionExpiredReach, getMillisecond(vSessionExpireMinutes));
			$window.localStorage.setItem(vSessionExpireTime, _ts + getMillisecond(vSessionExpireMinutes));
		}

		function checkLocale(param) {
			var v_locale = getLocale(), vLocaleChange=false, url, vObj, sessionNumber, _ts;
			if (vLocale != v_locale) {
				vLocaleChange = true;
				vLocale = v_locale;
				$window.sessionStorage.setItem(vLocaleName, vLocale);
			} 

			if (vLocaleChange) {
				url = vDomain + vContextRoot + '/model/att/ecom/service/SwitchLocaleService/switchLocale';
				vObj = {};
				sessionNumber = param;
				_ts = new Date().getTime();
				vObj.withCredentials = true;
				vObj.params = {'_dynSessConf':sessionNumber, '_': _ts, 'locale':vLocale + '_US'};
				return $http.get(url, vObj);
			}		
		}
		
		function clearForReferral() {
			var dfd = $q.defer(),
				_ts = new Date().getTime(),
				frommyATT =  (getQueryParam("referral_app_id") === "myatt" ||  ($window.document.referrer != null && $window.document.referrer.indexOf("/olam/") > -1)) ;
			if ($window.location.href.indexOf("/shop/myuverse/referrals.html") > -1 && frommyATT && _ts >= parseInt($window.localStorage.getItem(vSessionExpireTime))) {
				$window.sessionStorage.clear();
				$window.localStorage.removeItem(vSessionExpireTime);
				dfd.resolve();
			} else {
				dfd.resolve();
			}
			return dfd.promise;
		}
		if (typeof $window.sessionStorage.getItem(vLocaleName) === "undefined") {
			vLocale = getLocale();
			$window.sessionStorage.setItem(vLocaleName, vLocale);
		} else {
			vLocale = $window.sessionStorage.getItem(vLocaleName);
		}
		
		clearForReferral().then(function(){
		getSessionNumber().then(function (httpData) {
			if (httpData !== null) {
				setSessionExpire();
			}
			checkLocale(httpData);
		})});
		
		services.sessionNumber = getSessionNumber;
		services.domain = vDomain;
		services.rest_context_root = vContextRoot;
		services.rest_base_url = vDomain + vContextRoot;
		services.locale = getLocale;
		services.resetSessionExpire = setSessionExpire;
		services.flowType = vFlowType;
		services.appInfo = appInfo;
		services.clearSessionNumber = clearSessionNumber;
		return services;
	})

	.factory("httpATT", function($http, Env, $rootScope, $window, attRedirect) {
		var domain = Env.rest_base_url, conflictCount = 0,
			services = function (obj) {
				var vObj = obj;
				vObj.withCredentials = true; 
				vObj.url = domain + vObj.url; 
				return Env.sessionNumber().then(function (httpData) {
					var sessionNumber = httpData, _ts = new Date().getTime();		
					vObj.params = {'_dynSessConf':sessionNumber, '_': _ts};
					return $http(vObj); 
				});
			};
		
		function checkRedirect (pParam) {
			if (pParam.data.wbfcResponse != undefined) {
				if (pParam.data.wbfcResponse.doRedirect == true) {
					if (pParam.data.wbfcResponse.redirectURL != null) {
						if (pParam.data.wbfcResponse.statusCode === 601) {
							attRedirect(pParam.data.wbfcResponse.redirectURL, true);
						} else {
							//For Move Integraiton project - before redirecting we have to show the Modal popup
							if ((Env.appInfo.noRedirect == false) || (Env.appInfo.noRedirect == undefined)) {
								attRedirect(pParam.data.wbfcResponse.redirectURL);
							}
						}	
					}
				}
			}
		}
		
		function getHTTP (pPath, pObj) {
			var url = domain + pPath, vObj = pObj || {};
			vObj.withCredentials = true;
			return Env.sessionNumber().then(function (httpData) {
				var sessionNumber = httpData, _ts = new Date().getTime();
				//Fix for security defect: do not pass session conf number as query string param
				//vObj.params = {'_dynSessConf':sessionNumber, '_': _ts};
				vObj.params = {'_': _ts};
				vObj.cache = false;
				return $http.get(url, vObj).then(function(successdata){
						$rootScope.$emit("ATT_REPORT_RESP", [successdata]);
						checkRedirect(successdata);
						conflictCount = 0;
						return successdata;
					},function(failuredata){
						$rootScope.$emit("ATT_REPORT_RESP", [failuredata]);
						if(failuredata.status == "409" && failuredata.data === 'Your session expired due to inactivity.') {
							Env.clearSessionNumber();
							$window.localStorage.removeItem("profileVisited");
							$window.localStorage.removeItem("profileVisitedLocal");
							conflictCount++;
							if(conflictCount > 10){
								$rootScope.$broadcast('SESSION_EXPIRE', {sessionExpireType:'expired'});
								conflictCount = 0;
								return failuredata;
							} else {
								return getHTTP(pPath, pObj);
							}
						}
				});
				
			});
		};

		function postHTTP (pPath, pData, pObj) {
			var url = domain + pPath, vObj = pObj || {};
			vObj.withCredentials = true;
			return Env.sessionNumber().then(function (httpData) {
				var sessionNumber = httpData, _ts = new Date().getTime();
				vObj.params = {'_dynSessConf':sessionNumber, '_': _ts}; 
				return $http.post(url, pData, vObj).then(function(successdata){
					$rootScope.$emit("ATT_REPORT_RESP", [successdata]);
					checkRedirect(successdata);
					conflictCount = 0;
					return successdata;
				},function(failuredata){
					$rootScope.$emit("ATT_REPORT_RESP", [failuredata]);
					if(failuredata.status == "409" && failuredata.data === 'Your session expired due to inactivity.') {
						Env.clearSessionNumber();
						$window.localStorage.removeItem("profileVisited");
						$window.localStorage.removeItem("profileVisitedLocal");
						conflictCount++;
						if(conflictCount > 10){
							$rootScope.$broadcast('SESSION_EXPIRE', {sessionExpireType:'expired'});
							conflictCount = 0;
							return failuredata;
						} else {
							return postHTTP(pPath, pData, pObj);
						}
					}
				});
				
			});
		};
		
		services.get = getHTTP;
		services.post = postHTTP;
		return services;
	})
	
	.factory("attRedirect", function($window, $rootScope, Env){
		return function(path, passAlongQueryParams) {
			passAlongQueryParams = passAlongQueryParams || false;
			if ($rootScope.backUpStorageUsed) {
				return function(path) {
					if (path.indexOf("?") > -1) {
						path += "&_dynSessConf="+Env.sessionNumber() + '&locale=' + Env.locale();
					} else {
						path += "?_dynSessConf="+Env.sessionNumber() + '&locale=' + Env.locale();
					}
					$window.location.href = path;
				};
			} else {
				if (passAlongQueryParams) {
					if (path.indexOf("?") > -1) {
						path += "&"+$window.location.search.substring(1,$window.location.search.length);
					} else {
						path += $window.location.search;
					}
				}
				if ($window.location.search.indexOf('wcmmode=disabled') > -1) {
					path += (path.indexOf("?") > -1) ? "&wcmmode=disabled" : "?wcmmode=disabled";
				}
				$window.location.href = path;
			}
		};
	})
	.factory("attReload", function($window){ //GP Migration - Used to reload page
		return function(){
			$window.location.reload();
		};
	});
	
})();
