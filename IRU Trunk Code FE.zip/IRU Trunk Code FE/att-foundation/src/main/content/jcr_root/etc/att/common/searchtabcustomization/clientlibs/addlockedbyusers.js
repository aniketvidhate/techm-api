CQ.Ext.ns("AddLockedByUserClientLib");
console.log("HI");
AddLockedByUserClientLib.SiteAdminSearchPanel = {
    SA_SEARCH_PANEL_LB: 'cq-addlockedbyuserclientlib-searchpanel-locked-by',
    SA_SEARCH_PANEL_SEARCH: "cq-siteadminsearchpanel-search",
    SA_SEARCH_PANEL_GRID: "cq-siteadminsearchpanel-grid",
    SA_SEARCH_PANEL: "cq-siteadminsearchpanel",
 
    addLockedBy: function(){
        var panel = CQ.Ext.getCmp(this.SA_SEARCH_PANEL_SEARCH);
 
        var defaults = {
            "predicateName":"property",
            "propertyName":"jcr:content/jcr:lockOwner"
        };
 
        var id = CQ.wcm.PredicateBase.createId(defaults.predicateName);
 
        panel.add(new CQ.Ext.form.Hidden({
            "name": id,
            "value": defaults.propertyName
        }));
 
        var aCombo = new CQ.Ext.form.Checkbox({
            id: this.SA_SEARCH_PANEL_LB,
			"name": id + ".value",
            "anchor": "100%",
            "valueField" : "id",
            "displayField" : "name",
            "fieldLabel": CQ.I18n.getMessage("Locked By User"),
            "filter" : "users",
            "autoSelect" : false,
            "inputValue" :CQ.User.getCurrentUser().getUserID()
        });
 
        panel.add(aCombo);
        panel.doLayout();
 
       // var sPanel = CQ.Ext.getCmp(this.SA_SEARCH_PANEL);
        //sPanel.reloadPages();
    }
};
 
(function(){
    if(window.location.pathname.indexOf("/siteadmin") >-1){
        var s = AddLockedByUserClientLib.SiteAdminSearchPanel;

        CQ.Ext.override(CQ.wcm.SiteAdminSearchPanel, {
            reloadPages: function(){
                this.performReset();
 
                var lockedBy = CQ.Ext.getCmp(s.SA_SEARCH_PANEL_LB);
 
                if(lockedBy){
                    //CQ.shared.User.data["userID"]
                    lockedBy.setValue(CQ.User.getCurrentUser().getUserID());
                    this.performSearch();
                }
            }
        });

        var INTERVAL = setInterval(function(){
            var grid = CQ.Ext.getCmp(s.SA_SEARCH_PANEL_GRID);
 
            if(grid && (grid.rendered == true)){
                clearInterval(INTERVAL);
                s.addLockedBy();
            }
        }, 250);
    }
})();