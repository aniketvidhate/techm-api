package com.att.sapmp.apigw.mdmauthtoken.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.mdmauthtoken.exception.CErrorDefs;
import com.att.sapmp.apigw.mdmauthtoken.exception.MdmAuthTokenException;

import io.swagger.annotations.ApiModel;

/**
 * @author pg238s
 *
 */
@ApiModel(value = "RequestProcessor", description = "RequestProcessor for incoming request from camel route")
@Component
public class RequestProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(RequestProcessor.class);
	@Value("${IBM_authTokenURL}")
	private String authTokenUrl;
	
	@Value("${IBM_userName}")
	private String userName;
	
	@Value("${IBM_password}")
	private String userPassword;
	
	@Autowired
	InitializationService is;

	public final void initializeHeader(Exchange e) throws MdmAuthTokenException {

		try {
			
			String stIBMAuthTokenUrlFinal = "";
			StringBuilder stIBMAuthTokenUrlBase = new StringBuilder(authTokenUrl);
			

			HashMap<String, Object> hmRequestList = InitializationService.getRequestparammap();

			String stBillingId = is.getBillingId();

			if (stBillingId == null || stBillingId.isEmpty()) {

				throw new MdmAuthTokenException(CErrorDefs.ERROR_CODE_400, "billingId  is null in input");

			}

			stIBMAuthTokenUrlBase.append("/" + stBillingId);

			stIBMAuthTokenUrlFinal = stIBMAuthTokenUrlBase.toString();

			if (hmRequestList != null && !hmRequestList.isEmpty()) {

				hmRequestList.put("userName", userName);
				hmRequestList.put("password", userPassword);
				hmRequestList.put("billingID", stBillingId);
				hmRequestList.put("IBMUrl", stIBMAuthTokenUrlFinal);
				}
			

			log.info("Setting Header IBMUrl=" + stIBMAuthTokenUrlFinal);		
			e.getOut().setHeaders(hmRequestList);
			
			VelocityContext velocityContext = new VelocityContext(hmRequestList);
			e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);

		} catch (MdmAuthTokenException idex) {
			log.error(idex.getErrorMsg());
			e.getOut().setHeader("errorCode", idex.getErrorCode());
			throw new MdmAuthTokenException(idex.getErrorCode(), idex.getErrorMsg());
		}  catch (Exception ex) {
			log.error(ex.getMessage());
			throw new MdmAuthTokenException(CErrorDefs.ERROR_CODE_500, CErrorDefs.SYSTEM_ERROR);
		}
	}

}