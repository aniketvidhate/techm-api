package com.att.sapmp.apigw.mdmauthtoken.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class AuthResponse {
	
	Map<Object, Object> authResponse;
	
	public Map<Object, Object> getAuthResponse() {
		return authResponse;
	}

	public void setAuthResponse(Map<Object, Object> authResponse) {
		this.authResponse = authResponse;
	}

}
