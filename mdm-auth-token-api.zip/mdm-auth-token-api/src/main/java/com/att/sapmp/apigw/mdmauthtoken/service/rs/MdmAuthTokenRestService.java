package com.att.sapmp.apigw.mdmauthtoken.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "/sapmp/v1/mdmauthtoken")
@Produces({ MediaType.APPLICATION_JSON })
public interface MdmAuthTokenRestService {

	@GET
	@Consumes({ MediaType.APPLICATION_JSON })
	@ApiOperation(
			value = "Returns authToken on input accountId",
			notes = "MdmAuthToken API will call MDM Vendor to get the admin auth token "
					+ "auth token will be utilized to make further MDM operations. "
					+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
					+ "All failures would be logged for reporting purpose. ",
			response = Object.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void getAuthToken(@PathParam("billingId") String billingId);
}