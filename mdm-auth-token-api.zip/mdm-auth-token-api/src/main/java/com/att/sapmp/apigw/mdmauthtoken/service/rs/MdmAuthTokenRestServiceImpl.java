package com.att.sapmp.apigw.mdmauthtoken.service.rs;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.springframework.beans.factory.annotation.Autowired;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.mdmauthtoken.service.InitializationService;

@AjscService
public class MdmAuthTokenRestServiceImpl implements MdmAuthTokenRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(MdmAuthTokenRestServiceImpl.class);
	
	@Autowired
	InitializationService is;

	public MdmAuthTokenRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@GET 
	@Path("/{billingId}")
	public void getAuthToken(@PathParam("billingId") String billingId) {	
		log.info("Received request in MdmAuthToken API. billingId="+billingId);
		is.setBillingId(billingId);
		
	}

}
