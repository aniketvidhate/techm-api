package com.att.sapmp.apigw.mdmauthtoken.service;

import java.util.HashMap;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.mdmauthtoken.exception.CErrorDefs;
import com.att.sapmp.apigw.mdmauthtoken.model.AuthResponse;

import io.swagger.annotations.ApiModel;

/**
 * @author pg238s
 *
 */
@ApiModel(value = "ResponseProcessor", description = "ResponseProcessor for parsing the response from camel route")
@Component
public class ResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ResponseProcessor.class);

	public final void handleResponse(Exchange e) throws Exception {

		AuthResponse authRes = (AuthResponse) e.getIn().getBody();

		String authToken = (String) authRes.getAuthResponse().get("authToken");
		Integer errorCode = (Integer) authRes.getAuthResponse().get("errorCode");;
		HashMap<String, Object> hmAuthRes = new HashMap<String, Object>();
		hmAuthRes.put("authToken", authToken);
		hmAuthRes.put("errorCode", errorCode);
		
		if(authToken == null || authToken.isEmpty()){
			String errorDesc = (String) authRes.getAuthResponse().get("errorDesc");
			if(errorDesc != null && !errorDesc.isEmpty()){
				hmAuthRes.put("errorDesc", errorDesc);
			}
			
		}

		JSONObject jsonAuthToken = new JSONObject();
		jsonAuthToken.put("authResponse", hmAuthRes);

		log.info("Response from MDMAuthToken API " + jsonAuthToken);
		e.getOut().setBody(jsonAuthToken);

	}

	public final void handleErrorResponse(Exchange e) throws Exception {

		String stBody = e.getIn().getBody(String.class);
		String stStatusCode = String.valueOf(e.getIn().getHeader("CamelHttpResponseCode"));
		JSONObject jsonError = new JSONObject();
		jsonError.put("errorCode", stStatusCode);
		jsonError.put("message", ((String) CErrorDefs.ERROR_MAP.get(stStatusCode)));

		log.error("Received error from MDM with errorCode=" + stStatusCode + " and details::" + stBody);

		e.getOut().setHeader("CamelHttpResponseCode", e.getIn().getHeader("CamelHttpResponseCode"));
		e.getOut().setBody(jsonError);

	}

}
