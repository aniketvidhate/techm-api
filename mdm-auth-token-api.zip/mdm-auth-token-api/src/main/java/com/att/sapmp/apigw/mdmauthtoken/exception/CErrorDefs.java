package com.att.sapmp.apigw.mdmauthtoken.exception;

import java.util.HashMap;

public class CErrorDefs {
	
	public static final HashMap<String , Object> ERROR_MAP = new HashMap<String , Object>();
	static {
		ERROR_MAP.put("500" , "Internal Server Error");
		ERROR_MAP.put("400" , "Bad Request");
		ERROR_MAP.put("401" , "Unauthorized");
		ERROR_MAP.put("403" , "Forbidden");
	}
	
	public static final String RESPONSE_SUCCESS_CODE="200";
	public static final String RESPONSE_SUCCESS_MSG="SUCCESS";
	
	public static final String OK="200";
	public static final String ERROR_CODE_500="500";
	public static final String ERROR_CODE_400="400";
	public static final String ERROR_CODE_403="403";
	public static final String ERROR_CODE_404="404";
	
	public static final String SYSTEM_ERROR="System Error";
	
	public static final String ERROR_MSG_500="Internal Server Error";
	public static final String ERROR_MSG_401="Unauthorized";
	public static final String ERROR_MSG_403="Forbidden";
	public static final String ERROR_MSG_400="Bad Request";
	
	public static final String ERROR_MSG_INVALID_DATA="Input request contains invalid data";
	

}
