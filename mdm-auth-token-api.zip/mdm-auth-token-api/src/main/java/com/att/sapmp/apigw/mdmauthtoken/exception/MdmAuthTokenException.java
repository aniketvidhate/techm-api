package com.att.sapmp.apigw.mdmauthtoken.exception;

public class MdmAuthTokenException extends Exception {

	public MdmAuthTokenException() {
		super();
	}

	public MdmAuthTokenException(String msg) {
		super(msg);
	}

	public MdmAuthTokenException(String msg, Exception exp) {
		super(msg, exp);
	}

	public MdmAuthTokenException(String errorCode, String errorMsg) {
		super(errorMsg);
		this.errorMsg = errorMsg;
		this.errorCode = errorCode;
	}

	String errorMsg;
	String errorCode;

	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

}
