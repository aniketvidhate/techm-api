package com.att.sapmp.apigw.mdmauthtoken.service;

import java.util.HashMap;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import io.swagger.annotations.ApiModel;

/**
 * @author pg238s
 *
 */
@ApiModel(value = "InitializationService", description = "InitializationService to load the properties")
@Component
public class InitializationService {

	@Value("${IBM_authTParam}")
	private String authParam;

	private String billingId;

	private static final HashMap<String, Object> requestParamMap = new HashMap<String, Object>();

	/**
	 * 
	 * This method read the properties from application.properties and parse it.
	 */

	private void init() {
		if (authParam != null && !authParam.isEmpty()) {
			String[] responsePair = authParam.split(",");
			for (String pair : responsePair) {
				String[] kv = pair.split("=");
				requestParamMap.put(kv[0], kv[1]);
			}

		}

	}

	public static HashMap<String, Object> getRequestparammap() {
		return requestParamMap;
	}

	public String getBillingId() {
		return billingId;
	}

	public void setBillingId(String billingId) {
		this.billingId = billingId;
	}

}