package com.att.sapmp.apigw.mdmauthtoken.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;
import com.att.ajsc.common.utility.SystemPropertiesLoader;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class MdmAuthTokenTest {

	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	@Autowired
	InitializationService initService;
	
	@Autowired
	RequestProcessor requestProcessor;

	@Before
	public void setUp() throws Exception {
		
		initService.setBillingId("30052663");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInit() throws Exception {
		assertFalse(initService.getBillingId().isEmpty());
	}
	
	@Test
	public void testRequestProcessor() throws Exception {
		CamelContext context =  new DefaultCamelContext();
		Exchange e = (Exchange) new DefaultExchange(context);
		requestProcessor.initializeHeader(e);
	}
}
