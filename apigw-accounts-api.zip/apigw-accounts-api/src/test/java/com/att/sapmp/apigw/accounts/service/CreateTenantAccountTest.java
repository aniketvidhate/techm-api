package com.att.sapmp.apigw.accounts.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.impl.DefaultExchange;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CreateTenantAccountTest {

	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	@Autowired
	InitializationService initService;
	
	@Autowired
	CreateTenantAccountRequest createTenantAccountRequest;
	
	@Autowired
	CreateTenantAccountResponse createTenantAccountResponse;

	@Before
	public void setUp() throws Exception {
		
//		initService.setBillingId("1101234");
	}

	@After
	public void tearDown() throws Exception {
	}

//	@Test
//	public void testInit() throws Exception {
//		assertFalse(initService.getBillingId().isEmpty());
//	}
	 
	@Test
	public void testRequestProcessor() throws Exception {
		CamelContext context =  new DefaultCamelContext();
		Exchange e = (Exchange) new DefaultExchange(context);
		
		e.getIn().setHeader("CamelHttpUrl", "http://localhost:8080/sapmp/v1/accounts/createaccount/1101234");
		
		String jsonPostReq = "{\"fan\":\" FAN0012121334\", \"fanName\":\"Demo\",\"email\":\"account-admin@att.com\","
				+ "\"productCode\":\"Customer\"}";
		
		e.getIn().setBody(jsonPostReq);
		
		createTenantAccountRequest.initializeHeader(e);
	}
	
	
	@Test
	public void testResponseProcessor() throws Exception {
		CamelContext context =  new DefaultCamelContext();
		Exchange e = (Exchange) new DefaultExchange(context);
		
		createTenantAccountResponse.handleResponse(e);
		assertEquals(e.getOut().getHeader("CamelHttpResponseCode"), "500"); 
	}
	
	
	@Test
	public void testResponseProcessorError() throws Exception {
		CamelContext context =  new DefaultCamelContext();
		
		Exchange e = (Exchange) new DefaultExchange(context);
		e.getIn().setHeader("CamelHttpResponseCode", "500");//Change the error code to test other scenarios
		
		try{
			
			createTenantAccountResponse.handleErrorResponse(e);
			
			assertEquals(e.getOut().getHeader("CamelHttpResponseCode"), "500"); 
			
			
		}catch(Exception excp){
			excp.printStackTrace();
		}
		
		
	}
	
	@Test
	public void testInit() throws Exception {
		assertFalse(InitializationService.getRequestcreatetenantaccntparammap().isEmpty());
		assertFalse(InitializationService.getResponsecreatetenantaccntparammap().isEmpty());
	}
}
