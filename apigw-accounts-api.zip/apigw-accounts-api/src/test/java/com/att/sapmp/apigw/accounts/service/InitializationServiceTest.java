package com.att.sapmp.apigw.accounts.service;

import static org.junit.Assert.assertFalse;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class InitializationServiceTest {
	
	static{
		SystemPropertiesLoader.addSystemProperties(); 
	}
	
	@Autowired
	InitializationService initService;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInit() throws Exception {
		//initService.init(null);
		assertFalse(initService.getRequestparammap().isEmpty());
		assertFalse(initService.getResponseparammap().isEmpty());
		
	}
}
