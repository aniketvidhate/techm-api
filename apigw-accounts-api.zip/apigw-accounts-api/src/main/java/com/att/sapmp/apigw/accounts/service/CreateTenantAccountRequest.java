package com.att.sapmp.apigw.accounts.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.exception.CreateTenantAccountException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiModel;

/**
 * @author av0041
 *
 */
@ApiModel(value = "CreateTenantAccountRequest", description = "CreateTenantAccountRequest for incoming request from camel route")
@Component
public class CreateTenantAccountRequest {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateTenantAccountRequest.class);
	
	@Value("${IBM_CREATE_TENANT_ACCOUNT_URL}")
	private String createTenantUrl;
	
	@Value("${IBM_partnerBillingId}")
	private String partnerBillingId;
	
	
	public final void initializeHeader(Exchange e) throws CreateTenantAccountException {
		
		try {
			
			String createTenantAccntFinalURL = "";
		
			String postReq = (String) (e.getIn().getBody());
			
			if (postReq == null || postReq.isEmpty()) {

				throw new CreateTenantAccountException(CErrorDefs.ERROR_CODE_400, "Input payload  is null in input");

			}
			

			// create ObjectMapper instance
			ObjectMapper objectMapper = new ObjectMapper();

			// convert json string to object
			Map<String, Object> hmCreateTenantAccnt = objectMapper.readValue(postReq, HashMap.class);
			
			hmCreateTenantAccnt.put("partnerBillingId", partnerBillingId);
		
			createTenantAccntFinalURL = createTenantUrl+"/"+partnerBillingId;
			
			
			log.info("Setting Header IBMCreateTenantAccountUrl=" + createTenantAccntFinalURL);
			e.getOut().setHeader("IBMCreateTenantAccountUrl", createTenantAccntFinalURL);

			VelocityContext velocityContext = new VelocityContext(hmCreateTenantAccnt);
			e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
			e.getOut().setHeader("billingId", partnerBillingId);


		} catch (CreateTenantAccountException ctaex) {
			log.error(CErrorDefs.ERROR_CODE,ctaex);
			e.getOut().setHeader(CErrorDefs.ERROR_CODE, ctaex.getErrorCode());
			throw new CreateTenantAccountException(ctaex.getErrorCode(), ctaex.getErrorMsg());
		}  catch (Exception ex) {
			log.error(CErrorDefs.ERROR_CODE,ex);
			throw new CreateTenantAccountException(CErrorDefs.ERROR_CODE_500, CErrorDefs.SYSTEM_ERROR);
		}
	}

}