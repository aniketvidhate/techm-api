package com.att.sapmp.apigw.accounts.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.swagger.annotations.ApiModel;

/**
 * @author pg238s
 *
 */
@ApiModel(value = "InitializationService", description = "InitializationService to load the properties")
@Component
public class InitializationService {

	@Value("${IBM_ResponseTransformParam}")
	private String responseParam;

	@Value("${IBM_RequestTransformParam}")
	private String requestParam;

	private static final Map<String, Object> responseParamMap = new HashMap<String, Object>();

	private static final Map<String, Object> requestParamMap = new HashMap<String, Object>();
	
	private static final Map<String, Object> responseCreateTenantAccntParamMap = new HashMap<String, Object>();

	private static final Map<String, Object> requestCreateTenantAccntParamMap = new HashMap<String, Object>();
	
	@Value("${IBM_Create_Tenant_Response_Param}")
	private String createTenantAccntResponse;

	@Value("${IBM_Create_Tenant_Request_Param}")
	private String createTenantAccntRequest;

	
	
	private String billingId;


	/**
	 * 
	 * @param e
	 *            This method read the properties from application.properties
	 *            and parse it.
	 */

	private void init() {
		String[] responsePair = responseParam.split(",");
		for (String pair : responsePair) {
			String[] kv = pair.split("=");
			responseParamMap.put(kv[0], kv[1]);
		}

		String[] requestPair = requestParam.split(",");
		for (String pair : requestPair) {
			String[] kv = pair.split("=");
			requestParamMap.put(kv[0], kv[1]);
		}
		
		if (createTenantAccntRequest != null && !createTenantAccntResponse.isEmpty()) {

			String[] responsePairs = createTenantAccntResponse.split(",");
			for (String pair : responsePairs) {
				String[] kv = pair.split("=");
				responseCreateTenantAccntParamMap.put(kv[0], kv[1]);
			}

			String[] requestPairs = createTenantAccntRequest.split(",");
			for (String pair : requestPairs) {
				String[] kv = pair.split("=");
				requestCreateTenantAccntParamMap.put(kv[0], kv[1]);
			}
		}

	}

	public static Map<String, Object> getResponseparammap() {
		return responseParamMap;
	}

	public static Map<String, Object> getRequestparammap() {
		return requestParamMap;
	}
	
	
	public static Map<String, Object> getResponsecreatetenantaccntparammap() {
		return responseCreateTenantAccntParamMap;
	}


	public static Map<String, Object> getRequestcreatetenantaccntparammap() {
		return requestCreateTenantAccntParamMap;
	}

	
	public String getBillingId() {
		return billingId;
	}
	
	
	public void setBillingId(String billingId) {
		this.billingId = billingId;
	}
}