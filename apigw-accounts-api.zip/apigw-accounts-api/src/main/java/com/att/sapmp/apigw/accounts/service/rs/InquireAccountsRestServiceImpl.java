package com.att.sapmp.apigw.accounts.service.rs;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;

@AjscService
public class InquireAccountsRestServiceImpl implements InquireAccountsRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InquireAccountsRestServiceImpl.class);

	public InquireAccountsRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@GET 
	@Path("/")
	public void getAccounts(@QueryParam("searchcriteria") String searchcriteria) {	
		log.info("Received request in InquireAccounts API. searchcriteria="+searchcriteria);
	}

}
