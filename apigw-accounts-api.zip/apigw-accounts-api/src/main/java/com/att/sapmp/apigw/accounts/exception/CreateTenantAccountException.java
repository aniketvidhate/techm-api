package com.att.sapmp.apigw.accounts.exception;

public class CreateTenantAccountException extends Exception {

	private final String errorMsg;
	private final String errorCode;

	public CreateTenantAccountException(String errorCode, String errorMsg) {
		super(errorMsg);
		this.errorMsg = errorMsg;
		this.errorCode = errorCode;
	}

	
	public String getErrorCode() {
		return errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

}
