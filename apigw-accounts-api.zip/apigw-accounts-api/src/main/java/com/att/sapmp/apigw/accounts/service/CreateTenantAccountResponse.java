package com.att.sapmp.apigw.accounts.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.exception.CErrorDefs;
import com.att.sapmp.apigw.accounts.model.CreateTenantAccountResp;

import io.swagger.annotations.ApiModel;

/**
 * @author av0041
 *
 */
@ApiModel(value = "CreateTenantAccountResponse", description = "CreateTenantAccountResponse for parsing the response from camel route")
@Component
public class CreateTenantAccountResponse {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateTenantAccountResponse.class);

	public final void handleResponse(Exchange e) throws Exception {

		CreateTenantAccountResp createAccountRes = (CreateTenantAccountResp) e.getIn().getBody();
		
		JSONObject jsonAuthToken = new JSONObject();
		Map<String, Object> hmCreateAccountJsonRes = new HashMap<String, Object>();
		
		Map hmAccount = null;
		if (createAccountRes != null) {

			hmAccount = (HashMap) createAccountRes.getAccont();

			log.info("Response from MDM Create account API " + hmAccount);

			if (hmAccount != null && !hmAccount.isEmpty() && !hmAccount.containsKey(CErrorDefs.ERROR_CODE)) {
				hmCreateAccountJsonRes.put("emmAccountId", hmAccount.get(CErrorDefs.BILLING_ID));
				hmCreateAccountJsonRes.put("fanName", hmAccount.get(CErrorDefs.ACCOUNT_NAME));
				jsonAuthToken.put("account", hmCreateAccountJsonRes);
				e.getOut().setHeader("CamelHttpResponseCode", CErrorDefs.Created);
			}

		}
		
		if (hmCreateAccountJsonRes == null || hmCreateAccountJsonRes.isEmpty()){
			e.getOut().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_500);
			jsonAuthToken.put("errorCode","E4002");
			jsonAuthToken.put("description ", "Unable to create EMM tenant account");
		}
		
		log.info("Response from CreateTenantAccount API " + jsonAuthToken);
		e.getOut().setBody(jsonAuthToken);

	}

	public final void handleErrorResponse(Exchange e) throws Exception {

		String stBody = e.getIn().getBody(String.class);

		
		String stStatusCode = String.valueOf(e.getIn().getHeader(CErrorDefs.CAMEL_HTTP_RESPONSE_CODE));

		
		JSONObject jsonError = new JSONObject();
		jsonError.put("errorCode", stStatusCode);
		jsonError.put("message", ((String) CErrorDefs.ERROR_MAP.get(stStatusCode)));

		log.error("Received error from CreateTenantAccountResponse with errorCode=" + stStatusCode + " and details::" + stBody);

		e.getOut().setHeader("CamelHttpResponseCode", e.getIn().getHeader(CErrorDefs.CAMEL_HTTP_RESPONSE_CODE));
		e.getOut().setBody(jsonError);

	}

}
