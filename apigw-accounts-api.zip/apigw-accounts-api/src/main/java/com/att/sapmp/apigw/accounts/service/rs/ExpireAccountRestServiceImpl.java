package com.att.sapmp.apigw.accounts.service.rs;


import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.springframework.beans.factory.annotation.Autowired;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.service.InitializationService;

@AjscService
public class ExpireAccountRestServiceImpl implements ExpireAccountRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ExpireAccountRestServiceImpl.class);
	
	@Autowired
	InitializationService is;

	public ExpireAccountRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@DELETE 
	@Path("/{billingId}")
	public void expireAccount(@PathParam("billingId") String billingId) {	
		log.info("Received request in ExpireAccountRestServiceImpl API. billingId="+billingId);
		is.setBillingId(billingId);
		
	}

}
