package com.att.sapmp.apigw.accounts.service;

import com.att.sapmp.apigw.accounts.model.HelloWorld;

public interface SpringService {
	public HelloWorld getQuickHello(String name);
}
