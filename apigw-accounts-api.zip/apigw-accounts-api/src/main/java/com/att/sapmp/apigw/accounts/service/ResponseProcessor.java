package com.att.sapmp.apigw.accounts.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.model.Accounts;
import com.att.sapmp.apigw.mdm.exception.CErrorDefs;

import io.swagger.annotations.ApiModel;

/**
 * @author pg238s
 *
 */
@ApiModel(value = "ResponseProcessor", description = "ResponseProcessor for parsing the response from camel route")
@Component
public class ResponseProcessor {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ResponseProcessor.class);
	
	
	public final void handleExpireAccountResponse(Exchange e) throws Exception {
		
		String respBody = e.getIn().getBody(String.class);
		log.info("Received response in handleExpireAccountResponse method:: "+respBody);
		e.getOut().setHeader("CamelHttpResponseCode", "202");
		
	}


	public final void handleResponse(Exchange e) throws Exception {
		Map<String, Object> hmResponseParam = InitializationService.getResponseparammap();

		Accounts oDev = (Accounts) e.getIn().getBody();

		Object oAccounts = oDev.getAccounts().get("account");

		HashMap<String, Object> hmAccountsResponse = new HashMap<String, Object>();
		ArrayList<HashMap<String, Object>> alAccount = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> hmSingleAccount = null;
		if (oAccounts instanceof ArrayList) {
			ArrayList<HashMap> alAccountsList = (ArrayList<HashMap>) oAccounts;
			for (HashMap<String, Object> hmAccount : alAccountsList) {
				Iterator<String> itResponse = hmResponseParam.keySet().iterator();
				hmSingleAccount = new HashMap<String, Object>();
				while (itResponse.hasNext()) {
					String stKey = (String) itResponse.next();
					if (hmAccount.containsKey(stKey)) {
						hmSingleAccount.put((String) hmResponseParam.get(stKey), hmAccount.get(stKey));
					}
				}

				alAccount.add(hmSingleAccount);

			}

			hmAccountsResponse.put("account", alAccount);
		} else if (oAccounts instanceof HashMap) {
			HashMap<String, Object> hmAccount = (HashMap<String, Object>) oAccounts;
			Iterator<String> itResponse = hmResponseParam.keySet().iterator();
			hmSingleAccount = new HashMap<String, Object>();
			while (itResponse.hasNext()) {
				String stKey = (String) itResponse.next();
				if (hmAccount.containsKey(stKey)) {
					hmSingleAccount.put((String) hmResponseParam.get(stKey), hmAccount.get(stKey));
				}
			}

			hmAccountsResponse.put("account", hmSingleAccount);
		}

		JSONObject jsonAccounts = new JSONObject();
		jsonAccounts.put("accounts", hmAccountsResponse);

		log.info("Response from InquireAccounts API "+jsonAccounts);
		e.getOut().setBody(jsonAccounts);

	}

	public final void handleErrorResponse(Exchange e) throws Exception {

		String stBody = e.getIn().getBody(String.class);

		String stHttpResponseCode = String.valueOf(e.getIn().getHeader("CamelHttpResponseCode"));
		String stDescription = (String) e.getIn().getHeader(CErrorDefs.DESCRIPTION);
		String stErrorCode = (String) e.getIn().getHeader(CErrorDefs.ERROR_CODE);

		JSONObject jsonError = new JSONObject();
		if (stErrorCode != null && !stErrorCode.isEmpty()) {
			jsonError.put(CErrorDefs.ERROR_CODE, stErrorCode);
		} else {
			jsonError.put(CErrorDefs.ERROR_CODE, "E5001");
		}
		if (stDescription != null && !stDescription.isEmpty()) {
			jsonError.put(CErrorDefs.DESCRIPTION, stDescription);
			log.error("Received error in handleErrorResponse method with errorCode=" + stErrorCode
					+ " and description::" + stDescription);
		} else {
			jsonError.put(CErrorDefs.DESCRIPTION, ((String) CErrorDefs.ERROR_MAP.get(stHttpResponseCode)));
			log.error("Received error in handleErrorResponse method with errorCode=" + stErrorCode + " and details::"
					+ stBody);
		}

		e.getOut().setHeader("CamelHttpResponseCode", stHttpResponseCode);
		e.getOut().setBody(jsonError);

	}

}
