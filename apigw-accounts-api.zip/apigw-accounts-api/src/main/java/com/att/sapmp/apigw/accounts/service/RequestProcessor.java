package com.att.sapmp.apigw.accounts.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.mdm.exception.CErrorDefs;
import com.att.sapmp.apigw.mdm.exception.ApigwException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiModel;

/**
 * @author pg238s
 *
 */
@ApiModel(value = "RequestProcessor", description = "RequestProcessor for incoming request from camel route")
@Component
public class RequestProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(RequestProcessor.class);
	@Value("${IBM_searchAccount}")
	private String searchAccountUrl;
	
	@Value("${IBM_expireAccount}")
	private String expireAccountUrl;
	
	@Value("${IBM_partnerBillingId}")
	private String partnerBillingId;
	
	@Autowired
	InitializationService is;	
	
	public final void initializeExpireAccountHeader(Exchange e) throws ApigwException {
		
		try {
	
		log.info("Invoking initializeExpireAccountHeader");
		
		log.info("Setting Header IBMUrl=" + expireAccountUrl);
		String stBillingId = is.getBillingId();
		String stPartnerBillingId= partnerBillingId;
		HashMap<String, Object> hmExpire = new HashMap<String, Object>();
		hmExpire.put("billingId", stBillingId);
		
		if(stBillingId == null || stBillingId.isEmpty()){
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "Billing Id is null in input");
		}
		
		e.getOut().setHeader("IBMUrl", expireAccountUrl + "/" + stPartnerBillingId);
		
		VelocityContext velocityContext = new VelocityContext(hmExpire);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
		e.getOut().setHeader("billingId", stPartnerBillingId);
		} catch (ApigwException iaex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_400);
			e.getIn().setHeader(CErrorDefs.DESCRIPTION, iaex.getErrorMsg());
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, iaex.getErrorCode());
			log.error("Caught ApigwException with error message::"+iaex.getErrorMsg());
			throw new ApigwException(iaex.getErrorCode(), iaex.getErrorMsg());
		} catch (Exception ex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_500);
			e.getIn().setHeader(CErrorDefs.DESCRIPTION, CErrorDefs.SYSTEM_ERROR);
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_5001);
			log.error("Caught Exception with error message::"+ex.getMessage());
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}

	}

	public final void initializeHeader(Exchange e) throws ApigwException {

		try {
			String stIBMSearchAccountUrlFinal = "";
			StringBuilder stIBMSearchAccountUrlBase = new StringBuilder(searchAccountUrl);

			Map<String, Object> hmRequestList = InitializationService.getRequestparammap();

			String searchcriteria = (String) (e.getIn().getHeader("searchcriteria"));

			if (searchcriteria == null || searchcriteria.isEmpty()) {

				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "searchcriteria  is null in input");

			}

			String stEmmAccountId = null;
			// create ObjectMapper instance
			ObjectMapper objectMapper = new ObjectMapper();

			// convert json string to object
			HashMap<String, Object> hmSearch = objectMapper.readValue(searchcriteria, HashMap.class);

			if (hmSearch != null && !hmSearch.isEmpty()) {
				stEmmAccountId = (String) hmSearch.get("emmAccountId");

				if (stEmmAccountId == null || stEmmAccountId.isEmpty()) {
					throw new ApigwException(CErrorDefs.ERROR_CODE_1001, "Account Id is null in input");
				}
			
				stIBMSearchAccountUrlBase.append("/" + partnerBillingId);
				
				stIBMSearchAccountUrlFinal = stIBMSearchAccountUrlBase.toString();

				hmSearch.remove("emmAccountId");

				if (!hmSearch.isEmpty()) {
					stIBMSearchAccountUrlBase.append("?");
					for (Map.Entry<String, Object> entry : hmSearch.entrySet()) {
						stIBMSearchAccountUrlBase.append(hmRequestList.get(entry.getKey()) + "="
								+ entry.getValue()+"&");
					}
					stIBMSearchAccountUrlFinal = stIBMSearchAccountUrlBase.substring(0, stIBMSearchAccountUrlBase.length()-1);
				}

			}
					
			log.info("Setting Header IBMUrl=" + stIBMSearchAccountUrlFinal);
			e.getOut().setHeader("IBMUrl", stIBMSearchAccountUrlFinal);
			e.getOut().setHeader("billingId", partnerBillingId);

		} catch (ApigwException iaex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_400);
			e.getIn().setHeader(CErrorDefs.DESCRIPTION, iaex.getErrorMsg());
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, iaex.getErrorCode());
			log.error("Caught ApigwException with error message::"+iaex.getErrorMsg());
			throw new ApigwException(iaex.getErrorCode(), iaex.getErrorMsg());
		} 
		catch (JsonParseException jex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_400);
			e.getIn().setHeader(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_MSG_400);
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_1001);
			log.error("Caught ApigwException with error message::"+jex.getMessage());
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_MSG_400);
		}catch (Exception ex) {
			e.getIn().setHeader("CamelHttpResponseCode", CErrorDefs.ERROR_CODE_500);
			e.getIn().setHeader(CErrorDefs.DESCRIPTION, CErrorDefs.SYSTEM_ERROR);
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_5001);
			log.error("Caught Exception with error message::"+ex.getMessage());
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}

}