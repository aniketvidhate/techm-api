package com.att.sapmp.apigw.accounts;

import javax.servlet.Filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.att.cadi.filter.CadiFilter;
 
 
 
@Configuration
public class WebConfiguration {
    @Bean
    public FilterRegistrationBean cadiFilterRegistration() {
         
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(cadiFilter());
        registration.addUrlPatterns("/*");
        String stPath = System.getProperty("OCE_RESOURCES_HOME");
        StringBuffer sbPath = new StringBuffer();
        if(stPath == null || stPath.isEmpty()){
        	sbPath.append("src/main/resources");
        }else{
        	sbPath.append(stPath);
        }
        
        sbPath.append("/cadi.properties");
        registration.addInitParameter("cadi_prop_files", sbPath.toString());
        registration.setName("cadiFilter");
        registration.setOrder(0);
        return registration;
    }
    @Bean(name = "cadiFilter")
    public Filter cadiFilter() {
         
        return new CadiFilter();
    }
     
     
}