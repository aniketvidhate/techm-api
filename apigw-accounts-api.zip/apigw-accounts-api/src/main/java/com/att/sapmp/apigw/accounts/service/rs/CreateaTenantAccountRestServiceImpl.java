package com.att.sapmp.apigw.accounts.service.rs;


import javax.ws.rs.POST;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.accounts.service.InitializationService;

@AjscService
public class CreateaTenantAccountRestServiceImpl implements CreateaTenantAccountRestService {	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateaTenantAccountRestServiceImpl.class);
	
	@Autowired
	InitializationService is;
	

	public CreateaTenantAccountRestServiceImpl() {
		// needed for autowiring
	}

	@Override
	@POST 
	public void createTenantAccount(@RequestBody JSONObject input) {	
		log.info("Received request in CreateaTenantAccountRestServiceImpl API");
		
	}

}
