package com.att.sapmp.apigw.accounts.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.RequestBody;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "/createaccount")
@Produces({ MediaType.APPLICATION_JSON })
public interface CreateaTenantAccountRestService {

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/createaccount")
	@ApiOperation(
			value = "Create the Teanant Account",
			notes = "CreateaTenantAccountRestService API will call MDM Vendor to create the Teanant Account in the System"
					+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
					+ "All failures would be logged for reporting purpose. ",
			response = Object.class
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void createTenantAccount(@ApiParam(value = "Create Account Request Object", required = true) @RequestBody JSONObject input);
	
}