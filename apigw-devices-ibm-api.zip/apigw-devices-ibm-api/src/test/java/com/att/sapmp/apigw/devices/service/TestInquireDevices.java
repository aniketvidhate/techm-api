package com.att.sapmp.apigw.devices.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestInquireDevices extends TestBase {

	@Value("${test.emmAccountId}")
	private String emmAccountId;

	@Value("${test.ibm.inquire.device.basePath}")
	protected String basePath;

	@Override
	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
	}

	@Override
	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenInquireDeviceIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception {
		headers.set("authorization", "Basic 123");
		executeGet();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireDeviceWhenRequiredFieldsAreNotPassedThenTransactionFailsAndReturnInvalidRequestError() throws Exception {
		executeGet();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	}	

	@Test
	public void testGivenAuthTokenIsvalidWhenInquireDeviceIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenInquireDeviceWhenRequiredFieldsArePassedAndDeviceRecordExistsThenResponseContainsDeviceDetails() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("deviceId")));
	}

	//@Test
	// Manually, need data for which we have deviceStatus as Active 
	public void testGivenInquireDeviceWhenActiveDevicesAreInquiredThenActiveDevicesAreReturned() throws Exception {
		/*executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("Active"))); */
	}

	@Test
	public void testGivenInquireDeviceWhenInActiveDevicesAreInquiredThenInActiveDevicesAreReturned() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("Inactive")));
	}

	@Test
	//In JSON we have set deviceID as "ApplC39KVZU7FH19"
	public void testGivenInquireDeviceWhenSpecificDeviceIdIsInquiredThenReponseContainsSpecificDevice() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("devices")));
	}

	@Test
	//Manually, as response contains values for all devices
	public void testGivenInquireDeviceWhenAnroidDevicesAreSearchedThenReponseContainsOnlyAndroidDevices() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("Android")));
	}

	//@Test
	//Manually, as response contains values for all devices
	public void testGivenInquireDeviceWhenAppleDevicesAreSearchedThenReponseContainsOnlyAppleDevices() throws Exception {
		/*executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("iPhone")));*/	
	}

	//@Test
	//Manually, as response contains values for all devices
	public void testGivenInquireDeviceWhenWindowsDevicesAreSearchedThenReponseContainsOnlyWindowsDevices() throws Exception {
		/*executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		// we tried for make, platformName, osName
		assertThat(responseBody, allOf(containsString("Windows")));*/
	}

	@Test
	public void testGivenInquireDeviceWhenSearchCriteriaHasPageSizeAndPageNumberThenReponseConfinesToPageSizeAndPageNumberValues() throws Exception {
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("pageSize"),containsString("pageNumber")));
	}
	
	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenNoApiCallMadeInLast60MinutesForGivenEmmAccountIdThenNewlyObtainedAuthTokenIsUsedForAuthentication() throws Exception {
	}

	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenApiCallsMadeInLast60MinutesForEmmAccountIdThenExistingAuthTokenIsUsedForAuthentication() throws Exception {
	}
}
