package com.att.sapmp.apigw.devices.service;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.att.ajsc.common.utility.SystemPropertiesLoader;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.Application;




@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@TestPropertySource(locations = "classpath:application-test.properties")
@ContextConfiguration(classes = { Application.class, TestConfiguration.class })
public class DeviceManagementTest {
	
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceManagementTest.class);
	
	static{
		SystemPropertiesLoader.addSystemProperties(); 
	}
	
	static {
		SystemPropertiesLoader.addSystemProperties();
	}

	   @Autowired
	    private TestRestTemplate template;
	   
	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
	}

	
	
	@Test
	public void testInquireDevice() throws Exception {
			
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
		headers.set("accountpassphrase", "7284955");
		headers.set("trackingid", "12345");
		headers.set("emmproductcode", "IBMMASS");

		 HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		String queryParam = "{\"emmAccountId\":\"30062325\"}";
	     ResponseEntity<String> response = template.exchange("/devices?searchcriteria={queryParam}", HttpMethod.GET, entity, String.class, queryParam);

		log.info("Response:" + response.getBody());
/*		assertEquals(HttpStatus.OK, response.getStatusCode());*/
	}
	
	@Test
	public void testInquireDeviceHistory() throws Exception {
			
		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");
		headers.set("authorization", "Basic bTExMjE0QG1kbWd3LmF0dC5jb206TWFyY2gyMDE3IQ==");
		headers.set("accountpassphrase", "7284955");
		headers.set("trackingid", "1234895");
		headers.set("emmproductcode", "IBMMASS");

		 HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
		String queryParam = "{\"emmAccountId\":\"30062325\", \"deviceId\": \"Android8975435a538e6db6\",\"actionExecutionTimeFrom\":\"2015-11-30T05:52:53\",\"actionExecutionTimeTo\":\"2017-10-09T05:52:53\"}";
	     ResponseEntity<String> response = template.exchange("/devices/history?searchcriteria={queryParam}", HttpMethod.GET, entity, String.class, queryParam);

		log.info("Response:" + response.getBody());
	/*	assertEquals(HttpStatus.OK, response.getStatusCode());*/
	}
}
