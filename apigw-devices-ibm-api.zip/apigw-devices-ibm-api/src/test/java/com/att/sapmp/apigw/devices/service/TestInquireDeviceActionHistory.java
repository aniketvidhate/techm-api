package com.att.sapmp.apigw.devices.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.att.sapmp.apigw.devices.service.TestBase;

public class TestInquireDeviceActionHistory extends TestBase {
	
	@Value("${test.emmAccountId}")
	private String emmAccountId;
	
	@Value("${test.actionExecutionTimeTo}")
	private String actionExecutionTimeTo;
	
	@Value("${test.deviceId}")
	private String deviceId;		
	
	@Value("${test.actionExecutionTimeFrom}")
	protected String actionExecutionTimeFrom;	
	
	@Value("${test.ibm.inquire.device.actionHistory.basePath}")
	protected String basePath;

	@Override
	protected void replaceTokensInRequest() throws Exception {
        requestJson = requestJson.replaceAll("\\$\\{actionExecutionTimeTo\\}", actionExecutionTimeTo);    
        requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", deviceId);   
        requestJson = requestJson.replaceAll("\\$\\{actionExecutionTimeFrom\\}", actionExecutionTimeFrom);  
        requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
	}
	
	@Override
	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenDeviceIsValidWhenRequiredFieldsArePassedThenDeviceActionHistoryIsReturned() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());

	}

	@Test
	public void testGivenDeviceIsAlreadyEnrolledWhenDeviceActionHistoryIsRequestedThenResponseContainsRequiredFields() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody,allOf(containsString("actionHistory"))); 
	}

	@Test
	public void testGivenDeviceIsAlreadyEnrolledWhenActionRequestedForInvalidDateRangeThenResponeContainsNoData() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testGivenDeviceNotExistsWhenActionHistoryIsRequestedThenReponseContainsNoData() throws Exception{
		executeGet();		
	    assertEquals(HttpStatus.OK, response.getStatusCode());
	    assertThat(responseBody, allOf(containsString("")));
	}
	
	@Test
	public void testGivenAuthTokenIsvalidWhenDeviceActionHistoryIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception{
		executeGet();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}
	
	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceActionHistoryIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception{
		headers.set("authorization", "Basic 123");
		executeGet();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}
	
	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken 
	public void testGivenApiRequestWhenNoApiCallMadeInLast60MinutesForGivenEmmAccountIdThenNewlyObtainedAuthTokenIsUsedForAuthentication() throws Exception{ 
	} 
 
	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenApiCallsMadeInLast60MinutesForEmmAccountIdThenExistingAuthTokenIsUsedForAuthentication() throws Exception{ 
	}
}
