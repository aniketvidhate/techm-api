package com.att.sapmp.apigw.devices.service;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestDeviceDeEnrollment extends TestBase {

	@Value("${test.deviceId}")
	private String deviceId;

	@Value("${test.emmAccountId}")
	private String emmAccountId;

	@Value("${test.ibm.deenroll.basePath}")
	protected String basePath;

	@Override
	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{deviceId\\}", deviceId);
		requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
	}

	@Override
	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenDeviceDeEnrollmentWhenRequiredFieldAreMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDeviceAlreadyEnrolledWhenRequiredFieldArePassedThenDeviceIsDeEnrolled() throws Exception {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testGivenDeviceNotEnrolledPreviouslyWhenRequiredFieldArePassedThenDeviceDeEnrollFails() throws Exception {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceDeEnrollmentIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenDeviceDeEnrollmentIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenNoApiCallMadeInLast60MinutesForGivenEmmAccountIdThenNewlyObtainedAuthTokenIsUsedForAuthentication() throws Exception {
	}

	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenApiCallsMadeInLast60MinutesForEmmAccountIdThenExistingAuthTokenIsUsedForAuthentication() throws Exception {
	}

}
