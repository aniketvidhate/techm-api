package com.att.sapmp.apigw.devices.service;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestDeviceEnrollment extends TestBase {

	@Value("${test.emmAccountId}")
	private String emmAccountId;

	@Value("${test.fan}")
	private String fan;

	@Value("${test.ibm.enroll.basePath}")
	protected String basePath;

	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
		requestJson = requestJson.replaceAll("\\$\\{fan\\}", fan);
	}

	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceEnrollmentIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}	
	@Test
	public void testGivenDeviceEnrollmentWhenAnyRequiredFieldAreMissingThenTransactionFailsAndReturnInvalidRequestError() throws Exception {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDeviceEnrollmentWhenAllRequiredFieldsArePassedThenDeviceIsEnrolledAndResponseContainsEnrollmentURLAndPasscode() throws Exception {
		executePost();
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("url"), containsString("passcode")));
	}

	@Test
	public void testGivenDeviceEnrollmentWhenDeviceUserExistsThenDeviceEnollmentSucceedsUnderExistingUserAndResponseContainsEnrollmentURLAndPasscode() throws Exception {
		executePost();
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("url"), containsString("passcode")));
	}

	@Test
	public void testGivenDeviceEnrollmentWhenDeviceUserNotExistsThenNewDeviceUserIsCreatedAndEnrollmentSucceedsAndResponseContainsEnrollmentURLAndPasscode() throws Exception {
		// Create a randomCTN as a new user is required for this request
		executePost();
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertThat(responseBody, allOf(containsString("url"), containsString("passcode")));
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenDeviceEnrollmentIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception {
		executePost();
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
	}
	
	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenNoApiCallMadeInLast60MinutesForGivenEmmAccountIdThenNewlyObtainedAuthTokenIsUsedForAuthentication()
			throws Exception {
	}

	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenApiCallsMadeInLast60MinutesForEmmAccountIdThenExistingAuthTokenIsUsedForAuthentication()throws Exception {
	}

	@Test
	public void testGivenEnrollmentRequestWhenRequiredFieldsAreMissingInHeaderThenTransactionFailsAndReturnInvalidRequestError()throws Exception {
		headers.remove("accountpassphrase");
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody,anyOf(containsString("E1002"), containsString("errorCode"), containsString("description")));
	}

}
