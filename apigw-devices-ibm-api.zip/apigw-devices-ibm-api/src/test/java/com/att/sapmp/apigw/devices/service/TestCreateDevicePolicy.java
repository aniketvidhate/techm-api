package com.att.sapmp.apigw.devices.service;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

public class TestCreateDevicePolicy extends TestBase {
	@Value("${test.emmAccountId}")
	private String emmAccountId;

	@Value("${test.platform}")
	private String platform;

	@Value("${test.passcodePolicyCode}")
	private String passcodePolicyCode;

	@Value("${test.securityPolicyCode}")
	private String securityPolicyCode;

	@Value("${test.ibm.changeDevice.basePath}")
	protected String basePath;

	@Override
	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
		requestJson = requestJson.replaceAll("\\$\\{platform\\}", platform);
		requestJson = requestJson.replaceAll("\\$\\{passcodePolicyCode\\}", passcodePolicyCode);
		requestJson = requestJson.replaceAll("\\$\\{securityPolicyCode\\}", securityPolicyCode);
	}

	@Override
	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenDeviceAndDevicePolicyExistsWhenRequiredFieldsArePassedThenDevicePolicyIsChanged() throws Exception{
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDeviceDoesNotExistsWhenRequiredFieldsArePassedThenDevicePolicyIsNotChanged() throws Exception{
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());		
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDeviceExistsWhenRequiredFieldsAreNotPassedThenReturnInvalidRequestError() throws Exception{
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDevicePolicyDoesNotExistsWhenRequiredFieldsArePassedThenDevicePolicyIsNotChanged() throws Exception{		
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenDeviceIsWindowsWhenRequiredFieldsArePassedThenDevicePolicyChangeIsNotSupported() throws Exception{
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	}
	
	@Test
	public void testGivenAuthTokenIsvalidWhenChangeDevicePolicyIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception{
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertThat(responseBody, anyOf(containsString("errorCode"), containsString("description")));
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenChangeDevicePolicyIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception{
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	//@Test 
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenNoApiCallMadeInLast60MinutesForGivenEmmAccountIdThenNewlyObtainedAuthTokenIsUsedForAuthentication() throws Exception{
	}

	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenApiCallsMadeInLast60MinutesForEmmAccountIdThenExistingAuthTokenIsUsedForAuthentication() throws Exception{
	}
	

}
