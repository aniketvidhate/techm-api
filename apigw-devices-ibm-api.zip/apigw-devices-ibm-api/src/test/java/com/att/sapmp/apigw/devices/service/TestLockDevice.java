package com.att.sapmp.apigw.devices.service;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestLockDevice extends TestBase {

	@Value("${test.emmAccountId}")
	private String emmAccountId;

	@Value("${test.ibm.lockDevice.basePath}")
	protected String basePath;

	@Override
	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);

	}

	@Override
	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceLockIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenLockDeviceWhenRequiredFieldsArePassedThenDeviceIsLocked() throws Exception {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testGivenLockDeviceWhenRequiredFieldsArePassedAndNoMatchingDeviceToLockThenDeviceLockIsFailed() throws Exception {		
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testGivenLockDeviceWhenRequiredFieldsAreNotPassedThenReturnInvalidRequestError() throws Exception {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	@Test
	public void testGivenAuthTokenIsvalidWhenDeviceLockIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	
	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenNoApiCallMadeInLast60MinutesForGivenEmmAccountIdThenNewlyObtainedAuthTokenIsUsedForAuthentication() throws Exception {
	}

	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenApiCallsMadeInLast60MinutesForEmmAccountIdThenExistingAuthTokenIsUsedForAuthentication() throws Exception {
	}

}
