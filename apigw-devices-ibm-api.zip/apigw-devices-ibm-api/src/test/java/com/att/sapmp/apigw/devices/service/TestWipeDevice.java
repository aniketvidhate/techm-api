package com.att.sapmp.apigw.devices.service;

import static org.junit.Assert.assertEquals;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestWipeDevice extends TestBase {

	@Value("${test.emmAccountId}")
	private String emmAccountId;

	@Value("${test.wipeType}")
	private String wipeType;

	@Value("${test.ibm.WipeDevice.basePath}")
	protected String basePath;

	protected void replaceTokensInRequest() throws Exception {
		requestJson = requestJson.replaceAll("\\$\\{emmAccountId\\}", emmAccountId);
		requestJson = requestJson.replaceAll("\\$\\{wipeType\\}", wipeType);
	}

	protected String getBasePath() {
		return basePath;
	}

	@Test
	public void testGivenAuthTokenIsInvalidWhenDeviceWipeIsAttemptedThenTransactionFailsAndReturnUserUnauthorizedError() throws Exception {
		headers.set("authorization", "Basic 123");
		executePost();
		assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
	}

	@Test
	public void testGivenSelectiveWipeIsRequestedWhenCorrenpondingDeviceIsFoundThenDeviceIsSelectiveWiped() throws Exception {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testGivenFullWipeIsRequestedWhenCorrenpondingDeviceIsFoundThenDeviceIsFullyWiped() throws Exception {
		executePost();
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testGivenWipeDeviceWhenRequiredFieldsAreNotPassedThenReturnInvalidRequestError() throws Exception {
		executePost();
		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}

	//@Test
	public void testGivenAuthTokenIsvalidWhenDeviceWipeIsAttemptedAndRequiredFieldsArePassedThenTransactionSucceeds() throws Exception {
		//This is successful scenario of Wipe Device, so it needs to be Manual.
		/*  executePost();
		 * assertEquals(HttpStatus.OK, response.getStatusCode());
		 */
	}

	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenNoWipeDeviceApiCallMadeInLast60MinutesForGivenEmmAccountIdThenNewlyObtainedAuthTokenIsUsedForAuthentication()
			throws Exception {
	}

	//@Test
	//Needs to be manually tested as it is not feasible to wait for 60 Minutes for AuthToken
	public void testGivenApiRequestWhenApiCallsMadeInLast60MinutesForEmmAccountIdThenExistingAuthTokenIsUsedForAuthentication()
			throws Exception {
	}

}
