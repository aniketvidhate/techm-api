package com.att.sapmp.apigw.devices.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class DeviceSoftwares {

	Map<Object, Object> hmDeviceSoftwares;

	public Map<Object, Object> getDeviceSoftwares() {
		return hmDeviceSoftwares;
	}

	public void setDeviceSoftwares(Map<Object, Object> deviceSoftwares) {
		this.hmDeviceSoftwares = deviceSoftwares;

	}

}
