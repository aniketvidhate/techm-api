package com.att.sapmp.apigw.devices.service.rs;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Inquire Devices")

@Produces({ MediaType.APPLICATION_JSON })
public interface InquireDevicesRestService {

	@GET
	@Path("")
	@ApiOperation(
			value = "Supports searching of devices by device attributes",
			notes = "Search for devices based on selected criteria."
			+  "DeviceId and IMEI based serach is recommented to get specific device details."
			+ "If deviceId is populated in the request the installed apps will also be returned in the response.")

					
	@ApiResponses(
			value = {
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	
	public void getDevices(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid, @DefaultValue("{\"emmAccountId\":\"30058930\"}")@QueryParam("searchcriteria") String searchcriteria);
}