package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.model.LockDevice;
import com.att.sapmp.apigw.devices.util.CommonDefs;

/**
 * @author av0041
 *
 */

@Component
public class LockDeviceResponse {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(LockDeviceResponse.class);

	public final void handleResponse(Exchange e) throws ApigwException {
		LockDevice lockDevice = (LockDevice) e.getIn().getBody();
		Map<Object, Object> lockDeviceMap = lockDevice.getActionResponse();
		e.getOut().setHeaders(e.getIn().getHeaders());
		log.info("Response from LockDeviceResponse API " + lockDeviceMap);

		JSONObject responseJSON = new JSONObject(lockDeviceMap);
		e.getOut().setBody(responseJSON);

		if (lockDeviceMap != null && !lockDeviceMap.isEmpty() && lockDeviceMap.containsKey(CommonDefs.MASS_360_DEVICE_ID)
				&& lockDeviceMap.containsKey(CommonDefs.ACTION_STATUS)) {

			if (lockDeviceMap.get(CommonDefs.ACTION_STATUS).toString().equals(CommonDefs.ZERO)) {

				e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);

			} else {

				e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, e.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE));
				Map<String, String> bodyMap = new HashMap<>();
				bodyMap.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4001);
				bodyMap.put(CErrorDefs.DESCRIPTION, lockDeviceMap.get(CommonDefs.DESCRIPTION).toString());
				e.getOut().setBody(bodyMap);
			}
		}
	}

	public final void handleNoContentResponse(Exchange e) throws ApigwException {

		JSONObject jsonError = new JSONObject();
		jsonError.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4001);
		e.getOut().setHeaders(e.getIn().getHeaders());
		jsonError.put(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4001_DESCRIPTION);
		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
		e.getOut().setBody(jsonError);

	}

}
