package com.att.sapmp.apigw.devices.service.rs;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.model.WipeDeviceModel;

import io.swagger.annotations.ApiParam;

public class WipeDeviceRestServiceImp implements WipeDeviceRestService {
	
	/*
	 * @Autowired InitializationService is;
	 */
	public WipeDeviceRestServiceImp() {
		// needed for autowiring
	}

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(WipeDeviceRestServiceImp.class);

	@POST
	@Override
	public void wipeDevice(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@PathParam("deviceId") String deviceId , @ApiParam(value = "Wipe Device Request Object", required = true) @RequestBody WipeDeviceModel wipeDevice) {
		
		log.info("Received request in WipeDevice API. billingId=" + deviceId);
	}

}
