package com.att.sapmp.apigw.devices.common;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.json.JSONObject;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.util.CommonDefs;

public class DeviceAppAggregationStrategy implements AggregationStrategy {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceAppAggregationStrategy.class);

	@Override
	public Exchange aggregate(Exchange exchange1, Exchange exchange2) {
		if (exchange1 == null) {
			return exchange2;
		} else {
				JSONObject jsonDevices = (JSONObject) exchange1.getIn().getBody();
				JSONObject jsonApps = (JSONObject) exchange2.getIn().getBody();
				JSONObject jDevices = (JSONObject) jsonDevices.get(CommonDefs.DEVICES);

				JSONObject jDevice = (JSONObject) jDevices.get(CommonDefs.DEVICE);

				jDevice.put("appsInstalled", jsonApps.get("appsInstalled"));

				log.info("Consolidated response with Devices and Apps = " + jsonDevices);
				exchange1.getIn().setBody(jsonDevices);

			return exchange1;
		}
	}

}
