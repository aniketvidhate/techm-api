package com.att.sapmp.apigw.devices.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.model.DeviceSoftwares;
import com.att.sapmp.apigw.devices.model.Devices;
import com.att.sapmp.apigw.devices.util.CommonDefs;

/**
 * @author pg238s
 *
 */
@Component
public class InquireDeviceResponseProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InquireDeviceResponseProcessor.class);

	public final void handleDeviceResponse(Exchange e) throws Exception {
		try {
			Map<String, Object> responseParamMap = InitializationService.getResponseparammap();
			Devices objDevice = (Devices) e.getIn().getBody();
			Object oDevices = objDevice.getDevices().get(CommonDefs.DEVICE);
			log.info("Response from MDM in InquireDeviceResponseProcessor:: " + objDevice.getDevices());
			HashMap<String, Object> devicesResponseMap = populateMetaData(objDevice);
			ArrayList<HashMap<String, Object>> deviceList = new ArrayList<>();
			HashMap<String, Object> singleDeviceMap = null;
			if (oDevices instanceof ArrayList) {
				ArrayList<HashMap> devicesList = (ArrayList<HashMap>) oDevices;
				for (HashMap<String, Object> deviceMap : devicesList) {
					singleDeviceMap = getDeviceMap(deviceMap, responseParamMap);
					deviceList.add(singleDeviceMap);
				}
				devicesResponseMap.put(CommonDefs.DEVICE, deviceList);
			} else if (oDevices instanceof HashMap) {
				HashMap<String, Object> deviceMap = (HashMap<String, Object>) oDevices;
				singleDeviceMap = getDeviceMap(deviceMap, responseParamMap);
				devicesResponseMap.put(CommonDefs.DEVICE, singleDeviceMap);
			}
			JSONObject jsonDevices = new JSONObject();
			jsonDevices.put(CommonDefs.DEVICES, devicesResponseMap);
			log.info("Response in InquireDeviceResponseProcessor from handleDeviceResponse API " + jsonDevices);
			e.getOut().setBody(jsonDevices);
		} catch (Exception ex) {
			log.error("Caught Exception in InquireDeviceResponseProcessor with error message::" + ex.getMessage(), ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}

	@SuppressWarnings("unchecked")
	public final void handleAppResponse(Exchange e) throws Exception {
		try {
			DeviceSoftwares objDevice = (DeviceSoftwares) e.getIn().getBody();
			Map<Object, Object> deviceSoftwaresMap = objDevice.getDeviceSoftwares();
			ArrayList<HashMap<String, Object>> deviceSwList = (ArrayList<HashMap<String, Object>>) deviceSoftwaresMap
					.get(CommonDefs.DEVICE_SW);
			ArrayList<HashMap<String, Object>> appsList = new ArrayList<>();
			if (deviceSwList != null && !deviceSwList.isEmpty()) {
				for (HashMap<String, Object> deviceSwMap : deviceSwList) {
					ArrayList<HashMap<String, Object>> swAttrsList = (ArrayList<HashMap<String, Object>>) deviceSwMap
							.get(CommonDefs.SW_ATTRS);
					String appName = (String) deviceSwMap.get(CommonDefs.SW_NAME);
					HashMap<String, Object> appMap = getHashMap();
					appMap.put(CommonDefs.APP_NAME, appName);
					for (HashMap<String, Object> swAttrsMap : swAttrsList) {
						String key = (String) swAttrsMap.get(CommonDefs.KEY);
						if (CommonDefs.APPLICATION_ID.equalsIgnoreCase(key)) {
							String appId = (String) swAttrsMap.get(CommonDefs.VALUE);
							appMap.put(CommonDefs.APP_ID, appId);
						}
						if (CommonDefs.VERSION_1.equalsIgnoreCase(key)) {
							Object appVersion = swAttrsMap.get(CommonDefs.VALUE);
							appMap.put(CommonDefs.APP_VERSION, appVersion);
						}
					}
					appsList.add(appMap);
				}
			}
			HashMap<String, Object> appsMap = new HashMap<>();
			appsMap.put(CommonDefs.APP, appsList);
			JSONObject jsonApps = new JSONObject();
			jsonApps.put(CommonDefs.APP_INSTALLED, appsMap);
			log.info("Response in InquireDeviceResponseProcessor from handleAppResponse method " + jsonApps);
			e.getOut().setBody(jsonApps);
		} catch (Exception ex) {
			log.error("Caught Exception in InquireDeviceResponseProcessor with error message::" + ex.getMessage(), ex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_5001, CErrorDefs.SYSTEM_ERROR);
		}
	}

	private HashMap<String, Object> getHashMap() {
		return new HashMap<>();
	}

	private HashMap<String, Object> getDeviceMap(HashMap<String, Object> deviceMap,
			Map<String, Object> responseParamMap) {
		Iterator<String> itResponse = responseParamMap.keySet().iterator();
		HashMap<String, Object> singleDeviceMap = new HashMap<>();
		while (itResponse.hasNext()) {
			String stKey = itResponse.next();
			if (deviceMap.containsKey(stKey)) {
				singleDeviceMap.put((String) responseParamMap.get(stKey), deviceMap.get(stKey));
			}
		}
		return singleDeviceMap;
	}

	private HashMap<String, Object> populateMetaData(Devices objDevice) {
		Object count = objDevice.getDevices().get(CommonDefs.COUNT);
		Object pageNumber = objDevice.getDevices().get(CommonDefs.pageNumber);
		Object pageSize = objDevice.getDevices().get(CommonDefs.pageSize);
		HashMap<String, Object> metaMap = new HashMap<>();
		metaMap.put(CommonDefs.COUNT, count);
		metaMap.put(CommonDefs.pageNumber, pageNumber);
		metaMap.put(CommonDefs.pageSize, pageSize);
		HashMap<String, Object> devicesResponseMap = new HashMap<>();
		devicesResponseMap.put(CommonDefs.METADATA, metaMap);
		return devicesResponseMap;
	}
}
