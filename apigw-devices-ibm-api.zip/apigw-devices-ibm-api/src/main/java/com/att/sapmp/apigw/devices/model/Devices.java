package com.att.sapmp.apigw.devices.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class Devices {

	Map<Object, Object> hmDevices;

	public Map<Object, Object> getDevices() {
		return hmDevices;
	}

	public void setDevices(Map<Object, Object> devices) {
		this.hmDevices = devices;

	}

}
