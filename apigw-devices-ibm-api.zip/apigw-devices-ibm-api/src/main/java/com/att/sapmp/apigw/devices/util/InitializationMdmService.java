package com.att.sapmp.apigw.devices.util;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author pg238s
 *
 */
@Component
public class InitializationMdmService {

	@Value("${ibm.auth.param}")
	private String authParam;

	@Value("${ibm.partner.name}")
	private String userName;

	@Value("${ibm.partner.password}")
	private String password;

	private static final HashMap<String, Object> propAuthParamMap = new HashMap<String, Object>();

	private static final HashMap<String, Object> authTokenMap = new HashMap<String, Object>();

	/**
	 * 
	 * This method read the properties from application.properties and parse it.
	 */

	public void init() {
		if (authParam != null && !authParam.isEmpty()) {
			String[] responsePair = authParam.split(",");
			for (String pair : responsePair) {
				String[] kv = pair.split("=");
				propAuthParamMap.put(kv[0], kv[1]);
			}

		}

		if (userName != null && !userName.isEmpty())
			propAuthParamMap.put("userName", userName);

		if (password != null && !password.isEmpty())
			propAuthParamMap.put("password", password);

	}

	public static Map<String, Object> getPropAuthParamMap() {
		return propAuthParamMap;
	}

	public static Map<String, Object> getAuthtokenmap() {
		return authTokenMap;
	}

	void setAuthtokenmap(HashMap<String, Object> hmInput) {
		synchronized (InitializationMdmService.class) {
			authTokenMap.putAll(hmInput);
		}
	}

}
