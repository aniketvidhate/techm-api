package com.att.sapmp.apigw.devices.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.sapmp.apigw.devices.model.EnrollModel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Create Device Enrollment")
@Produces({ MediaType.APPLICATION_JSON })
@FunctionalInterface
public interface EnrollDeviceRestServices {
	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/enroll")
	@ApiOperation(value = "Enroll device in MDM system ", notes = " In CreateDeviceEnrollmentRestServices API Multiple devices can be enrolled for a corporate CRU account and each user created in MDM will be linked to a BAN by establishing an association with account "
			+ "Client can specify required Account established with MDM , User created with MDM,Device IMEI value,Passcode Policy Code,Security Policy Code and Device Platform as inputs. "
			+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
			+ "All failures would be logged for reporting purpose. ")
	@ApiResponses(value = { @ApiResponse(code = 202, message = "Accepted"), @ApiResponse(code = 200, message = "OK"),
			@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
			@ApiResponse(code = 404, message = "Service not available"),
			@ApiResponse(code = 500, message = "Unexpected Server error") })
	public void enrolledDevice(@HeaderParam(value = "Authorization") String authorization,
			@HeaderParam(value = "EMMProductCode") String productCode,
			@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,
			@HeaderParam(value = "TrackingID") String trackingid,
			@ApiParam(value = "Enroll device Request Object", required = true) @RequestBody EnrollModel enroll);

}
