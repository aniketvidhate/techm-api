package com.att.sapmp.apigw.devices.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.sapmp.apigw.devices.model.DeviceUser;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Create User")
@Produces({ MediaType.APPLICATION_JSON })
@FunctionalInterface
public interface CreateUserRestService {

	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/users/{userName}")
	@ApiOperation(
			value = "Creates a local user account in MDM system ",
			notes = "CreateUserRestService API can  can create  Multiple users for a corporate CRU account and each user created in MDM will be linked to a BAN by establishing an association at the time of account creation  "
					+ "Client can specify required BAN number associated to the customer account for ease of operations with MDM vendor APIs., User CTN,Email address of the user,Domain "
					+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
					+ "All failures would be logged for reporting purpose. "		
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 204, message = "No Content"),
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void createLocalUser(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@PathParam("userName") String userName , @ApiParam(value = "Create User Request Object", required = true) @RequestBody DeviceUser user);
	

}
