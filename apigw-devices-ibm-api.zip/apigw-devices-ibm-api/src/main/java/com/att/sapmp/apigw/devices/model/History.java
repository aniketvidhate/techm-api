package com.att.sapmp.apigw.devices.model;

import java.util.Map;

import org.springframework.stereotype.Component;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class History {

	Map<Object, Object> actionHistory;
	

	public Map<Object, Object> getHistory() {
		
		
		return actionHistory;
	}

	public void setHistory(Map<Object, Object> actionHistory) {
		
		this.actionHistory = actionHistory;

	}

}
