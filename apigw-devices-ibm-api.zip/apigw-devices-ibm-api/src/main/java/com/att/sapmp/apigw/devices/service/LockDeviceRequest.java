package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author av0041
 *
 */
@Component
public class LockDeviceRequest extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(LockDeviceRequest.class);

	@Value("${ibm.lock.device.url}")
	private String lockDeviceUrl;

	public final void execute(Exchange e) throws ApigwException {

		String postReqUrl = (String) e.getIn().getHeader(CommonDefs.CAMEL_HTTP_URL);

		String[] urlArr = postReqUrl.split(CommonDefs.FORWARD_SLASH);
		String deviceId = urlArr[urlArr.length - 2];

		if (StringUtils.isEmpty(deviceId)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.DEVICE_ID_NULL_INPUT);
		}
		String postReq = (String) (e.getIn().getBody());
		log.info("LockDeviceRequest Pay load for Lock Device IBM API :: " + postReq);

		if (StringUtils.isEmpty(postReq)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.BODY_NULL_INPUT);
		}

		JSONObject postReqJSON = new JSONObject();
		try{
			 postReqJSON = new JSONObject(postReq);
        } catch (JSONException jsex) {
            log.error("Exception occurred while parsing post request: " + jsex.getMessage());
            throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1003_DESCRIPTION);
        }		
		validateJSON(postReqJSON, CommonDefs.LOCK_DEVICE_MANDATORY_FIELDS);
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> lockDeviceRequestMap = null;

		try {
			lockDeviceRequestMap = objectMapper.readValue(postReq, HashMap.class);
		} catch (IOException e1) {
			log.error("Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);

		}
		lockDeviceRequestMap.put(CommonDefs.DEVICE_ID, deviceId);
		setVelocityContext(lockDeviceRequestMap, e);
		
	}

	private void setVelocityContext(HashMap<String, Object> lockDeviceRequestMap, Exchange e) throws ApigwException {

		String lockDeviceFinalURL;
		StringBuilder lockDeviceUrlBase = new StringBuilder(lockDeviceUrl);

		if (lockDeviceRequestMap != null && !lockDeviceRequestMap.isEmpty()) {

			if (StringUtils.isEmpty(lockDeviceRequestMap.get(CommonDefs.EMM_ACCOUNT_ID).toString())) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1002, CommonDefs.ENTER_MANDATORY_FIELDS);
			}

			lockDeviceUrlBase.append(CommonDefs.FORWARD_SLASH + lockDeviceRequestMap.get(CommonDefs.EMM_ACCOUNT_ID));

			lockDeviceFinalURL = lockDeviceUrlBase.toString();

		} else {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.EMPTY_REQUEST);
		}

		log.info("LockDeviceRequest the url for IBM lockDevice is :: " + lockDeviceFinalURL);
		e.getOut().setHeader(CommonDefs.IBM_LOCK_DEVICE_FINAL_URL, lockDeviceFinalURL);

		e.getOut().setHeader(CommonDefs.BILLING_ID, lockDeviceRequestMap.get(CommonDefs.EMM_ACCOUNT_ID));

		VelocityContext velocityContext = new VelocityContext(lockDeviceRequestMap);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

}