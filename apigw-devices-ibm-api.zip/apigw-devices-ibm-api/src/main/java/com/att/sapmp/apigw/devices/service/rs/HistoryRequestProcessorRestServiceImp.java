package com.att.sapmp.apigw.devices.service.rs;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.QueryParam;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;

public class HistoryRequestProcessorRestServiceImp implements HistoryRequestProcessorRestService {
	/*
	 * @Autowired InitializationService is;
	 */

	public HistoryRequestProcessorRestServiceImp() {
		// needed for autowiring
	}

	private static EELFLogger log = AjscEelfManager.getInstance()
			.getLogger(HistoryRequestProcessorRestServiceImp.class);

	@GET
	@Override
	public void getHistory(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@DefaultValue("{\"emmAccountId\":\"30058930\",\"deviceId\": \"Android8975435a538e6db6\",\"actionExecutionTimeFrom\":\"2015-11-30T05:52:53\",\"actionExecutionTimeTo\":\"2017-10-09T05:52:53\"}")@QueryParam("searchcriteria") String searchcriteria){
		
		log.info("Received request in HistoryRequestProcessorRestServiceImp API. searchcriteria=" + searchcriteria);
	}

}
