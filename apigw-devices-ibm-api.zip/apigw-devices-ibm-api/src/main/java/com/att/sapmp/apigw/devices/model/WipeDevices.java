package com.att.sapmp.apigw.devices.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class WipeDevices {

	Map<Object, Object> actionResponse;

	public Map<Object, Object> getActionResponse() {
		return actionResponse;
	}

	public void setActionResponse(Map<Object, Object> devices) {
		this.actionResponse = devices;

	}

}
 