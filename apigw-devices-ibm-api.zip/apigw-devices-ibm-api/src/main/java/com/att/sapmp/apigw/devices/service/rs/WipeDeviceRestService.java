package com.att.sapmp.apigw.devices.service.rs;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;


import com.att.sapmp.apigw.devices.model.WipeDeviceModel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Wipe Device (Full or Selective Wipe)")

@Produces({ MediaType.APPLICATION_JSON })
public interface WipeDeviceRestService {
	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/{deviceId}/wipe")
	@ApiOperation(
			value = "Supports different types of wipes such as 'full', 'selective'.",
			notes = "WipeDeviceRestService API can be executed on an Exchange ActiveSync, Notes, BES, iOS MDM, Android MDM or Windows Phone MDM device."
					+ "Client can specify required Account ID of the account for which the web-service is being executed, Client Serial Number of the device "
					+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
					+ "All failures would be logged for reporting purpose. "
	
	)

	@ApiResponses(
			value = {
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 204, message = "No Content"),
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})
	public void wipeDevice(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@PathParam("deviceId") String deviceId , @ApiParam(value = "Wipe Device Request Object", required = true) @RequestBody WipeDeviceModel wipeDevice);
	
	

}
