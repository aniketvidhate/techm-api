package com.att.sapmp.apigw.devices.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class CreateUser {
	
	Map<Object, Object> response;

	public Map<Object, Object> getResponse() {
		return response;
	} 

	public void setResponse(Map<Object, Object> response) {
		this.response = response;
	}

}
