package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author av0041
 *
 */
@Component
public class CreateUserRequest extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateUserRequest.class);

	@Value("${ibm.create.user.url}")
	private String createUserUrl;

	public final void execute(Exchange e) throws ApigwException {
		String createUserFinalURL;
		StringBuilder createUserUrlBase = new StringBuilder(createUserUrl);
		String postReqUrl = (String) e.getIn().getHeader(CommonDefs.CAMEL_HTTP_URL);
		String userName = postReqUrl.substring(postReqUrl.lastIndexOf(CommonDefs.FORWARD_SLASH) + 1,
				postReqUrl.length());
		String billingId = (String) e.getIn().getHeader(CommonDefs.BILLING_ID);

		if (StringUtils.isEmpty(userName)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.REQUEST_USERNAME_NULL);
		}
		String postReq = (String) (e.getIn().getBody());
		if (StringUtils.isEmpty(postReq)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.EMPTY_REQUEST_BODY);
		}

		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> createUserMap = null;
		try {
			createUserMap = objectMapper.readValue(postReq, HashMap.class);
		} catch (IOException e1) {
			log.error("CreateUserRequest Exception occurred while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}

		if (createUserMap != null && !createUserMap.isEmpty()) {
			validateMap(createUserMap, CommonDefs.CREATE_USER_MANDATORY_FIELDS);
			if(StringUtils.isEmpty(billingId)){
				billingId = (String) createUserMap.get(CommonDefs.EMM_ACCOUNT_ID);
			}
			createUserUrlBase.append(CommonDefs.FORWARD_SLASH + billingId);
			createUserMap.put(CommonDefs.USER_NAME, userName);
			createUserFinalURL = createUserUrlBase.toString();

		} else {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.EMPTY_REQUEST);
		}

		log.info("CreateUserRequest Setting Header IBMCreateUserUrl=" + createUserFinalURL);
		e.getOut().setHeader(CommonDefs.IBM_CREATE_USER_URL, createUserFinalURL);

		log.info("CreateUserRequest Setting Header userName=" + userName);
		e.getOut().setHeader(CommonDefs.BILLING_ID, billingId);

		VelocityContext velocityContext = new VelocityContext(createUserMap);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

}