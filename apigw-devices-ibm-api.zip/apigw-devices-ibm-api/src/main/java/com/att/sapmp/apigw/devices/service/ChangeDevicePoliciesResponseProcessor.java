package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ChangeDevicePoliciesResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance()
			.getLogger(ChangeDevicePoliciesResponseProcessor.class);

	public final void handleResponse(Exchange e) throws ApigwException {

		String stBody = e.getIn().getBody(String.class);
		log.info("ChangeDevicePoliciesResponseProcessor received response from MDM ChangeDevicePolicies :" + stBody);
		e.getOut().setHeaders(e.getIn().getHeaders());
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> changePolicyMap;
		try {
			changePolicyMap = objectMapper.readValue(stBody, HashMap.class);
		} catch (IOException ioex) {
			log.error("Exception occurred in ChangeDevicePoliciesResponseProcessor while parsing Body ::"
					+ ioex.getMessage() + " and Exception :: " + ioex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		Map<String, Object> responseMap = (HashMap<String, Object>) changePolicyMap.get(CommonDefs.ACTION_RESPONSE);

		JSONObject responseJSON = new JSONObject(responseMap);
		e.getOut().setBody(responseJSON);
		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
	}

	public final void handleNoContentResponse(Exchange e) throws Exception {

		JSONObject jsonError = new JSONObject();
		e.getOut().setHeaders(e.getIn().getHeaders());
		jsonError.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4001);
		jsonError.put(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4001_DESCRIPTION);
		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
		e.getOut().setBody(jsonError);

	}

}
