package com.att.sapmp.apigw.devices.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public  class EnrollModel {
	String emmAccountId;
    String fan;
    String fanName;
    String liabilityType;
    String email;
   	String productCode;
    Enrollments enrollments;
    
    @JsonCreator
    public EnrollModel(@JsonProperty("emmAccountId") String emmAccountId, @JsonProperty("fan") String fan, @JsonProperty("fanName") String fanName, @JsonProperty("email") String email,@JsonProperty("liabilityType") String liabilityType, @JsonProperty("productCode") String productCode, @JsonProperty("enrollments") Enrollments enrollments){
        this.emmAccountId = emmAccountId;
        this.fan = fan;
        this.fanName = fanName;
        this.email = email;
        this.productCode = productCode;
        this.enrollments = enrollments;
    }
    
	 @ApiModelProperty(value = "emmAccountId", example = "30059025")
    public String getEmmAccountId() {
		return emmAccountId;
	}

	public void setEmmAccountId(String emmAccountId) {
		this.emmAccountId = emmAccountId;
	}
	 @ApiModelProperty(value = "fan", example = "5001234")
	public String getFan() {
		return fan;
	}

	public void setFan(String fan) {
		this.fan = fan;
	}
	 @ApiModelProperty(value = "fanName", example = "ABCorp")
	public String getFanName() {
		return fanName;
	}

	public void setFanName(String fanName) {
		this.fanName = fanName;
	}
	 @ApiModelProperty(value = "liabilityType", example = "CRU")
	   

		public String getLiabilityType() {
		return liabilityType;
	}

	public void setLiabilityType(String liabilityType) {
		this.liabilityType = liabilityType;
	}

	 @ApiModelProperty(value = "email", example = "9034970998@txt.att.net")
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	 @ApiModelProperty(value = "productCode", example = "ibmmass")
	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public Enrollments getEnrollments() {
		return enrollments;
	}

	public void setEnrollments(Enrollments enrollments) {
		this.enrollments = enrollments;
	}

    public static final class Enrollments {
        public final Enrollment [] enrollment;

        @JsonCreator
        public Enrollments(@JsonProperty("enrollment") Enrollment[] enrollment){
            this.enrollment = enrollment;
        }

        public static  class Enrollment {
			String lineId;
            Device device;
            User user;
            Group group;
            Profile profile;
            
            @JsonCreator          
            public Enrollment(@JsonProperty("lineId") String lineId, @JsonProperty("device") Device device, @JsonProperty("user") User user, @JsonProperty("group") Group group, @JsonProperty("profile") Profile profile){
            	this.lineId = lineId;
                this.device = device;
                this.user = user;
                this.group = group;
                this.profile = profile;
            }
            
            public String getLineId() {
				return lineId;
			}
            @ApiModelProperty(value = "lineId", example = "xnxn-9898-fghg-ghgh")
			public void setLineId(String lineId) {
				this.lineId = lineId;
			}
           
			public Device getDevice() {
				return device;
			}

			public void setDevice(Device device) {
				this.device = device;
			}

			public User getUser() {
				return user;
			}

			public void setUser(User user) {
				this.user = user;
			}

			public Group getGroup() {
				return group;
			}

			public void setGroup(Group group) {
				this.group = group;
			}

			public Profile getProfile() {
				return profile;
			}

			public void setProfile(Profile profile) {
				this.profile = profile;
			}
    
            public static  class Device {
				String id;
                String imei;
                String platform;   
                
                @JsonCreator
                public Device(@JsonProperty("id") String id, @JsonProperty("imei") String imei, @JsonProperty("platform") String platform){
                    this.id = id;
                    this.imei = imei;
                    this.platform = platform;
                }       
                
            	@ApiModelProperty(value = "id", example = "ApplC39KVZU7FH19")
                public String getId() {
					return id;
				}

				public void setId(String id) {
					this.id = id;
				}
				 @ApiModelProperty(value = "imei", example = "12334234234234")
				public String getImei() {
					return imei;
				}

				public void setImei(String imei) {
					this.imei = imei;
				}
				 @ApiModelProperty(value = "platform", example = "iOS")
				public String getPlatform() {
					return platform;
				}

				public void setPlatform(String platform) {
					this.platform = platform;
				} 
            }
    
            public static  class User {
                String firstName;
                String lastName;
                String ctn;
                String ban;
                String email;
                String domain;
                
				@JsonCreator
                public User(@JsonProperty("firstName") String firstName, @JsonProperty("lastName") String lastName, @JsonProperty("ctn") String ctn, @JsonProperty("ban") String ban, @JsonProperty("email") String email, @JsonProperty("domain") String domain){
                    this.firstName = firstName;
                    this.lastName = lastName;
                    this.ctn = ctn;
                    this.ban = ban;
                    this.email = email;
                    this.domain = domain;
                }
				
                @ApiModelProperty(value = "firstName", example = "Test19")
                public String getFirstName() {
					return firstName;
				}

				public void setFirstName(String firstName) {
					this.firstName = firstName;
				}
				 @ApiModelProperty(value = "lastName", example = "Test19")
				public String getLastName() {
					return lastName;
				}

				public void setLastName(String lastName) {
					this.lastName = lastName;
				}
				 @ApiModelProperty(value = "ctn", example = "9725679737")
				public String getCtn() {
					return ctn;
				}

				public void setCtn(String ctn) {
					this.ctn = ctn;
				}
				 @ApiModelProperty(value = "ban", example = "2342342342")
				public String getBan() {
					return ban;
				}

				public void setBan(String ban) {
					this.ban = ban;
				}
				 @ApiModelProperty(value = "email", example = "abc@att.com")
				public String getEmail() {
					return email;
				}

				public void setEmail(String email) {
					this.email = email;
				}
				 @ApiModelProperty(value = "domain", example = "att.com")
				public String getDomain() {
					return domain;
				}

				public void setDomain(String domain) {
					this.domain = domain;
				}
            }
    
            public static  class Group {
                String groupId;
                String groupName;
        
                @JsonCreator
                public Group(@JsonProperty("groupId") String groupId, @JsonProperty("groupName") String groupName){
                    this.groupId = groupId;
                    this.groupName = groupName;
                }
                @ApiModelProperty(value = "groupId", example = "G001")
				public String getGroupId() {
					return groupId;
				}

				public void setGroupId(String groupId) {
					this.groupId = groupId;
				}
				 @ApiModelProperty(value = "groupName", example = "Executives")
				public String getGroupName() {
					return groupName;
				}

				public void setGroupName(String groupName) {
					this.groupName = groupName;
				}
            }
    
            public static  class Profile {
                String profileId;
                String profileName;
                String networkControl;
                String passcodePolicyCode;
                String securityPolicyCode;
                Applications applications;
        
                @JsonCreator
                public Profile(@JsonProperty("profileId") String profileId, @JsonProperty("profileName") String profileName, @JsonProperty("networkControl") String networkControl, @JsonProperty("passcodePolicyCode") String passcodePolicyCode, @JsonProperty("securityPolicyCode") String securityPolicyCode, @JsonProperty("applications") Applications applications){
                    this.profileId = profileId;
                    this.profileName = profileName;
                    this.networkControl = networkControl;
                    this.passcodePolicyCode = passcodePolicyCode;
                    this.securityPolicyCode = securityPolicyCode;
                    this.applications = applications;
                }
                @ApiModelProperty(value = "profileId", example = "P001")
                public String getProfileId() {
					return profileId;
				}

				public void setProfileId(String profileId) {
					this.profileId = profileId;
				}
				 @ApiModelProperty(value = "profileName", example = "DefaultProfile")
				public String getProfileName() {
					return profileName;
				}

				public void setProfileName(String profileName) {
					this.profileName = profileName;
				}
				 @ApiModelProperty(value = "networkControl", example = "true")
				public String getNetworkControl() {
					return networkControl;
				}

				public void setNetworkControl(String networkControl) {
					this.networkControl = networkControl;
				}
				 @ApiModelProperty(value = "passcodePolicyCode", example = "PN")
				public String getPasscodePolicyCode() {
					return passcodePolicyCode;
				}

				public void setPasscodePolicyCode(String passcodePolicyCode) {
					this.passcodePolicyCode = passcodePolicyCode;
				}
				 @ApiModelProperty(value = "securityPolicyCode", example = "SE")
				public String getSecurityPolicyCode() {
					return securityPolicyCode;
				}

				public void setSecurityPolicyCode(String securityPolicyCode) {
					this.securityPolicyCode = securityPolicyCode;
				}

				public Applications getApplications() {
					return applications;
				}

				public void setApplications(Applications applications) {
					this.applications = applications;
				}

				public static  class Applications {
                    public final Application [] application;
            
                    @JsonCreator
                    public Applications(@JsonProperty("application") Application[] application){
                        this.application = application;
                    }
            
                    public static final class Application {
                        String appId;
                        String appType;
                        String emailNotification;
                        String sendNotification;
                        
						@JsonCreator
                        public Application(@JsonProperty("appId") String appId, @JsonProperty("appType") String appType, @JsonProperty("emailNotification") String emailNotification, @JsonProperty("sendNotification") String sendNotification){
                            this.appId = appId;
                            this.appType = appType;
                            this.emailNotification = emailNotification;
                            this.sendNotification = sendNotification;
                        }
						
                        @ApiModelProperty(value = "appId", example = "App1")
                        public String getAppId() {
							return appId;
						}

						public void setAppId(String appId) {
							this.appId = appId;
						}
						 @ApiModelProperty(value = "appType", example = "1")
						public String getAppType() {
							return appType;
						}

						public void setAppType(String appType) {
							this.appType = appType;
						}
						 @ApiModelProperty(value = "emailNotification", example = "Yes")
						public String getEmailNotification() {
							return emailNotification;
						}
						 
						public void setEmailNotification(String emailNotification) {
							this.emailNotification = emailNotification;
						}
						 @ApiModelProperty(value = "sendNotification", example = "No")
						public String getSendNotification() {
							return sendNotification;
						}

						public void setSendNotification(String sendNotification) {
							this.sendNotification = sendNotification;
						}
                    }
                }
            }
        }
    }
}