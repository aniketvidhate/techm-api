package com.att.sapmp.apigw.devices.service.rs;



import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.sapmp.apigw.devices.model.DeEnrollDevice;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "De-Enroll Device(s)")
@Produces({ MediaType.APPLICATION_JSON })
@FunctionalInterface
public interface DeviceDeEnrollOrchRestService {

	
	@POST
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/deenroll")
	@ApiOperation(
			value = "This operation will mark the device as inactive or De-Enrolled",
			notes = "DeviceDeEnrollmentRestService API can be executed on iOS MDM, Android MDM, Windows Phone MDM or BES device  "
					+ "Client can specify Account established with MDM , Full deviceId of the device to be marked inactive as input. "
					+ "Exception Handling - MDM API failures will be handled and corresponding error response will be returned "
					+ "All failures would be logged for reporting purpose. "			
	)
	@ApiResponses(
			value = {
					@ApiResponse(code = 202, message = "Accepted"),
					@ApiResponse(code = 200, message = "OK"),
					@ApiResponse(code = 400, message = "Bad Request. Please verify your input"),
					@ApiResponse(code = 404, message = "Service not available"),
					@ApiResponse(code = 500, message = "Unexpected Server error")
					})

	public void deEnrolledDevices(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@ApiParam(value = " Request Object", required = true) @RequestBody DeEnrollDevice deenrollDevice);
}
