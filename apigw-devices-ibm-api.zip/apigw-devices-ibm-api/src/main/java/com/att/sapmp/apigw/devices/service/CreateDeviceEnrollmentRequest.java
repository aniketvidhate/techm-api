package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author av0041
 *
 */
@Component
public class CreateDeviceEnrollmentRequest extends BaseProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateDeviceEnrollmentRequest.class);
	@Value("${ibm.enroll.device.url}")
	private String enrollDeviceUrl;

	public final void execute(Exchange e) throws ApigwException {
		String enrollDeviceFinalURL;
		StringBuilder enrollDeviceUrlBase = new StringBuilder(enrollDeviceUrl);
		String fan;
		String billingId = null;
		String postReq = (String) (e.getIn().getBody());
		if (StringUtils.isEmpty(postReq)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.EMPTY_REQUEST);
		}
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> enrollDeviceMap = null;
		try {
			enrollDeviceMap = objectMapper.readValue(postReq, HashMap.class);
		} catch (IOException e1) {
			log.error("Exception occurred in CreateDeviceEnrollmentRequest while parsing post request: " + e1);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		List<Map<String, Object>> enrollmentList;
		if (enrollDeviceMap != null && !enrollDeviceMap.isEmpty()) {
			if (enrollDeviceMap.get(CommonDefs.EMM_ACCOUNT_ID) != null) {
				billingId = String.valueOf(enrollDeviceMap.get(CommonDefs.EMM_ACCOUNT_ID)).trim();
			}
			if (StringUtils.isEmpty(billingId)) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.EMMACCOUNTID_NULL_INPUT);
			}
			fan = String.valueOf(enrollDeviceMap.get(CommonDefs.FAN));
			Map<String, Object> enrollmentsMap = (Map<String, Object>) enrollDeviceMap.get(CommonDefs.ENROLLMENTS);
			enrollmentList = (List<Map<String, Object>>) enrollmentsMap.get(CommonDefs.ENROLLMENT);
			enrollDeviceUrlBase.append(CommonDefs.FORWARD_SLASH + billingId);
			enrollDeviceFinalURL = enrollDeviceUrlBase.toString();
		} else {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.EMPTY_REQUEST);
		}
		Map<String, Object> headerMap = new HashMap<>();
		headerMap.put(CommonDefs.ENROLLMENT_LIST, enrollmentList);
		headerMap.put(CommonDefs.IBM_ENROLL_DEVICE_URL, enrollDeviceFinalURL);
		headerMap.put(CommonDefs.BILLING_ID, billingId);
		headerMap.put(CommonDefs.FAN, fan);
		log.info("CreateDeviceEnrollmentRequest Setting Header IBMEnrollDeviceUrl=" + enrollDeviceFinalURL);
		e.getOut().setHeader(CommonDefs.BILLING_ID, billingId);
		e.getOut().setHeaders(headerMap);
		e.getOut().setBody(e.getIn().getBody());
	}

	public final void split(Exchange e) throws ApigwException {
		try {
			Map<String, Object> headerMap = e.getIn().getHeaders();
			Map<String, Object> map = (Map<String, Object>) e.getIn().getBody();
			Map<String, Object> userMap = (Map<String, Object>) map.get(CommonDefs.USER);
			Map<String, Object> deviceMap = (Map<String, Object>) map.get(CommonDefs.DEVICE_JSON);
			Map<String, Object> profileMap = (Map<String, Object>) map.get(CommonDefs.PROFILE_JSON);
			String policySet = getPolicySet(deviceMap, profileMap);
			String billingId = String.valueOf(headerMap.get(CommonDefs.BILLING_ID));
			String enrollDeviceFinalURL = String.valueOf(headerMap.get(CommonDefs.IBM_ENROLL_DEVICE_URL));
			e.getOut().setHeaders(e.getIn().getHeaders());
			e.getOut().setHeader(CommonDefs.BILLING_ID, billingId);
			e.getOut().setHeader(CommonDefs.IBM_ENROLL_DEVICE_URL, enrollDeviceFinalURL);
			setVelocityContext(e, billingId, userMap, enrollDeviceFinalURL, deviceMap, policySet);
		} catch (ApigwException ex) {
			log.error("Error while processing multiple Enrolment request....", ex);
			e.getIn().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_400);
			e.getIn().setHeader(CErrorDefs.DESCRIPTION, ex.getErrorMsg());
			e.getIn().setHeader(CErrorDefs.ERROR_CODE, ex.getErrorCode());
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_MSG_400);
		}
	}

	private void setVelocityContext(Exchange e, String billingId, Map<String, Object> userMap,
			String enrollDeviceFinalURL, Map<String, Object> deviceMap, String policySet) throws ApigwException {
		String domain = getDomain(userMap);
		String email = getEmail(userMap);
		String userName = getUserName(userMap, e);
		String platform = getPlatform(deviceMap);
		HashMap<String, String> hmVelocityContext = new HashMap<>();
		hmVelocityContext.put(CommonDefs.BILLING_ID, billingId);
		hmVelocityContext.put(CommonDefs.USER_NAME, userName);
		hmVelocityContext.put(CommonDefs.DOMAIN, domain);
		hmVelocityContext.put(CommonDefs.EMAIL_ADDRESS, email);
		hmVelocityContext.put(CommonDefs.IBM_ENROLL_DEVICE_URL, enrollDeviceFinalURL);
		hmVelocityContext.put(CommonDefs.EMAIL_USER, CommonDefs.NO);
		hmVelocityContext.put(CommonDefs.EMAIL_ADMIN, CommonDefs.NO);
		hmVelocityContext.put(CommonDefs.SEND_SMS_USER, CommonDefs.NO);
		hmVelocityContext.put(CommonDefs.PLATFORM, platform);
		hmVelocityContext.put(CommonDefs.POLICYSET, policySet);
		VelocityContext velocityContext = new VelocityContext(hmVelocityContext);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);
	}

	private String getUserName(Map<String, Object> userMap, Exchange e) throws ApigwException {
		Map<String, Object> headerMap = e.getIn().getHeaders();
		String fan = String.valueOf(headerMap.get(CommonDefs.FAN));
		String ctn;
		String userName = "";
		if (userMap != null && userMap.containsKey(CommonDefs.CTN)) {
			ctn = getCtn(userMap);
			userName = fan + CommonDefs.UNDERSCORE + ctn;
		}
		if (StringUtils.isEmpty(userName)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.ENTER_MANDATORY_FIELDS);
		}
		return userName;
	}

	private String getDomain(Map<String, Object> userMap) throws ApigwException {
		String domain = "";
		if (userMap != null && userMap.containsKey(CommonDefs.DOMAIN)) {
			domain = userMap.get(CommonDefs.DOMAIN).toString().trim();
		}
		if (StringUtils.isEmpty(domain)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.ENTER_MANDATORY_FIELDS);
		}
		return domain;
	}

	private String getEmail(Map<String, Object> userMap) throws ApigwException {
		String email = "";
		if (userMap != null && userMap.containsKey(CommonDefs.EMAIL)) {
			email = userMap.get(CommonDefs.EMAIL).toString().trim();
		}
		if (StringUtils.isEmpty(email)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.ENTER_MANDATORY_FIELDS);
		}
		return email;
	}

	private String getCtn(Map<String, Object> userMap) throws ApigwException {
		String ctn = "";
		if (userMap != null && userMap.containsKey(CommonDefs.CTN)) {
			ctn = userMap.get(CommonDefs.CTN).toString().trim();
		}
		if (StringUtils.isEmpty(ctn)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.ENTER_MANDATORY_FIELDS);
		}
		return ctn;
	}

	private String getPolicySet(Map<String, Object> deviceMap, Map<String, Object> profileMap) throws ApigwException {
		String policySet;
		String platform = getPlatform(deviceMap);
		String securityPolicyCode = null;
		String passcodePolicyCode = null;
		if (deviceMap != null && deviceMap.containsKey(CommonDefs.PLATFORM)) {
			securityPolicyCode = profileMap.get(CommonDefs.SECURITY_POLOCY_CODE).toString().trim();
			passcodePolicyCode = profileMap.get(CommonDefs.PASSCODE_POLOCY_CODE).toString().trim();
		}
		policySet = platform + CommonDefs.UNDERSCORE + securityPolicyCode + passcodePolicyCode;
		return policySet;
	}

	private String getPlatform(Map<String, Object> deviceMap) throws ApigwException {
		String platform = "";
		if (deviceMap != null && deviceMap.containsKey(CommonDefs.PLATFORM)) {
			platform = deviceMap.get(CommonDefs.PLATFORM).toString().trim();
		}
		if (StringUtils.isEmpty(platform)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.ENTER_MANDATORY_FIELDS);
		}
		return platform;
	}
}