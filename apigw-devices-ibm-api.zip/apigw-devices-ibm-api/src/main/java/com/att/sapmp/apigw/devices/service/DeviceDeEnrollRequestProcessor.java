package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author AD574A
 *
 */
@Component
public class DeviceDeEnrollRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceDeEnrollRequestProcessor.class);
	@Value("${ibm.deEnroll.device.url}")
	private String deEnrollDeviceUrl;

	public final void execute(Exchange e) throws ApigwException {

		List<String> deviceIdList = null;
		String stBillingId = "";
		StringBuilder deEnrollDeviceIBMUrl = new StringBuilder(deEnrollDeviceUrl);
		String messageBody = e.getIn().getBody(String.class);
		if (StringUtils.isEmpty(messageBody)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001,CErrorDefs.ERROR_CODE_1004_DESCRIPTION);
		}
		JSONObject postReqJSON = new JSONObject();
		try {
			postReqJSON = new JSONObject(messageBody);
		} catch (JSONException jsex) {
			log.error("Exception occurred in DeviceDeEnrollRequestProcessor while parsing post request: "+ jsex.getMessage());
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1003_DESCRIPTION);
		}
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> deEnrollDeviceMap;
		try {
			deEnrollDeviceMap = objectMapper.readValue(messageBody, HashMap.class);
		} catch (IOException ioex) {
			log.error("Exception occurred in DeviceDeEnrollRequestProcessor while parsing Body ::" + ioex.getMessage() + " and Exception :: " + ioex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		validateMap(deEnrollDeviceMap, CommonDefs.DEVICE_DEENROLL_MANDATORY_FIELDS);
		if (MapUtils.isNotEmpty(deEnrollDeviceMap)) {
			stBillingId = (String) deEnrollDeviceMap.get(CommonDefs.EMM_ACCOUNT_ID);
			deviceIdList = (ArrayList<String>) deEnrollDeviceMap.get(CommonDefs.DEVICE_IDS);

		}
		if (deviceIdList.size() > CommonDefs.MAX_NO_OF_DEVICES) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.MAX_DEVICE_MESSAGE);
		}

		deEnrollDeviceMap.put(CommonDefs.BILLING_ID, stBillingId);
		deEnrollDeviceMap.put(CommonDefs.DEVICE_LIST, deviceIdList);
		deEnrollDeviceMap.put(CommonDefs.IBM_URL, deEnrollDeviceIBMUrl + CommonDefs.FORWARD_SLASH + stBillingId);
		log.info("Setting Header IBMUrl_DE_ENROLL=" + deEnrollDeviceIBMUrl);
		e.getOut().setHeaders(deEnrollDeviceMap);
		e.getOut().setHeader(CommonDefs.BILLING_ID, stBillingId);

	}

	public final void split(Exchange e) throws ApigwException {

		String strDeviceId = (String) e.getIn().getBody();
		if (StringUtils.isEmpty(strDeviceId)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.DEVICE_ID_NULL_INPUT);
		}
		log.info("split with body ::" + strDeviceId);
		HashMap<String, String> velocityContextMap = new HashMap<>();
		velocityContextMap.put(CommonDefs.DEVICE_ID, strDeviceId);

		VelocityContext velocityContext = new VelocityContext(velocityContextMap);
		e.getIn().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);

	}

}