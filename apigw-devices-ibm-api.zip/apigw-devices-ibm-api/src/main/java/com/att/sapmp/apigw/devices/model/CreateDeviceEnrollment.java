package com.att.sapmp.apigw.devices.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class CreateDeviceEnrollment {
	
	Map<Object, Object> deviceEnrollment;

	public Map<Object, Object> getDeviceEnrollment() {
		return deviceEnrollment;
	}

	public void setDeviceEnrollment(Map<Object, Object> deviceEnrollment) {
		this.deviceEnrollment = deviceEnrollment;
	}

}
