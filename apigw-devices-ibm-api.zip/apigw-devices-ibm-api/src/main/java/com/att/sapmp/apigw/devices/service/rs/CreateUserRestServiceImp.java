package com.att.sapmp.apigw.devices.service.rs;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;

import org.springframework.web.bind.annotation.RequestBody;

import com.att.ajsc.common.AjscService;
import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.model.DeviceUser;

import io.swagger.annotations.ApiParam;
@AjscService
public class CreateUserRestServiceImp implements CreateUserRestService{

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateUserRestServiceImp.class);

	public CreateUserRestServiceImp() {
		// needed for autowiring
	}
	@POST 
	@Override
	public void createLocalUser(@HeaderParam(value = "Authorization") String authorization,@HeaderParam(value = "EMMProductCode") String productCode,@HeaderParam(value = "AccountPassPhrase") String accountpassphrase,@HeaderParam(value = "TrackingID") String trackingid,@PathParam("userName") String userName , @ApiParam(value = "Create User Request Object", required = true) @RequestBody DeviceUser user){
		log.info("Received request in createlocaluseraccount API. userName");
	}

}
