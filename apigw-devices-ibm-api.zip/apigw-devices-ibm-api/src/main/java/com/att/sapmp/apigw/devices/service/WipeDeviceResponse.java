package com.att.sapmp.apigw.devices.service;

import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.model.WipeDevices;
import com.att.sapmp.apigw.devices.util.CommonDefs;

/**
 * @author vn212m
 *
 */
@Component
public class WipeDeviceResponse {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(WipeDeviceResponse.class);

	public final void handleResponse(Exchange e) throws Exception {

		WipeDevices wipeDevice = (WipeDevices) e.getIn().getBody();
		Map<Object, Object> responseMap = wipeDevice.getActionResponse();
		e.getOut().setHeaders(e.getIn().getHeaders());
		JSONObject responseJSON = new JSONObject(responseMap);
		e.getOut().setBody(responseJSON);
		log.info("WipeDeviceResponse Response from IBM for WipeDevice = " + responseMap);

		if (isMandatoryAttributeinResponse(responseMap)) {
			if (CommonDefs.ZERO.equals(String.valueOf(responseMap.get(CommonDefs.ACTION_STATUS)))) {
				e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
			} else {
				e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, e.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE));
				responseMap.remove(CommonDefs.ACTION_STATUS);
				responseMap.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4001);
				e.getOut().setBody(responseMap);
			}
		}
	}

	public final void handleNoContentResponse(Exchange e) throws Exception {

		JSONObject jsonError = new JSONObject();
		jsonError.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4001);
		e.getOut().setHeaders(e.getIn().getHeaders());
		jsonError.put(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4001_DESCRIPTION);
		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
		e.getOut().setBody(jsonError);

	}

	private boolean isMandatoryAttributeinResponse(Map<Object, Object> responseMap) {
		return responseMap != null && responseMap.get(CommonDefs.MASS_360_DEVICE_ID) != null
				&& responseMap.get(CommonDefs.ACTION_STATUS) != null;
	}
}
