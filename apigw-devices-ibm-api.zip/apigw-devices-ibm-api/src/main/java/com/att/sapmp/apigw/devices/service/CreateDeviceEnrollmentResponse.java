package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.model.CreateDeviceEnrollment;
import com.att.sapmp.apigw.devices.util.CommonDefs;

/**
 * @author av0041
 *
 */
@Component
public class CreateDeviceEnrollmentResponse {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateDeviceEnrollmentResponse.class);

	public final void handleResponse(Exchange e) throws Exception {
		CreateDeviceEnrollment createDeviceEnrollment = (CreateDeviceEnrollment) e.getIn().getBody();
		Map<Object, Object> createDeviceEnrollmentMap = createDeviceEnrollment.getDeviceEnrollment();
		String stStatusCode = String.valueOf(e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		if (createDeviceEnrollmentMap != null && !createDeviceEnrollmentMap.isEmpty()) {
			log.info("Response from CreateDeviceEnrollmentResponse API +" + createDeviceEnrollmentMap + "  StatusCode:: "
					+ stStatusCode);
			if (!createDeviceEnrollmentMap.containsKey(CErrorDefs.ERROR_CODE)) {
				if (createDeviceEnrollmentMap.containsKey(CommonDefs.URL)
						&& createDeviceEnrollmentMap.containsKey(CommonDefs.CORPORATE_IDENTIFIER)
						&& createDeviceEnrollmentMap.containsKey(CommonDefs.PASSCODE)
						&& createDeviceEnrollmentMap.containsKey(CommonDefs.QR_CODE_URL)) {
					e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_CREATED_CODE);
					JSONObject jsonResponse = new JSONObject(createDeviceEnrollmentMap);
					e.getOut().setBody(jsonResponse);
					e.setProperty(CommonDefs.SMSPARAMETERS, createDeviceEnrollmentMap);
				}
			} else if (createDeviceEnrollmentMap.containsKey(CErrorDefs.ERROR_CODE)) {
				processEnrollmentResponse(stStatusCode, createDeviceEnrollmentMap, e);
			} else {
				e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, e.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE));
				Map<String, String> hmBody = new HashMap<>();
				hmBody.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_1001);
				hmBody.put(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_ENROLL_DEVICE);
				e.getOut().setBody(hmBody);
			}
		} else {
			String responseBody = (String) e.getProperty(CommonDefs.RESPONSE_BODY);
			log.info("Response from CreateDeviceEnrollmentResponse API =" + responseBody + "  StatusCode:: "
					+ stStatusCode);
			e.getIn().setBody(e.getProperty(CommonDefs.RESPONSE_BODY));
		}
	}

	private void processEnrollmentResponse(String stStatusCode, Map<Object, Object> createDeviceEnrollmentMap,
			Exchange e) {
		String vendorErrorMsg = "";
		JSONObject createDeviceEnrollmentJsonRes = new JSONObject();
		if (stStatusCode.equals(CommonDefs.RESPONSE_SUCCESS_CODE)) {
			if (createDeviceEnrollmentMap.containsKey(CErrorDefs.ERROR_MESSAGE)) {
				vendorErrorMsg = String.valueOf(createDeviceEnrollmentMap.get(CErrorDefs.ERROR_MESSAGE));
			}
			e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
			e.getOut().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
			e.getOut().setHeader(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4002_DESCRIPTION + vendorErrorMsg);
			createDeviceEnrollmentJsonRes.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
			createDeviceEnrollmentJsonRes.put(CErrorDefs.DESCRIPTION,
					CErrorDefs.ERROR_CODE_4002_DESCRIPTION + vendorErrorMsg);
		} else {
			e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_500);
			createDeviceEnrollmentJsonRes.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
			createDeviceEnrollmentJsonRes.put(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4002_DESCRIPTION);
		}
		e.getOut().setBody(createDeviceEnrollmentJsonRes);
	}
}
