package com.att.sapmp.apigw.devices.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@ApiModel(value = "EnrollDevice", description = " input payload")
public  class DeEnrollDevice {
	
	String emmAccountId;
    String[] deviceIds;
    
	public DeEnrollDevice(@com.fasterxml.jackson.annotation.JsonProperty("emmAccountId") String emmAccountId, @com.fasterxml.jackson.annotation.JsonProperty("deviceIds") String[] deviceIds){
        this.emmAccountId = emmAccountId;
        this.deviceIds = deviceIds;
    }
	
    public void setEmmAccountId(String emmAccountId) {
		this.emmAccountId = emmAccountId;
	}


	public void setDeviceIds(String[] deviceIds) {
		this.deviceIds = deviceIds;
	}

    @ApiModelProperty(value = "EmmAccountId", example = "30058930")
    public String getEmmAccountId() {
		return emmAccountId;
	}

    @ApiModelProperty(value = "deviceIds")
	public String[] getDeviceIds() {
		return deviceIds;
	}

}