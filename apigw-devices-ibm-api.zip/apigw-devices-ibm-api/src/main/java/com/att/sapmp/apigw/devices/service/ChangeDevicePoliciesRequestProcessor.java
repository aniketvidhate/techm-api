package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.component.velocity.VelocityConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author AD574A
 *
 */
@Component
public class ChangeDevicePoliciesRequestProcessor extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(ChangeDevicePoliciesRequestProcessor.class);
	@Value("${ibm.device.policy.url}")
	private String changePolicyUrl;

	public final void execute(Exchange e) throws ApigwException {

		String stAccountId = null;
		String stPlatform = null;
		String stPasscodePolicyCode = null;
		String stSecurityPolicyCode = null;
		String stPolicyName = null;
		StringBuilder changeDevicePolicyUrlBase = new StringBuilder(changePolicyUrl);

		String postRequestedUrl = (String) e.getIn().getHeader(CommonDefs.CAMEL_HTTP_URL);
		String[] splitUrl = postRequestedUrl.split(CommonDefs.FORWARD_SLASH);
		String stdevieceId = splitUrl[splitUrl.length - 2].trim();
		if (stdevieceId == null) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.DEVICE_ID_NULL_INPUT);
		}
		String messageBody = e.getIn().getBody(String.class);
		log.info("Input request to ChangeDevicePoliciesRequestProcessor=" + messageBody);
		if (messageBody == null) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.INVALID_INPUT_BILLINGID);
		}
		if (StringUtils.isEmpty(messageBody)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}

		JSONObject postReqJSON = new JSONObject();
		try {
			postReqJSON = new JSONObject(messageBody);
		} catch (JSONException jsex) {
			log.error("Exception occurred in ChangeDevicePoliciesRequestProcessor while parsing post request: "
					+ jsex.getMessage());
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1003_DESCRIPTION);
		}

		validateJSON(postReqJSON, CommonDefs.CHANGE_POLICY_DEVICE_MANDATORY_FIELDS);

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> changePolicyMap;
		try {
			changePolicyMap = objectMapper.readValue(messageBody, HashMap.class);

		} catch (IOException ioex) {
			log.error("Exception occurred while parsing Body ::" + ioex.getMessage() + " and Exception :: " + ioex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		if (changePolicyMap == null || changePolicyMap.isEmpty()) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.BODY_NULL_INPUT);
		} else {
			stAccountId = (String) changePolicyMap.get(CommonDefs.EMM_ACCOUNT_ID);
			stPlatform = (String) changePolicyMap.get(CommonDefs.PLATFORM);
			stPasscodePolicyCode = (String) changePolicyMap.get(CommonDefs.PASSCODE_POLICY_CODE);
			stSecurityPolicyCode = (String) changePolicyMap.get(CommonDefs.SECURITY_POLOCY_CODE);
			stPolicyName = getPolicySet(stPlatform, stSecurityPolicyCode, stPasscodePolicyCode);
		}
		changeDevicePolicyUrlBase.append(CommonDefs.FORWARD_SLASH + stAccountId);
		String changeDevicePolicyUrl = changeDevicePolicyUrlBase.toString();

		if (!CommonDefs.PLATFORM_CODE_VALUES.contains(stPlatform)) {
			e.getOut().setHeaders(e.getIn().getHeaders());
			e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_400);
			e.getOut().setHeader(CErrorDefs.DESCRIPTION, CommonDefs.INVALID_PLATFORM_REQUEST);
			e.getOut().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_1001);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.INVALID_PLATFORM_REQUEST);
		}
		if (!CommonDefs.PASSCODE_POLICY_CODE_VALUES.contains(stPasscodePolicyCode)) {
			e.getOut().setHeaders(e.getIn().getHeaders());
			e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_400);
			e.getOut().setHeader(CErrorDefs.DESCRIPTION, CommonDefs.INVALID_PASSCODE_POLICY_CODE_REQUEST);
			e.getOut().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_1001);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.INVALID_PASSCODE_POLICY_CODE_REQUEST);
		}
		if (!CommonDefs.SECURITY_POLICY_CODE_VALUES.contains(stSecurityPolicyCode)) {
			e.getOut().setHeaders(e.getIn().getHeaders());
			e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_400);
			e.getOut().setHeader(CErrorDefs.DESCRIPTION, CommonDefs.INVALID_SECURITY_POLICY_CODE_REQUEST);
			e.getOut().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_1001);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.INVALID_SECURITY_POLICY_CODE_REQUEST);
		}

		changePolicyMap.put(CommonDefs.DEVICE_IDS, stdevieceId);
		changePolicyMap.put(CommonDefs.POLICY_DETAILS, stPolicyName);

		e.getOut().setHeader(CommonDefs.IBM_URL, changeDevicePolicyUrl);
		e.getOut().setHeader(CommonDefs.BILLING_ID, stAccountId);

		VelocityContext velocityContext = new VelocityContext(changePolicyMap);
		e.getOut().setHeader(VelocityConstants.VELOCITY_CONTEXT, velocityContext);

	}

	private String getPolicySet(String platform, String securityPolicyCode, String passcodePolicyCode) {
		String policySet = null;
		policySet = platform + CommonDefs.UNDERSCORE + securityPolicyCode + passcodePolicyCode;
		return policySet;

	}

}