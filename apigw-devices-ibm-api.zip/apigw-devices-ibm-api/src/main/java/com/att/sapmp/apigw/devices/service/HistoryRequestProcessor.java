package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

@SuppressWarnings("unchecked")
@Component
public class HistoryRequestProcessor extends BaseProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(HistoryRequestProcessor.class);
	@Value("${ibm.search.device.history.url}")
	private String searchDeviceUrl;

	public final void execute(Exchange e) throws ApigwException {
		String stIBMSearchDeviceUrlFinal = "";
		StringBuilder stIBMSearchDeviceUrlBase = new StringBuilder(searchDeviceUrl);
		String stEmmAccountId = null;
		Map<String, Object> requestMap = InitializationService.getHistoryRequestparammap();
		String searchcriteria = (String) (e.getIn().getHeader(CommonDefs.SEARCH_CRITERIA));
		if (StringUtils.isEmpty(searchcriteria)) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		HashMap<String, Object> searchMap = null;
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			searchMap = objectMapper.readValue(searchcriteria, HashMap.class);
		} catch (IOException ioex) {
			log.error("Exception occurred in HistoryRequestProcessor while parsing searchcriteria::" + ioex.getMessage()
					+ " and Exception :: " + ioex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		if (!searchMap.isEmpty()) {
			stEmmAccountId = (String) searchMap.get(CommonDefs.EMM_ACCOUNT_ID);
			String stactionExecutionTimeFrom = (String) searchMap.get(CommonDefs.ACT_EXECUTION_TIME_FROM);
			String stactionExecutionTimeTo = (String) searchMap.get(CommonDefs.ACT_EXECUTION_TIME_TO);
			JSONObject postReqJSON = new JSONObject(searchMap);
			validateJSONReq(postReqJSON, CommonDefs.Action_History_Mandatory_Param, e);
			Date stactionExecutionTimeFromDate = this.validateDate(stactionExecutionTimeFrom);
			if (stactionExecutionTimeFromDate == null)
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.INCORRECT_ACTIONEXECUTIONTIME_FROM);
			DateFormat df = new SimpleDateFormat(CommonDefs.DATE_FORMAT);
			try {
				String newDateString = df.format(stactionExecutionTimeFromDate);
				searchMap.put(CommonDefs.ACT_EXECUTION_TIME_FROM, newDateString);
			} catch (Exception e1) {
				log.error("Exception occurred in HistoryRequestProcessor while parsing  request: " + e1);
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
			}
			Date stactionExecutionTimeToDate = this.validateDate(stactionExecutionTimeTo);
			if (stactionExecutionTimeToDate == null)
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.INCORRECT_ACTIONEXECUTIONTIME_TO);
			try {
				String newDateString = df.format(stactionExecutionTimeToDate);
				searchMap.put(CommonDefs.ACT_EXECUTION_TIME_TO, newDateString);
			} catch (Exception e1) {
				log.error("Exception occurred in HistoryRequestProcessorwhile parsing request: " + e1);
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
			}

			if (stactionExecutionTimeFromDate.compareTo(stactionExecutionTimeToDate) > 0) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001,
						CommonDefs.ACTIONEXECUTIONTIME_FROM_AFTER_ACTIONEXECUTIONTIME_TO);
			}
			stIBMSearchDeviceUrlBase.append(CommonDefs.FORWARD_SLASH + stEmmAccountId);
			stIBMSearchDeviceUrlFinal = stIBMSearchDeviceUrlBase.toString();
			searchMap.remove(CommonDefs.EMM_ACCOUNT_ID);
			if (!searchMap.isEmpty()) {
				stIBMSearchDeviceUrlBase.append(CommonDefs.QUESTION_MARK);
				for (Map.Entry<String, Object> entry : searchMap.entrySet()) {
					stIBMSearchDeviceUrlBase.append(requestMap.get(entry.getKey()) + CommonDefs.EQUAL_SIGN
							+ entry.getValue() + CommonDefs.AMPERCEND);
				}
				stIBMSearchDeviceUrlFinal = stIBMSearchDeviceUrlBase.substring(0,
						stIBMSearchDeviceUrlBase.length() - 1);
			}
		}
		log.info("HistoryRequestProcessor Setting Header IBMUrl=" + stIBMSearchDeviceUrlFinal);
		e.getOut().setHeader(CommonDefs.IBM_URL, stIBMSearchDeviceUrlFinal);
		e.getOut().setHeader(CommonDefs.BILLING_ID, stEmmAccountId);
	}

	public Date validateDate(String date) throws ApigwException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH);
		Date parsedDate;
		try {
			parsedDate = sdf.parse(date);
			return parsedDate;
		} catch (ParseException e2) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001,
					"Incorrect date format,Please Provide date in yyyy-MM-dd'T'HH:mm:ss format");
		}
	}
}