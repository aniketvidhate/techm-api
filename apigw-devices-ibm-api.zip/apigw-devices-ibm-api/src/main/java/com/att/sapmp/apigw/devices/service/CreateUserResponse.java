package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.model.CreateUser;
import com.att.sapmp.apigw.devices.util.CommonDefs;

/**
 * @author av0041
 *
 */
@Component
public class CreateUserResponse {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(CreateUserResponse.class);

	public final void handleResponse(Exchange e) throws Exception {
		CreateUser createUser = (CreateUser) e.getIn().getBody();
		Map<Object, Object> createUserMap = createUser.getResponse();
		if (createUserMap != null && !createUserMap.isEmpty()) {
			if (createUserMap.containsKey(CommonDefs.STATUS)) {
				if (createUserMap.get(CommonDefs.STATUS).toString().equals(CommonDefs.ZERO)) {
					e.getOut().setHeader(CommonDefs.AUTH_TOKEN, e.getIn().getHeader(CommonDefs.AUTH_TOKEN));
					e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_CREATED_CODE);
					e.getOut().setBody(createUserMap);
				} else {
					if (createUserMap.get(CommonDefs.DESCRIPTION).equals(CErrorDefs.ERROR_USER_EXITS)) {
						e.getOut().setHeader(CommonDefs.AUTH_TOKEN, e.getIn().getHeader(CommonDefs.AUTH_TOKEN));
						e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_CREATED_CODE);
					} else {
						e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_400);
					}
					Map<String, String> bodyMap = new HashMap<>();
					bodyMap.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_1001);
					bodyMap.put(CErrorDefs.DESCRIPTION, createUserMap.get(CommonDefs.DESCRIPTION).toString());
					e.getOut().setBody(bodyMap);
				}
			} else if (createUserMap.containsKey(CErrorDefs.ERROR_CODE)) {
				processCreateUSerSuccessFail(createUserMap, e);
			}
		} else {
			e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, e.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE));
			Map<String, String> bodyMap = new HashMap<>();
			bodyMap.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_1001);
			bodyMap.put(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_ENROLL_DEVICE);
			e.getOut().setBody(bodyMap);
		}
		log.info("Response from CreateUserResponse API " + e.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE));
	}

	private void processCreateUSerSuccessFail(Map<Object, Object> createUserMap, Exchange e) {
		JSONObject createUserJsonRes = new JSONObject();
		String vendorErrorMsg = "";
		String stStatusCode = String.valueOf(e.getIn().getHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE));
		if (stStatusCode.equals(CommonDefs.RESPONSE_SUCCESS_CODE)) {
			if (createUserMap.containsKey(CErrorDefs.ERROR_MESSAGE)) {
				vendorErrorMsg = String.valueOf(createUserMap.get(CErrorDefs.ERROR_MESSAGE));
			}
			e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
			e.getOut().setHeader(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
			e.getOut().setHeader(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4002_DESCRIPTION + vendorErrorMsg);
			createUserJsonRes.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
			createUserJsonRes.put(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4002_DESCRIPTION + vendorErrorMsg);
		} else {
			e.getOut().setHeader(Exchange.HTTP_RESPONSE_CODE, CErrorDefs.ERROR_CODE_500);
			createUserJsonRes.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4002);
			createUserJsonRes.put(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4002_DESCRIPTION);
		}
		e.getOut().setBody(createUserJsonRes);
	}
}
