package com.att.sapmp.apigw.devices.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)

@ApiModel(value = "LockDevice", description = "LockDevice - input payload")
public class LockDeviceModel {

	  @JsonProperty
	  private String emmAccountId;
	  @ApiModelProperty(value = "emmAccountId", example = "30058930")
	  public String getEmmAccountId() { return this.emmAccountId; }

	  public void setEmmAccountId(String emmAccountId) { this.emmAccountId = emmAccountId; }
	 
	

}
