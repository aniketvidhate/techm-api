
package com.att.sapmp.apigw.devices.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@Controller
@RequestMapping("/velocity")
public class VelocityRouterController {


	@RequestMapping(value = "/demo", method = RequestMethod.GET)
	public String velocityTemp() {
		return "index";
	}

	@RequestMapping(value = "/demo1", method = RequestMethod.GET)
	public String velocityTpldemo() {
		return "demo1";
	}

	

}
