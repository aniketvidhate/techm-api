package com.att.sapmp.apigw.devices.model;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@Component
public class ComplianceNotification {
	
	Map<Object, Object> mdmNotification;

	public Map<Object, Object> getMdmNotification() {
		return mdmNotification;
	}

	public void setMdmNotification(Map<Object, Object> mdmNotification) {
		this.mdmNotification = mdmNotification;

	}

}
