package com.att.sapmp.apigw.devices.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class DeviceUser {
	@JsonProperty
	  private String firstName;

	  public String getFirstName() { return this.firstName; }
	  @ApiModelProperty(value = "firstName", example = "John")
	  public void setFirstName(String firstName) { this.firstName = firstName; }
	  @JsonProperty
	  private String lastName;

	  public String getLastName() { return this.lastName; }
	  @ApiModelProperty(value = "lastName", example = "Lowry")
	  public void setLastName(String lastName) { this.lastName = lastName; }
	  
	  @JsonProperty
	  private String emmAccountId;

	  public String getEmmAccountId() { return this.emmAccountId; }
	  @ApiModelProperty(value = "emmAccountId", example = "123456789")
	  public void setEmmAccountId(String emmAccountId) { this.emmAccountId = emmAccountId; }
	  
	  @JsonProperty
	  private String subscriberNumber;

	  public String getSubscriberNumber() { return this.subscriberNumber; }
	  @ApiModelProperty(value = "subscriberNumber", example = "4699099424")
	  public void setSubscriberNumber(String subscriberNumber) { this.subscriberNumber = subscriberNumber; }
	  @JsonProperty
	  private String email;

	  public String getEmail() { return this.email; }
	  @ApiModelProperty(value = "email", example = "4699099424@txt.att.com")
	  public void setEmail(String email) { this.email = email; }
	  @JsonProperty
	  private String domain;

	  public String getDomain() { return this.domain; }
	  @ApiModelProperty(value = "domain", example = "att.com")
	  public void setDomain(String domain) { this.domain = domain; }
	  @JsonProperty
	  private String ctn;

	public String getCtn() {
		return ctn;
	}
	 @ApiModelProperty(value = "ctn", example = "9725679737")
	public void setCtn(String ctn) {
		this.ctn = ctn;
	}
	  
	

}
