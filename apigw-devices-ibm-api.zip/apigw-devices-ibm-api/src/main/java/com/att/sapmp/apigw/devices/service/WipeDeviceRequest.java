package com.att.sapmp.apigw.devices.service;

import org.apache.camel.Exchange;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;

/**
 * @author vn212m
 *
 */
@Component
public class WipeDeviceRequest extends BaseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(WipeDeviceRequest.class);

	@Value("${ibm.selectivewipe.device.url}")
	private String selectiveWipeDeviceURL;

	@Value("${ibm.wipe.device.url}")
	private String wipeDeviceURL;

	public final void execute(Exchange e) throws ApigwException {

		String wipeDeviceUrlBase;
		String reqUrl = (String) e.getIn().getHeader(CommonDefs.CAMEL_HTTP_URL);

		String[] urlArr = reqUrl.split(CommonDefs.FORWARD_SLASH);
		log.info("WipeDeviceRequest Request = " + reqUrl);
		String deviceId = urlArr[urlArr.length - 2];

		if (deviceId == null || deviceId.isEmpty()) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_400, CommonDefs.DEVICE_ID_NULL_INPUT);
		}
		String postReq = (String) (e.getIn().getBody());
		log.info("WipeDeviceRequest Pay load for Wipe Device IBM API :: " + postReq);

		if (postReq == null || postReq.isEmpty()) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_400, CommonDefs.EMPTY_REQUEST);
		}

		JSONObject postReqJSON = new JSONObject();
		try {
			postReqJSON = new JSONObject(postReq);
		} catch (JSONException jsex) {
			log.error("Exception occurred while parsing post request: " + jsex.getMessage());
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1003_DESCRIPTION);
		}

		validateJSON(postReqJSON, CommonDefs.WIPE_DEVICE_MANDATORY_FIELDS);

		wipeDeviceUrlBase = getwipeDeviceUrl(
				String.valueOf(postReqJSON.get(CommonDefs.WIPE_DEVICE_MANDATORY_FIELDS[1])),
				String.valueOf(postReqJSON.get(CommonDefs.WIPE_DEVICE_MANDATORY_FIELDS[0])), deviceId);
		log.info("WipeDeviceRequest IBM WipeDevice Final URL = " + wipeDeviceUrlBase);
		e.getOut().setHeader(CommonDefs.IBM_WIPE_DEVICE_FINAL_URL, wipeDeviceUrlBase);
		e.getOut().setHeader(CommonDefs.WIPE_TYPE,String.valueOf(postReqJSON.get(CommonDefs.WIPE_DEVICE_MANDATORY_FIELDS[1])));
		e.getOut().setHeader(CommonDefs.BILLING_ID, String.valueOf(postReqJSON.get(CommonDefs.EMM_ACCOUNT_ID)));
	}

	private String getwipeDeviceUrl(String wipeType, String billingId, String deviceId) throws ApigwException {
		switch (wipeType) {
		case CommonDefs.ZERO:
			return wipeDeviceURL + CommonDefs.FORWARD_SLASH + billingId + CommonDefs.APPEND_DEVICE_ID + deviceId;
		case CommonDefs.ONE:
			return selectiveWipeDeviceURL + CommonDefs.FORWARD_SLASH + billingId + CommonDefs.APPEND_DEVICE_ID + deviceId;
		default:
			throw new ApigwException(CErrorDefs.ERROR_CODE_400, CommonDefs.INVALID_WIPETYPE_COMMNET + wipeType);
		}
	}

}