package com.att.sapmp.apigw.devices.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.model.History;
import com.att.sapmp.apigw.devices.util.CommonDefs;

@Component
public class HistoryResponseProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(HistoryResponseProcessor.class);

	public final void handleResponse(Exchange e) throws Exception {
		Map<String, Object> responseParamMap = InitializationService.getHistryResponseparammap();
		History oHis = (History) e.getIn().getBody();
		Object oHistories = oHis.getHistory().get(CommonDefs.ACT_STATUS_RESPONSE);
		HashMap<String, Object> historyResponseMap = new HashMap<>();
		ArrayList<HashMap<String, Object>> historyList = new ArrayList<>();
		HashMap<String, Object> singleHistoryMap = null;
		if (oHistories instanceof ArrayList) {
			ArrayList<HashMap> historysList = (ArrayList<HashMap>) oHistories;
			for (HashMap<String, Object> deviceMap : historysList) {
				Iterator<String> itResponse = responseParamMap.keySet().iterator();
				singleHistoryMap = new HashMap<>();
				while (itResponse.hasNext()) {
					String stKey = itResponse.next();
					if (deviceMap.containsKey(stKey)) {
						singleHistoryMap.put((String) responseParamMap.get(stKey), deviceMap.get(stKey));
					}
				}
				historyList.add(singleHistoryMap);
			}
			historyResponseMap.put(CommonDefs.ACT_STATUS_RESP, historyList);
		} else if (oHistories instanceof HashMap) {
			HashMap<String, Object> deviceMap = (HashMap<String, Object>) oHistories;
			Iterator<String> itResponse = responseParamMap.keySet().iterator();
			singleHistoryMap = new HashMap<>();
			while (itResponse.hasNext()) {
				String stKey = itResponse.next();
				if (deviceMap.containsKey(stKey)) {
					singleHistoryMap.put((String) responseParamMap.get(stKey), deviceMap.get(stKey));
				}
			}
			historyResponseMap.put(CommonDefs.ACT_STATUS_RESP, singleHistoryMap);
		}
		JSONObject jsonHistories = new JSONObject();
		jsonHistories.put(CommonDefs.ACTION_HISTORY, historyResponseMap);
		log.info("HistoryResponseProcessor Response from InquireDeviceAction API " + jsonHistories);
		e.getOut().setBody(jsonHistories);
	}
}
