package com.att.sapmp.apigw.devices.service;

import org.apache.camel.Exchange;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;

/**
 * @author AD574A
 *
 */
@Component
public class DeviceDeEnrollResponseProcessor {

	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(DeviceDeEnrollResponseProcessor.class);

	public final void handleResponse(Exchange e) throws ApigwException {
		String stBody = e.getIn().getBody(String.class);
		log.info("Received response in DeviceDeEnrollResponseProcessor from MDM :" + stBody);
		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_ACCEPT_CODE);
		e.getOut().setBody(stBody);
	}
	
	public final void handleNoContentResponse(Exchange e) throws Exception {
		JSONObject jsonError = new JSONObject();
		e.getOut().setHeaders(e.getIn().getHeaders());
		jsonError.put(CErrorDefs.ERROR_CODE, CErrorDefs.ERROR_CODE_4001);
		jsonError.put(CErrorDefs.DESCRIPTION, CErrorDefs.ERROR_CODE_4001_DESCRIPTION);
		e.getOut().setHeader(CommonDefs.CAMEL_HTTP_RESPONSE_CODE, CommonDefs.RESPONSE_SUCCESS_CODE);
		e.getOut().setBody(jsonError);

	}
}