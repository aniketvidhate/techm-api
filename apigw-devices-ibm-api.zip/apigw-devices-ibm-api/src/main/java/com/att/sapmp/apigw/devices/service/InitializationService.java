package com.att.sapmp.apigw.devices.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.sapmp.apigw.devices.util.CommonDefs;


/**
 * @author pg238s
 *
 */
@Component
public class InitializationService {

	@Value("${ibm.response.transform.param}")
	private String responseParam;

	@Value("${ibm.request.transform.param}")
	private String requestParam;
	
	@Value("${ibm.history.response.transform.param}")
	private String responseHistoryParam;

	@Value("${ibm.history.request.transform.param}")
	private String requestHistoryParam;

	private static final HashMap<String, Object> responseParamMap = new HashMap<>();

	private static final HashMap<String, Object> requestParamMap = new HashMap<>();
	
	private static final HashMap<String, Object> responseHistoryParamMap = new HashMap<>();

	private static final HashMap<String, Object> requestHistoryParamMap = new HashMap<>();


	/**
	 * 
	 * This method read the properties from application.properties
	 * and parse it.
	 */

	private void init() {
		if (StringUtils.isNotEmpty(responseParam)) {
			String[] responsePair = responseParam.split(CommonDefs.COMMA);
			for (String pair : responsePair) {
				String[] kv = pair.split(CommonDefs.EQUAL_SIGN);
				responseParamMap.put(kv[0], kv[1]);
			}
		}

		if (StringUtils.isNotEmpty(requestParam)) {
			String[] requestPair = requestParam.split(CommonDefs.COMMA);
			for (String pair : requestPair) {
				String[] kv = pair.split(CommonDefs.EQUAL_SIGN);
				requestParamMap.put(kv[0], kv[1]);
			}
		}
		
		if (StringUtils.isNotEmpty(responseHistoryParam)) {
			String[] responsePair = responseHistoryParam.split(CommonDefs.COMMA);
			for (String pair : responsePair) {
				String[] kv = pair.split(CommonDefs.EQUAL_SIGN);
				responseHistoryParamMap.put(kv[0], kv[1]);
			}
		}

		if (StringUtils.isNotEmpty(requestHistoryParam)) {
			String[] requestPair = requestHistoryParam.split(CommonDefs.COMMA);
			for (String pair : requestPair) {
				String[] kv = pair.split(CommonDefs.EQUAL_SIGN);
				requestHistoryParamMap.put(kv[0], kv[1]);
			}
		}

	}

	public static Map<String, Object> getResponseparammap() {
		return responseParamMap;
	}

	public static Map<String, Object> getRequestparammap() {
		return requestParamMap;
	}

	public static Map<String, Object> getHistryResponseparammap() {
		return responseHistoryParamMap;
	}

	public static Map<String, Object> getHistoryRequestparammap() {
		return requestHistoryParamMap;
	}
}