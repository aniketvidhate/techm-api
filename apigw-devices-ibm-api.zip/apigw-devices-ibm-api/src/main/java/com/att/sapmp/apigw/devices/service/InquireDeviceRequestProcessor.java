package com.att.sapmp.apigw.devices.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.att.ajsc.logging.AjscEelfManager;
import com.att.eelf.configuration.EELFLogger;
import com.att.sapmp.apigw.devices.exception.ApigwException;
import com.att.sapmp.apigw.devices.exception.CErrorDefs;
import com.att.sapmp.apigw.devices.util.CommonDefs;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author pg238s
 *
 */
@Component
public class InquireDeviceRequestProcessor extends BaseProcessor {
	private static EELFLogger log = AjscEelfManager.getInstance().getLogger(InquireDeviceRequestProcessor.class);
	@Value("${ibm.search.device.url}")
	private String searchDeviceUrl;

	@Value("${ibm.search.apps.url}")
	private String searchAppsUrl;

	public final void execute(Exchange e) throws ApigwException {
		String stEmmAccountId = null;
		String stIBMSearchDeviceUrlFinal = "";
		StringBuilder stIBMSearchDeviceUrlBase = new StringBuilder(searchDeviceUrl);
		String stIBMSearchAppsUrl = searchAppsUrl;
		Map<String, Object> requestMap = InitializationService.getRequestparammap();
		String searchcriteria = (String) (e.getIn().getHeader(CommonDefs.SEARCH_CRITERIA));
		if (searchcriteria == null || searchcriteria.isEmpty()) {
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.SEARCH_CRITERIA_NULL_INPUT);
		}
		ObjectMapper objectMapper = new ObjectMapper();
		HashMap<String, Object> searchMap;
		try {
			searchMap = objectMapper.readValue(searchcriteria, HashMap.class);
		} catch (IOException ioex) {
			log.error("Exception occurred in InquireDeviceRequestProcessor while parsing searchcriteria::"
					+ ioex.getMessage() + " and Exception :: " + ioex);
			throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CErrorDefs.ERROR_CODE_1001_DESCRIPTION);
		}
		if (searchMap != null && !searchMap.isEmpty()) {
			stEmmAccountId = (String) searchMap.get(CommonDefs.EMM_ACCOUNT_ID);
			if (stEmmAccountId == null || stEmmAccountId.isEmpty()) {
				throw new ApigwException(CErrorDefs.ERROR_CODE_1001, CommonDefs.EMMACCOUNTID_NULL_INPUT);
			}
			String stDeviceId = (String) searchMap.get(CommonDefs.DEVICE_ID);
			if (stDeviceId != null && !stDeviceId.isEmpty()) {
				stIBMSearchAppsUrl = stIBMSearchAppsUrl + CommonDefs.FORWARD_SLASH + stEmmAccountId
						+ CommonDefs.APPEND_DEVICE_ID + stDeviceId;
				e.getOut().setHeader(CommonDefs.IBM_SEARCH_APP_URL, stIBMSearchAppsUrl);
			}
			stIBMSearchDeviceUrlBase.append(CommonDefs.FORWARD_SLASH + stEmmAccountId);
			stIBMSearchDeviceUrlFinal = stIBMSearchDeviceUrlBase.toString();
			searchMap.remove(CommonDefs.EMM_ACCOUNT_ID);
			if (!searchMap.isEmpty()) {
				stIBMSearchDeviceUrlBase.append(CommonDefs.QUESTION_MARK);
				for (Map.Entry<String, Object> entry : searchMap.entrySet()) {
					stIBMSearchDeviceUrlBase.append(requestMap.get(entry.getKey()) + CommonDefs.EQUAL_SIGN
							+ entry.getValue() + CommonDefs.AMPERCEND);
				}
				stIBMSearchDeviceUrlFinal = stIBMSearchDeviceUrlBase.substring(0,
						stIBMSearchDeviceUrlBase.length() - 1);
			}
		}
		log.info("InquireDeviceRequestProcessor Setting InquireDeviceUrl =" + stIBMSearchDeviceUrlFinal);
		e.getOut().setHeader(CommonDefs.IBM_URL, stIBMSearchDeviceUrlFinal);
		e.getOut().setHeader(CommonDefs.BILLING_ID, stEmmAccountId);
	}

}