/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.List;

import org.apache.commons.lang.CharEncoding;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, metatype = true, label = "JCR Hash Generation Configuration")
@Service(value = com.att.ecom.cq.bundle.helpers.jcrsameness.JCRHashGeneratorConfig.class)
@Properties({ @Property(name = Constants.SERVICE_DESCRIPTION, value = "JCR Hash generator servlet configuration"),
        @Property(name = Constants.SERVICE_VENDOR, value = "CMS@ATT"),
        @Property(name = "process.label", value = "JCR Hash generator servlet configuration") })
/**
 * It contains the configuration required for the JCR hash generator servlet.
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884)
 * @Since Dec 28, 2012 11:13:39 AM
 */
public class JCRHashGeneratorConfig {

    @SuppressWarnings("rawtypes")
    private static Dictionary props = null;
    
    private static final Logger log = LoggerFactory.getLogger(JCRHashGeneratorConfig.class);

    @Property(label = "Excluded Properties", cardinality = 1, value = "jcr:uuid," +
    		                                                           "jcr:versionHistory," +
    		                                                           "jcr:predecessors," +
                                                                       "jcr:baseVersion," +
    		                                                           "jcr:created," +
                                                                       "jcr:createdBy," +
    		                                                           "cq:lastModified," +
    		                                                           "cq:lastModifiedBy," +
                                                                       "jcr:lastModified," +
                                                                       "jcr:lastModifiedBy," +
    		                                                           "cq:lastReplicated," +
    		                                                           "cq:lastReplicatedBy," +
                                                                       "jcr:lastReplicated," +
                                                                       "jcr:lastReplicatedBy," +
    		                                                           "cq:lastReplicationAction," +
                                                                       "jcr:lastReplicationAction," +                                                                       
    		                                                           "jiracomment," +
    		                                                           "jiraid," +
    		                                                           "validateOnAuthor," +
    		                                                           "doyouhaveJira," +
    		                                                           "validateOnFinalStage," +
    		                                                           "validateOnPreStg," +
    		                                                           "assignPreStgValidatorGroup," +
    		                                                           "workflowInitiator," +
    		                                                           "assignFinalStgValidatorGroup")
    private static final String EXCLUDED_PROPS_FROM_HASH_CALC = "excluded.properties";

    @Property(label = "Hash Algorithm Name", value = "MD5")
    private static final String HASH_ALGORITHM_NAME = "hash.algorithm";
    
    @Property(label = "Encoding Type", value = "UTF-8")
    private static final String ENCODE_TYPE_UTF_8 = CharEncoding.UTF_8;
    
	@Property(label = "Excluded Nodes", cardinality = 1, value = "rep:policy")
    private static final String EXCLUDED_NODES_FROM_HASH_CALC = "excluded.nodes";

    public List<String> mExcludedProperties = new ArrayList<String>();
    
    public List<String> mExcludedNodes = new ArrayList<String>();
    
    /**
     * It activates the component.
     * @param ctx ComponentContext object.
     */
    protected void activate(ComponentContext ctx) {
        log.info(" started JCRHashServletConfig ");
        props = ctx.getProperties();
        getExcludedPropsFromHashCalculation();
        getExcludedNodesFromHashCalculation();
    }
    
    /**
     * This will return a list of excluded properties. It takes the string as input param, splits it into tokens by comma(,) delimiter and adds each of it to a list.
     * @return List - list of excluded properties.
     */
    public List<String> getExcludedPropsFromHashCalculation() {
        String[] excludedProperties = ((String)(props.get(EXCLUDED_PROPS_FROM_HASH_CALC))).split(",");
        mExcludedProperties = (excludedProperties != null) ? Arrays.asList(excludedProperties) : null;
        return mExcludedProperties;
    }    

    public String getHashAlgorithmName() {
        return (String) props.get(HASH_ALGORITHM_NAME);
    }
    
    public String getEncodingType() {
        return (String) props.get(ENCODE_TYPE_UTF_8);
    }
    
    public List<String> getExcludedNodesFromHashCalculation() {
	    String[] excludedNodes = ((String)(props.get(EXCLUDED_NODES_FROM_HASH_CALC))).split(",");
	    mExcludedNodes = (excludedNodes != null) ? Arrays.asList(excludedNodes) : null;
	    return mExcludedNodes;
	}		
	
    protected void deactivate(ComponentContext ctx) {
        log.info(" stopped JCRHashServletConfig ");
        mExcludedProperties = null;
    }    
}
