/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2013 AT&T Knowledge Ventures All Rights Reserved.
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 *
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers;

import java.util.Set;

/**
 * This helper class has functions required by JSPs..
 * 
 * @author st124e
 * 
 */
public class ATTAngularAssist {

    /**
     * Add the param name to the Set of moduleNames param.
     * 
     * @param name
     * @param moduleNames
     */
    public static void setModuleName(String name, Set<String> moduleNames) {
        if (moduleNames != null) {
            moduleNames.add(name);
        }

    }

}
