/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is a runnable class for getting JCR hash. It makes a call to servlet that generates and returns the JCR hash
 * value as TreeMap. In TreeMap key is a JCR content path and value is it's hash value. Based on the input mode this
 * class will also fix the differences in target JCR.
 * 
 * @author Sunil Reddy Aleti
 * @since 10th January 2013
 */
public class JCRCompareCallable implements Callable<JCRCompareResponse> {

    public static final Logger LOGGER = LoggerFactory.getLogger(JCRCompareCallable.class);

    private JCRSamenessToolRequest mJCRSamenessToolRequest = null;

    private long mStartTime;

    private String mTargetHostName = null;

    private JCRSamenessToolHelper mJCRSamenessToolHelper;

    private Future<SortedMap<String, String>> mFuture = null;

    private String mOutputFolderName = null;

    /**
     * Constructor.
     */
    public JCRCompareCallable(Future<SortedMap<String, String>> pFuture, String pTargetHostName,
            JCRSamenessToolRequest pJCRSamenessToolRequest, JCRSamenessToolHelper pJCRSamenessToolHelper,
            long pStartTime, String pOutputFolderName) {
        mFuture = pFuture;
        mTargetHostName = pTargetHostName;
        mJCRSamenessToolRequest = pJCRSamenessToolRequest;
        mJCRSamenessToolHelper = pJCRSamenessToolHelper;
        mStartTime = pStartTime;
        mOutputFolderName = pOutputFolderName;
    }

    /**
     * Makes a URL connection to servlet and gets the generated JCR hash from target machine. Depending upon input mode,
     * it may also fix the target JCR if there are any differences.
     */
    @SuppressWarnings("unchecked")
    public JCRCompareResponse call() {
        mStartTime = System.currentTimeMillis();
        String modifiedTargetHostName = mJCRSamenessToolHelper.getModifiedHostName(mTargetHostName);
        String modifiedSourceHostName = mJCRSamenessToolHelper.getModifiedHostName(mJCRSamenessToolRequest.getSourceHost());
        SortedMap<String, String> targetJCRHash = null;
        SortedMap<String, String> sourceJCRHash = null;
        SortedMap<String, String> diffFromSourceToTarget = null;
        SortedMap<String, String> extraContentOnTarget = null,extraNodesOnTarget=null;
        SortedMap<String, String> errorTreeMap = new TreeMap<String, String>();
        
        JCRCompareResponse result = new JCRCompareResponse();
        result.setResponseKey(modifiedSourceHostName + " to " + modifiedTargetHostName);
        result.getDetailedResponse().setHostName(modifiedTargetHostName);
        String processName = "[" + modifiedSourceHostName + " to " + modifiedTargetHostName + " JCR compare ] ";
        String processName1 = "[Getting JCR hash for Target " + modifiedTargetHostName + " ] --> ";

        LOGGER.info(processName1 + "start.");

        try {
            targetJCRHash = mJCRSamenessToolHelper.getJCRHash(mTargetHostName, mJCRSamenessToolRequest,
                    JCRSamenessServlet.CONTENT_TYPE_OCTET_STREAM, JCRSamenessServlet.REQUEST_METHOD_GET);

            LOGGER.info(processName1 + " time taken is " + ((System.currentTimeMillis() - mStartTime) / 1000)
                    + " seconds");

            // DO NOT continue if target JCR is null
            if (targetJCRHash == null || targetJCRHash.size() < 1) {
                LOGGER.error(processName
                        + "STOPPED. Target JCR was not generated, we can not continue with JCR sameness process.");
                errorTreeMap.put("Target JCR was not generated", "Target JCR was not generated, we can not continue with JCR sameness process.");
                mJCRSamenessToolHelper.writeToFile( errorTreeMap, mOutputFolderName + File.separator + 
                        modifiedSourceHostName + "_to_" + modifiedTargetHostName + "_error.txt", null);
                result.setResponseValue("Target JCR was not generated, JCR sameness process ended abruptly.");
                return result;
            }

            if (mFuture == null) {
                LOGGER.error(processName
                        + "STOPPED. Source JCR generation has some problems, we can not continue with JCR sameness process.");
                errorTreeMap.put("Target JCR was not generated", "Source JCR generation has some problems, we can not continue with JCR sameness process.");   
                mJCRSamenessToolHelper.writeToFile( errorTreeMap, mOutputFolderName + File.separator + 
                        modifiedSourceHostName + "_to_" + modifiedTargetHostName + "_error.txt", null);   
                result.setResponseValue("Source JCR generation has some problems, JCR sameness process ended abruptly.");                
                return result;
            }

            sourceJCRHash = mFuture.get();

            // QUICK Compare
            String sourceRootHashValue = (sourceJCRHash != null) ? sourceJCRHash.get(mJCRSamenessToolRequest.getPath()) : null;
            String targetRootHashValue = (targetJCRHash != null) ? targetJCRHash.get(mJCRSamenessToolRequest.getPath()) : null;

            if (StringUtils.isNotEmpty(sourceRootHashValue) && sourceRootHashValue.equals(targetRootHashValue)) { // $codepro.audit.disable nullPointerDereference
                LOGGER.info(processName + " Root hash value MATCHED, so Source and Target JCR's are same. Writing hash values to text file.");
                mJCRSamenessToolHelper.writeToFile(sourceRootHashValue, targetRootHashValue, mOutputFolderName + File.separator + 
                        modifiedSourceHostName + "_to_" + modifiedTargetHostName + "_same.txt");
                result.setResponseValue("Matched.");
                result.getDetailedResponse().setResult("SAME");
                result.getDetailedResponse().setBackgroundColor("green");
                return result;
            } else {
                LOGGER.info(processName + " Root hash values not matched, starting deep compare. src root hash - " + sourceRootHashValue + ", target hash - " + targetRootHashValue);
            }
            // DEEP Compare
            Map<String, Object> diffResult = mJCRSamenessToolHelper.getDiffFromSourceToTarget(sourceJCRHash, targetJCRHash,mJCRSamenessToolRequest.isCheckOrder());
            if (diffResult != null) {
                diffFromSourceToTarget = (SortedMap<String, String>) diffResult.get("differences");
                Set<String> onlyModifiedPages = (Set<String>) diffResult.get("pagesOnly");
                if (diffFromSourceToTarget != null && diffFromSourceToTarget.size() > 0) {
                    LOGGER.info(processName + " There are differences, writing them into file.");
                    mJCRSamenessToolHelper.writeToFile(onlyModifiedPages, mOutputFolderName + File.separator + 
                            modifiedSourceHostName + "_to_" + modifiedTargetHostName + "_diff_pages.txt", result);
                    
                    // Create here the meta file which can be used later for activation
                    mJCRSamenessToolHelper.updatePageActivateMetaFile(mOutputFolderName + File.separator + modifiedSourceHostName + "_to_" + modifiedTargetHostName + "_diff_pages.txt", mTargetHostName);
                    
                    
                    mJCRSamenessToolHelper.writeToFile(diffFromSourceToTarget, mOutputFolderName + File.separator + 
                            modifiedSourceHostName + "_to_" + modifiedTargetHostName + "_diff.txt", result);
                    result.getDetailedResponse().setNumOfDifferences(diffFromSourceToTarget.size());
                    result.getDetailedResponse().setNumOfPagesAffectedDueToDiff(onlyModifiedPages.size());
                    result.getDetailedResponse().setResult("DIFFERENT");
                    result.setResponseValue("Differences found."); 
                    result.getDetailedResponse().setBackgroundColor("red");
                } else {
                    LOGGER.info(processName
                            + " No differences found when compared from source to target, checking if there is any extra content on target.");
                }
            }

            Map<String,Object> extraNodesOnTargetMap = mJCRSamenessToolHelper.getExtraContentOnTarget(sourceJCRHash, targetJCRHash);
            if(null != extraNodesOnTargetMap){
            	extraNodesOnTarget =  (SortedMap<String, String>)extraNodesOnTargetMap.get("extrasOnTarget");
            	if(null != extraNodesOnTarget && extraNodesOnTarget.size() > 0){
                    LOGGER.info(processName + " There is an extra NODES found on target, writing them into file.");
                    mJCRSamenessToolHelper.writeToFile(extraNodesOnTarget,  mOutputFolderName + File.separator + modifiedSourceHostName
                            + "_to_" + modifiedTargetHostName + "_extra.txt", result);
                    if (result.getResponseValue() != null) {
                        result.setResponseValue("Differences found. Also, Extra NODES on target found.");  
                    } else {
                        result.setResponseValue("Extra NODES on target found.");                    
                    }
                    result.getDetailedResponse().setResult("DIFFERENT");
                    result.getDetailedResponse().setBackgroundColor("red");
                } else {
                    LOGGER.info(processName + " There are no extra Nodes content found on target.");
            		
            	}
            	
            	Set<String> extraPagesOnTarget = (Set<String>) extraNodesOnTargetMap.get("extraNodesOnTarget");
            	if(null != extraPagesOnTarget && extraPagesOnTarget.size() > 0){
            		LOGGER.info(processName + " There is an extra PAGES found on target, writing them into file.");
            		mJCRSamenessToolHelper.writeToFile(extraPagesOnTarget,  mOutputFolderName + File.separator + modifiedSourceHostName+ "_to_" + modifiedTargetHostName + "_extra_pages.txt", result);
            	}else{
            		LOGGER.info(processName + " There are NO extra PAGES found on target.");
            	}
            	
            }
            
//            extraContentOnTarget = mJCRSamenessToolHelper.getExtraContentOnTarget(sourceJCRHash, targetJCRHash);
//            if (extraContentOnTarget != null && extraContentOnTarget.size() > 0) {
//                LOGGER.info(processName + " There is an extra content found on target, writing them into file.");
//                mJCRSamenessToolHelper.writeToFile(extraContentOnTarget,  mOutputFolderName + File.separator + modifiedSourceHostName
//                        + "_to_" + modifiedTargetHostName + "_extra.txt", result);
//                if (result.getResponseValue() != null) {
//                    result.setResponseValue("Differences found. Also, Extra content on target found.");  
//                } else {
//                    result.setResponseValue("Extra content on target found.");                    
//                }
//                result.getDetailedResponse().setResult("DIFFERENT");
//                result.getDetailedResponse().setBackgroundColor("red");
//            } else {
//                LOGGER.info(processName + " There is no extra content found on target.");
//            }
        } catch (MalformedURLException mfe) {
            LOGGER.error(processName + "MalformedURLException - ", mfe);
            errorTreeMap.put("MalformedURLException", mfe.toString()); // $codepro.audit.disable possibleNullPointer
        } catch (IOException ioe) {
            LOGGER.error(processName + "IOException - ", ioe);
            errorTreeMap.put("IOException", ioe.toString()); // $codepro.audit.disable possibleNullPointer
        } catch (ClassNotFoundException cnfe) {
            LOGGER.error(processName + "ClassNotFoundException - ", cnfe);
            errorTreeMap.put("ClassNotFoundException", cnfe.toString()); // $codepro.audit.disable possibleNullPointer
        } catch (InterruptedException ie) {
            LOGGER.error(processName + "MalformedURLException - ", ie);
            errorTreeMap.put("InterruptedException", ie.toString()); // $codepro.audit.disable possibleNullPointer
        } catch (ExecutionException ee) {
            LOGGER.error(processName + "MalformedURLException - ", ee);
            errorTreeMap.put("ExecutionException", ee.toString()); // $codepro.audit.disable possibleNullPointer
        } catch (Exception e) { // $codepro.audit.disable caughtExceptions
            LOGGER.error(processName + "Exception (Global Exception) - ", e);
            errorTreeMap.put("Runtime exception happened", e.toString()); // $codepro.audit.disable possibleNullPointer
        } finally {
            // cleanup resources
            targetJCRHash = null;
            diffFromSourceToTarget = null;
            extraContentOnTarget = null;
            if (errorTreeMap != null && errorTreeMap.size() > 0) {
                try {
                    mJCRSamenessToolHelper.writeToFile( errorTreeMap, mOutputFolderName + File.separator + 
                            modifiedSourceHostName + "_to_" + modifiedTargetHostName + "_error.txt", null);
                } catch (IOException e) {
                    LOGGER.error("IOException happened while handling finally block", e);
                }            
            }
            LOGGER.info(processName + " End. Total time is " + ((System.currentTimeMillis() - mStartTime) / 1000)
                    + " seconds");
        }
        return result;
    }
}
