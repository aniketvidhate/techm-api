/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.SortedMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.org.apache.xalan.internal.xsltc.NodeIterator;

/**
 * It is a JCR sameness tool. It's main functions is to compare the 2 JCR's and if there are any differences then fix
 * the problem automatically. It runs in multi-threaded fashion, hence it consumes same time regardless of number of
 * targets. One specific JCR is identified as a golden or correct and it is considered as source JCR. Each thread will
 * have 1 distinct target JCR. It's job is to compare source JCR to target JCR, if there are any differences then record
 * them in a file and save that file. Based on the input mode, if there are any differences recorded then they will be
 * fixed in the same thread.
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884)
 * @Since Jan 06, 2013 12:43:39 PM
 */

@SlingServlet(methods = { "GET", "POST" }, paths = { "/system/att/servlets/jcrsamenesstool" })
public class JCRSamenessServlet extends SlingAllMethodsServlet {

    /**
     * Serial Version UID
     */
    private static final long serialVersionUID = 1L;

    public static final Logger logger = LoggerFactory.getLogger(JCRSamenessServlet.class);

    public static final String PATH = "path";

    public static final String SOURCE_HOST = "sourceHost";

    public static final String TARGET_HOSTS = "targetHosts";

    public static final String MODE = "mode";

    public static final String FILE_LOCATION = "fileLoaction";

    public static final String EXCLUDED_PROPERTIES = "excludedProperties";

    public static final String EXCLUDED_NODES = "excludedNodes";    
    
    public static final String EMAIL_HOST = "emailHost";
    
    public static final String EMAIL_ADDRESSES = "emailAddresses";

    public static final String INCLUDE_DEACTIVATED_NODES = "includeDeactivatedNodes";
    
    public static final String CHECK_INTERMEDIATE_NODES_SAMENESS = "checkIntermediateNodesSameness";
    
    public static final String CONTENT_TYPE_OCTET_STREAM = "application/octet-stream;charset=UTF-8";

    public static final String REQUEST_METHOD_GET = "GET";

    public static final String REQUEST_METHOD_POST = "POST";

    private ExecutorService mJCRSamenessExecutor = null;

    @Reference
    private JCRSamenessToolHelper mJCRSamenessToolHelper;
    
    @Reference
    private JCRSamenessEmailSender mJCRSamenessEmailSender;

    public void init(ServletConfig config) throws ServletException {
        
    }

    /**
     * It compares the Target JCR's with a source JCR and record the differences or sameness by writing that result in a
     * text file.
     * 
     * @param pRequest
     *            a HttpServletRequest value.
     * @param pResponse
     *            a HttpServletResponse value.
     * @exception ServletException
     *                if there was an error while executing the code.
     * @exception IOException
     *                if there was an error with servlet io.
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    protected void doPost(SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse)
            throws ServletException, IOException {
        int availbaleProcessors = Runtime.getRuntime().availableProcessors();

        
        List futureObjects = null;
        List<JCRCompareResponse> jcrCompareResponseList = null;
        try {
            long startTime = System.currentTimeMillis();
            logger.info("JCR sameness process started.");

            JCRSamenessToolRequest inputBean = populateInputBean(pRequest);
            mJCRSamenessExecutor = Executors.newFixedThreadPool(inputBean.getNoOfProcessors()>0?inputBean.getNoOfProcessors():20);
            logger.info("Inputs for this tool - " + inputBean.toString());
            boolean isValidInput = validateInputs(inputBean); 

            futureObjects = new ArrayList();

            if (isValidInput) {
                // get hash value of the source JCR
                Callable<SortedMap<String, String>> callableSource = new JCRHashGenerationCallable(inputBean, startTime,
                        inputBean.getSourceHost(), mJCRSamenessToolHelper);
                Future<SortedMap<String, String>> future = mJCRSamenessExecutor.submit(callableSource);
                futureObjects.add(future);

                // Make sure the directory exists where we write the output of the JCR comparison and pass that location to
                // compare threads
                String outputFolderName = getOutputFilesFolderName(inputBean.getOutputFolder(),mJCRSamenessToolHelper.getModifiedHostName(inputBean.getSourceHost()));

                // assign tasks (JCR compare from source to target) to threads to execute, one thread for each target host
                for (String targetHost : inputBean.getTargetHosts()) {
                    if (StringUtils.isNotEmpty(targetHost)) {
                        Callable<JCRCompareResponse> callableHost = new JCRCompareCallable(future, targetHost, inputBean,
                                mJCRSamenessToolHelper, startTime, outputFolderName);
                        Future<JCRCompareResponse> futureHost = mJCRSamenessExecutor.submit(callableHost);
                        futureObjects.add(futureHost);
                    }
                }
                
                JSONObject jsonResponse = new JSONObject();
                jcrCompareResponseList = new ArrayList<JCRCompareResponse>();
                // Find the time taken to complete the whole process
                for (Object futureObj : futureObjects) {
                    if (futureObj != null) {
                        try {
                            Object responseObj = ((Future) futureObj).get();
                            if (responseObj instanceof JCRCompareResponse) {
                                JCRCompareResponse jcrCompareResponse = (JCRCompareResponse) responseObj;
                                jcrCompareResponseList.add(jcrCompareResponse);
                                jsonResponse.put(jcrCompareResponse.getResponseKey(), jcrCompareResponse.getResponseValue());
                            }
                        } catch (InterruptedException ie) {
                            logger.error("InterruptedException from doPost() - ", ie);
                        } catch (ExecutionException ee) {
                            logger.error("ExecutionException from doPost() - ", ee);
                        } catch (JSONException je) {
                            logger.error("JSONException from doPost() - ", je);
                        }
                    }
                }
                pResponse.setHeader("Dispatcher", "no-cache");
                pResponse.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");
                PrintWriter out = pResponse.getWriter();
                out.print(jsonResponse);
                pResponse.setContentType("application/json");
                // pResponse.sendRedirect(actualCurrentPageUrl);
                out.flush();  
                logger.info("JCR sameness process completed. Total time taken is "
                        + ((System.currentTimeMillis() - startTime) / 1000) + " seconds");  
                
                mJCRSamenessEmailSender.sendEmailWithRepositorySamenessToolResults(inputBean, jcrCompareResponseList);
            } else {
                pResponse.getWriter().print("<html><font color='red'> Required input parameters are missing. </font></html> Available Processors on this box : " + availbaleProcessors);
            }
        } finally {
            futureObjects = null;
            jcrCompareResponseList = null;
            mJCRSamenessExecutor.shutdown();
        }
    }

    public void destroy() {
        
    }

    private boolean validateInputs(JCRSamenessToolRequest pInputBean) {

        if (pInputBean == null) {
            return false;
        }
        boolean inputValidity = true;
        if (StringUtils.isEmpty(pInputBean.getSourceHost())) {
            logger.error("Source Host is required for JCR Sameness process.");
            inputValidity = false;
        }
        if (pInputBean.getTargetHosts() == null || pInputBean.getTargetHosts().size() < 1) {
            logger.error("Target Hosts is required for JCR Sameness process.");
            inputValidity = false;
        }
        if (StringUtils.isEmpty(pInputBean.getPath())) {
            logger.error("JCR content path is required for JCR Sameness process.");
            inputValidity = false;
        }
        return inputValidity;
    }

    /**
     * Populates input parameters in input bean from request and returns the input bean.
     */
    private JCRSamenessToolRequest populateInputBean(SlingHttpServletRequest pRequest) {
        JCRSamenessToolRequest inputBean = new JCRSamenessToolRequest();
        // path
        String path = pRequest.getParameter(PATH);
        inputBean.setPath(path);

        // source host
        String sourceHost = pRequest.getParameter(SOURCE_HOST);
        if (StringUtils.isNotEmpty(sourceHost)) {
            inputBean.setSourceHost(sourceHost.trim());    
        }
        
        // set output folder name
        if(pRequest.getParameterMap().containsKey("outputResultFolder")){
        	inputBean.setOutputFolder(pRequest.getParameter("outputResultFolder"));
        }
        
    	int noOfProcessors = 0;        
        if(pRequest.getParameterMap().containsKey("noOfProcessors")){

            try{
            	noOfProcessors = Integer.parseInt(pRequest.getParameter("noOfProcessors"));
            }catch(NumberFormatException e){
            	logger.error("Encountered a NumberFormat Exception. Setting Processors to a default value (20)");
            	noOfProcessors = 20;
            }
        }else{
        	logger.info("No Parameter passed to set the no.of Processors. Setting Processors to a default value (20)");
        	noOfProcessors = 20;
        }
    	inputBean.setNoOfProcessors(noOfProcessors);
    	
    	if("on".equals(pRequest.getParameter("checkPageOrder"))){
    		inputBean.setCheckOrder(true);
    	}else{
    		inputBean.setCheckOrder(false);
    	}


        // target hosts
        String targetHosts = pRequest.getParameter(TARGET_HOSTS);
        if (StringUtils.isNotEmpty(targetHosts)) {
            targetHosts = targetHosts.replace(" ", "");
            String[] targetHostsArray = targetHosts.split(",");
            if (targetHostsArray != null && targetHostsArray.length > 0) {
                List<String> targetHostsList = Arrays.asList(targetHostsArray);
                inputBean.setTargetHosts(targetHostsList);
            }
            
            // Get the Replication Agent Names corresponding to these target hosts and 
            // set it to input Bean replicationAgentMap.
            Session jcrSession = pRequest.getResourceResolver().adaptTo(Session.class);
            Hashtable< String, String> raMap = new Hashtable<String, String>();
            try {
            	if(jcrSession.nodeExists("/etc/replication/agents.author")){
            		logger.info("Found Replication Agent node");
            		QueryManager queryManager = jcrSession.getWorkspace().getQueryManager();
            		String sqlQuery = ""; String targetHostName = "";
            		for (int i = 0; i < targetHostsArray.length; i++) {
            			if(targetHostsArray[i].indexOf('@')>0){
            				targetHostName = targetHostsArray[i].split("@")[1];
            			}else{
            				targetHostName = targetHostsArray[i];
            			}
            			sqlQuery = "select * from nt:unstructured where jcr:path like '/etc/replication/agents.author/%' and transportUri like '%"+targetHostName.replace(':', '%')+"%' and cq:template = '/libs/cq/replication/templates/agent'";
            			logger.info("Executing query:"+sqlQuery);
            			Query jcrQuery = queryManager.createQuery(sqlQuery, Query.SQL);
            			QueryResult queryResult = jcrQuery.execute();
            			javax.jcr.NodeIterator nodeItr = queryResult.getNodes(); // This Should match only one result.
            			String replicationAgentNames = "";
            			while(nodeItr.hasNext()){
            				replicationAgentNames += ","+nodeItr.nextNode().getParent().getName();
            			}
            			
            			raMap.put(targetHostsArray[i],replicationAgentNames.replaceFirst(",", ""));
					}
            	}else{
            		logger.info("NO replication agent found. Source Could be a Publish machine. NO REPLICATION AGENTS STORED IN THE MAP.");
            	}
				
			} catch (PathNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RepositoryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
            
        }

        // JCR Node's properties to be excluded from hash generation process
        String excludedProperties = pRequest.getParameter(EXCLUDED_PROPERTIES);
        if (StringUtils.isNotEmpty(excludedProperties)) {
            inputBean.setExcludedProperties(excludedProperties);
        }
        
        // JCR Nodes to be excluded from hash generation process
        String excludedNodes = pRequest.getParameter(EXCLUDED_NODES);
        if (StringUtils.isNotEmpty(excludedNodes)) {
            inputBean.setExcludedNodes(excludedNodes);
        }
        
        // Whether to include deactivated nodes or not during JCR comparison
        String includeDeactivatedNodes = pRequest.getParameter(INCLUDE_DEACTIVATED_NODES);
        if (StringUtils.isNotEmpty(includeDeactivatedNodes)) {
            if ("true".equalsIgnoreCase(includeDeactivatedNodes.trim())) {
                inputBean.setIncludeDeactivatedNodes(true);                
            }              
        }
        
        // email address
        String emailAddresses = pRequest.getParameter(EMAIL_ADDRESSES);
        if (StringUtils.isNotEmpty(emailAddresses)) {
            inputBean.setEmailAddresses(emailAddresses);
        }
        
        return inputBean;
    }

    /**
     * This will pass request to doPost method.
     * 
     * @param pRequest
     *            a HttpServletRequest value.
     * @param pResponse
     *            a HttpServletResponse value.
     * @exception ServletException
     *                if there was an error while executing the code.
     * @exception IOException
     *                if there was an error with servlet io.
     */
    protected void doGet(SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse) throws ServletException, // $codepro.audit.disable
            // missingCatchOfException
            IOException {
        doPost(pRequest, pResponse);
    }
    
    private String getOutputFilesFolderName(String outputFolder,String pSourceHost) {
        String atgDynamoDataDir = null;
        String outputFolderName = null;
        if (SystemUtils.IS_OS_WINDOWS) {
            atgDynamoDataDir = System.getenv("atg.dynamo.data-dir"); // $codepro.audit.disable environmentVariableAccess
        } else {
            atgDynamoDataDir = System.getProperty("atg.dynamo.data-dir");
        }
        String outPutFolderName = outputFolder=="" ? "ran_src_as_" + pSourceHost + "_at_" + Calendar.getInstance().getTimeInMillis()
        		: outputFolder+"_"+Calendar.getInstance().getTimeInMillis();
        
        if (StringUtils.isNotEmpty(atgDynamoDataDir)) {
            outputFolderName = atgDynamoDataDir + File.separator + "logs"+File.separator + "jcr_sameness_tool" + File.separator
                    + outPutFolderName;
        } else {
            outputFolderName = File.separator + "" + outPutFolderName + File.separator + outPutFolderName;
        }
        File dir = new File(outputFolderName); // $codepro.audit.disable com.instantiations.assist.eclipse.analysis.pathManipulation
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return outputFolderName;
    }
}
