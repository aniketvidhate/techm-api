/*
 * Globalsearch Element Builder.
 * @author Pratap Cheruvu (rc8891)
 * @created on Nov 05 2013
 */


package com.att.ecom.cq.bundle.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.Value;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import com.day.cq.wcm.api.PageManager;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;


import java.io.File;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
 
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


@Component(immediate=true)
@Service(value=GlobalsearchRelatedQueriesElementBuilder.class)

public class GlobalsearchRelatedQueriesElementBuilder 
{

	private Logger logger = LoggerFactory.getLogger(GlobalsearchRelatedQueriesElementBuilder.class);
	
	private String outputWithHypderlinks="";

	@Reference
	private SlingRepository slingRepository;
	
	@Reference
	private ResourceResolverFactory resourceResolverFactory;	

	private Session administrativeSession;
	
	DocumentBuilderFactory docFactory; 
	DocumentBuilder docBuilder;
	// root elements
	Document doc;
	Element rootElement;
	
	private int pageid=0;
	

	protected void activate(ComponentContext ctx) throws RepositoryException 
	{
		administrativeSession = slingRepository.loginAdministrative(null);
	}
	
	protected void deactivate(ComponentContext ctx) {
		administrativeSession.logout();
	}
	/*
     * Get the CQ template Paths
     */	
	public synchronized String buildElements(String currentPagePath) throws RepositoryException 
	{
		String output="";
		pageid=0;
		StreamResult streamResult = new StreamResult(new StringWriter());
		outputWithHypderlinks="";
		String child_Pages="SELECT * FROM nt:base WHERE jcr:path like '"+currentPagePath +"/%' and jcr:primaryType='cq:Page' ";
		if (administrativeSession.isLive()) 
		{	
			// get QueryManager
    		QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();    		
    		// make SQL query
    		Query query = queryManager.createQuery(child_Pages, Query.SQL);
    		// execute query
    		QueryResult result = query.execute();
    		// execute query and fetch result
    		NodeIterator nodes = result.getNodes();
    		ResourceResolver adminResolver = null;
    		int indent=2;
			try 
			{
				String template_name,module_name,node_name,nodepath;
				adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);				
				docFactory = DocumentBuilderFactory.newInstance();
				docBuilder = docFactory.newDocumentBuilder();
				doc = docBuilder.newDocument();				
				rootElement = doc.createElement("add");
				doc.appendChild(rootElement);
				doc =parseCurrentPage(currentPagePath,doc);
				while (nodes.hasNext()) 
				{
					Node node = nodes.nextNode();
					doc =parseCurrentPage(node.getPath().toString(),doc);
					
			    }
				// write the content into xml file
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				transformerFactory.setAttribute("indent-number", indent);
				Transformer transformer = transformerFactory.newTransformer();
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				DOMSource source = new DOMSource(doc);			
				
				transformer.transform(source, streamResult);
				output=streamResult.getWriter().toString();			
				
			}catch (LoginException e) {
				logger.error("Unable to login for CMS Repository Report", e);
			}
			catch(ParserConfigurationException pce){
				logger.error("ParserConfigurationException", pce);
			}
			catch(TransformerException  tfe){
				logger.error("TransformerException", tfe);
			}
			finally {
				if (adminResolver != null) {
					adminResolver.close();
				}
			}
		}
		
		return output;	
	}
	
	/**
	 * Parsing giving Global Search promoion page 
	 * return elements
	 */
	public synchronized Document parseCurrentPage(String currentPagePath, Document pageDoc) throws RepositoryException {
		ResourceResolver adminResolver = null;
		String nodepath="";
		Attr attr;
		Element childElement;
		int searchQueryCount=0;
		try{
			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			PageManager pageManager = adminResolver.adaptTo(PageManager.class);
			Page rootPage = pageManager.getPage(currentPagePath);
			if( null != rootPage){
				Resource rootpageRes = rootPage.getContentResource();
				Resource rootpagemainpar = adminResolver.getResource(rootpageRes , "relatedquery");
				if(null != rootpagemainpar){
					Node tempNode = rootpagemainpar.adaptTo(Node.class);
					nodepath= tempNode.getCorrespondingNodePath(tempNode.getSession().getWorkspace().getName());
					//Check related Query
					if (tempNode.hasProperty("relatedQuery")) {
						try{
								Value[]  relatedQueryvalues= tempNode.getProperty("relatedQuery").getValues();   
								for(int relatedQueryvalueindex=0; relatedQueryvalueindex<relatedQueryvalues.length ;relatedQueryvalueindex++){									
									if (relatedQueryvalues[relatedQueryvalueindex].getString().trim().length() > 0) {
										Element docElement = pageDoc.createElement("doc");
										rootElement.appendChild(docElement);
										//Check searchQuery
										if (tempNode.hasProperty("searchQuery")) {
											if (tempNode.getProperty("searchQuery").getString().trim().length() > 0){
												pageDoc=buildChildElements("searchQuery",tempNode.getProperty("searchQuery").getString(),pageDoc,docElement);
												if(searchQueryCount < 1){
													outputWithHypderlinks +="\n"+"<a href='"+currentPagePath+".html' target=_blank>"+tempNode.getProperty("searchQuery").getString()+"</a>=>";
												}
												searchQueryCount++;
											}
										} // end searchQuery									
										pageDoc=buildChildElements("relatedQuery",relatedQueryvalues[relatedQueryvalueindex].getString(),pageDoc,docElement);
										if(searchQueryCount==1){
											outputWithHypderlinks +="<a href='"+currentPagePath+".html' target=_blank>"+relatedQueryvalues[relatedQueryvalueindex].getString()+"</a>";
										}
										else{
											outputWithHypderlinks +=","+"<a href='"+currentPagePath+".html' target=_blank>"+relatedQueryvalues[relatedQueryvalueindex].getString()+"</a>";
										}
									}
									
								}
		                	}// end of try
							catch(RepositoryException e){								
	    		            	//Check searchQuery
	    		            	if (tempNode.getProperty("relatedQuery").getString().trim().length() > 0){
	    		            		Element docElement = pageDoc.createElement("doc");
		    		            	rootElement.appendChild(docElement);
	    		            		if (tempNode.hasProperty("searchQuery")) {
	    		            			if (tempNode.getProperty("searchQuery").getString().trim().length() > 0){
	    		            				pageDoc=buildChildElements("searchQuery",tempNode.getProperty("searchQuery").getString(),pageDoc,docElement);
	    		            				outputWithHypderlinks +="\n"+"<a href='"+currentPagePath+".html' target=_blank>"+tempNode.getProperty("searchQuery").getString()+"</a>=>";
	    		            			}
	    		            		}// end searchQuery	    		            	
	    		            		pageDoc=buildChildElements("relatedQuery",tempNode.getProperty("relatedQuery").getString(),pageDoc,docElement);
	    		            		outputWithHypderlinks +="<a href='"+currentPagePath+".html' target=_blank>"+tempNode.getProperty("relatedQuery").getString()+"</a>";
	    		            	}
							}//end of catch
							outputWithHypderlinks +="\n";
		            	} //end of if Check related Query
					}// end of if rootpagemainpar null
			} //end of if rootPage
			
		}//end of try
		catch(Exception e){
			logger.error("Unable to parse", e);
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
			
		}		
		
		return pageDoc;
	}	
	
	/**
	 *  build child elements
	 */
	public synchronized Document buildChildElements(String fieldName, String cqPropertyName,  Document childPageDoc, Element docElement) throws RepositoryException {
		Attr attr;
		Element childElement;
		try{
			childElement=childPageDoc.createElement("field");
        	//childElement.appendChild(childPageDoc.createCDATASection(cqPropertyName));
			childElement.appendChild(childPageDoc.createTextNode(cqPropertyName));
        	docElement.appendChild(childElement);
        	// set attribute to staff element
        	attr = childPageDoc.createAttribute("name");
        	attr.setValue(fieldName);
        	childElement.setAttributeNode(attr);
		}
		catch(Exception e){
			logger.error("Unable to build Child Elements", e);
		}		
		return childPageDoc;
	}
	
	
	public synchronized String buildSearchElements(String currentPagePath) throws RepositoryException
	{
		String outputwithouthyperlink="";
		try{
			outputwithouthyperlink=buildElements(currentPagePath);
		
			
		}
		catch (Exception e){
			logger.error("ERROR ", e);
		}
		return outputWithHypderlinks;	
	}
	
}

