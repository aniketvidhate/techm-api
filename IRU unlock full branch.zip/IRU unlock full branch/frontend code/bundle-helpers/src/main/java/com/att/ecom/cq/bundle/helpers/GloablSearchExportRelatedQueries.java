package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.ValueFactory;
import javax.servlet.ServletException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@SlingServlet(paths = "/system/att/cms/internaltools/relatedqueries")


public class GloablSearchExportRelatedQueries extends SlingAllMethodsServlet {

	/**
	 * Servlet to Automatically create Related Queries page in CQ through XML
	 * created by : Hemant Arora(ha061x)
	 */
	private static final long serialVersionUID = 1L;
	private static final String JCR_PATH="/content/att/cmsfeed/globalsearch";
	private static final String NODE_RELATED_QUERY_AUTOMATION ="relatedQueries";
	private static final String RESOURCE_TYPE="sling:resourceType";
	private static final String PAGE_RESOURCE_TYPE="cq:Page";
	private static final String PAGE_CONTENT ="cq:PageContent";
	private static final String RESOURCE_TYPE_VALUE="att/common/components/relatedqueries";
	private static final String MAIN_PAGE_RESOURCE_TYPE_VALUE="/apps/att/common/components/page/globalsearch/relatedqueries";
	private static final String PAGE_RESOURCE_TYPE_VALUE="/apps/att/common/components/page/globalsearch/relatedqueries";
	private static final String PAGE_TEMPLATE="cq:template";
	private static final String PAGE_TEMPLATE_VALUE="/apps/att/common/templates/globalsearch/relatedqueries";
	private static final String ELEMENT_NAME="name";
	private static final String ELEMENT_DOC="doc";
	private static final String ATTR_SEARCH_QUERY="searchQuery";
	private static final String ATTR_RELATED_QUERY="relatedQuery";
	private static final String NODE_TYPE="cq:PageContent";
	private static final String JCR_TITLE ="jcr:title";
	private static final String JCR_CONTENT ="jcr:content";
	private static final String NODE_RELATEDQUERY ="relatedquery";
	private static final String PRIMARY_TYPE_UNSTRUCTURED ="nt:unstructured";

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Reference
	private SlingRepository slingRepository;

	@Reference
	private ResourceResolverFactory resourceResolverFactory;    

	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,	IOException 
	{

		javax.jcr.Node rootNode=null;
		javax.jcr.Session session=null;
		ResourceResolver adminResolver = null;
		try 
		{
			adminResolver=resourceResolverFactory.getAdministrativeResourceResolver(null);
			//Create a Session
			session =slingRepository.loginAdministrative(null);
			rootNode =(javax.jcr.Node) session.getItem(JCR_PATH);
			//if relatedQueries main page node does not exist
			if(null!=rootNode && !rootNode.hasNode(NODE_RELATED_QUERY_AUTOMATION)) {
				//	create relatedQueries main page
				logger.info("Created Node relatedQueries") ;
				createNode(rootNode, session);
				//get related query node
				rootNode=(javax.jcr.Node) session.getItem(JCR_PATH+"/"+NODE_RELATED_QUERY_AUTOMATION);
				//set child node properties
				setChildNodeProperties(rootNode,session);  
				logger.info("Created child Nodes and set its properties") ;
				logger.info("Saving Session");
				session.save();
			}
			//if relatedQueries main page node exist
			else{
				//set root node as NODE_RELATED_QUERY_AUTOMATION
				logger.info("RelatedQueries Node exists") ;
				//get related query node
				rootNode=(javax.jcr.Node) session.getItem(JCR_PATH+"/"+NODE_RELATED_QUERY_AUTOMATION);
				//set child node properties
				setChildNodeProperties(rootNode,session);  
				logger.info("Created child Nodes and set its properties") ;
				session.save();
				logger.info("Saving Session");
			}
			PrintWriter pw=response.getWriter();
			pw.write("Migration Completed Successfully. Thanks");
			pw.flush();
		}
		
		catch (RepositoryException e) 
		{
		}
		catch (Exception e) 
		{  
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}if(session!=null){
				session.logout();
			}

		}
	}


	/*
	 * method to set properties of child nodes under NODE_RELATED_QUERY_AUTOMATION
	 */
	public void setChildNodeProperties(javax.jcr.Node rootNode,Session session){

		////logger.error("Create Child nodes and set properties");
		javax.jcr.Node currentNode = null ;  
		String nodetype="";
		String searchQueryValue="";
		List<Value> relatedQueryList = null;
		List<Value> sameNodeRelatedQueryList = null; 
		Value vs[]=new Value[0];
		Value val[]=new Value[0];
		String fieldname="";
		String fieldvalue="";
		int i,k;


		try 
		{
			//URL url = new URL("http://10.13.64.55/relatedQueries.xml");
			URL url = new URL("http://cmsdev4.admin.cingular.net/globalsearch/relatedQueries.xml");
			URLConnection connection = url.openConnection();
			//get file from disk
			/*File file = new File("D:\\temp\\Auto_Suggest.xml");
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(file);*/

			Document doc = parseXML(connection.getInputStream());
			NodeList docNodes = doc.getElementsByTagName(ELEMENT_DOC);

			javax.jcr.Node childPageNode =null;
			JSONObject jsonpageinfo=null;
			for(i=0; i<docNodes.getLength();i++)
			{    
				jsonpageinfo=new JSONObject();
				NodeList docchildNodes = docNodes.item(i).getChildNodes();
				for (k=0; k<docchildNodes.getLength(); k++)
				{        
					Node nNode = docchildNodes.item(k);

					if (nNode.getNodeType() == Node.ELEMENT_NODE) 
					{    
						Element elem = (Element) nNode;
						fieldname=elem.getAttribute(ELEMENT_NAME).toString().trim();
						//logger.error("fieldname=="+fieldname);
						fieldvalue=elem.getTextContent().toString().replaceAll("^\\s+","");
						//logger.error("fieldvalue=="+fieldvalue);
						//if search query exists
						if(fieldname.equalsIgnoreCase(ATTR_SEARCH_QUERY)){
							searchQueryValue=fieldvalue;
							//if relatedQueries does not have child node "fieldvalue"
							if(!rootNode.hasNode(fieldvalue)){
								//create child page
								currentNode = (javax.jcr.Node)rootNode.addNode(searchQueryValue,PAGE_RESOURCE_TYPE);
								//add jcr:content node
								childPageNode = currentNode.addNode(JCR_CONTENT,PAGE_CONTENT);
								//add properties
								childPageNode.setProperty(RESOURCE_TYPE, PAGE_RESOURCE_TYPE_VALUE);
								jsonpageinfo.put(PAGE_TEMPLATE,PAGE_TEMPLATE_VALUE);
								jsonpageinfo.put(JCR_TITLE,searchQueryValue);
								//set page properties
								setNodeProperties(childPageNode, session, JCR_CONTENT,"", jsonpageinfo, "");
								childPageNode= childPageNode.addNode(NODE_RELATEDQUERY,PRIMARY_TYPE_UNSTRUCTURED);
								//set property searchQuery
								childPageNode.setProperty(ATTR_SEARCH_QUERY, searchQueryValue);
								session.save();
							}
							else{//if relatedQueries has child node "fieldvalue"
								if(!searchQueryValue.equalsIgnoreCase(fieldvalue)){//condition to avoid duplicate entry
									relatedQueryList = new ArrayList<Value>();
									//logger.error("else has rootNode.hasNode=="+fieldvalue);
									childPageNode=rootNode.getNode(searchQueryValue);
									//get relatedQuery node
									childPageNode=childPageNode.getNode(JCR_CONTENT+"/"+NODE_RELATEDQUERY);
									//iterate through existing values in node properties
									for(Value v : childPageNode.getProperty(ATTR_RELATED_QUERY).getValues()) {
										if(v!=null){
											if(!v.getString().equalsIgnoreCase(fieldvalue)){
												relatedQueryList.add(v);
											}
										}
									}
									ValueFactory vFactory=childPageNode.getSession().getValueFactory();
									Value newValue=vFactory.createValue(fieldvalue);
									relatedQueryList.add(newValue);	
									Value[] finalValues=(Value[])relatedQueryList.toArray(vs);
									//setting property related query
									childPageNode.setProperty(ATTR_RELATED_QUERY, finalValues);
								}
							}

						}
						else{//else for adding relatedQuery 
							sameNodeRelatedQueryList = new ArrayList<Value>();
							childPageNode=rootNode.getNode(searchQueryValue);
							childPageNode=childPageNode.getNode(JCR_CONTENT+"/"+NODE_RELATEDQUERY);
							if(childPageNode.hasProperty(ATTR_RELATED_QUERY)){
								for(Value v : childPageNode.getProperty(ATTR_RELATED_QUERY).getValues()) {
									if(v!=null){
										if(!v.getString().equalsIgnoreCase(fieldvalue)){
											sameNodeRelatedQueryList.add(v);
										}
									}
								}
							}
							ValueFactory vFactory=childPageNode.getSession().getValueFactory();
							Value newValue=vFactory.createValue(fieldvalue);
							sameNodeRelatedQueryList.add(newValue);	
							Value[] finalValues=(Value[])sameNodeRelatedQueryList.toArray(val);
							//setting property related query
							childPageNode.setProperty(ATTR_RELATED_QUERY, finalValues);

						}
					}
				}

			}


		}
		catch (RepositoryException e) 
		{
			logger.error("RepositoryException==="+e.getMessage());
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			logger.error("Exception==="+e.getMessage());
		}
	}

	/*
	 * Method to create node
	 */
	public static void createNode(javax.jcr.Node node, Session session){
		javax.jcr.Node rootNode=null;

		if(null!=node){
			try {
				rootNode=node;
				rootNode=rootNode.addNode(NODE_RELATED_QUERY_AUTOMATION,PAGE_RESOURCE_TYPE);
				rootNode=rootNode.addNode(JCR_CONTENT,PAGE_CONTENT);
				rootNode.setProperty(PAGE_TEMPLATE,PAGE_TEMPLATE_VALUE);
				rootNode.setProperty(JCR_TITLE,NODE_RELATED_QUERY_AUTOMATION);
				rootNode.setProperty(RESOURCE_TYPE, MAIN_PAGE_RESOURCE_TYPE_VALUE);
				session.save();
			} catch (PathNotFoundException e) {
				e.printStackTrace();
			} catch (RepositoryException e) {
				e.printStackTrace();
			}
		}
	}


	/*
	 * Method to set properties of relatedquery child node pages
	 */
	public void setNodeProperties(javax.jcr.Node node, Session session, String nodetype,String referencenodepath,JSONObject jsonnodeinfo, String strpositionalcode ) throws RepositoryException,  Exception {
		Iterator<String> iter = jsonnodeinfo.keys();
		while(iter.hasNext()){
			String key = (String)iter.next();
			String value = jsonnodeinfo.getString(key);
			nodetype=node.getPrimaryNodeType().getName();
			node.setProperty(key,value);
			if(nodetype.equalsIgnoreCase(NODE_TYPE)){
				node.setProperty(RESOURCE_TYPE, MAIN_PAGE_RESOURCE_TYPE_VALUE);
			}
			else if(!nodetype.equalsIgnoreCase(NODE_TYPE) && !nodetype.equalsIgnoreCase(JCR_CONTENT)){
				node.setProperty(RESOURCE_TYPE,RESOURCE_TYPE_VALUE);   
			}
		}

		session.save(); 
	}

	/*
	 * method to parse xml
	 */
	private Document parseXML(InputStream stream)
			throws Exception
			{
		DocumentBuilderFactory objDocumentBuilderFactory = null;
		DocumentBuilder objDocumentBuilder = null;
		Document doc = null;
		try
		{
			objDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
			objDocumentBuilder = objDocumentBuilderFactory.newDocumentBuilder();
			doc = objDocumentBuilder.parse(stream);
		}
		catch(Exception ex)
		{
			ex.getMessage();
			throw ex;
		}       
		return doc;
			}

	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}


}
