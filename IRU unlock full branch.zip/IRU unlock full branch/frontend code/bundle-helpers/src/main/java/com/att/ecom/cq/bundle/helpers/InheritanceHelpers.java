package com.att.ecom.cq.bundle.helpers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.StringEscapeUtils;
import com.day.cq.wcm.api.Page;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;


/**
 * 
 * @author Jon Ito
 * @version 1.0
 */
public class InheritanceHelpers {

    private static final Logger log = LoggerFactory.getLogger(com.att.ecom.cq.bundle.helpers.InheritanceHelpers.class);
    private static final String COMPONENT_START_PATH = "jcr:content";

    private InheritanceHelpers() {
        //prevent instansiation
    }

	/**
	 * @param resource
	 * @param resourceResolver
	 * @param actpage
	 * @param propName
	 * @param defaultProps
	 * @return properties for the resource (checking parents if not available on the current resource)
	 */	
    public static ValueMap getProperties(Resource resource, ResourceResolver resolver, Page actpage, String propName, ValueMap defaultProps) {
        if (resource == null) {
            log.error("A null resource was provided, unable to inherit");
            return null;
        }
        if (actpage == null) {
            log.error("A null act page was provided, unable to inherit");
            return null;
        }
        if (resolver == null) {
            log.error("A null resource resolved we provided, unable to inherit");
            return null;
        }
        if (StringUtils.isEmpty(propName)) {
            log.error("An empty qualident was provided, unable to inherit");
            return null;
        }
        ValueMap properties = defaultProps;
        if (properties != null) {
            if (properties.get(propName) == null) {
                String relPath = getComponentRelativePath(resource.getPath());
                properties = inheritProps(properties, resolver, actpage.getParent(), relPath, propName);
            }
        }
        return properties;
    }

    /**
     * Will attempt to inherit a properties object for a page or a component.
     *
     * @param resolver
     * @param actpage
     * @param relPath <code>String</code> represents the path to the component below the page level. So for example
     *                if the component's resource path is /content/site/en/home/product/jcr:content/header the component's
     *                relative path would be /jcr:content/header. 
     * @param propName
     * @return
     */
	public static ValueMap getProperties(ValueMap defaultProps, ResourceResolver resolver, Page actpage, String relPath, String propName, boolean checkCurrentPage) {
		// Verify that required parameters are not null

        if (actpage == null) {
            log.error("A null act page was provided, unable to inherit");
            return null;
        }
        if (resolver == null) {
            log.error("A null resource resolved we provided, unable to inherit");
            return null;
        }
        if (StringUtils.isEmpty(propName)) {
            log.error("An empty property name was provided, unable to inherit");
            return null;
        }
        if (relPath == null) {
            relPath = "";
        }

        log.debug("Trying to inherit prop " + relPath + "/" + propName + " from tree starting at " + actpage.getParent());

        ValueMap properties = defaultProps;
        //try to get the properties object for the relPath from the current page.
        if (StringUtils.isNotEmpty(relPath)) {
            Resource iResource = resolver.getResource(actpage.getContentResource(), relPath);
            if (iResource != null) {
                properties = iResource.adaptTo(org.apache.sling.api.resource.ValueMap.class);
            }
        }
        //check to see if the current properties object has the property needed.
        if (checkCurrentPage && properties.get(propName) != null) {
            return properties;
        }
		Page currentPage = actpage.getParent();

		return inheritProps(properties, resolver, currentPage, relPath, propName);
	}

    private static ValueMap inheritProps(ValueMap properties, ResourceResolver resolver, Page currentPage, String relPath, String propName) {
			// Keep going up the tree until we get to the top
			while (currentPage != null) {
				log.debug("Trying page " + currentPage.getPath());
                log.debug("Attempting to inherit path " + relPath + ", prop " + propName);
                Resource source = currentPage.getContentResource();
                log.debug("Source path = " + source.getPath());
                if (StringUtils.isNotEmpty(relPath)) {
                    log.debug("Getting relative resource");
                    source = resolver.getResource(source, relPath);
                }

                if (source != null) {
                    log.debug("New source page: " + source.getPath());
                    ValueMap props = source.adaptTo(org.apache.sling.api.resource.ValueMap.class);
                    if (props != null && props.containsKey(propName)) {
                        log.debug("child props contains key");
                        Object obj = props.get(propName);
                        if (obj != null) {
                            properties = props;
                            log.debug("Current page has required value." + obj.toString());
                            break;
                        } else {
                            log.error("Current page had the property, but it was a null value");
                        }
                    } else {
                        log.error("Current page did not have the required property");
                    }
                } else {
                    log.error("Current page did not have the required resource");
                }

				currentPage = currentPage.getParent();
			}
		return properties;
    }

    /**
     * Will attempt to inherit a resource if content accoring to path exists
     *
     * @param resolver
     * @param actpage
     * @param relPath <code>String</code> represents the path to the component below the page level. So for example
     *                if the component's resource path is /content/site/en/home/product/jcr:content/header the component's
     *                relative path would be /jcr:content/header. 
     * @param propName
     * @return
     */
    public static Resource inheritResourceIfHasContent(Resource resource, ResourceResolver resolver, Page currentPage, String relPath) {
    	if (resource != null && StringUtils.isEmpty(relPath)) {
    		relPath = getComponentRelativePath(resource.getPath());
    	}
    	while (currentPage != null) {
    		Resource source = currentPage.getContentResource();
    		if (StringUtils.isNotEmpty(relPath)) {
    			source = resolver.getResource(source, relPath);
    		}
    		if (source != null) {
	    		ValueMap props = source.adaptTo(ValueMap.class);
	    		if (props != null) {
	    			resource = source;
	    			break;
	    		}
    		}
    		
    		currentPage = currentPage.getParent();
    	}
    	return resource;
    }
    
    private static String getComponentRelativePath(String path) {
    	path = StringUtils.trimToEmpty(path);
    	if (path.indexOf(COMPONENT_START_PATH) > 0) {
    		int index = path.indexOf(COMPONENT_START_PATH);
    		path = path.substring(index+12);
    	}
    	return path;
    }
    
    
}
