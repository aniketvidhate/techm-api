/*
 * Globalsearch Synonyms Builder.
 * @author Pratap Cheruvu (rc8891)
 * @created on Nov 25 2013
 */
package com.att.ecom.cq.bundle.helpers;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.Value;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import com.day.cq.wcm.api.PageManager;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;

@Component(immediate=true)
@Service(value=GlobalSearchSynonyms.class)

public class GlobalSearchSynonyms{
	private Logger logger = LoggerFactory.getLogger(GlobalSearchSynonyms.class);
 
	private String outputWithHypderlinks="";
	@Reference
	private SlingRepository slingRepository;
	
	@Reference
	private ResourceResolverFactory resourceResolverFactory;	

	private Session administrativeSession;
	
	protected void activate(ComponentContext ctx) throws RepositoryException 
	{
		administrativeSession = slingRepository.loginAdministrative(null);
	}
	
	protected void deactivate(ComponentContext ctx) {
		administrativeSession.logout();
	}
	
	/*
     * Get the CQ pages
     */	
	public synchronized String buildElements(String currentPagePath) throws RepositoryException 
	{
		String output="";
		outputWithHypderlinks="";
		String child_Pages="SELECT * FROM nt:base WHERE jcr:path like '"+currentPagePath +"/%' and jcr:primaryType='cq:Page' ";		
		String synonymsLine="";
		if (administrativeSession.isLive()) 
		{	
			// get QueryManager
    		QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();    		
    		// make SQL query
    		Query query = queryManager.createQuery(child_Pages, Query.SQL);
    		// execute query
    		QueryResult result = query.execute();
    		// execute query and fetch result
    		NodeIterator nodes = result.getNodes();
    		ResourceResolver adminResolver = null;    		
			try 
			{
				
				adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
				synonymsLine =parseCurrentPage(currentPagePath);
				//System.out.println("currentPagePath: "+currentPagePath);
				output=synonymsLine;
				if(synonymsLine.trim().length() > 0){
					outputWithHypderlinks="<a href='"+currentPagePath+"'>"+synonymsLine+"</a>";
				}
				while (nodes.hasNext()) 
				{
					Node node = nodes.nextNode();
					synonymsLine =parseCurrentPage(node.getPath().toString());
					if(synonymsLine.trim().length() > 0 ){
						//System.out.println("here are lines *********************"+synonymsLine+"***************************** \n" );
						outputWithHypderlinks=outputWithHypderlinks+"\n"+"<a href='"+node.getPath().toString()+".html' target=_blank>"+synonymsLine+"</a>";
						output=output+"\n"+synonymsLine;
					}
					else{
						  
						outputWithHypderlinks=outputWithHypderlinks+"\n"+"<a style='color:red' href='"+node.getPath().toString()+".html' target=_blank>Empty Page - "+node.getPath().toString().substring(node.getPath().toString().lastIndexOf("/")+1)+"</a>";
					}
					//System.out.println("here are lines *********************"+outputWithHypderlinks+"*****************************");									
					
					
			    }
				
			}catch (LoginException e) {
				logger.error("Unable to login for CMS Repository Report", e);
			}
			catch (Exception e) {
				logger.error("Exception", e);
			}
			finally {
				if (adminResolver != null) {
					adminResolver.close();
				}
			}
		}
		output=output.trim();
		outputWithHypderlinks=outputWithHypderlinks.trim();
		//System.out.println("here are lines *********************"+outputWithHypderlinks+"*****************************");		
		return output;	
	}
	
	/**
	 * Parsing giving Global Search promoion page 
	 * return elements
	 */
	public synchronized String parseCurrentPage(String currentPagePath) throws RepositoryException {
		ResourceResolver adminResolver = null;
		String currentsynonymsline="";
		String nodepath="";
		try{
			//System.out.println("currentPagePath: "+currentPagePath);
			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			PageManager pageManager = adminResolver.adaptTo(PageManager.class);
			Page rootPage = pageManager.getPage(currentPagePath);
			if( null != rootPage){
				Resource rootpageRes = rootPage.getContentResource();
				Resource rootpagemainpar = adminResolver.getResource(rootpageRes , "synonyms");
				if(null != rootpagemainpar){
					Node tempNode = rootpagemainpar.adaptTo(Node.class);
					nodepath= tempNode.getCorrespondingNodePath(tempNode.getSession().getWorkspace().getName());
					//Check related Query
					if (tempNode.hasProperty("synonyms")) {
						try{
								Value[]  synonymsValues= tempNode.getProperty("synonyms").getValues();   
								for(int synonymsValueIndex=0; synonymsValueIndex<synonymsValues.length ;synonymsValueIndex++){										    		            	
									currentsynonymsline +=synonymsValues[synonymsValueIndex].getString()+",";
									//System.out.println("currentsynonymsline: "+currentsynonymsline);											    		          
								}
								if(currentsynonymsline.contains(",")){
									currentsynonymsline=currentsynonymsline.substring(0, currentsynonymsline.length() - 1);
								}		
								if(tempNode.hasProperty("substitutionvalue")){									
									if(tempNode.getProperty("substitutionvalue").getString().length() > 0) {
										currentsynonymsline=currentsynonymsline+" => "+tempNode.getProperty("substitutionvalue").getString();
									}
								} // end substitutionvalue	
		                	}// end of try
							catch(RepositoryException e){   	
	    		            	currentsynonymsline=tempNode.getProperty("synonyms").getString();
	    		            	if(tempNode.hasProperty("substitutionvalue")) {
	    		            		if(tempNode.getProperty("substitutionvalue").getString().length() > 0) {
	    		            			currentsynonymsline=currentsynonymsline+"=>"+tempNode.getProperty("substitutionvalue").getString();
	    		            		}
								} // end substitutionvalue
	    		            	//System.out.println("currentsynonymsline: "+currentsynonymsline);
							}//end of catch
		            	} //end of if Check related Query
					}// end of if rootpagemainpar null
			} //end of if rootPage
			
		}//end of try
		catch(Exception e){
			logger.error("Unable to parse", e);
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
			
		}
		
		return currentsynonymsline;
	}
	
	/*
     * Get the CQ pages
     */	
	public synchronized String buildElementsWithHyperlinks(String currentPagePath) throws RepositoryException  
	{
		String outputwithouthyperlink="";
		try{
			outputwithouthyperlink=buildElements(currentPagePath);
		
			
		}
		catch (Exception e){
			logger.error("ERROR ", e);
		}
		return outputWithHypderlinks;	
	}
	
}
