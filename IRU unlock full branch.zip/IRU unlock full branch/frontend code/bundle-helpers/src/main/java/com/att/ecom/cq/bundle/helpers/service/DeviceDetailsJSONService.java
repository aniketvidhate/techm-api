/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */ 
package com.att.ecom.cq.bundle.helpers.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.helpers.PathHelpers;

/**
 * For any given device it returns the JSON response. JSON response contains the information of "features", "specification" and "In the box".
 * (Example URL that client is going to hit is : http://www.att.com/shop/wireless/device.detailsasjson.html?skuid=sku123456)
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884)
 * @since September 23rd 2013
 * 
 * Modified json response.Added parent objects(type,tabname) to json array response. Fetching tab names from translator. 
 * @author Hemant Arora (attuid: ha061x )
 * @since October 28th 2013
 */
@SlingServlet(methods = { "GET" }, resourceTypes = "sling/servlet/default", selectors = "detailsasjson", extensions = "html")
public class DeviceDetailsJSONService extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final String SKUID = "skuid";
	private static final String ENGLISH = "en";
	private static final String TYPE = "type";
	private static final String TABNAME = "tabName";
	private static final String CONTENTS = "contents";
	
	private static final String TYPE_KEY_FEATURES = "keyfeatures";
    private static final String TYPE_FEATURES = "features";
    private static final String TYPE_TECHNICAL_SPECIFICATIONS = "techSpecs";
    private static final String TYPE_IN_THE_BOX = "whatsInTheBox";
    
	private static final String KEY_FEATURES_KEY = "label.detailtab.features";
	private static final String FEATURES_KEY = "label.detailtab.details";
	private static final String TECHNICAL_SPECIFICATIONS_KEY = "label.detailtab.techspecs";
	private static final String IN_THE_BOX_KEY ="label.inthebox.accessories";
	

	public static final Logger LOGGER = LoggerFactory.getLogger(DeviceDetailsJSONService.class);

	@Override
	protected void doGet(SlingHttpServletRequest pRequest,
			SlingHttpServletResponse pResponse) throws ServletException,
			IOException {
	 
		long startTime = System.currentTimeMillis();		
        LOGGER.debug("GET Device Details as JSON :: process started");

        try {
            ResourceResolver resourceResolver = pRequest.getResourceResolver();
            if (resourceResolver == null) {
                LOGGER.error("ResourceResolver is not available in request, can't continue further");
                pResponse.setStatus(HttpServletResponse.SC_EXPECTATION_FAILED);
                return;
            }

        	String skuId = pRequest.getParameter(SKUID);
            if (StringUtils.isEmpty(skuId)) {
                LOGGER.error("No SUFICIENT INPUT. Reason - SKU ID is empty, can't continue further.");
                pResponse.setStatus(HttpServletResponse.SC_EXPECTATION_FAILED);
                return;
            }
            
    		Resource resource = PathHelpers.getDeviceDetailsResource(resourceResolver, ENGLISH, skuId);
    		Node deviceNode = resource.adaptTo(Node.class);
    		
    		List<JSONObject> deviceDetails = null;
    		
    		deviceDetails = constructDeviceDetailsJSON(resourceResolver, deviceNode, deviceDetails,pRequest);
    		
            PrintWriter out = pResponse.getWriter();
            if (deviceDetails != null) {
                out.print(deviceDetails.toString());            	
            }
            pResponse.setContentType("application/json");
            out.flush();
            
        } catch (Exception pException) {
        	LOGGER.error("GET Device Details as JSON :: Exception occured while reading the device details and constructing JSON :" + pException);
        } finally {
        	// Cleanup resources (if any needs to be cleaned up)
        }
        
        LOGGER.debug("GET Device Details as JSON :: process completed in [" + (System.currentTimeMillis() - startTime)/1000 + "] seconds.");
	}
    
	/**
	 * It iterates thru device nodes and constructs the JSON array with all details. 
	 */
	private List<JSONObject> constructDeviceDetailsJSON(ResourceResolver pResourceResolver, Node pDeviceNode, List<JSONObject> pDeviceDetailsList,SlingHttpServletRequest pRequest) {
		
		if (pDeviceNode == null) {
			LOGGER.error("Construct Device Details as JSON :: device NODE is null, so, can't continue further.");
			return null;
		}
		pDeviceDetailsList = new ArrayList<JSONObject>();
		try {
			// Key Features
			JSONObject keyFeatures = buildKeyFeaturesJSON(pResourceResolver, pDeviceNode,pRequest);
			if (keyFeatures != null) { 
				pDeviceDetailsList.add(keyFeatures);		
			}
		
			// Features
			JSONObject features = buildFeaturesJSON(pResourceResolver, pDeviceNode,pRequest);
			if (features != null) {
				pDeviceDetailsList.add(features);
			}

			// Technical Specifications
			JSONObject techSpecs = buildTechnicalSpecifications(pResourceResolver, pDeviceNode,pRequest);
			if (techSpecs != null) {
				pDeviceDetailsList.add(techSpecs);		
			}
			
			// In the box (what's in the box?)
			JSONObject inTheBox = buildInTheBoxJSON(pResourceResolver, pDeviceNode,pRequest);
			if (inTheBox != null) {
				pDeviceDetailsList.add(inTheBox);		
			}

		} catch (JSONException pException) {
			LOGGER.error("GET Device Details as JSON :: Exception occured while reading the device details and constructing JSON :" + pException);
			pException.printStackTrace();
		} catch (PathNotFoundException pException) {
			LOGGER.error("GET Device Details as JSON :: Exception occured while reading the device details and constructing JSON :" + pException);
		} catch (ValueFormatException pException) {
			LOGGER.error("GET Device Details as JSON :: Exception occured while reading the device details and constructing JSON :" + pException);
		} catch (RepositoryException pException) {
			LOGGER.error("GET Device Details as JSON :: Exception occured while reading the device details and constructing JSON :" + pException);
		} catch (InvalidParameterException pException) {
			LOGGER.error("GET Device Details as JSON :: Exception occured while reading the device details and constructing JSON :" + pException);
		}
		return pDeviceDetailsList;
	}

	/**
	 * Builds JSON object with device details "key feature" values. 
	 */
	private JSONObject buildKeyFeaturesJSON(ResourceResolver pResourceResolver, Node pDeviceNode,SlingHttpServletRequest pRequest) 
			throws JSONException, PathNotFoundException, ValueFormatException, RepositoryException {
		
	    String keyFeatureTabNameValue=getTabName(KEY_FEATURES_KEY,pRequest);
	    
		JSONArray keyFeaturesJSONArray = new JSONArray();
		JSONObject keyFeaturesJSONObject = null;
		
		getKeyFeaturePar(keyFeaturesJSONArray, pDeviceNode, pResourceResolver, "jcr:content/devicetabs/leftfeaturepar");
		getKeyFeaturePar(keyFeaturesJSONArray, pDeviceNode, pResourceResolver,"jcr:content/devicetabs/rightfeaturepar");
		
		if (keyFeaturesJSONArray.length() > 0) {
			keyFeaturesJSONObject = new JSONObject();
			keyFeaturesJSONObject.put(TYPE,TYPE_KEY_FEATURES);
			keyFeaturesJSONObject.put(TABNAME,keyFeatureTabNameValue);
			keyFeaturesJSONObject.put(CONTENTS, keyFeaturesJSONArray);
		}

		return keyFeaturesJSONObject;
	}
	
	/**
	 * Builds JSON object with device details "device feature" values. 
	 */
	private JSONObject buildFeaturesJSON(ResourceResolver pResourceResolver, Node pDeviceNode,SlingHttpServletRequest pRequest) throws PathNotFoundException, ValueFormatException, RepositoryException, JSONException {
		
	    String featuresTabNameValue=getTabName(FEATURES_KEY,pRequest);
		JSONArray featuresJSONArray = new JSONArray();
		JSONObject featuresJSONObject = null;
		
		getDeviceDeatilsParNodeInfo(featuresJSONArray, pDeviceNode, pResourceResolver, "jcr:content/devicetabs/leftdetailpar", featuresTabNameValue,pRequest);
		getDeviceDeatilsParNodeInfo(featuresJSONArray, pDeviceNode, pResourceResolver,"jcr:content/devicetabs/rightdetailpar", featuresTabNameValue,pRequest);
		
		if (featuresJSONArray.length() > 0) {
			featuresJSONObject = new JSONObject();
			featuresJSONObject.put(TYPE,TYPE_FEATURES);
			featuresJSONObject.put(TABNAME,featuresTabNameValue);
			featuresJSONObject.put(CONTENTS, featuresJSONArray);
		}

		return featuresJSONObject;	
	}

	/**
	 * Builds JSON object with device details "technical specifications" values. 
	 */
	private JSONObject buildTechnicalSpecifications(
			ResourceResolver pResourceResolver, Node pDeviceNode,SlingHttpServletRequest pRequest) throws PathNotFoundException, ValueFormatException, RepositoryException, JSONException {
		
	    String techSpecsTabNameValue=getTabName(TECHNICAL_SPECIFICATIONS_KEY,pRequest);
	    JSONArray techSpecsJSONArray = new JSONArray();
		JSONObject techSpecsJSONObject = null;
		
		getDeviceDeatilsParNodeInfo(techSpecsJSONArray, pDeviceNode, pResourceResolver, "jcr:content/devicetabs/leftspecpar", techSpecsTabNameValue,pRequest);
		getDeviceDeatilsParNodeInfo(techSpecsJSONArray, pDeviceNode, pResourceResolver,"jcr:content/devicetabs/rightspecpar", techSpecsTabNameValue,pRequest);
		
		if (techSpecsJSONArray.length() > 0) {
			techSpecsJSONObject = new JSONObject();
			techSpecsJSONObject.put(TYPE,TYPE_TECHNICAL_SPECIFICATIONS);
			techSpecsJSONObject.put(TABNAME,techSpecsTabNameValue);
			techSpecsJSONObject.put(CONTENTS, techSpecsJSONArray);
		}

		return techSpecsJSONObject;	
	}
	
	/**
	 * Builds JSON object with device details "in the box" values. 
	 */
	private JSONObject buildInTheBoxJSON(ResourceResolver pResourceResolver,
			Node pDeviceNode,SlingHttpServletRequest pRequest) throws PathNotFoundException, ValueFormatException, RepositoryException, JSONException {
		
	    String inTheBoxTabNameValue=getTabName(IN_THE_BOX_KEY,pRequest);
	    JSONArray inTheBoxJSONArray = new JSONArray();
		JSONObject inTheBoxJSONObject = null;
		
		getDeviceDeatilsInTheBoxParNodeInfo(inTheBoxJSONArray, pDeviceNode, pResourceResolver, "jcr:content/devicetabs/leftintheboxpar");
		getDeviceDeatilsInTheBoxParNodeInfo(inTheBoxJSONArray, pDeviceNode, pResourceResolver,"jcr:content/devicetabs/rightintheboxpar");
		
		if (inTheBoxJSONArray.length() > 0) {
			inTheBoxJSONObject = new JSONObject();
			inTheBoxJSONObject.put(TYPE,TYPE_IN_THE_BOX);
			inTheBoxJSONObject.put(TABNAME, inTheBoxTabNameValue);
			inTheBoxJSONObject.put(CONTENTS, inTheBoxJSONArray);
		}

		return inTheBoxJSONObject;	
	}

	private void getDeviceDeatilsInTheBoxParNodeInfo(
			JSONArray pInTheBoxJSONArray, Node pDeviceNode,
			ResourceResolver pResourceResolver, String pPath) throws JSONException, RepositoryException {
		validateMethodParameters(pInTheBoxJSONArray, pDeviceNode, pResourceResolver, pPath);
		
		if (!pDeviceNode.hasNode(pPath)) {
			LOGGER.debug("Device Node [" + pDeviceNode.getPath() + "] does not have child node [" + pPath + "].");
			return;
		}
		
		Node parNode = pDeviceNode.getNode(pPath);
		if (parNode == null) {
			LOGGER.debug("Unable to get Device Node's [" + pDeviceNode.getPath() + "] child node [" + pPath + "].");
			return;
		}

		NodeIterator childNodes = parNode.getNodes();
		if (childNodes == null) {
			LOGGER.debug("Unable to get Device Node's [" + pDeviceNode.getPath() + "] immediate child node's [" + pPath + "] child nodes.");
			return;
		}

		JSONObject inTheBoxJSONObject = null;
		
		for (NodeIterator ni = childNodes; ni.hasNext();) {

			Node childNode = ni.nextNode();
			if (childNode == null) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node is null, looping thru next node.");
				continue;
			}
			if (!childNode.hasProperty("path")) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node doesn't have property \"path\", looping thru next node.");
				continue;
			}
			
			String sharedContentPath = (childNode.getProperty("path") != null) ? childNode.getProperty("path").getString() : null;
			
			if (sharedContentPath == null) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node's path property has null value, looping thru next node.");
				continue;
			}
			
			Resource sharedContentResource = (sharedContentPath != null) ? pResourceResolver.getResource(sharedContentPath) : null;
			
			if (sharedContentResource == null) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node's Resource is null, looping thru next node.");
				continue;
			}
			
			ValueMap sharedContentValueMap = sharedContentResource.adaptTo(ValueMap.class);
			if (sharedContentValueMap == null) {
				LOGGER.debug("sharedContentPath's [" + sharedContentPath + "] valueMap is null, looping thru next node.");				
				continue;
			}
		
			JSONObject inTheBoxBulletJSONObject = new JSONObject();
			inTheBoxBulletJSONObject.put("value", sharedContentValueMap.get("accessoryTitle"));
			
			Resource sharedContentIamgeResource = pResourceResolver.getResource(sharedContentPath + "/image");
			if (sharedContentIamgeResource != null) {
				ValueMap inTheBoxIamgeMap = sharedContentIamgeResource.adaptTo(ValueMap.class);
			    // checking the presence of fileReference property in image component
				if(inTheBoxIamgeMap.get("fileReference") != null)
				{
				 inTheBoxBulletJSONObject.put("imagePath", pResourceResolver.map((String) inTheBoxIamgeMap.get("fileReference")));
				}
			}
			pInTheBoxJSONArray.put(inTheBoxBulletJSONObject);
		}
		if (pInTheBoxJSONArray.length() > 0) {
			inTheBoxJSONObject = new JSONObject();
			inTheBoxJSONObject.put("inTheBoxBullets", pInTheBoxJSONArray);
		}
	}

	private void getDeviceDeatilsParNodeInfo(JSONArray pFeaturesJSONArray, Node pDeviceNode,
			ResourceResolver pResourceResolver, String pPath, String pFeatureOrSpec,SlingHttpServletRequest pRequest) throws RepositoryException, JSONException {

		validateMethodParameters(pFeaturesJSONArray, pDeviceNode, pResourceResolver, pPath);
		
		if (!pDeviceNode.hasNode(pPath)) {
			LOGGER.debug("Device Node [" + pDeviceNode.getPath() + "] does not have child node [" + pPath + "].");
			return;
		}
		
		Node parNode = pDeviceNode.getNode(pPath);
		if (parNode == null) {
			LOGGER.debug("Unable to get Device Node's [" + pDeviceNode.getPath() + "] child node [" + pPath + "].");
			return;
		}

		NodeIterator childNodes = parNode.getNodes();
		if (childNodes == null) {
			LOGGER.debug("Unable to get Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child nodes.");
			return;
		}

		JSONObject featureJSONObject = null;
		JSONArray featureJSONArray = null;

		for (NodeIterator ni = childNodes; ni.hasNext();) {

			Node childNode = ni.nextNode();
			if (childNode == null) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node is null, looping thru next node.");
				continue;
			}
			if (!childNode.hasProperty("path")) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node doesn't have property \"path\", looping thru next node.");
				continue;
			}
			
			String sharedContentPath = (childNode.getProperty("path") != null) ? childNode.getProperty("path").getString() : null;
			
			if (sharedContentPath == null) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node's path property has null value, looping thru next node.");
				continue;
			}
			
			Resource sharedContentResource = (sharedContentPath != null) ? pResourceResolver.getResource(sharedContentPath) : null;
			
			if (sharedContentResource == null) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node's Resource is null, looping thru next node.");
				continue;
			}
			
			ValueMap sharedContentValueMap = sharedContentResource.adaptTo(ValueMap.class);
			if (sharedContentValueMap == null) {
				LOGGER.debug("sharedContentPath's [" + sharedContentPath + "] valueMap is null, looping thru next node.");				
				continue;
			}
			
			if (sharedContentPath.endsWith("/categoryheader")) {
				// This node is identified as the feature header node (Ex: Camera, Music, Messaging, Email, etc.)
				if (featureJSONObject != null) {
					// since this object is already have the header and it's associated details bullets, let's add it to top level JSON array
					if (getTabName(FEATURES_KEY,pRequest).equals(pFeatureOrSpec)) {
						featureJSONObject.put("featureBullets", featureJSONArray);				
					} else if (getTabName(TECHNICAL_SPECIFICATIONS_KEY,pRequest).equals(pFeatureOrSpec)) {
						featureJSONObject.put("techSpecBullets", featureJSONArray);
					}
					pFeaturesJSONArray.put(featureJSONObject);
				}
				// re-instantiate irrespective of whether it is already instantiated or not to reset its value for every new category header
				featureJSONObject = new JSONObject();
				featureJSONArray = new JSONArray();
				
				// add a title and image to this category header JSONObject
				if (getTabName(FEATURES_KEY,pRequest).equals(pFeatureOrSpec)) {
					featureJSONObject.put("heading", sharedContentValueMap.get("name"));					
				} else if (getTabName(TECHNICAL_SPECIFICATIONS_KEY,pRequest).equals(pFeatureOrSpec)) {
					featureJSONObject.put("heading", sharedContentValueMap.get("jcr:title"));
				}

				Resource sharedContentIamgeResource = pResourceResolver.getResource(sharedContentPath + "/image");
				if (sharedContentIamgeResource != null) {
					ValueMap featureIamgeMap = sharedContentIamgeResource.adaptTo(ValueMap.class);
					// checking the presence of fileReference property in image component
					if(featureIamgeMap.get("fileReference") != null)
                    {
					 featureJSONObject.put("imagePath", pResourceResolver.map((String) featureIamgeMap.get("fileReference")));
                    }
				}
			} else {
				// This node is identified as the feature details bullet
				JSONObject featureBulletJSONObject = new JSONObject();
				featureBulletJSONObject.put("key", sharedContentValueMap.get("name"));
				String value = (String) sharedContentValueMap.get("value");
				if (StringUtils.isEmpty(value) || value.indexOf("<img") != -1) {
					featureBulletJSONObject.put("value", "checkbox"); 
				} else {
					value = (value.indexOf("href") != -1) ? StringEscapeUtils.escapeHtml(value) : value;
					featureBulletJSONObject.put("value", value); 
				}
				//checking the featureJSONArray value. For apple devices we are getting featureJSONArray is null
				if(featureJSONArray == null)
				{
				  featureJSONArray = new JSONArray();
				}
				featureJSONArray.put(featureBulletJSONObject);				
			}
		}
		// to add last element which we couldn't add in the for loop above
		if (featureJSONObject != null) {
			// since this object is already have the header and it's associated details bullets, let's add it to top level JSON array
		    if (getTabName(FEATURES_KEY,pRequest).equals(pFeatureOrSpec)) {
				featureJSONObject.put("featureBullets", featureJSONArray);				
			} else if (getTabName(TECHNICAL_SPECIFICATIONS_KEY,pRequest).equals(pFeatureOrSpec)) {
				featureJSONObject.put("techSpecBullets", featureJSONArray);
			}

			pFeaturesJSONArray.put(featureJSONObject);
		}
	}

	private void getKeyFeaturePar(
			JSONArray pKeyFeaturesJSONArray, Node pDeviceNode, ResourceResolver pResourceResolver, String pPath) 
					throws PathNotFoundException, ValueFormatException, RepositoryException, JSONException {
		
		validateMethodParameters(pKeyFeaturesJSONArray, pDeviceNode, pResourceResolver, pPath);
		
		if (!pDeviceNode.hasNode(pPath)) {
			LOGGER.debug("Device Node [" + pDeviceNode.getPath() + "] does not have child node [" + pPath + "].");
			return;
		}
		
		Node parNode = pDeviceNode.getNode(pPath);
		if (parNode == null) {
			LOGGER.debug("Unable to get Device Node's [" + pDeviceNode.getPath() + "] child node [" + pPath + "].");
			return;
		}

		NodeIterator childNodes = parNode.getNodes();
		if (childNodes == null) {
			LOGGER.debug("Unable to get Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child nodes.");
			return;
		}

		for (NodeIterator ni = childNodes; ni.hasNext();) {
			Node childNode = ni.nextNode();
			if (childNode == null) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node is null, looping thru next node.");
				continue;
			}
			if (!childNode.hasProperty("path")) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node doesn't have property \"path\".");
				continue;
			}
			
			String sharedContentPath = (childNode.getProperty("path") != null) ? childNode.getProperty("path").getString() : null;
			Resource sharedContentResource = (sharedContentPath != null) ? pResourceResolver.getResource(sharedContentPath) : null;
			
			if (sharedContentResource == null) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node's Resource is null, looping thru next node.");
				continue;
			}

			ValueMap sharedContentValueMap = sharedContentResource.adaptTo(ValueMap.class);
			if (sharedContentValueMap == null) {
				LOGGER.debug("Device Node's [" + pDeviceNode.getPath() + "] child node's [" + pPath + "] child node's valueMap is null, looping thru next node.");				
				continue;
			}
			
			Resource sharedContentJcrContentResource = pResourceResolver.getResource(sharedContentPath.substring(0, sharedContentPath.lastIndexOf("jcr:content") + "jcr:content".length()));
			ValueMap sharedContentJcrContentValueMap = sharedContentJcrContentResource.adaptTo(ValueMap.class);
			
			JSONObject keyFeatureJSON = new JSONObject();
			keyFeatureJSON.append("heading", (String) sharedContentJcrContentValueMap.get("jcr:title"));			
			keyFeatureJSON.append("desc", StringEscapeUtils.escapeHtml((String) sharedContentValueMap.get("desc")));
			
			Resource sharedContentIamgeResource = pResourceResolver.getResource(sharedContentPath.substring(0, sharedContentPath.lastIndexOf("jcr:content") + "jcr:content".length()) + "/image");
			ValueMap featureIamgeMap = sharedContentIamgeResource.adaptTo(ValueMap.class);
			// checking the presence of fileReference property in image component
			if(featureIamgeMap.get("fileReference") != null)
			{
			 keyFeatureJSON.append("imagePath", pResourceResolver.map((String) featureIamgeMap.get("fileReference")));
			}
			pKeyFeaturesJSONArray.put(keyFeatureJSON);
		}
	}

	private void validateMethodParameters(JSONArray pKeyFeaturesJSONArray,
			Node pDeviceNode, ResourceResolver pResourceResolver, String pPath) throws RepositoryException {
		if (pKeyFeaturesJSONArray == null) {
			throw new InvalidParameterException("Required Param JSONArray is null.");
		}

		if (pResourceResolver == null) {
			throw new InvalidParameterException("Required Param ResourceResolver is null.");
		}
		
		if (pDeviceNode == null) {
			throw new InvalidParameterException("Required Param device details page NODE is null.");
		}
		
		if (pPath == null) {
			throw new InvalidParameterException("Required Param device details page's [" + pDeviceNode.getPath() + "] child NODE path is null.");
		}
	}	
	
	private static String getTabName(String key,SlingHttpServletRequest request){
	    String value="";
	    if(null!=request.getResourceBundle(request.getLocale())){
	        value=request.getResourceBundle(request.getLocale()).getString(key);
	    }
	   return value; 
	}
}
