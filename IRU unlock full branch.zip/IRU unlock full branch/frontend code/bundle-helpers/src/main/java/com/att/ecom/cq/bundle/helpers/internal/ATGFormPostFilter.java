package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, metatype = true, label="ATG Form Post Filter", description="Filter to change ATG Form Posts from POST to GET for proper page handling.")
@Property(name="pattern", value="/.*", propertyPrivate=true)
@Service
public class ATGFormPostFilter implements Filter {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private static final boolean DEFAULT_ENABLED = true;
	private static final boolean DEFAULT_SLOWERANDBETTER = false;

	@Property(label = "Enabled", description = "Is this filter enabled?", boolValue = DEFAULT_ENABLED)
	private static final String PROP_ENABLED = "atgform.enabled";
	
	@Property(label = "Slower and Better", description = "Normally checks for _dynSessConf. Should we check for any _D:/<path> param instead??", boolValue = DEFAULT_ENABLED)
	private static final String PROP_SLOWERANDBETTER = "atgform.slowerAndBetter";
	
	private boolean enabled;
	private boolean slowerAndBetter;
	
	protected void activate(ComponentContext ctx) {
		Dictionary<?,?> props = ctx.getProperties();
		this.enabled = OsgiUtil.toBoolean(props.get(PROP_ENABLED), DEFAULT_ENABLED);
		this.slowerAndBetter = OsgiUtil.toBoolean(props.get(PROP_SLOWERANDBETTER), DEFAULT_SLOWERANDBETTER);
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		boolean chainPassed = false;
		if (enabled) {
			if (request instanceof HttpServletRequest
					&& response instanceof HttpServletResponse) {

				HttpServletRequest httpRequest = (HttpServletRequest) request;
				if (httpRequest.getMethod().equals("POST")) {
				
					boolean isDynamoForm = false;
					
					if (!slowerAndBetter) {
						// Detect an ATG form by the presence of a form parameter
						// named "_dynSessConf".
						String val = httpRequest.getParameter("_dynSessConf");
						if ((val != null) && (val.length() > 0)) {
							isDynamoForm = true;
							
							logger.debug("This is a dynamo form, based on fast '_dynSessConf' check.");
						}
						
					} else { // slowerAndBetter
						// Loop through all form params and look for any that start with "_D:/".
						String paramName;
						Enumeration paramNames = httpRequest.getParameterNames();
						
						while ((paramNames.hasMoreElements()) && (!isDynamoForm)) {
							paramName = (String)paramNames.nextElement();
							if (paramName.startsWith("_D:/")) {
								isDynamoForm = true;
								
								logger.debug("This is a dynamo form, based on param '" + paramName + "'.");
							}
							
						}
					}
					
					if (isDynamoForm) {
						// Create a version of the request object which fools CQ into believing this
						// is a GET, not a POST. This is the best way to do it, according to Justin from CQ.
						HttpServletRequest httpGETRequest = new HttpServletRequestWrapper(httpRequest) {
							public String getMethod() { return "GET"; }
						};
						
						chainPassed = true;
						chain.doFilter(httpGETRequest, response);
					}
				}
			}
		}
		
		if (chainPassed == false) {
			chain.doFilter(request, response);
		}
	}

	@Override
	public void destroy() {
	}

}
