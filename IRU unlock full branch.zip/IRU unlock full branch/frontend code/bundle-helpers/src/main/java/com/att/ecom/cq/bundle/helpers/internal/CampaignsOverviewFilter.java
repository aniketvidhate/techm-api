package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.util.Calendar;
import java.util.Iterator;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.servlet.Filter;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingFilter;
import org.apache.felix.scr.annotations.sling.SlingFilterScope;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.request.RequestPathInfo;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.commons.json.JSONException;

import com.day.cq.commons.JSONWriterUtil;
import com.day.cq.commons.TidyJSONWriter;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.tagging.Tag;
import com.day.cq.wcm.api.Page;
import com.day.cq.xss.XSSProtectionService;
import com.day.text.Text;

/**
 * Filter which intercepts requests for the CampaignsOverviewServlet and produces compatible output while descending
 * into folders within /content/campaigns.
 */
@SlingFilter(scope = SlingFilterScope.REQUEST, order = 0)
public class CampaignsOverviewFilter extends AbstractOverlayFilter implements Filter {

    /**
     * Adapter class to use an Iterator as part of a for..in.. loop
     */
    private class IteratorAdapter<T> implements Iterable<T> {

        /**
         * The wrapped iterator.
         */
        private Iterator<T> mAdapted;

        /**
         * Construct a new instance wrapping the provided iterator
         * 
         * @param pAdapted
         *            the iterator to wrap
         */
        private IteratorAdapter(Iterator<T> pAdapted) {
            this.mAdapted = pAdapted;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public Iterator<T> iterator() {
            return mAdapted;
        }
    }

    /**
     * The blank string.
     */
    private static final String BLANK_STRING = "";

    /**
     * The default path to look up.
     */
    private static final String DEFAULT_PATH = "/content/campaigns";

    /**
     * The format to use to generate png image references.
     */
    private static final String FMT_IMG_PNG = "%s.img.png";

    /**
     * The format to generate the path to an image within the main par.
     */
    private static final String FMT_PAR_IMAGE = "%s/jcr:content/par/image";

    /**
     * The format to generate the path to an image a textimage component within the main par.
     */
    private static final String FMT_PAR_TEXTIMAGE = "%s/jcr:content/par/textimage/image";

    /**
     * The format to use to generate png image thumbnail references.
     */
    private static final String FMT_THUMB_PNG = "%s.thumb.png";

    /**
     * The format to build a display title.
     */
    private static final String FMT_TITLE = "%s (%s)";

    /**
     * The key which contains the active flag.
     */
    private static final String KEY_ACTIVE = "active";

    /**
     * The key which contains the description.
     */
    private static final String KEY_DESCRIPTION = "description";

    /**
     * The key which contains the full title.
     */
    private static final String KEY_FULL_TITLE = "fullTitle";

    /**
     * The key which contains newsletters.
     */
    private static final String KEY_NEWSLETTERS = "newsletters";

    /**
     * The key which contains the off time.
     */
    private static final String KEY_OFF_TIME = "offTime";

    /**
     * The key which contains the on time.
     */
    private static final String KEY_ON_TIME = "onTime";

    /**
     * The key for campaign paths.
     */
    private static final String KEY_PATH = "path";

    /**
     * The key for segments.
     */
    private static final String KEY_SEGMENTS = "segments";

    /**
     * The key for tags.
     */
    private static final String KEY_TAGS = "tags";

    /**
     * The key for the teaser list.
     */
    private static final String KEY_TEASERS = "teasers";

    /**
     * The key for the thumbnail image.
     */
    private static final String KEY_THUMBNAIL = "thumbnail";

    /**
     * The key for the title.
     */
    private static final String KEY_TITLE = "title";

    /**
     * The request parameter containing the path.
     */
    private static final String PATH_PARAM = KEY_PATH;

    /**
     * The property name for the segment list.
     */
    private static final String PN_CQ_SEGMENTS = "cq:segments";

    /**
     * The request extension.
     */
    private static final String RQ_EXTENSION = "json";

    /**
     * The request extension.
     */
    private static final String RQ_METHOD = "GET";

    /**
     * The request path.
     */
    private static final String RQ_PATH = "/libs/mcm/campaigns";

    /**
     * The resource type for newsletters.
     */
    private static final String RT_NEWSLETTER = "mcm/components/newsletter/page";

    /**
     * The resource type for teaser pages.
     */
    private static final String RT_TEASER = "cq/personalization/components/teaserpage";

    /**
     * Parameter indicating whether or not to produce tidy output.
     */
    private static final String TIDY_PARAM = "tidy";

    /**
     * Utility method to determine if the page is a newsletter page.
     * 
     * @param pCandidate
     *            the candidate page
     * 
     * @return true if the page is a newsletter page
     */
    private static boolean isNewsletter(final Page pCandidate) {
        return ResourceUtil.isA(pCandidate.getContentResource(), RT_NEWSLETTER);
    }

    /**
     * Utility method to determine if the page is a teaser page.
     * 
     * @param pCandidate
     *            the candidate page
     * 
     * @return true if the page is a teaser page
     */
    private static boolean isTeaser(final Page pCandidate) {
        return ResourceUtil.isA(pCandidate.getContentResource(), RT_TEASER);
    }

    /**
     * Render a single campaign as a JSON object.
     * 
     * @param pOut
     *            the JSON writer
     * @param pResolver
     *            the resource resolver
     * @param pCampaign
     *            the campaign to render
     * @param pIsTeaser
     *            true if the campaign is a teaser
     * @param pXss
     *            the XSS service
     */
    private static void renderCampaign(final TidyJSONWriter pOut, final ResourceResolver pResolver,
            final Page pCampaign, final boolean pIsTeaser, final XSSProtectionService pXss) {
        try {
            pOut.object();

            JSONWriterUtil.write(pOut, KEY_TITLE, pCampaign.getTitle(), JSONWriterUtil.WriteMode.BOTH, pXss);
            final String desc = pCampaign.getDescription();
            JSONWriterUtil.write(pOut, KEY_DESCRIPTION, desc == null ? BLANK_STRING : desc,
                    JSONWriterUtil.WriteMode.BOTH, pXss);
            pOut.key(KEY_PATH).value(pCampaign.getPath());
            pOut.key(KEY_ACTIVE).value(pCampaign.isValid());
            final Calendar on = pCampaign.getOnTime();
            pOut.key(KEY_ON_TIME).value(on != null ? on.getTimeInMillis() : BLANK_STRING);
            final Calendar off = pCampaign.getOffTime();
            pOut.key(KEY_OFF_TIME).value(off != null ? off.getTimeInMillis() : BLANK_STRING);
            pOut.key(KEY_TAGS);
            pOut.array();
            final Tag[] tags = pCampaign.getTags();
            for (final Tag tag : tags) {
                pOut.object();
                JSONWriterUtil.write(pOut, KEY_FULL_TITLE, tag.getTitlePath(), JSONWriterUtil.WriteMode.BOTH, pXss);
                JSONWriterUtil.write(pOut, KEY_TITLE, tag.getTitle(), JSONWriterUtil.WriteMode.BOTH, pXss);
                pOut.endObject();
            }
            pOut.endArray();

            pOut.key(KEY_SEGMENTS);
            pOut.array();
            final Node node = pCampaign.adaptTo(Node.class);
            try {
                final Property segments = node.getNode(JcrConstants.JCR_CONTENT).getProperty(PN_CQ_SEGMENTS);
                if (segments.isMultiple()) {
                    for (final Value segment : segments.getValues()) {
                        final String s = segment.getString();
                        pOut.object();
                        pOut.key(KEY_PATH).value(s);
                        pOut.key(KEY_TITLE).value(Text.getName(s));
                        pOut.endObject();
                    }
                } else {
                    final String s = segments.getString();
                    pOut.object();
                    pOut.key(KEY_PATH).value(s);
                    pOut.key(KEY_TITLE).value(Text.getName(s));
                    pOut.endObject();
                }
            } catch (RepositoryException re) {
            }
            pOut.endArray();

            if (pIsTeaser) {
                String imagePath = String.format(FMT_THUMB_PNG, pCampaign.getPath());
                // try to find first available image
                Resource imgRes = pResolver.getResource(String.format(FMT_PAR_IMAGE, pCampaign.getPath()));
                if (imgRes != null) {
                    imagePath = String.format(FMT_IMG_PNG, imgRes.getPath());
                } else {
                    imgRes = pResolver.getResource(String.format(FMT_PAR_TEXTIMAGE, pCampaign.getPath()));
                    if (imgRes != null) {
                        imagePath = String.format(FMT_IMG_PNG, imgRes.getPath());
                    }
                }
                pOut.key(KEY_THUMBNAIL).value(imagePath);
            } else {
                // newsletter page
                Resource imgRes = null;
                String imagePath = pCampaign.getTemplate().getIconPath();
                if (imagePath != null) {
                    imgRes = pResolver.getResource(imagePath);
                }
                if (imgRes == null) {
                    imagePath = pCampaign.getTemplate().getThumbnailPath();
                    if (imagePath != null) {
                        imgRes = pResolver.getResource(imagePath);
                        if (imgRes == null) {
                            imagePath = null;
                        }
                    }
                }
                if (imagePath != null)
                    pOut.key(KEY_THUMBNAIL).value(imagePath);
            }

            pOut.endObject();

        } catch (JSONException e) {
        }
    }

    /**
     * Reference to the cross-site-scripting protection service.
     */
    @Reference
    private XSSProtectionService mXss;

    /**
     * {@inheritDoc}
     */
    @Override
    protected void handle(final SlingHttpServletRequest pRequest, final SlingHttpServletResponse pResponse)
            throws IOException {
        try {
            setJsonHeaders(pResponse);

            final ResourceResolver resolver = pRequest.getResourceResolver();

            final String path = pRequest.getParameter(PATH_PARAM) != null ? pRequest.getParameter(PATH_PARAM)
                    : DEFAULT_PATH;

            final Resource root = resolver.getResource(path);

            final TidyJSONWriter out = new TidyJSONWriter(pResponse.getWriter());
            out.setTidy(Boolean.parseBoolean(pRequest.getParameter(TIDY_PARAM)));

            out.array();

            renderCampaignFolder(root, resolver, out);

            out.endArray();
        } catch (JSONException e) {
        } catch (RepositoryException e) {
        }

    }


    /**
     * Render a campaign folder recursively.
     * 
     * @param pRoot
     *            the folder node
     * @param pResolver
     *            the resource resolver
     * @param pOut
     *            the output writer
     * 
     * @throws JSONException
     *             if the serialization fails
     * @throws RepositoryException
     *             if reading from the repository fails
     */
    private void renderCampaignFolder(final Resource pRoot, final ResourceResolver pResolver, final TidyJSONWriter pOut)
            throws JSONException, RepositoryException {
        final Iterator<Resource> campaignsRoot = pResolver.listChildren(pRoot);
        while (campaignsRoot.hasNext()) {
            final Resource campaignCandidate = campaignsRoot.next();
            final Page campaigns = campaignCandidate.adaptTo(Page.class);
            if (campaigns == null) {
                Node campaignCandidateNode = campaignCandidate.adaptTo(Node.class);
                if (campaignCandidateNode != null && campaignCandidateNode.isNodeType(JcrConstants.NT_FOLDER)) {
                    renderCampaignFolder(campaignCandidate, pResolver, pOut);
                }
                continue;
            }

            // parents (campaign pages)
            pOut.object();
            final String title = String.format(FMT_TITLE, campaigns.getTitle(), campaigns.getPath());
            JSONWriterUtil.write(pOut, KEY_TITLE, title, JSONWriterUtil.WriteMode.BOTH, this.mXss);
            pOut.key(KEY_PATH).value(campaigns.getPath());

            pOut.key(KEY_TEASERS);
            pOut.array();
            for (final Page teaser : new IteratorAdapter<Page>(campaigns.listChildren())) {
                if (!isTeaser(teaser)) {
                    continue;
                }
                renderCampaign(pOut, pResolver, teaser, true, this.mXss);
            }
            pOut.endArray();

            pOut.key(KEY_NEWSLETTERS);
            pOut.array();
            for (final Page newsletter : new IteratorAdapter<Page>(campaigns.listChildren())) {
                if (!isNewsletter(newsletter))
                    continue;
                renderCampaign(pOut, pResolver, newsletter, false, this.mXss);
            }
            pOut.endArray();

            pOut.endObject();
        }
    }

    /**
     * Determine if this is a request we should overwrite, i.e. it is a campaigns overview request.
     * 
     * @param pSlingRequest
     *            the request
     * @return true if this is a request we should overwrite.
     */
    @Override
    protected boolean shouldOverlayRequest(final SlingHttpServletRequest pSlingRequest) {
        final RequestPathInfo requestPathInfo = pSlingRequest.getRequestPathInfo();
        return RQ_PATH.equals(requestPathInfo.getResourcePath()) && RQ_EXTENSION.equals(requestPathInfo.getExtension())
                && RQ_METHOD.equals(pSlingRequest.getMethod());
    }
}
