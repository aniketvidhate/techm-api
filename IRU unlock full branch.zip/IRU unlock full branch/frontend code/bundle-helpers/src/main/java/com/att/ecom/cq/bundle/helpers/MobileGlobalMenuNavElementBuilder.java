/*
 * Mobile Global Menu Nav Element Builder.
 * @author Pratap Cheruvu (rc8891)
 * @created on March 05 2013
 */


package com.att.ecom.cq.bundle.helpers;



import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.Value;
import javax.jcr.Session;

import com.day.cq.wcm.api.PageManager;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.json.JSONArray;

import com.day.cq.wcm.api.Page;


@Component(immediate=true)
@Service(value=MobileGlobalMenuNavElementBuilder.class)

public class MobileGlobalMenuNavElementBuilder 
{

	private Logger logger = LoggerFactory.getLogger(MobileGlobalMenuNavElementBuilder.class);

	@Reference
	private SlingRepository slingRepository;
	
	@Reference
	private ResourceResolverFactory resourceResolverFactory;	

	private Session administrativeSession;

	protected void activate(ComponentContext ctx) throws RepositoryException 
	{
		administrativeSession = slingRepository.loginAdministrative(null);
	}
	
	protected void deactivate(ComponentContext ctx) {
		administrativeSession.logout();
	}
	/*
     * Get the CQ template Paths
     */	
	public synchronized String buildElements(String currentPagePath) throws RepositoryException 
	{
		String output="";		
		ResourceResolver adminResolver = null;
		try{
			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			PageManager pageManager = adminResolver.adaptTo(PageManager.class);
			Page rootPage = pageManager.getPage(currentPagePath);
			
			JSONObject obj = new JSONObject();
			JSONArray menuItemlist = new JSONArray();
			JSONObject idobj = new JSONObject();
			JSONArray menuGrouplist = new JSONArray();
			JSONObject menuGroupObject = new JSONObject();
			JSONObject menuObject = new JSONObject();
			String mapURL="";
			if( null != rootPage){
				Resource rootpageRes = rootPage.getContentResource();
				Resource rootpagemainpar = adminResolver.getResource(rootpageRes , "mainpar");
				if(null != rootpagemainpar){
					Node rootpagemainNode = rootpagemainpar.adaptTo(Node.class);  
					for ( NodeIterator ni = rootpagemainNode .getNodes(); ni.hasNext();) {
		            	Node tempNode =  ni.nextNode();
		            	idobj = new JSONObject();
		            	menuItemlist = new JSONArray();
		            	if (tempNode.hasProperty("chooseid")) {		            		 
		            		idobj.put("id", tempNode.getProperty("chooseid").getString());
		                } //end of   chooseid
		            	//Get All tiles
		                for ( NodeIterator tempnodeIterator = tempNode.getNodes(); tempnodeIterator .hasNext();) {
		                	Node tempIteratorNode =  tempnodeIterator .nextNode();
		                	for ( NodeIterator tempIteratorNodeIterator = tempIteratorNode .getNodes(); tempIteratorNodeIterator .hasNext();) {
		                		Node menuitemsNode =  tempIteratorNodeIterator .nextNode();
		                		if (menuitemsNode .hasProperty("type")) {
		                			if( menuitemsNode.getProperty("type").getString().equals("title")){
		                				if (menuitemsNode .hasProperty("linkText")) {		                				
		                					idobj.put("value", menuitemsNode.getProperty("linkText").getString());
		                				}
		                				if (menuitemsNode .hasProperty("linkUrl")) {
		                					mapURL=menuitemsNode.getProperty("linkUrl").getString();
		                					if(mapURL.startsWith("/content/")){
		                						mapURL=adminResolver.map(mapURL); 
		                						if((mapURL.lastIndexOf(".")<=0) && (mapURL.substring(mapURL.lastIndexOf("/")).length()>1) ) {
		                							mapURL+=".html"	;
		                						}
		                					}
		                					idobj.put("href", mapURL);
		                				}
		                			}// end of if menuitem node type for title
		                			else if( menuitemsNode.getProperty("type").getString().equals("normallink")){
		                				obj = new JSONObject();
		                				if (menuitemsNode .hasProperty("itemid")) {
		                					obj.put("id", menuitemsNode.getProperty("itemid").getString());
		                				}
		                				if (menuitemsNode .hasProperty("linkText")) {		                				
		                					obj.put("value", menuitemsNode.getProperty("linkText").getString());
		                				}
		                				if (menuitemsNode .hasProperty("linkUrl")) {
		                					mapURL=menuitemsNode.getProperty("linkUrl").getString();
		                					if(mapURL.startsWith("/content/")){
		                						mapURL=adminResolver.map(mapURL); 
		                						if((mapURL.lastIndexOf(".")<=0) && (mapURL.substring(mapURL.lastIndexOf("/")).length()>1) ) {
		                							mapURL+=".html"	;
		                						}
		                					}
		                					obj.put("href",mapURL);
		                				}
		                				menuItemlist.put(obj);		                				
		                			}// end of else menuitem node type for normallink
		                				
		                		}//end of if menuitems type
		                	}// end of for loop  tempIteratorNodeIterator
		                } // end of for loop  NodeIterator tempnodeIterator
						idobj.put("menuItem",menuItemlist);
						menuGrouplist.put(idobj);
					}// end of for NodeIterator ni
				} // end of rootpagemainpar				
			}// end of rootPage
			
			menuGroupObject.put("menuGroup",menuGrouplist);
			menuObject.put("menu",menuGroupObject);
			output = "menuBuilder("+menuObject.toString()+");";
			
		}//end of try
		catch(JSONException e1)
		{
			logger.error("Unable to create JSON object", e1);
		}
		
		catch (LoginException e) {
			logger.error("Unable to login for CMS Repository Report", e);
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
		}
		return output;	
	}
}
