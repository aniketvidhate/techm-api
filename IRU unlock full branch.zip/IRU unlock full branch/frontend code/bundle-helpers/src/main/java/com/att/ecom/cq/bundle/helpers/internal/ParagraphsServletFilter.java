package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Iterator;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.sling.SlingFilter;
import org.apache.felix.scr.annotations.sling.SlingFilterScope;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.wrappers.SlingHttpServletResponseWrapper;
import org.apache.sling.commons.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.TidyJSONWriter;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.WCMMode;
import com.day.cq.wcm.api.components.Component;
import com.day.cq.wcm.commons.WCMUtils;
import com.day.cq.wcm.foundation.Paragraph;
import com.day.cq.wcm.foundation.ParagraphSystem;
/**
 * Filter which intercepts requests for the ParagraphsServlet and
 * produces compatible output while descending throught the node hierarchy.
 */
@SlingFilter(scope = SlingFilterScope.REQUEST, order = 0)
public class ParagraphsServletFilter implements Filter {
    
    private static final String RQ_EXTENSION = "json";
    private static final String RQ_SELECTOR = "paragraphs";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (request instanceof SlingHttpServletRequest && response instanceof SlingHttpServletResponse) {
            SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) request;
            SlingHttpServletResponse slingResponse = (SlingHttpServletResponse) response;
            if (isParagraphsRequest(slingRequest)) {
                handle(slingRequest, slingResponse);
            } else {
                chain.doFilter(request, response);
            }
        } else {
            chain.doFilter(request, response);
        }
    }

    private void handle(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException, ServletException {
        Page page = request.getResource().adaptTo(Page.class);
        if (page == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Page not found: " + request.getResource().getPath());
            return;
        }

        Resource content = page.getContentResource();
        if (content == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Content not found: " + page.getPath());
            return;
        }

        try {
            new ParagraphWriter(request, response).writeParagraphSystems(content);
        } catch (JSONException e) {
            throw new ServletException("Failed to produce JSON output", e);
        }

    }

    private boolean isParagraphsRequest(SlingHttpServletRequest slingRequest) {
        return RQ_EXTENSION.equals(slingRequest.getRequestPathInfo().getExtension()) && RQ_SELECTOR.equals(slingRequest.getRequestPathInfo().getSelectorString());
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // NO-OP
    }
    
    @Override
    public void destroy() {
        // NO-OP
    }
    
    private static class ParagraphWriter {

        /** Logger */
        private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

        private final Writer writer;

        private final TidyJSONWriter json;

        private final SlingHttpServletRequest request;

        private final SlingHttpServletResponse response;

        private long count = 0;

        public ParagraphWriter(
                SlingHttpServletRequest request,
                SlingHttpServletResponse response) {
            this.writer = new StringWriter();
            this.json = new TidyJSONWriter(writer);
            this.request = request;
            this.response = response;
        }

        public void writeParagraphSystems(Resource content)
                throws JSONException, IOException {
            // We just want previews, so disable all interactive functionality
            WCMMode.DISABLED.toRequest(request);

            json.object();
            json.key("paragraphs");
            json.array();
            writeResource(content);
            json.endArray();
            json.key("count").value(count);
            json.endObject();

            response.setContentType("application/json; charset=UTF-8");
            response.getWriter().write(writer.toString());
        }

        private void writeResource(Resource content) throws JSONException {
            Iterator<Resource> iterator =
                content.getResourceResolver().listChildren(content);
            while (iterator.hasNext()) {
                Resource resource = iterator.next();
                Component component = WCMUtils.getComponent(resource);
                if (component != null && component.isContainer()) {
                    writeParagraphs(resource);
                }
                writeResource(resource);
            }
        }

        public void writeParagraphs(Resource container) throws JSONException {
            ParagraphSystem system = new ParagraphSystem(container);
            for (Paragraph paragraph : system.paragraphs()) {
                if (paragraph.getType() == Paragraph.Type.NORMAL) {
                    json.object();
                    json.key("path").value(paragraph.getPath());
                    json.key("html").value(render(paragraph.getPath()));
                    json.endObject();
                    count++;
                }
            }
        }

        public String render(String path) {
            try {
                final Writer buffer = new StringWriter();
                final ServletOutputStream stream = new ServletOutputStream() {
                    @Override
                    public void write(int b) throws IOException {
                        // TODO: Proper character encoding support!
                        buffer.append((char) b);
                    }
                };

                SlingHttpServletResponseWrapper wrapper =
                    new SlingHttpServletResponseWrapper(response) {
                        @Override
                        public ServletOutputStream getOutputStream() {
                            return stream;
                        }
                        @Override
                        public PrintWriter getWriter() throws IOException {
                            return new PrintWriter(buffer);
                        }
                        @Override
                        public SlingHttpServletResponse getSlingResponse() {
                            return super.getSlingResponse();
                        }
                    };

                // TODO: The ".html" suffix is a somewhat strange workaround
                // and should be removed. See SLING-633 for background.
                RequestDispatcher dispatcher =
                    request.getRequestDispatcher(path + ".html");
                dispatcher.include(request, wrapper);
                return buffer.toString();
            } catch (Exception e) {
                logger.error("Exception occured: " + e.getMessage(), e);
                return e.getMessage();
            }
        }
    }

    
}
