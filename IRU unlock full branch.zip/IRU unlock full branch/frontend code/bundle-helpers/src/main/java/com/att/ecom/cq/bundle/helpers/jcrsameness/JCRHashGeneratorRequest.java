/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.util.List;

/**
 * It holds the initial parameters to perform the hash generation.
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884)
 * @Since Jan 2, 2013 11:13:39 PM
 */
public class JCRHashGeneratorRequest {

    private String mPath = null;

    private List<String> mExcludedProperties = null;

    private List<String> mExcludedNodes = null;
    
    private String mValidateFailedReason = null;
    
    private boolean mIncludeDeactivatedNodes = true;
    
    private int mMode = 0;
    
    private boolean checkPagePrder = false;
    
    /**
     * @return the path
     */
    public String getPath() {
        return mPath;
    }

    /**
     * @param pPath
     *            the path to set
     */
    public void setPath(String pPath) {
        mPath = pPath;
    }

    /**
     * @return the excludedProperties
     */
    public List<String> getExcludedProperties() {
        return mExcludedProperties;
    }

    /**
     * @param pExcludedProperties
     *            the excludedProperties to set
     */
    public void setExcludedProperties(List<String> pExcludedProperties) {
        mExcludedProperties = pExcludedProperties;
    }

    /**
     * @return the validateFailedReason
     */
    public String getValidateFailedReason() {
        return mValidateFailedReason;
    }

    /**
     * @param pValidateFailedReason the validateFailedReason to set
     */
    public void setValidateFailedReason(String pValidateFailedReason) {
        mValidateFailedReason = pValidateFailedReason;
    }

    /**
     * @return the excludedNodes
     */
    public List<String> getExcludedNodes() {
        return mExcludedNodes;
    }

    /**
     * @param pExcludedNodes the excludedNodes to set
     */
    public void setExcludedNodes(List<String> pExcludedNodes) {
        mExcludedNodes = pExcludedNodes;
    }    
    
    public String toString() {
        StringBuilder toStringBuilder = new StringBuilder();
        toStringBuilder.append("PATH = ");
        toStringBuilder.append(getPath());
        toStringBuilder.append("\n EXCLUDED PROPS = ");
        toStringBuilder.append(toString(getExcludedProperties()));
        return toStringBuilder.toString();
    }

    private String toString(List<?> pList) {
        StringBuilder sb = new StringBuilder("(");
        String sep = "";
        for (Object object : pList) {
            if (object != null) {
                sb.append(sep).append(object.toString());
                sep = ":";
            }
        }
        return sb.append(')').toString();
    }

    /**
     * @return the includeDeactivatedNodes
     */
    public boolean isIncludeDeactivatedNodes() {
        return mIncludeDeactivatedNodes;
    }

    /**
     * @param pIncludeDeactivatedNodes the includeDeactivatedNodes to set
     */
    public void setIncludeDeactivatedNodes(boolean pIncludeDeactivatedNodes) {
        mIncludeDeactivatedNodes = pIncludeDeactivatedNodes;
    }

    /**
     * @return the mode
     */
    public int getMode() {
        return mMode;
    }

    /**
     * @param pMode the mode to set
     */
    public void setMode(int pMode) {
        mMode = pMode;
    }
	public boolean isCheckPagePrder() {
		return checkPagePrder;
	}

	public void setCheckPagePrder(boolean checkPagePrder) {
		this.checkPagePrder = checkPagePrder;
	}
}
