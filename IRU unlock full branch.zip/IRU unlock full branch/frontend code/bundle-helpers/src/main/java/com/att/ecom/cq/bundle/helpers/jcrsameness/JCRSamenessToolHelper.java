/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TimeZone;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.jcr.AccessDeniedException;
import javax.jcr.ItemNotFoundException;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.PersistableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Constants;
import org.osgi.framework.FrameworkUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.Agent;
import com.day.cq.replication.AgentConfig;
import com.day.cq.replication.AgentManager;

@Component(immediate = false)
@Service(value = com.att.ecom.cq.bundle.helpers.jcrsameness.JCRSamenessToolHelper.class)
@Properties({ @Property(name = Constants.SERVICE_DESCRIPTION, value = "JCR hash generator servlet Helper"),
        @Property(name = Constants.SERVICE_VENDOR, value = "CMS@ATT"),
        @Property(name = "process.label", value = "JCR Hash generator servlet helper") })
/**
 * It contains the utility methods required for the JCR hash generation.
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884)
 * @Since Dec 28, 2012 11:13:39 AM
 */
public class JCRSamenessToolHelper {

    private static final Logger logger = LoggerFactory.getLogger(JCRSamenessToolHelper.class);

    public static final String JCR_HASH_GENERATOR_SERVLET_PATH = "/system/att/servlets/jcrhashgenerator";

    @Reference
    private JCRHashGeneratorConfig mJCRHashGeneratorConfig;
    
    /**
     * It activates the component.
     * 
     * @param ctx
     *            ComponentContext object.
     */
    protected void activate(ComponentContext ctx) {
        logger.info(" started JCRSamenessToolHelper ");
    }

    /**
     * It calculates the hash for the JCR from the given starting path. 
     */
    public void calculateHashValueForEachNode(Node pCurrentNode, SortedMap<String, String> pCQPathToCQPathHashMap,
            ResourceResolver pAdminResolver, JCRHashGeneratorRequest pInputBean, Set<String> pDeactivatedNodes) throws RepositoryException,
            IOException {
        if (pCurrentNode == null) {
            logger.error("Node passed in is null");
            return;
        }

        boolean thisNodeToBeExcluded = canThisNodeExcluded(pCurrentNode, pInputBean, pAdminResolver, pDeactivatedNodes);
        if (thisNodeToBeExcluded) {
            if (logger.isDebugEnabled()) {
                logger.debug(" The Node - [" + pCurrentNode.getPath() + "] is excluded from Repository Comparison, so ignoring this node");
            }
            return;
        }
        try {
            if (pCurrentNode.hasNodes()) {
                NodeIterator childNodes = pCurrentNode.getNodes();
                if (childNodes != null && childNodes.getSize() > 0) {
                    Node childNode = null;
                    while (childNodes.hasNext()) {
                        childNode = (Node) childNodes.next();
                        if (childNode != null) {
                            calculateHashValueForEachNode(childNode, pCQPathToCQPathHashMap, pAdminResolver, pInputBean, pDeactivatedNodes);
                        }
                    }
                }
                // re-assigning the child nodes from current node
                childNodes = pCurrentNode.getNodes();
                if (childNodes != null && childNodes.getSize() > 0) {
                    BigInteger currentNodeHash = null;
                    BigInteger currentNodePlusChildrenHash = null;
                    String currentNodePath = pCurrentNode.getPath();
                    PersistableValueMap valueMapOfCurrentNode = getValueMap(currentNodePath, pAdminResolver);
                    String currentNodeConcatenatedString = getConcatenatedPropertyValues(valueMapOfCurrentNode,
                            pInputBean, pAdminResolver, pCurrentNode);
                    
                    boolean isPage = false,isLeafPage = false;
                	String coOrodinates = "";
                    if (valueMapOfCurrentNode != null) {
                        String jcrPrimaryType = (String) valueMapOfCurrentNode.get("jcr:primaryType");
                        if ("cq:Page".equals(jcrPrimaryType)) {
                            isPage = true;
                            if(isLeafPage(currentNodePath, pAdminResolver)) {
                            	logger.debug(currentNodePath+" is Leaf Page");
                            	isLeafPage = true;
                            	if(pInputBean.isCheckPagePrder()){
                            		coOrodinates = calculateNodeCoOrdinates(currentNodePath,pAdminResolver);
                            		logger.info("jcr coordinates of current campain, "+currentNodePath +" is "+coOrodinates);
                            		// Add Co-ordinates to the currentNodeConcatinated String if it is isPage and isLeafPage 
                            		// so that the hash includes the order as well
                            		currentNodeConcatenatedString+=coOrodinates;
                            	}
                            }else{
                            	logger.debug(currentNodePath+" is NOT Leaf Page");
                            	isLeafPage = false;
                            }
                        }
                    }                    
                    
                    
					currentNodeHash = getHashString(currentNodeConcatenatedString.toString());
                    StringBuilder currentNodePlusItsChildsConcString = (StringUtils
                            .isNotEmpty(currentNodeConcatenatedString)) ? new StringBuilder(
                            currentNodeConcatenatedString) : new StringBuilder();
                    SortedMap<String, String> map = new TreeMap<String, String>();

                    Node childNode = null;
                    String childNodePath = null;
                    while (childNodes.hasNext()) {
                        childNode = (Node) childNodes.next();
                        childNodePath = childNode.getPath();
                        if (!canThisNodeExcluded(childNode, pInputBean, pAdminResolver, pDeactivatedNodes)) {
                            map.put(childNodePath, pCQPathToCQPathHashMap.get(childNodePath));                            
                        }
                    }
                    for (String key : map.keySet()) {
                        if (key != null) {
                            currentNodePlusItsChildsConcString.append(map.get(key));
                        }
                    }
                    currentNodePlusChildrenHash = getHashString(currentNodePlusItsChildsConcString.toString());

                    String currentNodeHashPlustItsChildrenHash = (currentNodePlusChildrenHash != null) ? currentNodePlusChildrenHash.toString() : null;
                    String currentNodeHashValue = (currentNodeHash != null) ? currentNodeHash.toString() : null;
                    
                    String isPageAppendText = "";
                    if (isPage) {
                    	isPageAppendText += ":isPage=" + isPage;
                    	if(isLeafPage) {
                    		isPageAppendText += "|isLeafPage="+isLeafPage+"|"+coOrodinates;
                    	}
                    	
                        pCQPathToCQPathHashMap.put(currentNodePath, currentNodeHashValue + "," + currentNodeHashPlustItsChildrenHash + isPageAppendText);
                        
                    } else {
                        pCQPathToCQPathHashMap.put(currentNodePath, currentNodeHashValue + "," + currentNodeHashPlustItsChildrenHash);
                    }
                }
            } else {
                // Get the path from node only once to improve the performance
                String path = pCurrentNode.getPath();
                PersistableValueMap valueMapOfCurrentNode = getValueMap(path, pAdminResolver);
                boolean isPage = false;
                if (valueMapOfCurrentNode != null) {
                    String jcrPrimaryType = (String) valueMapOfCurrentNode.get("jcr:primaryType");
                    if ("cq:Page".equals(jcrPrimaryType)) {
                        isPage = true;
                        
                    }
                }
                String concatenatedString = getConcatenatedPropertyValues(valueMapOfCurrentNode, pInputBean, pAdminResolver, pCurrentNode);
                BigInteger currentNodeHash = getHashString(concatenatedString);

                String currentNodeHashValueAsString = (currentNodeHash != null) ? currentNodeHash.toString() : null;

                if (isPage) {
                    pCQPathToCQPathHashMap.put(path, currentNodeHashValueAsString + ":isPage=" + isPage);
                } else {
                    pCQPathToCQPathHashMap.put(path, currentNodeHashValueAsString);
                }
            }
        } catch (RepositoryException e) {
            logger.error("calculateHashValueForEachNode() : Error while traversing the node --> "
                    + pCurrentNode.getPath());
            e.printStackTrace();
        }
    }

    private boolean canThisNodeExcluded(Node pCurrentNode, JCRHashGeneratorRequest pInputBean, ResourceResolver pAdminResolver, Set<String> pDeactivatedNodes) throws RepositoryException {
        if (pCurrentNode == null || pInputBean == null) {
            logger.error("Either Node [" + pCurrentNode + "] or input bean [" + pInputBean + "] is null.");
            return false;
        }
        boolean exclude = false;
        String path = pCurrentNode.getPath();
        // Check 1 - verify whether this node is deactivated
        PersistableValueMap valueMapOfCurrentNode = getValueMap(path, pAdminResolver);        
        String replicationAction = (valueMapOfCurrentNode != null) ? (String) valueMapOfCurrentNode.get("cq:lastReplicationAction") : null;
        if ("Deactivate".equals(replicationAction)) {
            pDeactivatedNodes.add(path);
            if (!pInputBean.isIncludeDeactivatedNodes()) {
                return true;                    
            }
        }
        
        // Check 2 - verify whether this node is listed in Exclude Nodes list
        List<String> excludedNodes = pInputBean.getExcludedNodes();
        if (path != null && excludedNodes != null && excludedNodes.size() > 0) {
            for (String nodePath : excludedNodes) {
                if (StringUtils.isNotEmpty(nodePath)) {
                    if (path.indexOf(nodePath) != -1) {
                        return true;
                    }
                }
            }
        }
        return exclude;
    }

    public PersistableValueMap getValueMap(String pCurrentNodePath, ResourceResolver pAdminResolver) {
        if (StringUtils.isEmpty(pCurrentNodePath)) {
            
        }
        Resource resource = getJCRResource(pCurrentNodePath, pAdminResolver);
        if (resource == null) {
            logger.error("Unable to locate a resource for a path - " + pCurrentNodePath);
            return null;
        }

        return resource.adaptTo(PersistableValueMap.class);
    }
    
    
    private String calculateNodeCoOrdinates(String pCurrentNodePath, ResourceResolver pAdminResolver) {
    	int x = 0,y=0;
    	Resource currentNodeResource = getJCRResource(pCurrentNodePath, pAdminResolver);
    	Node currentNode = currentNodeResource.adaptTo(Node.class);
    	
    	try {
    		x=currentNode.getDepth();
			Node curentNodeParent = currentNode.getParent();
			for (NodeIterator childNodeItr = curentNodeParent.getNodes(); childNodeItr.hasNext();) {
				Node childNode = (Node) childNodeItr.next();
				if(pCurrentNodePath.equals(childNode.getPath())){
					y=new Long(childNodeItr.getPosition()).intValue();
					break;
				}
			}
			return x+"-"+y;
		} catch (AccessDeniedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Error while Calculating node coordiantes";
		} catch (ItemNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Error while Calculating node coordiantes";
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Error while Calculating node coordiantes";
		}
    }
    
    
    
    /**
     * Checks if the current Page is a leaf page or not.
     * @param pCurrentNodePath
     * @param pAdminResolver
     * @return
     */
    private boolean isLeafPage(String pCurrentNodePath, ResourceResolver pAdminResolver) {
    	boolean isNotLeafPage = false;
    	Resource currentNodeResource = getJCRResource(pCurrentNodePath, pAdminResolver);
    	
    	for (Iterator<Resource> resourceItr =  pAdminResolver.listChildren(currentNodeResource); resourceItr.hasNext();) {
    		Resource currentPageResource = resourceItr.next();
    		PersistableValueMap valueMap = currentPageResource.adaptTo(PersistableValueMap.class);
    		// Check all the child nodes and see if any thing is a page. If there one Page then this node is not the leaf Page.
    		isNotLeafPage = "cq:Page".equals(valueMap.get("jcr:primaryType"))?true:false;
    		if(isNotLeafPage) break;
		}
    	
		if(isNotLeafPage){
			logger.debug("The current Page Node is NOT leaf Page: "+pCurrentNodePath);
			return false;
		}else{
			logger.debug("The current Page Node is leaf Page: "+pCurrentNodePath);
			return true;
		}
    }
    
    private Resource getJCRResource(String pJCRContentPath, ResourceResolver pAdminResolver) {
        if (StringUtils.isEmpty(pJCRContentPath)) {
            logger.error("JCRContentPath is required to query JCR.");
            return null;
        }
        if (pAdminResolver == null) {
            logger.error("AdminResolver is required to query JCR.");
            return null;
        }

        Resource resource = pAdminResolver.getResource(pJCRContentPath);
        if (resource == null) {
            logger.error("Unable to locate a resource for a path - " + pJCRContentPath);
            return null;
        }

        return resource;
    }
    /**
     * It loops thru each of the Node's property value, constructs concatenated String of each of node's property value
     * and returns it. It excludes the specific properties while concatenating.
     * 
     * @param pJCRContentPath
     *            - the content path of the node.
     * @param pAdminResolver
     *            - AdminResolver object.
     * @param pInputBean
     *            - JCRHashGeneratorRequest object, it contains the input parameters.
     * @param pAdminResolver 
     * @param pCurrentNode 
     * @throws RepositoryException
     *             - throws RepositoryException when there is an error while reading the map.
     * @return String - concatenated string of this nodes properties.
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public String getConcatenatedPropertyValues(PersistableValueMap pValueMapOfCurrentNode,
            JCRHashGeneratorRequest pInputBean, ResourceResolver pAdminResolver, Node pCurrentNode) throws RepositoryException {
        if (pValueMapOfCurrentNode == null) {
            logger.error("ValueMap of CurrentNode is null, so can't generate the concatenated property value string");
            return null;
        }

        SortedMap map = new TreeMap(pValueMapOfCurrentNode);

        if (map.size() < 1) {
            return null;
        }

        StringBuilder concatenatedPropValues = new StringBuilder();

        String key = null;
        Object value = null;
        for (Iterator iter = map.keySet().iterator(); iter.hasNext();) {
            key = (String) iter.next();
            if (StringUtils.isEmpty(key)) {
                continue;
            }

            value = map.get(key);
            if (value == null) {
                continue;
            }
            // Check whether property is excluded
            if (pInputBean.getExcludedProperties().contains(key)) {
                if (logger.isDebugEnabled()) {
                    logger.debug("Property [" + key + "] is excluded from hash calculation");
                }
                continue;
            }
            // check whether it is a multi valued property, if yes then loop thru and concatenate the contents of it
            if (value instanceof Object[]) {
                Object[] values = (Object[]) value;
                TreeSet<String> sortedPropArraySet = new TreeSet<String>();
                
                if (values != null && values.length > 0) {
                    for (int idx = 0; idx < values.length; idx++) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("key = " + key + ", value = " + values[idx]);
                        }
                        // Sorting the list of property values.
                        if(values[idx] instanceof String)
                        	sortedPropArraySet.add(values[idx].toString());
                    }
                    
                    for (Iterator iterator = sortedPropArraySet.iterator(); iterator.hasNext();) {
						String sortedValue = (String) iterator.next();
                        concatenatedPropValues.append(sortedValue);
                        concatenatedPropValues.append(':');
					}
                    
                }
            } else if (value instanceof InputStream){
                // It means it contains an image bytes.
                byte[] bytes = null;
                try {
                    bytes = value.toString().getBytes(mJCRHashGeneratorConfig.getEncodingType());
                    concatenatedPropValues.append(getHashString(bytes));
                } catch (UnsupportedEncodingException e) {
                    logger.error("UnsupportedEncodingException while getting bytes from Input stream" + e);
                }
            } else {
                concatenatedPropValues.append(value);
            }
            if (logger.isDebugEnabled()) {
                logger.debug("key = " + key + ", value = " + value);
            }
        }
        return (concatenatedPropValues != null) ? concatenatedPropValues.toString() : null;
    }

    /**
     * Generates and return hash value for the input String.
     * 
     * @param pValue
     *            - String for which the hash value has to be generated.
     * @return hash value
     */
    public BigInteger getHashString(String pValue) {

        if (StringUtils.isEmpty(pValue)) {
            logger.error("input param is empty for hash calculation");
            return null;
        }
        BigInteger hashedValue = null;
        try {
            hashedValue = getHashString(pValue.toString().getBytes(mJCRHashGeneratorConfig.getEncodingType()));
        } catch (UnsupportedEncodingException e) {
            logger.error("Unable to Encode", e); 
        } 
        return hashedValue;
    }

    
    public BigInteger getHashString(byte[] pBytes) {
        BigInteger hashedValue = null;

            MessageDigest messageDigest = null;
            try {
                messageDigest = MessageDigest.getInstance(mJCRHashGeneratorConfig.getHashAlgorithmName());
            } catch (NoSuchAlgorithmException e) {
                logger.error("Unable to Hash", e);
            }
            messageDigest.update(pBytes);

            hashedValue = new BigInteger(1, messageDigest.digest());
            if (logger.isDebugEnabled()) {
                logger.debug("The Hash value for is [" + hashedValue + "]");
            }
 
        return hashedValue;
    }
    
    @SuppressWarnings("unchecked")
    public SortedMap<String, String> getJCRHash(String pHost, JCRSamenessToolRequest pInputBean, String pContentType,
            String pRequestMethod) throws MalformedURLException, IOException, ClassNotFoundException {
        if (pHost == null) {
            return null;
        }
        // Split the host into userpassword & host
        String host = null;
        String userPassword = null;
        if (StringUtils.isNotEmpty(pHost)) {
            int index = pHost.lastIndexOf('@');
            if (index != -1) {
                userPassword = pHost.substring(0, index);
                host = pHost.substring(index + 1);
            } else {
                host = pHost;
            }

        }
        // build the URL to call hash generator servlet
        StringBuilder url = new StringBuilder("http://");
        url.append(host);
        url.append(JCR_HASH_GENERATOR_SERVLET_PATH);
        url.append('?');
        url.append(JCRHashGeneratorServlet.PATH);
        url.append('=');
        url.append(pInputBean.getPath()); // $codepro.audit.disable possibleNullPointer
        if (StringUtils.isNotEmpty(pInputBean.getExcludedNodes())) {
            url.append('&');
            url.append(JCRHashGeneratorServlet.EXCLUDED_NODES);
            url.append('=');
            url.append(pInputBean.getExcludedNodes());
        }
        if (StringUtils.isNotEmpty(pInputBean.getExcludedProperties())) {
            url.append('&');
            url.append(JCRHashGeneratorServlet.EXCLUDED_PROPERTIES);
            url.append('=');            
            url.append(pInputBean.getExcludedProperties());
        }

        url.append('&');
        url.append(JCRHashGeneratorServlet.INCLUDE_DEACTIVATED_NODES);
        url.append('=');            
        url.append(pInputBean.isIncludeDeactivatedNodes());
        
        // Append checkOrder
        url.append('&');
        url.append(JCRHashGeneratorServlet.CHECK_PAGE_ORDER);
        url.append('=');            
        url.append(pInputBean.isCheckOrder()+"");
        

        // open a connection to hash generator servlet
        HttpURLConnection httpConnection = (HttpURLConnection) new URL(url.toString()).openConnection();
        SortedMap<String, String> jcrHash = null;
        if (httpConnection != null) {
            httpConnection.setRequestProperty("Content-Type", pContentType);
            httpConnection.setRequestMethod(pRequestMethod);
            httpConnection.setReadTimeout(0);

        if (StringUtils.isNotEmpty(userPassword)) {
            String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userPassword.getBytes());
            httpConnection.setRequestProperty("Authorization", basicAuth);
        }

            // read the jcr hash value from servlet response
            ObjectInputStream inputStream = new ObjectInputStream(httpConnection.getInputStream());
            jcrHash = (SortedMap<String, String>) inputStream.readObject();
            inputStream.close();
        }
        
        return jcrHash;
    }

    public Map<String, Object> getDiffFromSourceToTarget(SortedMap<String, String> pSourceSortedMap, SortedMap<String, String> pTargetSortedMap,boolean checkPathOrder) {
        if (pSourceSortedMap == null) {
            logger.error("Unable to find differences between source JCR and target JCR. Reason, source sorted map is empty");
            return null;
        } 
        if(pTargetSortedMap == null) {
            logger.error("Unable to find differences between source JCR and target JCR. Reason, target sorted map is empty");
            return null;
        }
        Map<String, Object> map = new HashMap<String, Object>();
        SortedMap<String, String> rawDiff = new TreeMap<String, String>();
        Set<String> affectedPages = new HashSet<String>();
        String sourceHashValue = null;
        String targetHashValue = null;
        String[] sourceHashValuesArray = null;
        String[] targetHashValuesArray = null;
        String sourceNodeSelfHash = null;
        String targetNodeSelfHash = null,sourceNodeChildrenHash=null,targetNodeChildrenHash=null;
        String pageKey = null;
        int jcrColonContentIndex = 0;
        for (String key : pSourceSortedMap.keySet()) {
            if (key == null || StringUtils.isEmpty(key)) {
                logger.error("KEY is null in the source map, should not happend");
                continue;
            }
            sourceHashValue = pSourceSortedMap.get(key);
            jcrColonContentIndex = key.indexOf("/jcr:content");
            
            // Check whether key exists in target or not
            if (pTargetSortedMap.containsKey(key)) {
                targetHashValue = pTargetSortedMap.get(key);
                // If both values are empty then it is treated as they are equal
                if (StringUtils.isEmpty(sourceHashValue) && StringUtils.isEmpty(targetHashValue)) {
                    continue;
                }
                // If they are different then add them to the differences map
                if (!StringUtils.isEmpty(sourceHashValue) && !sourceHashValue.equals(targetHashValue)) {
                    // check for intermediate nodes
                    sourceHashValuesArray = sourceHashValue.split(","); // Each key has 2 values <Hash for node itself>, <Hash for combined Node+Child Nodes>
                    if (sourceHashValuesArray != null && sourceHashValuesArray.length > 1) {
                        targetHashValuesArray = targetHashValue.split(",");
                        sourceNodeSelfHash = sourceHashValuesArray[0];
                        targetNodeSelfHash = targetHashValuesArray[0];
                        if(sourceHashValuesArray.length >1) sourceNodeChildrenHash = sourceHashValuesArray[1];
                        if(targetHashValuesArray.length >1) targetNodeChildrenHash = targetHashValuesArray[1];
                        
                        if(checkPathOrder && sourceNodeChildrenHash.contains("isPage=true|isLeafPage=true")){
                        	String sourceCoordinate="",targetCoordinate=null;
                        	logger.info("Checking for path:"+key);
                        	sourceCoordinate = sourceNodeChildrenHash.substring(sourceNodeChildrenHash.lastIndexOf('|')+1);
                        	
                        	if(targetNodeChildrenHash.contains(("isPage=true|isLeafPage=true"))){
                        		targetCoordinate = targetNodeChildrenHash.substring(targetNodeChildrenHash.lastIndexOf('|')+1);
                            	if(!sourceCoordinate.equals(targetCoordinate)){
                            		logger.info("Coordinates mismatch found [source="+sourceCoordinate+", target="+targetCoordinate+ "] for path "+key );
                            		affectedPages.add(key);
                            	}
                        	}
                        	/* 
                        	 * Commenting this piece of code because
                        	 * 	1. If source node is a leaf node and on target is not leaf then it would be captured in extra node.
                        	 * 	2. If souce node is not a leaf node and target is a leaf then it would be captured in the diff pages.
                        	 * 	3. This check here is only if the for the leaf campaign pages that exists on both source and destination.
                        	 */
//                        	else if("".equals(targetCoordinate)){
//                        		affectedPages.add(key);
//                        	}
                        	
                        }
                        
                        if (sourceNodeSelfHash != null && sourceNodeSelfHash.equals(targetNodeSelfHash)) {
                            // Do nothing. It is an intermediate node. Node itself is same but its children are different.    
                        	// If sourceNodeChildrenHash != targetNodeChildrenHash && (sourceNodeChildrenHash.contains(isPage)) add to activate page Map
                        	if((sourceNodeChildrenHash != targetNodeChildrenHash) && sourceNodeChildrenHash.contains("isPage=true|isLeafPage=true")){
                        		affectedPages.add(key);
                        	}
                        	
                        } else {
                            // Means Node itself is different
                            rawDiff.put(key, sourceHashValue);
                            if (jcrColonContentIndex != -1) {
                                pageKey = key.substring(0, jcrColonContentIndex);
                                rawDiff.put(pageKey, pSourceSortedMap.get(pageKey));
                                affectedPages.add(key.substring(0, jcrColonContentIndex));
                            } else {
                                affectedPages.add(key);
                            }
                        }
                    } else {
                        // Node does not have any child nodes
                        rawDiff.put(key, sourceHashValue);
                        if (jcrColonContentIndex != -1) {
                            pageKey = key.substring(0, jcrColonContentIndex);
                            rawDiff.put(pageKey, pSourceSortedMap.get(pageKey));
                            affectedPages.add(key.substring(0, jcrColonContentIndex));
                        } else {
                            affectedPages.add(key); // SHOULD WE DO THIS ???
                        }                         
                    }
                }
            } else {
                // key does not exist in target
                rawDiff.put(key, sourceHashValue);
                if (jcrColonContentIndex != -1) {
                    pageKey = key.substring(0, jcrColonContentIndex);
                    rawDiff.put(pageKey, pSourceSortedMap.get(pageKey));                    
                    affectedPages.add(key.substring(0, jcrColonContentIndex));
                } else {
                    // if jcr:content is missing implies node is likely a folder or a page missing a jcr:Content
                    affectedPages.add(key);
                }                
            }
        }
        
        
        map.put("differences", rawDiff);
        map.put("pagesOnly", affectedPages);
        return map;
    }

    public Map<String, Object>  getExtraContentOnTarget(SortedMap<String, String> pSourceSortedMap, SortedMap<String, String> pTargetSortedMap) {
    	
        if (pSourceSortedMap == null) {
            logger.error("Unable to find differences between source JCR and target JCR. Reason, source sorted map is empty");
            return null;
        } 
        if(pTargetSortedMap == null) {
            logger.error("Unable to find differences between source JCR and target JCR. Reason, target sorted map is empty");
            return null;
        }
        Map<String,Object> extraNodesOnTargetMap = new HashMap<String, Object>();
        Set<String> extraNodesOnTarget = new HashSet<String>();

        SortedMap<String, String> missingKeysInSourceMap = new TreeMap<String, String>();
        for (String key : pTargetSortedMap.keySet()) {
            if (StringUtils.isEmpty(key)) {
                logger.error("KEY is null in the target map, should not happend");
                continue;
            }
            
            // Check whether key exists in source
            if (!pSourceSortedMap.containsKey(key)) {
            	
            	// missingKeysInSourceMap contains all extra nodes (includingpages) with information regarding isPage=true and ifLeafNode. This is only for reporting.
            	//extraNodesOnTarget contains all the extra Node paths on the target ( this includes pages and nodes) and these paths would be furthter DELETED but not Deactivated on the target
            		// Reson for deleting and not for deactivatoin is because deactivation sets the status on the page on the source but would delete it on the target. In this case the paths 
            	 	// does not exist on the source. So deleting would be the best to do.
                missingKeysInSourceMap.put(key, pTargetSortedMap.get(key));
               	logger.info("Found extra Node on target : "+key);
               	extraNodesOnTarget.add(key);
            }
        }
        extraNodesOnTargetMap.put("extrasOnTarget", missingKeysInSourceMap);
        extraNodesOnTargetMap.put("extraNodesOnTarget", extraNodesOnTarget);
        
        return extraNodesOnTargetMap;
    }

    public void writeToFile(SortedMap<String, String> pDataMap, String pFileName, JCRCompareResponse pResponse)
            throws IOException {
        if (StringUtils.isEmpty(pFileName)) {
            logger.error("File Name is not passed, so not writing the file.");
            return;
        }
        File file = new File(pFileName);
        FileWriter fileWriter = new FileWriter(file);
        try {
            long numOfPagesAffected = 0;

            for (String key : pDataMap.keySet()) {
                if (StringUtils.isNotEmpty(key)) {
                    String value = pDataMap.get(key);
                    String[] values = value.split(":");
                    if (pFileName.indexOf("error") == -1) {
                        if (values != null && values.length > 1) {
                            value = values[1];
                            numOfPagesAffected++;
                        } else {
                            value = "";
                        }
                    }
                    // DO NOT write hash value in this file, it is not needed anymore at this stage
                    if (StringUtils.isNotEmpty(value)) {
                        fileWriter.write(key + "|" + value);
                    } else {
                        fileWriter.write(key);
                    }
                    fileWriter.write("\n");
                }
            }
            if (pResponse != null) {
                if (pFileName.indexOf("diff") != -1) {
                    pResponse.getDetailedResponse().setNumOfDifferences(pDataMap.size());
                    pResponse.getDetailedResponse().setNumOfPagesAffectedDueToDiff(numOfPagesAffected);
                } else if (pFileName.indexOf("extra") != -1) {
                    pResponse.getDetailedResponse().setNumOfExtraNodesOnTarget(pDataMap.size());
                    pResponse.getDetailedResponse().setNumOfPagesAffectedDueToExtra(numOfPagesAffected);
                }

            }

            fileWriter.close();

        } catch (Exception e) {
            logger.error("Error while wirting to file " + pFileName, e);
        } finally {
            if (fileWriter != null) {
                fileWriter.close();                
            }
        }
    }

    public void writeToFile(String pSourceJCRHash, String pTargetJCRHash, String pFileName) throws IOException {

        File file = new File(pFileName);
        FileWriter writer = new FileWriter(file);
        try {
            writer.write(pSourceJCRHash);
            writer.write(" : ");
            writer.write("Source JCR Hash");
            writer.write("\n");
            writer.write(pTargetJCRHash);
            writer.write(" : ");
            writer.write("Target JCR Hash");

        } catch (Exception e) {
            logger.error("Error while wirting to file " + pFileName, e);
        } finally {
            if (writer != null) {
                writer.close();                
            }
        }
    }

    public void writeToFile(Set<String> pOnlyModifiedPages, String pFileName, JCRCompareResponse pResult) {
        
        if (pOnlyModifiedPages == null || pOnlyModifiedPages.size() == 0) {
            return;
        }
        File file = new File(pFileName);
        FileWriter writer = null;
        try {
            writer = new FileWriter(file);
            for (String page : pOnlyModifiedPages) {
                writer.write(page);
                writer.write("\n");
            }
        } catch (Exception e) {
            logger.error("Error while wirting to file " + pFileName, e);
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    logger.error("IOException while closing the writer ", e);
                }                
            }
        }
    }
    
    public static final String getDateTime() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd_hh-mm-ss");
        df.setTimeZone(TimeZone.getTimeZone("PST"));
        return df.format(new Date());
    }

    public String getModifiedHostName(String pHostName) {

        if (StringUtils.isEmpty(pHostName)) {
            return null;
        }
        String hostNameWithoutUserPwd = null;
        if (pHostName.indexOf("@") != -1) {
            hostNameWithoutUserPwd = pHostName.split("@")[1];
        } else {
            hostNameWithoutUserPwd = pHostName;
        }
        
        String modifiedHostName = null;
        String port = null;

        String[] tokens = hostNameWithoutUserPwd.split(":");
        modifiedHostName = tokens[0];
        if (tokens.length > 1) {
            port = tokens[1];
        }
        if (StringUtils.isEmpty(modifiedHostName)) {
            return null;
            // this should never happen though
        }

        String modifiedHostName_NoDots = modifiedHostName.replace(".", "");
        if (StringUtils.isNumeric(modifiedHostName_NoDots)) {
            modifiedHostName = modifiedHostName.replace(".", "_");
        } else {
            if (modifiedHostName.indexOf(".") != -1) {
                modifiedHostName = modifiedHostName.substring(0, modifiedHostName.indexOf("."));
            }
        }

        if (StringUtils.isNotEmpty(port)) {
            modifiedHostName = modifiedHostName + "_" + port;
        }
        return modifiedHostName;
    }
    
    public void updatePageActivateMetaFile(String diffPagesFileAbsolutePath, String targetHostAndPort){
    	
		BundleContext ctx = FrameworkUtil.getBundle(JCRSamenessToolHelper.class).getBundleContext();
		AgentManager agentManager =  (AgentManager)ctx.getService(ctx.getServiceReference("com.day.cq.replication.AgentManager"));
		Map<String, Agent> agentsMap = agentManager.getAgents();
		String targetHost="",port= "",agentId="";
		logger.debug("Using target:port as :"+targetHostAndPort);
		
		//	Formats that can appear
    	//	user:password@host.edc.cingular.net:port
    	//	user:password@host:port
    	//	host:port

		if(targetHostAndPort.contains("@")){
			// this host is author
			String localTargetAndHost = targetHostAndPort.substring(targetHostAndPort.lastIndexOf('@')+1); 
			targetHost = localTargetAndHost.split(":")[0];
			port = localTargetAndHost.split(":")[1];
		}else {
			targetHost = targetHostAndPort.split(":")[0];
			port = targetHostAndPort.split(":")[1];
		}
		
		logger.debug("Targethost:port :"+targetHostAndPort);
		logger.info("Target host:"+targetHost);
		logger.info("Target Port:"+port);
		
		for (Iterator<String> agentItr = agentsMap.keySet().iterator(); agentItr.hasNext();) {
			Agent agent = agentsMap.get(agentItr.next());
			AgentConfig agentConfig = agent.getConfiguration();
			String transportUrl = agentConfig.getTransportURI();
			if(transportUrl.contains(targetHost) && transportUrl.contains(port)){
				logger.info("Agent Identified:"+agent.getConfiguration().getName());
				agentId = agent.getConfiguration().getName();
				break;
			}
		}
		
		if(!"".equals(agentId)){
			try {
				File diffFilePath = new File(diffPagesFileAbsolutePath);
				logger.info("Setting Meta file path as:"
						+ diffFilePath.getParentFile().getPath()
						+ File.separator + "PAGE-ACTIVATE-META-FILE.txt");
				File metafilePath = new File(diffFilePath.getParentFile()
						.getPath()
						+ File.separator
						+ "PAGE-ACTIVATE-META-FILE.txt");
				if (!metafilePath.exists()) {
					logger.info("File " + metafilePath.getAbsolutePath()
							+ " does not exist. Creating a new file");
					FileUtils.touch(metafilePath);
				}
				@SuppressWarnings("unchecked")
				List<String> readLinesList = FileUtils.readLines(metafilePath);
				if (null != readLinesList) {
					logger.info("Appending :" + agentId + "\t"
							+ diffPagesFileAbsolutePath);
					readLinesList.add(agentId + "\t"
							+ diffPagesFileAbsolutePath);
					logger.debug(readLinesList.toString());
					FileUtils.writeLines(metafilePath, readLinesList, "\n");
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else{
			logger.info("Agent NOT Identified for :"+targetHostAndPort);
		}
    }
}
