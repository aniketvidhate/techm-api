/* 
 * . Adding class to get Noide UUID and then it's portion for data-cqpath
 * @author Chaturkumar (cg975w) 
 * @created on Apr 11 2014 
 */ 
 
 
package com.att.ecom.cq.bundle.helpers; 
 
import java.math.BigInteger;
import java.security.MessageDigest;

import javax.jcr.Node; 
 

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

 
import org.slf4j.Logger; 
import org.slf4j.LoggerFactory; 
 
public class GetNodeUUID { 
	static Logger logger = LoggerFactory.getLogger(GetNodeUUID.class); 
	
	public static String getNodeUUId(Node n) { 
		String nodeUUID = null; 
		try { 
 				String nodeID = n.getIdentifier();
 				if (nodeID != null || nodeID != "") {
 					int	uidIndex = nodeID.lastIndexOf("-"); 
 					if (uidIndex>0) { 
					nodeUUID = nodeID.substring(uidIndex+1); 
 					}  
 				}
		} 
		catch (Exception e) { 
			
			logger.error("Unable to getNodeUUID", e); 
		} 
		return nodeUUID; 
	}
	
	public static String getNodeUUId(String path, ResourceResolver resolver) { 
		
		
		String nodeUUID = null;

		try {
			Resource r = resolver.getResource(path);
			if(r != null) {
				Node n = r.adaptTo(Node.class);
				String nodeID = n.getIdentifier();
				if (nodeID != null || nodeID != "") {
					int uidIndex = nodeID.lastIndexOf("-");
					if (uidIndex>0) {
						nodeUUID = nodeID.substring(uidIndex+1);
					}
				}
			}
		} catch (Exception e) {

		logger.error("Unable to getNodeUUID", e);
		}
		
		if (nodeUUID == null) {
			nodeUUID = path;
		}
		
		return nodeUUID; 
	}
	
	
	
	public static String getMd5ForResource(String path){
		
		String hashedPath = " ";
		
		if (StringUtils.isNotBlank(path)) {
			try {
				MessageDigest messageDigest=MessageDigest.getInstance("MD5");
				messageDigest.update(path.getBytes(),0,path.length());
				hashedPath = new BigInteger(1,messageDigest.digest()).toString();
				logger.debug("The Hashed Server Name is:"+hashedPath);
			} catch (Exception e) {
				logger.error("Unable to Hash", e);				
			} 
		}
		return hashedPath;
	}
	
		
	
}