package com.att.ecom.cq.bundle.helpers;


import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.scheduler.Scheduler;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

@Component(immediate=true)
public class GlobalSearchAutoSuggestScheduler {

	private static final String JCR_PATH="/content/att/cmsfeed/globalsearch";
	private static final String NODE_AUTO_SUGGEST_AUTOMATION ="autosuggest";
	private static final String RESOURCE_TYPE="sling:resourceType";
	private static final String PAGE_RESOURCE_TYPE="cq:Page";
	private static final String PAGE_CONTENT ="cq:PageContent";
	private static final String RESOURCE_TYPE_VALUE="/apps/att/common/components/autosuggest";
	private static final String MAIN_PAGE_RESOURCE_TYPE_VALUE="/apps/att/common/components/page/globalsearch/autosuggest";
	private static final String PAGE_RESOURCE_TYPE_VALUE="/apps/att/common/components/page/globalsearch/autosuggest";
	private static final String PAGE_TEMPLATE="cq:template";
	private static final String PAGE_TEMPLATE_VALUE="/apps/att/common/templates/globalsearch/autosuggest";
	private static final String ELEMENT_NAME="name";
	private static final String ELEMENT_DOC="doc";
	private static final String ATTR_USER_QUERY="userQuery";
	private static final String ATTR_ADMIN_BOOST="adminBoost";
	private static final String NODE_TYPE="cq:PageContent";
	private static final String JCR_TITLE ="jcr:title";
	private static final String JCR_CONTENT ="jcr:content";
	private static final String NODE_AUTOSUGGEST ="autosuggest";
	private static final String PRIMARY_TYPE_UNSTRUCTURED ="nt:unstructured";
	private static final String DATE_FORMAT="MMM-dd-yyyy_hh-mm-ss";
	private static final String JOB_NAME="AutoSuggestJob";

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Reference
	private SlingRepository slingRepository;

	@Reference
	private ResourceResolverFactory resourceResolverFactory;    

	@Reference
	private Scheduler scheduler;

	private ComponentContext compCtx ;

	protected void activate(ComponentContext componentContext) throws Exception {
		compCtx = componentContext;


		final Runnable job = new Runnable() {
			@Override
			public void run() {
				logger.error("RUNNING AUTOSUGGEST JOB");
				doJob();
			}
		};

		scheduler.addJob(JOB_NAME, job, null, GlobalSearchAutoSuggestConfiguration.getCronExpression(), false);
	}

	protected void deactivate(ComponentContext ctx) {
		compCtx = null;
	}

	private void doJob() {

		javax.jcr.Node rootNode=null;
		String output="";
		javax.jcr.Session session=null;
		//String backUpNode="";
		ResourceResolver adminResolver = null;
		Page appPage =null;

		try 
		{
			adminResolver=resourceResolverFactory.getAdministrativeResourceResolver(null);
			PageManager manager = adminResolver.adaptTo(PageManager.class);

			//Create a Session
			//logger.error("Create session with defaut credentials");
			session =slingRepository.loginAdministrative(null);
			rootNode =(javax.jcr.Node) session.getItem(JCR_PATH);

			if(null!=rootNode && !rootNode.hasNode(NODE_AUTO_SUGGEST_AUTOMATION)) {
				//create NODE_AUTO_SUGGEST_AUTOMATION if it does not exist
				logger.error("create NODE_AUTO_SUGGEST_AUTOMATION if it does not exist") ;
				createNode(rootNode, session);
				logger.error("Created Node AutoSuggestAutomation") ;
				//set root node as AutoSuggestAutomation
				rootNode=(javax.jcr.Node) session.getItem(JCR_PATH+"/"+NODE_AUTO_SUGGEST_AUTOMATION);
				//create version
				logger.error("CHECK VERSIONING=="+GlobalSearchAutoSuggestConfiguration.checkVersion());
				if(GlobalSearchAutoSuggestConfiguration.checkVersion()){
					appPage = manager.getPage(rootNode.getPath());
					logger.error("Page to be versioned==="+appPage);
					manager.createRevision(appPage);        
				}
				//set child node properties
				setChildNodeProperties(rootNode,session);  
				logger.error("Created child Nodes and set its properties") ;
				session.save();
				logger.error("Saving Session");
			}
			else if(null!=rootNode && rootNode.hasNode(NODE_AUTO_SUGGEST_AUTOMATION)){
				logger.error("rootnode already exists") ;
				rootNode=(javax.jcr.Node) session.getItem(JCR_PATH+"/"+NODE_AUTO_SUGGEST_AUTOMATION);
				logger.error("create child nodes and set properties");
				setChildNodeProperties(rootNode,session);
				//create version
				logger.error("CHECK VERSIONING=="+GlobalSearchAutoSuggestConfiguration.checkVersion());
				if(GlobalSearchAutoSuggestConfiguration.checkVersion()){
					appPage = manager.getPage(rootNode.getPath());
					logger.error("Page to be versioned==="+appPage);
					manager.createRevision(appPage);          
				}
				session.save();
				logger.error("Saving Session");
				output +="<br>Migration Completed Successfully.";
			}
		}

		catch (RepositoryException e) 
		{
			output +="RepositoryException Error:<br>";
			output +=e.getMessage();
		}
		catch (Exception e) 
		{
			output +="Error:<br>";
			output +=e.getMessage();  
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}if(session!=null){
				session.logout();
			}

		}
	}


	/*
	 * method to set properties of child nodes under AutoSuggestAutomation
	 */
	public void setChildNodeProperties(javax.jcr.Node rootNode,Session session){

		//logger.error("Create Child nodes and set properties");
		javax.jcr.Node currentNode = null ;  
		// String output="";   
		String nodetype="";
		String collection="";
		String collectionValue="";
		String userqueryValue="";
		Boolean isNodeExist=false;
		Boolean isMatchFound=false;
		String fieldname="";
		String fieldvalue="";

		int i,k;

		try 
		{
			java.util.Date date = new Date();
			//logger.error("XML_URL=="+GlobalSearchAutoSuggestConfiguration.getXmlUrl());
			//System.out.println("XML_URL:   "+XML_URL+date.toString());
			URL url = new URL(GlobalSearchAutoSuggestConfiguration.getXmlUrl());
			URLConnection connection = url.openConnection();


			//get file from disk
			/*File file = new File("D:\\temp\\Auto_Suggest.xml");
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(file);*/

			Document doc = parseXML(connection.getInputStream());
			NodeList docNodes = doc.getElementsByTagName(ELEMENT_DOC);

			javax.jcr.Node childPageNode =null;
			javax.jcr.Node matchedChildPageNode =null;
			PropertyIterator childPageNodeProperties=null;
			JSONObject jsonnodeinfo=null;
			JSONObject jsonpageinfo=null;
			String userQ="";
			String userV="";
			for(i=0; i<docNodes.getLength();i++)
			{    
				jsonnodeinfo=new JSONObject();
				jsonpageinfo=new JSONObject();
				NodeList docchildNodes = docNodes.item(i).getChildNodes();
				for (k=0; k<docchildNodes.getLength(); k++)
				{        
					Node nNode = docchildNodes.item(k);
					
					if (nNode.getNodeType() == Node.ELEMENT_NODE) 
					{    
						//logger.error("reading=="+k);

						Element elem = (Element) nNode;
						
						fieldname=elem.getAttribute(ELEMENT_NAME).toString().trim();
						if(fieldname.equalsIgnoreCase(ATTR_USER_QUERY)){
						userQ=fieldname;
						userV=elem.getTextContent().toString().replaceAll("^\\s+","");
						}
						//logger.error("fieldname=="+fieldname);
						fieldvalue=elem.getTextContent().toString().replaceAll("^\\s+","");
						//logger.error("fieldvalue=="+fieldvalue);
						
						if(fieldname.equalsIgnoreCase("collection")){
							collection=elem.getTextContent().toString();
							
						}else{
							jsonnodeinfo.put(fieldname,fieldvalue);
							continue;
						}
						
						if(userQ.equalsIgnoreCase(ATTR_USER_QUERY )){
							String queryData=userV+"_"+collection;
							//logger.error("queryData======="+queryData);
							// Get all the child nodes or root node "autosuggest"
							NodeIterator autosuggestChildListItr=rootNode.getNodes();
							while(autosuggestChildListItr.hasNext()){
								//iterate each node to check the userquery of that node
								childPageNode=autosuggestChildListItr.nextNode();
								//logger.error("childPageNode Name======="+childPageNode.getName());
								if(childPageNode.getName().equals("jcr:content")){
									continue;
								}
								
								
								if(childPageNode.hasNode(JCR_CONTENT+"/"+NODE_AUTOSUGGEST)){
									childPageNodeProperties=childPageNode.getNode(JCR_CONTENT+"/"+NODE_AUTOSUGGEST).getProperties();
								}else{
									continue;
									
								}
								//childPageNodeProperties=childPageNode.getNode(JCR_CONTENT+"/"+NODE_AUTOSUGGEST).getProperties();
								while(childPageNodeProperties.hasNext()){
									Property prop = childPageNodeProperties.nextProperty();
									String propName=prop.getName();
									if(propName.equals("collection")){
										collectionValue=prop.getString();
										//logger.error("collectionValue==="+collectionValue);
									}else if(propName.equals("userQuery")){
										userqueryValue=prop.getString();
										//logger.error("userqueryValue==="+userqueryValue);
									}
								}
								/*Update the page properties if a node is found*/
								if(null!=queryData && queryData.equals(userqueryValue+"_"+collectionValue)){
									isNodeExist=true;
									isMatchFound=true;
									matchedChildPageNode=childPageNode;
									//logger.error("matchedChildPageNode==="+matchedChildPageNode.getName());
								//	logger.error("Node already exists so update the properties of node ==="+fieldvalue+"_"+collection);
									currentNode = (javax.jcr.Node)rootNode.getNode(childPageNode.getName());
									//logger.error("currentNode==="+currentNode.getName().toString());
									childPageNode=currentNode.getNode(JCR_CONTENT);
								//	logger.error("childPageNode1==="+currentNode.getName().toString());
									childPageNode=childPageNode.getNode(NODE_AUTOSUGGEST);
									//logger.error("Node exists:childPageNode="+childPageNode.getName());
									//logger.error("isNodeExist=="+isNodeExist);
								}else{
									isNodeExist=false;
									//logger.error("isNodeExist=="+isNodeExist);									
								}
							}
							/*Create new node if it does not exist*/
							if(!isMatchFound && !rootNode.hasNode(queryData)){
								//logger.error("If child node does not exist then create node==="+queryData);
								currentNode = (javax.jcr.Node)rootNode.addNode(userV+"_"+collection,PAGE_RESOURCE_TYPE);
								childPageNode = currentNode.addNode(JCR_CONTENT,PAGE_CONTENT);
								childPageNode.setProperty(RESOURCE_TYPE, PAGE_RESOURCE_TYPE_VALUE);
								jsonpageinfo.put(PAGE_TEMPLATE,PAGE_TEMPLATE_VALUE);
								jsonpageinfo.put(JCR_TITLE,userV+"_"+collection);
								setNodeProperties(childPageNode, session, JCR_CONTENT,"", jsonpageinfo, "");
								childPageNode= childPageNode.addNode(NODE_AUTOSUGGEST,PRIMARY_TYPE_UNSTRUCTURED); 
								childPageNode.setProperty("id",userV+"_"+collection);
								session.save();
							}
						}
						jsonnodeinfo.put(fieldname,fieldvalue);
						//logger.error("jsonnodeinfo=="+jsonnodeinfo.toString());
					}
					
				}
				
				if(isMatchFound){
					//logger.error("if setNodeProperties for matchedChildPageNode=="+matchedChildPageNode.getName());
					matchedChildPageNode=matchedChildPageNode.getNode(JCR_CONTENT+"/"+NODE_AUTOSUGGEST);
					setNodeProperties(matchedChildPageNode, session, nodetype,"", jsonnodeinfo, "");
					isMatchFound=false;
				}else{
					//logger.error("else setNodeProperties for childPageNode== "+childPageNode.getName());
					setNodeProperties(childPageNode, session, nodetype,"", jsonnodeinfo, "");
				}
			}
		}
		catch (RepositoryException e) 
		{
			logger.error("RepositoryException==="+e.getMessage());
			e.printStackTrace();
		}
		catch (Exception e) 
		{
			logger.error("Exception==="+e.getMessage());

		}
	}

	/*
	 * Method to create node
	 */
	public static void createNode(javax.jcr.Node node, Session session){
		javax.jcr.Node rootNode=null;

		if(null!=node){
			try {
				rootNode=node;
				rootNode=rootNode.addNode(NODE_AUTO_SUGGEST_AUTOMATION,PAGE_RESOURCE_TYPE);
				rootNode=rootNode.addNode(JCR_CONTENT,PAGE_CONTENT);
				rootNode.setProperty(PAGE_TEMPLATE,PAGE_TEMPLATE_VALUE);
				rootNode.setProperty(JCR_TITLE,NODE_AUTO_SUGGEST_AUTOMATION);
				rootNode.setProperty(RESOURCE_TYPE, MAIN_PAGE_RESOURCE_TYPE_VALUE);
				session.save();
			} catch (PathNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RepositoryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/*
	 * method to create back up of node after a scheduled interval 
	 */
	public static String renameNode(javax.jcr.Node node) throws RepositoryException 
	{
		String newTitle = NODE_AUTO_SUGGEST_AUTOMATION+"_"+setTimestamp();
		if(null!=node){
			node.getSession().move(node.getPath(),node.getParent().getPath() + "/" + newTitle);
			node.getNode(JCR_CONTENT).setProperty(JCR_TITLE,newTitle);
			node.getSession().save();
		}
		return newTitle;
	}


	/*
	 * Method to set properties of autosuggest node
	 */
	public void setNodeProperties(javax.jcr.Node node, Session session, String nodetype,String referencenodepath,JSONObject jsonnodeinfo, String strpositionalcode ) throws RepositoryException,  Exception {
		//logger.error("setNodeProperties jsonnodeinfo=="+jsonnodeinfo.toString());
		Iterator iter = jsonnodeinfo.keys();
		while(iter.hasNext()){
			String key = (String)iter.next();
			
			String value = jsonnodeinfo.getString(key);
			//logger.error("KEY=="+key+"===value=="+value);
			//logger.error("Node Name==="+node.getName()+" and nodeType="+node.getPrimaryNodeType().getName());
			nodetype=node.getPrimaryNodeType().getName();
			// AutoSuggest Schedule should not set values for AdminBoost.
			// AdminBoost values are always from CQ. 
			// So added below condition
			if(! key.equals("adminBoost")){
				//logger.error("Inside adminBoost Test");
				//logger.error("Key=="+key+" and value="+value);
				node.setProperty(key,value);
				if(nodetype.equalsIgnoreCase(NODE_TYPE)){
					node.setProperty(RESOURCE_TYPE, MAIN_PAGE_RESOURCE_TYPE_VALUE);
				}
				else if(!nodetype.equalsIgnoreCase(NODE_TYPE) && !nodetype.equalsIgnoreCase(JCR_CONTENT)){
					node.setProperty(RESOURCE_TYPE,RESOURCE_TYPE_VALUE);   
				}
			}
		}

		 session.save(); 
	}

	/*
	 * method to add timestamp to name of back up node
	 */
	public static String setTimestamp(){

		DateFormat date = new SimpleDateFormat(DATE_FORMAT);
		String timestamp = date.format(new Date());
		return timestamp;
	}

	/*
	 * method to parse xml
	 */
	private Document parseXML(InputStream stream)
	throws Exception
	{
		DocumentBuilderFactory objDocumentBuilderFactory = null;
		DocumentBuilder objDocumentBuilder = null;
		Document doc = null;
		try
		{
			objDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
			objDocumentBuilder = objDocumentBuilderFactory.newDocumentBuilder();
			doc = objDocumentBuilder.parse(stream);
		}
		catch(Exception ex)
		{
			ex.getMessage();
			throw ex;
		}       
		return doc;
	}

	/*
	 * Method to fetch boost count property from last moved node
	 */
	public void addBoostCountInfo(javax.jcr.Node backUpNode,Session session,javax.jcr.Node newNode){

		JSONObject boostCountInfo= new JSONObject();

		if(null!=backUpNode){

			NodeIterator childNodes;
			try {
				childNodes = backUpNode.getNodes();
				for (NodeIterator ni = childNodes; ni.hasNext();) {
					javax.jcr.Node childNode = ni.nextNode();
					logger.error("CHILD NODE ===="+childNode);
					if(childNode.getProperty("jcr:primaryType").getString().equalsIgnoreCase(PAGE_RESOURCE_TYPE)){
						logger.error("inside if get child node property"+childNode.getName()+"===depth=="+childNode.getDepth());
						if(childNode.hasNode(JCR_CONTENT)){
							javax.jcr.Node jcrContentNode=childNode.getNode(JCR_CONTENT);
							// if(jcrContentNode.hasNode(NODE_MAINPAR)){
							// javax.jcr.Node mainparNode=jcrContentNode.getNode(NODE_MAINPAR);
							if(jcrContentNode.hasNode(NODE_AUTOSUGGEST)){
								javax.jcr.Node autoSuggestnode=jcrContentNode.getNode(NODE_AUTOSUGGEST);
								if(autoSuggestnode.hasProperty(ATTR_ADMIN_BOOST)){
									boostCountInfo.put(childNode.getName(),autoSuggestnode.getProperty(ATTR_ADMIN_BOOST).getString());
									logger.error("adding admin boost to json=="+childNode.getName()+"=="+autoSuggestnode.getProperty(ATTR_ADMIN_BOOST).getString());
								}//end if has property adminboost
							}//end if mainpar node has node autosuggest
							// }//end if jcrcontentnode has node mainpar
						}//end if child node has node jcr:content
					}
				}

				childNodes=newNode.getNodes();
				for (NodeIterator ni = childNodes; ni.hasNext();) {
					javax.jcr.Node childNode = ni.nextNode();
					logger.error("CHILD NODE ===="+childNode);
					if(childNode.getProperty("jcr:primaryType").getString().equalsIgnoreCase(PAGE_RESOURCE_TYPE)){
						logger.error("inside if get child node property"+childNode.getName()+"===depth=="+childNode.getDepth());
						if(childNode.hasNode(JCR_CONTENT)){
							javax.jcr.Node jcrContentNode=childNode.getNode(JCR_CONTENT);
							// if(jcrContentNode.hasNode(NODE_MAINPAR)){
							// javax.jcr.Node mainparNode=jcrContentNode.getNode(NODE_MAINPAR);
							if(jcrContentNode.hasNode(NODE_AUTOSUGGEST)){
								javax.jcr.Node autoSuggestnode=jcrContentNode.getNode(NODE_AUTOSUGGEST);
								if(autoSuggestnode.hasProperty(ATTR_ADMIN_BOOST)){
									Iterator iter = boostCountInfo.keys();
									while(iter.hasNext()){
										String key = (String)iter.next();
										String value = boostCountInfo.getString(key);
										if(key==childNode.getName()){
											logger.error("set childNode.getName()=="+childNode.getName());
											logger.error("set in new node key=="+key);
											logger.error("set in new node value=="+value);
											// AutoSuggest Schedule should not set values for AdminBoost.
											// AdminBoost values are always from CQ. 
											// So commenting the below line
											// autoSuggestnode.setProperty(ATTR_ADMIN_BOOST,value);
										}
									}
									session.save(); 
								}//end if has property adminboost
							}//end if mainpar node has node autosuggest
							//}//end if jcrcontentnode has node mainpar
						}//end if child node has node jcr:content

					}
				}
			}    
			catch (RepositoryException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
			catch (JSONException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
		}
	}

}
