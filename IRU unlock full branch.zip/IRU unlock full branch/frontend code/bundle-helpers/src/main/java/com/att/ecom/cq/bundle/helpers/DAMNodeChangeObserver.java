package com.att.ecom.cq.bundle.helpers;
import java.util.ArrayList;
import java.util.Arrays;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;
import javax.jcr.observation.ObservationManager;

import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;


import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;

/** Genre implementation
*
* @scr.service
*
* @scr.component
* immediate="true"
* metatype="false"
*
* @scr.property
* name="service.description"
* value="DAM Event Listner"
*
* @scr.property
* name="service.vendor"
* value="ATT"
* by Pratap Cheruvu
*/ 

public class DAMNodeChangeObserver implements EventListener{
	
	/**
     * ResourceResolverFactory
     */
	/** @scr.reference */
    private ResourceResolverFactory resourceResolverFactory;
	
private Logger log = LoggerFactory.getLogger(getClass());
    
/** @scr.reference */
    private SlingRepository repository;
    
    private Session session;
    private ObservationManager observationManager;
    
    /**
     * the property for DAM asset project name
     */
    private static final String DAM_PROJECT_PROPERTY_NAME = "projectName";
    
    /**
     * the property for DAM asset project name
     */
    private static final String VAR_DAM_PROJECT_PROPERTY_NAME = "attcms:currentProject";
	
	protected void activate(ComponentContext context)  throws Exception {
        session = repository.loginAdministrative(null);
       // Listen for changes to our orders
        if (repository.getDescriptor(Repository.OPTION_OBSERVATION_SUPPORTED).equals("true")) {
            observationManager = session.getWorkspace().getObservationManager();
            final String[] types = { "nt:unstructured","sling:Folder" };
            final String path = "/content/dam/att/";
            observationManager.addEventListener(this, Event.NODE_ADDED, path, true, null, null, false);
            log.error("Observing property changes to {} nodes under {}", Arrays.asList(types), path);
        }
        
    }

    protected void deactivate(ComponentContext componentContext) throws RepositoryException {
        
        if(observationManager != null) {
            observationManager.removeEventListener(this);
        }
        if (session != null) {
            session.logout();
            session = null;
            
            
        }
    }
	
    
    /**
	 * onEvent method triggers 
	 */
	public void onEvent(EventIterator eventIterator) {
		Event event;
		String metadata_asset_path;
		String var_dam_path="";
		String var_dam_project_value="";
		try{				
			if(eventIterator.hasNext()){
				event=eventIterator.nextEvent();			
				var_dam_path=event.getPath().substring(0,event.getPath().indexOf("/jcr:content")).replace("content", "var");
				metadata_asset_path=event.getPath().substring(0,event.getPath().indexOf("renditions"))+"metadata";
				var_dam_project_value= getProjectName(var_dam_path);
				if(var_dam_project_value.length() > 0){
					setProjectName(metadata_asset_path,var_dam_project_value);
				}
			}		
								
		} catch(RepositoryException e){
			log.error("Error in Repository Exception",e);
		}
	}
	
	/**
	 * set the project name property to DAM Assets
	 */
	public void setProjectName(String  metadata_asset_path, String var_dam_project_value) throws RepositoryException {
		ResourceResolver adminResolver = null;
		try{			
			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);			
        	Resource resource = adminResolver.getResource(metadata_asset_path);
        	if(null != resource){        	
        		Node dam_node = resource.adaptTo(Node.class);        		
        		dam_node.setProperty(DAM_PROJECT_PROPERTY_NAME, var_dam_project_value);
        		dam_node.save();
        	}
		}		
		catch(LoginException e){			
			log.error("Error in Login Exception",e);
		}
		catch(Exception e){
			//log.error("Exception",e);
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
		}
	}
	
	/**
	 * get var dam property name
	 */
	public String getProjectName(String  var_dam_path) throws RepositoryException {
		ResourceResolver adminResolver = null;
		String var_dam_project_property_value="";
		try{			
			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);			
        	Resource resource = adminResolver.getResource(var_dam_path);
        	if(null != resource){        		
        		Node var_dam_node = resource.adaptTo(Node.class);  
        		if(var_dam_node.hasProperty(VAR_DAM_PROJECT_PROPERTY_NAME)){
        			var_dam_project_property_value= var_dam_node.getProperty(VAR_DAM_PROJECT_PROPERTY_NAME).getString();
        		}
        	}        	    	
		}		
		catch(LoginException e){			
			log.error("Error in Login Exception",e);
		}
		catch(Exception e){
			//log.error("Exception",e);
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
		}		
		return var_dam_project_property_value;
	}
}
