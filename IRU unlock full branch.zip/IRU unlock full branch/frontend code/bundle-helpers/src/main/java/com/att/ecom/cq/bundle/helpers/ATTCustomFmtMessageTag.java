package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import java.util.Set;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.PageContext;

import org.apache.sling.settings.SlingSettingsService;
import org.apache.taglibs.standard.tag.common.core.Util;
import org.apache.taglibs.standard.tag.el.fmt.MessageTag;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("serial")
public class ATTCustomFmtMessageTag extends MessageTag {
	private static final Logger log = LoggerFactory.getLogger(ATTCustomFmtMessageTag.class);

	private static final String REQUEST_PARAM = "showkeys";
	private static final String AUTHOR_MODE = "author";
	
	private boolean showkeySpecified = false;
	private String var;
	private int scope;
	private boolean isAuthorMode = false;
	private boolean isRunModeCheckSuccessful = false;

	public ATTCustomFmtMessageTag() {
		super();
		init();
	}

	private void init() {
		showkeySpecified = false;
		var = null;
		scope = PageContext.PAGE_SCOPE;
	}

	@Override
	public void release() {
		super.release();
		init();
	}
	
	public void setVar(String var) {
        this.var = var;
        super.setVar(var); // pass on to super
    }

    public void setScope(String scope) {
    	this.scope = Util.getScope(scope);
    	super.setScope(scope); // pass on to super
    }

	@Override
	public int doStartTag() throws JspException {
		// Check request parameters if we have 'showkeys'
		if (pageContext.getRequest().getParameterMap()
				.containsKey(REQUEST_PARAM)) {
			
			showkeySpecified = Boolean.valueOf(pageContext.getRequest()
					.getParameter(REQUEST_PARAM));
		}

		return super.doStartTag();
	}

	@Override
	public int doEndTag() throws JspException {
		if(isRunModeCheckSuccessful == false) {
			try {
				if(getRunModes().contains(AUTHOR_MODE)) {
					isAuthorMode = true;
				}
				isRunModeCheckSuccessful = true;
			}
			catch(Exception e) {
				isAuthorMode = false;
				isRunModeCheckSuccessful = false;
				log.error("Failed to get CQ instance run mode.", e);
			}
			
			//log.info(String.format("Internal flag status for custom tag. [showkeySpecified: %s isAuthorMode: %s isRunModeCheckSuccessful: %s", showkeySpecified, isAuthorMode, isRunModeCheckSuccessful));
		}
		
		log.debug(String.format("Internal flag status for custom tag. [showkeySpecified: %s isAuthorMode: %s isRunModeCheckSuccessful: %s", showkeySpecified, isAuthorMode, isRunModeCheckSuccessful));
		
		if (showkeySpecified && isAuthorMode) {
			try {
				if(var != null) {
					pageContext.setAttribute(var, keyAttrValue, scope);
				}
				else {
					pageContext.getOut().print(keyAttrValue);
				}
			} catch (IOException ioe) {
				throw new JspTagException(ioe.toString(), ioe);
			}
			
			// Observed few times that release() method is not called.
			// So resetting local variables explicitly.
			init();
			return EVAL_PAGE;

		} else {
			return super.doEndTag();
		}
	}
	
	 public Set<String> getRunModes() {
		log.debug("Querying runmodes of CQ Instance.");
		 
        BundleContext bundleContext = FrameworkUtil.getBundle(ATTCustomFmtMessageTag.class).getBundleContext();
        ServiceReference serviceReference = bundleContext.getServiceReference(SlingSettingsService.class.getName( ));
        SlingSettingsService slingSettingsService = (SlingSettingsService)bundleContext.getService(serviceReference);
        Set<String> runModes = slingSettingsService.getRunModes();
        
        log.debug("CQ Instance current run modes " + runModes);
        return runModes;
    }

}
