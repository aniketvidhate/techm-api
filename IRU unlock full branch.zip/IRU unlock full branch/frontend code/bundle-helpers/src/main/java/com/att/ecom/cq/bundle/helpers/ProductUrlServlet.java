package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import java.io.Writer;
import java.util.*;


import javax.servlet.ServletException; 
import javax.jcr.RepositoryException;


import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.query.Query;
import javax.jcr.query.QueryResult;
import javax.jcr.Session;
import org.apache.sling.jcr.api.SlingRepository;

import org.apache.felix.scr.annotations.Reference;
import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.resource.ResourceResolver;
import com.att.ecom.cq.bundle.helpers.PathHelpers;

import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;


@SlingServlet(paths = "/system/att/product/url")
/**
 * Servlet to return Product url for a passed in skus and producttype
 * to be used by DynamicContent for now.
 */
public class ProductUrlServlet extends SlingAllMethodsServlet {
	
	private static final String DEVICE = "device";
	private static final String PLAN = "plan";
	private static final String SERVICE = "service";
	private static final String ACCESSORY = "accessory";
	private static final String PACKAGE = "package";
	private static final String DEFAULT_LIST_URL = "/shop/wireless/devices/cellphones.html";
	
	private static final long serialVersionUID = 1L;
	
	@Reference
	    SlingRepository repo;
	
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,	IOException {
	
		String skulist = request.getParameter("skusList");
		String producttype = request.getParameter("productType");
		String language = request.getParameter("lang");
		language = language!=null?language:"en";
		
		ResourceResolver resourceResolver = request.getResourceResolver();
		
		String scheme = request.getScheme();
        String servername = request.getServerName();
        int serverport = request.getServerPort();
        
		// init response
        response.setContentType("text/json");
        response.setCharacterEncoding("utf-8");
        Writer out = response.getWriter();   
                
        String[] temp;        
        /* delimiter */
        String delimiter = ",";
        /* given string will be split by the argument delimiter provided. */
        temp = skulist.split(delimiter);       
       
        JSONArray jsonarray = new JSONArray();
		JSONObject productlistjson=new JSONObject();
		String devicepath = null;
		String fulldevicepath = null;
		
		try{
			  for(int i =0; i < temp.length ; i++) {				 
	        	 String eachsku = temp[i];	        	
	        	 if(producttype.equals(DEVICE)){
	        		 devicepath = PathHelpers.getDeviceDetailsPagePath(resourceResolver,language,eachsku);
	        	 } else if(producttype.equals(PLAN)){
	        		 devicepath = PathHelpers.getPlanDetailsPagePath(resourceResolver,language,eachsku);
	        	 } else if(producttype.equals(SERVICE)){
	        		 devicepath = PathHelpers.getServiceDetailsPagePath(resourceResolver,language,eachsku);
	        	 } else if(producttype.equals(ACCESSORY)){
	        		 devicepath = PathHelpers.getAccessoryDetailsPagePath(resourceResolver,language,eachsku);
	        	 } else if(producttype.equals(PACKAGE)){
	        		 devicepath = PathHelpers.getPackageDetailsPagePath(resourceResolver,language,eachsku);
	        	 }
	        	
	        	 if (StringUtils.isNotEmpty(devicepath)){
	        		 fulldevicepath = resourceResolver.map(devicepath);
	     		 }
	     		 productlistjson.put(eachsku,fulldevicepath);	  
	     		 
	          }
			  jsonarray.put(productlistjson);
			
		} catch (JSONException e) {
            out.write("<br/>");
            out.write("<br/>");
            out.write("ERROR: " + e.getMessage());
        } 		
		out.write(jsonarray.toString());				
	}


	@Override
    protected void doPost(SlingHttpServletRequest request,
            SlingHttpServletResponse response) throws ServletException,
            IOException {
			
		String skulist = request.getParameter("skusList");
		String producttype = request.getParameter("productType");
		String language = request.getParameter("lang");
		language = language!=null?language:"en";
		
		ResourceResolver resourceResolver = request.getResourceResolver();
		
		String scheme = request.getScheme();
        String servername = request.getServerName();
        int serverport = request.getServerPort();
        
		// init response
        response.setContentType("text/json");
        response.setCharacterEncoding("utf-8");
        Writer out = response.getWriter();   
                
        String[] temp;        
        /* delimiter */
        String delimiter = ",";
        /* given string will be split by the argument delimiter provided. */
        temp = skulist.split(delimiter);       
       
        JSONArray jsonarray = new JSONArray();
		JSONObject productlistjson=new JSONObject();
		String devicepath = null;
		String fulldevicepath = null;
		
		try{
			  for(int i =0; i < temp.length ; i++) {				 
	        	 String eachsku = temp[i];	        	
	        	 if(producttype.equals(DEVICE)){
	        		 devicepath = PathHelpers.getDeviceDetailsPagePath(resourceResolver,language,eachsku);
	        	 } else if(producttype.equals(PLAN)){
	        		 devicepath = PathHelpers.getPlanDetailsPagePath(resourceResolver,language,eachsku);
	        	 } else if(producttype.equals(SERVICE)){
	        		 devicepath = PathHelpers.getServiceDetailsPagePath(resourceResolver,language,eachsku);
	        	 } else if(producttype.equals(ACCESSORY)){
	        		 devicepath = PathHelpers.getAccessoryDetailsPagePath(resourceResolver,language,eachsku);
	        	 } else if(producttype.equals(PACKAGE)){
	        		 devicepath = PathHelpers.getPackageDetailsPagePath(resourceResolver,language,eachsku);
	        	 }
	        	
	        	 if (StringUtils.isNotEmpty(devicepath)){
	        		 fulldevicepath = resourceResolver.map(devicepath);
	     		 } else {
	     			 fulldevicepath = resourceResolver.map(DEFAULT_LIST_URL);
	     		 }
	     		 productlistjson.put(eachsku,fulldevicepath);	  
	     		     		 
	          }
			  jsonarray.put(productlistjson);
			
			
	//	out.write(jsonarray);	
		productlistjson.write(response.getWriter());
		} catch (JSONException e) {
            out.write("<br/>");
            out.write("<br/>");
            out.write("ERROR: " + e.getMessage());
        } 	
		
	}
}
