package com.att.ecom.cq.bundle.helpers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate=true)
@Service(value=ProductPathResolver.class)
public class ProductPathResolver {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Reference
	private SlingRepository slingRepository;
	
	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	private static final Map<String, String> TYPES;
	
	private static final String QUERY_FOR_MAP;
	
	private static final String QUERY_FOR_MOBILE_MAP;

	private static final String QUERY_FOR_VANITY_PATHS;
	
	private static final String QUERY_FOR_RTI_MAP;
	
	private static final Map<String, String> RTITYPES;

	static {
		String queryBase = "/jcr:root/content/att/shop//element(*, cq:PageContent)[@sku]";
		
		TYPES = new HashMap<String, String>();
		TYPES.put("/apps/att/wireless/templates/details/devicedetails", "devices");
		TYPES.put("/apps/att/wireless/templates/details/fullwidthdevicedetails", "devices");
		TYPES.put("/apps/att/wireless/templates/details/devicedetailswithaccessories", "devices");
		TYPES.put("/apps/att/wireless/templates/details/accessorydetails", "accessories");
		TYPES.put("/apps/att/wireless/templates/details/overviewaccessorydetails", "accessories");
		TYPES.put("/apps/att/wireless/templates/details/plandetails", "plans");
		TYPES.put("/apps/att/wireless/templates/details/packagedetails", "packages");
		TYPES.put("/apps/att/wireless/templates/details/servicedetails", "services");
		TYPES.put("/apps/att/mobile/wireless/templates/structured/baseheader/searchmenufooter/devicedetails","m_devices");
		TYPES.put("/apps/att/mobile/wireless/templates/structured/baseheader/basefooter/accessorydetails","m_accessories");
		TYPES.put("/apps/att/mobile/wireless/templates/structured/baseheader/basefooter/plandetails","m_plans");
		TYPES.put("/apps/att/mobile/wireless/templates/structured/baseheader/searchmenufooter/packagedetails","m_packages");
		TYPES.put("/apps/att/mobile/wireless/templates/structured/baseheader/basefooter/servicedetails","m_services");
		
		StringBuilder builder = new StringBuilder();
		builder.append(queryBase);
		builder.append("[");
		for (Iterator<String> it = TYPES.keySet().iterator(); it.hasNext();) {
			builder.append("@cq:template = '").append(it.next()).append("'");
			if (it.hasNext()) {
				builder.append(" or ");
			}
		}
		builder.append("]");
		
		QUERY_FOR_MAP = builder.toString();
		
		QUERY_FOR_VANITY_PATHS = queryBase + "[@sling:vanityPath]";
		
		String mobileQueryBase = "/jcr:root/content/att/shopmobile//element(*, cq:PageContent)[@skuId]";
		
		StringBuilder mobileBuilder = new StringBuilder();
		mobileBuilder.append(mobileQueryBase);
		mobileBuilder.append("[");
		for (Iterator<String> it = TYPES.keySet().iterator(); it.hasNext();) {
			mobileBuilder.append("@cq:template = '").append(it.next()).append("'");
			if (it.hasNext()) {
				mobileBuilder.append(" or ");
			}
		}
		mobileBuilder.append("]");
		
		QUERY_FOR_MOBILE_MAP = mobileBuilder.toString();
		
		String rtiqueryBase = "//*";		
		RTITYPES = new HashMap<String, String>();
		RTITYPES.put("/apps/att/wireless/templates/rticustomersku", "rticustomerskus");			
		
		StringBuilder builder1 = new StringBuilder();
		builder1.append(rtiqueryBase);
		builder1.append("[");
		for (Iterator<String> it = RTITYPES.keySet().iterator(); it.hasNext();) {
			builder1.append("@cq:template = '").append(it.next()).append("'");
			if (it.hasNext()) {
				builder1.append(" or ");
			}
		}
		builder1.append("]");
		
		QUERY_FOR_RTI_MAP = builder1.toString();		
		
	}
	
	

	private Session administrativeSession;

	private Map<String, Map<String, Map<String, String>>> dataMap;
	
	private Map<String, String> rtiCustomerSkuMap;

	protected void activate(ComponentContext ctx) throws RepositoryException {
		administrativeSession = slingRepository.loginAdministrative(null);

		logger.info("rewriting current vanity paths into skuPath");
		rewriteCurrentVanityPaths();
		logger.info("done rewriting vanity paths");
		
		logger.info("loading maps");
		reloadMaps();
		logger.info("done loading maps");
		
		logger.info("loading  RTI Customer maps");
		reloadRTISkuMaps();
		
	}
	
	protected void deactivate(ComponentContext ctx) {
		administrativeSession.logout();
	}
	
	public Map<String, Map<String, Map<String, String>>> getData() {
		return dataMap;
	}

	private boolean isSkuPath(String candidate) {
		String[] parts = candidate.split("/");
		
		return parts.length == 4 && TYPES.containsValue(parts[2]);
	}

	private void put(Map<String, Map<String, Map<String, String>>> dataMap, String language, String type, String sku, String path) {
		Map<String, Map<String, String>> langMap = dataMap.get(language);
		if (langMap == null) {
			langMap = new HashMap<String, Map<String, String>>();
			dataMap.put(language, langMap);
		}
		Map<String, String> typeMap = langMap.get(type);
		if (typeMap == null) {
			typeMap = new HashMap<String, String>();
			langMap.put(type, typeMap);
		}
		typeMap.put(sku, path);
	}

	public synchronized void reloadMaps() throws RepositoryException {
		Map<String, Map<String, Map<String, String>>> newDataMap = new HashMap<String, Map<String, Map<String, String>>>();
		
		if (administrativeSession.isLive()) {
    		QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();
    		
    		Query query = queryManager.createQuery(QUERY_FOR_MAP, Query.XPATH);
    		QueryResult result = query.execute();
    
    		NodeIterator nodes = result.getNodes();
    		ResourceResolver adminResolver = null;
			try {
					adminResolver = resourceResolverFactory
						.getAdministrativeResourceResolver(null);
		    		while (nodes.hasNext()) {
		    			Node node = nodes.nextNode();
		    			
		    			// no assertions need to be made below because all of these conditions are ensured by the query
		    			String sku = node.getProperty("sku").getString();			
		    			String type = TYPES.get(node.getProperty("cq:template").getString());
		    			
		    			// but our query is broad enough that we need to ensure that the path has the right number of segments
		    			String language = null;
		    			String[] parts = node.getPath().split("/");
		    			if (parts.length > 5) {
		    				language = parts[4];
		    			}
		    
		    			if (language != null) {    				
		    				put(newDataMap, language, type, sku, adminResolver.map(node.getParent().getPath()));
    			    	}
		    		}
		    		
			}catch (LoginException e) {
				logger.error("Unable to login for adminResolver", e);				
			}
			
			Query mobileQuery = queryManager.createQuery(QUERY_FOR_MOBILE_MAP, Query.XPATH);
    		QueryResult mobileResult = mobileQuery.execute();
    
    		NodeIterator mobileNodes = mobileResult.getNodes();
    		adminResolver = null;
			try {
					adminResolver = resourceResolverFactory
						.getAdministrativeResourceResolver(null);
		    		while (mobileNodes.hasNext()) {
		    			Node node = mobileNodes.nextNode();
		    			
		    			// no assertions need to be made below because all of these conditions are ensured by the query
		    			String sku = node.getProperty("skuId").getString();			
		    			String type = TYPES.get(node.getProperty("cq:template").getString());
		    			
		    			// but our query is broad enough that we need to ensure that the path has the right number of segments
		    			String language = null;
		    			String[] parts = node.getPath().split("/");
		    			if (parts.length > 5) {
		    				language = parts[4];
		    			}
		    
		    			if (language != null) {    				
		    				put(newDataMap, language, type, sku, adminResolver.map(node.getParent().getPath()));
    			    	}
		    		}
		    		
			}catch (LoginException e) {
				logger.error("Unable to login for adminResolver", e);				
			}
			
			finally {
				if (adminResolver != null) {
					adminResolver.close();
				}
			}
		
    		dataMap = Collections.unmodifiableMap(newDataMap);
    		PathHelpers.setData(dataMap);
		}
	}
	
	
	/**
	 * method to load rtiskumaps from /etc location
	 * @throws RepositoryException
	 */
	public synchronized void reloadRTISkuMaps() throws RepositoryException {
		Map<String, String> newRtiDataMap = new HashMap<String, String>();
		
		if (administrativeSession.isLive()) {
    		QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();    		
    		Query query = queryManager.createQuery(QUERY_FOR_RTI_MAP, Query.XPATH);
    		QueryResult result = query.execute();
    		
    		logger.debug("The RTI Map Builder Query:"+query.getStatement());
    		NodeIterator nodes = result.getNodes();
    		ResourceResolver adminResolver = null;
			try {
					adminResolver = resourceResolverFactory
						.getAdministrativeResourceResolver(null);
		    		while (nodes.hasNext()) {
		    			
		    			Node node = nodes.nextNode();	    			
		    			String sku = node.getProperty("sku").getString();			

		    			newRtiDataMap.put(sku, node.getParent().getPath());
    			    	
		    		}
		    		
			}catch (LoginException e) {
				logger.error("Unable to login for adminResolver", e);				
			}
			
			finally {
				if (adminResolver != null) {
					adminResolver.close();
				}
			}
		
			rtiCustomerSkuMap = Collections.unmodifiableMap(newRtiDataMap);			
			PathHelpers.setRTIData(rtiCustomerSkuMap);
		}
	}
	
	private void rewriteCurrentVanityPaths() throws RepositoryException {
		QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();
		Query query = queryManager.createQuery(QUERY_FOR_VANITY_PATHS, Query.XPATH);
		QueryResult result = query.execute();

		NodeIterator nodes = result.getNodes();
		while (nodes.hasNext()) {
			Node node = nodes.nextNode();
			Property prop = node.getProperty("sling:vanityPath");
			if (prop.isMultiple()) {
				List<Value> resetValues = new ArrayList<Value>();
				Value[] values = prop.getValues();
				for (Value value : values) {
					String candidate = value.getString();
					if (!isSkuPath(candidate)) {
						resetValues.add(value);
					}
				}
				if (resetValues.size() != values.length) {
					if (resetValues.size() == 0) {
						prop.remove();
						if (node.hasProperty("sling:redirect")) {
							node.getProperty("sling:redirect").remove();
						}
					} else {
						prop.setValue(resetValues.toArray(new Value[resetValues.size()]));
					}
				}
			} else {
				String candidate = prop.getString();
				if (isSkuPath(candidate)) {
					prop.remove();
					if (node.hasProperty("sling:redirect")) {
						node.getProperty("sling:redirect").remove();
					}
				}
			}

		}

		if (administrativeSession.hasPendingChanges()) {
			administrativeSession.save();
		}

	}

}
