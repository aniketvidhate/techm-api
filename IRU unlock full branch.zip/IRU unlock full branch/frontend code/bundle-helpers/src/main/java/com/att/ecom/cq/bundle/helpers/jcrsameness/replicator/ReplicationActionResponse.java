package com.att.ecom.cq.bundle.helpers.jcrsameness.replicator;

import java.util.Hashtable;

public class ReplicationActionResponse {
	private String agentId;
	private Hashtable<String, String> pathReplicationAction;
	private String agentTransportURL;
	private String replicationAgentStatus;
	
	public String getReplicationAgentStatus() {
		return replicationAgentStatus;
	}
	public void setReplicationAgentStatus(String replicationAgentStatus) {
		this.replicationAgentStatus = replicationAgentStatus;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public Hashtable<String, String> getPathReplicationAction() {
		return pathReplicationAction;
	}
	public void setPathReplicationAction(Hashtable<String, String> pathReplicationAction) {
		this.pathReplicationAction = pathReplicationAction;
	}
	public String getAgentTransportURL() {
		return agentTransportURL;
	}
	public void setAgentTransportURL(String agentTransportURL) {
		this.agentTransportURL = agentTransportURL;
	}

}
