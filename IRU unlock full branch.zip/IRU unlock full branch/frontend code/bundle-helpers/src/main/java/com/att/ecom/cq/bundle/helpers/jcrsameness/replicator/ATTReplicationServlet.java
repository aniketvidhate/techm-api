package com.att.ecom.cq.bundle.helpers.jcrsameness.replicator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

@SlingServlet(
        paths = {"/system/att/servlets/replicationservlet"}
)
public class ATTReplicationServlet  extends SlingAllMethodsServlet  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	protected void doPost(SlingHttpServletRequest request,SlingHttpServletResponse response) throws ServletException,	IOException {
		String replicationAgents = "ALL";
		if(request.getParameterMap().containsKey("replicationAgentIds") && !"".equals(request.getParameter("replicationAgentIds"))){
			replicationAgents = request.getParameter("replicationAgentIds"); 
		}
		
		ReplicateDifferences replicateDifferences = new ReplicateDifferences(replicationAgents, request.getParameter("diffFilePath"),request.getParameter("replicationAction"));
		ArrayList<ReplicationActionResponse> actionResp = replicateDifferences.replicateDifferences();
		JSONObject responseJsonObj= new JSONObject();
		try {
			
			for (Iterator iterator = actionResp.iterator(); iterator.hasNext();) {
				ReplicationActionResponse replicationActionResponse = (ReplicationActionResponse) iterator.next();
				JSONObject responseAppendObj = new JSONObject();
				responseAppendObj.put("ReplicationAgentId", replicationActionResponse.getAgentId());
				responseAppendObj.put("transportURL", replicationActionResponse.getAgentTransportURL());
				responseAppendObj.put("status", replicationActionResponse.getReplicationAgentStatus());
				responseAppendObj.put("replicationResult", replicationActionResponse.getPathReplicationAction());
				responseJsonObj.put(replicationActionResponse.getAgentId(), responseAppendObj);
			}
			
		} catch (JSONException e1) {
			e1.printStackTrace();
		}
		
		String output = responseJsonObj.toString();
		response.getOutputStream().print(output);
		response.setContentType("application/json");
	}
	
	protected void doGet(SlingHttpServletRequest request,SlingHttpServletResponse response) throws ServletException,	IOException {
		doPost(request, response);
	}
	
	
	
	
	

}
