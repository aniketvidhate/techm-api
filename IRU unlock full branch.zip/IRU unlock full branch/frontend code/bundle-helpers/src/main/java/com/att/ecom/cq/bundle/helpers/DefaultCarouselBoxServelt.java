package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Servlet to Update content of globalsearch_AutoSuggest.xml to CQ Repository.
 * @author Sushant Patil(SP0159)
 * @created on Jan 2014
 */

@SlingServlet(paths = "/system/att/cms/internaltools/defaultcarousel")

public class DefaultCarouselBoxServelt extends SlingAllMethodsServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String CQ_TEMPLATE="cq:template";
	private static final String ATTR_CONTENTPAGE="contentPage";
	private static final String PRODUCT_ACCESSORY_DETAIL_OVERVIEW ="/apps/att/wireless/templates/details/overviewaccessorydetails";
	private static final String PRODUCT_ACCESSORY_DETAIL_WO_OVERVIEW ="/apps/att/wireless/templates/details/accessorydetails";
	private static final String PRODUCT_DEVICE_DETAIL_ACCESSORY ="/apps/att/wireless/templates/details/devicedetailswithaccessories";


	private Logger logger = LoggerFactory.getLogger(DefaultCarouselBoxServelt.class);

	@Reference
	private SlingRepository slingRepository;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,	IOException 
	{	
		//logger.error("calling validation servlet=="+request.getParameter(ATTR_CONTENTPAGE));
		javax.jcr.Node rootNode=null;
		String output="";
		response.setStatus(response.SC_OK);		
		response.setCharacterEncoding("US-ASCII");
		response.setContentType("text/html");
		Writer out = response.getWriter();
		String contentPagePath= request.getParameter(ATTR_CONTENTPAGE);
		  if(contentPagePath!=null || contentPagePath!=""){
			try 
			{
				Session session = request.getResourceResolver().adaptTo(Session.class);
				rootNode =(javax.jcr.Node) session.getNode(contentPagePath);
				if(null!=rootNode){
					
					NodeIterator childNodes= rootNode.getNodes();
					for (NodeIterator ni = childNodes; ni.hasNext();) {
						javax.jcr.Node childNode = ni.nextNode();
						if(childNode.getProperty(CQ_TEMPLATE).getString().equalsIgnoreCase(PRODUCT_ACCESSORY_DETAIL_OVERVIEW) ||
						   childNode.getProperty(CQ_TEMPLATE).getString().equalsIgnoreCase(PRODUCT_ACCESSORY_DETAIL_WO_OVERVIEW))
						{
						  output="Recommended Accessories";
						  break;
						}
						if(childNode.getProperty(CQ_TEMPLATE).getString().equalsIgnoreCase(PRODUCT_DEVICE_DETAIL_ACCESSORY))
						{
						  output="Recommended Accessories <br><p style=\"font-size: 13px;\">Add accessories to the cart prior to adding the device, and the accessories will display at checkout.</p>";
						  break;
						}
							
					}
				}
				//logger.error("create child nodes and set properties");
			}
			catch (RepositoryException e)  
			{
				logger.error(e.getMessage());
				output +="RepositoryException Error:<br>"+e.getMessage();
				//output +=e.getMessage();
			}

			catch (Exception e) 
			{
				logger.error(e.getMessage());
				output +="Error:<br>"+e.getMessage();
				//output +=e.getMessage();
			}
		}
		out.write(output);
	}

	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}