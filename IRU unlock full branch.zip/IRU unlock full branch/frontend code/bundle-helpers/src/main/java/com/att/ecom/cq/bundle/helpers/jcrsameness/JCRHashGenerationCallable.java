/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.SortedMap;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is a Callable class to get JCR hash. It makes a call to servlet that generates and returns the JCR hash
 * value as TreeMap. In TreeMap key is a JCR content path and value is it's hash value. FInally it returns JCR hash map.
 * 
 * @author Sunil Reddy Aleti
 * @since 16th January 2013
 */

public class JCRHashGenerationCallable implements Callable<SortedMap<String, String>> {

    public static final Logger logger = LoggerFactory.getLogger(JCRHashGenerationCallable.class);

    private JCRSamenessToolRequest mJCRSamenessToolRequest = null;

    private long mStartTime;

    private String mSourceHostName = null;

    private JCRSamenessToolHelper mJCRSamenessToolHelper;

    public JCRHashGenerationCallable(JCRSamenessToolRequest pInputRequest, long pStartTime, String pSourceHostName,
            JCRSamenessToolHelper pJCRSamenessToolHelper) {
        mJCRSamenessToolRequest = pInputRequest;
        mStartTime = pStartTime;
        mSourceHostName = pSourceHostName;
        mJCRSamenessToolHelper = pJCRSamenessToolHelper;
    }

    @Override
    public SortedMap<String, String> call() throws Exception {
        String modifiedHostName = mJCRSamenessToolHelper.getModifiedHostName(mSourceHostName);
        String processName = "[Getting JCR hash for Source " + modifiedHostName + " ] --> ";
        logger.info(processName + "start.");
        
        SortedMap<String, String> sourceJCRHash = null;
        try {

            sourceJCRHash = mJCRSamenessToolHelper.getJCRHash(mSourceHostName, mJCRSamenessToolRequest,
                    JCRSamenessServlet.CONTENT_TYPE_OCTET_STREAM, JCRSamenessServlet.REQUEST_METHOD_GET);
            
        } catch (MalformedURLException mfe) {
            logger.error(processName + "MalformedURLException - ", mfe);
        } catch (IOException ioe) {
            logger.error(processName + "IOException - ", ioe);
        } catch (ClassNotFoundException cnfe) {
            logger.error(processName + "ClassNotFoundException - ", cnfe);
        } finally {
            logger.info(processName + " End. Total time is " + ((System.currentTimeMillis() - mStartTime) / 1000)
                    + " seconds");        
        }
        
        return sourceJCRHash;
    }

}
