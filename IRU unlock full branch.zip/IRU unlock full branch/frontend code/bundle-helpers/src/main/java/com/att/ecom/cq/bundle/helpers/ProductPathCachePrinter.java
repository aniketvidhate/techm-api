package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Map;
import java.io.PrintWriter;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import com.att.ecom.cq.bundle.helpers.ProductPathResolver;

/**
 * 
 * Servlet to output CQ Product Path Cache Urls.
 * 
 * @author rx1755
 * @created April 26 2012
 */

@SlingServlet(paths = "/system/att/product/paths")

public class ProductPathCachePrinter extends SlingAllMethodsServlet{

    /**
     * The path resolver.
     */
	@Reference
	private ProductPathResolver mProductPathResolver;
	
	
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,	IOException 
	{
		// init response
        response.setContentType("text/html");
        response.setCharacterEncoding("utf-8");
      
        PrintWriter printWriter = response.getWriter();
        final Map<String, Map<String, Map<String, String>>> data = this.mProductPathResolver.getData();
		if (data == null) {
			printWriter.println("No cached data available.");
		} else {
			for (final String language : data.keySet()) {
				printWriter.println("Language is: ");
				printWriter.println(language);
				printWriter.println("<br/>");
		
				Map<String, Map<String, String>> langData = data.get(language);
				for (String type : langData.keySet()) {
					printWriter.println("The ProductType is: ");
					printWriter.println(type);
					printWriter.println("<br/>");
					Map<String, String> typeData = langData.get(type);
					for (String sku : typeData.keySet()) {
						printWriter.println(sku);
						printWriter.println(" - ");
						printWriter.println(typeData.get(sku));
						printWriter.println("<br/>");
					}
				}
			}
		}
		
	}	
}


