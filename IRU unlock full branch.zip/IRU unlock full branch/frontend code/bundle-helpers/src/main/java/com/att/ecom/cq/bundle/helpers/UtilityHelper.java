package com.att.ecom.cq.bundle.helpers;

import java.math.BigInteger;
import java.security.MessageDigest;
import org.apache.commons.lang.StringUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * 
 * @author rx1755
 * Utility Helper class 
 */
public class UtilityHelper {
	
  private static final Logger LOGGER = LoggerFactory.getLogger(UtilityHelper.class);
  
    /**
     * method to return MD5 hashing of a string
     * @param serverName
     * @return hashedServerName
     */
	public static String getMD5HashString(String serverName) {
		String hashedServerName = "Not Known";
		
		if (StringUtils.isNotBlank(serverName)) {
			try {
				MessageDigest messageDigest=MessageDigest.getInstance("MD5");
				messageDigest.update(serverName.getBytes(),0,serverName.length());
		        hashedServerName = new BigInteger(1,messageDigest.digest()).toString();
		        LOGGER.debug("The Hashed Server Name is:"+hashedServerName);
			} catch (Exception e) {
				LOGGER.error("Unable to Hash", e);				
			} 
		}
		return hashedServerName;
	}

}
