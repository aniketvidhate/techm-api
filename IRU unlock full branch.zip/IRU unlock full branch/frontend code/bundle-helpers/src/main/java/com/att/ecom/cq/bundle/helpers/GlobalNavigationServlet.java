package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Property;
import javax.jcr.Value;
import javax.jcr.PropertyIterator;
import javax.servlet.ServletException; 
import javax.jcr.RepositoryException;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.commons.lang.StringUtils;
import javax.jcr.Session;
//import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.apache.sling.api.resource.ResourceResolverFactory;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


/*
 * Servlet for "GlobalNavigationServlet.
 * @author Shovon Zaman (sz1004)
 * @created on July 2013
 * Notes:
 */
 

@SlingServlet(methods = { "GET", "POST" },paths = {"/system/att/helpers/globalnavigationservlet"})

public class GlobalNavigationServlet extends SlingAllMethodsServlet{

	private Logger logger = LoggerFactory.getLogger(GlobalNavigationServlet.class);
	
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException 
	{
		
		String pagepath = request.getParameter("pagepath");
		String nodepath = request.getParameter("path");
		String showtree = request.getParameter("showtree");
		showtree = showtree!=null?showtree.toLowerCase():"false";
		String getnodeinfo= request.getParameter("getnodeinfo");
		getnodeinfo = getnodeinfo!=null?getnodeinfo.toLowerCase():"false";
		String addnode= request.getParameter("addnode");
		addnode = addnode!=null?addnode.toLowerCase():"false";		
		String deletenode= request.getParameter("deletenode");
		deletenode = deletenode!=null?deletenode.toLowerCase():"false";
		Node topNode =null;
		Node chNode =null;	
		int i=0;
		String output = "";
		try 
		{
			ResourceResolver resourceResolver =request.getResourceResolver();
			Session session = resourceResolver.adaptTo(Session.class);
			//Resource currentResource = request.getResource(pagepath.replace("/jcr:content/mainpar","/jcr:content"));
			//Node currentNode = currentResource.adaptTo(Node.class);
			Node currentNode =(Node) session.getItem(pagepath.replace("/jcr:content/mainpar","/jcr:content"));
			if(currentNode.hasNode("mainpar"))
			{
				topNode=currentNode.getNode("mainpar");		
			}
			else
			{
				topNode = currentNode.addNode("mainpar", "nt:unstructured");
				session.save();
			}
			List<JSONObject> objjsonNavigationList = new ArrayList<JSONObject>();  
			JSONObject jsonnavelementobj=new JSONObject();
	        PrintWriter out = response.getWriter();
			if((showtree.equals("true"))&& (nodepath.equals(pagepath)))
			{
				if(topNode.hasNode("header"))
				{
					chNode=null;
					chNode=topNode.getNode("header");
					i=getNodenumchild(chNode);
					jsonnavelementobj=getjsonproperties(jsonnavelementobj,chNode.getName().toString(),false,i);
				}
				else
				{
					jsonnavelementobj=getjsonproperties(jsonnavelementobj,"header",false,0);
				}
				objjsonNavigationList.add(jsonnavelementobj);
				jsonnavelementobj=null;
				jsonnavelementobj=new JSONObject();
				if(topNode.hasNode("footer"))
				{
					chNode=null;
					chNode=topNode.getNode("footer");
					i=getNodenumchild(chNode);
					jsonnavelementobj=getjsonproperties(jsonnavelementobj,chNode.getName().toString(),false,i);
				}
				else
				{
					jsonnavelementobj=getjsonproperties(jsonnavelementobj,"footer",false,0);
				}
				objjsonNavigationList.add(jsonnavelementobj);
				jsonnavelementobj=null;
				jsonnavelementobj=new JSONObject();
				if(topNode.hasNode("globalnav"))
				{
					chNode=null;
					chNode=topNode.getNode("globalnav");
					i=getNodenumchild(chNode);
					jsonnavelementobj=getjsonproperties(jsonnavelementobj,chNode.getName().toString(),false,i);
				}
				else
				{
					jsonnavelementobj=getjsonproperties(jsonnavelementobj,"globalnav",false,0);
				}
				objjsonNavigationList.add(jsonnavelementobj);
				out.print(objjsonNavigationList);
			}
			else if((showtree.equals("true"))&& (!(nodepath.equals(pagepath))))
			{
				 //if (session.nodeExists((topNode.getPath() + pnodepath)))
				 String pnodepath = nodepath.replace(pagepath,"");
				 pnodepath=pnodepath.substring(1);
				
				 int pnodeposition = StringUtils.countMatches(pnodepath, "/");
				 if(topNode.hasNode(pnodepath))
				 {
					 Node pNode=topNode.getNode(pnodepath);
                     if (pNode.hasNodes())
                     {  
							NodeIterator childNodes = pNode.getNodes();
							while (childNodes.hasNext()) 
							{
                                 Boolean isleaf=false;							
								 chNode=null;
								 chNode = childNodes.nextNode();
								 i=getNodenumchild(chNode);
								 if ((pnodeposition > 1)&&( i ==0))
								 {
									isleaf=true;
								 }
								 jsonnavelementobj=null;
								 jsonnavelementobj=new JSONObject();
								 jsonnavelementobj=getjsonproperties(jsonnavelementobj,chNode.getName().toString(),isleaf,i);
								 objjsonNavigationList.add(jsonnavelementobj);
							}
					  }	 
				 }
				 out.print(objjsonNavigationList);
			}
			else if(getnodeinfo.equals("true"))
			{
				if(topNode.hasNode(nodepath))
				{
					 chNode=topNode.getNode(nodepath);
                     if (chNode.hasProperties())
                     { 
						PropertyIterator nodeproperties = chNode.getProperties();
						while (nodeproperties.hasNext()) 
						{	
							Property prop= nodeproperties.nextProperty();
							//if(!prop.getDefinition().isMultiple()){}
							if (prop.isMultiple()) 
							{
								 Value [] arrvalues = prop.getValues();
								 JSONArray jArray = new JSONArray();
								 for (int j=0;j<arrvalues.length;j++)
								 {	
									jArray.put(arrvalues[j].getString());	
								 }
								 jsonnavelementobj.put(prop.getName(),jArray);
								 
							} else 
							{
								jsonnavelementobj.put(prop.getName(), prop.getString());
							}
						}
					 }
				}
				out.print(jsonnavelementobj);
			}
			else if(addnode.equals("true"))
			{			
				if(topNode.hasNode(nodepath))
				{
					jsonnavelementobj.put("status","conflict");
				}
				else
				{
				    String[] strnodenames = nodepath.split("/");
					for (int j=0;j<strnodenames.length;j++)
					{
					    if (j==0)
						{
							nodepath=strnodenames[j];
						}	
						else
						{
							nodepath=nodepath + "/" + strnodenames[j];
						}
						if(!(topNode.hasNode(nodepath)))
						{
							chNode = topNode.addNode(nodepath, "nt:unstructured");
							session.save();
						}	
					}
					jsonnavelementobj.put("status","success");
				}
				out.print(jsonnavelementobj);
			}
			else if(deletenode.equals("true"))
			{			
				if(topNode.hasNode(nodepath))
				{
					chNode = topNode.getNode(nodepath);
					chNode.remove();
					session.save();
					jsonnavelementobj.put("status","success");
				}
				else
				{
					jsonnavelementobj.put("status","conflict");
				}
				out.print(jsonnavelementobj);
			}	
			else
			{
				out.print(objjsonNavigationList);
			}
			response.setContentType("application/json");
			response.setStatus(response.SC_OK);	
			out.flush();
			jsonnavelementobj=null;
			objjsonNavigationList.clear();
		}
		catch (RepositoryException e) 
		{
			logger.error("RepositoryException", e);
			 e.printStackTrace();
		}
		catch (JSONException e) {
			logger.error("JSONException", e);
            e.printStackTrace();
        }
	}
	public static JSONObject getjsonproperties(JSONObject jsonelementobj,String nodename,boolean leafbool, int numchild) {
	    try {	    	
			jsonelementobj.put("name", nodename);
			jsonelementobj.put("text", nodename);
			if(leafbool)
			{	  				  
				  jsonelementobj.put("type","cq:Page");
				  jsonelementobj.put("cls","file");
				  jsonelementobj.put("expandable",false);
				  jsonelementobj.put("leaf",true);
				  jsonelementobj.put("sub",numchild);
			}
			else
			{

				  jsonelementobj.put("expandable",true);
				  if(numchild > 0)
				  {
					jsonelementobj.put("sub",numchild);
					jsonelementobj.put("expanded",false);
				  }
				  else
				  {
					jsonelementobj.put("expanded",true);
				  }
				  jsonelementobj.put("loaded",false);
				  jsonelementobj.put("type","sling:OrderedFolder");
				  jsonelementobj.put("cls","folder");
				  jsonelementobj.put("leaf",false);
			
			}
			jsonelementobj.put("isLiveCopy",false);
	    } 
	    catch (JSONException e) {
            e.printStackTrace();
        }
	    return jsonelementobj;
	}
	/*
	
	*/
	public static int getNodenumchild(Node pNode) {
	    int  numchild=0;
	    try {	    	
			if(pNode.hasNodes())
			{
			     NodeIterator ni = pNode.getNodes();
                 numchild = (int)ni.getSize();
			}				 
	    } 
	    catch (RepositoryException e) {
            e.printStackTrace();
        }
	    return numchild;
	}	
	/*
	
	*/
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
}
