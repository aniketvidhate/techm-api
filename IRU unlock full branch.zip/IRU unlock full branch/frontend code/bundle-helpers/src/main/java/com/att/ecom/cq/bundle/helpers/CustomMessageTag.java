package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;

import org.apache.taglibs.standard.tag.el.fmt.MessageTag;

@SuppressWarnings("serial")
public class CustomMessageTag extends MessageTag {

	private static final String REQUEST_PARAM = "showkeys";
	private boolean showkeySpecified = false;

	public CustomMessageTag() {
		super();
		init();
	}

	private void init() {
		showkeySpecified = false;
	}

	@Override
	public void release() {
		super.release();
		init();
	}

	@Override
	public int doStartTag() throws JspException {
		// Check request parameters if we have 'showkeys'
		if (pageContext.getRequest().getParameterMap()
				.containsKey(REQUEST_PARAM)) {
			
			showkeySpecified = Boolean.valueOf(pageContext.getRequest()
					.getParameter(REQUEST_PARAM));
		}

		return super.doStartTag();
	}

	@Override
	public int doEndTag() throws JspException {
		if (showkeySpecified) {
			try {
				pageContext.getOut().print(keyAttrValue);
			} catch (IOException ioe) {
				throw new JspTagException(ioe.toString(), ioe);
			}
			
			// Observed few times that release() method is not called.
			// So reseting local variables explicitly.
			init();
			return EVAL_PAGE;

		} else {
			return super.doEndTag();
		}
	}

}
