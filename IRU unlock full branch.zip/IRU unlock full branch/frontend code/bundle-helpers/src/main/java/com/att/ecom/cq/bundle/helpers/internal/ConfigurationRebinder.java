package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Bundle;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Scheduled job which periodically examines all available Configuration objects and checks for cases where a
 * configuration is bound to a location which does not exist. If a replacement location can be found, the configuration
 * is rebound.
 */
@Component
@Service
@Property(name = "scheduler.period", longValue = 60)
public class ConfigurationRebinder implements Runnable {

    /**
     * The OSGi Bundle Context
     */
    private BundleContext mBundleContext;

    /**
     * The OSGi configuration admin service.
     */
    @Reference
    private ConfigurationAdmin mConfigAdmin;

    /**
     *  A logger.
     */
    private final Logger mLogger = LoggerFactory.getLogger(ConfigurationRebinder.class);

    /**
     * Activate this component
     * 
     * @param pCompCtx the component context
     */
    protected void activate(final ComponentContext pCompCtx) {
        this.mBundleContext = pCompCtx.getBundleContext();
    }

    /**
     * Deactivate this component
     * 
     * @param pCompCtx the component context
     */
    protected void deactivate(final ComponentContext pCompCtx) {
        this.mBundleContext = null;
    }

    /**
     * Run the actual rebinding process.
     */
    @Override
    public void run() {
        this.mLogger.debug("Start checking configuration bindings");
        final Pattern pattern = Pattern.compile("-\\d+\\.");

        final Map</* prefix */String, /* location */String> bundleLocations = new HashMap<String, String>();
        for (final Bundle bundle : this.mBundleContext.getBundles()) {
            final String location = bundle.getLocation();
            final Matcher matcher = pattern.matcher(location);
            if (matcher.find()) {
                final String prefix = location.substring(0, matcher.start());
                bundleLocations.put(prefix, location);
            } else {
                bundleLocations.put(location, location);
            }
        }

        try {
            final Configuration[] configs = this.mConfigAdmin.listConfigurations(null);
            for (Configuration config : configs) {
                final String location = config.getBundleLocation();
                if (location != null) {
                    if (!bundleLocations.containsValue(location)) {
                        this.mLogger.debug("For pid {}; Found unmatched location: {}", config.getPid(), location);
                        final Matcher matcher = pattern.matcher(location);
                        if (matcher.find()) {
                            final String prefix = location.substring(0, matcher.start());
                            if (bundleLocations.containsKey(prefix)) {
                                final String newLocation = bundleLocations.get(prefix);
                                this.mLogger.debug("Found matching location using prefix {} - {}", prefix, newLocation);
                                config.setBundleLocation(newLocation);
                            } else {
                                this.mLogger.debug("Unable to find matching location using prefix {}", prefix);
                            }
                        } else {
                            this.mLogger.debug("Bundle location {} is not matchable.", location);
                        }
                    }
                }
            }

        } catch (IOException e) {
            this.mLogger.error("Unable to list configurations");
        } catch (InvalidSyntaxException e) {
            this.mLogger.error("Unable to list configurations");
        }
        this.mLogger.debug("End checking configuration bindings");
    }
}
