package com.att.ecom.cq.bundle.helpers;

import java.sql.Date;
import java.util.Map;

import org.apache.sling.api.resource.ResourceResolver;

import com.day.cq.wcm.api.Page;

public class AccessorySharedItem extends SharedContentItem {

	private Page mCurrentPage;
	
	public AccessorySharedItem(String pContentPath,
			ResourceResolver pResourceResolver) {
		super(pContentPath, pResourceResolver);
	}
	
	public Boolean getHideOverview() {
		return Boolean.valueOf(getPropertyValue("hideoverview"));
	}
	
	public Boolean getHideDetails() {
		return Boolean.valueOf(getPropertyValue("hidedetails"));
	}

	public Boolean getHideFeatures() {
		return Boolean.valueOf(getPropertyValue("hidefeatures"));
	}
	
	public Boolean getDetailsOverview() {
		return Boolean.valueOf(getPropertyValue("detailsOverview"));
	}
	
	public Boolean getHideReviews() {
		return Boolean.valueOf(getPropertyValue("hidereviews"));
	}
	
	public String getOverviewLabel() {
		return getPropertyValue("overviewLabel");
	}
	
	public String getDetailsLabel() {
		return getPropertyValue("detailsLabel");
	}
	
	public String getReviewsLabel() {
		return getPropertyValue("reviewsLabel");
	}
	
	public Date getLastModified() {
		return getPropertyValue("jcr:lastModified", Date.class, false);
	}
	
	public String getDetailsOverviewParPath() {
		return getResourcePath("detailsoverviewpar");
	}
	
	public String getVideoBoxParPath() {
		return getResourcePath("videoboxparsys");
	}
	
	public Page getCurrentPage() {
		return this.mCurrentPage;
	}
	
	public void setCurrentPage(Page pCurrentPage) {
		this.mCurrentPage = pCurrentPage;
	}

	@Override
	public String getUrlDisplayPath() {
		return PathHelpers.getDynamicAccessoryDetailsPagePath(super.mResourceResolver, mCurrentPage, getSku(), getTitle());
	}
	
	public String getUrlResourcePath() {
		return getUrlDisplayPath().replace(".html", "");
	}
	
}
