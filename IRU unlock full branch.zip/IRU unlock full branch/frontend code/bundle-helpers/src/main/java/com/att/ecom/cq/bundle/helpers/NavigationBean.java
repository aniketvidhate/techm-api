package com.att.ecom.cq.bundle.helpers;

import javax.jcr.Node;
import javax.jcr.RepositoryException;


public class NavigationBean {

	
	private String displayText;
	private String linkUrl;
	private String fontStyle;
	private String linkOnClickScript;
	private String linkTarget;	
	private Integer order;
	private String path;
	private String cqPath;
	
	public NavigationBean(String text, String url, int order) {
	      this.displayText = text;
	      this.linkUrl = url;
	      this.order = new Integer(order);
    }
	
	public NavigationBean(String text, String url, String cqpath , int order) {
	      this.displayText = text;
	      this.linkUrl = url;
	      this.cqPath = cqpath;
	      this.order = new Integer(order);
  }
	
	public NavigationBean(String text, String url, String onclickscript, String target, int order) {
	      this.displayText = text;
	      this.linkUrl = url;
	      this.linkOnClickScript= onclickscript;
	      this.linkTarget = target;
	      this.order = new Integer(order);
  }
	
	public NavigationBean(String text, String url, String style,String onclickscript, String target, int order) {
	      this.displayText = text;
	      this.linkUrl = url;
	      this.fontStyle = style;
	      this.linkOnClickScript= onclickscript;
	      this.linkTarget = target;
	      this.order = new Integer(order);
}
	
    public NavigationBean(Node n) {
    	try {
	      if (n.getProperty("displayText") != null) {
	  	  	this.displayText = n.getProperty("displayText").getString();
	      }
    	} catch (Exception e) {
    		this.displayText = null;
    	}
    	try {
	      if (n.getProperty("linkUrl") != null) {
		  	this.linkUrl = n.getProperty("linkUrl").getString();
	      } 
    	} catch (Exception e2) {
    		this.linkUrl = null;
    	}
    	try {
    		String name = n.getName();
    		this.order = new Integer(name); 
    	} catch (Exception e5) {
    		this.order = null;
    	}
    	/*
    	 * Added below two new properties to get onclick script and target for links
    	 */
    	try {
  	      if (n.getProperty("linkOnClickScript") != null) {
  	  	  	this.linkOnClickScript = n.getProperty("linkOnClickScript").getString();
  	      }
      	} catch (Exception e3) {
      		this.linkOnClickScript = null;
      	}
      	try {
  	      if (n.getProperty("linkTarget") != null) {
  		  	this.linkTarget = n.getProperty("linkTarget").getString();
  	      } 
      	} catch (Exception e4) {
      		this.linkTarget = null;
      	}
      	/*
    	 * Added below  new properties to get font style
    	 */
      	try {
    	      if (n.getProperty("fontStyle") != null) {
    		  	this.fontStyle = n.getProperty("fontStyle").getString();
    	      } 
        	} catch (Exception e6) {
        		this.fontStyle = null;
        	}
    	
    	try {
			this.path = n.getPath();
		} catch (RepositoryException e) {
			this.path = null;
		}
		
		/*
    	 * Added below  new propertie to get cqpath
    	 */
      	try {
    	      if (n.getProperty("cqPath") != null) {
    		  	this.cqPath = n.getProperty("cqPath").getString();
    	      } 
        	} catch (Exception e7) {
        		this.cqPath = null;
        	}
		
    }

    public String getDisplayText() {
    	return this.displayText;
    }
    
    public String getLinkUrl() {
    	return this.linkUrl;
    }
    
    public Integer getOrder() {
    	return this.order;
    }
    
    public void setPath(String Path) {
    	this.path = Path;
    }
    
    public String getPath() {
    	return this.path;
    }
    
    public String getLinkOnClickScript() {
    	return this.linkOnClickScript;
    }
    
    public String getlinkTarget() {
    	return this.linkTarget;
    }
    
    public String getfontStyle() {
    	return this.fontStyle;
    }

	public String getCqPath() {
		return cqPath;
	}

	public void setCqPath(String cqPath) {
		this.cqPath = cqPath;
	}
    
    public String getcqPath() {
    	return this.cqPath;
    }
    
    
}