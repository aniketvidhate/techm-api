package com.att.ecom.cq.bundle.helpers.jcrsameness.replicator;

/*
 * 
 * THIS CLASS IS JUST KEPT AS A CONCEPT AND IS NOT USED. THIS CAN BE USED 
 * ONLY IF THE THE REPLCATION OPTIONS HAS isSyncronous TO TRUE
 * 
 * 
 */


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.helpers.jcrsameness.JCRSamenessServlet;
import com.day.cq.replication.Agent;
import com.day.cq.replication.ReplicationAction;
import com.day.cq.replication.ReplicationListener;
import com.day.cq.replication.ReplicationLog.Level;
import com.day.cq.replication.ReplicationResult;

public class ReplicateDifferencesLogListener implements ReplicationListener{
	public static final Logger logger = LoggerFactory.getLogger(ReplicateDifferencesLogListener.class);
	
	@Override
	public void onStart(Agent paramAgent,	ReplicationAction paramReplicationAction) {
		logger.info("------------------ ON START------------------");
		logger.info("Agent Used:"+paramAgent.getId());
		logger.info(""+paramReplicationAction.getPath());
		logger.info(""+paramReplicationAction.getLog().getLines().toArray());
		
	}

	@Override
	public void onMessage(Level paramLevel, String paramString) {
		logger.info("------------------ ON MESSAGE------------------");
		logger.info(paramString);
//		logger.info("Agent Used:"+paramAgent.getId());
//		logger.info(""+paramReplicationAction.getPath());
//		logger.info(""+paramReplicationAction.getLog().getLines().toArray());
		
	}

	@Override
	public void onEnd(Agent paramAgent,ReplicationAction paramReplicationAction,ReplicationResult paramReplicationResult) {
		logger.info("------------------ ON END------------------");
		logger.info("Agent Used:"+paramAgent.getId());
		logger.info(""+paramReplicationAction.getPath());
		logger.info(""+paramReplicationAction.getLog().getLines().toArray());
		
	}

	@Override
	public void onError(Agent paramAgent,ReplicationAction paramReplicationAction, Exception paramException) {
		logger.info("------------------ ON ERROR------------------");
		logger.info("Agent Used:"+paramAgent.getId());
		logger.info(""+paramReplicationAction.getPath());
		logger.info(""+paramReplicationAction.getLog().getLines().toArray());
		
	}

}
