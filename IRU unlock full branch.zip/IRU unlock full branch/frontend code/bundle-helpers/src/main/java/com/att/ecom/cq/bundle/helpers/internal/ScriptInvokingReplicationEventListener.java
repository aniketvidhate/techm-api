package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.util.Collections;
import java.util.Dictionary;
import java.util.regex.Pattern;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.ConfigurationPolicy;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.ReplicationAction;
import com.day.cq.replication.ReplicationActionType;

/**
 * Replication listener which invokes an arbitrary script following an activate event. The substitution pattern ${path}
 * will be replaced in the command line.
 */
@Component(configurationFactory = true, policy = ConfigurationPolicy.REQUIRE, metatype = true, label = "Script Invoking Replication Event Listener", description = "Replication Event Listener which invokes a command-line script after a successful activation")
@Service
@Property(name = "event.topics", value = ReplicationAction.EVENT_TOPIC, propertyPrivate = true)
public class ScriptInvokingReplicationEventListener implements EventHandler {

    /**
     * The blank string.
     */
    private static final String BLANK = "";

    /**
     * The error message when there's no command line configured.
     */
    private static final String ERROR_NO_COMMAND_LINE = "Must specify a command line configuration value";

    /**
     * Error message when the command line can't be executed.
     */
    private static final String ERROR_UNABLE_TO_EXECUTE = "Unable to execute command line";

    /**
     * Log message when the command line is being executed.
     */
    private static final String MSG_EXECUTING = "Executing command line {}.";

    /**
     * The OSGi configuration property containing the command line to execute.
     */
    @Property(label = "Command line to execute", description = "Command-line script to execute. Use ${path} where the path should be.")
    private static final String PROP_COMMAND_LINE = "command.line";

    /**
     * A pattern which is compared against the path being activated.
     */
    @Property(label = "Path Pattern", description = "Pattern which path must match to invoke the command-line script. Leave blank to process all path.")
    private static final String PROP_PATTERN = "pattern";

    /**
     * The path substitution variable.
     */
    private static final String VAR_PATH = "path";

    /**
     * The configured command line.
     */
    private String mCommandLine;

    /**
     * A logger
     */
    private final Logger mLogger = LoggerFactory.getLogger(this.getClass());

    /**
     * The compiled path pattern.
     */
    private Pattern mPathPattern;

    /**
     * Activate the component by reading configuration.
     * 
     * @param pCtx
     *            the OSGi Component Context
     */
    @SuppressWarnings("unused")
    private void activate(final ComponentContext pCtx) {
        final Dictionary<?, ?> props = pCtx.getProperties();
        this.mCommandLine = OsgiUtil.toString(props.get(PROP_COMMAND_LINE), null);
        if (this.mCommandLine == null) {
            throw new IllegalArgumentException(ERROR_NO_COMMAND_LINE);
        }

        final String patternString = OsgiUtil.toString(props.get(PROP_PATTERN), BLANK);
        if (StringUtils.isNotBlank(patternString)) {
            this.mPathPattern = Pattern.compile(patternString);
        }
    }

    /**
     * Event handler method.
     * 
     * @param pEvent
     *            the event
     */
    @Override
    public void handleEvent(final Event pEvent) {
        final ReplicationAction action = ReplicationAction.fromEvent(pEvent);
        if (action != null) {
            if (action.getType() == ReplicationActionType.ACTIVATE) {
                final String path = action.getPath();

                if (this.mPathPattern == null || this.mPathPattern.matcher(path).matches()) {
                    final CommandLine cmdLine = CommandLine.parse(this.mCommandLine,
                            Collections.singletonMap(VAR_PATH, path));
                    this.mLogger.info(MSG_EXECUTING, cmdLine);
                    final DefaultExecutor exec = new DefaultExecutor();
                    try {
                        exec.execute(cmdLine);
                    } catch (ExecuteException e) {
                        this.mLogger.error(ERROR_UNABLE_TO_EXECUTE, e);
                    } catch (IOException e) {
                        this.mLogger.error(ERROR_UNABLE_TO_EXECUTE, e);
                    }
                }
            }
        }

    }

}
