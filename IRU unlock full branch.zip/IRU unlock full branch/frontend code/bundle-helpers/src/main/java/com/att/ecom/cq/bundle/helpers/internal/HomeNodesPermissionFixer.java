package com.att.ecom.cq.bundle.helpers.internal;

import javax.jcr.Session;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Scheduled job which occasionally will verify that User and Group nodes have the minimal ACLs configured for
 * CQ to work normally.
 *
 //commenting for performance issues.
@Component
@Service
@Properties({ @Property(name = "scheduler.period", longValue = 600), @Property(name = "scheduler.concurrent", boolValue = false) })

*/
public class HomeNodesPermissionFixer implements Runnable {

    /**
     * The root home path for groups.
     */
    private static final String HOME_GROUPS = "/home/groups";

    /**
     * The root home path for users.
     */
    private static final String HOME_USERS = "/home/users";

    /**
	 * A logger
	 */
	private final Logger mLogger = LoggerFactory.getLogger(this.getClass());

	/**
     * The JCR Repository
     */
	@Reference
	private SlingRepository mSlingRepository;
	
	/**
	 * Activate this component; run the process on activation.
	 */
	@Activate
	protected void activate() {
		//commenting this out as per RM's request for performance issues
		//run();
	}

	/**
	 * The actual process implementation.
	 */
	@Override
	public void run() {
	    if (this.mSlingRepository != null) {
    		this.mLogger.debug("Starting home nodes permission fixing");
    		Session session = null;
    		try {
    			session = mSlingRepository.loginAdministrative(null);
    
    			session.getNode(HOME_USERS).accept(new UserFixer(this.mLogger));
    
    			session.getNode(HOME_GROUPS).accept(new GroupFixer(this.mLogger));
    
    		} catch (Exception e) {
    			this.mLogger.error("Exception in user node permission fixing", e);
    		} finally {
    			if (session != null) {
    				session.logout();
    			}
    		}
    		mLogger.debug("Done with home nodes permission fixing");
	    }
	}

}
