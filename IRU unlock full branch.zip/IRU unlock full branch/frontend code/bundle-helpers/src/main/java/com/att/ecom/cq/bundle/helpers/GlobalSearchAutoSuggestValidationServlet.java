package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Servlet to Update content of globalsearch_AutoSuggest.xml to CQ Repository.
 * @author Hemant Arora (ha061x)
 * @created on November 2013
 * This updates admin boost values
 */

@SlingServlet(paths = "/system/att/cms/internaltools/autosuggest/validate")

public class GlobalSearchAutoSuggestValidationServlet extends SlingAllMethodsServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String JCR_PATH="/content/att/cmsfeed/globalsearch";
	private static final String NODE_AUTO_SUGGEST_AUTOMATION ="autosuggest";
	private static final String PAGE_RESOURCE_TYPE="cq:Page";
	private static final String ATTR_USER_QUERY="userQuery";
	private static final String ATTR_COLLECTION="collection";
	//private static final String ATTR_ADMIN_BOOST="adminBoost";//field element attribute in xml
	private static final String JCR_CONTENT ="jcr:content";
	private static final String NODE_AUTOSUGGEST ="autosuggest";

	private Logger logger = LoggerFactory.getLogger(GlobalSearchAutoSuggestValidationServlet.class);

	@Reference
	private SlingRepository slingRepository;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,	IOException 
	{	
		logger.error("calling validation servlet=="+request.getParameter(ATTR_USER_QUERY));
		javax.jcr.Node rootNode=null;
		String output="";
		String existingVal="";
		response.setStatus(response.SC_OK);		
		response.setCharacterEncoding("US-ASCII");
		response.setContentType("text/html");
		Writer out = response.getWriter();

		if(request.getParameter(ATTR_USER_QUERY)!=null || request.getParameter(ATTR_USER_QUERY)!=""){
			try 
			{
				String userQuery="";
				Session session = request.getResourceResolver().adaptTo(Session.class);
				rootNode =(javax.jcr.Node) session.getItem(JCR_PATH);

				if(null!=rootNode && rootNode.hasNode(NODE_AUTO_SUGGEST_AUTOMATION)){
					// //logger.error("rootnode already exists") ;

					rootNode=(javax.jcr.Node) session.getItem(JCR_PATH+"/"+NODE_AUTO_SUGGEST_AUTOMATION);
					////logger.error("get node==="+rootNode);

					NodeIterator childNodes= rootNode.getNodes();
					for (NodeIterator ni = childNodes; ni.hasNext();) {
						javax.jcr.Node childNode = ni.nextNode();
						if(childNode.getProperty("jcr:primaryType").getString().equalsIgnoreCase(PAGE_RESOURCE_TYPE)){
							////logger.error("inside if get child node property"+childNode.getName()+"===depth=="+childNode.getDepth());
							if(childNode.hasNode(JCR_CONTENT)){
								javax.jcr.Node jcrContentNode=childNode.getNode(JCR_CONTENT);
								if(jcrContentNode.hasNode(NODE_AUTOSUGGEST)){
									//javax.jcr.Node mainparNode=jcrContentNode.getNode(NODE_MAINPAR);
									if(jcrContentNode.hasNode(NODE_AUTOSUGGEST)){
										javax.jcr.Node autoSuggestnode=jcrContentNode.getNode(NODE_AUTOSUGGEST);
										existingVal=autoSuggestnode.getProperty(ATTR_USER_QUERY).getString()+"_"+autoSuggestnode.getProperty(ATTR_COLLECTION).getString();
										//logger.error("EXISTING VAL=="+existingVal);
										if(existingVal.equalsIgnoreCase(request.getParameter(ATTR_USER_QUERY))){
											//logger.error("node exists");
											output="1";
											break;
										}else{
											//logger.error("inside else");
											output="0";
										}
									}
								}
							}
						}
					}
				}
				//logger.error("create child nodes and set properties");
			}
			catch (RepositoryException e)  
			{
				logger.error(e.getMessage());
				output +="RepositoryException Error:<br>"+e.getMessage();
				//output +=e.getMessage();
			}

			catch (Exception e) 
			{
				logger.error(e.getMessage());
				output +="Error:<br>"+e.getMessage();
				//output +=e.getMessage();
			}
			out.write(output);

		}else{
			//logger.error("param not found");
			output="0";
			out.write(output);
		}

	}

	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}