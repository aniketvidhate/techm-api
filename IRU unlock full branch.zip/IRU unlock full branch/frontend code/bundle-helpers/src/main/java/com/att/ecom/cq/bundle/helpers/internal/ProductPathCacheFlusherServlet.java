package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;

import javax.jcr.RepositoryException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;

import com.att.ecom.cq.bundle.helpers.ProductPathResolver;

/**
 * Servlet which allows the product path cache to be manually flushed.
 */
@SuppressWarnings("serial")
@SlingServlet(paths = "/bin/cacheflush/productpaths", generateComponent = false)
@Component()
public class ProductPathCacheFlusherServlet extends SlingAllMethodsServlet {

    /**
     * The userid of the admin user
     */
    private static final String USER_ADMIN = "admin";
    
    /**
     * The path resolver.
     */
	@Reference
	private ProductPathResolver productPathResolver;

	/**
	 * Handle a post request.
	 */
	@Override
	protected void doPost(final SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse) throws ServletException, IOException {
		String userId = pRequest.getResourceResolver().getUserID();
		if (USER_ADMIN.equals(userId)) {
			try {
				productPathResolver.reloadMaps();
				pResponse.getWriter().println("cache flushed");
			} catch (RepositoryException e) {
				throw new ServletException(e);
			}
		} else {
			pResponse.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE);
		}
	}

}
