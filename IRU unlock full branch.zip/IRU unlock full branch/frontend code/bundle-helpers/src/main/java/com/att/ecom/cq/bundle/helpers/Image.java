/*
 *Author: Jon Ito
 *Pulled from /libs/foundation/src/impl/src/main/java/com/day/cq/wcm/foundation/Image.java
 *updated for AT&T
 */

package com.att.ecom.cq.bundle.helpers;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;


import com.day.cq.commons.ImageResource;
import com.day.cq.wcm.api.components.DropTarget;
import com.day.cq.wcm.api.components.Component;
import com.day.cq.wcm.api.designer.Style;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.Rendition;
import com.day.cq.wcm.commons.WCMUtils;
import com.day.cq.wcm.foundation.ImageMap;
import com.day.cq.wcm.foundation.WCMRenditionPicker;
import com.day.text.Text;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Provides convenience methods for displaying images.
 */
public class Image extends ImageResource {
    
    /**
     * A logger.
     */
    private final Logger log = LoggerFactory.getLogger(Image.class);
    
    /**
     * name of the image map property
     */
    public static final String PN_IMAGE_MAP = "imageMap";

    /**
     * id of the image map
     */
    private String imageMapId;

    /**
     * deserialized image map
     */
    private ImageMap imageMap;

    /**
     * flag controlling if a placeholder image should be rendered if this image
     * has no content.
     */
    private boolean noPlaceholder;
    
    private ResourceResolver rr;

    /**
     * Creates a new image based on the given resource. the image properties are
     * considered to 'on' the given resource.
     *
     * @param resource resource of the image
     * @throws IllegalArgumentException if the given resource is not adaptable to node.
     */
    public Image(Resource resource) {
        super(resource);
        this.rr = resource.getResourceResolver();
        // init default params
        imageMap = null;
        if (properties.containsKey(PN_IMAGE_MAP)) {
            try {
                String mapDefinition = properties.get(PN_IMAGE_MAP, "");
                if (mapDefinition.length() > 0) {
                    imageMap = ImageMap.fromString(mapDefinition);
                    imageMapId = "map_"
                            + Math.round(Math.random() * Integer.MAX_VALUE) + "_"
                            + System.currentTimeMillis();
                }
            } catch (IllegalArgumentException iae) {
                // ignore wrong map definition
                imageMap = null;
                imageMapId = null;
            }
        }
    }

    /**
     * Creates a new image based on the given resource. the image properties are
     * considered to 'on' the given resource unless <code>imageName</code>
     * is specified. then the respective child resource holds the image
     * properties.
     *
     * @param resource  current resource
     * @param imageName name of the image resource
     * @throws IllegalArgumentException if the given resource is not adaptable to node.
     */
    public Image(Resource resource, String imageName) {
        this(getRelativeResource(resource, imageName));
    }

    /**
     * Sets the drop target id for this image. the id is added as css class
     * to the image attribute. and has the format:
     * "{@value DropTarget#CSS_CLASS_PREFIX}{id}-{classifier}"
     *
     * @param id the drop target id as configured in edit config.
     * @param classifier optional classifier
     */
    public void setDropTargetId(String id, String classifier) {
        if (classifier == null) {
            classifier = "";
        }
        if (!classifier.startsWith("-")) {
            classifier = "-" + classifier;
        }
        addCssClass(DropTarget.CSS_CLASS_PREFIX + id + classifier);
    }

    /**
     *
     * Sets the drop target id for this image, using the name of the resources
     * as path.
     *
     * @param id the drop target id as configured in edit config.
     */
    public void setDropTargetId(String id) {
        String classifier = ResourceUtil.isNonExistingResource(this)
                ? String.valueOf(System.currentTimeMillis())
                : Text.getName(getPath());
        setDropTargetId(id, classifier);
    }

    /**
     * Returns the placeholder flag.
     * @return <code>true</code> if no placeholder for empty content should be
     *         drawn.
     */
    public boolean hasNoPlaceholder() {
        return noPlaceholder;
    }

    /**
     * Sets the placeholder flag.
     * @param noPlaceholder if <code>true</code> no placeholder for empty content
     *        is used.
     */
    public void setNoPlaceholder(boolean noPlaceholder) {
        this.noPlaceholder = noPlaceholder;
    }

    /**
     * Loads several definitions from style.
     * <p>
     * Currently, the minimum/maximum width and height are transferred from the given style.
     *
     * @param style style to load definitions from
     */
    public void loadStyleData(Style style) {
        // load additional definitions from style
        if (style != null) {
            this.set(Image.PN_MIN_WIDTH, style.get("minWidth", ""));
            this.set(Image.PN_MIN_HEIGHT, style.get("minHeight", ""));
            this.set(Image.PN_MAX_WIDTH, style.get("maxWidth", ""));
            this.set(Image.PN_MAX_HEIGHT, style.get("maxHeight", ""));
        }
    }

    /**
     * {@inheritDoc}
     *
     * @return <code>true</code> if {@link #hasNoPlaceholder()} is <code>false</code>
     *         or the image has content.
     */
    @Override
    protected boolean canDraw() {
        //return !noPlaceholder || hasContent();
        return true;
    }

    @Override
    protected Map<String, String> getImageTagAttributes() {
        /*
        String src = null;
        
        if (!hasContent()) {
            src = "/etc/designs/default/0.gif";
            addCssClass("cq-image-placeholder");
        }
        */
        
        Map<String, String> attributes = new HashMap<String, String>();
        if (get(getItemName(PN_HTML_WIDTH)).length() > 0) {
            attributes.put("width", get(getItemName(PN_HTML_WIDTH)));
        }
        if (get(getItemName(PN_HTML_HEIGHT)).length() > 0) {
            attributes.put("height", get(getItemName(PN_HTML_HEIGHT)));
        }
        // changed from getSrc() - gives the component path rendered image
        // need the path in the DAM
        String src = getFileReference();
        if (src != null) {
            String q = getQuery();
            if (q == null) {
                q = "";
            }
            attributes.put("src", Text.escape(src, '%', true) + q);
        }
        attributes.put("alt", getAlt());
        //tried to remove title attribute, but is overridden by parent class
        if (getTitle() != null && !getTitle().equals("")) {
            attributes.put("title", getTitle());
        }

        if (attrs != null) {
            attributes.putAll(attrs);
        }
        if (src != null) {
            attributes.put("src", src);
        }
        if (imageMap != null) {
            attributes.put("usemap", "#" + imageMapId);
        }
        return attributes;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void doDraw(PrintWriter w)  {
        /*
        super.doDraw(w);
        if (imageMap != null) {
            w.print(imageMap.draw(imageMapId));
        }
        */
        Map<String, String> attributes = getImageTagAttributes();
        String linkURL = get(PN_LINK_URL);
        if (linkURL.length() > 0) {
            w.printf("<a href=\"%s\">", this.rr.map(linkURL));
        }
        w.print("<img ");
        for (Map.Entry e : attributes.entrySet()) {
            Object value = e.getValue();
            w.printf("%s=\"%s\" ",
                    StringEscapeUtils.escapeHtml(e.getKey().toString()),
                    StringEscapeUtils.escapeHtml(value != null ? value.toString() : ""));
        }
        //if (doctype.isXHTML()) {
        //    w.print("/>");
        //} else {
            w.print(">");
        //}

        if (linkURL.length() > 0) {
            w.print("</a>");
        }
        if (imageMap != null) {
            w.print(imageMap.draw(imageMapId));
        }
    }

    /**
     * {@inheritDoc}
     *
     * Checks if the component of the resource provides an icon for the
     * respective type.
     */
    @Override
    public String getIconPath() {
        // Note: copied from Download.java, since we cannot extend from 2 classes.
        //       whenever you change this, also update the copy in Download.java
        Component c = WCMUtils.getComponent(this);
        if (c == null) {
            return null;
        }
        Resource icon = c.getLocalResource("resources/" + getIconType() + ".gif");
        if (icon == null) {
            icon = c.getLocalResource("resources/default.gif");
        }
        return icon == null ? null : icon.getPath();
    }


    /**
     * {@inheritDoc}
     *
     * Checks if the resource is an asset and returns the correct rendition.
     */
    @Override
    protected Resource getReferencedResource(String path) {
        // Note: copied from Download.java, since we cannot extend from 2 classes.
        //       whenever you change this, also update the copy in Download.java
        Resource res = super.getReferencedResource(path);
        if (res != null) {
            // check for asset
            if (res.adaptTo(Asset.class) != null) {
                final Rendition rendition = res.adaptTo(Asset.class).getRendition(new WCMRenditionPicker());
                res = (null != rendition) ? rendition.adaptTo(Resource.class) : null;
            }
        }
        return res;
    }

    /**
     * {@inheritDoc}
     *
     * Checks if the resource is an asset and returns the correct rendition.
     */
    @Override    
    public boolean hasContent() {
        return getFileReference() != null && !"".equals(getFileReference());
    }
}