/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;


/**
 * This is a response for a thread JCRCompareCallable.
 * 
 * @author Sunil Reddy Aleti
 * @since 19th January 2013
 */
public class JCRCompareResponse {

    private String mResponseKey = null;
    
    private String mResponseValue = null;

    private DetailedResponse mDetailedResponse = null;
    
    protected class DetailedResponse{
        private String mHostName = null;
        private String mResult = null;
        private long mNumOfDifferences = 0;
        private long mNumOfPagesAffectedDueToDiff = 0;
        private long mNumOfExtraNodesOnTarget = 0;
        private long mNumOfPagesAffectedDueToExtra = 0;
        private String mBackgroundColor = "";
        /**
         * @return the hostName
         */
        public String getHostName() {
            return mHostName;
        }
        /**
         * @param pHostName the hostName to set
         */
        public void setHostName(String pHostName) {
            mHostName = pHostName;
        }
        /**
         * @return the result
         */
        public String getResult() {
            return mResult;
        }
        /**
         * @param pResult the result to set
         */
        public void setResult(String pResult) {
            mResult = pResult;
        }
        /**
         * @return the numOfDifferences
         */
        public long getNumOfDifferences() {
            return mNumOfDifferences;
        }
        /**
         * @param pNumOfDifferences the numOfDifferences to set
         */
        public void setNumOfDifferences(long pNumOfDifferences) {
            mNumOfDifferences = pNumOfDifferences;
        }

        /**
         * @return the numOfExtraNodesOnTarget
         */
        public long getNumOfExtraNodesOnTarget() {
            return mNumOfExtraNodesOnTarget;
        }
        /**
         * @param pNumOfExtraNodesOnTarget the numOfExtraNodesOnTarget to set
         */
        public void setNumOfExtraNodesOnTarget(long pNumOfExtraNodesOnTarget) {
            mNumOfExtraNodesOnTarget = pNumOfExtraNodesOnTarget;
        }
        /**
         * @return the backgroundColor
         */
        public String getBackgroundColor() {
            return mBackgroundColor;
        }
        /**
         * @param pBackgroundColor the backgroundColor to set
         */
        public void setBackgroundColor(String pBackgroundColor) {
            mBackgroundColor = pBackgroundColor;
        }
        /**
         * @return the numOfPagesAffectedDueToDiff
         */
        public long getNumOfPagesAffectedDueToDiff() {
            return mNumOfPagesAffectedDueToDiff;
        }
        /**
         * @param pNumOfPagesAffectedDueToDiff the numOfPagesAffectedDueToDiff to set
         */
        public void setNumOfPagesAffectedDueToDiff(long pNumOfPagesAffectedDueToDiff) {
            mNumOfPagesAffectedDueToDiff = pNumOfPagesAffectedDueToDiff;
        }
        /**
         * @return the numOfPagesAffectedDueToExtra
         */
        public long getNumOfPagesAffectedDueToExtra() {
            return mNumOfPagesAffectedDueToExtra;
        }
        /**
         * @param pNumOfPagesAffectedDueToExtra the numOfPagesAffectedDueToExtra to set
         */
        public void setNumOfPagesAffectedDueToExtra(long pNumOfPagesAffectedDueToExtra) {
            mNumOfPagesAffectedDueToExtra = pNumOfPagesAffectedDueToExtra;
        }
    }
    /**
     * @return the responseKey
     */
    public String getResponseKey() {
        return mResponseKey;
    }

    /**
     * @param pResponseKey the responseKey to set
     */
    public void setResponseKey(String pResponseKey) {
        mResponseKey = pResponseKey;
    }

    /**
     * @return the responseValue
     */
    public String getResponseValue() {
        return mResponseValue;
    }

    /**
     * @param pResponseValue the responseValue to set
     */
    public void setResponseValue(String pResponseValue) {
        mResponseValue = pResponseValue;
    }

    /**
     * @return the detailedResponse
     */
    public DetailedResponse getDetailedResponse() {
        if (mDetailedResponse == null) {
            mDetailedResponse = new DetailedResponse();
        }
        return mDetailedResponse;
    }

    /**
     * @param pDetailedResponse the detailedResponse to set
     */
    public void setDetailedResponse(DetailedResponse pDetailedResponse) {
        mDetailedResponse = pDetailedResponse;
    }
}
