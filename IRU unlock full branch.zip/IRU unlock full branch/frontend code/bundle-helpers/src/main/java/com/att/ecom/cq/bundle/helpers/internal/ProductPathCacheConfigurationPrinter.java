package com.att.ecom.cq.bundle.helpers.internal;

import java.io.PrintWriter;
import java.util.Map;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;

import com.att.ecom.cq.bundle.helpers.ProductPathResolver;

/**
 * Web Console configuration printer to output the current cache of product paths.
 */
@Component()
@Service(Object.class)
@Properties({ @Property(propertyPrivate = true, name = "felix.webconsole.label", value = "productpathcache"),
		@Property(propertyPrivate = true, name = "felix.webconsole.title", value = "Product Path Cache"),
		@Property(propertyPrivate = true, name = "felix.webconsole.configprinter.modes", value = "always") })
public class ProductPathCacheConfigurationPrinter {

    /**
     * The path resolver.
     */
	@Reference
	private ProductPathResolver mProductPathResolver;

	/**
	 * Print the paths to the console.
	 * 
	 * @param pWriter a writer.
	 */
	public void printConfiguration(final PrintWriter pWriter) {
	    final Map<String, Map<String, Map<String, String>>> data = this.mProductPathResolver.getData();
		if (data == null) {
			pWriter.println("No cached data available.");
		} else {
			for (final String language : data.keySet()) {
				pWriter.print("Language: ");
				pWriter.println(language);
				Map<String, Map<String, String>> langData = data.get(language);
				for (String type : langData.keySet()) {
					pWriter.print("    Type: ");
					pWriter.println(type);
					Map<String, String> typeData = langData.get(type);
					for (String sku : typeData.keySet()) {
						pWriter.print("        ");
						pWriter.print(sku);
						pWriter.print(" - ");
						pWriter.println(typeData.get(sku));
					}
				}
			}
		}
		
		
	}

}
