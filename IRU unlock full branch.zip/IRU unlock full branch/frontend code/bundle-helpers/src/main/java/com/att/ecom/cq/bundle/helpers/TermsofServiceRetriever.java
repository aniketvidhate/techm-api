/**
 * 
 */
package com.att.ecom.cq.bundle.helpers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;	

import javax.jcr.Node;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

/**
 * @author rx1755
 * Class to retrieve the current line of service 
 */
public class TermsofServiceRetriever {	
	
		private static final Logger log = LoggerFactory.getLogger(TermsofServiceRetriever.class);
		private static final String BASE_TOS_PATH = "/content/tos/";
		private static final String DEFAULT_TOS = "defaulttos";
		private static final String YEAR = "year";
		private static final String MONTH = "defaulttos";
		private static final String DAY = "DAY";
		private static final String VERSION = "version";
		private static final String DEFAULT = "default";
		
		private TermsofServiceRetriever() {
		}
	    
	    /**
	     * method to return current or latest tos url for a passed in tosname
	     * @param tosname
	     * @return tospath
	     */
    public static LinkedHashMap getTermsofServiceResourceUrl(List<String> toslist,ResourceResolver resourceResolver, String language){
	    	
	    	log.debug("The passed in list is now:"+toslist+":the language is:"+language);
	    	
	    	List<String> tosList = toslist;
		    if(tosList == null || tosList.size()==0){		      
		      tosList.add(DEFAULT_TOS);		      
		    }
		     
		      LinkedHashMap<String, String> tosResourceUrlMap = new LinkedHashMap();
		      for (String eachtos : tosList)  
		      {  
		    	  String eachresourcePath = getResourcePath(eachtos,resourceResolver,language);	
		    	  if(eachresourcePath==null){
		    		  eachresourcePath = getResourcePath(DEFAULT_TOS,resourceResolver,language);
		    	  }
		    	  tosResourceUrlMap.put(eachtos, eachresourcePath);
		      }
			
		      return tosResourceUrlMap;
	    }
    
    /**
     * method to return current or latest tos url for a passed in toskey
     * @param toskey
     * @return tospath
     */
    public static String getTermsofServiceResourcePath(String toskey,ResourceResolver resourceResolver, String language){
    	
		  log.debug("The passed in toskey is:"+toskey+":the language is:"+language);
	
		  String tosResourcePath = null;
		  if(toskey == null) {
			  tosResourcePath = getResourcePath(DEFAULT_TOS,resourceResolver,language);
		  }
		  else {
			  tosResourcePath = getResourcePath(toskey,resourceResolver,language);	
			  if(tosResourcePath==null){
	    		  tosResourcePath = getResourcePath(DEFAULT_TOS,resourceResolver,language);
	    	  }
		  }    	  
	   
	   return tosResourcePath;
    }
	    
	    
	    /**
	     * get each passed in tos resource path
	     * @param tosname
	     * @return resourcePath
	     */
	    public static String getResourcePath(String tosname,ResourceResolver resourceResolver, String language){
	    	
	    	Calendar cal = Calendar.getInstance();
		    int day = cal.get(Calendar.DATE);
		    int month = cal.get(Calendar.MONTH) + 1;
		    int year = cal.get(Calendar.YEAR);
		    int dow = cal.get(Calendar.DAY_OF_WEEK);
		    int dom = cal.get(Calendar.DAY_OF_MONTH);		        
		    
		    String monthstring = Integer.toString(month);
	    	 if(month<10) {
		         monthstring = "0"+month;
		     }
	    	
	    	String lang = language!=null?language:"en";
		    log.debug("The Day:"+day+":month:"+month+":year:"+year+":dow:"+dow+":dom:"+dom);
		    String path = BASE_TOS_PATH+lang+"/"+tosname;
		    log.debug("The initial path :"+path);		  
		 
		    Resource tospageresource = resourceResolver.getResource(path);	 
		    if(tospageresource==null){
				return null;
			}
			
			log.debug("The Root resource:"+tospageresource);
		    
		    Resource yearresource = getDescOrderResource(tospageresource , year , DEFAULT);
	        
		    Resource versionresource = null;
		    String versionresourcepath = null;
		    
		    if(yearresource!=null){	
		    	Resource monthresource = getDescOrderResource(yearresource , Integer.parseInt(monthstring) , DEFAULT);
		    	 
		    	if(monthresource !=null){		    		
		    		Resource dayresource = null;
		    		if(monthresource.getName().equals(monthstring))
		    			dayresource = getDescOrderResource(monthresource , dom , DAY);
		    		else 
		    			dayresource = getDescOrderResource(monthresource , dom , DEFAULT);
		    		if(dayresource !=null ){		    			
		    			versionresource = getDescOrderResource(dayresource , -1 , DEFAULT);		    			 
		    		}
		    	}
		    }
		    
		    log.debug("The returning TOS resource path is :"+tospageresource.getPath());
		    if(versionresource!=null) {
		    	versionresourcepath = versionresource.getPath();
		    } 
		    
		    return versionresourcepath;
	    }
	    
	    /**
	     * method returning the Descending ordered Page
	     * @param page
	     * @return latest page
	     */
	    public static Page getDescOrderPage(Page page , int currentnum){	    	
	    	ArrayList<Page> pagelist = new ArrayList<Page>();
		    for (Iterator<Page> jcrcontent = page.listChildren(); jcrcontent.hasNext();) {             
		          Page pg = jcrcontent.next();	
		          int pagenum = Integer.parseInt(pg.getName());		          
		          if(currentnum < 0 || pagenum <= currentnum) {
		        	  log.debug("Adding page :"+pg.getName());
		        	  pagelist.add(pg);		
		          }
		      }		    
			if(pagelist.size()>0){
			   Collections.sort(pagelist, new CompareLength());
			   Collections.reverse(pagelist);			  
			   return pagelist.get(0);
			 } 
			return null;
	    }
	    
	    /**
	     * method returning the Descending ordered Resource
	     * @param resource
	     * @return latest resource
	     */
	    public static Resource getDescOrderResource(Resource resource , int currentnum , String stg){	    	
	    	ArrayList<Resource> resourcelist = new ArrayList<Resource>();
	    	
		    for (Iterator<Resource> jcrcontent = resource.listChildren(); jcrcontent.hasNext();) {             
		    	  Resource rs = jcrcontent.next();	
		    	  if(!rs.getName().equals("jcr:content")){
			          int resourcenum = Integer.parseInt(rs.getName());        
			          log.debug("Adding in resource :"+rs.getName());
			          resourcelist.add(rs);				          
		    	  }
		      }		    
			if(resourcelist.size()>0){
			   Collections.sort(resourcelist, new CompareLength());
			   Collections.reverse(resourcelist);			  
			   return resourcelist.get(0);
			 } 
			return null;
	    }
	    
	    
}
