package com.att.ecom.cq.bundle.helpers.internal;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Arrays; 
import java.util.ArrayList; 

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventConstants;
import org.osgi.service.event.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.SlingConstants;

import com.att.ecom.cq.bundle.helpers.ProductPathResolver;

/**
 * Event listener which rebuilds the product path cache on any content change.
 */
@Component
@Service
@Properties({ @Property(name = EventConstants.EVENT_TOPIC, value = "org/apache/sling/api/resource/Resource/ADDED"),
		@Property(name = EventConstants.EVENT_FILTER, value = "(path=/content/att/*)") })
public class ProductPathCacheFlusherEventListener implements EventHandler {
	
	/**
	 * list of content types to be flushed for 
	 */
	ArrayList contentFlushResources = new ArrayList(Arrays.asList(
										"att/wireless/components/page/details/devicedetails",
										"att/wireless/components/page/details/plandetails",
										"att/wireless/components/page/details/servicedetails",
										"att/wireless/components/page/details/accessorydetails",
										"att/wireless/components/page/details/packagedetails"));

    /**
     * The actual rebuilding process.
     *
     */
	static class Flusher implements Runnable {
		
	    /** A logger. */
		private final Logger mLogger;
		
		/** The path resolver. */
		private final ProductPathResolver mProductPathResolver;

		/**
		 * Construct a new instance
		 * 
		 * @param pProductPathResolver the resolver
		 * @param pLogger the logger
		 */
		public Flusher(final ProductPathResolver pProductPathResolver, final Logger pLogger) {
			this.mProductPathResolver = pProductPathResolver;
			this.mLogger = pLogger;
		}
		
		/**
		 * Reload the path maps.
		 */
		@Override
		public void run() {
			try {	
				this.mProductPathResolver.reloadMaps();
				this.mLogger.debug("finished flushing cache");
			} catch (Exception e) {
			    this.mLogger.error("Unable to reload product path maps", e);
			}
		}
	}

	/**
	 * A logger.
	 */
	private Logger mLogger = LoggerFactory.getLogger(this.getClass());

	/**
	 * The path resolver.
	 */
	@Reference
	private ProductPathResolver mProductPathResolver;

	/**
	 * An execution queue to run the actual map reloading.
	 */
	private ExecutorService mQueue;

	/**
	 * Activate this component by setting up a new queue.
	 * @param pCtx
	 */
	protected void activate(final ComponentContext pCtx) {
		this.mQueue = Executors.newSingleThreadExecutor();
	}

	/**
	 * Deactivate this component by shutting down the queue.
	 * @param pCtx
	 */
	protected void deactivate(final ComponentContext pCtx) {
	    this.mQueue.shutdown();
	    this.mQueue = null;
	}

	/**
	 * On an event, add a flush execution to the queue.
	 */
	@Override
	public void handleEvent(final Event pEvent) {
		this.mLogger.debug("resource change event received; flushing cache");
		this.mLogger.debug("the event Topic  is:"+pEvent.getTopic());
		
		if(contentFlushResources.contains(pEvent.getProperty(SlingConstants.PROPERTY_RESOURCE_TYPE))){
			this.mLogger.debug("Its DETAILS Page:"+pEvent.getProperty(SlingConstants.PROPERTY_RESOURCE_TYPE));
			this.mQueue.submit(new Flusher(this.mProductPathResolver, this.mLogger));			
		}
		
	}

}
