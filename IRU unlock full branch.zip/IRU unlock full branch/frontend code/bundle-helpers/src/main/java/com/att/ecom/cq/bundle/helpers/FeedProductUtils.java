package com.att.ecom.cq.bundle.helpers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.ItemExistsException;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.nodetype.NoSuchNodeTypeException;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.jcr.version.VersionException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.api.SlingRepository;

import org.osgi.service.component.ComponentContext;

@Component(immediate=true)
@Service(value=FeedProductUtils.class)
public class FeedProductUtils {
	
	@Reference
	public SlingRepository slingRepository;
	
	private static FeedProductUtils feedutils;
	
	public static SlingRepository getSlingRepository() {
		if (feedutils == null) {
			feedutils = new FeedProductUtils();
		}
		return feedutils.slingRepository;
	}
	
	private static final String NO = "N";
	private static final String YES = "Y";
	private static final String JCR_CONTENT = "jcr:content";
	private static final String JCR_CONTENT_DEVICEPAR = "/jcr:content/devicepar";
	private static final String HTML_FILE_EXTENSION = ".html";
	private static final String FEED_LANGUAGE = "en";
	private static final String PROP_PATH = "path";
	private static final String CATEGORY_HEADER_NODE = "categoryheader";
	private static final String DIMENSIONS = "dimensions";
	private static final String TAXO_PROP_VAL_PREFIX = "taxo";
	private static final String PROP_DISPLAY_TEXT = "displayText";
	private static final String PROP_OPTION_VALUE = "optionValue";
	private static final String NODE_FILTER_OPTIONS = "filteroptions";
	private static final String PROP_VALUE_TAXO_STYLE = "taxoStyle";
	private static final String PROP_CAT_VALUE = "catvalue";
	private static final String MHZ = "mhz";
	private static final String WIRELESS_TECHNOLOGY = "wireless_technology";
	private static final String IN_USE_TIME = "in-use time";
	private static final String TALK_TIME = "talk time";
	private static final String ALL_NON_NUMBERS_REGEX = "[^0-9\\.]";
	private static final String ZERO = "0";
	private static final String HOURS_REGEX = "(\\d+\\.?\\d* hours)";
	private static final String DAYS_REGEX = "(\\d+\\.?\\d* days)";
	private static final String STANDBY_TIME = "Standby time";
	private static final String BATTERY_SPEC = "battery";
	private static final String DIM_WEIGHT = "Weight";
	private static final String NON_NUMBER_REGEX = "[^0-9\\.]+";
	private static final String PROP_VALUE = "value";
	private static final String DIM_SIZE = "Size";
	private static final String PROP_NAME = "name";
	private static final String LEFTSPECPAR_PATH = "jcr:content/devicetabs/leftspecpar";
	private static final String RIGHTSPECPAR_PATH = "jcr:content/devicetabs/rightspecpar";
	private static final String LIST_PATH = "/jcr:content/devicepar/list";
	private static final String SPEC_PATH = "/content/sharedcontent/en/portal/specs/";
	private static final String PAGES_PROPERTY = "pages";
	private static final String TRUE = "true";
	private static final String FEED_ENABLED = "feedEnabled";
	private static final String DEFAULT = "default";
	private static final String DISPLAY_AS = "displayAs";
	private static final String STATIC = "static";
	private static final String LIST_FROM = "listFrom";
	private static final String FOUNDATION_COMPONENTS_LIST = "foundation/components/list";
	private static final String LIST = "list";
	private static final String FOUNDATION_COMPONENTS_PARSYS = "foundation/components/parsys";
	private static final String SLING_RESOURCE_TYPE = "sling:resourceType";
	private static final String DEVICEPAR = "devicepar";
	private static final String NT_UNSTRUCTURED = "nt:unstructured";
	private static final String[] FILTER_PATHS = {"/content/att/shop/en/wireless/devices/cellphones/jcr:content/filterparsys",
		"/content/att/shop/en/wireless/accessories/accessorieslist/jcr:content",
								"/content/att/shop/en/wireless/plans/individualplans/jcr:content",
								"/content/att/shop/en/wireless/plans/familyplans/jcr:content",
								"/content/att/shop/en/wireless/plans/dataplans/jcr:content",
								"/content/att/shop/en/wireless/plans/mobilesharedata/jcr:content",
								"/content/att/shop/en/wireless/plans/mobileshare/jcr:content",
								"/content/att/shop/en/wireless/services/serviceslist/jcr:content",
								"/content/sharedcontent/filters/phoneFilters/jcr:content/individual",
								"/content/sharedcontent/filters/deviceFilters/jcr:content/individual",
								"/content/sharedcontent/filters/tabletFilters/jcr:content/individual",
								"/content/sharedcontent/filters/prepaidFilters/jcr:content/individual",
								"/content/sharedcontent/filters/pkgFilters/jcr:content/individual",};

	private static List<Node> taxonNodes;
	
	private static Session session;
	
	protected void activate(ComponentContext ctx) throws RepositoryException {
		session = slingRepository.login();
	}
	
	protected void deactivate(ComponentContext ctx) {
		session.logout();
	}
	
	public static void importContent(ResourceResolver pResourceResolver,
			String pSpec, String pSkuList, String pAppendToList)
			throws RepositoryException {

		if (pSpec != null && pSkuList != null) {

			Resource specResource = pResourceResolver
					.getResource(SPEC_PATH
							+ pSpec);
			List<String> skusPage = new ArrayList<String>();
			String[] skus = pSkuList.split(",");
			for (int i = 0; i < skus.length; i++) {
				String skuPath = PathHelpers.getDeviceDetailsPagePath(
						pResourceResolver, FEED_LANGUAGE, skus[i]);
				if (skuPath != null) {
					skuPath = (skuPath.lastIndexOf(HTML_FILE_EXTENSION) > 0) ? skuPath
							.substring(0,skuPath.lastIndexOf(HTML_FILE_EXTENSION)) : skuPath;
					skusPage.add(skuPath);
				}
			}

			if (specResource != null) {
				Resource deviceParResource = pResourceResolver
						.getResource(specResource.getPath()
								+ JCR_CONTENT_DEVICEPAR);
				if (deviceParResource != null) {
					Node devParNode = deviceParResource.adaptTo(Node.class);
					if (devParNode.hasNode(LIST)) {
						Node listNode = devParNode.getNode(LIST);
						setListNodePagesProperty(listNode, skusPage,
								pAppendToList);
					} else {
						Node listNode = createListNode(devParNode);
						setListNodePagesProperty(listNode, skusPage,
								pAppendToList);
					}
				} else {
					Node specNode = specResource.adaptTo(Node.class);
					Node contentNode = specNode.getNode(JCR_CONTENT);
					Node deviceParNode = createDeviceParNode(contentNode);
					Node listNode = createListNode(deviceParNode);
					setListNodePagesProperty(listNode, skusPage, pAppendToList);
				}
			}
		}
	}

	public static void appendSkus(List<String> pCurrentPages,
			List<String> pNewPages) {
		for (String path : pNewPages) {
			if (!pCurrentPages.contains(path)) {
				pCurrentPages.add(path);
			} else {
				int currentIndex = pCurrentPages.indexOf(path);
				pCurrentPages.remove(currentIndex);
				pCurrentPages.add(path);
			}
		}
	}

	public static Node createDeviceParNode(Node pContentNode)
			throws ItemExistsException, PathNotFoundException,
			NoSuchNodeTypeException, LockException, VersionException,
			ConstraintViolationException, RepositoryException {
		Node deviceparNode = pContentNode
				.addNode(DEVICEPAR, NT_UNSTRUCTURED);
		deviceparNode.setProperty(SLING_RESOURCE_TYPE,
				FOUNDATION_COMPONENTS_PARSYS);

		return deviceparNode;
	}

	public static Node createListNode(Node pDeviceParNode)
			throws ItemExistsException, PathNotFoundException,
			NoSuchNodeTypeException, LockException, VersionException,
			ConstraintViolationException, RepositoryException {
		Node listNode = pDeviceParNode.addNode(LIST, NT_UNSTRUCTURED);
		listNode.setProperty(SLING_RESOURCE_TYPE, FOUNDATION_COMPONENTS_LIST);
		listNode.setProperty(LIST_FROM, STATIC);
		listNode.setProperty(DISPLAY_AS, DEFAULT);
		listNode.setProperty(FEED_ENABLED, TRUE);

		return listNode;
	}

	public static List<String> valueArrayToList(Value[] pValues)
			throws RepositoryException {
		List<String> valueList = new ArrayList<String>();

		for (int i = 0; i < pValues.length; i++) {
			valueList.add(pValues[i].getString());
		}

		return valueList;
	}

	public static void setListNodePagesProperty(Node pListNode,
			List<String> pNewPages, String pAppendToList)
			throws PathNotFoundException, RepositoryException {
		if (YES.equalsIgnoreCase(pAppendToList)) {
			Property devicePages = pListNode.getProperty(PAGES_PROPERTY);
			Value[] pages = devicePages.getValues();
			List<String> existingPages = valueArrayToList(pages);
			FeedProductUtils.appendSkus(existingPages, pNewPages);
			pListNode.setProperty(PAGES_PROPERTY, existingPages.toArray(new String[0]));
		} else {
			pListNode.setProperty(PAGES_PROPERTY, pNewPages.toArray(new String[0]));
		}
	}
	
	public static String hasSpec(ResourceResolver pResourceResolver, String pSpec, String pDevicePath ) throws RepositoryException {
		
		Resource listResource = pResourceResolver.getResource(SPEC_PATH + pSpec + LIST_PATH);
		if (listResource != null) {
			Node listNode = listResource.adaptTo(Node.class);
			Property pagesProp = listNode.getProperty(PAGES_PROPERTY);
			Value[] values = pagesProp.getValues();
			for(int i=0; i<values.length; i++) {
				String path = values[i].getString();
				if(path.equalsIgnoreCase(pDevicePath)) {
					return YES;
				}
			}
		}
		
		return NO;
	}
	
	public static String getDimensions(ResourceResolver pResourceResolver, String pDevicePath) throws PathNotFoundException, RepositoryException {
		
		Resource deviceResource = pResourceResolver.getResource(pDevicePath);
		
		Node deviceNode = deviceResource.adaptTo(Node.class);
		Node rightSpecPar = null;
		Node leftSpecPar = null;
		if (deviceNode.hasNode(RIGHTSPECPAR_PATH)) {
			rightSpecPar = deviceNode.getNode(RIGHTSPECPAR_PATH);
		}
		if (deviceNode.hasNode(LEFTSPECPAR_PATH)) {
			leftSpecPar = deviceNode.getNode(LEFTSPECPAR_PATH);
		}
		
		if (rightSpecPar != null || leftSpecPar != null) {
			List<Node> dimensionNodes = getDimensionNodes(pResourceResolver, rightSpecPar);
			dimensionNodes.addAll(getDimensionNodes(pResourceResolver, leftSpecPar));
			
			for(Node dimNode : dimensionNodes) {
				if (dimNode.getProperty(PROP_NAME).getString().startsWith(DIM_SIZE)) {
					return dimNode.getProperty(PROP_VALUE).getString();
				}
			}
		}
		
		return "";
	}
	
	public static BigDecimal getWeight(ResourceResolver pResourceResolver, String pDevicePath) throws PathNotFoundException, RepositoryException {
		Resource deviceResource = pResourceResolver.getResource(pDevicePath);
		
		Node deviceNode = deviceResource.adaptTo(Node.class);
		
		Node rightSpecPar = null;
		Node leftSpecPar = null;
		if (deviceNode.hasNode(RIGHTSPECPAR_PATH)) {
			rightSpecPar = deviceNode.getNode(RIGHTSPECPAR_PATH);
		}
		if (deviceNode.hasNode(LEFTSPECPAR_PATH)) {
			leftSpecPar = deviceNode.getNode(LEFTSPECPAR_PATH);
		}
		
		if (rightSpecPar != null || leftSpecPar != null) {
			List<Node> dimensionNodes = getDimensionNodes(pResourceResolver, rightSpecPar);
			dimensionNodes.addAll(getDimensionNodes(pResourceResolver, leftSpecPar));
			
			for(Node dimNode : dimensionNodes) {
				if (dimNode.hasProperty(PROP_NAME) && dimNode.getProperty(PROP_NAME).getString().startsWith(DIM_WEIGHT)) {
					String weight = dimNode.getProperty(PROP_VALUE).getString();
					weight = weight.toLowerCase().replaceAll(NON_NUMBER_REGEX, "").trim();
					return BigDecimal.valueOf(Double.parseDouble(weight));
				}
			}
		}
		return BigDecimal.valueOf(-1.0);
	}
	
	public static BigDecimal getStandByTime(ResourceResolver pResourceResolver, String pDevicePath) throws PathNotFoundException, RepositoryException {
		Resource deviceResource = pResourceResolver.getResource(pDevicePath);
		
		Node deviceNode = deviceResource.adaptTo(Node.class);
		Node rightSpecPar = null;
		Node leftSpecPar = null;
		if (deviceNode.hasNode(RIGHTSPECPAR_PATH)) {
			rightSpecPar = deviceNode.getNode(RIGHTSPECPAR_PATH);
		}
		if (deviceNode.hasNode(LEFTSPECPAR_PATH)) {
			leftSpecPar = deviceNode.getNode(LEFTSPECPAR_PATH);
		}
		
		if (rightSpecPar != null || leftSpecPar != null) {
			List<Node> nodes = getNodes(pResourceResolver, rightSpecPar, BATTERY_SPEC);
			nodes.addAll(getNodes(pResourceResolver, leftSpecPar, BATTERY_SPEC));
			
			for(Node node : nodes) {
				if (node.hasProperty(PROP_NAME) && node.getProperty(PROP_NAME).getString().startsWith(STANDBY_TIME)) {
					
					Pattern dayRegex = Pattern.compile(DAYS_REGEX);
					Pattern hoursRegex = Pattern.compile(HOURS_REGEX);
					String value = node.getProperty(PROP_VALUE).getString().toLowerCase().trim();
					String days = ZERO;
					String hours = ZERO;
					
					Matcher dayMatcher = dayRegex.matcher(value);
					if(dayMatcher.find()) {
						days = dayMatcher.group().replaceAll(ALL_NON_NUMBERS_REGEX, "");
					}
					
					Matcher hoursMatcher = hoursRegex.matcher(value);
					if(hoursMatcher.find()) {
						hours = hoursMatcher.group().replaceAll(ALL_NON_NUMBERS_REGEX, "");
					}
					
					double standByTime = (Double.parseDouble(days)*24) + Integer.parseInt(hours);
					
					return BigDecimal.valueOf(Math.round(standByTime));
				}
			}
		}
		return BigDecimal.valueOf(-1.0);
	}
	
	public static BigDecimal getTalkTime(ResourceResolver pResourceResolver, String pDevicePath) throws PathNotFoundException, RepositoryException {
		Resource deviceResource = pResourceResolver.getResource(pDevicePath);
		
		Node deviceNode = deviceResource.adaptTo(Node.class);
		
		Node rightSpecPar = null;
		Node leftSpecPar = null;
		if (deviceNode.hasNode(RIGHTSPECPAR_PATH)) {
			rightSpecPar = deviceNode.getNode(RIGHTSPECPAR_PATH);
		}
		if (deviceNode.hasNode(LEFTSPECPAR_PATH)) {
			leftSpecPar = deviceNode.getNode(LEFTSPECPAR_PATH);
		}
		
		if (rightSpecPar != null || leftSpecPar != null) {
			List<Node> nodes = getNodes(pResourceResolver, rightSpecPar, BATTERY_SPEC);
			nodes.addAll(getNodes(pResourceResolver, leftSpecPar, "batter"));
			
			for(Node node : nodes) {
				if (node.hasProperty(PROP_NAME) && 
						(node.getProperty(PROP_NAME).getString().toLowerCase().startsWith(TALK_TIME)
						|| node.getProperty(PROP_NAME).getString().toLowerCase().startsWith(IN_USE_TIME))) {
					Pattern dayRegex = Pattern.compile(DAYS_REGEX);
					Pattern hoursRegex = Pattern.compile(HOURS_REGEX);
					String value = node.getProperty(PROP_VALUE).getString().toLowerCase().trim();
					String days = ZERO;
					String hours = ZERO;
					
					Matcher dayMatcher = dayRegex.matcher(value);
					if(dayMatcher.find()) {
						days = dayMatcher.group().replaceAll(ALL_NON_NUMBERS_REGEX, "");
					}
					
					Matcher hoursMatcher = hoursRegex.matcher(value);
					if(hoursMatcher.find()) {
						hours = hoursMatcher.group().replaceAll(ALL_NON_NUMBERS_REGEX, "");
					}
					
					double talkTime = ((Double.parseDouble(days)*24) + Double.parseDouble(hours));
					return BigDecimal.valueOf(Math.round(talkTime));
				}
			}
		}		
		return BigDecimal.valueOf(-1.0);
	}
	
	public static String getTechnologyFrequency(ResourceResolver pResourceResolver, String pDevicePath) throws PathNotFoundException, RepositoryException {
		
		Resource deviceResource = pResourceResolver.getResource(pDevicePath);
		
		Node deviceNode = deviceResource.adaptTo(Node.class);
		
		Node rightSpecPar = null;
		Node leftSpecPar = null;
		if (deviceNode.hasNode(RIGHTSPECPAR_PATH)) {
			rightSpecPar = deviceNode.getNode(RIGHTSPECPAR_PATH);
		}
		if (deviceNode.hasNode(LEFTSPECPAR_PATH)) {
			leftSpecPar = deviceNode.getNode(LEFTSPECPAR_PATH);
		}
		
		if (rightSpecPar != null || leftSpecPar != null) {
			List<Node> nodes = getNodes(pResourceResolver, rightSpecPar, WIRELESS_TECHNOLOGY);
			nodes.addAll(getNodes(pResourceResolver, leftSpecPar, WIRELESS_TECHNOLOGY));
			
			for(Node node : nodes) {
				if (node.hasProperty(PROP_VALUE) && node.getProperty(PROP_VALUE).getString().toLowerCase().trim().endsWith(MHZ)) {
					return node.getProperty(PROP_VALUE).getString();
				}
			}
		}		
		return "";
	}
	
	@SuppressWarnings("rawtypes")
	public static String getStyleIndicator(ResourceResolver pResourceResolver, List<String> pItemCategories, Map<String,String> pFeedCategories) throws RepositoryException {
		
		List<Node> taxonFilterNodes = getTaxonFilterNodes(pResourceResolver);
		for (String itemCategory : pItemCategories) {
			String displayName = pFeedCategories.get(itemCategory);
			for(Node taxonFilter : taxonFilterNodes) {
				if(taxonFilter.hasProperty(PROP_CAT_VALUE) && taxonFilter.getProperty(PROP_CAT_VALUE).getString().equals(PROP_VALUE_TAXO_STYLE)) {
					if (taxonFilter.hasNode(NODE_FILTER_OPTIONS)) {
						NodeIterator styleNodes = taxonFilter.getNode(NODE_FILTER_OPTIONS).getNodes();
						while(styleNodes.hasNext()) {
							Node styleNode = styleNodes.nextNode();
							if (styleNode.hasProperty(PROP_OPTION_VALUE) && styleNode.getProperty(PROP_OPTION_VALUE).getString().equals(displayName)) {
								return styleNode.getProperty(PROP_DISPLAY_TEXT).getString();
							}
						}
					} else if (taxonFilter.hasNode("denfilteroptions")) {
						NodeIterator styleNodes = taxonFilter.getNode("denfilteroptions").getNodes();
						while(styleNodes.hasNext()) {
							Node styleNode = styleNodes.nextNode();
							if (styleNode.hasProperty(PROP_OPTION_VALUE) && styleNode.getProperty(PROP_OPTION_VALUE).getString().equals(displayName)) {
								return styleNode.getProperty(PROP_DISPLAY_TEXT).getString();
							}
						}
					}
				}
			}
		}
		
		return "";
	}
	
	public static Map<String, String> getCategoryDisplayNameMap(ResourceResolver pResourceResolver, String pTaxonomyName) throws RepositoryException {
		String displayName = "";
		Map<String,String> categoryValues = new HashMap<String, String>();
		categoryValues.put("displayName", pTaxonomyName);
		for(Node childNode : getTaxonFilterNodes(pResourceResolver)) {
			if (childNode.hasNode(NODE_FILTER_OPTIONS)) {
				NodeIterator taxoIter = childNode.getNode(NODE_FILTER_OPTIONS).getNodes();
				while(taxoIter.hasNext()) {
					Node taxoNode = taxoIter.nextNode();
					if(taxoNode.hasProperty(PROP_OPTION_VALUE) && taxoNode.getProperty(PROP_OPTION_VALUE).getString().equals(pTaxonomyName)) {
						displayName = taxoNode.getProperty(PROP_DISPLAY_TEXT).getString();
						categoryValues.put("displayName", displayName);
						categoryValues.put("category", childNode.getProperty(PROP_CAT_VALUE).getString());
						return categoryValues;
					}
				}
			} else if (childNode.hasNode("denfilteroptions")) {
				NodeIterator taxoIter = childNode.getNode("denfilteroptions").getNodes();
				while(taxoIter.hasNext()) {
					Node taxoNode = taxoIter.nextNode();
					if(taxoNode.hasProperty(PROP_OPTION_VALUE) && taxoNode.getProperty(PROP_OPTION_VALUE).getString().equals(pTaxonomyName)) {
						displayName = taxoNode.getProperty(PROP_DISPLAY_TEXT).getString();
						categoryValues.put("displayName", displayName);
						categoryValues.put("category", childNode.getProperty(PROP_CAT_VALUE).getString());
						return categoryValues;
					}
				}
			}
		}
		
		return categoryValues;
	}
	
	public static String getCategoryDisplayName(ResourceResolver pResourceResolver, String pTaxonomyName) throws RepositoryException {
		String displayName = "";
		
		for(Node childNode : getTaxonFilterNodes(pResourceResolver)) {
			if (childNode.hasNode(NODE_FILTER_OPTIONS)) {
				NodeIterator taxoIter = childNode.getNode(NODE_FILTER_OPTIONS).getNodes();
				while(taxoIter.hasNext()) {
					Node taxoNode = taxoIter.nextNode();
					if(taxoNode.hasProperty(PROP_OPTION_VALUE) && taxoNode.getProperty(PROP_OPTION_VALUE).getString().equals(pTaxonomyName)) {
						displayName = taxoNode.getProperty(PROP_DISPLAY_TEXT).getString();
						return displayName;
					}
				}
			} else if (childNode.hasNode("denfilteroptions")) {
				NodeIterator taxoIter = childNode.getNode("denfilteroptions").getNodes();
				while(taxoIter.hasNext()) {
					Node taxoNode = taxoIter.nextNode();
					if(taxoNode.hasProperty(PROP_OPTION_VALUE) && taxoNode.getProperty(PROP_OPTION_VALUE).getString().equals(pTaxonomyName)) {
						displayName = taxoNode.getProperty(PROP_DISPLAY_TEXT).getString();
						return displayName;
					}
				}
			}
		}
		
		return pTaxonomyName;
	}
	
	private static List<Node> getTaxonFilterNodes(ResourceResolver pResourceResolver) throws RepositoryException {
		if (taxonNodes == null) {
			taxonNodes = new ArrayList<Node>();
			
			if (session == null) {
				session = getSlingRepository().login();
			}
			
			QueryManager queryManager = session.getWorkspace().getQueryManager();
			String queryBase = "/jcr:root/content/sharedcontent/filters//element(*, nt:unstructured)[@catvalue]";
			Query query = queryManager.createQuery(queryBase, Query.XPATH);
			
			QueryResult result = query.execute();
			
			NodeIterator nodes = result.getNodes();		
			while(nodes.hasNext()) {
				Node filterNode = nodes.nextNode();
				if(filterNode.hasProperty(PROP_CAT_VALUE) && filterNode.getProperty(PROP_CAT_VALUE).getString().startsWith(TAXO_PROP_VAL_PREFIX)) {
					taxonNodes.add(filterNode);
				}
			}
		}
		return taxonNodes;
	}
	
	private static List<Node> getDimensionNodes(ResourceResolver pResourceResolver, Node pSpecParNode) throws ValueFormatException, PathNotFoundException, RepositoryException {
		
		List<Node> dimNodes = getNodes(pResourceResolver, pSpecParNode, DIMENSIONS);
		Node nodeToRemove = null;
		for(Node dimNode : dimNodes) {
			if(dimNode.getPath().endsWith(CATEGORY_HEADER_NODE)) {
				nodeToRemove = dimNode;
				break;
			}
		}
		if (nodeToRemove != null) {
			dimNodes.remove(nodeToRemove);
		}
		
		return dimNodes;
	}
	
	private static List<Node> getNodes(ResourceResolver pResourceResolver, Node pSpecParNode, String pPathIdentifier) throws RepositoryException {
		List<Node> nodes = new ArrayList<Node>();
		if (pSpecParNode != null) {
			NodeIterator nodeIter = pSpecParNode.getNodes();
			while(nodeIter.hasNext()) {
				Node specNode = nodeIter.nextNode();
				if (specNode.hasProperty(PROP_PATH)) {
					String refPath = specNode.getProperty(PROP_PATH).getString();
					if (refPath.contains(pPathIdentifier)) {
						Resource dimensionResource = pResourceResolver.getResource(refPath);
						if (dimensionResource != null) {
							Node dimensionNode = dimensionResource.adaptTo(Node.class);
							if (dimensionNode != null) {
								nodes.add(dimensionNode);
							}
						}
					}
				}
			}
		}
		return nodes;
	}
	
	public static List<String> getPlanFeatures(ResourceResolver pResourceResolver, Node pPlanNode) throws PathNotFoundException, RepositoryException {
		List<String> planFeatures = new ArrayList<String>();
		if (pPlanNode.hasNode("jcr:content/plandetailstabs/featurespar")) {
			Node featuresParNode = pPlanNode.getNode("jcr:content/plandetailstabs/featurespar");
			if (featuresParNode != null) {
				NodeIterator featureNodes = featuresParNode.getNodes();
				if (featureNodes != null) {
					while(featureNodes.hasNext()) {
						Node featureRefNode = featureNodes.nextNode();
						if (featureRefNode.hasProperty("path")) {
							Resource featureResource = pResourceResolver.getResource(featureRefNode.getProperty("path").getString());
							if (featureResource != null) {
								ValueMap featureMap = featureResource.adaptTo(ValueMap.class);
								String title = featureMap.get("title", "");
								planFeatures.add(title);
							}
						}
					}
				}
			}
		}
		
		return planFeatures;
	}

	public static List<Map<String, String>> getKeyFeatures(ResourceResolver pResourceResolver, Node pDevicePageNode) throws RepositoryException {
		
		List<Map<String, String>> keyFeatures = new ArrayList<Map<String, String>>();
		
		setLeftFeaturePar(keyFeatures, pDevicePageNode, pResourceResolver, "jcr:content/devicetabs/leftfeaturepar");
		setRightFeaturePar(keyFeatures, pDevicePageNode, pResourceResolver,"jcr:content/devicetabs/rightfeaturepar");
		
		return keyFeatures;
	}

	private static void setRightFeaturePar(
			List<Map<String, String>> keyFeatures, Node pDevicePageNode,
			ResourceResolver pResourceResolver, String pPath) throws PathNotFoundException, ValueFormatException, RepositoryException {
		setFeaturePar(keyFeatures, pDevicePageNode, pResourceResolver, pPath);
		
	}

	private static void setLeftFeaturePar(
			List<Map<String, String>> keyFeatures, Node pDevicePageNode,
			ResourceResolver pResourceResolver, String pPath) throws PathNotFoundException, ValueFormatException, RepositoryException {
		setFeaturePar(keyFeatures, pDevicePageNode, pResourceResolver, pPath);
		
	}

	private static void setFeaturePar(
			List<Map<String, String>> keyFeatures, Node pDevicePageNode, ResourceResolver pResourceResolver, String pPath) throws PathNotFoundException, ValueFormatException, RepositoryException {
		
		if (pDevicePageNode.hasNode(pPath)) {
			Node leftFeaturesParNode = pDevicePageNode.getNode(pPath);
			if (leftFeaturesParNode == null) {
				return;
			}

			NodeIterator leftFeatureNodes = leftFeaturesParNode.getNodes();
			if (leftFeatureNodes == null) {
				return;
			}

			//while (leftFeatureNodes.hasNext()) {
			for (NodeIterator ni = leftFeatureNodes; ni.hasNext();) {
				Node leftFeatureRefNode = ni.nextNode();
				if (leftFeatureRefNode == null) {
					continue;
				}
				if (leftFeatureRefNode.hasProperty("path")) {
					Resource featureResource = pResourceResolver.getResource(leftFeatureRefNode.getProperty("path").getString());
					if (featureResource == null) {
						return;
					}
					if (featureResource != null) {
						ValueMap featureMap = featureResource.adaptTo(ValueMap.class);
						if (featureMap == null) {
							return;
						}
						Map<String, String> keyFeaturesMap = new HashMap<String, String>();
						keyFeaturesMap.put("title", (String) featureMap.get("title"));
						keyFeaturesMap.put("desc", (String) featureMap.get("desc"));
						keyFeatures.add(keyFeaturesMap);
					}
				}
			}
		}
	}
}
