package com.att.ecom.cq.bundle.helpers.internal;

import javax.jcr.ItemVisitor;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.security.AccessControlEntry;
import javax.jcr.security.AccessControlList;
import javax.jcr.security.AccessControlManager;
import javax.jcr.security.AccessControlPolicy;

import org.slf4j.Logger;

/**
 * Process which ensures that all users have read access to themselves.
 */
class UserFixer extends AbstractFixer implements ItemVisitor {

    /**
     * Construct a new instance.
     * 
     * @param pLogger
     *            a logger
     */
    public UserFixer(final Logger pLogger) {
        super(pLogger);
    }

    /**
     * Fired when a node is encountered. If this node is a user, ensure that the group has read privledges for itself.
     * 
     * @param pNode
     *            the node
     * @param pLevel
     *            the level
     */
    @Override
    protected void entering(final Node pNode, final int pLevel) throws RepositoryException {
        if (pNode.getPrimaryNodeType().getName().equals(NT_USER)) {
            final String principalName = pNode.getProperty(PN_PRINCIPAL_NAME).getString();

            final AccessControlManager acm = pNode.getSession().getAccessControlManager();

            final AccessControlPolicy[] policies = acm.getPolicies(pNode.getPath());
            for (final AccessControlPolicy policy : policies) {
                if (policy instanceof AccessControlList) {
                    final AccessControlList acl = (AccessControlList) policy;
                    for (AccessControlEntry entry : acl.getAccessControlEntries()) {
                        if (entry.getPrincipal().getName().equals(principalName)) {
                            return;
                        }
                    }
                }
            }

            mLogger.info("Adding ACE on user node " + pNode.getPath());

            configureAccessControlEntry(pNode, principalName);
        }
    }
}
