package com.att.ecom.cq.bundle.helpers.jcrsameness.replicator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.Agent;
import com.day.cq.replication.AgentManager;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationOptions;
import com.day.cq.replication.Replicator;


public class ReplicateDifferences {
	
	private String replication_ids;
	private String diffFilePath;
	private String replicateToHost;
	private String replicteToPort;
	private String replicationAction;

	
	public String getReplication_ids() {
		return replication_ids;
	}


	public void setReplication_id(String replication_id) {
		this.replication_ids = replication_id;
	}


	public String getDiffFilePath() {
		return diffFilePath;
	}


	public void setDiffFilePath(String diffFilePath) {
		this.diffFilePath = diffFilePath;
	}


	
	public String getReplicateToHost() {
		return replicateToHost;
	}


	public void setReplicateToHost(String replicateToHost) {
		this.replicateToHost = replicateToHost;
	}


	public String getReplicteToPort() {
		return replicteToPort;
	}


	public void setReplicteToPort(String replicteToPort) {
		this.replicteToPort = replicteToPort;
	}



	
	
	public String getReplicationAction() {
		return replicationAction;
	}


	public void setReplicationAction(String replicationAction) {
		this.replicationAction = replicationAction;
	}

	private static final Logger log = LoggerFactory.getLogger(ReplicateDifferences.class);

	ReplicateDifferences(String replication_id,String diffFilePath, String replicationAction){
		this.replication_ids = replication_id;
		this.diffFilePath = diffFilePath;
		if(null!= replicationAction && !"".equals(replicationAction)) {
			this.replicationAction = replicationAction.toUpperCase();
		}
		else {
			this.replicationAction = "ACTIVATE";
		}
	}
	
	
	
	public ArrayList<ReplicationActionResponse> replicateDifferences(){
		ArrayList<ReplicationActionResponse> responseList  = new ArrayList<ReplicationActionResponse>();
		boolean isSuccess = false;
		AgentManager agentManager = (AgentManager)getServiceReference("com.day.cq.replication.AgentManager");
		ReplicationOptions replicationOptions = new ReplicationOptions();
		if(this.getReplication_ids() !=""){
			String[] agentArray ;
			Map<String, Agent> agentsMap = agentManager.getAgents();
  		    agentArray = new String[agentsMap.size()];
			  if("ALL".equals(this.getReplication_ids())){
				  int i = 0;
				  for (Iterator<String> agentKeyItr = agentsMap.keySet().iterator(); agentKeyItr.hasNext();) {
					String agentIdStr = (String) agentKeyItr.next();
					if(agentsMap.get(agentIdStr).isValid() && agentsMap.get(agentIdStr).isEnabled()){
						agentArray[i++] = agentIdStr;
					}
				}
			  }else{
				  agentArray = this.getReplication_ids().split(",");  
			  }
//				replicationOptions.setFilter(new ATTAgentIdFilter(agentArray));
//				replicationOptions.setSynchronous(false);
//				replicationOptions.setSuppressVersions(true);		
//				doReplicate(replicationOptions,);
				for (String agentId : agentArray) {
					if(null!= agentId && !"".equals(agentId) && agentsMap.containsKey(agentId.trim())){
						log.info("----------------------------------------------------------------------------------------------------");
						log.info("Setting Replication Agent as :"+agentId);
						Agent agent = agentsMap.get(agentId);
						agent.getQueue().isBlocked();
						agent.getConfiguration().checkValid();
						agent.getQueue().isPaused();
						replicationOptions.setFilter(new ATTAgentIdFilter(agentId));
						replicationOptions.setSynchronous(false);
						replicationOptions.setSuppressVersions(true);
						
						ReplicationActionResponse actionResp = new ReplicationActionResponse();
						actionResp.setAgentId(agentId);
						actionResp.setAgentTransportURL(agent.getConfiguration().getTransportURI());
						if(agent.getQueue().getStatus().getNextRetryTime() != -1){ 
							actionResp.setReplicationAgentStatus("IS BLOCKED");
						}
						else{
							actionResp.setReplicationAgentStatus("IS ACTIVE");
							if(agent.getQueue().isPaused()) actionResp.setReplicationAgentStatus("IS ACTIVE but PAUSED");
						}
						actionResp.setPathReplicationAction(doReplicate(replicationOptions,agentId));
						responseList.add(actionResp);
					}
				}
		}else{
			// Search for the replication agent which has the transport
			// URL similar to getHost:getPort
//			session = slingRepo.loginAdministrative(null);
//			QueryManager qm = session.getWorkspace().getQueryManager();
//			Query query = qm.createQuery("select * from ", arg1)
		}
		return responseList;
	}
	
	public static Object getServiceReference(String className){
		BundleContext ctx = FrameworkUtil.getBundle(ReplicateDifferences.class).getBundleContext();
		return ctx.getService(ctx.getServiceReference(className));
	}
	
	private File validateDiffPath(String difFilePaht) throws FileNotFoundException{
		File diffPathFile = new File(difFilePaht);
		String   atgDynamoDataDir = "";
		if(diffPathFile.exists() && !diffPathFile.isDirectory()){
			return diffPathFile;
		}else{
	        if (SystemUtils.IS_OS_WINDOWS) {
	            atgDynamoDataDir = System.getenv("atg.dynamo.data-dir"); 
	        } else {
	            atgDynamoDataDir = System.getProperty("atg.dynamo.data-dir");
	        }
	        diffPathFile =new File(atgDynamoDataDir+File.separator+difFilePaht); 
			if(diffPathFile.exists() && !diffPathFile.isDirectory()){
				return diffPathFile;
			}else{
				return null;
			}
		}
	}
	
	
	private Hashtable<String,String> doReplicate(ReplicationOptions replicationOptions,String agentId){
		Properties props = new Properties();
		Replicator replicator = (Replicator)getServiceReference("com.day.cq.replication.Replicator");
		SlingRepository slingRepo = (SlingRepository)getServiceReference("org.apache.sling.jcr.api.SlingRepository");
		boolean isSuccess = false;
		Session adminSession = null;
		Hashtable<String, String> responseMap = new Hashtable<String,String>();
		
		try {
			if(null != validateDiffPath(this.getDiffFilePath())){
				props.load(new FileInputStream(validateDiffPath(this.getDiffFilePath())));
				List<String> listOfEntries = FileUtils.readLines(validateDiffPath(this.getDiffFilePath()));
				
				Enumeration e = props.propertyNames();
				adminSession  = slingRepo.loginAdministrative(null);
				ReplicationActionType replicationType = null;
				if("ACTIVATE".equals(this.getReplicationAction().toUpperCase())){
					replicationType = ReplicationActionType.ACTIVATE;
				}else if("DEACTIVATE".equals(this.getReplicationAction().toUpperCase())){
					replicationType = ReplicationActionType.DEACTIVATE;
				}else if("DELETE".equals(this.getReplicationAction().toUpperCase())){
					replicationType = ReplicationActionType.DELETE;
				}
				/*
				 * If the Replicatoin Action is Delete dont check for the existence of the node on the source. Just Delete it on the destination.
				 * Check for the existence of the node only if the replication action is activate/Deactivate
				 */
				replicationOptions.setListener(new ReplicateDifferencesLogListener());
				for (Iterator pathItr = listOfEntries.iterator(); pathItr.hasNext();) {
					String key = (String) pathItr.next();
						log.info("Replicating via ReplicateDifference class.\t "+key+" ");
						if(replicationType.equals(ReplicationActionType.DELETE)){
							try{
								replicator.replicate(adminSession,replicationType , key, replicationOptions);
								responseMap.put(key, this.getReplicationAction()+"D");
	 						}catch(Exception e3){
								log.error("EXCEPTION HAPPENED WHILE REPLICATING FOR "+key+" USING AGENT :" +agentId);
								e3.printStackTrace();
								responseMap.put("ERROR-"+key, e3.getMessage()+" Could be Agent is not enabled");
								continue;
	 						}
						}else{
							if(adminSession.nodeExists(key)){
								try{
									
									replicator.replicate(adminSession,replicationType , key, replicationOptions);
									responseMap.put(key, this.getReplicationAction()+"D");
									}catch(Exception e3){
										log.error("EXCEPTION HAPPENED WHILE REPLICATING FOR "+key+" USING AGENT :" +agentId);
										e3.printStackTrace();
										responseMap.put("ERROR-"+key, e3.getMessage()+" Could be Agent is not enabled");
										continue;
									}
							}else{
								responseMap.put(key, "Path Not Found on Source. Could not "+this.replicationAction+"");
							}
						}
				}
			}else{
				responseMap.put("ERROR","INPUT FILE PATH NOT FOUND");
				
			}
			

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			responseMap.put("ERROR", e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			responseMap.put("ERROR", e.getMessage());
		} catch (RepositoryException e1) {
			e1.printStackTrace();
			responseMap.put("ERROR", e1.getMessage());
		}finally{
			if(null != adminSession ) adminSession.logout();
		}
		
		return responseMap;
		
	}
	
    
}
