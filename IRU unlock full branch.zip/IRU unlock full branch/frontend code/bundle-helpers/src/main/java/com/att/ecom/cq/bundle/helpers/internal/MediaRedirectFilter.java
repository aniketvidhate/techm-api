package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.util.Dictionary;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Filter which redirects static asset requests to an alternate domain for situations where the static assets are not
 * available locally.
 */
@Component(immediate = true, metatype = true, label = "Media Redirect Filter for ecareCMS", description = "Filter to redirect requests for /media/<notcms>/.")
@Service
@Property(name = "pattern", value = "^(/catalog/|/images/|/scripts/|/support_media/|/support_static_files/|/styles/|(/media/(?!cms/shop)(?!cms/homepage))).*$")
public class MediaRedirectFilter implements Filter {

    /**
     * The default enabled state.
     */
    private static final boolean DEFAULT_ENABLED = true;

    /**
     * The default redirect base URL.
     */
    private static final String DEFAULT_REDIRECT_BASE_URL = "http://www.att.com";

    /**
     * OSGi configuration property for enable state.
     */
    @Property(label = "Enabled", description = "Is redirect enabled?", boolValue = DEFAULT_ENABLED)
    private static final String PROP_ENABLED = "redirect.enabled";

    /**
     * OSGi configuration property for the redirect base URL.
     */
    @Property(label = "Redirect Base URL", description = "Base url to redirect requests to", value = DEFAULT_REDIRECT_BASE_URL)
    private static final String PROP_REDIRECT_BASE_URL = "redirect.base";

    /**
     * The current enabled state.
     */
    private boolean mEnabled;

    /**
     * A logger.
     */
    private final Logger mLogger = LoggerFactory.getLogger(this.getClass());

    /**
     * The
     */
    private String mRedirectBaseUrl;

    /**
     * Activate this component.
     * 
     * @param pCtx
     *            the OSGi component context
     */
    protected void activate(final ComponentContext pCtx) {
        final Dictionary<?, ?> props = pCtx.getProperties();
        this.mRedirectBaseUrl = OsgiUtil.toString(props.get(PROP_REDIRECT_BASE_URL), DEFAULT_REDIRECT_BASE_URL);
        this.mEnabled = OsgiUtil.toBoolean(props.get(PROP_ENABLED), DEFAULT_ENABLED);

    }

    /**
     * No-op. Normal filter livecycle ignored.
     */
    @Override
    public void destroy() {
    }

    /**
     * If enabled, construct a redirect path and send a redirect.
     * 
     * @param pRequest
     *            the request
     * @param pResponse
     *            the response
     * @param pChain
     *            the filter chain
     */
    @Override
    public void doFilter(final ServletRequest pRequest, final ServletResponse pResponse, final FilterChain pChain)
            throws IOException, ServletException {
        if (!this.mEnabled) {
            pChain.doFilter(pRequest, pResponse);
        } else {
            if (pRequest instanceof HttpServletRequest && pResponse instanceof HttpServletResponse) {
                final HttpServletRequest httpRequest = (HttpServletRequest) pRequest;
                final HttpServletResponse httpResponse = (HttpServletResponse) pResponse;
                final String path = httpRequest.getPathInfo();
                String queryString = httpRequest.getQueryString(); 
                if (queryString == null) {
                	queryString = "";
                } else {
                	queryString = "?" + queryString;
                }
                
                try {
                    httpResponse.sendRedirect(this.mRedirectBaseUrl + path + queryString);
                } catch (IllegalStateException e) {
                    this.mLogger.warn("Error in redirecting request for {}: {}", new Object[] { path, e.getMessage() });
                }
            } else {
                pChain.doFilter(pRequest, pResponse);
            }
        }
    }

    /**
     * No-op. Normal filter livecycle ignored.
     */
    @Override
    public void init(final FilterConfig pFilterConfig) throws ServletException {
    }

}
