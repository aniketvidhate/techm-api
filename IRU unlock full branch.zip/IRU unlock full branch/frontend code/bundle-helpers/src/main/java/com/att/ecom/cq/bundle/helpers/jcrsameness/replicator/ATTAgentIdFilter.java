package com.att.ecom.cq.bundle.helpers.jcrsameness.replicator;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.Agent;
import com.day.cq.replication.AgentFilter;
import com.day.cq.replication.AgentManager;

public class ATTAgentIdFilter implements AgentFilter {
	  private final Set<String> ids = new HashSet<String>();
	  
	  
	  private static final Logger log = LoggerFactory.getLogger(ATTAgentIdFilter.class);
	   public ATTAgentIdFilter(String[] ids)
	   {
		   AgentManager agentManager = (AgentManager)ReplicateDifferences.getServiceReference("com.day.cq.replication.AgentManager");
		   if("ALL".equals(ids[0])){
			   log.info("Adding replication Agents:"+agentManager.getAgents().keySet());
			   this.ids.addAll(agentManager.getAgents().keySet());
		   }else{
			   log.info("Adding replication Agents:"+Arrays.asList(ids));
			   this.ids.addAll(Arrays.asList(ids));
		   }
	   }
	   
	   public ATTAgentIdFilter(String id){
		   log.info("Setting replication Agent to:"+id);
		   this.ids.add(id);
	   }
	 
	   public boolean isIncluded(Agent agent)
	   {
		   if(this.ids.contains(agent.getId()) && agent.isValid() && agent.isEnabled() ){
			   log.info("Using replication Agent:"+agent.getId());
			   return this.ids.contains(agent.getId());
		   }else{
			   log.debug("Ignoring replication Agent (Could be invalid or inActive or isNotDefault):"+agent.getId());
			   return false;
		   }
	   }

}
