/**
 * 
 */
package com.att.ecom.cq.bundle.helpers;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.wcm.api.Page;

/**
 * @author bb791k
 *
 */
public class SharedContentItem {

	private final String OVERVIEW_PAR = "overviewpar";
	private final String OVERVIEW_LEGAL_PAR = "overviewlegal";
	private final String LEFT_KEY_FEATURES_PAR = "leftkeyfeaturepar";
	private final String RIGHT_KEY_FEATURES_PAR = "rightkeyfeaturepar";
	private final String LEFT_FEATURES_PAR = "leftfeaturepar";
	private final String RIGHT_FEATURES_PAR = "rightfeaturepar";
	private final String LEFT_SPECS_PAR = "lefttechspecpar";
	private final String RIGHT_SPECS_PAR = "righttechspecpar";
	private final String LEFT_IN_THE_BOX_PAR = "inboxleftpar";
	private final String RIGHT_IN_THE_BOX_PAR = "inboxrightpar";
	private final String LEGAL_PAR = "legalpar";
	private final String IN_THE_BOX_MAIN_PAR = "inboxmainpar";
	
	
	protected Resource mContentResource;
	protected ResourceResolver mResourceResolver;
	protected String mLocale;
	protected String mFolder;
	
	public SharedContentItem(String pContentPath, ResourceResolver pResourceResolver) {
		if (pResourceResolver != null) {
			this.mResourceResolver = pResourceResolver;
			this.mContentResource = this.mResourceResolver.getResource(pContentPath);
		}
	}
	
	public String getOverviewParPath() {
		return getResourcePath(OVERVIEW_PAR);
	}
	
	public String getOverviewLegalParPath() {
		return getResourcePath(OVERVIEW_LEGAL_PAR);
	}
	
	public String getKeyFeaturesLeftParPath() {
		return getResourcePath(LEFT_KEY_FEATURES_PAR);
	}

	public String getKeyFeaturesRightParPath() {
		return getResourcePath(RIGHT_KEY_FEATURES_PAR);
	}
	
	public String getFeaturesLeftParPath() {
		return getResourcePath(LEFT_FEATURES_PAR);
	}

	public String getFeaturesRightParPath() {
		return getResourcePath(RIGHT_FEATURES_PAR);
	}
	
	public String getSpecsLeftParPath() {
		return getResourcePath(LEFT_SPECS_PAR);
	}

	public String getSpecsRigthParPath() {
		return getResourcePath(RIGHT_SPECS_PAR);
	}
	
	public String getInTheBoxLeftParPath() {
		return getResourcePath(LEFT_IN_THE_BOX_PAR);
	}

	public String getInTheBoxRightParPath() {
		return getResourcePath(RIGHT_IN_THE_BOX_PAR);
	}
	
	public String getInTheBoxMainParPath() {
		return getResourcePath(IN_THE_BOX_MAIN_PAR);
	}
	
	public String getLegalPar() {
		return getResourcePath(LEGAL_PAR);
	}
	
	public String getTitle() {
		String title = "";
		
		String pageTitle = getPropertyValue("pageTitle");
		String jcrTitle = getPropertyValue("jcr:title");
		if (StringUtils.isNotEmpty(pageTitle)) {
			title = pageTitle;
		} else if (StringUtils.isNotEmpty(jcrTitle)) {
			title = jcrTitle;
		}
		
		return title;
	}
	
	public String getNavigationTitle() {
		return getPropertyValue("navTitle");
	}
	
	public String getSku() {
		return getPropertyValue("sku", false);
	}
	
	public String getMediaAvailable() {
		String isAvail = "false";
		isAvail = getPropertyValue("mediaAvailable", false);
		return isAvail;
	}
	
	public String getDeliveryPromise() {
		return getPropertyValue("deliveryPromise");
	}
	
	public String getFolder() {
		return mFolder;
	}

	public void setFolder(String pFolder) {
		this.mFolder = pFolder;
	}

	public Resource getContentResource() {
		return mContentResource;
	}

	public void setContentResource(Resource pContentResource) {
		this.mContentResource = pContentResource;
	}
	
	public String getContentPath() {
		return this.mContentResource.getPath();
	}
	
	protected String getPropertyValue(String propName) {
		return getPropertyValue(propName, true);
	}
	
	protected String getPropertyValue(String propName, boolean useLocale) {
		return getPropertyValue(propName, String.class, useLocale);
	}
	
	protected <T> T getPropertyValue(String propName, Class<T> type, boolean useLocale) {
		Page resourcePage = this.mContentResource.adaptTo(Page.class);
		Resource contentResource = resourcePage.getContentResource();
		if (useLocale) {
			Resource localeResource = contentResource.getChild(this.mLocale);
			if (localeResource != null) {
				ValueMap props = localeResource.adaptTo(ValueMap.class);
				return props.get(propName, type);
			}
		} else {
			ValueMap props = contentResource.adaptTo(ValueMap.class);
			return props.get(propName, type);
		}
		return null;
	}
	
	protected String getResourcePath(String pChildPath) {
		String resourcePath = pChildPath;
		
		Page resourcePage = this.mContentResource.adaptTo(Page.class);
		Resource contentResource = resourcePage.getContentResource();
		resourcePath = contentResource.getPath() + "/" + this.mLocale + "/" + pChildPath;
		
		return resourcePath;
	}
	
	public void setLocale(String pLanguageCode) {
		this.mLocale = pLanguageCode;
	}
	
	public String getUrlDisplayPath() {
		return "not implemented";
	}
}
