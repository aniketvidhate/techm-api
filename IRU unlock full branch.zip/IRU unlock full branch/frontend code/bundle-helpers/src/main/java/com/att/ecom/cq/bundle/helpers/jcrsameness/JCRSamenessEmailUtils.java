/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * It contains utility methods to compose a JCR sameness result e-mail.
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884@att.com)
 * @since Jan 21, 2013 12:43:39 PM
 */
public class JCRSamenessEmailUtils {

    private static final Logger logger = LoggerFactory.getLogger(JCRSamenessEmailUtils.class); // $codepro.audit.disable unusedField
    private static final String CSS = "<style type='text/css'>table.skutable { border-collapse:collapse; }table.skutable td, table.skutable th { border:1px solid black; }</style>";
    private static final String TABLE_TEMPLATE_BODY = "%s<table class='skutable'>%s%s</table>";
    private static final String HEADER_ROW_FOR_JCR_SAMENESS_RESULTS =  
     "<tr>" +
        "<th width='300'><b><font color='blue'>Host Name</font></b></th>" +
        "<th width='20'><b><font color='blue'>Result</font></b></th>" +
        "<th width='100'><b><font color='blue'>No. of differences</font></b></th>" +
        "<th width='100'><b><font color='blue'>No. of pages affected by differences</font></b></th>" +
        "<th width='100'><b><font color='blue'>No. of extra nodes</font></b></th>" +
        "<th width='100'><b><font color='blue'>No. of pages affected by extra nodes</font></b></th>" +        
    "</tr>";
    
    private static final String ROW_TEMPLATE_FOR_JCR_SAMENESS_RESULT = 
    "<tr>" +
        "<td align='center'><b><font color='brown'>%s</font></b></td>" +
        "<td align='center' bgcolor='%s'>%s</td>" +
        "<td align='center'><font color='brown'>%s</font></td>" +
        "<td align='center'><font color='brown'>%s</font></td>" +
        "<td align='center'><font color='brown'>%s</font></td>" +
        "<td align='center'><font color='brown'>%s</font></td>" +        
    "</tr>";    
    
    public static String buildHTMLEmailMessageForJCRSamenessResult(List<JCRCompareResponse> pJCRCompareResponseList, JCRSamenessToolRequest pInput) {
        StringBuilder allrows = new StringBuilder();
        for(JCRCompareResponse jcrCompareResponse : pJCRCompareResponseList) {
            allrows.append(buildJCRSamenessResultRow(jcrCompareResponse));
        }
        
        return buildTableForJCRSamenessResult(allrows.toString(), pInput);
    }
    
    private static String buildJCRSamenessResultRow(JCRCompareResponse pJCRCompareResponse) {
        //LOGGER.debug(skuObject.toString());
        
        return String.format(
                ROW_TEMPLATE_FOR_JCR_SAMENESS_RESULT,
                new Object[] { pJCRCompareResponse.getDetailedResponse().getHostName(),
                        pJCRCompareResponse.getDetailedResponse().getBackgroundColor(),
                        pJCRCompareResponse.getDetailedResponse().getResult(),
                        pJCRCompareResponse.getDetailedResponse().getNumOfDifferences(), 
                        pJCRCompareResponse.getDetailedResponse().getNumOfPagesAffectedDueToDiff(),
                        pJCRCompareResponse.getDetailedResponse().getNumOfExtraNodesOnTarget(), 
                        pJCRCompareResponse.getDetailedResponse().getNumOfPagesAffectedDueToExtra(),});
    }
    
    private static String buildTableForJCRSamenessResult(String pRows, JCRSamenessToolRequest pInput) {
        StringBuilder emailBody = new StringBuilder();
        emailBody.append(buildEmailHeader(pInput));
       
        return emailBody.append(String.format(TABLE_TEMPLATE_BODY, new Object[] {CSS, HEADER_ROW_FOR_JCR_SAMENESS_RESULTS,
                pRows })).toString();
    }

    private static Object buildEmailHeader(JCRSamenessToolRequest pInput) {
        StringBuilder emailHeader = new StringBuilder();
        emailHeader.append("<table align=center> <h2> <font color='#C73F17' >Repository Sameness Tool Results </font></h2></table>");
        emailHeader.append("<br/><br/><table>");
        emailHeader.append("<tr><td><b><font color='brown'> Path : </b>" + pInput.getPath() + "</td></tr>");
        emailHeader.append("<tr><td><b><font color='brown'> Source Host : </b>" + pInput.getSourceHost() + "</td></tr>");
        emailHeader.append("<tr><td><b><font color='brown'> Target Host(s) : </b>" + pInput.toString(pInput.getTargetHosts()) + "</td></tr>");
        emailHeader.append("</table> <br/> <br/>");
        return emailHeader.toString();
    }    
}
