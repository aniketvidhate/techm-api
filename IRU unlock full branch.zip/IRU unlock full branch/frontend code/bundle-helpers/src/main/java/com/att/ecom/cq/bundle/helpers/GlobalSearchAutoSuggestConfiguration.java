package com.att.ecom.cq.bundle.helpers;

import java.util.Dictionary;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;

@Component(immediate = true, metatype = true, label = "GlobalSearch AutoSuggest Configuration", description = "Global Search Auto Suggest Configuration")
@Service(value = com.att.ecom.cq.bundle.helpers.GlobalSearchAutoSuggestConfiguration.class)
public class GlobalSearchAutoSuggestConfiguration {

	@SuppressWarnings("rawtypes")
	private static Dictionary props = null;

	private static final String DEFAULT_CRON_EXPRESSION = "* 22 * * * ?";
	private static final String DEFAULT_XML_URL = "http://cmsdev4.admin.cingular.net/globalsearch/autosuggest.xml";
	private static final String DEFAULT_PAGE_PATH = "/content/att/cmsfeed/globalsearch";
	private static final boolean DEFAULT_IS_ENABLED = false;
	
	
		
	@Property(label = "Cron Expression", value = "")
	private static final String CRON_EXPRESSION = "auto.suggest.cron.expression";
	
	@Property(label = "XML Url", value = "")
	private static final String XML_URL = "auto.suggest.xml.url";
	
	@Property(label = "Page Path", value = "")
    private static final String PAGE_PATH = "auto.suggest.page.path";
	
    @Property(label = "Create Versions", boolValue = DEFAULT_IS_ENABLED, description = "Create Versions?")
    private static final String IS_ENABLED_PROPERTY = "isEnabled";
    
    @Property(label = "Filter Collection", boolValue = DEFAULT_IS_ENABLED, description = "Filter Collection value 0?")
    private static final String IS_FILTER_ENABLED = "isFilterEnabled";

	protected void activate(ComponentContext ctx) {
		props = ctx.getProperties();
	}
	
	
	public static String getCronExpression() {
		return OsgiUtil.toString(props.get(CRON_EXPRESSION), DEFAULT_CRON_EXPRESSION);
	}
	
	public static String getXmlUrl() {
        return OsgiUtil.toString(props.get(XML_URL), DEFAULT_XML_URL);
    }
	public static String getDefaultPagePath() {
        return OsgiUtil.toString(props.get(PAGE_PATH), DEFAULT_PAGE_PATH);
    }
		
	public static boolean checkVersion() {
        return OsgiUtil.toBoolean(props.get(IS_ENABLED_PROPERTY),DEFAULT_IS_ENABLED);
    }
	public static boolean checkCollectionFilter() {
        return OsgiUtil.toBoolean(props.get(IS_FILTER_ENABLED),DEFAULT_IS_ENABLED);
    }
	  
}
