/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.util.ArrayList;
import java.util.List;

import javax.mail.internet.InternetAddress;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.mail.HtmlEmail;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.mailer.MessageGateway;
import com.day.cq.mailer.MessageGatewayService;

/**
 * It sends an e-mail with JCR sameness Tool results.
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884)
 * @Since Dec 28, 2012 11:13:39 AM
 */
@Component(immediate = true)
@Service(value = JCRSamenessEmailSender.class)
public class JCRSamenessEmailSender {

    @Reference
    private MessageGateway<HtmlEmail> messageGateway;

    @Reference
    private MessageGatewayService messageGatewayService;

    @Reference
    private JCRSamenessConfig mJCRSamenessConfig;

    private static final Logger LOGGER = LoggerFactory.getLogger(JCRSamenessEmailSender.class);

    public void sendEmailWithRepositorySamenessToolResults(JCRSamenessToolRequest pInputBean, List<JCRCompareResponse> pJCRCompareResponseList) {
        try {
            HtmlEmail email = new HtmlEmail();
            
            // Set To e-mail addresses
            ArrayList<InternetAddress> emailRecipientsTo = new ArrayList<InternetAddress>();
            String tos = mJCRSamenessConfig.getGroupEmailAddress();                
            if (tos != null) {
                for (String to : tos.split(",")) {
                    if (StringUtils.isNotEmpty(to)) {
                        emailRecipientsTo.add(new InternetAddress(to));                        
                    }
                }
            }
            email.setTo(emailRecipientsTo);
            
            // Set CC e-mail addresses
            ArrayList<InternetAddress> emailRecipientsCC = new ArrayList<InternetAddress>();
            if (StringUtils.isNotEmpty(pInputBean.getEmailAddresses())) {
                String[] additionalEmailAddArray = pInputBean.getEmailAddresses().trim().split(",");
                if (additionalEmailAddArray != null && additionalEmailAddArray.length > 0) {
                    for (String emailAddress : additionalEmailAddArray) {
                        emailRecipientsCC.add(new InternetAddress(emailAddress));
                    }
                }
            }
            if (emailRecipientsCC.size() > 0) {
                email.setCc(emailRecipientsCC);                
            }
            
            // Set From e-mail address and From name
            email.setFrom( mJCRSamenessConfig.getFromAddress(), mJCRSamenessConfig.getFromName());                
            
            // Set subject
            email.setSubject("JCR Sameness Tool Results");
            
            // Set HTML message
            email.setHtmlMsg(JCRSamenessEmailUtils.buildHTMLEmailMessageForJCRSamenessResult(pJCRCompareResponseList, pInputBean));
            
            // Set e-mail handler host
            email.setHostName(mJCRSamenessConfig.getEmailHost());

            messageGateway = messageGatewayService.getGateway(HtmlEmail.class);

            messageGateway.send(email);
        } catch (Exception e) {
            LOGGER.error("Error while sending email", e);
        }
    }
}
