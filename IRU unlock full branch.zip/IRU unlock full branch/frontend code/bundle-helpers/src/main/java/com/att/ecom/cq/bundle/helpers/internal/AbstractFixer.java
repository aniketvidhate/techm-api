package com.att.ecom.cq.bundle.helpers.internal;

import java.security.Principal;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.util.TraversingItemVisitor.Default;

import org.apache.sling.jcr.base.util.AccessControlUtil;
import org.slf4j.Logger;

/**
 * Base class for UserFixer and GroupFixer
 *
 */
public abstract class AbstractFixer extends Default {

    /**
     * The node type for groups.
     */
    protected static final String NT_GROUP = "rep:Group";

    /**
     * The node type for groups.
     */
    protected static final String NT_USER = "rep:User";

    /**
     * Identifier to indicate that any created ACEs should be the first ACE.
     */
    protected static final String ORDER_FIRST = "first";

    /**
     * The property name containing the principal name.
     */
    protected static final String PN_PRINCIPAL_NAME = "rep:principalName";

    /**
     * The JCR Read privledge.
     */
    protected static final String PRIVLEDGE_JCR_READ = "jcr:read";

    /**
     * A logger.
     */
    protected final Logger mLogger;

    /**
     * Construct a new instance.
     * 
     * @param pLogger
     *            a logger
     */
    public AbstractFixer(final Logger pLogger) {
        this.mLogger = pLogger;
    }

    /**
     * Give the principal a read access control entry on the node.
     * 
     * @param pNode
     *            the node
     * @param principalName
     *            the principal name
     * @throws RepositoryException
     *             if something goes wrong
     */
    protected void configureAccessControlEntry(final Node pNode, final String principalName) throws RepositoryException {
        final Session session = pNode.getSession();

        final Principal principal = AccessControlUtil.getPrincipalManager(session).getPrincipal(principalName);

        AccessControlUtil.replaceAccessControlEntry(session, pNode.getPath(), principal,
                new String[] { PRIVLEDGE_JCR_READ }, null, null, ORDER_FIRST);

        session.save();
    }

}