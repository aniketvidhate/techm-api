package com.att.ecom.cq.bundle.helpers;

import javax.servlet.jsp.JspException;

import org.apache.taglibs.standard.tag.el.fmt.ParamTag;;

public class ATTCustomFmtParamTag extends ParamTag{
	
	// This is a place holder class to bypass error.
	// Since I made custom implementation of <fmt:message> tag to <attfmt:message>,
	// <fmt:param> tag used within <attfmt:message> is throwing error. As it is always needs to be nested inside <fmt:message>
	// <fmt:param> tag is used inside <fmt:message>
	// e.g
	// <fmt:message key="label.key">
	//		<fmt:param value="value.attr">
	// </fmt:message>
	//
	// With this implementation now <fmt:message> and <fmt:param> tag should be replace as flollows
	// <attfmt:message key="label.key">
	//		<attfmt:param value="value.attr">
	// </attfmt:message>

	@Override
	public int doStartTag() throws JspException {
		return super.doStartTag();
	}
}
