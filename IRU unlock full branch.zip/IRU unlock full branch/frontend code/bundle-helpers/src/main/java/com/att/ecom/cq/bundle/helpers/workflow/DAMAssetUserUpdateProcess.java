package com.att.ecom.cq.bundle.helpers.workflow;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

/**
 * Workflow process that updates a DAM asset with the user who uploaded
 */
@Component
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "A Workflow process - DAM Asset update."),
        @Property(name = Constants.SERVICE_VENDOR, value = "AT&T"),
        @Property(name = "process.label", value = "DAM User Update Workflow Process")})
public class DAMAssetUserUpdateProcess implements WorkflowProcess {
    
    private static final Logger log = LoggerFactory.getLogger(DAMAssetUserUpdateProcess.class);
    private static final String TYPE_JCR_PATH = "JCR_PATH";

    public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) throws WorkflowException {
        WorkflowData workflowData = item.getWorkflowData();
        if (workflowData.getPayloadType().equals(TYPE_JCR_PATH)) {
            String path = workflowData.getPayload().toString();
            //path points to rendition, need to get actual asset  
            int index = path.indexOf("jcr:content");
            path = path.substring(0, index + 11);
            log.debug("path = " + path);
            //replace /content with /var
            String varPath = "/var" + path.substring(8);
            log.debug("varpath = " + varPath);
            try {
                Node node = (Node) session.getSession().getItem(path);
                Node varNode = (Node)session.getSession().getItem(varPath);
                if (varNode != null) {
                    String user = varNode.getProperty("jcr:lastModifiedBy").getString();
                    if (node != null) {
                        node.setProperty("jcr:lastModifiedBy", user);
                        session.getSession().save();
                    }
                }
            } catch (RepositoryException e) {
                throw new WorkflowException(e.getMessage(), e);
            }
        }
    }
}