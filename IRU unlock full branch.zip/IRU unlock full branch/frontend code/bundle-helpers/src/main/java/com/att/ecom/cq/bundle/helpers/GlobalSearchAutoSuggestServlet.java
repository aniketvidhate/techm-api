package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
 * Servlet to Update content of globalsearch_AutoSuggest.xml to CQ Repository.
 * @author Hemant Arora (ha061x)
 * @created on November 2013
 * This updates admin boost values
 */

@SlingServlet(paths = "/system/att/cms/internaltools/autosuggest")

public class GlobalSearchAutoSuggestServlet extends SlingAllMethodsServlet{

	
	private static final long serialVersionUID = 1L;
	private static final String JCR_PATH="/content/att/cmsfeed/globalsearch";
	private static final String NODE_AUTO_SUGGEST_AUTOMATION ="autosuggest";
	private static final String PAGE_RESOURCE_TYPE="cq:Page";
	private static final String ATTR_USER_QUERY="userQuery";
	private static final String ATTR_COLLECTION="collection";
	private static final String ATTR_ADMIN_BOOST="adminBoost";//field element attribute in xml
	private static final String JCR_CONTENT ="jcr:content";
	private static final String NODE_AUTOSUGGEST ="autosuggest";
	

	private Logger logger = LoggerFactory.getLogger(GlobalSearchAutoSuggestServlet.class);

	@Reference
	private SlingRepository slingRepository;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,	IOException 
	{	
		javax.jcr.Node rootNode=null;
		String output="";	
		try 
		{
			//Create a Session
			//logger.error("Create session with defaut credentials");
			javax.jcr.Session session =slingRepository.loginAdministrative(null);

			ResourceResolver resourceResolver =request.getResourceResolver();
			session = resourceResolver.adaptTo(Session.class);
			rootNode =(javax.jcr.Node) session.getItem(JCR_PATH);
			javax.jcr.Node childNode=null;

			if(null!=rootNode && rootNode.hasNode(NODE_AUTO_SUGGEST_AUTOMATION)){
				output +="<br>ROOT NODE EXISTS " + JCR_PATH;
				rootNode=(javax.jcr.Node) session.getItem(JCR_PATH+"/"+NODE_AUTO_SUGGEST_AUTOMATION);
				String selectedValues=request.getParameter("selectedValue");
				selectedValues = null != selectedValues ? selectedValues.substring(1,selectedValues.length()-2).replaceAll("\"", "") : null;
				Map<String,String> selecteValueMap = convertToMap(selectedValues);
				if(selecteValueMap != null){
					for (Map.Entry<String, String> entry : selecteValueMap.entrySet()) {
						String userQuery="";
						String key=entry.getKey().toString();
						String value= entry.getValue().toString();
						//check if node exists under root node
						if(rootNode.hasNode(key)){
							childNode=rootNode.getNode(key);
							if(childNode.getProperty("jcr:primaryType").getString().equalsIgnoreCase(PAGE_RESOURCE_TYPE)){
								if(childNode.hasNode(JCR_CONTENT)){
									javax.jcr.Node jcrContentNode=childNode.getNode(JCR_CONTENT);
									if(jcrContentNode.hasNode(NODE_AUTOSUGGEST)){
										javax.jcr.Node autoSuggestnode=jcrContentNode.getNode(NODE_AUTOSUGGEST);
										userQuery=autoSuggestnode.getProperty(ATTR_USER_QUERY).getString()+"_"+autoSuggestnode.getProperty(ATTR_COLLECTION).getString();
										if(userQuery.equalsIgnoreCase(key.toString())){
											autoSuggestnode.setProperty(ATTR_ADMIN_BOOST,value);
										}
									}
								}
							}
						}else{ //otherwise iterate all the child nodes to check its userQuery and Collection property
							NodeIterator autosuggestChildListItr=rootNode.getNodes();
							while(autosuggestChildListItr.hasNext()){
								//iterate each node to check the userquery of that node
								childNode=autosuggestChildListItr.nextNode();
								if(childNode.getName().equals("jcr:content")){
									continue;
								}
								if(childNode.getProperty("jcr:primaryType").getString().equalsIgnoreCase(PAGE_RESOURCE_TYPE)){
									if(childNode.hasNode(JCR_CONTENT)){
										javax.jcr.Node jcrContentNode=childNode.getNode(JCR_CONTENT);
										if(jcrContentNode.hasNode(NODE_AUTOSUGGEST)){
											javax.jcr.Node autoSuggestnode=jcrContentNode.getNode(NODE_AUTOSUGGEST);
											userQuery=autoSuggestnode.getProperty(ATTR_USER_QUERY).getString()+"_"+autoSuggestnode.getProperty(ATTR_COLLECTION).getString();
											if(userQuery.equalsIgnoreCase(key.toString())){
												autoSuggestnode.setProperty(ATTR_ADMIN_BOOST,value);
											}
										}
									}
								}

							}
						}
					}
				}
			}
			session.save();
			response.sendRedirect("/cmsfeed/globalsearch/autosuggest.adminboost.html");
		}
		catch (RepositoryException e)  
		{
			logger.error(e.getMessage());
			output +="RepositoryException Error:<br>"+e.getMessage();
		}
		catch (Exception e) 
		{
			logger.error(e.getMessage());
			output +="Error:<br>"+e.getMessage();
		}

		response.setStatus(response.SC_OK);		
		response.setCharacterEncoding("US-ASCII");
		response.setContentType("text/html");
		Writer out = response.getWriter();
		out.write(output);
	}
    
	
	/**
	 * 
	 * @param mapStr
	 * @return
	 */
	protected Map<String,String> convertToMap(String mapStr){
		Map<String,String> map = new HashMap<String,String>();
		if(null!=mapStr){
			for(String str : mapStr.split(",")){
				if(!str.isEmpty() && str.contains(":")){
					if(str.split(":").length==2){
						map.put(str.split(":")[0], str.split(":")[1]);
					}else{
						map.put(str.split(":")[0], "");	
					}
					
				}
			}	
		}
		return map;
	}
	
	
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}