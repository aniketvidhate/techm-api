package com.att.ecom.cq.bundle.helpers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jcr.Node;
import javax.jcr.query.Query;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.text.Text;

/**
 * Miscellanous helper methods for working with paths.
 * 
 */
public class PathHelpers {
	private static final String ACCESSORY_FOLDER_PATH = "/content/att/%s/%s/wireless/accessories/%s";
	private static final String ACCESSORY_DETAIL_PATH = "/content/att/%s/%s/wireless/accessory.%s-%s-%s.html";
	private static final String ACCESSORY_FORWARD_PATH = "/content/att/%s/%s/wireless/accessories/%s/jcr:content";
    
    private static final Logger LOGGER = LoggerFactory.getLogger(PathHelpers.class);

	private static final String HTML = ".html";
	
	private static final String PERIOD = ".";
	
	private static final String EMPTY_STRING = "";

	private static final String ES = "es";

	private static final String EN = "en";
	
	private static final String EFFECTIVE_OUTOF_STOCK = "effectiveoutofstock";
	
	private static final String INSTOCK = "instock";
	
	private static final Set<String> ALLOWED_LANGUAGES;

	private static Map<String, String> englishDevicesMap;

	private static Map<String, String> spanishDevicesMap;
	
	private static Map<String, String> englishMobileDevicesMap;
	
	private static Map<String, String> spanishMobileDevicesMap;

	private static Map<String, String> englishAccessoriesMap;

	private static Map<String, String> spanishAccessoriesMap;

	private static Map<String, String> englishMobileAccessoriesMap;
	
	private static Map<String, String> spanishMobileAccessoriesMap;

	private static Map<String, String> englishPlansMap;

	private static Map<String, String> spanishPlansMap;

	private static Map<String, String> englishMobilePlansMap;
	
	private static Map<String, String> spanishMobilePlansMap;

	private static Map<String, String> englishPackagesMap;

	private static Map<String, String> spanishPackagesMap;

	private static Map<String, String> englishMobilePackagesMap;
	
	private static Map<String, String> spanishMobilePackagesMap;

	private static Map<String, String> englishServicesMap;

	private static Map<String, String> spanishServicesMap;

	private static Map<String, String> englishMobileServicesMap;
	
	private static Map<String, String> spanishMobileServicesMap;
	
	private static Map<String, String> rtiCustomerSkuMap;
	
	private static Map<String, String> skuMap;

	private static Map<String, String> accSkuMap;
	
	
	static {
	    Set<String> tempSet = new HashSet<String>();
	    tempSet.add(ES);
	    tempSet.add(EN);
	    ALLOWED_LANGUAGES = Collections.unmodifiableSet(tempSet);
	}

    /**
     * Get the URL String of a list page with a filter SKU
     * 
     * @param resourceResolver
     * @param listPage 
     * @param sku
     * @return the String URL for the list page
     */
    public static String getListPageURL(final ResourceResolver resourceResolver, final Page listPage, final String sku) {
        return getPageURL(resourceResolver, listPage, HTML, sku);
    }
    
    /**
     * Get the URL String of a page with selectors
     * 
     * @param resourceResolver
     * @param page 
     * @param sku
     * @return the String URL for the page with added selectors and extension
     */
    public static String getPageURL(final ResourceResolver resourceResolver, final Page page, final String extension, final String... selectors) {
        if (page != null && resourceResolver != null) {
            StringBuilder sb = new StringBuilder(resourceResolver.map(page.getPath()));
            for (String selector: selectors) {
                if (selector != null && !EMPTY_STRING.equals(selector)) {
                    sb.append(PERIOD);
                    sb.append(selector);
                }
            }
            String ext = null;
            if (extension == null) {
                ext = HTML;
            } else if (!extension.startsWith(PERIOD)) {
                ext = PERIOD + extension;
            } else {
                ext = extension;
            }
            sb.append(ext);
            return sb.toString();
        }
        return null;
    }    
    
	
	/**
	 * Get the Page object of a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the accessory details Page object
	 */
	public static Page getAccessoryDetailsPage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getAccessoryDetailsResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the accessory details Page object
	 */
	public static Page getAccessoryDetailsMobilePage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getAccessoryDetailsMobileResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the accessory details Page Object
	 */
	public static Page getAccessoryDetailsPage(final ResourceResolver resourceResolver, final String language, final String sku) {
		final Resource ddResource = getAccessoryDetailsResource(resourceResolver, language, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the accessory details Page Object
	 */
	public static Page getAccessoryDetailsMobilePage(final ResourceResolver resourceResolver, final String language, final String sku) {
		final Resource ddResource = getAccessoryDetailsMobileResource(resourceResolver, language, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Generate the path to a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the accessory details page path or null
	 */
	public static String getAccessoryDetailsPagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getAccessoryDetailsPagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the accessory details page path or null
	 */
	public static String getAccessoryDetailsMobilePagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getAccessoryDetailsMobilePagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the accessory details page path or null
	 */
	public static String getAccessoryDetailsPagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getAccessoryDetailsResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}
	
	public static String getDynamicAccessoryDetailsPagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku, final String displayName, String selector) {
		String path = "";
		String store = "shop";
		if (currentPage.getPath().contains("/shopmobile/")) {
			store = "shopmobile";
		}
		Resource detailsResource = getAccessoryDetailsResource(resourceResolver, currentPage, sku);
		if (detailsResource != null) {
			String folderName = detailsResource.getParent().getName();
			String accName = Slugify.slugify(displayName);  
			path = String.format(ACCESSORY_DETAIL_PATH, store, getLanguage(currentPage), selector + "." + folderName, accName, sku);
		}
		path = resourceResolver.map(path);
		return path;
	}
	
	public static String getDynamicAccessoryDetailsPagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku, final String displayName) {
		String path = "";
		String store = "shop";
		Resource detailsResource;
		detailsResource = getAccessoryDetailsResource(resourceResolver, currentPage, sku);
		if (currentPage.getPath().contains("/shopmobile/")) {
			store = "shopmobile";
			detailsResource = getAccessoryDetailsMobileResource(resourceResolver, currentPage, sku);
		}
		if (detailsResource != null) {
			String folderName = detailsResource.getParent().getName();
			String accName = Slugify.slugify(displayName);  
			path = String.format(ACCESSORY_DETAIL_PATH, store, getLanguage(currentPage), folderName, accName, sku);
		}
		path = resourceResolver.map(path);
		return path;
	}

	/**
	 * Generate the path to a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the accessory details page path or null
	 */
	public static String getAccessoryDetailsMobilePagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getAccessoryDetailsMobileResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}

	/**
	 * Get the Resource of a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the accessory details page resource
	 */
	public static Resource getAccessoryDetailsResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getAccessoryDetailsResource(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Get the Resource of a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the accessory details page resource
	 */
	public static Resource getAccessoryDetailsMobileResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getAccessoryDetailsMobileResource(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Get the Resource of a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the accessory details page resource
	 */
	public static Resource getAccessoryDetailsResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getAccessoryDetailsResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	/**
	 * Get the Resource of a accessory details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the accessory details page resource
	 */
	public static Resource getAccessoryDetailsMobileResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getAccessoryDetailsMobileResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	private static String getAccessoryDetailsResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishAccessoriesMap != null ? englishAccessoriesMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishAccessoriesMap != null ? spanishAccessoriesMap.get(sku) : null;
		} else {
			return null;
		}
	}

	private static String getAccessoryDetailsMobileResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishMobileAccessoriesMap != null ? englishMobileAccessoriesMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishMobileAccessoriesMap != null ? spanishMobileAccessoriesMap.get(sku) : null;
		} else {
			return null;
		}
	}

	/**
	 * Get the Page object of a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the device details Page object
	 */
	public static Page getDeviceDetailsPage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getDeviceDetailsResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a device details mobile page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the device details Page object
	 */
	public static Page getDeviceDetailsMobilePage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getDeviceDetailsMobileResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the device details Page Object
	 */
	public static Page getDeviceDetailsPage(final ResourceResolver resourceResolver, final String language, final String sku) {
		final Resource ddResource = getDeviceDetailsResource(resourceResolver, language, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Generate the path to a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the device details page path or null
	 */
	public static String getDeviceDetailsPagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getDeviceDetailsPagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the device details page path or null
	 */
	public static String getDeviceDetailsMobilePagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getDeviceDetailsMobilePagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the device details page path or null
	 */
	public static String getDeviceDetailsPagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getDeviceDetailsResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}

	/**
	 * Generate the path to a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the device details page path or null
	 */
	public static String getDeviceDetailsMobilePagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getDeviceDetailsMobileResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}

	/**
	 * Get the Resource of a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the device details page resource
	 */
	public static Resource getDeviceDetailsResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getDeviceDetailsResource(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Get the Resource of a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the device details page resource
	 */
	public static Resource getDeviceDetailsMobileResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getDeviceDetailsMobileResource(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Get the Resource of a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the device details page resource
	 */
	public static Resource getDeviceDetailsResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getDeviceDetailsResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	/**
	 * Get the Resource of a device details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the device details page resource
	 */
	public static Resource getDeviceDetailsMobileResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getDeviceDetailsMobileResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	public static String getDeviceDetailsResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishDevicesMap != null ? englishDevicesMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishDevicesMap != null ? spanishDevicesMap.get(sku) : null;
		} else {
			return null;
		}
	}

	private static String getDeviceDetailsMobileResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishMobileDevicesMap != null ? englishMobileDevicesMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishMobileDevicesMap != null ? spanishMobileDevicesMap.get(sku) : null;
		} else {
			return null;
		}
	}

	public static String getLanguage(final Page currentPage) {
	    String languageCode = currentPage.getLanguage(false).getLanguage();
	    if (ALLOWED_LANGUAGES.contains(languageCode)) {
	        return languageCode;
	    } else {
	        final String languagePath = Text.getAbsoluteParent(currentPage.getPath(), 3);
	        if (StringUtils.isNotBlank(languagePath)) {
	            return StringUtils.substringAfterLast(languagePath, "/");
	        } else {
	            LOGGER.warn("Unable to determine language code for {}. Assuming English.", currentPage.getPath());
	            return EN;
	        }
	    }
	}

	/**
	 * Get the Page object of a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the package details Page object
	 */
	public static Page getPackageDetailsPage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getPackageDetailsResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the package details Page object
	 */
	public static Page getPackageDetailsMobilePage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getPackageDetailsMobileResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the package details Page Object
	 */
	public static Page getPackageDetailsPage(final ResourceResolver resourceResolver, final String language, final String sku) {
		final Resource ddResource = getPackageDetailsResource(resourceResolver, language, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the package details Page Object
	 */
	public static Page getPackageDetailsMobilePage(final ResourceResolver resourceResolver, final String language, final String sku) {
		final Resource ddResource = getPackageDetailsMobileResource(resourceResolver, language, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Generate the path to a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the package details page path or null
	 */
	public static String getPackageDetailsPagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getPackageDetailsPagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the package details page path or null
	 */
	public static String getPackageDetailsMobilePagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getPackageDetailsMobilePagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the package details page path or null
	 */
	public static String getPackageDetailsPagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getPackageDetailsResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}

	/**
	 * Generate the path to a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the package details page path or null
	 */
	public static String getPackageDetailsMobilePagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getPackageDetailsMobileResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}

	/**
	 * Get the Resource of a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the package details page resource
	 */
	public static Resource getPackageDetailsResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getPackageDetailsResource(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Get the Resource of a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the package details page resource
	 */
	public static Resource getPackageDetailsMobileResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getPackageDetailsResource(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Get the Resource of a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the package details page resource
	 */
	public static Resource getPackageDetailsResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getPackageDetailsResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	/**
	 * Get the Resource of a package details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the package details page resource
	 */
	public static Resource getPackageDetailsMobileResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getPackageDetailsMobileResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	private static String getPackageDetailsResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishPackagesMap != null ? englishPackagesMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishPackagesMap != null ? spanishPackagesMap.get(sku) : null;
		} else {
			return null;
		}
	}

	private static String getPackageDetailsMobileResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishMobilePackagesMap != null ? englishMobilePackagesMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishMobilePackagesMap != null ? spanishMobilePackagesMap.get(sku) : null;
		} else {
			return null;
		}
	}

	/**
	 * Get the Page object of a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the plan details Page object
	 */
	public static Page getPlanDetailsPage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getPlanDetailsResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the plan details Page object
	 */
	public static Page getPlanDetailsMobilePage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getPlanDetailsMobileResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the plan details Page Object
	 */
	public static Page getPlanDetailsPage(final ResourceResolver resourceResolver, final String language, final String sku) {
		final Resource ddResource = getPlanDetailsResource(resourceResolver, language, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}
	/**
	 * Get the Page object of a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the plan details Page Object
	 */
	public static Page getPlanDetailsMobilePage(final ResourceResolver resourceResolver, final String language, final String sku) {
		final Resource ddResource = getPlanDetailsMobileResource(resourceResolver, language, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Generate the path to a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the plan details page path or null
	 */
	public static String getPlanDetailsPagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getPlanDetailsPagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the plan details page path or null
	 */
	public static String getPlanDetailsMobilePagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getPlanDetailsMobilePagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the plan details page path or null
	 */
	public static String getPlanDetailsPagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getPlanDetailsResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}

	/**
	 * Generate the path to a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the plan details page path or null
	 */
	public static String getPlanDetailsMobilePagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getPlanDetailsMobileResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}

	/**
	 * Get the Resource of a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the plan details page resource
	 */
	public static Resource getPlanDetailsResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getPlanDetailsResource(resourceResolver, getLanguage(currentPage), sku);
	}
	/**
	 * Get the Resource of a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the plan details page resource
	 */
	public static Resource getPlanDetailsMobileResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getPlanDetailsMobileResource(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Get the Resource of a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the plan details page resource
	 */
	public static Resource getPlanDetailsResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getPlanDetailsResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	/**
	 * Get the Resource of a plan details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the plan details page resource
	 */
	public static Resource getPlanDetailsMobileResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getPlanDetailsMobileResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	private static String getPlanDetailsResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishPlansMap != null ? englishPlansMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishPlansMap != null ? spanishPlansMap.get(sku) : null;
		} else {
			return null;
		}
	}

	private static String getPlanDetailsMobileResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishMobilePlansMap != null ? englishMobilePlansMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishMobilePlansMap != null ? spanishMobilePlansMap.get(sku) : null;
		} else {
			return null;
		}
	}

	/**
	 * Get the Page object of a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the service details Page object
	 */
	public static Page getServiceDetailsPage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getServiceDetailsResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the service details Page object
	 */
	public static Page getServiceDetailsMobilePage(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		final Resource ddResource = getServiceDetailsMobileResource(resourceResolver, currentPage, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the service details Page Object
	 */
	public static Page getServiceDetailsPage(final ResourceResolver resourceResolver, final String language, final String sku) {
		final Resource ddResource = getServiceDetailsResource(resourceResolver, language, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Get the Page object of a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the service details Page Object
	 */
	public static Page getServiceDetailsMobilePage(final ResourceResolver resourceResolver, final String language, final String sku) {
		final Resource ddResource = getServiceDetailsMobileResource(resourceResolver, language, sku);
		if (ddResource != null) {
			return ddResource.adaptTo(Page.class);
		}
		return null;
	}

	/**
	 * Generate the path to a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the service details page path or null
	 */
	public static String getServiceDetailsPagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getServiceDetailsPagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the service details page path or null
	 */
	public static String getServiceDetailsMobilePagePath(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getServiceDetailsMobilePagePath(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Generate the path to a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the service details page path or null
	 */
	public static String getServiceDetailsPagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getServiceDetailsResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}

	/**
	 * Generate the path to a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the service details page path or null
	 */
	public static String getServiceDetailsMobilePagePath(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getServiceDetailsMobileResourcePath(language, sku);
		return path != null ? path + HTML : null;
	}

	/**
	 * Get the Resource of a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the service details page resource
	 */
	public static Resource getServiceDetailsResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getServiceDetailsResource(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Get the Resource of a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param currentPage
	 * @param sku
	 * @return the service details page resource
	 */
	public static Resource getServiceDetailsMobileResource(final ResourceResolver resourceResolver, final Page currentPage, final String sku) {
		return getServiceDetailsMobileResource(resourceResolver, getLanguage(currentPage), sku);
	}

	/**
	 * Get the Resource of a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the service details page resource
	 */
	public static Resource getServiceDetailsResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getServiceDetailsResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	/**
	 * Get the Resource of a service details page from a SKU.
	 * 
	 * @param resourceResolver
	 * @param language
	 * @param sku
	 * @return the service details page resource
	 */
	public static Resource getServiceDetailsMobileResource(final ResourceResolver resourceResolver, final String language, final String sku) {
		final String path = getServiceDetailsMobileResourcePath(language, sku);
		if (path != null) {
			return resourceResolver.resolve(path);
		}
		return null;
	}

	private static String getServiceDetailsResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishServicesMap != null ? englishServicesMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishServicesMap != null ? spanishServicesMap.get(sku) : null;
		} else {
			return null;
		}
	}
	
	/**
	 * method to look for all the maps and return a details page url for a passed in sku with language
	 * currently only looks for devices, accessory and packages
	 * @param language
	 * @param sku
	 * @return url
	 */
	public static String getDetailsPageResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			if(englishDevicesMap.get(sku)!=null){
				return englishDevicesMap.get(sku);
			}
			else if(englishAccessoriesMap != null){
				return englishAccessoriesMap.get(sku);
			}
			else if(englishPackagesMap != null){
				return englishPackagesMap.get(sku);
			}				
		} else if (ES.equals(language)) {
			if(spanishDevicesMap.get(sku)!=null){
				return spanishDevicesMap.get(sku);
			}
			else if(spanishAccessoriesMap != null){
				return spanishAccessoriesMap.get(sku);
			}
			else if(spanishPackagesMap != null){
				return spanishPackagesMap.get(sku);
			}	
		} 
		return null;
	}

	private static String getServiceDetailsMobileResourcePath(final String language, final String sku) {
		if (EN.equals(language)) {
			return englishMobileServicesMap != null ? englishMobileServicesMap.get(sku) : null;
		} else if (ES.equals(language)) {
			return spanishMobileServicesMap != null ? spanishMobileServicesMap.get(sku) : null;
		} else {
			return null;
		}
	}


	static void setData(Map<String, Map<String, Map<String, String>>> dataMap) {
		Map<String, Map<String, String>> english = dataMap.get(EN);
		Map<String, Map<String, String>> spanish = dataMap.get(ES);

		englishDevicesMap = english != null ? english.get("devices") : null;
		spanishDevicesMap = spanish != null ? spanish.get("devices") : null;

		englishMobileDevicesMap = english != null ? english.get("m_devices") : null;
		spanishMobileDevicesMap = spanish != null ? spanish.get("m_devices") : null;

		englishAccessoriesMap = english != null ? english.get("accessories") : null;
		spanishAccessoriesMap = spanish != null ? spanish.get("accessories") : null;

		englishMobileAccessoriesMap = english != null ? english.get("m_accessories") : null;
		spanishMobileAccessoriesMap = spanish != null ? spanish.get("m_accessories") : null;

		englishPlansMap = english != null ? english.get("plans") : null;
		spanishPlansMap = spanish != null ? spanish.get("plans") : null;

		englishMobilePlansMap = english != null ? english.get("m_plans") : null;
		spanishMobilePlansMap = spanish != null ? spanish.get("m_plans") : null;

		englishPackagesMap = english != null ? english.get("packages") : null;
		spanishPackagesMap = spanish != null ? spanish.get("packages") : null;

		englishMobilePackagesMap = english != null ? english.get("m_packages") : null;
		spanishMobilePackagesMap = spanish != null ? spanish.get("m_packages") : null;

		englishServicesMap = english != null ? english.get("services") : null;
		spanishServicesMap = spanish != null ? spanish.get("services") : null;

		englishMobileServicesMap = english != null ? english.get("m_services") : null;
		spanishMobileServicesMap = spanish != null ? spanish.get("m_services") : null;

	}
	
	static void setRTIData(Map<String, String> rtidataMap) {	
		rtiCustomerSkuMap = rtidataMap != null ? rtidataMap : null;
	}

	/**
	 * get the effective out of stock of a passed in sku.
	 * 
	 * @param sku
	 * @return In Stock or Out of Stock
	 */
	public static String getEffectiveOutOfStockStatus(ResourceResolver resourceResolver,final String sku) {
			LOGGER.debug("getEffectiveOutOfStockStatus method called for sku:"+sku);

			Resource skuResource = resourceResolver.resolve("/etc/att/rti/customerskus/"+sku);
			LOGGER.debug("getEffectiveOutOfStockStatus customerSkuResource:"+skuResource);
			Page skuPage = null;
			if (skuResource != null) {
				skuPage =  skuResource.adaptTo(Page.class);
				if(null != skuPage){
					return skuPage.getProperties().get(EFFECTIVE_OUTOF_STOCK,null);
				}else{
					LOGGER.error("SKU Page NOT FOUND. Returning default status for:"+ sku);
					return INSTOCK;
				}
			}else{
				LOGGER.error("SKU Resource NOT FOUND. Returning default status for:"+ sku);
				return INSTOCK;
			}
	}
	
	
	
	public static List<String> getAllOutOfStockSkuIds(ResourceResolver resourceResolver){
		List<String> currentOutOfStockSkuIds = new ArrayList<String>();
		
		String query = "select * from nt:base where jcr:path like '/etc/att/rti/customerskus/%' and effectiveoutofstock = 'outofstock'";
		for (Iterator<Resource> resourceItr = resourceResolver.findResources(query, Query.SQL); resourceItr.hasNext();) {
			Resource outOfStockResource = (Resource) resourceItr.next();
			
			currentOutOfStockSkuIds.add(outOfStockResource.getParent().getName());
		}
		LOGGER.info("[RTI] - Responding with out of stock skus"+ currentOutOfStockSkuIds);
		return currentOutOfStockSkuIds;
		
	}
	
	
	/**
	 * method to return customer sku url for effective oos 
	 * @param skuid
	 * @return customerskuurl
	 */
	public static String getRtiCustomerSkuPath(String skuid){
		return rtiCustomerSkuMap != null ? rtiCustomerSkuMap.get(skuid) : null;
	}
	
	public static String getSharedDeviceContent(String skuId, String productId, ResourceResolver resourceResolver) {
	
		String productType = "devices";
		String contentPath = getSharedProductContent(skuId, productId, productType, resourceResolver);
		
		return contentPath;
	}
	
	public static String getSharedProductContent(String skuid, String productId, String productType, ResourceResolver resourceResolver) {
		String contentPath = "";
		final String basePath = "/content/sharedcontent/" + productType + "/"; 
	
		String productPath = basePath + "/" + productId; 
		String skuPath = productPath + "/" + skuid;
	
		//check for existing page on sku level then check product level
		Resource skuResource = resourceResolver.getResource(skuPath);
		if (skuResource != null) {
			contentPath = skuPath;
		} else {
			Resource productResource = resourceResolver.getResource(productPath);
			if (productResource != null) {
				contentPath = productPath;
			}
		}
		return contentPath;
	}
	
	public static void setSharedData(Map<String,String> skus) {
		skuMap = skus;
	}

	public static void setAccSharedData(Map<String,String> skus) {
		accSkuMap = skus;
	}
	
	public static SharedContentItem getSharedContentItem(String skuId, ResourceResolver resourceResolver) {
		SharedContentItem content = null;
		
		if (skuMap.containsKey(skuId)) {
			String path = skuMap.get(skuId);
			if (path != null) {
				content = new SharedContentItem(path, resourceResolver);
			}
		}
		
		return content;
	}

	public static AccessorySharedItem getAccSharedContentItem(String skuId, ResourceResolver resourceResolver) {
		AccessorySharedItem content = null;
		
		if (accSkuMap != null && accSkuMap.containsKey(skuId)) {
			String path = accSkuMap.get(skuId);
			if (path != null) {
				content = new AccessorySharedItem(path, resourceResolver);
			}
		}
		
		return content;
	}
	
	
	
	
	
	/**
	 * Helper method to return the node with the specification content needed based on that value passed in.
	 * @param specTag
	 * @param skuId
	 * @param productId
	 * @param resourceResolver
	 * @return returns the {@link Node} object representing the specification needed
	 */
	public static Node getSpecNode(String specTag, String skuId, String productId, ResourceResolver resourceResolver) {
		Node resultNode = null;
		
		String contentPath = getSharedContentItem(skuId, resourceResolver).getContentPath();
		String tagQuery = String.format("select * from nt:unstructured where jcr:path like '%s' and cq:tags = '%s'", contentPath, specTag);
		
		
		Iterator<Resource> taggedResources = resourceResolver.findResources(tagQuery, Query.SQL);
		if (taggedResources.hasNext()) {
			Resource taggedResource = taggedResources.next();
			resultNode = taggedResource.adaptTo(Node.class);
		}
		
		return resultNode;
	}
	
	public static boolean isAccessoryFolder(ResourceResolver resourceResolver, Page currentPage, String folderName) {
		boolean isFolder = false;
		
		String store = "shop";
		if (currentPage.getPath().contains("/shopmobile/")) {
			store = "shopmobile";
		}
		String accFolderPath = String.format(ACCESSORY_FOLDER_PATH, store, getLanguage(currentPage), folderName);
		if (resourceResolver.getResource(accFolderPath) != null) {
			isFolder = true;
		}
		return isFolder;
	}
	
	public static String getDynamicAccessoryForwardPath(Page currentPage, String folderName, String sku) {
		String path = "";
		String store = "shop";
		if (currentPage.getPath().contains("/shopmobile/")) {
			store = "shopmobile";
		}
		path = String.format(ACCESSORY_FORWARD_PATH, store, getLanguage(currentPage), folderName + sku);
		return path;
	}
	
	private PathHelpers() {
	}
}
