package com.att.ecom.cq.bundle.helpers;

import java.util.Comparator;
import com.day.cq.wcm.api.Page;
import org.apache.sling.api.resource.Resource;

  class CompareLength implements Comparator {
	  public int compare(Object o1, Object o2) {
	    Resource p1 = (Resource)o1;
	    Resource p2 = (Resource)o2;
	    
	    int page1 = Integer.parseInt(p1.getName());
	    int page2 = Integer.parseInt(p2.getName());
	    
	    if(page1 > page2)	 
          return 1;	 
	    else if(page1 < page2)	 
          return -1;	 
	    else
           return 0;    
	  }  
	}  
