package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferenceCardinality;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.NonExistingResource;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;

import javax.jcr.Node;


@Component(immediate=true, metatype=false)
@Service(value=javax.servlet.Filter.class)
@Properties({
    @Property(name="service.description", value="Resource Validation Filter"),
    @Property(name="service.vendor", value="Resource Validation Filter"),
    @Property(name="filter.scope", value="request"),
    @Property(name="sling.filter.scope", value="request")
})
public class ResourceValidationFilter implements Filter {
	
	private static final Logger mLogger = LoggerFactory.getLogger(ResourceValidationFilter.class);
	
	//@Reference
    //private ResourceResolverFactory resourceResolverFactory;
	
	//private ResourceResolver resolver = null;			
	
	public void destroy() {
		// NO-OP - lifecycle is in deactivate()
	}

	@Override 
	public void doFilter(ServletRequest req, ServletResponse rsp,
			FilterChain chain) throws IOException, ServletException {
		
		
				HttpServletRequest hreq = (HttpServletRequest) req;				
				HttpServletResponse hrsp = (HttpServletResponse) rsp;	
				/*							
				try {
					resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
					Resource resource = resolver.resolve(hreq.getRequestURI());					
					if(resource != null && !(resource instanceof NonExistingResource) && resource.getPath().startsWith("/content/att")) {
						//get only content node
						resource = resolver.resolve(resource.getPath()+"/jcr:content");
						//get only those resource which have jcr:content
						if(resource != null && !(resource instanceof NonExistingResource)){
							//get node
							Node node = resource.adaptTo(Node.class);
							String strResourceType = "";
							//if node has resource type
							if(node.hasProperty("sling:resourceType")){
								strResourceType = node.getProperty("sling:resourceType").getString();
								if(strResourceType.startsWith("/")){
									if(!ValidateResource(strResourceType))
										hrsp.sendError(HttpServletResponse.SC_NOT_FOUND);
								}else{
									//check if the resource is in /apps or /libs
									if(!ValidateResource("/apps/"+strResourceType) && !ValidateResource("/libs/"+strResourceType))
										hrsp.sendError(HttpServletResponse.SC_NOT_FOUND);									
								}								
							}
							//if node has resource type
							else if(node.hasProperty("sling:resourceSuperType")){
								strResourceType = node.getProperty("sling:resourceSuperType").getString();							
								if(strResourceType.startsWith("/")){
									if(!ValidateResource(strResourceType))
										hrsp.sendError(HttpServletResponse.SC_NOT_FOUND);
								}else{
									//check if the resource is in /apps or /libs
									if(!ValidateResource("/apps/"+strResourceType) && !ValidateResource("/libs/"+strResourceType))
										hrsp.sendError(HttpServletResponse.SC_NOT_FOUND);									
								}
							} 
							//no resource type
							else{								
								hrsp.sendError(HttpServletResponse.SC_NOT_FOUND);								
							}
							
						}
					}					
				} catch (LoginException e) {
					mLogger.error("Error encounterd while obtaining ResourceResolver from factory.", e);
				}catch (javax.jcr.PathNotFoundException e) {
					mLogger.error("Error encounterd while obtaining ResourceResolver from factory.", e);
				}catch (javax.jcr.ValueFormatException e) {
					mLogger.error("Error encounterd while obtaining ResourceResolver from factory.", e);
				}catch (javax.jcr.RepositoryException e) {
					mLogger.error("Error encounterd while obtaining ResourceResolver from factory.", e);
				}
				
				
				finally {
					if(resolver != null) {
						resolver.close();
					}
				}			
				*/	
		chain.doFilter(hreq, rsp); // go on our merry way...
	}
	/*
	private Boolean ValidateResource(String path){		
		Resource resource = resolver.resolve(path);
		if(resource == null || (resource instanceof NonExistingResource)){
			return false;			
		}
		return true;		
	}*/

	public void init(FilterConfig cfg) throws ServletException {
		// NO-OP - lifecycle is in activate()
	}

}
