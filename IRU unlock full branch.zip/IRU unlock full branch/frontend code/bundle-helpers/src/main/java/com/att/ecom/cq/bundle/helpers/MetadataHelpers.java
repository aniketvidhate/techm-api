package com.att.ecom.cq.bundle.helpers;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;

import com.day.cq.wcm.api.Page;

/**
 * Miscellanous helper methods for retrieving metadata information 
 *
 */
public class MetadataHelpers {
	
	private MetadataHelpers() {
	}
	
	public static String getDateLastModifiedString(Page page) {
		return getDateLastModifiedString(page.getContentResource(), null);
	}	
	
	public static String getDateLastModifiedString(Page page, String format) {
		return getDateLastModifiedString(page.getContentResource(), format);
	}
	
	public static String getDateLastModifiedString(Resource resource) {
		return getDateLastModifiedString(resource, null);
	}
		
	public static String getDateLastModifiedString(Resource resource, String format) {
		//defaults to the Julian Date
		String dateFormat = "yyyyDDD";
		
		DateFormat df = null;
		try {
			if (format != null && !"".equals(format)) {
				dateFormat = format;
			}
			df = new SimpleDateFormat(dateFormat);
		} catch (Exception e) {
			df = new SimpleDateFormat(dateFormat);
		}
		return df.format(getDateLastModified(resource)); 
	}
	
	public static Date getDateLastModified(Page page) {
		return getDateLastModified(page.getContentResource());
	}
	
	public static Date getDateLastModified(Resource resource) {
		ValueMap properties = resource.adaptTo(ValueMap.class);
		Date lastMod = null;
		if (properties != null) {
			lastMod = properties.get("jcr:lastModified", Date.class);
			if (lastMod == null) {
				lastMod = properties.get("cq:lastModified", Date.class);
			}
		}
		if (lastMod != null) {
			return lastMod;
		}
		return new Date();
	}
	
	public static String getAccessoryType(Resource resource) {
		ValueMap properties = resource.getParent().getChild("jcr:content").adaptTo(ValueMap.class);
		String type = "";
		if (properties != null) {
			type = properties.get("jcr:title", String.class);
		}
		if (type != null) {
			return type.toLowerCase();
		}
		return "";
	}
	
	public static String getDeviceType(Resource resource) {
		String type = "";
		if (resource != null) {
			
		}
		return type;
	}
	
	public static String getCQPath(Node node, String pathValue) {
		String path = "";
		try {
			String nodepath= node.getCorrespondingNodePath(node.getSession().getWorkspace().getName());                                           
			int indexofPathValue=nodepath.lastIndexOf(pathValue); 
			indexofPathValue = indexofPathValue+pathValue.length()+1;              
			String cqPath=nodepath.substring(indexofPathValue) ;                     	
	        
	        path = cqPath;
		} catch (RepositoryException e) {
			path = "unknown";
		}
		return path;
	}
}