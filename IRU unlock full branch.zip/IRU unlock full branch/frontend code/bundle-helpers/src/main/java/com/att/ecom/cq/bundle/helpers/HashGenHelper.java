/* 
 * . Adding class to get Noide UUID and then it's portion for data-cqpath
 * @author Chaturkumar (cg975w) 
 * @created on Apr 11 2014 
 */ 
 
 
package com.att.ecom.cq.bundle.helpers; 
 
import java.math.BigInteger;
import java.security.MessageDigest;

import javax.jcr.Node;
import java.text.Format;
import java.util.Date;


import org.apache.commons.lang.time.FastDateFormat;
import org.apache.felix.scr.annotations.Property;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.ResourceResolver; 
 
import org.slf4j.Logger; 
import org.slf4j.LoggerFactory; 
 
public class HashGenHelper { 
	
	static final String FMT_PATH_AND_DATE = ";%tY%<tj";
	
	static Logger logger = LoggerFactory.getLogger(HashGenHelper.class); 
	
	// This method IS ALSO DEFINED AS IS in CSVDumpServlet.java in the reporting module. Any changes here should be done there also.
	
	public static String getMd5ForResource(String path){
		
		String hashedPath = " ";
		
		if (StringUtils.isNotBlank(path)) {
			try {
				MessageDigest messageDigest=MessageDigest.getInstance("MD5");
				messageDigest.update(path.getBytes(),0,path.length());
				hashedPath = new BigInteger(1,messageDigest.digest()).toString();
				logger.debug("The Hashed Server Name is:"+hashedPath);
			} catch (Exception e) {
				logger.error("Unable to Hash", e);				
			} 
		}
		return hashedPath;
	}
	
	//End of Remove
	
// This method IS ALSO DEFINED AS IS in CSVDumpServlet.java in the reporting module. Any changes here should be done there also.
public static String getMd5ForResource(String path, ResourceResolver resolver){
		
		String hashedPath = "";
		String jDate = null;
			
		try {
			Node n = resolver.getResource(path).adaptTo(Node.class);
			if (n != null) {
				//Node kNode = n.getParent().getParent();
				if(n.hasProperty("jcr:lastModified")) {
					
					Date pdate = n.getProperty("jcr:lastModified").getDate().getTime();
					jDate = String.format(FMT_PATH_AND_DATE, pdate);
					
				} else if (n.hasProperty("cq:lastModified")) {
					Date pdate = n.getProperty("cq:lastModified").getDate().getTime();
					jDate = String.format(FMT_PATH_AND_DATE, pdate);
				} else {
					jDate = "";
				}
			}
		}
		catch (Exception e) { 
			logger.error("Unable to get LastModified property", e);
		} 
		
		if (StringUtils.isNotBlank(path)) {
			try {
				MessageDigest messageDigest=MessageDigest.getInstance("MD5");
				messageDigest.update(path.getBytes(),0,path.length());
				hashedPath = new BigInteger(1,messageDigest.digest()).toString();
				logger.debug("The Hashed Server Name is:"+hashedPath);
			} catch (Exception e) {
				logger.error("Unable to getMD5 value", e);				
			} 
		}
		return hashedPath + jDate;
	}	
}