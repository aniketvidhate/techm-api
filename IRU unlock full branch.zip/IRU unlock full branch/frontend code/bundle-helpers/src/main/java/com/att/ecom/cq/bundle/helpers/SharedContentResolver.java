package com.att.ecom.cq.bundle.helpers;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.framework.AdminPermission;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.SearchResult;
import com.day.cq.wcm.api.Page;


@Component(immediate=true)
@Service(value=SharedContentResolver.class)
public class SharedContentResolver {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private final String CATALOG_TOOLS_PATH = "dynamo:/atg/commerce/catalog/CatalogTools";
	
	private Map<String, String> skuIds = new HashMap<String, String>();
	private Map<String, String> accSkuIds = new HashMap<String, String>();
	
	@Reference
	private SlingRepository slingRepository;
	
	@Reference
	private QueryBuilder queryBuilder;
	
	public SharedContentResolver() {
		
	}

	protected void activate(ComponentContext ctx) throws RepositoryException {
		
		reloadSharedContent();
		reloadAccessorySharedContent();
	}
	
	protected void deactivate(ComponentContext ctx) {
		logger.info("deactivating SharedContentResolver");
	}
	
	public synchronized void reloadSharedContent() throws RepositoryException {
		Session administrativeSession = slingRepository.loginAdministrative(null);
		
		if (administrativeSession.isLive()) {
			Map<String, String> predicates = new HashMap<String, String>();
			predicates.put("path", "/content/sharedcontent");
			predicates.put("type", "cq:Page");
			predicates.put("property", "jcr:content/sling:resourceType");
			predicates.put("property.value", "att/wireless/components/page/sharedcontent/shareddetails");
			
			Query query = queryBuilder.createQuery(PredicateGroup.create(predicates), administrativeSession);
			SearchResult results = query.getResult();
			
			Iterator<Node> nodes = results.getNodes();
			while(nodes.hasNext()) {
				Node resultNode = nodes.next();
				if (resultNode != null) {
					String resultNodeName = resultNode.getName();
					if (resultNodeName.startsWith("sku")) {
						addSkuPage(resultNode);
					}
				}
				
			}
		}
		PathHelpers.setSharedData(skuIds);
		administrativeSession.logout();
	}
	
	public synchronized void reloadAccessorySharedContent() throws RepositoryException {
		Session administrativeSession = slingRepository.loginAdministrative(null);
		
		if (administrativeSession.isLive()) {
			Map<String, String> predicates = new HashMap<String, String>();
			predicates.put("path", "/content/sharedcontent");
			predicates.put("type", "cq:Page");
			predicates.put("property", "jcr:content/sling:resourceType");
			predicates.put("property.value", "att/wireless/components/page/sharedcontent/accessoryshareddetails");
			
			Query query = queryBuilder.createQuery(PredicateGroup.create(predicates), administrativeSession);
			SearchResult results = query.getResult();
			
			Iterator<Node> nodes = results.getNodes();
			while(nodes.hasNext()) {
				Node resultNode = nodes.next();
				if (resultNode != null) {
					String resultNodeName = resultNode.getName();
					if (resultNodeName.startsWith("sku")) {
						addAccSkuPage(resultNode);
					}
				}
				
			}
		}
		PathHelpers.setAccSharedData(accSkuIds);
		administrativeSession.logout();
	}
		
	private void addSkuPage(Node skuNode) {
		try {
			skuIds.put(skuNode.getName(), skuNode.getPath());
		} catch (RepositoryException ex) {
			logger.error("Error adding sku to map", ex);
		}
	}

	private void addAccSkuPage(Node skuNode) {
		try {
			accSkuIds.put(skuNode.getName(), skuNode.getPath());
		} catch (RepositoryException ex) {
			logger.error("Error adding sku to map", ex);
		}
	}
}
