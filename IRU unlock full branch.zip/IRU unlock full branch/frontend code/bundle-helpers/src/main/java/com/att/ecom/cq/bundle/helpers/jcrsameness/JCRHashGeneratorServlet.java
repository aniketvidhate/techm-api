/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.jcr.Node;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.PersistableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * It generates the MD5 hash for each node in JCR repository from the specified starting JCR location. It returns the
 * text file, each row (or line) in text file contains the cq path of a node and it's MD5 hash code separated by
 * colon(:).Also, at the end of the each line "isPage=true/false" will be appended to identify the path is of a page or
 * page's node.
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884)
 * @Since Dec 26, 2012 2:43:39 PM
 */

@SlingServlet(methods = { "GET" }, paths = { "/system/att/servlets/jcrhashgenerator" })
public class JCRHashGeneratorServlet extends SlingAllMethodsServlet {

    /**
     * Serial Version UID
     */
    private static final long serialVersionUID = 1L;

    public static final Logger LOGGER = LoggerFactory.getLogger(JCRHashGeneratorServlet.class);

    public static final String EXCLUDED_PROPERTIES = "excludedProperties";
    
    public static final String EXCLUDED_NODES = "excludedNodes";

    public static final String PATH = "path";
    
    public static final String INCLUDE_DEACTIVATED_NODES = "inclDeactivatedNodes";
    
    public static final String CHECK_PAGE_ORDER = "checkPageOrder";
    
    public static final String CHECK_INTERMEDIATE_NODES_SAMENESS = "checkIntermediateNodesSameness";

    public static final String MODE = "mode";
    
    @Reference
    private ResourceResolverFactory resourceResolverFactory;

    @Reference
    private JCRSamenessToolHelper mJCRSamenessToolHelper;

    @Reference
    private JCRHashGeneratorConfig mJCRHashGeneratorConfig;

    /**
     * This will generate a text file. It's each line contains the cq path and it's MD5 hash value separated by
     * colon(:).
     * 
     * @param pRequest
     *            a HttpServletRequest value.
     * @param pResponse
     *            a HttpServletResponse value.
     * @exception ServletException
     *                if there was an error while executing the code.
     * @exception IOException
     *                if there was an error with servlet io.
     */
    protected void doGet(SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse) throws ServletException,
            IOException {
        LOGGER.info("JCR Hash generation process started");
        
        long startTime = System.currentTimeMillis();
        ResourceResolver adminResolver = null;
        ObjectOutputStream objectOutputStream = null;
        SortedMap<String, String> cqPathToCQPathHashValueMap = null;
        Set<String> deactivatedNodes = new TreeSet<String>();
        JCRHashGeneratorRequest inputBean = getRequestParams(pRequest);
        if (inputBean == null) {
            return;
        }
        boolean sufficientInput = validate(inputBean);
        
        if (sufficientInput) {
            try {
            
                LOGGER.info("JCR Hash generation Input Params -- "+ inputBean.toString());
                
                // STEP 1 - get the node for a given path
                adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
                Resource resource = adminResolver.getResource(inputBean.getPath());
                Node startNode = resource.adaptTo(Node.class);
                if (startNode == null) {
                    LOGGER.error("JCR Hash generation process stopped. Unable to find the node for the specified path - "
                            + inputBean.getPath());
                    return;
                }

                cqPathToCQPathHashValueMap = new TreeMap<String, String>();

                pResponse.setHeader("Dispatcher", "no-cache");
                pResponse.setHeader("Cache-Control", "no-cache,no-store,must-revalidate");

                // STEP 2 - start traversing the tree from that starting node and generate hash
                mJCRSamenessToolHelper.calculateHashValueForEachNode(startNode, cqPathToCQPathHashValueMap, adminResolver,
                        inputBean,deactivatedNodes);
                if (inputBean.getMode() == 1) {
                    // Send only the root hash value for the given JCR path
                    pResponse.setContentType("text/plain"); 
                    final PrintWriter out = pResponse.getWriter();
                    String rootHashValueRaw = cqPathToCQPathHashValueMap.get(inputBean.getPath());
                    if (StringUtils.isNotEmpty(rootHashValueRaw)) {
                        String[] rootHashValueArray = rootHashValueRaw.split(",");
                        if (rootHashValueArray != null && rootHashValueArray.length > 0) {
                            String rootHashValue = null;
                            if (rootHashValueArray.length == 1) {
                                rootHashValue = rootHashValueArray[0];

                            } else if (rootHashValueArray.length > 1) {
                                rootHashValue = rootHashValueArray[1];                                
                            }
                            if (rootHashValue != null && rootHashValue.indexOf(":isPage") > 0) {
                                rootHashValue = rootHashValue.substring(0, rootHashValue.indexOf(":isPage"));
                            }
                            out.print(rootHashValue);                            
                        }
                    } else {
                        out.print("ERROR: Unable to calculate root hash value");
                    }
                    out.close();                    
                } else if (inputBean.getMode() == 2) {
                    pResponse.setContentType("text/plain"); 
                    final PrintWriter out = pResponse.getWriter();
                    PersistableValueMap valueMapOfCurrentNode = mJCRSamenessToolHelper.getValueMap(startNode.getPath(), adminResolver);
                    String currentNodeConcatenatedString = mJCRSamenessToolHelper.getConcatenatedPropertyValues(valueMapOfCurrentNode,
                            inputBean, adminResolver, startNode);
                    out.print(currentNodeConcatenatedString); 
                    out.close(); 
                } else {
                    pResponse.setContentType("application/octet-stream");
                    objectOutputStream = new ObjectOutputStream(pResponse.getOutputStream());
                    objectOutputStream.writeObject(cqPathToCQPathHashValueMap);
                }
            } catch (Exception e) {
                LOGGER.error("Error while traversing the JCR content tree ", e);
                e.printStackTrace();
            } finally {
                cqPathToCQPathHashValueMap = null;
                if (objectOutputStream != null) {
                    objectOutputStream.close();
                }
                if (adminResolver != null) {
                    adminResolver.close();
                }
                LOGGER.info("JCR Hash generation process completed. Total time - " + (System.currentTimeMillis() - startTime) / 1000 + " seconds");
            }
        } else {
            LOGGER.error("No SUFICIENT INPUT. Reason - " + inputBean.getValidateFailedReason());
            pResponse.setStatus(HttpServletResponse.SC_EXPECTATION_FAILED);
        }
    }

    /**
     * It validates the input parameters and returns true if valid, returns false otherwise.
     */
    private boolean validate(JCRHashGeneratorRequest pInputBean) {
        if (pInputBean == null) {
            return false;
        }
        if (StringUtils.isEmpty(pInputBean.getPath())) {
            pInputBean.setValidateFailedReason("path input is not passed, it is rerquired to generate hash.");
        }
        return StringUtils.isNotEmpty(pInputBean.getPath());
    }

    /**
     * Extracts the request parameters and put it in the request bean.
     * 
     * @param pRequest
     *            - a HttpServletRequest value.
     * @return input bean with request parameter values populated.
     */
    private JCRHashGeneratorRequest getRequestParams(SlingHttpServletRequest pRequest) {
        JCRHashGeneratorRequest inputBean = new JCRHashGeneratorRequest();

        if (pRequest == null) {
            return inputBean;
        }
        
        // Path
        String jcrContentPath = pRequest.getParameter(PATH);
        if (StringUtils.isNotEmpty(jcrContentPath)) {
            inputBean.setPath(jcrContentPath.trim());
        }

        // Mode
        String mode = pRequest.getParameter(MODE);
        if (StringUtils.isNotEmpty(mode) && StringUtils.isNumeric(mode)) {
            inputBean.setMode(Integer.valueOf(mode.trim()));
        }
        
        // Excluded Properties
        List<String> excludedProps = mJCRHashGeneratorConfig.mExcludedProperties;
        if (excludedProps == null) {
            excludedProps = new ArrayList<String>();
        }
        String excludedPropertiesFromHashCalc = pRequest.getParameter(EXCLUDED_PROPERTIES);
        List<String> toBeSetOnExcludedListOfProperties = new ArrayList<String>(excludedProps); // Adding this variable because 'excludedProps' is set in the activate Method of JCRHashGeneratorConfig and will have to remain constant once it is loaded.
        if (StringUtils.isNotEmpty(excludedPropertiesFromHashCalc)) {
            String[] exclPropsArray = excludedPropertiesFromHashCalc.split(",");
            if (exclPropsArray != null && exclPropsArray.length > 0) {
            	toBeSetOnExcludedListOfProperties.addAll(Arrays.asList(exclPropsArray)); // adding the excluded list to the newly created toBeSetOnExcludedListOfProperties (line 237) and this is set to input bean. Earlier we were setting on to 'excludedProps' which would alter the in memory map and further requests would continue to have the excluded list of properties.
            }
        }
        inputBean.setExcludedProperties(toBeSetOnExcludedListOfProperties);
        
        // Excluded Nodes
        List<String> excludedNodes = mJCRHashGeneratorConfig.mExcludedNodes;
        if (excludedNodes == null) {
            excludedNodes = new ArrayList<String>();
        }
        List<String> toBeSetOnExcludedListOfNodes = new ArrayList<String>(excludedNodes); // Adding this variable because 'excludedNodes' is set in the activate Method of JCRHashGeneratorConfig and will have to remain constant once it is loaded.
        String excludedNodesFromHashCalc = pRequest.getParameter(EXCLUDED_NODES);
        if (StringUtils.isNotEmpty(excludedNodesFromHashCalc)) {
            String[] exclNodesArray = excludedNodesFromHashCalc.split(",");
            if (exclNodesArray != null && exclNodesArray.length > 0) {
            	toBeSetOnExcludedListOfNodes.addAll(Arrays.asList(exclNodesArray));// adding the excluded list to the newly created toBeSetOnExcludedListOfProperties (line 251) and this is set to input bean. Earlier we were setting on to 'excludedNodes' which would alter the in memory map and further requests would continue to have the excluded list of properties.
            }
        }
        inputBean.setExcludedNodes(toBeSetOnExcludedListOfNodes);
        
        // Should we Include deactivated nodes or not while calculating Hash for the nodes
        String includeDeactivatedNodes = pRequest.getParameter(INCLUDE_DEACTIVATED_NODES);
        if (StringUtils.isNotEmpty(includeDeactivatedNodes)) {
            if ("true".equalsIgnoreCase(includeDeactivatedNodes.trim())) {
                inputBean.setIncludeDeactivatedNodes(true);                
            }
        }
        
        //Check if page order has to be checked or not. This is currently set to true only for campaigns.
        if(pRequest.getParameterMap().containsKey("checkPageOrder")){
        	inputBean.setCheckPagePrder(pRequest.getParameter("checkPageOrder").equals("true")?true:false);
        }else{
        	inputBean.setCheckPagePrder(false);
        }
        return inputBean;
    }
}
