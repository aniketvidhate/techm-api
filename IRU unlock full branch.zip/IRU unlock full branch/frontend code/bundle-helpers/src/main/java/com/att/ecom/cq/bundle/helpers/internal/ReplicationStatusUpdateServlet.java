package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.concurrent.atomic.AtomicInteger;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.NameConstants;
import com.day.jcr.vault.fs.api.ProgressTrackerListener;
import com.day.jcr.vault.packaging.JcrPackage;
import com.day.jcr.vault.packaging.JcrPackageDefinition;
import com.day.jcr.vault.packaging.JcrPackageManager;
import com.day.jcr.vault.packaging.PackageId;
import com.day.jcr.vault.packaging.Packaging;

/**
 * Servlet which updates the replication status properties of pages (or assets)
 * contained in a content package. By default, the current date/time will be
 * used as the activation timestamp. Optionally, if the timestampSource
 * parameter is set to 'build', the build timestamp of the content package will
 * be used.
 */
@SuppressWarnings("serial")
@SlingServlet(paths = "/bin/repstatusupdate", generateComponent = false)
@Component(name = "Replication Status Update Servlet", description = "Servlet which updates replication status properties of pages in a package.")
public class ReplicationStatusUpdateServlet extends SlingAllMethodsServlet {

    /** The activate action. */
	private static final String ACTION_ACTIVATE = "Activate";

	/** The mime type of text responses. */
    private static final String MIME_TEXT_PLAIN = "text/plain";

    /** The replication node type. */
    private static final String NT_REPLICATION_STATUS = "cq:ReplicationStatus";

    /** The build parameter value */
    private static final String PARAM_BUILD = "build";

    /** The package path parameter. */
    private static final String PARAM_PACKAGE_PATH = "packagePath";

    /** The replicating user parameter. */
    private static final String PARAM_REPLICATING_USER = "replicatingUser";

    /** The timestamp source paramter. */
    private static final String PARAM_TIMESTAMP_SOURCE = "timestampSource";

    /** The verbose parameter. */
    private static final String PARAM_VERBOSE = "verbose";

    /** The true value. */
	private static final String TRUE = "true";

	/**
     * The JCR Package Manager.
	 */
	@Reference
    private Packaging packaging;

	/**
	 * A logger
	 */
	private final Logger mLogger = LoggerFactory.getLogger(this.getClass());

	/**
	 * Handle the POST request.
	 */
	@Override
	protected void doPost(final SlingHttpServletRequest request, final SlingHttpServletResponse response) throws ServletException,
			IOException {
		try {
			final String packagePath = request.getParameter(PARAM_PACKAGE_PATH);
			if (packagePath == null) {
				throw new ServletException("Must provide a packagePath parameter");
			}

			final String timestampSource = request.getParameter(PARAM_TIMESTAMP_SOURCE);

			final ResourceResolver resolver = request.getResourceResolver();
			final Session session = resolver.adaptTo(Session.class);

			final PackageId packageId = new PackageId(packagePath);
			final JcrPackage jcrPackage = this.packaging.getPackageManager(request.getResourceResolver().adaptTo(Session.class)).open(packageId);
			if (jcrPackage == null) {
				throw new ServletException("Unable to find package " + packagePath);
			}
			final JcrPackageDefinition definition = jcrPackage.getDefinition();

			response.setContentType(MIME_TEXT_PLAIN);
			final PrintWriter writer = response.getWriter();

			final Calendar timestamp;
			if (PARAM_BUILD.equalsIgnoreCase(timestampSource) && (definition.getLastWrapped() != null)) {
				timestamp = definition.getLastWrapped();
			} else {
				timestamp = Calendar.getInstance();
			}

			final String userId = request.getParameter(PARAM_REPLICATING_USER) != null ? request.getParameter(PARAM_REPLICATING_USER) : session
					.getUserID();

			final AtomicInteger counter = new AtomicInteger();

			definition.dumpCoverage(new ProgressTrackerListener() {

				@Override
				public void onError(Mode mode, String path, Exception e) {
					ReplicationStatusUpdateServlet.this.mLogger.warn("Exception getting package content", e);

				}

				@Override
				public void onMessage(Mode mode, String action, String path) {
					try {
						Resource resource = resolver.getResource(path);
						Node node = resource.adaptTo(Node.class);
						if (node != null) {
							if (node.isNodeType(NT_REPLICATION_STATUS)) {
								if (TRUE.equals(request.getParameter(PARAM_VERBOSE))) {
									writer.println("Update replication status on " + path);
								}
								node.setProperty(NameConstants.PN_PAGE_LAST_REPLICATED, timestamp);
								node.setProperty(NameConstants.PN_PAGE_LAST_REPLICATED_BY, userId);
								node.setProperty(NameConstants.PN_PAGE_LAST_REPLICATION_ACTION, ACTION_ACTIVATE);
								counter.incrementAndGet();
							}
						}
					} catch (RepositoryException e) {
						mLogger.error("Unable to update replication status on " + path, e);
					}
				}
			});
			writer.println("Updated replication status on " + counter.intValue() + " pages");
			if (session.hasPendingChanges()) {
				session.save();
			}
		} catch (RepositoryException e) {
			throw new ServletException("Unable to update replication statue", e);
		}
	}
}
