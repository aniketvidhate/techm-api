/**
 * 
 */
package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.util.TraversingItemVisitor;
import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.jcr.resource.JcrResourceUtil;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.WCMMode;

/**
 * @author bb791k
 *
 */
@SuppressWarnings("serial")
@SlingServlet(resourceTypes = "sling/servlet/default", selectors = "migrate", extensions = "html")
public class MobileContentMigrator extends SlingSafeMethodsServlet {

	private static final Map<String,List<String>> templateTypes;
	private static final List<String> devices;
	private static final List<String> accessories;
	private static final List<String> packages;
	private static final List<String> plans;
	private static final List<String> services;
	
	private static final String DEVICES = "devices";
	private static final String ACCESSORIES = "accessories";
	private static final String PACKAGES = "packages";
	private static final String PLANS = "plans";
	private static final String SERVICES = "services";
	
	static {
		devices = new ArrayList<String>();
		devices.add("/apps/att/wireless/templates/details/devicedetails");
		devices.add("/apps/att/wireless/templates/details/devicedetailswithaccessories");
		devices.add("/apps/att/wireless/templates/details/fullwidthdevicedetails");
		devices.add("/apps/att/wireless/templates/details/devicedetailswithaccessories");
		
		accessories = new ArrayList<String>();
		accessories.add("/apps/att/wireless/templates/details/accessorydetails");
		accessories.add("/apps/att/wireless/templates/details/overviewaccessorydetails");
		
		plans = new ArrayList<String>();
		plans.add("/apps/att/wireless/templates/details/plandetails");
		
		packages = new ArrayList<String>();
		packages.add("/apps/att/wireless/templates/details/packagedetails");
		
		services = new ArrayList<String>();
		services.add("/apps/att/wireless/templates/details/servicedetails");
		
		templateTypes = new HashMap<String,List<String>> ();
		templateTypes.put(DEVICES, devices);
		templateTypes.put(ACCESSORIES, accessories);
		templateTypes.put(PLANS,plans);
		templateTypes.put(PACKAGES, packages);
		templateTypes.put(SERVICES, services);
	}
	@Override
	protected void doGet(SlingHttpServletRequest pRequest,
			SlingHttpServletResponse pResponse) throws ServletException,
			IOException {
		
		if (WCMMode.fromRequest(pRequest) != WCMMode.EDIT) {
			pResponse.sendError(403);
			return;
		}
		
		
		
		Resource currentResource = pRequest.getResource();
		ResourceResolver resourceResolver = pRequest.getResourceResolver();
		Node currentNode = currentResource.adaptTo(Node.class);
		
		String migrationType = pRequest.getParameter("type");
		List<String> templates = new ArrayList<String>();
		if (migrationType != null) {
			templates = templateTypes.get(migrationType);
		}
		
		if (templates != null) {
			if (DEVICES.equals(migrationType)) {
				migrateDeviceNodes(templates, currentNode, resourceResolver);
			} else if (PLANS.equals(migrationType)) {
				migratePlans(templates, currentNode, resourceResolver);
			} else if (ACCESSORIES.equals(migrationType)) {
				migrateAccessories(templates, currentNode, resourceResolver);
			} else if (SERVICES.equals(migrationType)) {
				migrateServices(templates, currentNode, resourceResolver);
			}
		}
		
		pResponse.getWriter().write("Migration Complete");
	}
	
	private void migrateDeviceNodes(final List<String> pTemplates, final Node pCurrentNode, final ResourceResolver pResourceResolver) throws ServletException {
		try {
			final Session session = pResourceResolver.adaptTo(javax.jcr.Session.class);
			
			pCurrentNode.accept( new TraversingItemVisitor.Default() {
				@Override
				protected void entering(Node pNode, int pLevel) {
					try {
						if (pNode.hasProperty("cq:template")
								&& pTemplates.contains(pNode.getProperty("cq:template").getString())) {
							
							String nodePath = pNode.getParent().getPath();
							String mobileNodePath = nodePath.replace("shop", "shopmobile");
							
							String sku = pNode.hasProperty("sku") ? pNode.getProperty("sku").getString() : null;
							String prodId = pNode.hasProperty("productId") ? pNode.getProperty("productId").getString() : null;
							String manufacturer = pNode.hasProperty("manufacturer") ? pNode.getProperty("manufacturer").getString() : null;
							String mobileTitle = pNode.hasProperty("jcr:title") ? pNode.getProperty("jcr:title").getString() : null;
							String mobileDescription = pNode.hasProperty("jcr:description") ? pNode.getProperty("jcr:description").getString() : null;
							String mobilePageTitle = pNode.hasProperty("navTitle") ? pNode.getProperty("navTitle").getString() : pNode.hasProperty("pageTitle") ? pNode.getProperty("pageTitle").getString() : mobileTitle; 
							String mobileDeliveryPromise = pNode.hasProperty("deliveryPromise") ? pNode.getProperty("deliveryPromise").getString() : null;
							String mobileMediaAvail = pNode.hasProperty("mediaAvailable") ? pNode.getProperty("mediaAvailable").getString() : null;
							
							Node mobilePageNode = JcrResourceUtil.createPath(mobileNodePath, "cq:Page", "cq:Page", session, true);
							Page mobilePage = pResourceResolver.resolve(mobilePageNode.getPath()).adaptTo(Page.class);
							Page mobileParentPage = mobilePage.getParent();
							if (mobileParentPage.getTemplate() == null) {
								Resource mobileParentResource = mobileParentPage.getContentResource();
								if (mobileParentResource == null) {
									Node mobileParentNode = mobileParentPage.adaptTo(Node.class);
									Node parentContentNode = mobileParentNode.addNode("jcr:content", "cq:PageContent");
									parentContentNode.setProperty("cq:template", "/apps/att/mobile/wireless/templates/archive/lists/devicelist");
									parentContentNode.setProperty("sling:resourceType", "att/mobile/wireless/components/page/lists/devicelist");
									parentContentNode.setProperty("jcr:title", manufacturer);
								}
							}
							Resource mobilePageContentResource = mobilePage.getContentResource();
							if (mobilePageContentResource != null) { //doing a bug correction so that content will work in the different list pages
								Node mobilePageContentNode = mobilePageContentResource.adaptTo(Node.class);
								String primaryType = mobilePageContentNode.getProperty("jcr:primaryType").getString();
								if ("nt:unstructured".equals(primaryType)) {
									mobilePageContentNode.setPrimaryType("cq:PageContent");
								}
							} else if (mobilePageContentResource == null) {
								Node mobileContentNode = mobilePageNode.addNode("jcr:content", "cq:PageContent");
								mobilePageContentResource = mobilePage.getContentResource();
							}
							Node mobilePageContentNode = mobilePageContentResource.adaptTo(Node.class);
							mobilePageContentNode.setProperty("cq:template", "/apps/att/mobile/wireless/templates/structured/baseheader/searchmenufooter/devicedetails");
							mobilePageContentNode.setProperty("sling:resourceType", "att/mobile/wireless/components/page/layouts/structured/baseheader/searchmenufooter/devicedetails");
							if (StringUtils.isNotEmpty(sku)) {
								mobilePageContentNode.setProperty("skuId", sku);
							}
							if (StringUtils.isNotEmpty(prodId)) {
								mobilePageContentNode.setProperty("productId", prodId);
							}
							if (StringUtils.isNotEmpty(manufacturer)) {
								mobilePageContentNode.setProperty("manufacturer", manufacturer);
							}
							mobilePageContentNode.setProperty("jcr:title", mobileTitle);
							mobilePageContentNode.setProperty("jcr:description", mobileDescription);
							String currentDeliveryPromiseStr = "";
							
							Property delPromiseProp = null;
							if (mobilePageContentNode.hasProperty("deliveryPromise")) {
								delPromiseProp = mobilePageContentNode.getProperty("deliveryPromise");
							}
							if (delPromiseProp != null) {
								currentDeliveryPromiseStr = delPromiseProp.getString();
							}
							if (StringUtils.isNotEmpty(mobileDeliveryPromise) && StringUtils.isEmpty(currentDeliveryPromiseStr)) {
								mobilePageContentNode.setProperty("deliveryPromise", mobileDeliveryPromise);
							}
							mobilePageContentNode.setProperty("pageType","device");
							mobilePageContentNode.setProperty("mediaAvailable",mobileMediaAvail);
							if (!mobilePageContentNode.hasNode("title")) {
								Node titleNode = mobilePageContentNode.addNode("title", "nt:unstructured");
								titleNode.setProperty("pageTitle", mobilePageTitle);
								titleNode.setProperty("showFacebook", true);
								titleNode.setProperty("seoTitle", true);
								titleNode.setProperty("sling:resourceType", "att/mobile/common/components/titles/pagetitle");
							} else {
								Node titleNode = mobilePageContentNode.getNode("title");
								titleNode.setProperty("pageTitle", mobilePageTitle);
								titleNode.setProperty("showFacebook", true);
								titleNode.setProperty("seoTitle", true);
								titleNode.setProperty("sling:resourceType", "att/mobile/common/components/titles/pagetitle");
							}
							//migrate tab content
							Resource desktopResource = pResourceResolver.getResource(pNode.getPath());
							Resource mobileResource = mobilePage.getContentResource();
							
							migrateDetailsFromDesktop(mobileResource, desktopResource);
							migrateFeaturesFromDesktop(mobileResource, desktopResource);
							migrateLegalTextFromDesktop(mobileResource, desktopResource);
						}
					} catch (RepositoryException ex) {
						//failed
						System.out.println(ex.getMessage());
					}
				}
			});
			
			session.save();
		} catch (RepositoryException ex) {
			throw new ServletException("unable to finish migration", ex);
		}
	}
	
	private void migratePlans(final List<String> pTemplates, final Node pCurrentNode, final ResourceResolver pResourceResolver) throws ServletException {
		try {
			final Session session = pResourceResolver.adaptTo(javax.jcr.Session.class);
			
			pCurrentNode.accept( new TraversingItemVisitor.Default() {
				@Override
				protected void entering(Node pNode, int pLevel) {
					try {
						if (pNode.hasProperty("cq:template")
								&& pTemplates.contains(pNode.getProperty("cq:template").getString())) {
							
							String nodePath = pNode.getParent().getPath();
							String mobileNodePath = nodePath.replace("shop", "shopmobile");
							
							String sku = pNode.hasProperty("sku") ? pNode.getProperty("sku").getString() : null;
							String prodId = pNode.hasProperty("productId") ? pNode.getProperty("productId").getString() : null;
							String manufacturer = pNode.hasProperty("manufacturer") ? pNode.getProperty("manufacturer").getString() : null;
							String mobileTitle = pNode.hasProperty("jcr:title") ? pNode.getProperty("jcr:title").getString() : null;
							String mobileDescription = pNode.hasProperty("jcr:description") ? pNode.getProperty("jcr:description").getString() : null;
							String mobileLongDescription = pNode.hasProperty("longDescription") ? pNode.getProperty("longDescription").getString() : null;
							
							Node mobilePageNode = JcrResourceUtil.createPath(mobileNodePath, "cq:Page", "cq:Page", session, true);
							Page mobilePage = pResourceResolver.resolve(mobilePageNode.getPath()).adaptTo(Page.class);
							Resource mobilePageContentResource = mobilePage.getContentResource();
							if (mobilePageContentResource != null) { //doing a bug correction so that content will work in the different list pages
								Node mobilePageContentNode = mobilePageContentResource.adaptTo(Node.class);
								String primaryType = mobilePageContentNode.getProperty("jcr:primaryType").getString();
								if ("nt:unstructured".equals(primaryType)) {
									mobilePageContentNode.setPrimaryType("cq:PageContent");
								}
							} else if (mobilePageContentResource == null) {
								Node mobileContentNode = mobilePageNode.addNode("jcr:content", "cq:PageContent");
								mobilePageContentResource = mobilePage.getContentResource();
							}
							Node mobilePageContentNode = mobilePageContentResource.adaptTo(Node.class);
							mobilePageContentNode.setProperty("cq:template", "/apps/att/mobile/wireless/templates/structured/baseheader/basefooter/plandetails");
							mobilePageContentNode.setProperty("sling:resourceType", "att/mobile/wireless/components/page/layouts/structured/baseheader/basefooter/plandetails");
							if (StringUtils.isNotEmpty(sku)) {
								mobilePageContentNode.setProperty("skuId", sku);
							}
							if (StringUtils.isNotEmpty(prodId)) {
								mobilePageContentNode.setProperty("productId", prodId);
							}
							mobilePageContentNode.setProperty("jcr:title", mobileTitle);
							mobilePageContentNode.setProperty("jcr:description", mobileDescription);
							mobilePageContentNode.setProperty("longDescripton", mobileLongDescription);
							mobilePageContentNode.setProperty("pageType", "plan");
							
						}
					} catch (RepositoryException ex) {
						//failed
					}
				}
			});
			
			session.save();
		} catch (RepositoryException ex) {
			throw new ServletException("unable to finish migration", ex);
		}
	}
	
	private void migrateAccessories(final List<String> pTemplates, final Node pCurrentNode, final ResourceResolver pResourceResolver) throws ServletException {
		try {
			final Session session = pResourceResolver.adaptTo(javax.jcr.Session.class);
			
			pCurrentNode.accept( new TraversingItemVisitor.Default() {
				@Override
				protected void entering(Node pNode, int pLevel) {
					try {
						if (pNode.hasProperty("cq:template")
								&& pTemplates.contains(pNode.getProperty("cq:template").getString())) {
							
							String nodePath = pNode.getParent().getPath();
							String mobileNodePath = nodePath.replace("shop", "shopmobile");
							
							String sku = pNode.hasProperty("sku") ? pNode.getProperty("sku").getString() : null;
							String prodId = pNode.hasProperty("productId") ? pNode.getProperty("productId").getString() : null;
							String mobileTitle = pNode.hasProperty("jcr:title") ? pNode.getProperty("jcr:title").getString() : null;
							String mobileDescription = pNode.hasProperty("jcr:description") ? pNode.getProperty("jcr:description").getString() : null;
							String mobilePageTitle = pNode.hasProperty("navTitle") ? pNode.getProperty("navTitle").getString() : pNode.hasProperty("pageTitle") ? pNode.getProperty("pageTitle").getString() : mobileTitle; 
							String mobileDeliveryPromise = pNode.hasProperty("deliveryPromise") ? pNode.getProperty("deliveryPromise").getString() : null;
							
							Node mobilePageNode = JcrResourceUtil.createPath(mobileNodePath, "cq:Page", "cq:Page", session, true);
							
							//put in intermediate page info
							Page mobilePage = pResourceResolver.resolve(mobilePageNode.getPath()).adaptTo(Page.class);
							Page mobileParentPage = mobilePage.getParent();
							if (mobileParentPage.getTemplate() == null) {
								Resource mobileParentResource = mobileParentPage.getContentResource();
								if (mobileParentResource == null) {
									Node mobileParentNode = mobileParentPage.adaptTo(Node.class);
									Node parentContentNode = mobileParentNode.addNode("jcr:content", "cq:PageContent");
									parentContentNode.setProperty("cq:template", "/apps/att/mobile/wireless/templates/structured/baseheader/basefooter/accessorylist");
									parentContentNode.setProperty("sling:resourceType", "att/mobile/wireless/components/page/layouts/structured/baseheader/basefooter/accessorylist");
								}
							}
							
							Resource mobilePageContentResource = mobilePage.getContentResource();
							if (mobilePageContentResource != null) { //doing a bug correction so that content will work in the different list pages
								Node mobilePageContentNode = mobilePageContentResource.adaptTo(Node.class);
								String primaryType = mobilePageContentNode.getProperty("jcr:primaryType").getString();
								if ("nt:unstructured".equals(primaryType)) {
									mobilePageContentNode.setPrimaryType("cq:PageContent");
								}
							} else if (mobilePageContentResource == null) {
								Node mobileContentNode = mobilePageNode.addNode("jcr:content", "cq:PageContent");
								mobilePageContentResource = mobilePage.getContentResource();
							}
							Node mobilePageContentNode = mobilePageContentResource.adaptTo(Node.class);
							mobilePageContentNode.setProperty("cq:template", "/apps/att/mobile/wireless/templates/structured/baseheader/basefooter/accessorydetails");
							mobilePageContentNode.setProperty("sling:resourceType", "att/mobile/wireless/components/page/layouts/structured/baseheader/basefooter/accessorydetails");
							if (StringUtils.isNotEmpty(sku)) {
								mobilePageContentNode.setProperty("skuId", sku);
							}
							if (StringUtils.isNotEmpty(prodId)) {
								mobilePageContentNode.setProperty("productId", prodId);
							}
							mobilePageContentNode.setProperty("jcr:title", mobileTitle);
							mobilePageContentNode.setProperty("jcr:description", mobileDescription);
							mobilePageContentNode.setProperty("pageType", "accessory");
							mobilePageContentNode.setProperty("deliveryPromise", mobileDeliveryPromise);
							if (!mobilePageContentNode.hasNode("pagetitle")) {
								Node titleNode = mobilePageContentNode.addNode("pagetitle", "nt:unstructured");
								titleNode.setProperty("pageTitle", mobilePageTitle);
								titleNode.setProperty("showFacebook", true);
								titleNode.setProperty("seoTitle", true);
								titleNode.setProperty("sling:resourceType", "att/mobile/common/components/titles/pagetitle");
							} else {
								Node titleNode = mobilePageContentNode.getNode("pagetitle");
								titleNode.setProperty("pageTitle", mobilePageTitle);
								titleNode.setProperty("showFacebook", true);
								titleNode.setProperty("seoTitle", true);
								titleNode.setProperty("sling:resourceType", "att/mobile/common/components/titles/pagetitle");
							}
							//put in accessory description content
							String descriptionText = "";
							if (pNode.hasNode("accessorytabs/description")) {
								Node descNode = pNode.getNode("accessorytabs/description");
								descriptionText = descNode.getProperty("authorrichtext").getString();
							} else {
								if (pNode.hasNode("accessorytabs/detailsoverviewpar")) {
									Node overviewParNode = pNode.getNode("accessorytabs/detailsoverviewpar");
									if (overviewParNode.hasNode("opentext")) {
										Node openTextNode = overviewParNode.getNode("opentext");
										String openText = openTextNode.getProperty("authortext").getString();
										descriptionText += openText;
									}
									if (overviewParNode.hasNode("text")) {
										Node textNode = overviewParNode.getNode("text");
										String text = textNode.getProperty("text").getString();
										descriptionText += text;
									}
									if (overviewParNode.hasNode("tiletext")) {
										Node tileTextNode = overviewParNode.getNode("tiletext");
										String text = tileTextNode.getProperty("text").getString();
										descriptionText += text;
									}									
								}
							}
							
							Node detailsNode = null; 
							if (mobilePageContentNode.hasNode("details")) {
								detailsNode = mobilePageContentNode.getNode("details");
								//clean up possible duplicate description nodes happened because of a bad "hasNode" call below
								NodeIterator descriptionNodeIter = detailsNode.getNodes();
								while (descriptionNodeIter.hasNext()) {
									Node descriptionNode = descriptionNodeIter.nextNode();
									descriptionNode.remove();
								}
							} else {
								detailsNode = mobilePageContentNode.addNode("details", "nt:unstructured");
							}
							Node descriptionNode = null;
							if (detailsNode.hasNode("description")) {
								descriptionNode = detailsNode.getNode("description");
							} else {
								descriptionNode = detailsNode.addNode("description", "nt:unstructured");
							}
							descriptionNode.setProperty("authorrichtext", descriptionText);
							descriptionNode.setProperty("sling:resourceType", "att/common/components/authorrichtext");
							
						}
					} catch (RepositoryException ex) {
						log(ex.getMessage(), ex);
					}
				}
			});
			
			session.save();
		} catch (RepositoryException ex) {
			throw new ServletException("unable to finish migration", ex);
		}
	}

	private void migrateServices(final List<String> pTemplates, final Node pCurrentNode, final ResourceResolver pResourceResolver) throws ServletException {
		try {
			final Session session = pResourceResolver.adaptTo(javax.jcr.Session.class);
			
			pCurrentNode.accept( new TraversingItemVisitor.Default() {
				@Override
				protected void entering(Node pNode, int pLevel) {
					try {
						if (pNode.hasProperty("cq:template")
								&& pTemplates.contains(pNode.getProperty("cq:template").getString())) {
							
							String nodePath = pNode.getParent().getPath();
							String mobileNodePath = nodePath.replace("shop", "shopmobile");
							
							String sku = pNode.hasProperty("sku") ? pNode.getProperty("sku").getString() : null;
							String prodId = pNode.hasProperty("productId") ? pNode.getProperty("productId").getString() : null;
							String mobileTitle = pNode.hasProperty("jcr:title") ? pNode.getProperty("jcr:title").getString() : null;
							String mobileDescription = pNode.hasProperty("jcr:description") ? pNode.getProperty("jcr:description").getString() : null;
							String mobilePageTitle = pNode.hasProperty("navTitle") ? pNode.getProperty("navTitle").getString() : pNode.hasProperty("pageTitle") ? pNode.getProperty("pageTitle").getString() : mobileTitle; 
							String mobileDeliveryPromise = pNode.hasProperty("deliveryPromise") ? pNode.getProperty("deliveryPromise").getString() : null;
							
							Node mobilePageNode = JcrResourceUtil.createPath(mobileNodePath, "cq:Page", "cq:Page", session, true);
							
							//put in intermediate page info
							Page mobilePage = pResourceResolver.resolve(mobilePageNode.getPath()).adaptTo(Page.class);
							Page mobileParentPage = mobilePage.getParent();
							if (mobileParentPage.getTemplate() == null) {
								Resource mobileParentResource = mobileParentPage.getContentResource();
								if (mobileParentResource == null) {
									Node mobileParentNode = mobileParentPage.adaptTo(Node.class);
									Node parentContentNode = mobileParentNode.addNode("jcr:content", "cq:PageContent");
									parentContentNode.setProperty("cq:template", "/apps/att/mobile/wireless/templates/authored/baseheader/basefooter");
									parentContentNode.setProperty("sling:resourceType", "att/mobile/wireless/components/page/layouts/authored/baseheader/basefooter");
								}
							}
							
							Resource mobilePageContentResource = mobilePage.getContentResource();
							if (mobilePageContentResource != null) { //doing a bug correction so that content will work in the different list pages
								Node mobilePageContentNode = mobilePageContentResource.adaptTo(Node.class);
								String primaryType = mobilePageContentNode.getProperty("jcr:primaryType").getString();
								if ("nt:unstructured".equals(primaryType)) {
									mobilePageContentNode.setPrimaryType("cq:PageContent");
								}
							} else if (mobilePageContentResource == null) {
								Node mobileContentNode = mobilePageNode.addNode("jcr:content", "cq:PageContent");
								mobilePageContentResource = mobilePage.getContentResource();
							}
							Node mobilePageContentNode = mobilePageContentResource.adaptTo(Node.class);
							mobilePageContentNode.setProperty("cq:template", "/apps/att/mobile/wireless/templates/structured/baseheader/basefooter/servicedetails");
							mobilePageContentNode.setProperty("sling:resourceType", "att/mobile/wireless/components/page/layouts/structured/baseheader/basefooter/servicedetails");
							if (StringUtils.isNotEmpty(sku)) {
								mobilePageContentNode.setProperty("skuId", sku);
							}
							if (StringUtils.isNotEmpty(prodId)) {
								mobilePageContentNode.setProperty("productId", prodId);
							}
							mobilePageContentNode.setProperty("jcr:title", mobileTitle);
							mobilePageContentNode.setProperty("jcr:description", mobileDescription);
							mobilePageContentNode.setProperty("pageType", "service");
							mobilePageContentNode.setProperty("deliveryPromise", mobileDeliveryPromise);
							if (!mobilePageContentNode.hasNode("pagetitle")) {
								Node titleNode = mobilePageContentNode.addNode("pagetitle", "nt:unstructured");
								titleNode.setProperty("pageTitle", mobilePageTitle);
								titleNode.setProperty("showFacebook", false);
								titleNode.setProperty("seoTitle", false);
								titleNode.setProperty("sling:resourceType", "att/mobile/common/components/titles/pagetitle");
							} else {
								Node titleNode = mobilePageContentNode.getNode("pagetitle");
								titleNode.setProperty("pageTitle", mobilePageTitle);
								titleNode.setProperty("showFacebook", false);
								titleNode.setProperty("seoTitle", false);
								titleNode.setProperty("sling:resourceType", "att/mobile/common/components/titles/pagetitle");
							}
							//put in accessory description content
							
							StringBuilder descriptionText = new StringBuilder();
							if (pNode.hasNode("devicetabs/servicedescription")) {
								Node descNode = pNode.getNode("devicetabs/servicedescription");
								if (descNode.hasProperty("authorrichtext")) {
									String topText = descNode.getProperty("authorrichtext").getString();
									descriptionText.append(topText);
								}
							}
							if (pNode.hasNode("devicetabs/servicedescriptionLower")) {
								Node descNode = pNode.getNode("devicetabs/servicedescriptionLower");
								if (descNode.hasProperty("authorrichtext")) {
									String lowerText = descNode.getProperty("authorrichtext").getString();
									descriptionText.append(lowerText);
								}
							}
							
							Node detailsNode = null; 
							if (mobilePageContentNode.hasNode("details")) {
								detailsNode = mobilePageContentNode.getNode("details");
								//clean up possible duplicate description nodes happened because of a bad "hasNode" call below
								NodeIterator descriptionNodeIter = detailsNode.getNodes();
								while (descriptionNodeIter.hasNext()) {
									Node descriptionNode = descriptionNodeIter.nextNode();
									descriptionNode.remove();
								}
							} else {
								detailsNode = mobilePageContentNode.addNode("details", "nt:unstructured");
							}
							Node descriptionNode = null;
							if (detailsNode.hasNode("description")) {
								descriptionNode = detailsNode.getNode("description");
							} else {
								descriptionNode = detailsNode.addNode("description", "nt:unstructured");
							}
							descriptionNode.setProperty("authorrichtext", descriptionText.toString());
							descriptionNode.setProperty("sling:resourceType", "att/common/components/authorrichtext");
							
						}
					} catch (RepositoryException ex) {
						log(ex.getMessage(), ex);
					}
				}
			});
			
			session.save();
		} catch (RepositoryException ex) {
			throw new ServletException("unable to finish migration", ex);
		}
	}
	
	private void migrateDetailsFromDesktop(Resource pMobileResource, Resource pDesktopResource) throws RepositoryException {
    	if (pDesktopResource != null) {
			Resource leftDetailPar = pDesktopResource.getChild("devicetabs/leftdetailpar");
			Resource rightDetailPar = pDesktopResource.getChild("devicetabs/rightdetailpar");
			Resource leftSpecPar = pDesktopResource.getChild("devicetabs/leftspecpar");
			Resource rightSpecPar = pDesktopResource.getChild("devicetabs/rightspecpar");
			
			List<Resource> details = new ArrayList<Resource>();
			if (leftDetailPar != null) {
				Iterator<Resource> childrenIter = leftDetailPar.listChildren();
				while (childrenIter.hasNext()) {
					details.add(childrenIter.next());
				}
			}
			if (rightDetailPar != null) {
				Iterator<Resource> childrenIter = rightDetailPar.listChildren();
				while (childrenIter.hasNext()) {
					details.add(childrenIter.next());
				}
			}
			if (leftSpecPar != null) {
				Iterator<Resource> childrenIter = leftSpecPar.listChildren();
				while (childrenIter.hasNext()) {
					details.add(childrenIter.next());
				}
			}
			if (rightSpecPar != null) {
				Iterator<Resource> childrenIter = rightSpecPar.listChildren();
				while (childrenIter.hasNext()) {
					details.add(childrenIter.next());
				}
			}
			
			Resource currentDetailsPar = pMobileResource.getChild("details/detailspar");
			if (currentDetailsPar == null) {
				Resource detailsResource = pMobileResource.getChild("details");
				if (detailsResource == null) {
					Node currentNode = pMobileResource.adaptTo(Node.class);
					Node detailsNode = currentNode.addNode("details", "nt:unstructured");
					detailsResource = pMobileResource.getChild("details");
				}
				Node detailsNode = detailsResource.adaptTo(Node.class);
				Node detailsParNode = detailsNode.addNode("detailspar", "nt:unstructured");
				detailsParNode.setProperty("sling:resourceType", "foundation/components/parsys");
				currentDetailsPar = detailsResource.getChild("detailspar");
			}
			if (currentDetailsPar != null) {
				Node featureParNode = currentDetailsPar.adaptTo(Node.class);
				NodeIterator nodeIter = featureParNode.getNodes();
				while (nodeIter.hasNext()) {
					Node child = nodeIter.nextNode();
					child.remove();
				}
				
				for (Resource feature : details) {
					Node featureNode = feature.adaptTo(Node.class);
					if (featureNode.hasProperty("path")) {
						Node featureReference = featureParNode.addNode(featureNode.getName(), featureNode.getPrimaryNodeType().getName());
						if (featureNode.getProperty("path").getString().toLowerCase().contains("/categoryheader")) {
							featureReference.setProperty("sling:resourceType", "att/mobile/wireless/components/specifications/categoryheaderreference");
						} else {
							featureReference.setProperty("sling:resourceType", "att/mobile/wireless/components/specifications/additionaldetailreference");
						}
						featureReference.setProperty("path", featureNode.getProperty("path").getString());
					}
				}
			}
			
			
		}
    }
    
    private void migrateFeaturesFromDesktop(Resource pMobileResource, Resource pDesktopResource) throws RepositoryException {
    	if (pDesktopResource != null) {
			Resource leftFeaturePar = pDesktopResource.getChild("devicetabs/leftfeaturepar");
			Resource rightFeaturePar = pDesktopResource.getChild("devicetabs/rightfeaturepar");
			
			List<Resource> overview = new ArrayList<Resource>();
			if (leftFeaturePar != null) {
				Iterator<Resource> childrenIter = leftFeaturePar.listChildren();
				while (childrenIter.hasNext()) {
					overview.add(childrenIter.next());
				}
			}
			if (rightFeaturePar != null) {
				Iterator<Resource> childrenIter = rightFeaturePar.listChildren();
				while (childrenIter.hasNext()) {
					overview.add(childrenIter.next());
				}
			}
			
			Resource currentFeaturePar = pMobileResource.getChild("details/featurepar");
			if (currentFeaturePar == null) {
				Resource detailsResource = pMobileResource.getChild("details");
				if (detailsResource == null) {
					Node currentNode = pMobileResource.adaptTo(Node.class);
					Node detailsNode = currentNode.addNode("details", "nt:unstructured");
					detailsResource = pMobileResource.getChild("details");
				}
				Node detailsNode = detailsResource.adaptTo(Node.class);
				Node featureParNode = detailsNode.addNode("featurepar", "nt:unstructured");
				featureParNode.setProperty("sling:resourceType", "foundation/components/parsys");
				currentFeaturePar = detailsResource.getChild("featurepar");
			}
			if (currentFeaturePar != null) {
				Node featureParNode = currentFeaturePar.adaptTo(Node.class);
				NodeIterator nodeIter = featureParNode.getNodes();
				while (nodeIter.hasNext()) {
					Node child = nodeIter.nextNode();
					child.remove();
				}
				
				for (Resource feature : overview) {
					Node featureNode = feature.adaptTo(Node.class);
					Node featureReference = featureParNode.addNode(featureNode.getName(), featureNode.getPrimaryNodeType().getName());
					featureReference.setProperty("sling:resourceType", "att/mobile/wireless/components/specifications/featurereference");
					featureReference.setProperty("path", featureNode.getProperty("path").getString());
				}
			}
			
			
		}
    }
	

    private void migrateLegalTextFromDesktop(Resource pMobileResource, Resource pDesktopResource) throws RepositoryException {
    	if (pDesktopResource != null) {
    		Resource legalReferences = pDesktopResource.getChild("ReferenceA");
    		
    		List<Resource> legalTextItems = new ArrayList<Resource>();
    		Iterator<Resource> childIter = pDesktopResource.listChildren();
    		while (childIter.hasNext()) {
    			Resource child = childIter.next();
    			Node childNode = child.adaptTo(Node.class);
    			if (childNode.hasProperty("path")) {
    				String referencePath = childNode.getProperty("path").getString();
    				if (referencePath != null && (referencePath.contains("/legal/") || referencePath.contains("/warranty-info/"))) {
    					legalTextItems.add(child);
    				}
    			}
    		}
    		if (legalReferences != null) {
    			Iterator<Resource> childrenIter = legalReferences.listChildren();
    			while (childrenIter.hasNext()) {
    				legalTextItems.add(childrenIter.next());
    			}
    		}
    		
    		
    		
    		Resource currentFeaturePar = pMobileResource.getChild("details/legalpar");
    		if (currentFeaturePar == null) {
    			Resource detailsResource = pMobileResource.getChild("details");
    			if (detailsResource == null) {
    				Node currentNode = pMobileResource.adaptTo(Node.class);
    				Node detailsNode = currentNode.addNode("details", "nt:unstructured");
    				detailsResource = pMobileResource.getChild("details");
    			}
    			Node detailsNode = detailsResource.adaptTo(Node.class);
    			Node featureParNode = detailsNode.addNode("legalpar", "nt:unstructured");
    			featureParNode.setProperty("sling:resourceType", "foundation/components/parsys");
    			currentFeaturePar = detailsResource.getChild("legalpar");
    		}
    		if (currentFeaturePar != null) {
    			Node featureParNode = currentFeaturePar.adaptTo(Node.class);
    			NodeIterator nodeIter = featureParNode.getNodes();
    			while (nodeIter.hasNext()) {
    				Node child = nodeIter.nextNode();
    				child.remove();
    			}
    			
    			for (Resource legalTextResource : legalTextItems) {
    				Node legalTextNode = legalTextResource.adaptTo(Node.class);
    				Node legalReference = featureParNode.addNode(legalTextNode.getName(), legalTextNode.getPrimaryNodeType().getName());
    				legalReference.setProperty("sling:resourceType", "att/mobile/wireless/components/legal/legaldetailsreference");
    				legalReference.setProperty("path", legalTextNode.getProperty("path").getString());
    			}
    		}
    		
    		
    	}
    }
    
}
