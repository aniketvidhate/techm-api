package com.att.ecom.cq.bundle.helpers;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;


import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.Value;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import com.day.cq.wcm.api.PageManager;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.wcm.api.Page;
import java.io.File;
import java.io.StringWriter;



/*
 * @author Shovon Zaman (sz1004)
 * @created on October 2013
 * Notes:
 */


@Component(immediate = true, name = "Global Navigation Validation")
@Service(value = com.att.ecom.cq.bundle.helpers.GlobalNavigationValidation.class )

public class GlobalNavigationValidation
{

	private Logger logger = LoggerFactory.getLogger(GlobalNavigationValidation.class);

	@Reference
	private SlingRepository slingRepository;
	
	@Reference
	private ResourceResolverFactory resourceResolverFactory;	

	private Session administrativeSession;
			

	protected void activate(ComponentContext ctx) throws RepositoryException 
	{
		administrativeSession = slingRepository.loginAdministrative(null);
	}
	
	protected void deactivate(ComponentContext ctx) {
		administrativeSession.logout();
	}
	/*
     * Get Invalid Reference Node Path
     */	
	public synchronized String referenceNodePathValidation(String currentPagePath) throws RepositoryException 
	{
		String output="";		
		String children="SELECT * FROM nt:base WHERE jcr:path like '"+currentPagePath +"/%' and jcr:primaryType='cq:Page' ";
		if (administrativeSession.isLive()) 
		{	
			// get QueryManager
    		QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();    		
    		// make SQL query
    		Query query = queryManager.createQuery(children, Query.SQL);
    		// execute query
    		QueryResult result = query.execute();
    		// execute query and fetch result
    		NodeIterator nodes = result.getNodes();
    		ResourceResolver adminResolver = null;
			try 
			{
				adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);				
				while (nodes.hasNext()) 
				{
					Node node = nodes.nextNode();
					String listinvalidrefpaths="";
					listinvalidrefpaths +=parseCurrentPage(node.getPath().toString(),"mainpar/header",adminResolver);
					listinvalidrefpaths +=parseCurrentPage(node.getPath().toString(),"mainpar/footer",adminResolver);
					listinvalidrefpaths +=parseCurrentPage(node.getPath().toString(),"mainpar/globalnav",adminResolver);
					output +="<h3>CQ Path: " + node.getPath().toString().replace("/jcr:content" ,"") + "</h3>";
					if(listinvalidrefpaths.equals("")){
						output +="Invalid Reference Node Path(s) not found<br/><br/>";
			        }
					else{
					    output +="<table border='1'><th>Node Path</th><th>Invalid Reference Node Path</th>";
						output += listinvalidrefpaths + "</table><br/><br/>";
					}
				}	
			}catch (LoginException e) {
				logger.error("Unable to login for CMS Repository Report", e);
			}
			finally {
				if (adminResolver != null) {
					adminResolver.close();
				}
			}
		}
		return output;	
	}
	/**
	 * Parsing giving Global Navigation 
	 */
	public synchronized String parseCurrentPage(String currentPagePath,String rootnodepath,ResourceResolver adminResolver) throws RepositoryException {
		String output="";
		try{
			PageManager pageManager = adminResolver.adaptTo(PageManager.class);
			Page rootPage = pageManager.getPage(currentPagePath);
			String strnodepath;
			String strrefNodePath;
			
			Map<String, String>  dupnodepath_refpathmap = new HashMap<String, String>();
			Map<String, String> mainnodepathmap = new HashMap<String, String>();

			if( null != rootPage){
				Resource rootpageRes = rootPage.getContentResource();
				Resource rootpagemainpar = adminResolver.getResource(rootpageRes , rootnodepath);
				if(null != rootpagemainpar){
					Node rootpagemainNode = rootpagemainpar.adaptTo(Node.class);
					if (rootpagemainNode.hasNodes()) 
					{
						NodeIterator primarychildNodes = rootpagemainNode.getNodes();
						while (primarychildNodes.hasNext()) 
						{
							Node primarychildNode = primarychildNodes.nextNode();
							strnodepath=getNodePath(currentPagePath,primarychildNode.getPath().toString());
							strrefNodePath="";	
							if (primarychildNode.hasProperty("referenceNodePath")) {		
								strrefNodePath=primarychildNode.getProperty("referenceNodePath").getString();
							}
							if(strrefNodePath.equals("")){
								mainnodepathmap.put(strnodepath,"");	
							}
							else{
								dupnodepath_refpathmap.put(strnodepath,strrefNodePath);
							}
							if (primarychildNode.hasNodes()) 
							{
								NodeIterator secondarychildNodes = primarychildNode.getNodes();
								while (secondarychildNodes.hasNext()) 
								{
									//Secondary
									Node secondarychildNode = secondarychildNodes.nextNode();
									strnodepath=getNodePath(currentPagePath,secondarychildNode.getPath().toString());
									strrefNodePath="";
									if (secondarychildNode.hasProperty("referenceNodePath")) {
									    strrefNodePath=secondarychildNode.getProperty("referenceNodePath").getString();
									}
									if(strrefNodePath.equals("")){
										mainnodepathmap.put(strnodepath,"");	
									}
									else{
										dupnodepath_refpathmap.put(strnodepath,strrefNodePath);
									}
									if (secondarychildNode.hasNodes()) 
									{
										NodeIterator tertiaryNodes = secondarychildNode.getNodes();
										while (tertiaryNodes.hasNext()) 
										{
											//Tertiary
											Node tertiaryNode = tertiaryNodes.nextNode();
											strnodepath=getNodePath(currentPagePath,tertiaryNode.getPath().toString());
											strrefNodePath="";
											if (tertiaryNode.hasProperty("referenceNodePath")) 
											{
												strrefNodePath=tertiaryNode.getProperty("referenceNodePath").getString();
											}
											if(strrefNodePath.equals("")){
												mainnodepathmap.put(strnodepath,"");	
											}
											else{
												dupnodepath_refpathmap.put(strnodepath,strrefNodePath);
											}
										}
									}
								}
							} 	
						}
						for (String nodepath : dupnodepath_refpathmap.keySet()) {
							strrefNodePath=dupnodepath_refpathmap.get(nodepath);
							if (!(mainnodepathmap.containsKey(strrefNodePath))){
								output +="<tr><td>" + nodepath + "</td><td>" + strrefNodePath + "</td></tr>";
							}
						}	
					}   
				}// end of rootpagemainpar null
			} //end of if
			
		}//end of try
		catch(Exception e){
			logger.error("Unable to parse", e);
		}
		return output;
	}
	/**
	 *  
	*/	
	public static String getNodePath(String currentPagePath, String strnodepath) {
		strnodepath=strnodepath.replace(currentPagePath  ,"");
		strnodepath=strnodepath.replace("/jcr:content/mainpar/" ,"").toString();
        return strnodepath;
    }
}
