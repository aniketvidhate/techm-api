package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;
import java.util.Dictionary;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.helpers.PathHelpers;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.WCMMode;
import com.day.cq.wcm.commons.WCMUtils;

/**
 * Filter which redirects static asset requests to an alternate domain for situations where the static assets are not
 * available locally.
 */
@Component(immediate = true, metatype = true, label = "Accessory Redirect Filter", description = "Filter to redirect requests for /shop/wireless/accessories/.")
@Service
@Property(name = "pattern", value = "/.*./wireless/accessories/.+.sku.*")
public class AccessoryRedirectFilter implements Filter {

	@Reference
	private ResourceResolverFactory resolverFactory;
	
    /**
     * The default enabled state.
     */
    private static final boolean DEFAULT_ENABLED = true;
    
    /**
     * OSGi configuration property for enable state.
     */
    @Property(label = "Enabled", description = "Is redirect enabled?", boolValue = DEFAULT_ENABLED)
    private static final String PROP_ENABLED = "redirect.enabled";

    /**
     * The current enabled state.
     */
    private boolean mEnabled;

    /**
     * A logger.
     */
    private final Logger mLogger = LoggerFactory.getLogger(this.getClass());

    /**
     * Activate this component.
     * 
     * @param pCtx
     *            the OSGi component context
     */
    protected void activate(final ComponentContext pCtx) {
        final Dictionary<?, ?> props = pCtx.getProperties();
        this.mEnabled = OsgiUtil.toBoolean(props.get(PROP_ENABLED), DEFAULT_ENABLED);

    }

    /**
     * No-op. Normal filter livecycle ignored.
     */
    @Override
    public void destroy() {
    }

    /**
     * If enabled, construct a redirect path and send a redirect.
     * 
     * @param pRequest
     *            the request
     * @param pResponse
     *            the response
     * @param pChain
     *            the filter chain
     */
    @Override
    public void doFilter(final ServletRequest pRequest, final ServletResponse pResponse, final FilterChain pChain)
            throws IOException, ServletException {
    	
        if (!this.mEnabled) {
            pChain.doFilter(pRequest, pResponse);
        } else {
            if (pRequest instanceof HttpServletRequest && pResponse instanceof HttpServletResponse) {
                final HttpServletRequest httpRequest = (HttpServletRequest) pRequest;
                final HttpServletResponse httpResponse = (HttpServletResponse) pResponse;
                final String path = httpRequest.getPathInfo();
                try {
    
                	ResourceResolver resourceResolver = resolverFactory.getAdministrativeResourceResolver(null);
                	Resource resource = resourceResolver.resolve(httpRequest.getPathInfo());
                	Page currentPage = resource.adaptTo(Page.class);
                	if (currentPage != null) {
                		ValueMap props = currentPage.getProperties();
                		String skuPage = props.get("sku", String.class);
                		if (skuPage != null) {
	                		Page accPage = PathHelpers.getAccessoryDetailsPage(resourceResolver, currentPage, skuPage);
	                		String title = accPage.getTitle();
	                		String redirectPath = PathHelpers.getDynamicAccessoryDetailsPagePath(resourceResolver, currentPage, skuPage, title);
	                		String queryString = httpRequest.getQueryString();
	                		//Check for content
	                		if (StringUtils.isNotEmpty(redirectPath)) {
	                			httpResponse.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
	                			httpResponse.setHeader("Location", redirectPath + (queryString == null ? "" : "?" + queryString));
	                		} else {
	                			this.mLogger.debug("Redirect failed to occur because a redirect path could not be created from getDynamicAccessoryDetailsPagePath. Request URL: " + httpRequest.getRequestURL());
	                		}
                		} else {
                			this.mLogger.debug("Redirect failed to occur because a Sku could not be found in the current page. Request URL: " + httpRequest.getRequestURL());
                			pChain.doFilter(pRequest, pResponse);
                		}
                	} else {
                		this.mLogger.debug("Redirect failed to occur because the current CQ page could not be created with adaptTo(Page.class) method. Request URL: " + httpRequest.getRequestURL());
                		pChain.doFilter(pRequest, pResponse);
                	}
                } catch (IllegalStateException e) {
                    this.mLogger.warn("Error in redirecting request for {}: {}", new Object[] { path, e.getMessage() });
                    pChain.doFilter(pRequest, pResponse);
                } catch (LoginException e) {
                	this.mLogger.warn("Error logging in to session to get resourceResolver. {}", new Object [] {e.getMessage()});
                	pChain.doFilter(pRequest, pResponse);
                }
               
            } else {
            	this.mLogger.debug("Redirect failed to occur because a the Servlet Request and Response couldn't be cast Http equivalent objects.");
                pChain.doFilter(pRequest, pResponse);
            }
        }
    }

    /**
     * No-op. Normal filter livecycle ignored.
     */
    @Override
    public void init(final FilterConfig pFilterConfig) throws ServletException {
    }

}
