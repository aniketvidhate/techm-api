package com.att.ecom.cq.bundle.helpers;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;


import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.Value;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import com.day.cq.wcm.api.PageManager;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.wcm.api.Page;
import java.io.File;
import java.io.StringWriter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.OutputKeys;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/*
 * @author Shovon Zaman (sz1004)
 * @created on July 2013
 * Notes:
 */


@Component(immediate = true, name = "Global Navigation NextGen")
@Service(value = com.att.ecom.cq.bundle.helpers.GlobalNavigation.class )

public class GlobalNavigation
{

	private Logger logger = LoggerFactory.getLogger(GlobalNavigation.class);

	@Reference
	private SlingRepository slingRepository;
	
	@Reference
	private ResourceResolverFactory resourceResolverFactory;	

	private Session administrativeSession;
	
	private String cookieLessDomain;
	private static final String configPath="/content/att/config/gnav/gnavconfig/jcr:content";
	
	DocumentBuilderFactory docFactory; 
	DocumentBuilder docBuilder;
	// root elements
	Document doc;
	Element rootElement;
		

	protected void activate(ComponentContext ctx) throws RepositoryException 
	{
		administrativeSession = slingRepository.loginAdministrative(null);
	}
	
	protected void deactivate(ComponentContext ctx) {
		administrativeSession.logout();
	}
	/*
     * Get the CQ template Paths
     */	
	public synchronized String navXml(String currentPagePath) throws RepositoryException 
	{
		String output="";		
		String children="SELECT * FROM nt:base WHERE jcr:path like '"+currentPagePath +"/%' and jcr:primaryType='cq:Page' ";
		if (administrativeSession.isLive()) 
		{	
			// get QueryManager
    		QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();    		
    		// make SQL query
    		Query query = queryManager.createQuery(children, Query.SQL);
    		// execute query
    		QueryResult result = query.execute();
    		// execute query and fetch result
    		NodeIterator nodes = result.getNodes();
    		ResourceResolver adminResolver = null;
			try 
			{
				String template_name,module_name,node_name,nodepath;
				adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
				cookieLessDomain=getcookieLessDomain(configPath,adminResolver);
				docFactory = DocumentBuilderFactory.newInstance();
				docBuilder = docFactory.newDocumentBuilder();
				doc = docBuilder.newDocument();				
				rootElement = doc.createElement("add");
				doc.appendChild(rootElement);
				//doc =parseCurrentPage(currentPagePath,doc);
				while (nodes.hasNext()) 
				{
					Node node = nodes.nextNode();
					doc =parseCurrentPage(node.getPath().toString(),"mainpar/header","ge5p_z1",doc,adminResolver);
					doc =parseCurrentPage(node.getPath().toString(),"mainpar/footer","ge5p_z7",doc,adminResolver);
					doc =parseCurrentPage(node.getPath().toString(),"mainpar/globalnav","ge5p_z2",doc,adminResolver);
			    }
				// write the content into xml file
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				transformer.setOutputProperty(OutputKeys.METHOD, "xml");
				transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
				DOMSource source = new DOMSource(doc);				
				StreamResult streamResult = new StreamResult(new StringWriter());
				transformer.transform(source, streamResult);
				output=streamResult.getWriter().toString().trim();
			}catch (LoginException e) {
				logger.error("Unable to login for CMS Repository Report", e);
			}
			catch(ParserConfigurationException pce){
				logger.error("ParserConfigurationException", pce);
			}
			catch(TransformerException  tfe){
				logger.error("TransformerException", tfe);
			}
			finally {
				if (adminResolver != null) {
					adminResolver.close();
				}
			}
		}
		return output;	
	}
	
	/**
	 * Parsing giving Global Navigation 
	 * return elements
	 */
	public synchronized Document parseCurrentPage(String currentPagePath,String rootnodepath,String prefix, Document pageDoc,ResourceResolver adminResolver) throws RepositoryException {
		String nodepath="";
		Attr attr;
		try{
			PageManager pageManager = adminResolver.adaptTo(PageManager.class);
			Page rootPage = pageManager.getPage(currentPagePath);
			
			int primarynavnumid=1;
			String strnavposition="";
			String strelementid;
			String strpositionalcode;
			String strnodepath;
			String strrefNodePath;
			
			Map<String, Node> reference_id_node = new HashMap<String, Node>();
			Map<String, String> node_path_navposition = new HashMap<String, String>();
			Map<String, String> node_path_positionalcode = new HashMap<String, String>();

			
			if( null != rootPage){
				Resource rootpageRes = rootPage.getContentResource();
				Resource rootpagemainpar = adminResolver.getResource(rootpageRes , rootnodepath);
				if(null != rootpagemainpar){
					Node rootpagemainNode = rootpagemainpar.adaptTo(Node.class);
					if (rootpagemainNode.hasNodes()) 
					{
						NodeIterator primarychildNodes = rootpagemainNode.getNodes();
						int primarynavnum=0;
						int secondarynavnum=0;
						int tertiarynavnum=0;
						while (primarychildNodes.hasNext()) 
						{
							//Primary
							primarynavnumid= primarynavnumid + 1000;
							int secondarynavnumid=primarynavnumid;
							int tertiarynavnumid=primarynavnumid;
							secondarynavnum=0;
							tertiarynavnum=0;
							strelementid=prefix + "_p" + Integer.toString(primarynavnumid);
							Node primarychildNode = primarychildNodes.nextNode();
							strrefNodePath="";
							if (primarychildNode.hasProperty("referenceNodePath")) 
							{
								strrefNodePath=primarychildNode.getProperty("referenceNodePath").getString();
							}
							if(strrefNodePath.equals(""))
							{
								primarynavnum++;
							    strnavposition= prefix + "_" + Integer.toString(primarynavnum);
							    strpositionalcode=intToString(primarynavnum,2) + intToString(secondarynavnum,2) + intToString(tertiarynavnum,2);
								strnodepath=getNodePath(currentPagePath,primarychildNode.getPath().toString());
								node_path_navposition.put(strnodepath,strnavposition);
								node_path_positionalcode.put(strnodepath,strpositionalcode);
							   	pageDoc=addchildelementitems(primarychildNode,pageDoc,strnavposition, strelementid,strpositionalcode,adminResolver);    	
							}
							else
							{
								reference_id_node.put(strelementid,primarychildNode);
							}
							if (primarychildNode.hasNodes()) 
							{
								NodeIterator secondarychildNodes = primarychildNode.getNodes();
								while (secondarychildNodes.hasNext()) 
								{
									//Secondary
									tertiarynavnum=0;
									strelementid=prefix + "_s" + Integer.toString(secondarynavnumid);
									Node secondarychildNode = secondarychildNodes.nextNode();
									strrefNodePath="";
									if (secondarychildNode.hasProperty("referenceNodePath")) 
									{
									    strrefNodePath=secondarychildNode.getProperty("referenceNodePath").getString();
									}
									if(strrefNodePath.equals(""))
									{
										secondarynavnum++;
										strpositionalcode=intToString(primarynavnum,2) + intToString(secondarynavnum,2) + intToString(tertiarynavnum,2);
										strnodepath=getNodePath(currentPagePath,secondarychildNode.getPath().toString());
										node_path_navposition.put(strnodepath,strnavposition);
										node_path_positionalcode.put(strnodepath,strpositionalcode);
										pageDoc=addchildelementitems(secondarychildNode,pageDoc,strnavposition, strelementid,strpositionalcode,adminResolver);	
									}
									else
									{										
										reference_id_node.put(strelementid,secondarychildNode);
									}
									if (secondarychildNode.hasNodes()) 
									{
										NodeIterator tertiaryNodes = secondarychildNode.getNodes();
										while (tertiaryNodes.hasNext()) 
										{
											//Tertiary
											strelementid=prefix + "_t" + Integer.toString(tertiarynavnumid);
											Node tertiaryNode = tertiaryNodes.nextNode();
											strrefNodePath="";
											if (tertiaryNode.hasProperty("referenceNodePath")) 
											{
												strrefNodePath=tertiaryNode.getProperty("referenceNodePath").getString();
											}
											if(strrefNodePath.equals(""))
											{
												tertiarynavnum++;
											    strpositionalcode=intToString(primarynavnum,2) + intToString(secondarynavnum,2) + intToString(tertiarynavnum,2);
												strnodepath=getNodePath(currentPagePath,tertiaryNode.getPath().toString());
												node_path_navposition.put(strnodepath,strnavposition);
												node_path_positionalcode.put(strnodepath,strpositionalcode);	
												pageDoc=addchildelementitems(tertiaryNode,pageDoc,strnavposition, strelementid,strpositionalcode,adminResolver);
											}
											else
											{
												reference_id_node.put(strelementid,tertiaryNode);
											}
											tertiarynavnumid++;
										}
									}
									secondarynavnumid++;
								}
							} 	
						}
						for (String hashkey : reference_id_node.keySet())  
						{
							strrefNodePath="";
							Node refnode=reference_id_node.get(hashkey);
							if (refnode.hasProperty("referenceNodePath")) 
							{
								strrefNodePath=refnode.getProperty("referenceNodePath").getString();
							}
							if(!(strrefNodePath.equals("")))
							{
							    if (node_path_navposition.containsKey(strrefNodePath))
								{
									strnavposition=node_path_navposition.get(strrefNodePath);
									strpositionalcode=node_path_positionalcode.get(strrefNodePath);
									pageDoc=addchildelementitems(refnode,pageDoc,strnavposition, hashkey,strpositionalcode,adminResolver);
								}
							}
						}				
					}   
				}// end of rootpagemainpar null
			} //end of if
			
		}//end of try
		catch(Exception e){
			logger.error("Unable to parse", e);
		}
		return pageDoc;
	}
	/**
	*/
	public synchronized Document addchildelementitems(Node tempNode, Document pageDoc, String strnavposition,String  strelementid,String strpositionalcode,ResourceResolver adminResolver) throws RepositoryException {	
		     Element childElement;
		     try{
				Element docElement = pageDoc.createElement("doc");
				rootElement.appendChild(docElement);
				//nav_position
				pageDoc=buildChildren("nav_position",strnavposition,pageDoc,docElement);
				//id
				pageDoc=buildChildren("id",strelementid,pageDoc,docElement);  	
				//url field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "url" ); 	            		            
				//url_es field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "url_es");				
				//url_iru field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "url_iru");
				//url_iru_es field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "url_iru_es");
				//displayName field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "displayName");
				//displayName_es field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "displayName_es");
				//displayName_iru field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "displayName_iru");
				//displayName_iru_es field							
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "displayName_iru_es");
				//isHeading field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "isHeading");
				//positionalCode 
				pageDoc=buildChildren("positionalCode",strpositionalcode,pageDoc,docElement);
				//highlightCode field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "highlightCode");
				//windowLocation field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "windowLocation");
				//image field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "image");
				//image_es field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "image_es");
				//image_iru field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "image_iru");				
				//image_iru_es field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "image_iru_es");
				//specialTreatment field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "specialTreatment");
				//advanced field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "advanced");
				//actionType field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "actionType");
				//Check externalUrl field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "externalUrl");			
				//Check showGroup field
				if (tempNode.hasProperty("showGroup")) {
					try{
						Value[]  groupsvalues= tempNode.getProperty("showGroup").getValues();   
						for(int groupvalueindex=0; groupvalueindex<groupsvalues.length ;groupvalueindex++){                        	
							pageDoc=buildChildren("showGroup",groupsvalues[groupvalueindex].getString(),pageDoc,docElement);   	                        	
						}
					}
					catch(RepositoryException e){
						pageDoc=buildChildren("showGroup",tempNode.getProperty("showGroup").getString(),pageDoc,docElement);            	
					}
				}//end of showGroup
				
				//Check hideGroup field
				if (tempNode.hasProperty("hideGroup")) {
					try{
						Value[]  groupsvalues1= tempNode.getProperty("hideGroup").getValues();   
						for(int groupvalueindex1=0; groupvalueindex1<groupsvalues1.length ;groupvalueindex1++){                        	
							pageDoc=buildChildren("hideGroup",groupsvalues1[groupvalueindex1].getString(),pageDoc,docElement);   	                        	
						}
					}
					catch(RepositoryException e){
						pageDoc=buildChildren("hideGroup",tempNode.getProperty("hideGroup").getString(),pageDoc,docElement);            	
					}
				}//end of hideGroup
				
				//additionalLabel field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "additionalLabel");
				//additionalLabel_es field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "additionalLabel_es");
				//Check hiddenText field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "hiddenText");
				//Check hiddenText_es field
				pageDoc=addchildElement(tempNode,pageDoc,adminResolver,docElement, "hiddenText_es");				
			 }//end of try
			 catch(Exception e){
					logger.error("Unable to parse", e);
			 }
		return pageDoc;
	}
	/**
	 *  build child elements
	*/
	public synchronized Document addchildElement(Node tempNode, Document pageDoc,ResourceResolver adminResolver,Element docElement, String strPropertyname ) throws RepositoryException {	
		try{
			String strvalue="";
			if (tempNode.hasProperty(strPropertyname)) {
				strvalue=tempNode.getProperty(strPropertyname).getString();
			}
			if((!(strvalue.equals("")))&& (strPropertyname.matches("^image.*")))
			{
				strvalue=cookieLessDomain + adminResolver.map(strvalue);
			}			
			pageDoc=buildChildren(strPropertyname,strvalue,pageDoc,docElement);  	
		 }//end of try
		 catch(Exception e){
				logger.error("Unable to parse", e);
		 }
		 return pageDoc;
	}
	
	/**
	 *  build child elements
	 */
	public synchronized Document buildChildren(String fieldName, String cqPropertyName,  Document childPageDoc, Element docElement) throws RepositoryException {
		Attr attr;
		Element childElement;
		try{
			childElement=childPageDoc.createElement("field");
        	childElement.appendChild(childPageDoc.createCDATASection(cqPropertyName));
        	docElement.appendChild(childElement);
        	// set attribute to field element
        	attr = childPageDoc.createAttribute("name");
        	attr.setValue(fieldName);
        	childElement.setAttributeNode(attr);
		}
		catch(Exception e){
			logger.error("Unable to build Child Elements", e);
		}		
		return childPageDoc;
	}
	/**
	 *  
	*/
	public static String intToString(int num, int digits) {
        String output = Integer.toString(num);
        while (output.length() < digits) output = "0" + output;
        return output;
    }
	/**
	 *  
	*/	
	public static String getNodePath(String currentPagePath, String strnodepath) {
		strnodepath=strnodepath.replace(currentPagePath  ,"");
		strnodepath=strnodepath.replace("/jcr:content/mainpar/" ,"").toString();
        return strnodepath;
    }
	/**getcookieLessDomain function
	 * return strCookielessDomain
	 */
	public synchronized String getcookieLessDomain(String configPath,ResourceResolver adminResolver) throws RepositoryException {
        String strCookielessDomain="";
		try{
			Resource configresource = adminResolver.getResource(configPath);
			Node currNode = configresource.adaptTo(Node.class);
			if (currNode.hasProperty("CookielessDomain")) {
				strCookielessDomain = currNode.getProperty("CookielessDomain").getString();
			}
		}//end of try
		catch(Exception e){
			logger.error("Erro", e);
		}
		return strCookielessDomain;
	}
}