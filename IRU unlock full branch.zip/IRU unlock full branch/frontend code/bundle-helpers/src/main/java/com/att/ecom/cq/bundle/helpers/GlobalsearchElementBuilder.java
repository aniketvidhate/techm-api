/*
 * Globalsearch Element Builder.
 * @author Pratap Cheruvu (rc8891)
 * @created on Jan 05 2013
 */


package com.att.ecom.cq.bundle.helpers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Property;
import javax.jcr.PropertyIterator;
import javax.jcr.Value;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import com.day.cq.wcm.api.PageManager;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;


import java.io.File;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
 
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


@Component(immediate=true)
@Service(value=GlobalsearchElementBuilder.class)

public class GlobalsearchElementBuilder 
{

	private Logger logger = LoggerFactory.getLogger(GlobalsearchElementBuilder.class);

	@Reference
	private SlingRepository slingRepository;
	
	@Reference
	private ResourceResolverFactory resourceResolverFactory;	

	private Session administrativeSession;
	
	DocumentBuilderFactory docFactory; 
	DocumentBuilder docBuilder;
	// root elements
	Document doc;
	Element rootElement;
	
	private int pageid=0;
	

	protected void activate(ComponentContext ctx) throws RepositoryException 
	{
		administrativeSession = slingRepository.loginAdministrative(null);
	}
	
	protected void deactivate(ComponentContext ctx) {
		administrativeSession.logout();
	}
	/*
     * Get the CQ template Paths
     */	
	public synchronized String buildElements(String currentPagePath) throws RepositoryException 
	{
		String output="";
		pageid=0;
		
		String child_Pages="SELECT * FROM nt:base WHERE jcr:path like '"+currentPagePath +"/%' and jcr:primaryType='cq:Page' ";
		if (administrativeSession.isLive()) 
		{	
			// get QueryManager
    		QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();    		
    		// make SQL query
    		Query query = queryManager.createQuery(child_Pages, Query.SQL);
    		// execute query
    		QueryResult result = query.execute();
    		// execute query and fetch result
    		NodeIterator nodes = result.getNodes();
    		ResourceResolver adminResolver = null;
    		int indent=2;
			try 
			{
				String template_name,module_name,node_name,nodepath;
				adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);				
				docFactory = DocumentBuilderFactory.newInstance();
				docBuilder = docFactory.newDocumentBuilder();
				doc = docBuilder.newDocument();				
				rootElement = doc.createElement("add");
				doc.appendChild(rootElement);
				doc =parseCurrentPage(currentPagePath,doc);
				while (nodes.hasNext()) 
				{
					Node node = nodes.nextNode();
					doc =parseCurrentPage(node.getPath().toString(),doc);
					
			    }
				// write the content into xml file
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				transformerFactory.setAttribute("indent-number", indent);
				Transformer transformer = transformerFactory.newTransformer();
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				DOMSource source = new DOMSource(doc);				
				StreamResult streamResult = new StreamResult(new StringWriter());
				transformer.transform(source, streamResult);
				output=streamResult.getWriter().toString();
					
			}catch (LoginException e) {
				logger.error("Unable to login for CMS Repository Report", e);
			}
			catch(ParserConfigurationException pce){
				logger.error("ParserConfigurationException", pce);
			}
			catch(TransformerException  tfe){
				logger.error("TransformerException", tfe);
			}
			finally {
				if (adminResolver != null) {
					adminResolver.close();
				}
			}
		}		
		return output;	
	}
	
	/**
	 * Parsing giving Global Search promoion page 
	 * return elements
	 */
	public synchronized Document parseCurrentPage(String currentPagePath, Document pageDoc) throws RepositoryException {
		ResourceResolver adminResolver = null;
		String nodepath="";
		Attr attr;
		Element childElement;
		try{
			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			PageManager pageManager = adminResolver.adaptTo(PageManager.class);
			Page rootPage = pageManager.getPage(currentPagePath);
			if( null != rootPage){
				Resource rootpageRes = rootPage.getContentResource();
				Resource rootpagemainpar = adminResolver.getResource(rootpageRes , "mainpar");
				if(null != rootpagemainpar){
					Node rootpagemainNode = rootpagemainpar.adaptTo(Node.class);  
	            // iterator all doc
					for ( NodeIterator ni = rootpagemainNode .getNodes(); ni.hasNext();) {
		            	Node tempNode =  ni.nextNode();
		            	pageid++;
		            	
		            	//get Node path
		            	nodepath= tempNode.getCorrespondingNodePath(tempNode.getSession().getWorkspace().getName());            	
		            	Element docElement = pageDoc.createElement("doc");
		            	rootElement.appendChild(docElement);
		            	 
		            	pageDoc=buildChildElements("id",Integer.toString(pageid),pageDoc,docElement);
		            	pageDoc=buildChildElements("cqid",nodepath,pageDoc,docElement);
	            	
		            	//Check userBase
		            	if (tempNode.hasProperty("userbase")) {
		            		pageDoc=buildChildElements("userBase",tempNode.getProperty("userbase").getString(),pageDoc,docElement);                	
		                }
		            	else{
		            		pageDoc=buildChildElements("userBase","All",pageDoc,docElement);
		            	}
		            	//end of   userbase
		            	
		            	//Check Customer Type
		            	if (tempNode.hasProperty("Customer Type")) {
		            		try{
		                  		Value[]  customertypevalues= tempNode.getProperty("Customer Type").getValues();   
		                  		for(int customertypevalueindex=0; customertypevalueindex<customertypevalues.length ;customertypevalueindex++){
		                  			pageDoc=buildChildElements("customerType",customertypevalues[customertypevalueindex].getString(),pageDoc,docElement);
		                  		}
		                	}
							catch(RepositoryException e){
								pageDoc=buildChildElements("customerType",tempNode.getProperty("Customer Type").getString(),pageDoc,docElement);						                    	
							}
		            	} //end of customer type
		                
		                //doctype
		                if (tempNode.hasProperty("doctype")) {
		                	pageDoc=buildChildElements("docType",tempNode.getProperty("doctype").getString(),pageDoc,docElement);
		                } //end of doctype
		                
		                //search categories
		                if (tempNode.hasProperty("Search Categories")) {
		            		try{
		            			Value[]  searchcategoriesvalues= tempNode.getProperty("Search Categories").getValues();   
		            			for(int searchcategoryvalueindex=0; searchcategoryvalueindex<searchcategoriesvalues.length ;searchcategoryvalueindex++){                        	
		            				pageDoc=buildChildElements("searchCategory",searchcategoriesvalues[searchcategoryvalueindex].getString(),pageDoc,docElement);                   	
		                  		}
		                	}
							catch(RepositoryException e){
								pageDoc=buildChildElements("searchCategory",tempNode.getProperty("Search Categories").getString(),pageDoc,docElement);               	
							}
		            	}//end of Search Categories
		                
		              //search categories List
		                if (tempNode.hasProperty("Search Category List")) {
		            		try{
		            			Value[]  searchcategorylistvalues= tempNode.getProperty("Search Category List").getValues();   
		            			for(int searchcategorylistindex=0; searchcategorylistindex<searchcategorylistvalues.length ;searchcategorylistindex++){                        	
		            				pageDoc=buildChildElements("searchCategory",searchcategorylistvalues[searchcategorylistindex].getString(),pageDoc,docElement);                   	
		                  		}
		                	}
							catch(RepositoryException e){
								pageDoc=buildChildElements("searchCategory",tempNode.getProperty("Search Category List").getString(),pageDoc,docElement);               	
							}
		            	}//end of Search Categories List
	                
		                	//search terms
			                if (tempNode.hasProperty("Search Terms")) {
			            		try{
			            			Value[]  searchtermsvalues= tempNode.getProperty("Search Terms").getValues();   
			            			for(int searchtermvalueindex=0; searchtermvalueindex<searchtermsvalues.length ;searchtermvalueindex++){                        	
			            				pageDoc=buildChildElements("searchTerms",searchtermsvalues[searchtermvalueindex].getString(),pageDoc,docElement);   	                        	
			                  		}
			                	}
								catch(RepositoryException e){
									pageDoc=buildChildElements("searchTerms",tempNode.getProperty("Search Terms").getString(),pageDoc,docElement);            	
								}
			            	}//end of Search Terms
			                
			                //Check header Field
			                if (tempNode.hasProperty("header")) {
			                	pageDoc=buildChildElements("header",tempNode.getProperty("header").getString(),pageDoc,docElement);
			                } //end of header
			                
			                //nooflinks
			                if (tempNode.hasProperty("nooflinks")) {
			                	pageDoc=buildChildElements("numberOfLinks",tempNode.getProperty("nooflinks").getString(),pageDoc,docElement);
			                } //end nooflinks
			                
			                //imageurl
			                if (tempNode.hasProperty("imageurl")) {
			                	pageDoc=buildChildElements("imageUrl",tempNode.getProperty("imageurl").getString(),pageDoc,docElement);
			                } //end imageurl
			                
			                //imageposition
			                if (tempNode.hasProperty("imageposition")) {
			                	pageDoc=buildChildElements("imagePosition",tempNode.getProperty("imageposition").getString(),pageDoc,docElement);
			                } //end imageposition
			              //ctaurl
			                if (tempNode.hasProperty("ctaurl")) {
			                	pageDoc=buildChildElements("ctaUrl",tempNode.getProperty("ctaurl").getString(),pageDoc,docElement);
			                } //end ctaurl
			              //ctaimage
			                if (tempNode.hasProperty("ctaimage")) {
			                	pageDoc=buildChildElements("ctaImage",tempNode.getProperty("ctaimage").getString(),pageDoc,docElement);
			                } //end ctaimage
			                
			                //Get All tiles
			                for ( NodeIterator tempnodeIterator = tempNode.getNodes(); tempnodeIterator .hasNext();) {
			                    Node tempIteratorNode =  tempnodeIterator .nextNode();  
			                    for ( NodeIterator tempIteratorNodeIterator = tempIteratorNode .getNodes(); tempIteratorNodeIterator .hasNext();) {
			                    	Node tileNode =  tempIteratorNodeIterator .nextNode();
			                        //title field
									 if (tileNode .hasProperty("title")) {                        	 
										 pageDoc=buildChildElements("title",tileNode.getProperty("title").getString(),pageDoc,docElement);
									 }//end of title
									 //startdate
									 if (tileNode .hasProperty("startdate")) {
										 pageDoc=buildChildElements("startDate",tileNode.getProperty("startdate").getString(),pageDoc,docElement);
										 	           
			                        }//end of start date
									//end date
									 if (tileNode .hasProperty("enddate")) {
										 pageDoc=buildChildElements("endDate",tileNode.getProperty("enddate").getString(),pageDoc,docElement); 
			                        }
									 //end of end date
									 //start imageurls
									 if (tileNode .hasProperty("imageurls")) {
			                        	 String[]  imageurlssplit= tileNode .getProperty("imageurls").getString().split(",");
			                        	 for(String imageurlsplit: imageurlssplit){                     			
			                        		 pageDoc=buildChildElements("endDate",tileNode.getProperty("enddate").getString(),pageDoc,docElement); 
			                     		}           
			                        }
									 //end imageurls
									 //start url
									 if (tileNode .hasProperty("url")) {
										 pageDoc=buildChildElements("url",tileNode.getProperty("url").getString(),pageDoc,docElement);          
			                        }
									 //end  url
									 //start zipcode
									 if (tileNode .hasProperty("zipcode")) {
										 pageDoc=buildChildElements("zipCode",tileNode.getProperty("zipcode").getString(),pageDoc,docElement);							 
									 }
									 //end zipcode
									 //start state
									 if (tileNode .hasProperty("state")) {
										 pageDoc=buildChildElements("state",tileNode.getProperty("state").getString(),pageDoc,docElement);
									 }
									 //end state
									 //start dma
									 if (tileNode .hasProperty("dma")) {
										 pageDoc=buildChildElements("dma",tileNode.getProperty("dma").getString(),pageDoc,docElement); 
									 }
									 //end dma
		                    	}//end of tempIteratorNodeIterator
		                	}//end of reading tiles
	            		}  //end of iterator all doc
					}// end of rootpagemainpar null
			} //end of if
			
		}//end of try
		catch(Exception e){
			logger.error("Unable to parse", e);
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
			
		}
		
		return pageDoc;
	}	
	
	/**
	 *  build child elements
	 */
	public synchronized Document buildChildElements(String fieldName, String cqPropertyName,  Document childPageDoc, Element docElement) throws RepositoryException {
		Attr attr;
		Element childElement;
		try{
			childElement=childPageDoc.createElement("field");
        	childElement.appendChild(childPageDoc.createCDATASection(cqPropertyName));
        	docElement.appendChild(childElement);
        	// set attribute to staff element
        	attr = childPageDoc.createAttribute("name");
        	attr.setValue(fieldName);
        	childElement.setAttributeNode(attr);
		}
		catch(Exception e){
			logger.error("Unable to build Child Elements", e);
		}		
		return childPageDoc;
	}
}
