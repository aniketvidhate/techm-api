package com.att.ecom.cq.bundle.helpers;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Property;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.felix.scr.annotations.Reference;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.NonExistingResource;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;

@Component(immediate = true, metatype = true, label = "ATT CQ Environment Config")
@Service(value = ATTCQEnvironmentConfig.class)
public class ATTCQEnvironmentConfig {
	@SuppressWarnings("rawtypes")
	private static Dictionary props = null;
	
	private static final Logger mLogger = LoggerFactory.getLogger(ATTCQEnvironmentConfig.class);
	
	@Reference
    private ResourceResolverFactory resourceResolverFactory;

	@Property(
			label = "Valid 403 Entires", 
			value = {"/shop/.*","/shopmobile/.*","/maps/.*"},
			description = "Accepts regular expressions")
	private static final String PNAME_VALID_FOUR_ZERO_THREE_ENTRY_PATHS = "ValidFourZeroThree.EntryURI";
	
	@Property(
			label = "Global 403 Redirect", 
			value = "/homepage/sitemap.html")
	private static final String PNAME_GLOBAL_FOUR_ZERO_THREE_REDIRECT = "GlobalFourZeroThree.Redirect";
	
	@Property(
			label = "404 Redirect Entries", 
			value = {"/shop/.*=/homepage/sitemap.html","/shopmobile/.*=/shopmobile/homepage/index.html"},
			description = "Entry URLs (can be regex) which are mapped to a specific redirect page. e.g /shop/.*=/homepage/siteadmin.html")
	private static final String PNAME_FOUR_ZERO_FOUR_PATHS = "FourZeroFourRedirect.URI";
	
	@Property(
			label = "Global 404 Redirect", 
			value = "/homepage/sitemap.html",
			description = "Global 404 redirect.")
	private static final String PNAME_GLOBAL_FOUR_ZERO_FOUR_REDIRECT = "GlobalFourZeroFour.Redirect";
	
	@Property(
			label = "Do not redirect to URLs", 
			value = {"/shop.html", "/shopmobile/wireless.html", "/shopmobile.html"},
			description = "List of URLs to which redirect should not happen.")
	private static final String PNAME_FOUR_ZERO_FOUR_DONOT_REDIRECT = "FourZeroFourRedirect.DoNotRedirect";
	
	private HashMap<String,String> map404 = new HashMap<String,String>(); 
	private ArrayList<String> noRedirect404 = new ArrayList<String>();

	protected void activate(ComponentContext ctx) {
		props = ctx.getProperties();
		
		// Build map404
		map404.clear();
		for(String entry: get404ConfiguredPaths()) {
			String tokens[] = entry.split("=");
			if(tokens != null && tokens.length == 2) {
				map404.put(tokens[0], tokens[1]);
				mLogger.info("Adding 404 redirect entry path: " + entry);
			}
			else {
				mLogger.warn("Invalid 404 redirect entry path: " + entry + ". This path will not be used.");
			}
		}
		
		// build noRedirect404
		noRedirect404.clear();
		for(String entry : getNoRedirect404()) {
			noRedirect404.add(entry);
		}
	}
	
	public String[] getValid403EntryPaths() {
		return OsgiUtil.toStringArray(props.get(PNAME_VALID_FOUR_ZERO_THREE_ENTRY_PATHS), new String[] {"/shop/.*", "/shopmobile/.*", "/maps/.*"});
	}
	
	public String getGlobal403Redirect() {
		return OsgiUtil.toString(props.get(PNAME_GLOBAL_FOUR_ZERO_THREE_REDIRECT), "/homepage/sitemap.html");
	}
	
	public String getGlobal404Redirect() {
		return OsgiUtil.toString(props.get(PNAME_GLOBAL_FOUR_ZERO_FOUR_REDIRECT), "/homepage/sitemap.html");
	}
	
	public String[] get404ConfiguredPaths() {
		return OsgiUtil.toStringArray(props.get(PNAME_FOUR_ZERO_FOUR_PATHS), new String[] {"/shop/.*=/homepage/sitemap.html","/shopmobile/.*=/shopmobile/homepage/index.html"});
	}
	
	public String[] getNoRedirect404() {
		return OsgiUtil.toStringArray(props.get(PNAME_FOUR_ZERO_FOUR_DONOT_REDIRECT), new String[] {"/shop.html", "/shopmobile/wireless.html", "/shopmobile.html/"});
	}
	
	public String find403Redirect(String URI) {
		if(isAllowed403EntryPath(URI)) {
			return getAdjusted403Path(URI);
		}
		
		return null;
	}
	
	public String find404Redirect(String URI) {
		for(String entry : map404.keySet()) {
			if(URI.matches(entry)) {
				String redirectValue = map404.get(entry);
				mLogger.debug("Found valid 404 cofiguration " + entry + "=" + redirectValue + ". for URI " + URI);
				return redirectValue;
			}
		}
		
		return null;
	}
	
	public boolean isInDoNotRedirect404List(String url) {
		return noRedirect404.contains(url);
	}
	
	private String getAdjusted403Path(String URI) {
		mLogger.debug("Adjusting path for resource " + URI);
		ResourceResolver resolver = null;
		try {
			resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			Resource resource = resolver.resolve(URI);
			if(resource != null && !(resource instanceof NonExistingResource)) {
				String path = resolver.map(resource.getPath());
				return path + ".html";
			}
			else {
				mLogger.debug("No resource resolved for (403)URI " + URI);
			}
		} catch (LoginException e) {
			mLogger.error("Error encounterd while obtaining ResourceResolver from factory.", e);
		} finally {
			if(resolver != null) {
				resolver.close();
			}
		}
		
		return null;
	}
	
	private boolean isAllowed403EntryPath(String URI) {
		for(String allowedPath : getValid403EntryPaths()) {
			if(URI.matches(allowedPath)) {
				mLogger.debug("Found valid 403 entry path configured " + allowedPath + " for URI " + URI);
				return true;
			}
		}
		
		mLogger.debug("No valid 403 entry path configurred for URI " + URI);
		return false;
	}
}
