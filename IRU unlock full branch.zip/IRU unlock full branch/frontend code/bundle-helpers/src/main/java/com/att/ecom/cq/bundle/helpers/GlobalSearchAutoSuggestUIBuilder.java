package com.att.ecom.cq.bundle.helpers;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

@Component(immediate=true)
@Service(value=GlobalSearchAutoSuggestUIBuilder.class)

public class GlobalSearchAutoSuggestUIBuilder {

	private static final long serialVersionUID = 1L;

	private static final String ATTR_USER_QUERY="userQuery";
	private static final String ATTR_LOOKUPCOUNT="lookupCount";
	private static final String ATTR_ADMIN_BOOST="adminBoost";
	private static final String ATTR_COLLECTION="collection";

	private Logger logger = LoggerFactory.getLogger(GlobalsearchAutoSuggestElementBuilder.class);

	@Reference
	private SlingRepository slingRepository;

	@Reference
	private ResourceResolverFactory resourceResolverFactory;    

	private Session administrativeSession;

	protected void activate(ComponentContext ctx) throws RepositoryException 
	{
		administrativeSession = slingRepository.loginAdministrative(null);
	}

	protected void deactivate(ComponentContext ctx) {
		administrativeSession.logout(); 
	}
	/*
	 * Get the CQ template Paths
	 */ 
	public synchronized String buildElements(String currentPagePath) throws RepositoryException 
	{
		String output="";
		StringBuilder sb = new StringBuilder();

		String child_Pages="SELECT * FROM nt:base WHERE jcr:path like '"+currentPagePath +"/%' and jcr:primaryType='cq:Page' ";
		if (administrativeSession.isLive()) 
		{   
			// get QueryManager
			QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();         
			// make SQL query
			Query query = queryManager.createQuery(child_Pages, Query.SQL);
			// execute query
			QueryResult result = query.execute();
			// execute query and fetch result
			NodeIterator nodes = result.getNodes();
			ResourceResolver adminResolver = null;

			try 
			{
				adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);                

				while (nodes.hasNext()) 
				{
					Node node = nodes.nextNode();
					//logger.error("NODE=="+node.getName());
					sb =parseCurrentPage(node.getPath().toString(),sb);
				}
				if(sb.length()>0){      

					output=sb.toString();
					//logger.error("output=="+output);
				}else{
					output="<tr><td>Please start the Auto Suggest scheduler.</td></tr>";
				}
			}catch (LoginException e) {
				logger.error("Unable to login for CMS Repository Report", e);
			}
			finally {
				if (adminResolver != null) {
					adminResolver.close();
				}
			}
		}       
		return output;  
	}

	/**
	 * Parsing giving Global Search promoion page 
	 * return elements
	 */
	public synchronized StringBuilder parseCurrentPage(String currentPagePath, StringBuilder pageDoc) throws RepositoryException {
		ResourceResolver adminResolver = null;

		try{
			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			PageManager pageManager = adminResolver.adaptTo(PageManager.class);
			Page rootPage = pageManager.getPage(currentPagePath);
			if( null != rootPage){
				Resource rootpageRes = rootPage.getContentResource();
				Resource rootpagemainpar = adminResolver.getResource(rootpageRes ,"autosuggest");
				if(null != rootpagemainpar){
					Node tempNode =  rootpagemainpar.adaptTo(Node.class);
					//logger.error("TEMP NODE=="+tempNode.getProperty(ATTR_USER_QUERY).getString());
					//check for collection filter is enabled
					if(GlobalSearchAutoSuggestConfiguration.checkCollectionFilter()){
						if(tempNode.hasProperty(ATTR_COLLECTION) && tempNode.getProperty(ATTR_COLLECTION).getString().equalsIgnoreCase("0")){
							//Check userQuery
							//logger.error("HREF==="+rootPage.getPath().toString());
							if (tempNode.hasProperty(ATTR_USER_QUERY)) {
								pageDoc.append("<tr><td><a href='"+currentPagePath+".html' target=_blank>"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"</a></td>"+"=>");
							} 
							//end of   userQuery

							//Check Lookupcount
							if (tempNode.hasProperty(ATTR_LOOKUPCOUNT)) {
								pageDoc.append("<td>"+tempNode.getProperty(ATTR_LOOKUPCOUNT).getString()+"</td>"+"=>");                   
							}else{
								pageDoc.append("<td></td>"+"=>");
							}

							//Check boostLookupcount
							if (tempNode.hasProperty(ATTR_ADMIN_BOOST)) {
								pageDoc.append("<td><input onblur='removeextra(this)' data-val='"+tempNode.getProperty(ATTR_ADMIN_BOOST).getString()+"' type='text' name='"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"_"+tempNode.getProperty(ATTR_COLLECTION).getString()+"' id='"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"' value='"+tempNode.getProperty(ATTR_ADMIN_BOOST).getString()+"'></td></tr>"+"\n");                   
							}else{
								pageDoc.append("<td><input onblur='removeextra(this)' type='text' name='"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"_"+tempNode.getProperty(ATTR_COLLECTION).getString()+"' id='"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"'></td></tr>"+"\n");
							}
							//end of   boostLookupcount
						}
					}//end if collection filter is enabled
					else{
						//Check userQuery
							if (tempNode.hasProperty(ATTR_USER_QUERY)) {
								pageDoc.append("<tr><td><a href='"+currentPagePath+".html' target=_blank>"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"</a></td>"+"=>");
							} 
							//end of   userQuery

							//Check Lookupcount
							if (tempNode.hasProperty(ATTR_LOOKUPCOUNT)) {
								pageDoc.append("<td align='right'>"+tempNode.getProperty(ATTR_LOOKUPCOUNT).getString()+"</td>"+"=>");                   
							}else{
								pageDoc.append("<td></td>"+"=>");
							}

							//Check boostLookupcount
							if (tempNode.hasProperty(ATTR_ADMIN_BOOST)) {
								pageDoc.append("<td><input onblur='removeextra(this)' data-val='"+tempNode.getProperty(ATTR_ADMIN_BOOST).getString()+"' type='text' name='"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"_"+tempNode.getProperty(ATTR_COLLECTION).getString()+"' id='"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"' value='"+tempNode.getProperty(ATTR_ADMIN_BOOST).getString()+"'></td></tr>"+"\n");                   
							}else{
								pageDoc.append("<td><input onblur='removeextra(this)' type='text' name='"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"_"+tempNode.getProperty(ATTR_COLLECTION).getString()+"' id='"+tempNode.getProperty(ATTR_USER_QUERY).getString()+"'></td></tr>"+"\n");
							}
							//end of   boostLookupcount
						
					}
				}// end of rootpagemainpar null
			} //end of if

		}//end of try
		catch(Exception e){
			logger.error("Unable to parse", e);
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
		}
		//logger.error("PAGEDOC==="+pageDoc.toString());
		return pageDoc;
	}   

}
