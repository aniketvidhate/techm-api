package com.att.ecom.cq.bundle.helpers.internal;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;

/**
 * Generic superclass for filters which are overlaying a built-in servlet.
 */
public abstract class AbstractOverlayFilter implements Filter {

    /**
     * A constant for UTF-8 encoding.
     */
    private static final String ENCODING_UTF_8 = "utf-8";

    /**
     * The mime type for JSON responses.
     */
    private static final String MIME_JSON = "application/json";

    /**
     * Configure the response for a JSON response.
     * 
     * @param pResponse
     *            the response
     */
    protected static void setJsonHeaders(final SlingHttpServletResponse pResponse) {
        pResponse.setContentType(MIME_JSON);
        pResponse.setCharacterEncoding(ENCODING_UTF_8);
    }

    /**
     * No-op. Standard filter lifecycle is ignored.
     */
    @Override
    public void destroy() {
    }

    /**
     * Filter entry point. If the request is one we are supposed to handle, handle it. Otherwise, follow the chain.
     * 
     * @param pRequest
     *            the request
     * @param pResposne
     *            the response
     * @param pChain
     *            the filter chain
     */
    @Override
    public void doFilter(final ServletRequest pRequest, final ServletResponse pResponse, final FilterChain pChain)
            throws IOException, ServletException {
        if (pRequest instanceof SlingHttpServletRequest && pResponse instanceof SlingHttpServletResponse) {
            final SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) pRequest;
            final SlingHttpServletResponse slingResponse = (SlingHttpServletResponse) pResponse;
            if (shouldOverlayRequest(slingRequest)) {
                handle(slingRequest, slingResponse);
            } else {
                pChain.doFilter(pRequest, pResponse);
            }
        } else {
            pChain.doFilter(pRequest, pResponse);
        }

    }

    /**
     * Perform the actual handling of the request.
     * 
     * @param pRequest
     *            the request
     * @param pResponse
     *            the response
     * @throws IOException
     *             if the response can't be written
     */
    protected abstract void handle(final SlingHttpServletRequest pRequest, final SlingHttpServletResponse pResponse)
            throws IOException, ServletException;

    /**
     * No-op. Standard filter lifecycle is ignored.
     */
    @Override
    public void init(final FilterConfig pFilterConfig) throws ServletException {
    }

    /**
     * Determine if the request should be overlayed by this filter.
     * 
     * @param pSlingRequest
     *            the request
     * @return true if the request should be overlayed
     */
    protected abstract boolean shouldOverlayRequest(final SlingHttpServletRequest pSlingRequest);

}