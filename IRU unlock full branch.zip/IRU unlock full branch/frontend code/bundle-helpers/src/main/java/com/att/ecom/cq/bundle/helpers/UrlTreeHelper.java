package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.commons.io.IOUtils;

import com.day.cq.wcm.api.Page;

public class UrlTreeHelper {
    private static Pattern errDuringIncludePattern = Pattern.compile("<h1>Error during include of component '([/A-Za-z_0-9]+)'</h1>"); 
    
    public static List<String> getAttContentUrls(ResourceResolver resourceResolver,final String resourcePath, final String [] filters) {
        List<String> urls = new ArrayList<String>();
        
        Resource topResource = resourceResolver.getResource(resourcePath);
        Node topNode = topResource.adaptTo(Node.class);
        try {
            if (topNode.getPrimaryNodeType().isNodeType("cq:Page")) {
                String nodeUrl = resourceResolver.map(topNode.getPath() + ".html");
                Page topPage = topResource.adaptTo(Page.class);
                Resource topPageContent = topPage.getContentResource();
                ValueMap contentProps = ResourceUtil.getValueMap(topPageContent);
                if (topNode.getPath().contains("wireless/accessories/") && (contentProps.containsKey("sku") || contentProps.containsKey("skuId"))) {
                	String sku = contentProps.get("sku", "");
                	if (sku.equals("")) {
                		sku = contentProps.get("skuId", "");
                	}
                	String displayName = contentProps.get("jcr:title", "");
                	nodeUrl = PathHelpers.getDynamicAccessoryDetailsPagePath(resourceResolver, topPage, sku, displayName);
                }
                if (nodeUrl != null) {
                    if (!isFiltered(nodeUrl, filters)) {
                        urls.add(nodeUrl);
                    }
                }
            }
            if (topNode.hasNodes()) {
                NodeIterator childNodes = topNode.getNodes();
                while (childNodes.hasNext()) {
                    Node childNode = childNodes.nextNode();
                    urls.addAll(getAttContentUrls(resourceResolver, childNode.getPath(), filters));
                }
                
            }   
        } catch (RepositoryException ex) {
            
        }
        return urls;
    }
    
    public static boolean isFiltered(String nodePath, String[] filters) {
        
        for (String filter : filters) {
            if (nodePath.contains(filter)) {
                if (filter.contains("/help") && nodePath.contains("-category/")) {
                    return false;
                }
                if (filter.contains("/learningcenter") && nodePath.contains("/learningcenter/")) {
                    return false;
                }
                
                return true;
            }
        }
        
        return false;
    }
    
    public static void loadAllPages(List<String> urls, String urlPrefix, String urlSuffix, Writer writer) {
        for (String url : urls) {
            String realUrl = "http://" + (urlPrefix + url + urlSuffix).replace("//", "/");
            try {
                writeNoException(writer, "Loading \"" + url + "\".");
                writer.flush();
                HttpURLConnection connection = (HttpURLConnection) new URL(realUrl).openConnection();
                connection.setRequestMethod("HEAD");
                connection.getResponseCode();
            }
            catch (Exception ex) {
                ex.printStackTrace(new PrintWriter(writer));
            }
        }
    }
    
    public static void verifyPagesLoad(List<String> urls, String urlPrefix, String urlSuffix, int errorLimit, Writer writer) {
        int    totalErrors = 0;
        for (String url : urls) {
            String realUrl = "http://" + (urlPrefix + url + urlSuffix).replace("//", "/");
            try {
                writeNoException(writer, "Verifying \"" + url + "\".");
                writer.flush();
                HttpURLConnection connection = (HttpURLConnection) new URL(realUrl).openConnection();
                connection.setRequestMethod("GET");
                InputStream inputStream = connection.getErrorStream();
                if (inputStream == null)
                    inputStream = connection.getInputStream();
                if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    if ((++ totalErrors < errorLimit) || (errorLimit <= 0))
                        writeNoException(writer, "url[" + realUrl + "] failed, status[" + connection.getResponseCode() + "]" + "\n");
                    else
                        break;
                }
                else {
                    String  content = IOUtils.toString(inputStream);
                    Matcher matcher = errDuringIncludePattern.matcher(content);
                    if (matcher.find()) {
                        ++ totalErrors;
                        writeNoException(writer, "Error on page[" + matcher.group(1) + "] response[" + content + "]");
                    }
                }
            }
            catch (Exception ex) {
                writeNoException(writer, "url[" + realUrl + "] failed, exception[" + ex.getMessage() + "]" + "\n");
            }
        }
        if (totalErrors == 0)
            writeNoException(writer, "\nNo errors found.");
        else
            writeNoException(writer, "\n" + totalErrors + " error" + (totalErrors == 1 ? "" : "s") + " found.");
    }
    
    public static boolean isInArray(int target, int[] values) {
        boolean    result  = false;
        for (int value : values) {
            if (target == value) {
                result  = true;
                break;
            }
        }
        return result;
    }
    
    public static void writeNoException(Writer writer, String str) {
        try {
            writer.write(str);
        }
        catch (IOException ex) {
        }
    }
}
