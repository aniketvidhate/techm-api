package com.att.ecom.cq.bundle.helpers;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.ValueFactory;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SlingServlet(paths = "/system/att/cms/internaltools/synonyms")


public class GloablSearchExportSynonyms extends SlingAllMethodsServlet {

	/**
	 * Servlet to Automatically create Synonyms pages in CQ through XML
	 * created by : Hemant Arora(ha061x)
	 */
	private static final long serialVersionUID = 1L;
	private static final String JCR_PATH="/content/att/cmsfeed/globalsearch";
	private static final String NODE_SYNONYMS_AUTOMATION ="synonyms";
	private static final String RESOURCE_TYPE="sling:resourceType";
	private static final String PAGE_RESOURCE_TYPE="cq:Page";
	private static final String PAGE_CONTENT ="cq:PageContent";
	private static final String RESOURCE_TYPE_VALUE="att/common/components/synonyms";
	private static final String MAIN_PAGE_RESOURCE_TYPE_VALUE="/apps/att/common/components/page/globalsearch/synonyms";
	private static final String PAGE_RESOURCE_TYPE_VALUE="/apps/att/common/components/page/globalsearch/synonyms";
	private static final String PAGE_TEMPLATE="cq:template";
	private static final String PAGE_TEMPLATE_VALUE="/apps/att/common/templates/globalsearch/synonyms";
	private static final String ATTR_SYNONYMS="synonyms";
	private static final String JCR_TITLE ="jcr:title";
	private static final String JCR_CONTENT ="jcr:content";
	private static final String NODE_SYNONYMS ="synonyms";
	private static final String PRIMARY_TYPE_UNSTRUCTURED ="nt:unstructured";

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Reference
	private SlingRepository slingRepository;

	@Reference
	private ResourceResolverFactory resourceResolverFactory;    

	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,	IOException 
	{

		javax.jcr.Node rootNode=null;
		javax.jcr.Session session=null;
		ResourceResolver adminResolver = null;
		try 
		{
			adminResolver=resourceResolverFactory.getAdministrativeResourceResolver(null);
			//Create a Session
			session =slingRepository.loginAdministrative(null);
			rootNode =(javax.jcr.Node) session.getItem(JCR_PATH);
			//if synonyms main page node does not exist
			if(null!=rootNode && !rootNode.hasNode(NODE_SYNONYMS_AUTOMATION)) {
				//	create synonyms main page
				logger.info("Created Node relatedQueries") ;
				createNode(rootNode, session);
				//get synonyms node
				rootNode=(javax.jcr.Node) session.getItem(JCR_PATH+"/"+NODE_SYNONYMS_AUTOMATION);
				//set child node properties
				setChildNodeProperties(rootNode,session);  
				logger.info("Created child Nodes and set its properties") ;
				logger.info("Saving Session");
				session.save();
			}
			//if synonyms main page node exist
			else{
				//set root node as NODE_RELATED_QUERY_AUTOMATION
				logger.info("RelatedQueries Node exists") ;
				//get synonyms node
				rootNode=(javax.jcr.Node) session.getItem(JCR_PATH+"/"+NODE_SYNONYMS_AUTOMATION);
				//set child node properties
				setChildNodeProperties(rootNode,session);  
				logger.info("Created child Nodes and set its properties") ;
				session.save();
				logger.info("Saving Session");
			}
			PrintWriter pw=response.getWriter();
			pw.write("Migration Completed Successfully. Thanks");
			pw.flush();
		}
		
		catch (RepositoryException e) 
		{
		}
		catch (Exception e) 
		{  
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}if(session!=null){
				session.logout();
			}

		}
	}


	/*
	 * method to set properties of child nodes under NODE_SYNONYMS_AUTOMATION
	 */
	public void setChildNodeProperties(javax.jcr.Node rootNode,Session session) throws RepositoryException{

		////logger.error("Create Child nodes and set properties");
		javax.jcr.Node currentNode = null ;  
		List<Value> synonymsList = null;
		Value vs[]=new Value[0];
		javax.jcr.Node childPageNode =null;

		try 
		{
			//URL url = new URL("http://10.13.64.55/synonyms.txt");
			URL url = new URL("http://cmsdev4.admin.cingular.net/globalsearch/synonyms.txt");
			URLConnection connection = url.openConnection();
			//get file from disk
			/*File file = new File("D:\\temp\\Auto_Suggest.xml");
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();
                Document doc = db.parse(file);*/
			
			Scanner scn = new Scanner(new InputStreamReader(url.openStream()));
			while(scn.hasNext()){
				String synonym = scn.nextLine();
				String[] substitution = synonym.split(",");
				String pageName=substitution[0].replace("/","_").trim();
			//	logger.error("SYNONYM==="+synonym+"===substitution=="+pageName);
				if(!rootNode.hasNode(pageName)){
					//create child page
					currentNode = (javax.jcr.Node)rootNode.addNode(pageName,PAGE_RESOURCE_TYPE);
					//add jcr:content node
					childPageNode = currentNode.addNode(JCR_CONTENT,PAGE_CONTENT);
					//add properties
					childPageNode.setProperty(RESOURCE_TYPE, PAGE_RESOURCE_TYPE_VALUE);
					childPageNode.setProperty(PAGE_TEMPLATE,PAGE_TEMPLATE_VALUE);
					childPageNode.setProperty(JCR_TITLE,pageName);
					//set page properties
					childPageNode= childPageNode.addNode(NODE_SYNONYMS,PRIMARY_TYPE_UNSTRUCTURED);
					childPageNode.setProperty(RESOURCE_TYPE, RESOURCE_TYPE_VALUE);
					session.save();
					synonymsList = new ArrayList<Value>();
					for(int j=0;j<substitution.length;j++){
						//logger.error("childPageNode==="+childPageNode);
						ValueFactory vFactory=childPageNode.getSession().getValueFactory();
						Value newValue=vFactory.createValue(substitution[j].trim());
						synonymsList.add(newValue);	
						//logger.error("LIST==="+synonymsList.toString());
					}
					Value[] finalValues=(Value[])synonymsList.toArray(vs);
					//setting property synonyms
					childPageNode.setProperty(ATTR_SYNONYMS, finalValues);
					session.save();
				}
				else{//if synonyms has child node "substitution"
					synonymsList = new ArrayList<Value>();
						//logger.error("else has rootNode.hasNode=="+substitution);
						childPageNode=rootNode.getNode(pageName);
						//logger.error("else childPageNode==="+childPageNode);
						//get synonyms node
						childPageNode=childPageNode.getNode(JCR_CONTENT+"/"+NODE_SYNONYMS);
						//iterate through existing values in node properties
						for(Value v : childPageNode.getProperty(ATTR_SYNONYMS).getValues()) {
							if(v!=null){
							//	if(!v.getString().equalsIgnoreCase(pageName)){
									synonymsList.add(v);
								//}
							}
						}
						for(int j=0;j<substitution.length;j++){
							//logger.error("substitution==="+substitution[j]);
							//logger.error("childPageNode==="+childPageNode);
							ValueFactory vFactory=childPageNode.getSession().getValueFactory();
							Value newValue=vFactory.createValue(substitution[j].trim());
							synonymsList.add(newValue);	
							//logger.error("LIST==="+synonymsList.toString());
						}
						
						Value[] finalValues=(Value[])synonymsList.toArray(vs);
						//setting synonyms query
						childPageNode.setProperty(ATTR_SYNONYMS, finalValues);
					}
				}


		}
		catch (Exception e) 
		{
			logger.error("Exception==="+e.getMessage());
		}
	}

	/*
	 * Method to create root node Synonyms
	 */
	public static void createNode(javax.jcr.Node node, Session session){
		javax.jcr.Node rootNode=null;

		if(null!=node){
			try {
				rootNode=node;
				rootNode=rootNode.addNode(NODE_SYNONYMS_AUTOMATION,PAGE_RESOURCE_TYPE);
				rootNode=rootNode.addNode(JCR_CONTENT,PAGE_CONTENT);
				rootNode.setProperty(PAGE_TEMPLATE,PAGE_TEMPLATE_VALUE);
				rootNode.setProperty(JCR_TITLE,NODE_SYNONYMS_AUTOMATION);
				rootNode.setProperty(RESOURCE_TYPE, MAIN_PAGE_RESOURCE_TYPE_VALUE);
				session.save();
			} catch (PathNotFoundException e) {
				e.printStackTrace();
			} catch (RepositoryException e) {
				e.printStackTrace();
			}
		}
	}


	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}


}
