package com.att.ecom.cq.bundle.helpers;

import com.day.cq.wcm.api.Page;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CompareProductsHelper {
	private static final Logger log = LoggerFactory.getLogger(CompareProductsHelper.class);
	
	private static final String REFERENCE_RESOURCE_TYPE = "foundation/components/reference";
	private static final String FEATURE_REFERENCE_RESOURCE_TYPE = "att/wireless/components/specifications/featurereference";
	private static final String HEADER_RESOURCE_TYPE = "att/wireless/components/specifications/categoryheader";
	private static final String REFERENCE_PATH_PROP = "path";
	private static final String DEVICE_TABS_COMP_PATH = "devicetabs";
	private static final String LEFT_FEATURE_PARSYS = "leftfeaturepar"; 
	private static final String RIGHT_FEATURE_PARSYS = "rightfeaturepar";
	private static final String LEFT_DETAIL_PARSYS = "leftdetailpar";
	private static final String RIGHT_DETAIL_PARSYS = "rightdetailpar";
	private static final String LEFT_SPECIFICATION_PARSYS = "leftspecpar";
	private static final String RIGHT_SPECIFICATION_PARSYS = "rightspecpar";
	private static final String[] SPEC_PARS = {LEFT_FEATURE_PARSYS, RIGHT_FEATURE_PARSYS, LEFT_DETAIL_PARSYS, 
								RIGHT_DETAIL_PARSYS, LEFT_SPECIFICATION_PARSYS,RIGHT_SPECIFICATION_PARSYS};
	
	private Map productSpecs;
	private List productPages;
	
	/**
	 * Compare Products Helper bean - for the compare devices page/component 
	 * @param currentPage
	 * @param skus 
	 */
	public CompareProductsHelper(Page currentPage, String[] skus) {
		productSpecs = new HashMap();
		productPages = new ArrayList();
		for (int i=0; i<skus.length; i++) {
			Resource res = currentPage.adaptTo(Resource.class);
			log.debug("sku = " + skus[i]);
			Page product = PathHelpers.getDeviceDetailsPage(res.getResourceResolver(), currentPage, skus[i]);
			if (product != null) {
				productPages.add(product);
				List specs = getProductSpecifications(product);
				productSpecs.put(skus[i], specs);
			}
		}
	}

	/**
	 * Generates a list of productSpecifications given a productPage 
	 * @param productPage
	 * @return List of (String) paths to specification(s)
	 */
	public List getProductSpecifications(Page productPage) {
		List specs = new ArrayList();
		for (int x=0; x<SPEC_PARS.length; x++) {
			specs.addAll(getSpecifications(productPage, DEVICE_TABS_COMP_PATH + "/" + SPEC_PARS[x]));
		}
		return specs;
	}

	/**
	 * Generates a list of productSpecifications given a productPage and parsys  
	 * @param productPage
	 * @param parsysName
	 * @return List of (String) paths to specification(s)
	 */
	public List getSpecifications(Page productPage, String parsysName) {
		List specs = new ArrayList();
		
		Resource par = productPage.getContentResource(parsysName);
		
		log.debug("productPage = " + productPage.getPath());
		log.debug("parsys - " + parsysName);
		
		if (par != null) {
			for (Iterator<Resource> i = par.listChildren(); i.hasNext();) {
				Resource spec = i.next();
				if (spec.isResourceType(REFERENCE_RESOURCE_TYPE)) {
					Node specNode = spec.adaptTo(Node.class);
					try {
						if (specNode.getProperty(REFERENCE_PATH_PROP) != null) {
							String specPath = specNode.getProperty(REFERENCE_PATH_PROP).getString();
							specs.add(specPath);
						}
					} catch (PathNotFoundException pnfe) {
						log.error("PathNotFoundException: " + pnfe);
					} catch (ValueFormatException vfe) {
						log.error("ValueFormatException: " + vfe);
					} catch (RepositoryException re) {
						log.error("RepositoryException: " + re);
					}
				} else if (spec.isResourceType(FEATURE_REFERENCE_RESOURCE_TYPE)) {
					Node specNode = spec.adaptTo(Node.class);
					try {
						if (specNode.getProperty(REFERENCE_PATH_PROP) != null) {
							String specPath = specNode.getProperty(REFERENCE_PATH_PROP).getString();
							specs.add(specPath);
						}
					} catch (PathNotFoundException pnfe) {
						log.error("PathNotFoundException: " + pnfe);
					} catch (ValueFormatException vfe) {
						log.error("ValueFormatException: " + vfe);
					} catch (RepositoryException re) {
						log.error("RepositoryException: " + re);
					}
				}
			}
		}
		return specs;
	}
	
	/**
	 *  
	 * @return Map of Lists of productSpecs <(String)sku, (List)specs>
	 */
	public Map getProductSpecs() {
		return productSpecs;
	}

	/**
	 *  
	 * @return List of product pages retrieved from the String[] of skus
	 */
	public List getProductPages() {
		return productPages;
	}
	
	/**
	 * @param specs
	 * @param sku
	 * @return boolean - if any of the Array of specs is on the page representing the sku
	 */
	public boolean hasSpec(String[] specs, String sku) {
		boolean hasSpec = false;
		List prodSpecs = (List)productSpecs.get(sku);
		log.debug("prodSpecs = " + prodSpecs);
		if (prodSpecs != null) {
			for (int i=0; (i<specs.length && !hasSpec); i++) {
				log.debug("spec = " + specs[i]);
				if (prodSpecs.contains(specs[i])) {
					hasSpec = true;
				}
			}
		}
		return hasSpec;
	}

	/**
	 * @param resourceResolver
	 * @param specCategoryPage
	 * @param specPrefix
	 * @param sku
	 * @return specification value 
	 */
	public String getSpecValue(ResourceResolver resolver, String specCategoryPage, String specPrefix, String sku) {
		if (specCategoryPage == null || specPrefix == null || sku == null) {
			return null;
		}
		List prodSpecs = (List)productSpecs.get(sku);
		if (prodSpecs != null) {
			for (Iterator i = prodSpecs.iterator(); i.hasNext();) {
				String specPath = (String)i.next();
				log.debug("specPath = " + specPath);
				log.debug("specCategoryPage = " + specCategoryPage);
				if (specPath.startsWith(specCategoryPage)) {
					Resource res = resolver.resolve(specPath);
					Node n = res.adaptTo(Node.class);
					if (n != null) {
						String name = null;
						try {
							if (n.hasProperty("sling:resourceType") && n.getProperty("sling:resourceType").getString().equals(HEADER_RESOURCE_TYPE))
								continue;
							if (n.hasProperty("name") && n.getProperty("name") != null) {
								 name = n.getProperty("name").getString();
							}
							log.debug("name = " + name);
							if (name != null && name.startsWith(specPrefix) ) {
								if (n.getProperty("value") != null) {
									return n.getProperty("value").getString(); 
								}
							}
						} catch (PathNotFoundException pnfe) {
							log.error("PathNotFoundException: " + pnfe);
						} catch (ValueFormatException vfe) {
							log.error("ValueFormatException: " + vfe);
						} catch (RepositoryException re) {
							log.error("RepositoryException: " + re);
						}
					}
				}
			}
		}
		return null;
	}
}