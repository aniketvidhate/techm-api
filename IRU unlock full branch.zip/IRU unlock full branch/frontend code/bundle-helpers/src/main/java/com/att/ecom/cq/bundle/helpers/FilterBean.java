package com.att.ecom.cq.bundle.helpers;

import javax.jcr.Node;


public class FilterBean {

	
	private String displayText;
	private String optionValue;
	private String beginValue;
	private String endValue;
	private String path;
	private Integer order;
	private boolean optionSelected = false;
	
	
	public FilterBean(String text, String value, boolean isCheckedByDefault, int order) {
	      this.displayText = text;
	      this.optionValue = value;
	      this.beginValue = null;
	      this.endValue = null;
	      this.optionSelected = isCheckedByDefault;
	      this.order = new Integer(order);
	      this.path = null;
    }

	public FilterBean(String text, String beginValue, String endValue, boolean isCheckedByDefault, int order) {
	      this.displayText = text;
	      this.optionValue = null;
	      this.beginValue = beginValue;
	      this.endValue = endValue;
	      this.optionSelected = isCheckedByDefault;
	      this.order = new Integer(order);
	      this.path = null;
	}
	
    public FilterBean(Node n) {
    	try {
	      if (n.getProperty("displayText") != null) {
	  	  	this.displayText = n.getProperty("displayText").getString();
	      }
    	} catch (Exception e) {
    		this.displayText = null;
    	}
    	try {
	      if (n.getProperty("optionValue") != null) {
		  	this.optionValue = n.getProperty("optionValue").getString();
	      } 
    	} catch (Exception e2) {
    		this.optionValue = null;
    	}
    	try {
	  	  if (n.getProperty("beginValue") != null) {
			  this.beginValue = n.getProperty("beginValue").getString();
		  }
    	} catch (Exception e3) {
    		this.beginValue = null;
    	}
    	try {
  		  if (n.getProperty("endValue") != null) {
  			  this.endValue = n.getProperty("endValue").getString();
  		  }
      	} catch (Exception e3) {
      		this.endValue = null;
      	}
    	try {
		  if (n.getProperty("optionSelected") != null) {
		  	this.optionSelected = n.getProperty("optionSelected").getBoolean();
		  }
    	} catch (Exception e4) {
    	}
    	try {
    		String name = n.getName();
    		this.order = new Integer(name); 
    	} catch (Exception e5) {
    		this.order = null;
    	}
    	try {
			this.path = n.getPath();
		} catch (Exception e6) {
			this.path = null;
		}
    }

    public String getDisplayText() {
    	return this.displayText;
    }
    
    //used for getting filter value
    public String getOptionValue() {
    	return this.optionValue;
    }
    
    //used for getting ranged filter begin value
    public String getBeginValue() {
    	return this.beginValue;
    }
    
    //used for getting ranged filter end value
    public String getEndValue() {
    	return this.endValue;
    }
    
    public Integer getOrder() {
    	return this.order;
    }
    
    public boolean getOptionSelected() {
    	return this.optionSelected;
    }
    
    public String getPath() {
    	return this.path;
    }
}