package com.att.ecom.cq.bundle.helpers;
import java.io.StringWriter;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;

@Component(immediate=true)
@Service(value=GlobalsearchAutoSuggestElementBuilder.class)

public class GlobalsearchAutoSuggestElementBuilder 
{
    private static final String ATTR_USER_QUERY="userQuery";//field element attribute in xml
    private static final String ATTR_ID="id";//field element attribute in xml
    private static final String ATTR_ADMIN_BOOST="adminBoost";//field element attribute in xml
    private static final String ATTR_LOOKUP_COUNT="lookupCount";//field element attribute in xml
    private static final String ATTR_COLLECTION="collection";//field element attribute in xml
  //  private static final String NODE_MAINPAR="mainpar";//mainpar node
    
    private Logger logger = LoggerFactory.getLogger(GlobalsearchAutoSuggestElementBuilder.class);
 
    @Reference
    private SlingRepository slingRepository;

    @Reference
    private ResourceResolverFactory resourceResolverFactory;	

    private Session administrativeSession;

    DocumentBuilderFactory docFactory; 
    DocumentBuilder docBuilder;
    // root elements
    Document doc;
    Element rootElement;
    private int pageid=0;

    protected void activate(ComponentContext ctx) throws RepositoryException 
    {
        administrativeSession = slingRepository.loginAdministrative(null);
    }

    protected void deactivate(ComponentContext ctx) {
        administrativeSession.logout();
    }
    /*
     * Get the CQ template Paths
     */	
    public synchronized String buildElements(String currentPagePath) throws RepositoryException 
    {
        String output="";
        pageid=0;
        logger.error("CURRENT PAGE PATH==="+currentPagePath);
        String child_Pages="SELECT * FROM nt:base WHERE jcr:path like '"+currentPagePath +"/%' and jcr:primaryType='cq:Page' ";
        if (administrativeSession.isLive()) 
        {	
            // get QueryManager
            QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();    		
            // make SQL query
            Query query = queryManager.createQuery(child_Pages, Query.SQL);
            // execute query
            QueryResult result = query.execute();
            // execute query and fetch result
            NodeIterator nodes = result.getNodes();
            ResourceResolver adminResolver = null;
            int indent=2;
            try 
            {
                adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);				
                docFactory = DocumentBuilderFactory.newInstance();
                docBuilder = docFactory.newDocumentBuilder();
                doc = docBuilder.newDocument();				
                rootElement = doc.createElement("add");
                doc.appendChild(rootElement);
                doc =parseCurrentPage(currentPagePath,doc);
                while (nodes.hasNext()) 
                {
                    Node node = nodes.nextNode();
                    doc =parseCurrentPage(node.getPath().toString(),doc);
                    logger.error("DOC====="+doc.toString());
                }
                // write the content into xml file
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                transformerFactory.setAttribute("indent-number", indent);
                Transformer transformer = transformerFactory.newTransformer();
                transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                DOMSource source = new DOMSource(doc);				
                StreamResult streamResult = new StreamResult(new StringWriter());
                transformer.transform(source, streamResult);
                output=streamResult.getWriter().toString();
            }catch (LoginException e) {
                logger.error("Unable to login for CMS Repository Report", e);
            }
            catch(ParserConfigurationException pce){
                logger.error("ParserConfigurationException", pce);
            }
            catch(TransformerException  tfe){
                logger.error("TransformerException", tfe);
            }
            finally {
                if (adminResolver != null) {
                    adminResolver.close();
                }
            }
        }		
        return output;	
    }

    /**
     * Parsing giving Global Search promoion page 
     * return elements
     */
    public synchronized Document parseCurrentPage(String currentPagePath, Document pageDoc) throws RepositoryException {
        ResourceResolver adminResolver = null;

        try{
            adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
            PageManager pageManager = adminResolver.adaptTo(PageManager.class);
            Page rootPage = pageManager.getPage(currentPagePath);
            if( null != rootPage){
                Resource rootpageRes = rootPage.getContentResource();
                Resource rootpagemainpar = adminResolver.getResource(rootpageRes ,"autosuggest");
                if(null != rootpagemainpar){
                		Node tempNode = rootpagemainpar.adaptTo(Node.class);
                        if (tempNode.hasProperty(ATTR_ADMIN_BOOST) && tempNode.hasProperty(ATTR_LOOKUP_COUNT) && 
                                !tempNode.getProperty(ATTR_ADMIN_BOOST).getString().equalsIgnoreCase(tempNode.getProperty(ATTR_LOOKUP_COUNT).getString())
                                && !tempNode.getProperty(ATTR_ADMIN_BOOST).getString().equalsIgnoreCase("")) {
	                        //get Node path
	                        Element docElement = pageDoc.createElement("doc");
	                        rootElement.appendChild(docElement);
	                        
	                        
	
	                        //Check userQuery
	                        if (tempNode.hasProperty(ATTR_USER_QUERY)) {
	                            pageDoc=buildChildElements(ATTR_USER_QUERY,tempNode.getProperty(ATTR_USER_QUERY).getString(),pageDoc,docElement);                 
	                        }
	                        //end of userQuery
	                      //Check lookupcount
	                        //commenting the below if condition as we are overright lookup cound value with adminboost value.
	                        /** in the out xml field name value is lookup count but the date is adminboost value.
	                        if (tempNode.hasProperty(ATTR_LOOKUP_COUNT)) {	                        	
	                            pageDoc=buildChildElements(ATTR_LOOKUP_COUNT,tempNode.getProperty(ATTR_LOOKUP_COUNT).getString(),pageDoc,docElement);                	
	                        }
	                        **/
	                        //end of lookupcount
	                      //Check id
	                        if (tempNode.hasProperty(ATTR_COLLECTION)) {
	                            pageDoc=buildChildElements(ATTR_COLLECTION,tempNode.getProperty(ATTR_COLLECTION).getString(),pageDoc,docElement);                	
	                        }
	                        //end of if
	                        
	                        //Check adminBoost	                        
	                        //Admin boost value is default to 0 while sending to solr. Even though it is different from CQ Repository.
	                        if(tempNode.hasProperty(ATTR_ADMIN_BOOST)){
	                        	 //commenting for seeting adminboost value 0 
	                            //pageDoc=buildChildElements(ATTR_ADMIN_BOOST,tempNode.getProperty(ATTR_ADMIN_BOOST).getString(),pageDoc,docElement);
	                        	//swapped lookup count value with admin boost value
	                        	pageDoc=buildChildElements(ATTR_LOOKUP_COUNT,tempNode.getProperty(ATTR_ADMIN_BOOST).getString(),pageDoc,docElement);
	                        	pageDoc=buildChildElements(ATTR_ADMIN_BOOST,"0",pageDoc,docElement);
	                        	
	                        } //end of adminBoost
                        }
                }// end of rootpagemainpar null
                        
            } //end of if

        }//end of try
        catch(Exception e){
            logger.error("Unable to parse", e);
        }
        finally {
            if (adminResolver != null) {
                adminResolver.close();
            }
        }
        return pageDoc;
    }	

    /**
     *  build child elements
     */
    public synchronized Document buildChildElements(String fieldName, String cqPropertyName,  Document childPageDoc, Element docElement) throws RepositoryException {
        Attr attr;
        Element childElement;
        try{
            childElement=childPageDoc.createElement("field");            
            if(fieldName.equals("userQuery")){
            	childElement.appendChild(childPageDoc.createCDATASection(cqPropertyName));
            }
            else{
            	childElement.appendChild(childPageDoc.createTextNode(cqPropertyName));	
            }
            docElement.appendChild(childElement);
            // set attribute to staff element
            attr = childPageDoc.createAttribute("name");
            attr.setValue(fieldName);
            childElement.setAttributeNode(attr);
        }
        catch(Exception e){
            logger.error("Unable to build Child Elements", e);
        }		
        return childPageDoc;
    }
}
