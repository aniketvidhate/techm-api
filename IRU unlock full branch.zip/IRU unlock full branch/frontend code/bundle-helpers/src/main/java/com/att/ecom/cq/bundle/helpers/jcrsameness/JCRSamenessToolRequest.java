/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.util.Hashtable;
import java.util.List;

/**
 * It holds the input parameters required to compare JCR's.
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884)
 * @Since Jan 12, 2013 11:52:39 PM
 */
public class JCRSamenessToolRequest {

    /**
     * Starting JCR content path from where we start compare any 2 JCR's.
     */
    private String mPath = null;

    /**
     * Source, it is considered as correct / golden JCR.
     */
    private String mSourceHost = null;

    /**
     * List of target JCR's, each of these will be compared against source JCR.
     */
    private List<String> mTargetHosts = null;

    private String mExcludedProperties = null;
    
    private String mExcludedNodes = null;
    
    private String mEmailAddresses = null;
    
    private boolean mIncludeDeactivatedNodes = false;
    
    private Hashtable< String, String> targetRAMap;
    
    private int noOfProcessors = 0;
    
    private boolean checkOrder = false;
    
	private String outputFolder = "";    

	
    public String getOutputFolder() {
		return outputFolder;
	}

	public void setOutputFolder(String outputFolder) {
		this.outputFolder = outputFolder;
	}

    public int getNoOfProcessors() {
		return noOfProcessors;
	}

	public void setNoOfProcessors(int noOfProcessors) {
		this.noOfProcessors = noOfProcessors;
	}

	/**
     * @return the path
     */
    public String getPath() {
        return mPath;
    }

    /**
     * @param pPath
     *            the path to set
     */
    public void setPath(String pPath) {
        mPath = pPath;
    }

    /**
     * @return the sourceHost
     */
    public String getSourceHost() {
        return mSourceHost;
    }

    /**
     * @param pSourceHost
     *            the sourceHost to set
     */
    public void setSourceHost(String pSourceHost) {
        mSourceHost = pSourceHost;
    }

    /**
     * @return the targetHosts
     */
    public List<String> getTargetHosts() {
        return mTargetHosts;
    }

    /**
     * @param pTargetHosts
     *            the targetHosts to set
     */
    public void setTargetHosts(List<String> pTargetHosts) {
        mTargetHosts = pTargetHosts;
    }

    /**
     * @return the excludedProperties
     */
    public String getExcludedProperties() {
        return mExcludedProperties;
    }

    /**
     * @param pExcludedProperties the excludedProperties to set
     */
    public void setExcludedProperties(String pExcludedProperties) {
        mExcludedProperties = pExcludedProperties;
    }
    
    public String toString() {
        StringBuilder toStringBuilder = new StringBuilder();
        toStringBuilder.append("Path = ");
        toStringBuilder.append(getPath());
        toStringBuilder.append("\n Source Host = ");
        toStringBuilder.append(getSourceHost());
        toStringBuilder.append("\n Target Hosts = ");
        toStringBuilder.append(toString(getTargetHosts()));
        toStringBuilder.append("\n Excluded Properties (Additional Node propertiess to be excluded while comparing repositories) = ");
        toStringBuilder.append(getExcludedProperties());
        toStringBuilder.append("\n Excluded Nodes (Additional Nodes to be excluded while comparing repositories) = ");
        toStringBuilder.append(getExcludedNodes());   
        toStringBuilder.append("\n Include Deactivated Nodes = ");
        toStringBuilder.append(isIncludeDeactivatedNodes());        
        return toStringBuilder.toString();
    }

    public String toString(List<?> pList) {
        if (pList == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder("(");
        String sep = "";
        for (Object object : pList) {
            if (object != null) {
                sb.append(sep).append(object.toString());
                sep = "|";
            }
        }
        return sb.append(')').toString();
    }

    /**
     * @return the excludedNodes
     */
    public String getExcludedNodes() {
        return mExcludedNodes;
    }

    /**
     * @param pExcludedNodes the excludedNodes to set
     */
    public void setExcludedNodes(String pExcludedNodes) {
        mExcludedNodes = pExcludedNodes;
    }

    /**
     * @return the includeDeactivatedNodes
     */
    public boolean isIncludeDeactivatedNodes() {
        return mIncludeDeactivatedNodes;
    }

    /**
     * @param pIncludeDeactivatedNodes the includeDeactivatedNodes to set
     */
    public void setIncludeDeactivatedNodes(boolean pIncludeDeactivatedNodes) {
        mIncludeDeactivatedNodes = pIncludeDeactivatedNodes;
    }

    /**
     * @return the emailAddresses
     */
    public String getEmailAddresses() {
        return mEmailAddresses;
    }

    /**
     * @param pEmailAddresses the emailAddresses to set
     */
    public void setEmailAddresses(String pEmailAddresses) {
        mEmailAddresses = pEmailAddresses;
    }

	public Hashtable<String, String> getTargetRAMap() {
		return targetRAMap;
	}

	public void setTargetRAMap(Hashtable<String, String> targetRAMap) {
		this.targetRAMap = targetRAMap;
	}

	public boolean isCheckOrder() {
		return checkOrder;
	}

	public void setCheckOrder(boolean checkOrder) {
		this.checkOrder = checkOrder;
	}
}
