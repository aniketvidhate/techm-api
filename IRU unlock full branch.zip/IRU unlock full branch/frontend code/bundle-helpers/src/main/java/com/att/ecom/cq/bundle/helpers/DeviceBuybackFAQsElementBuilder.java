
/*
 * DeviceBuyBack FAQs Element Builder.
 * @author Teena Arora(ta241d)
 * @created on October 24 2013
 */

package com.att.ecom.cq.bundle.helpers;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import com.day.cq.wcm.api.PageManager;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.json.JSONArray;

import com.day.cq.wcm.api.Page;


/**
* For any page having FAQs component it returns the JSON response. JSON response contains the information of "Question" and "Answer".
* For the FAQ parent page it returns the JSON having all FAQ Question and Answer present on its child pages.
*/

@Component(immediate=true)
@Service(value=DeviceBuybackFAQsElementBuilder.class)

public class DeviceBuybackFAQsElementBuilder {
	private Logger logger = LoggerFactory.getLogger(DeviceBuybackFAQsElementBuilder.class);

	@Reference
	private SlingRepository slingRepository;
	
	@Reference
	private ResourceResolverFactory resourceResolverFactory;	

	private Session administrativeSession;
	
	private static final String FAQ_JSON = "FAQs";
	private static final String Device_Buy_Back_JSON = "deviceBuyBack";
	private static final String Question_key = "Question";
	private static final String Answer_key = "Answer";
	
	
	protected void activate(ComponentContext ctx) throws RepositoryException 
	{
		administrativeSession = slingRepository.loginAdministrative(null);
	}
	
	protected void deactivate(ComponentContext ctx) {
		administrativeSession.logout();
	}
	/**
     * Get the CQ template Paths.
     * It iterates through all the result nodes and creates a complete FAQ JSON.
     */	
	public synchronized String buildElements(String currentPagePath) throws RepositoryException 
	{   
		String output="";
		
		//String child_Pages="SELECT * FROM nt:base WHERE jcr:path like '"+currentPagePath +"/%' and jcr:primaryType='cq:Page' ";
		//String child_Pages="/jcr:root/content/att/pages/data/devicebuyback/faqs/* ";
		String child_Pages="/jcr:root"+currentPagePath+"/*";
		if (administrativeSession.isLive()) 
		{	
			// get QueryManager
    		QueryManager queryManager = administrativeSession.getWorkspace().getQueryManager();    		
    		// make SQL query
			Query query = queryManager.createQuery(child_Pages, Query.XPATH);			
    		// execute query
    		QueryResult result = query.execute();
    		// execute query and fetch result
    		NodeIterator nodes = result.getNodes();
    		ResourceResolver adminResolver = null;
    		
    		JSONArray faqDetailsArray = new JSONArray();
    		    		
    		try 
			{  
    			JSONObject faqJsonObject = null;
    			JSONObject devicebuyBackObject = new JSONObject();
    			
    			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);    			   			
    			
    			// constructing current page FAQs JSON
    			faqDetailsArray = constructCurrentFaqPageJson(currentPagePath,faqDetailsArray);
    			    			
    			while (nodes.hasNext()) 
				{
					Node node = nodes.nextNode();					
					// constructing FAQs JSON for child pages
					faqDetailsArray =constructCurrentFaqPageJson(node.getPath().toString(),faqDetailsArray);
			    }
    			if (faqDetailsArray.length() > 0) {
    				faqJsonObject = new JSONObject();
    				faqJsonObject.put(FAQ_JSON, faqDetailsArray);
    			}
    			if (faqJsonObject != null) {
    				devicebuyBackObject.put(Device_Buy_Back_JSON,faqJsonObject);   						
    			}
    			output=devicebuyBackObject.toString();
    			logger.debug("GET FAQ detail Json : FAQ Json: "+output);

			}//end of try block
    		catch(JSONException e1)
    		{
    			logger.error("GET FAQ detail Json :Unable to create JSON object", e1);
    		}
    		catch (LoginException e) {
				logger.error("GET FAQ detail Json :Unable to login for CMS Repository Report", e);
			}
    		catch (Exception pException) {
    			logger.error("GET FAQ detail Json :: Exception occured while reading the device details and constructing JSON :" + pException);
            } 
    		finally {
				if (adminResolver != null) {
					adminResolver.close();
				       }
		       }
		}
		return output;
	
  }
	/**
	 * It iterates through FAQs nodes and constructs the JSON array for a page with all details. 
	 */
	private JSONArray constructCurrentFaqPageJson(String currentPagePath,JSONArray pfaqDetailsJsonArray) throws RepositoryException {
		ResourceResolver adminResolver = null;
		
		try{
			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			PageManager pageManager = adminResolver.adaptTo(PageManager.class);
			Page rootPage = pageManager.getPage(currentPagePath);
			
			JSONObject faqJson = new JSONObject();
						
			if( null != rootPage){
				Resource rootpageRes = rootPage.getContentResource();
				Resource rootpagemainpar = adminResolver.getResource(rootpageRes , "mainpar");
				if(null != rootpagemainpar){
					Node rootpagemainNode = rootpagemainpar.adaptTo(Node.class);
					for ( NodeIterator ni = rootpagemainNode .getNodes(); ni.hasNext();) {
						Node tempNode =  ni.nextNode();
						faqJson = new JSONObject();
						if (tempNode .hasProperty("question")) {		                				
							faqJson.put(Question_key, tempNode.getProperty("question").getString());
        				}
						if (tempNode .hasProperty("answer")) {		                				
							faqJson.put(Answer_key, tempNode.getProperty("answer").getString());
        				}	
						pfaqDetailsJsonArray.put(faqJson);
					} // end of for NodeIterator ni
					
				} // end of rootpagemainpar	
			} // end of rootPage			
		}// end of try block
		catch(JSONException e1)
		{
			logger.error("constructCurrentFaqPageJson : Unable to create JSON object", e1);
		}
		catch (LoginException e) {
			logger.error("constructCurrentFaqPageJson : Unable to login for CMS Repository Report", e);
		}
		finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
		}
	return pfaqDetailsJsonArray;
	}
}
