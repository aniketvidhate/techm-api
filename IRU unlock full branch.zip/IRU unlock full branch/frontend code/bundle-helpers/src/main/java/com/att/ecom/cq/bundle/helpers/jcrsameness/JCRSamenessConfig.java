/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2011 AT&T Knowledge Ventures All Rights Reserved. 
 * No use, copying or distribution of this work may be made except in accordance with a valid license agreement from 
 * AT&T Knowledge Ventures. This notice must be included on all copies, modifications and derivatives of this work.
 * 
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.helpers.jcrsameness;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, metatype = true, label = "JCR Sameness Configuration")
@Service(value = com.att.ecom.cq.bundle.helpers.jcrsameness.JCRSamenessConfig.class)
@Properties({ @Property(name = Constants.SERVICE_DESCRIPTION, value = "MD5 hash generator servlet configuration"),
        @Property(name = Constants.SERVICE_VENDOR, value = "CMS@ATT"),
        @Property(name = "process.label", value = "JCR Sameness Configuration") })
/**
 * It contains the JCR Sameness global configuration.
 * 
 * @author Sunil Reddy Aleti (attuid: sa5884)
 * @Since Dec 28, 2012 11:13:39 AM
 */
public class JCRSamenessConfig {

    @SuppressWarnings("rawtypes")
    private static Dictionary props = null;
    
    private static final Logger log = LoggerFactory.getLogger(JCRSamenessConfig.class);

    @Property(label = "From Address", value = "repositorycompare@list.att.com")
    private static final String FROM_ADDRESS = "from.email";
    
    @Property(label = "From Name", value = "Repository Sameness Tool")
    private static final String FROM_NAME = "from.name";
    
    @Property(label = "JCR Sameness group e-mail address", value = "DL-repositorycompare@att.com")
    private static final String GROUP_EMAIL = "group.email";

    // Email host for development environment is bdcmx.edc.cingular.net
    @Property(label = "Email handler host name", value = "localhost")
    private static final String EMAIL_HOST = "email.host";

    public List<String> mExcludedProperties = new ArrayList<String>();
    /**
     * It activates the component.
     * @param ctx ComponentContext object.
     */
    protected void activate(ComponentContext ctx) {
        log.info(" started MD5HashServletConfig ");
        props = ctx.getProperties();
    }
    
    public String getFromAddress() {
        return (String) props.get(FROM_ADDRESS);
    }
    
    public String getGroupEmailAddress() {
        return (String) props.get(GROUP_EMAIL);
    }
    
    public String getFromName() {
        return (String) props.get(FROM_NAME);
    }
    
    public String getEmailHost() {
        return (String) props.get(EMAIL_HOST);
    }
}
