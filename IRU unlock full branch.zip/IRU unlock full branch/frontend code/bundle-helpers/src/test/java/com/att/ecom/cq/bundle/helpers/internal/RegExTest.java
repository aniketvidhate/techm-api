/* <AT&T Copyright>
 * Copyright (C) 2005 AT&T
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from AT&T.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AT&T MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AT&T 
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF 
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Copyright>
 */
package com.att.ecom.cq.bundle.helpers.internal;

import static org.junit.Assert.*;

import java.util.regex.Pattern;

import org.junit.Test;

public class RegExTest {
	
	@Test
	public void test() {
		String pattern = "^(/media/(?!cms/shop/)|/styles/).*$";
		Pattern regex = Pattern.compile(pattern);
		if (regex != null) {
			assertTrue(regex.matcher("/media/foo.png").matches());
			assertTrue(regex.matcher("/media/cms/foo.png").matches());
			assertFalse(regex.matcher("/media/cms/shop/foo.png").matches());
			assertFalse(regex.matcher("/media/cms/shop/styles/foo.png").matches());
			assertFalse(regex.matcher("/media/cms/shop/scripts/foo.png").matches());
			assertFalse(regex.matcher("/content/dam/foo.png").matches());
			assertTrue(regex.matcher("/styles/foo.png").matches());
			assertTrue(regex.matcher("/styles/fold/foo.png").matches());
		}
	}

}
