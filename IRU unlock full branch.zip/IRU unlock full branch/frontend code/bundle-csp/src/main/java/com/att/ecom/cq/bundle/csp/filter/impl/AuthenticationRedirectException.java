/**
 * 
 */
package com.att.ecom.cq.bundle.csp.filter.impl;

/**
 * @author bt0008
 *
 */
public class AuthenticationRedirectException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8934662383883634578L;

	/**
	 * 
	 */
	public AuthenticationRedirectException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public AuthenticationRedirectException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public AuthenticationRedirectException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public AuthenticationRedirectException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
