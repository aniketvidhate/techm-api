/**
 * 
 */
package com.att.ecom.cq.bundle.csp.filter.impl;

import java.io.IOException;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferenceCardinality;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A servlet filter to make the CSP service's authenticated cookie data
 * available to the servlet's authentication and authorization methods
 * 
 * @author bt0008
 */
@Component(immediate = true, metatype = true)
@Service
@Property(name = "pattern", value = "^(?!/system/console/)(?!/maven/).*$", propertyPrivate = true)
public class CSPCookieFilter implements Filter {
	/**
	 * Default implementation of {@link AuthenticationFilterAdaptor}, this class
	 * creates a {@link CSPCookieRequestWrapper} from the original
	 * {@link HttpServletRequest} and a new {@link CSPPrincipal} from the
	 * {@link Map} of parsed CSP cookie values
	 * 
	 * @author bt0008
	 */
	public static class CSPDefaultAdaptor implements
			AuthenticationFilterAdaptor {

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * com.att.security.web.servlet.filters.AuthenticationFilterAdaptor#
		 * getRedirectURL(javax.servlet.http.HttpServletRequest,
		 * javax.servlet.http.HttpServletResponse, java.lang.String)
		 */
		public String getRedirectURL(HttpServletRequest req,
				HttpServletResponse rsp, String dfltURL) {
			return dfltURL;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * com.att.security.web.servlet.filters.AuthenticationFilterAdaptor#
		 * getWrapper(javax.servlet.http.HttpServletRequest, java.util.Map)
		 */
		public HttpServletRequestWrapper getWrapper(HttpServletRequest req,
				HttpServletResponse rsp, Map<String, Object> m) {
			CSPCookieRequestWrapper wrapper = new CSPCookieRequestWrapper(req);
			wrapper.setUserPrincipal(new CSPPrincipal((String) m
					.get(CSPCookieFilter.CSP_ATT_UID), m));
			HttpSession existingSession = req.getSession(false);
			HttpSession session = req.getSession();
			if (log.isDebugEnabled())
				log.debug("Created new CSPCookieRequestWrapper with "
						+ ((existingSession != null) ? "existing" : "new")
						+ " session " + session.getId()
						+ " and Principal.name=" + m.get(CSP_ATT_UID));
			return wrapper;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * com.att.security.web.servlet.filters.AuthenticationFilterAdaptor#
		 * isAuthenticationRequired(javax.servlet.http.HttpServletRequest,
		 * boolean)
		 */
		public boolean isAuthenticationRequired(HttpServletRequest req,
				boolean defaultValue) {
			return defaultValue;
		}

	}

	/**
	 * base of CSPCookieFilter's property namespace. CSP may want to change this
	 * if they take over the code, which I sincerely hope they will
	 */
	static final String CSP_PROPERTIES_BASE = "com.att.security.CSP.";

	/**
	 * base of property names for attESSec cookie fields
	 */
	static final String CSP_SEC_COOKIE_BASE = CSP_PROPERTIES_BASE + "attESSec.";

	/**
	 * base of attESHr cookie field property namespace
	 */
	static final String CSP_HR_COOKIE_BASE = CSP_PROPERTIES_BASE + "attESHr.";

	/**
	 * a string of boolean values, signified by 'Y' or 'N', with various
	 * meanings
	 */
	static final String CSP_HR_PATTERN_A = CSP_HR_COOKIE_BASE + "patternA";

	static final String PATTERN_A_FIELDBASE = CSP_HR_PATTERN_A + ".";

	/**
	 * AT&amp;T User ID - the official cybername of every internal user
	 */
	public static final String CSP_ATT_UID = CSP_SEC_COOKIE_BASE + "attUid";

	/**
	 * the attribute key to the {@link Map} of cookie values from
	 * {@link HttpSession#getAttribute(java.lang.String)}
	 */
	public static final String CSP_AUTHENTICATED_INFO = CSP_PROPERTIES_BASE
			+ "authinfo";

	/**
	 * Authentication environment (currently "DEVL" or "PROD") - must match the
	 * corresponding argument to
	 * {@link esGateKeeper#esGateKeeper(java.lang.String, java.lang.String, java.lang.String)}
	 * or validation fails
	 */
	public static final String CSP_AUTHENV = CSP_SEC_COOKIE_BASE + "authEnv";

	/**
	 * CSP-assigned strength-of-authentication metric, so higher-sensitivity
	 * data and methods can require stronger authentication
	 */
	public static final String CSP_AUTHSTR = CSP_SEC_COOKIE_BASE
			+ "authStrength";

	/**
	 * A code signifying the user's HR status, this field contains "E" if the
	 * authenticated user is an employee, something else (for contractor,
	 * vendor, customer, retiree, perhaps...?) otherwise
	 */
	public static final String CSP_EMPTYPE = CSP_SEC_COOKIE_BASE
			+ "employeeType";

	/**
	 * Looks silly, but it's not; the Common Language Location Information code
	 * for the user's company address, if any
	 */
	public static final String CSP_HR_CLLI = CSP_HR_COOKIE_BASE + "clli";

	/**
	 * Signature over the attESHr cookie's unencoded value - no need to expose
	 * this, I think...
	 */
	public static final String CSP_HR_COOKIE_SIG = CSP_SEC_COOKIE_BASE
			+ "hrCookieSignature";
	/**
	 * user's email address
	 */
	public static final String CSP_HR_EMAIL = CSP_HR_COOKIE_BASE
			+ "emailAddress";
	/**
	 * user's first name
	 */
	public static final String CSP_HR_FIRST_NAME = CSP_HR_COOKIE_BASE
			+ "firstName";
	public static final String CSP_HR_FLAG_222 = PATTERN_A_FIELDBASE + "is222";
	public static final String CSP_HR_FLAG_272 = PATTERN_A_FIELDBASE + "is272";
	public static final String CSP_HR_FLAG_ASIAPACIFIC = PATTERN_A_FIELDBASE
			+ "isAsiaPacific";
	public static final String CSP_HR_FLAG_ASSOCIATE = PATTERN_A_FIELDBASE
			+ "isAssociate";

	public static final String CSP_HR_FLAG_ATTCORE = PATTERN_A_FIELDBASE
			+ "isATTCore";

	public static final String CSP_HR_FLAG_BBIS = PATTERN_A_FIELDBASE
			+ "isBBIS";
	public static final String CSP_HR_FLAG_CARIBLATINAMERICA = PATTERN_A_FIELDBASE
			+ "isCaribbeanLatinAmerica";
	public static final String CSP_HR_FLAG_EMEA = PATTERN_A_FIELDBASE
			+ "isEMEA";
	public static final String CSP_HR_FLAG_EXECUTIVE = PATTERN_A_FIELDBASE
			+ "isExecutive";
	public static final String CSP_HR_FLAG_EXPATRIATE = PATTERN_A_FIELDBASE
			+ "isExpatriate";
	public static final String CSP_HR_FLAG_GRCI = PATTERN_A_FIELDBASE
			+ "isGRCI";
	public static final String CSP_HR_FLAG_GSI_ONCALL = PATTERN_A_FIELDBASE
			+ "isGSIonCall";
	public static final String CSP_HR_FLAG_INPATRIATE = PATTERN_A_FIELDBASE
			+ "isInpatriate";
	public static final String CSP_HR_FLAG_INTERNATIONAL = PATTERN_A_FIELDBASE
			+ "isInternational";
	public static final String CSP_HR_FLAG_INTERNATIONALASSIGNEE = PATTERN_A_FIELDBASE
			+ "isInternationalAssignee";
	public static final String CSP_HR_FLAG_INTERNATIONALREGIONALASSIGNEE = PATTERN_A_FIELDBASE
			+ "isInternationalRegionalAssignee";
	public static final String CSP_HR_FLAG_MANAGEMENT = PATTERN_A_FIELDBASE
			+ "isManagement";

	public static final String CSP_HR_FLAG_NPW = PATTERN_A_FIELDBASE + "isNPW";
	public static final String CSP_HR_FLAG_OCCUPATIONAL = PATTERN_A_FIELDBASE
			+ "isOccupational";
	public static final String CSP_HR_FLAG_RETIREE = PATTERN_A_FIELDBASE
			+ "isRetiree";
	public static final String CSP_HR_FLAG_SBC = PATTERN_A_FIELDBASE + "isSBC";
	public static final String CSP_HR_FLAG_TERRITORY = PATTERN_A_FIELDBASE
			+ "isUSTerritory";
	public static final String CSP_HR_FLAG_TYCO = PATTERN_A_FIELDBASE
			+ "isTYCO";
	public static final String CSP_HR_FLAG_WIRELESS = PATTERN_A_FIELDBASE
			+ "isWireless";
	/**
	 * the formal Organization Code of the user's home organization
	 */
	public static final String CSP_HR_FML_ORG_CODE = CSP_HR_COOKIE_BASE
			+ "fmlOrgCode";
	/**
	 * user's last name
	 */
	public static final String CSP_HR_LAST_NAME = CSP_HR_COOKIE_BASE
			+ "lastName";
	/**
	 * AT&amp;T UID for user's supervisor (or other responsible party, in the
	 * case of non-employees...?)
	 */
	public static final String CSP_HR_MGR_ATTUID = CSP_HR_COOKIE_BASE
			+ "managerATTUid";
	/**
	 * HR ID of user's manager. Like the user's HRID, this identifier is
	 * obsolescent, so use of it is discouraged.
	 */
	public static final String CSP_HR_MGR_HRID = CSP_HR_COOKIE_BASE
			+ "managerHrId";
	/**
	 * user's middle name (or initial?)
	 */
	public static final String CSP_HR_MIDDLE_NAME = CSP_HR_COOKIE_BASE
			+ "middleName";
	/**
	 * qualifying suffix ("Jr.", "Sr.", "IV", etc.) to user's name
	 */
	public static final String CSP_HR_NAME_SUFFIX = CSP_HR_COOKIE_BASE
			+ "nameSuffix";

	/**
	 * user's salary grade - meaningful (and present) only when
	 * {@link CSPCookieFilter#CSP_EMPTYPE} field is "E"
	 */
	public static final String CSP_HR_SALARYGRADE = CSP_HR_COOKIE_BASE
			+ "salarygrade";
	/**
	 * work phone number
	 */
	public static final String CSP_HR_WORKPHONE = CSP_HR_COOKIE_BASE
			+ "workPhone";
	/**
	 * HR ID - CSP says the use of this identifier is obsolescent, so it might
	 * be a good idea not to make use of this field
	 */
	public static final String CSP_HRID = CSP_SEC_COOKIE_BASE + "hrId";
	/**
	 * Comma-separated list of CSP-assigned attributes, the
	 * {@link HttpServletRequest#isUserInRole(java.lang.String)} question is
	 * answered according to the presence of the argument in this list
	 */
	public static final String CSP_PRIVS = CSP_SEC_COOKIE_BASE + "privileges";
	/**
	 * time of attESSec cookie creation
	 */
	public static final String CSP_TIMESTAMP = CSP_SEC_COOKIE_BASE
			+ "timeStamp";

	public static final boolean DEFAULT_ALWAYS_VALIDATE = false;

	public static final boolean DEFAULT_MUST_AUTHENTICATE = true;

	private static final String[] DEFAULT_REPLACEMENT_POSTFIXES = new String[] {
			"sbc.com", "sbctest.com", "bls.com", "cingular.net" };
	
	private static final String DEFAULT_POSTFIX_TO_REPLACE = "csp.att.com";

	private static final Logger log = LoggerFactory
			.getLogger(CSPCookieFilter.class);

	static final String[] patternAFieldList = new String[] {
			CSP_HR_FLAG_INTERNATIONAL, CSP_HR_FLAG_INTERNATIONALASSIGNEE,
			CSP_HR_FLAG_INTERNATIONALREGIONALASSIGNEE, CSP_HR_FLAG_EXECUTIVE,
			CSP_HR_FLAG_MANAGEMENT, CSP_HR_FLAG_OCCUPATIONAL,
			CSP_HR_FLAG_ASSOCIATE, CSP_HR_FLAG_EXPATRIATE,
			CSP_HR_FLAG_INPATRIATE, CSP_HR_FLAG_ATTCORE, CSP_HR_FLAG_WIRELESS,
			CSP_HR_FLAG_BBIS, CSP_HR_FLAG_GRCI, CSP_HR_FLAG_TYCO,
			CSP_HR_FLAG_NPW, CSP_HR_FLAG_RETIREE, CSP_HR_FLAG_ASIAPACIFIC,
			CSP_HR_FLAG_SBC, CSP_HR_FLAG_CARIBLATINAMERICA, CSP_HR_FLAG_EMEA,
			CSP_HR_FLAG_TERRITORY, CSP_HR_FLAG_GSI_ONCALL, CSP_HR_FLAG_222,
			CSP_HR_FLAG_272 };

	@Property(boolValue = DEFAULT_ALWAYS_VALIDATE, label="Always Validate?", description = "Validate every request (true), or only once per session (false).")
	public static final String PROP_ALWAYS_VALIDATE = "alwaysValidate";

	@Property(boolValue = DEFAULT_MUST_AUTHENTICATE, label="Must Authenticate?", description = "If true, redirection to authentication site will happen.")
	public static final String PROP_MUST_AUTHENTICATE = "mustAuthenticate";

	/**
	 * Unfortunate that this needs to be repeated, but that's a quirk of the annotations spec
	 */
	@Property(value = { "sbc.com", "sbctest.com", "bls.com", "cingular.net" }, label="Replacement Domain Postfixes", description="The list of domain postfixes which will be replaced in the redirect domain name.")
	public static final String PROP_REPLACEMENT_EXTENSIONS = "replacementExtensions";
	
	@Property(value=DEFAULT_POSTFIX_TO_REPLACE, label="Domain Postfix to Replace", description="The postfix of the default redirect domain which should be replaced")
	public static final String PROP_POSTFIX_TO_REPLACE = "postfixToReplace";

	private static final String URL_PATTERN = "(http[s]?:\\/\\/)([\\.\\w\\-_]+)([\\w\\-\\.,@?^=%&amp;:/~\\+#]*[\\w\\-\\@?^=%&amp;/~\\+#])?";

	/**
	 * if <code>true</code>, every request will validate the CSP cookies;
	 * otherwise only their first valid appearance per session. Usually turned
	 * off because of the overhead of decrypting and verifying.
	 */
	private boolean alwaysValidate;

	/**
	 * Internal servlet authentication adaptor, initialized to default value
	 */
	@Reference(cardinality = ReferenceCardinality.OPTIONAL_UNARY)
	private AuthenticationFilterAdaptor authFilterAdaptor;

	/**
	 * Internal servlet authentication adaptor
	 */
	@Reference
	private CookieMapper mapper;

	/**
	 * Internal User creation service
	 */
	@Reference
	private UserService userService;

	/**
	 * If <code>true</code>, redirection to authentication site will happen.
	 * Initially set by properties but can be overridden by
	 * {@link AuthenticationFilterAdaptor #isAuthenticationRequired(HttpServletRequest, boolean)}
	 * which takes it as its default.
	 */
	private boolean mustAuthenticate;

	private String[] replacementPostfixes;

	private Pattern urlPattern;

	private int lengthOfPostfixToReplace;
	
	@SuppressWarnings("rawtypes")
	protected void activate(ComponentContext ctx) throws Exception {
		Dictionary props = ctx.getProperties();
		alwaysValidate = OsgiUtil.toBoolean(props.get(PROP_ALWAYS_VALIDATE),
				DEFAULT_ALWAYS_VALIDATE);
		mustAuthenticate = OsgiUtil.toBoolean(props.get(PROP_MUST_AUTHENTICATE), DEFAULT_MUST_AUTHENTICATE);

		if (authFilterAdaptor == null) {
			authFilterAdaptor = new CSPDefaultAdaptor();
		}
		if (log.isDebugEnabled())
			log.debug("Initialized " + this.getClass().getName()
					+ ": properties: " + props);
		urlPattern = Pattern.compile(URL_PATTERN);
		replacementPostfixes = OsgiUtil.toStringArray(
				props.get(PROP_REPLACEMENT_EXTENSIONS),
				DEFAULT_REPLACEMENT_POSTFIXES);
		lengthOfPostfixToReplace = OsgiUtil.toString(props.get(PROP_POSTFIX_TO_REPLACE), DEFAULT_POSTFIX_TO_REPLACE).length();
	}

	private String correctDomainName(HttpServletRequest request, String redirect) {
		Matcher match = urlPattern.matcher(redirect);
		if (match.matches()) {
			String requestDomainName = request.getServerName();
			for (String postfix : replacementPostfixes) {
				if (requestDomainName.endsWith(postfix)) {
					String redirectDomainName = match.group(2);
					StringBuilder sb = new StringBuilder();
					sb.append(match.group(1));
					sb.append(redirectDomainName.substring(0, redirectDomainName.length()
									- lengthOfPostfixToReplace));
					sb.append(postfix);
					sb.append(match.group(3));
					return sb.toString();
				}
			}
		}
		return redirect;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// NO-OP - lifecycle is in deactivate()
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 * javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	/**
	 * Calls routine to parse and validate cookies, subject to the
	 * {@link #alwaysValidate} flag (set from the property
	 * {@link #CSP_ALWAYS_VALIDATE}, a <code>true</code> value causes the
	 * validation to occur with every request, otherwise only once per session)
	 * and passes a custom request wrapper created with the cookie data down the
	 * chain. If {@link #mustAuthenticate} flag is set, any cookie problems will
	 * be handled by sending a redirect to the URL named in the exception and
	 * returning immediately, otherwise it's ignored and the original request is
	 * passed down the chain.
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void doFilter(ServletRequest req, ServletResponse rsp,
			FilterChain chain) throws IOException, ServletException {
		// for convenience
		HttpServletRequest hreq = (HttpServletRequest) req;
		HttpServletResponse hrsp = (HttpServletResponse) rsp;
		HttpSession session = hreq.getSession(false); // leave session creation
														// to getWrapper()
		Map<String, Object> m = null;
		HttpServletRequest outReq = hreq;

		if (alwaysValidate
				|| session == null
				|| (m = (HashMap<String, Object>) session
						.getAttribute(CSP_AUTHENTICATED_INFO)) == null) {
			try {
				outReq = authFilterAdaptor.getWrapper(hreq, hrsp,
						m = mapper.getCookieData(hreq));
				hreq.getSession(false).setAttribute(CSP_AUTHENTICATED_INFO, m);
				if (log.isDebugEnabled())
					log.debug("Mmmm! good CSP cookies, parsed values: " + m);
			} catch (AuthenticationRedirectException e) {
				if (authFilterAdaptor.isAuthenticationRequired(hreq,
						mustAuthenticate)) {
					String redirect = e.getMessage();
					redirect = correctDomainName(hreq, redirect);
					redirect = authFilterAdaptor.getRedirectURL(hreq, hrsp,
							redirect);
					if (log.isDebugEnabled())
						log.debug("No valid CSP cookies found: redirecting to "
								+ redirect);
					hrsp.sendRedirect(redirect);
					return;
				}
			}
		} else {
			/*
			 * if the session has logged-in data but there are no cookies, trash
			 * the session and redirect
			 */
			if (!mapper.hasRequiredCookies(hreq)) {
				StringBuffer URLbuf = hreq.getRequestURL();
				String query = hreq.getQueryString();
				if (query != null)
					URLbuf.append("?" + query);
				session.invalidate();
				log.debug("Authenticated session has no CSP cookies; invalidate and redirect to "
						+ URLbuf);
				hrsp.sendRedirect(URLbuf.toString());
				return;
			} else {
				if (log.isDebugEnabled())
					log.debug("Reusing existing session authentication data");
				outReq = authFilterAdaptor.getWrapper(hreq, hrsp, m);
			}
		}

		// If we are here, then user is already authenticated and data is available in session.
		if(m != null) {
			try {
				userService.createOrUpdateUser(m);
			} catch (LoginException e) {
				log.error("Failed to create/update user", e);
			}
		}

		chain.doFilter(outReq, rsp); // go on our merry way...
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	/**
	 * Gets configuration data from property file named by init-parameter
	 * <code>config</code>. Any properties required to be set are retrieved here
	 * in order to fail early.
	 */
	public void init(FilterConfig cfg) throws ServletException {
		// NO-OP - lifecycle is in activate()
	}

}
