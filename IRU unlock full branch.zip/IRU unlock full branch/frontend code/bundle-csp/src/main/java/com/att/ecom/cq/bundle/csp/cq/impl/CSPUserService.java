package com.att.ecom.cq.bundle.csp.cq.impl;

import java.util.Calendar;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.AccessDeniedException;
import javax.jcr.Node;
import javax.jcr.SimpleCredentials;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.auth.core.spi.AuthenticationInfo;
import org.apache.sling.auth.core.spi.AuthenticationInfoPostProcessor;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.csp.filter.impl.CSPCookieFilter;
import com.att.ecom.cq.bundle.csp.filter.impl.UserService;
import com.day.cq.security.Authorizable;
import com.day.cq.security.AuthorizableExistsException;
import com.day.cq.security.Group;
import com.day.cq.security.User;
import com.day.cq.security.UserManager;
import com.day.cq.security.profile.Profile;
import com.day.cq.wcm.api.NameConstants;

@Component(metatype=true)
@Service
public class CSPUserService implements UserService {

	private static final String DEFAULT_GROUP = "contributor,role-deny-nda";

	@Property(value = { DEFAULT_GROUP }, unbounded=PropertyUnbounded.ARRAY, label="Default Groups", description="The list of groups in which all users will be placed automatically.")
	private static final String PROP_GROUPS = "groups";

	private static final int DEFAULT_UPDATE_INTERVAL = 600;

	@Property(intValue = DEFAULT_UPDATE_INTERVAL, label="Update Interval", description="The amount of time (in seconds) between an update of the user's profile and group memberships.")
	private static final String PROP_UPDATE_INTERVAL = "updateInterval";

	private String groups;

	private int updateInterval;

	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	private Logger logger = LoggerFactory.getLogger(CSPUserService.class);

	@SuppressWarnings("rawtypes")
	protected void activate(ComponentContext ctx) {
		Dictionary props = ctx.getProperties();
		groups = OsgiUtil.toString(props.get(PROP_GROUPS),DEFAULT_GROUP);
		updateInterval = OsgiUtil.toInteger(props.get(PROP_UPDATE_INTERVAL),DEFAULT_UPDATE_INTERVAL);
	}

	private void addToGroups(UserManager userManager, User user) {
		String copyUserGroup = groups;
		for (Iterator<Group> group = user.memberOf(); group.hasNext();) {
			Group grp = group.next();
			if(grp.getID().toLowerCase().startsWith("nda")){
				copyUserGroup = copyUserGroup.replaceFirst("role-deny-nda", "");
			}
		}
		String[] myGroups = copyUserGroup.split(",");
		for (String groupName : myGroups) {
			if (groupName !="" && userManager.hasAuthorizable(groupName)) {
				Authorizable authorizable = userManager.get(groupName);
				if (authorizable instanceof Group) {
					Group group = (Group) authorizable;
					if (!group.isMember(user)) {
						group.addMember(user);
					}
				} else {
					logger.warn(String.format("Authorizable named %s was not a group, but was in the default group list",groupName));
				}
			} else {
				logger.warn(String.format("Authorizable named %s did not exist, but was in the default group list",groupName));
			}
		}
	}

	private void createUser(UserManager userManager, String userId,
			Map<String, Object> cspInfo) throws AccessDeniedException,
			AuthorizableExistsException, PersistenceException {
		User u = userManager.createUser(userId,
				RandomStringUtils.randomAlphanumeric(15), userId);
		setProfileProperties(u, cspInfo);
		addToGroups(userManager, u);

	}

	private void setProfileProperties(User user, Map<String, Object> cspInfo)
			throws PersistenceException {
		Profile profile = user.getProfile();
		profile.put(CQProfileConstants.EMAIL,
				cspInfo.get(CSPCookieFilter.CSP_HR_EMAIL));
		profile.put(CQProfileConstants.FIRST_NAME,
				cspInfo.get(CSPCookieFilter.CSP_HR_FIRST_NAME));
		profile.put(CQProfileConstants.LAST_NAME,
				cspInfo.get(CSPCookieFilter.CSP_HR_LAST_NAME));
		profile.save();
	}

	private boolean shouldUpdate(User user) {
		Node node = user.adaptTo(Node.class);
		try {
			Calendar cal = node.getProperty(NameConstants.PN_PAGE_LAST_MOD)
					.getDate();
			Calendar updateBoundary = Calendar.getInstance();
			updateBoundary.add(Calendar.SECOND, updateInterval);
			return (cal.after(updateBoundary));
		} catch (Exception e) { // $codepro.audit.disable logExceptions
			return true;
		}
	}

	private void updateUser(UserManager userManager, String userId,
			Map<String, Object> cspInfo) throws PersistenceException {
		User u = (User) userManager.get(userId);
		if (shouldUpdate(u)) {
			setProfileProperties(u, cspInfo);
		}
		addToGroups(userManager, u);
	}

	@Override
	public void createOrUpdateUser(Map<String, Object> cspInfo) throws LoginException {
			String userId = (String)cspInfo.get(CSPCookieFilter.CSP_ATT_UID);
 
			ResourceResolver adminResolver = null;
			try {
				adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
				UserManager userManager = adminResolver
						.adaptTo(UserManager.class);
				if (userManager.hasAuthorizable(userId)) {
					try {
						updateUser(userManager, userId, cspInfo);
					} catch (PersistenceException e) {
						logger.error(
								"Unable to update profile data from CSP cookie",
								e);
					}
				} else {
					try {
						createUser(userManager, userId, cspInfo);
					} catch (PersistenceException e) {
						logger.error(
								"Unable to save user profile properties from CSP cookie",
								e);
					} catch (Exception e) {
						logger.error("Unable to create new user", e);
						throw new LoginException("Unable to create new user", e);
					}
				}

			} finally {
				if (adminResolver != null) {
					adminResolver.close();
				}
			}
		}

}
