package com.att.ecom.cq.bundle.csp.cq.impl;

import java.util.Dictionary;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.csp.filter.impl.AuthenticationFilterAdaptor;
import com.att.ecom.cq.bundle.csp.filter.impl.CSPCookieFilter;
import com.att.ecom.cq.bundle.csp.filter.impl.CSPPrincipal;

@Component(metatype = true)
@Service
public class CQHeaderAuthenticationFilterAdapter implements
		AuthenticationFilterAdaptor {

	private static final Logger log = LoggerFactory
			.getLogger(CQHeaderAuthenticationFilterAdapter.class);

	private static final String DEFAULT_HEADER_NAME = "ATTUID";

	@Property(value = DEFAULT_HEADER_NAME, label = "ATTUID Header Name", description = "The name of the request header which needs to contain the ATTUID.")
	public static final String PROP_HEADER_NAME = "header";

	private String headerName;

	@SuppressWarnings("rawtypes")
	protected void activate(ComponentContext ctx) {
		Dictionary props = ctx.getProperties();
		headerName = OsgiUtil.toString(props.get(PROP_HEADER_NAME),
				DEFAULT_HEADER_NAME);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.att.security.web.servlet.filters.AuthenticationFilterAdaptor#
	 * getRedirectURL(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse, java.lang.String)
	 */
	public String getRedirectURL(HttpServletRequest req,
			HttpServletResponse rsp, String dfltURL) {
		return dfltURL;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.att.security.web.servlet.filters.AuthenticationFilterAdaptor#getWrapper
	 * (javax.servlet.http.HttpServletRequest, java.util.Map)
	 */
	public HttpServletRequestWrapper getWrapper(HttpServletRequest req,
			HttpServletResponse rsp, Map<String, Object> m) {
		CQCSPCookieRequestWrapper wrapper = new CQCSPCookieRequestWrapper(
				headerName, req);
		wrapper.setUserPrincipal(new CSPPrincipal((String) m
				.get(CSPCookieFilter.CSP_ATT_UID), m));
		HttpSession existingSession = req.getSession(false);
		HttpSession session = req.getSession();
		if (log.isDebugEnabled())
			log.debug("Created new CQCSPCookieRequestWrapper with "
					+ ((existingSession != null) ? "existing" : "new")
					+ " session " + session.getId() + " and Principal.name="
					+ m.get(CSPCookieFilter.CSP_ATT_UID));
		return wrapper;
	}

	/**
	 * If the Authentication header is set; use it and don't require CSP
	 * authentication
	 */
	public boolean isAuthenticationRequired(HttpServletRequest req,
			boolean defaultValue) {
		if (req.getHeader("Authorization") != null) {
			return false;
		} else {
			String hostName = req.getServerName();
			if (hostName.equals("localhost")) {
				return false;
			} else {
				return defaultValue;
			}
		}
	}
}
