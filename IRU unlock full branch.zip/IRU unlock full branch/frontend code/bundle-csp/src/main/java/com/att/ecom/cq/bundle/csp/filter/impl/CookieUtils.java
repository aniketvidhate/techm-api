/**
 * 
 */
package com.att.ecom.cq.bundle.csp.filter.impl;

/**
 * Utility class for the Cookie Filters
 * @author bt0008
 */
public class CookieUtils {

	/**
	 * Changes empty tokens (i.e. two consecutive delimiters) by inserting
	 * a space between the delimiters.  Prevents StringTokenizer's empty-token-skipping
	 * behavior from causing a miscount of fields.
	 * @param str - the {@link String} to modify
	 * @return a modified copy 
	 */
	static String fixAdjacentDelimiters(String str) {
		StringBuffer fixBuf = new StringBuffer(str);
	
		int n = 0;
		if(fixBuf.charAt(0) == '|')
			fixBuf.insert(0, ' ');
			
		while ((n = fixBuf.toString().indexOf("||", n)) != -1) {
			fixBuf = fixBuf.replace(n, n + 2, "| |");
			n += 2;
		}
		if(fixBuf.charAt(fixBuf.length()-1) == '|')
			fixBuf.append(' ');
		return fixBuf.toString();
	}
}
