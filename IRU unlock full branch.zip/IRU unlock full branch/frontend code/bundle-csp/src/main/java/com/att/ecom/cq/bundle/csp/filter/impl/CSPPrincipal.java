/**
 * 
 */
package com.att.ecom.cq.bundle.csp.filter.impl;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


/**
 * @author bt0008
 *
 */
public class CSPPrincipal implements Principal {

	/**
	 * Name returned by {@link #getName()}
	 */
	protected String name = null;
	/**
	 * All the fields from the CSP cookies.  Not all of these are interesting.
	 */
	private Map<String,Object> authInfo = null;
	private ArrayList<String> privs = null;
	
	
	/**
	 * @param attributes the list of values set in the CSP cookies
	 */
	public CSPPrincipal(String name, Map<String,Object> attributes) {
		this.name = name;
		authInfo = attributes;
		parsePatternA((String)authInfo.get(CSPCookieFilter.CSP_HR_PATTERN_A));
		String privsList = (String)authInfo.get(CSPCookieFilter.CSP_PRIVS);
		privs = new ArrayList<String>();
		for (String priv : privsList.split(","))
			privs.add(priv);
	}
	
	

	/**
	 * Gets objects parsed from the CSP cookies
	 * @param attr
	 * @return
	 */
	public Object get(String attr) {
		String[] prefixList = new String[]{
			CSPCookieFilter.CSP_HR_PATTERN_A + ".",
			CSPCookieFilter.CSP_HR_COOKIE_BASE, 
			CSPCookieFilter.CSP_SEC_COOKIE_BASE
		};
		Object value = null;
		
		for (String prefix : prefixList)
			if((value = authInfo.get(prefix + attr)) != null)
				break;
		return value;
	}

	public Map<String,Object> getMap() {
		return new HashMap<String,Object>(authInfo);
	}
	
	/* (non-Javadoc)
	 * @see java.security.Principal#getName()
	 */
	public String getName() {
		return name;
	}
	
	protected boolean hasRole(String privName) {
		return  Boolean.TRUE.equals(get(privName)) || privs.contains(privName);
	}
	
	protected void parsePatternA(String patternAstring) {
		int i = 0;
		int pAlength  = patternAstring.length();
		for(String name: CSPCookieFilter.patternAFieldList)
			authInfo.put(name, i<pAlength ? patternAstring.charAt(i++)=='Y': false);
	}
}

