/**
 * 
 */
package com.att.ecom.cq.bundle.csp.filter.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

/**
 * Handles {@link javax.servlet.http.Cookie}s, turning them into something interesting
 * @author bt0008
 *
 */
public interface CookieMapper {
	/**
	 * @param req
	 * @param props 
	 * @return a {@link HashMap} of values parsed from the cookies in the request
	 * @throws ServletException if, you know, something Really Bad happens
	 * @throws AuthenticationRedirectException to tell you where to go if it doesn't like the cookies
	 */
	public Map<String,Object> getCookieData(HttpServletRequest req) throws ServletException, AuthenticationRedirectException;
	/**
	 * @param req - the request we're filtering
	 * @return whether required cookies were found
	 */
	public boolean hasRequiredCookies(HttpServletRequest req);
}
