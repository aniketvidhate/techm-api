package com.att.ecom.cq.bundle.csp.cq.impl;

/**
 * Constants for property names within the CQ Profile.
 *
 */
public class CQProfileConstants {

	public static final String EMAIL = "email";
	
	public static final String FIRST_NAME = "givenName";
	
	public static final String LAST_NAME = "familyName";
}
