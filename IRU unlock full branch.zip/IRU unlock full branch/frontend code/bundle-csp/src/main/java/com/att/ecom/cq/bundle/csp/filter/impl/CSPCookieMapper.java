/**
 * 
 */
package com.att.ecom.cq.bundle.csp.filter.impl;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;

import esGateKeeper.esGateKeeper;
import esGateKeeper.hrCookie;

/**
 * @author bt0008
 * 
 */
@Component(metatype = true)
@Service
public class CSPCookieMapper implements CookieMapper {

	public static final int DEFAULT_HR_EMPCOOKIE_TOKENS = 12;

	public static final int DEFAULT_HR_PWCOOKIE_TOKENS = 12;

	public static final int DEFAULT_MIN_AUTH_STRENGTH = 0;

	public static final String DEFAULT_NO_COOKIE_URL = "https://webtest.csp.att.com/empsvcs/hrpinmgt/pagLogin/?retURL=";

	public static final int DEFAULT_SEC_COOKIE_TOKENS = 8;

	public static final String DEFAULT_SERVER_ENV = "DEVL";

	public static final String DEFAULT_TOO_WEAK_URL = "https://webtest.csp.att.com/empsvcs/hr/pagMenu_chgpin/?opt=12";

	@Property(intValue = DEFAULT_HR_EMPCOOKIE_TOKENS, label="Employee Cookie Tokens", description = "Required number of fields in the attESHr cookie if the user is an employee. Originally one more than if not an employee, accounts for the addition of the salary grade field.")
	public static final String PROP_HR_EMPCOOKIE_TOKENS = "empCookieTokens";

	@Property(intValue = DEFAULT_HR_PWCOOKIE_TOKENS, label="Non-Employee Cookie Tokens", description="Required number of fields in the attESHr cookie if the user is NOT an employee")
	public static final String PROP_HR_PWCOOKIE_TOKENS = "pwCookieTokens";

	@Property(intValue = DEFAULT_MIN_AUTH_STRENGTH, label="Minimum Auth Strength", description = "Optional minimum required authentication strength")
	public static final String PROP_MIN_AUTH_STRENGTH = "minAuthStrength";

	@Property(value = DEFAULT_NO_COOKIE_URL, label="No Cookie URL", description = "URL to which browsers will be redirected if the cookies don't crumble right")
	public static final String PROP_NO_COOKIE_URL = "noCookieURL";
	
	@Property(intValue = DEFAULT_SEC_COOKIE_TOKENS, label="Secure Cookie Tokens", description = "Required number of fields in the attESSec cookie")
	public static final String PROP_SEC_COOKIE_TOKENS = "secCookieTokens";

	@Property(value = DEFAULT_SERVER_ENV, label="Gatekeeper Environment", description = "The environment - development ('DEVL') or production ('PROD') - which supplies credentials")
	public static final String PROP_SERVER_ENV = "gateKeeperEnv";

	@Property(label="CSP System Name",description="CSP-assigned value for the sysName parameter of the login URL")
	public static final String PROP_SYSNAME = "sysName";

	@Property(value = DEFAULT_TOO_WEAK_URL, label="Too Weak URL", description = "URL to which browsers will be redirected if minimum auth strength is not met")
	public static final String PROP_TOO_WEAK_URL = "tooWeakURL";

	private static final int tzOffset = Calendar.getInstance().get(
			Calendar.ZONE_OFFSET)
			/ (3600 * 1000);
	private int hrEmpCookieTokenCount = 0;
	private int hrPwCookieTokenCount = 0;
	private int minAuthStrength = 20;
	private String noCookieURL = null;
	private int secCookieTokenCount = 0;
	private String serverEnv = null;
	private String sysName = null;
	private String tooWeakURL = null;

	protected void activate(ComponentContext ctx) throws IllegalArgumentException {
		Dictionary<?, ?> props = ctx.getProperties();
		noCookieURL = OsgiUtil.toString(props.get(PROP_NO_COOKIE_URL), DEFAULT_NO_COOKIE_URL);
		tooWeakURL = OsgiUtil.toString(props.get(PROP_TOO_WEAK_URL), DEFAULT_TOO_WEAK_URL);
		serverEnv = OsgiUtil.toString(props.get(PROP_SERVER_ENV), DEFAULT_SERVER_ENV);
		sysName = OsgiUtil.toString(props.get(PROP_SYSNAME), null);
		minAuthStrength = OsgiUtil.toInteger(props.get(PROP_MIN_AUTH_STRENGTH), DEFAULT_MIN_AUTH_STRENGTH);
		secCookieTokenCount = OsgiUtil.toInteger(props.get(PROP_SEC_COOKIE_TOKENS), DEFAULT_SEC_COOKIE_TOKENS);
		hrEmpCookieTokenCount = OsgiUtil.toInteger(props.get(PROP_HR_EMPCOOKIE_TOKENS), DEFAULT_HR_EMPCOOKIE_TOKENS);
		hrPwCookieTokenCount = OsgiUtil.toInteger(props.get(PROP_HR_PWCOOKIE_TOKENS), DEFAULT_HR_PWCOOKIE_TOKENS);

		if (noCookieURL == null) {
			throw new IllegalArgumentException("missing URL for CSP cookie-setting service");
		}
		if (minAuthStrength > 0 && tooWeakURL == null) {
			throw new IllegalArgumentException("missing URL for auth-strength error page");
		}
		if (sysName == null) {
			throw new IllegalArgumentException("missing sysname");
		}
	}

	/**
	 * Digests two cookies set by the AT&T Global Logon service if present,
	 * calling esGateKeeper.esGateKeeper() (NOT a constructor, despite its name)
	 * to decrypt and validate the "attESSec" cookie first, and tokenizing both
	 * on a "|" delimiter. The second attESSec field is a signature on the
	 * "attESHr" cookie's data, which is then validated.
	 * 
	 * If all checks succeed, the parsed tokens are placed in a Map keyed by
	 * names chosen arbitrarily by me, and an HTTPServletRequestWrapper is
	 * constructed of the original request and the Map by a configuration-
	 * specified AuthenticationFilterAdaptor implementation, or the default
	 * defined in this class. If all goes well, the wrapper is returned to pass
	 * down the filter chain.
	 * 
	 * @param req
	 *            the wrapped request
	 * @return an HttpServletRequestWrapper configured for the servlet's needs
	 *         from the request and the authenticated parsed cookie data.
	 * @throws AuthenticationRedirectException
	 *             if any problem arises that would be handled by a redirect if
	 *             the {@link #mustAuthenticate} flag is set.
	 * @throws ServletException
	 *             in case of hopeless error.
	 * 
	 */
	public Map<String, Object> getCookieData(HttpServletRequest req)
			throws ServletException, AuthenticationRedirectException {

		Cookie[] cookies = req.getCookies();
		HashMap<String, Object> map = null;
		String attESSec = null;
		String attESHr = null;
		try {
			if (cookies != null)
				for (Cookie cookie : cookies) {
					if (cookie.getName().equals("attESSec")) {
						if ((attESSec = esGateKeeper.esGateKeeper(
								cookie.getValue(), "CSP", serverEnv, tzOffset)) == null
								|| "".equals(attESSec)) {
							attESSec = null;
							break;
						}
					} else if (cookie.getName().equals("attESHr")) {
						attESHr = cookie.getValue();
					}
				}

			// Check the cookies to see that they're present, not expired, etc.
			if (attESSec == null || attESHr == null) {
				String query = ((query = req.getQueryString()) == null) ? ""
						: "?" + query;
				throw new AuthenticationRedirectException(noCookieURL
						+ URLEncoder.encode(req.getRequestURL() + query,
								"utf-8") + "&sysName=" + sysName);
			} else {
				map = new HashMap<String, Object>();
				String authStr = null;
				// per W3C, utf-8 is standard, despite the option
				String eSSec = CookieUtils.fixAdjacentDelimiters(URLDecoder
						.decode(attESSec, "utf-8"));
				StringTokenizer tokens = new StringTokenizer(eSSec, "|");
				int tokCount = tokens.countTokens();
				if (tokCount != secCookieTokenCount)
					throw new Exception(
							"broken cookie \"attESSec\": token count ("
									+ tokCount + ") not equal to "
									+ secCookieTokenCount);
				map.put(CSPCookieFilter.CSP_HRID, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_COOKIE_SIG, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_EMPTYPE, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_AUTHSTR,
						authStr = tokens.nextToken());
				map.put(CSPCookieFilter.CSP_PRIVS, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_ATT_UID, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_AUTHENV, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_TIMESTAMP, tokens.nextToken());
				if (Integer.parseInt(authStr) < minAuthStrength)
					throw new AuthenticationRedirectException(tooWeakURL);

				hrCookie oCookieVerifier = new hrCookie();

				// In Java environments the attESHr cookie must be decoded
				// before attempting to verify it.
				int hrCookieValid = oCookieVerifier.verify(
						URLDecoder.decode(attESHr, "utf-8"),
						(String) map.get(CSPCookieFilter.CSP_HR_COOKIE_SIG));
				if (hrCookieValid != 0)
					throw new Exception(
							"broken cookie \"attESHr\": signature check returned "
									+ hrCookieValid);

				String eSHr = CookieUtils.fixAdjacentDelimiters(URLDecoder
						.decode(attESHr, "utf-8"));
				tokens = new StringTokenizer(eSHr, "|");
				tokCount = tokens.countTokens();
				String empType = (String) map.get(CSPCookieFilter.CSP_EMPTYPE);
				int expectedTokenCount = "E".equals(empType) ? hrEmpCookieTokenCount
						: hrPwCookieTokenCount;
				if (tokCount != expectedTokenCount)
					throw new Exception(
							"broken cookie \"attESHr\": token count ("
									+ tokCount + ") not equal to "
									+ expectedTokenCount);
				map.put(CSPCookieFilter.CSP_HR_FIRST_NAME, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_LAST_NAME, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_EMAIL, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_WORKPHONE, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_MIDDLE_NAME, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_MGR_ATTUID, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_NAME_SUFFIX, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_MGR_HRID, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_PATTERN_A, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_CLLI, tokens.nextToken());
				map.put(CSPCookieFilter.CSP_HR_FML_ORG_CODE, tokens.nextToken());
				if (tokens.hasMoreTokens()) // [s]he's an employee
					map.put(CSPCookieFilter.CSP_HR_SALARYGRADE,
							tokens.nextToken());
			}
		} catch (AuthenticationRedirectException e) {
			throw e;
		} catch (Exception e) {
			throw new ServletException(e);
		}
		return map;
	}

	public boolean hasRequiredCookies(HttpServletRequest req) {
		Cookie[] cookies;
		int found = 0;
		if ((cookies = req.getCookies()) == null)
			return false;
		for (int i = 0; i < cookies.length; i++) {
			Cookie cookie = cookies[i];
			if ("attESSec".equals(cookie.getName())
					|| "attESHr".equals(cookie.getName())) {
				if (cookie.getMaxAge() == 0) // cookie present but expired
					break;
				found++;
			}
		}
		return found == 2;
	}

}
