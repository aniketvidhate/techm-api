/**
 * 
 */
package com.att.ecom.cq.bundle.csp.filter.impl;

import java.security.Principal;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 * Implementors of this class can adapt the CSPCookieFilter class's data
 * to the needs of their specific servlet.  A default implementation exists in
 * CSPCookieFilter.CSPWrapperFactory.
 * 
 * @author bt0008
 *
 */
public interface AuthenticationFilterAdaptor {
	/**
	 * If the filter decides that a redirect is required,
	 * it will redirect to the URL returned by this method.
	 * Ordinarily, this method should simply return the default URL passed to it;
	 * this method is provided so as to allow for cases where it must be modified. 
	 * @param req - the incoming servlet request
	 * @param rsp - the servlet response
	 * @param dfltURL - the default URL
	 * @return
	 */
	public String getRedirectURL(HttpServletRequest req, HttpServletResponse rsp, String dfltURL);
	
	
	/**
	 * Do whatever your servlet requires to be done with the parsed CSP cookie data.
	 * If a customized HttpServletRequestWrapper is needed by your
	 * servlet, you may construct it here.
	 * {@link CSPCookieFilter#doFilter(ServletRequest, ServletResponse, FilterChain)}
	 * calls this after successfully parsing the CSP cookies and setting them as attribute
	 * {@link CSPCookieFilter#CSP_AUTHENTICATED_INFO} in the session
	 * (or reusing existing data from the session, if appropriate).
	 * If valid information is not found in the request or reused from the session,
	 * this function will <b>not</b> be called.  A {@link CSPCookieRequestWrapper)
	 * may be constructed and returned; this will create a {@link Principal}
	 * which makes the Map available via a <code>getMap()</code> call, and whose
	 * standard call <code>getName()</code> returns the value keyed by
	 * {@link CSPCookieFilter#CSP_ATT_UID}.  It also implements 
	 * (@link javax.servlet.http.HttpServletRequestWrapper#isUserInRole(java.lang.String)}
	 * so that it returns <code>true</code> if its argument matches any of the roles 
	 * assigned in the {@link CSPCookieFilter#CSP_PRIVS} attribute
	 * or if it names one of the flags in the {@link CSPCookieFilter#CSP_HR_PATTERN_A} list
	 * whose value is "Y".
	 * Alternatively, the incoming request may be returned, with or without modification.
	 * @param req - the incoming servlet request
	 * @param rsp - the servlet response
	 * @param m the Map of cookie-supplied attributes
	 * @return an application-specific request wrapper configured for the servlet's
	 * specific needs.
	 */
	public HttpServletRequestWrapper getWrapper(HttpServletRequest req, HttpServletResponse rsp, Map<String, Object> m);
	
	/**
	 * Given the incoming request and the default configured value of 
	 * the <code>mustAuthenticate</code> flag, return whether this request should
	 * require authentication.  If this choice does not depend on anything in the 
	 * request, this should simply return <code>defaultValue</code>.
	 * 
	 * This method is for servlets for which the question of whether authentication
	 * should be required cannot be determined by the <code>url-pattern</code>
	 * in the filter-mapping elements of the deployment descriptor.
	 * If {@link CSPCookieFilter#doFilter(ServletRequest, ServletResponse, FilterChain)}
	 * cannot find valid CSP cookie data for a request and this method returns <code>true</code>, 
	 * it will redirect the browser to the CSP login page; otherwise, it will continue
	 * processing the filter chain.
	 * @param req - the incoming servlet request
	 * @param defaultValue - the value configured in the filter's
	 * init-param named <code>mustAuthenticate</code>
	 * @return
	 */
	public boolean isAuthenticationRequired(HttpServletRequest req, boolean defaultValue);
}
