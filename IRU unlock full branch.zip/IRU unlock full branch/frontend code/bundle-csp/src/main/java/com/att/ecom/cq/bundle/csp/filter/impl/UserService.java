package com.att.ecom.cq.bundle.csp.filter.impl;

import java.util.Map;

import org.apache.sling.api.resource.LoginException;

public interface UserService {
	public void createOrUpdateUser(Map<String, Object> userData) throws LoginException ;
}
