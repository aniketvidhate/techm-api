/**
 * 
 */
package com.att.ecom.cq.bundle.csp.filter.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;


/**
 * @author bt0008
 * 
 * Enables proper behaviour of HttpServletRequestWrapper's getUserPrincipal() 
 * and isUserInRole() methods for the CSPCookieFilter class.
 * 
 * Because HttpServletRequestWrapper doesn't have a setUserPrincipal method,
 * I'm wary of implementing one here, in particular because the wrapper used
 * by the application I originally created it for doesn't store a @link(Principal)
 * as a private field, but as a session attribute keyed with a package-specified 
 * value.  For this reason, the presumed calling filter, CSPCookieFilter.doFilter(),
 * calls setSessionData() from a class named by an initialization parameter and
 * implementing this package's SessionDataSetter interface.
 */
public class CSPCookieRequestWrapper extends HttpServletRequestWrapper {
	private CSPPrincipal userPrincipal;
	/**
	 * @param req
	 */
	public CSPCookieRequestWrapper(HttpServletRequest req) {
		super(req);
	}

	/**
	 * @return Returns the userPrincipal.
	 */
	public CSPPrincipal getUserPrincipal() {
		return userPrincipal;
	}
	

	@Override
	public boolean isUserInRole(String role) {
		return userPrincipal.hasRole(role);
	}

	/**
	 * @param userPrincipal The userPrincipal to set.
	 */
	public void setUserPrincipal(CSPPrincipal userPrincipal) {
		this.userPrincipal = userPrincipal;
	}
	
}
