package com.att.ecom.cq.bundle.csp.cq.impl;

import javax.servlet.http.HttpServletRequest;

import com.att.ecom.cq.bundle.csp.filter.impl.CSPCookieRequestWrapper;

/**
 * @author bt0008
 * @author je778t
 * 
 * Enables proper behaviour of HttpServletRequestWrapper's getUserPrincipal() 
 * and isUserInRole() methods for the CSPCookieFilter class.
 * 
 * Because HttpServletRequestWrapper doesn't have a setUserPrincipal method,
 * I'm wary of implementing one here, in particular because the wrapper used
 * by the application I originally created it for doesn't store a @link(Principal)
 * as a private field, but as a session attribute keyed with a package-specified 
 * value.  For this reason, the presumed calling filter, CSPCookieFilter.doFilter(),
 * calls setSessionData() from a class named by an initialization parameter and
 * implementing this package's SessionDataSetter interface.
 */
public class CQCSPCookieRequestWrapper extends CSPCookieRequestWrapper {
	
	private final String headerName;
	
	/**
	 * @param headerName 
	 * @param req
	 */
	public CQCSPCookieRequestWrapper(String headerName, HttpServletRequest req) {
		super(req);
		this.headerName = headerName;
	}

	@Override
	public String getHeader(String name) {
		if (headerName.equals(name)) {
			return getUserPrincipal().getName();
		} else {
			return super.getHeader(name);
		}
	}
	
}