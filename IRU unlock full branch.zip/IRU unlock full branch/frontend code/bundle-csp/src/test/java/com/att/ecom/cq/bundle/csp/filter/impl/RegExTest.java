package com.att.ecom.cq.bundle.csp.filter.impl;

import java.util.regex.Pattern;

import static org.junit.Assert.*;
import org.junit.Test;

public class RegExTest {
	
	@Test
	public void test() {
		String pattern = "^(?!/system/console/)(?!/maven/).*$";
		Pattern regex = Pattern.compile(pattern);
		
		assertFalse(regex.matcher("/system/console/bundles").matches());
		assertFalse(regex.matcher("/system/console/bundles/foo").matches());
		assertFalse(regex.matcher("/maven/").matches());
		assertFalse(regex.matcher("/maven/repository").matches());
		assertFalse(regex.matcher("/maven/repository/foo").matches());
		assertTrue(regex.matcher("/").matches());
		assertTrue(regex.matcher("/system/foo/bar").matches());
		assertTrue(regex.matcher("/content/system/console/bundles").matches());
		assertTrue(regex.matcher("/content/system/console/bundles/foo").matches());
		assertTrue(regex.matcher("/content/maven").matches());
		assertTrue(regex.matcher("/content/maven/repository").matches());
		assertTrue(regex.matcher("/content/maven/repository/foo").matches());
	}

}
