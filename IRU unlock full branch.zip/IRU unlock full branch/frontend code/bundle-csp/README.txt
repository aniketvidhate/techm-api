This module contains integration between AT&T's Common Security Platform (CSP) and CQ/CRX.

BEFORE installing this module, it is necessary to configure CRX for SSO to set the
trust credentials attribute to 03e2a1cac921ba5da75666813d03996c (which is already
configured in the SsoAuthenticationHandler.

Details can be found here: http://dev.day.com/content/docs/en/cq/current/deploying/configuring_cq.html#Single%20Sign%20On

In short, edit crx-quickstart/repository/repository.xml and add
<param name="trust_credentials_attribute" value="03e2a1cac921ba5da75666813d03996c"/>

to the LoginModule.

Then restart CRX.