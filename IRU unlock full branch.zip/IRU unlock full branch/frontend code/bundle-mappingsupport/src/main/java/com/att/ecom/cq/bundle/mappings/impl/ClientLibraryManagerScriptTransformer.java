package com.att.ecom.cq.bundle.mappings.impl;

import java.io.IOException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.rewriter.ProcessingComponentConfiguration;
import org.apache.sling.rewriter.ProcessingContext;
import org.apache.sling.rewriter.Transformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;

/**
 * Rewrite pipeline component which rewrites the JSON object used by the JavaScript implementation of the
 * CQClientLibraryManager. This class is not intended to be thread-safe.
 */
class ClientLibraryManagerScriptTransformer implements Transformer {

    /** A blank string. */
    private static final String BLANK = "";

    /** The end of a client library manager write() call. */
    private static final String END_CLIENT_MANAGER_JS = ",false);";

    /** The length of the client library manager end token. */
    private static final int END_CLIENT_MANAGER_JS_LENGTH;

    /** The key for paths in the JSON object. */
    private static final String KEY_PATH = "p";

    /** The logger instance used by this component. */
    private static final Logger LOGGER = LoggerFactory.getLogger(ClientLibraryManagerScriptTransformer.class);

    /** The newline character. */
    private static final String NL = "\n";

    /** The script tag name. */
    private static final String SCRIPT_TAG = "script";

    /** The start of a client library manager write() call. */
    private static final String START_CLIENT_MANAGER_JS = "GraniteClientLibraryManager.write(";

    /** The length of the client library manager start token. */
    private static final int START_CLIENT_MANAGER_JS_LENGTH;

    static {
        START_CLIENT_MANAGER_JS_LENGTH = START_CLIENT_MANAGER_JS.length();
        END_CLIENT_MANAGER_JS_LENGTH = END_CLIENT_MANAGER_JS.length();
    }

    /** The context path for the request in which this transformer is running. */
    private String mContextPath;

    /** Boolean indicating whether or not this request has a non-blank context path. */
    private boolean mHasContextPath;

    /**
     * The link rewriter used to rewrite links.
     */
    private final AllPathsLinkRewriter mLinkRewriter;

    /** The next pipeline component. */
    private ContentHandler mNextHandler;

    /** The actual request used in which this transformer is running. */
    private SlingHttpServletRequest mRequest;

    /** The StringBuilder used to collect character arrays within a script tag. */
    private StringBuilder mScriptStringBuilder;

    /**
     * Construct a new ClientLibraryManagerScriptTransformer instance.
     * 
     * @param pLinkRewriter an instance of AllPathsLinkRewriter
     */
    ClientLibraryManagerScriptTransformer(final AllPathsLinkRewriter pLinkRewriter) {
        this.mLinkRewriter = pLinkRewriter;
    }

    /**
     * Read characters from the parsed document. If we are inside of a script tag, append the text to a StringBuilder.
     * 
     * @param pCharacters
     *            the characters from the XML document
     * @param pStart
     *            the start position in the array
     * @param pLength
     *            the number of characters to read from the array
     */
    public void characters(final char[] pCharacters, final int pStart, final int pLength) throws SAXException {
        if (this.mScriptStringBuilder != null) {
            this.mScriptStringBuilder.append(pCharacters, pStart, pLength);
        } else {
            this.mNextHandler.characters(pCharacters, pStart, pLength);
        }

    }

    /** No-op. */
    public void dispose() {
    }

    /** No-op; pass through to next handler. */
    public void endDocument() throws SAXException {
        this.mNextHandler.endDocument();
    }

    /**
     * Upon the end of an element, if there is an open StringBuilder, rewrite the links within the
     * CQClientLibraryManager JSON Object.
     * 
     * @param pUri
     *            the namespace URI of the element
     * @param pLocalName
     *            the localName of the element
     * @param pQualifiedName
     *            the qualified name of the element
     */
    public void endElement(final String pUri, final String pLocalName, final String pQualifiedName) throws SAXException {
        if (this.mScriptStringBuilder != null) {
            String scriptString = this.mScriptStringBuilder.toString();
            final String trimmedScriptString = scriptString.trim();
            if (trimmedScriptString.startsWith(START_CLIENT_MANAGER_JS)
                    && trimmedScriptString.endsWith(END_CLIENT_MANAGER_JS)) {
                final String clientMgrArrString = trimmedScriptString.substring(START_CLIENT_MANAGER_JS_LENGTH,
                        trimmedScriptString.length() - END_CLIENT_MANAGER_JS_LENGTH);
                try {
                    final JSONArray clientMgrArray = new JSONArray(clientMgrArrString);
                    for (int i = 0; i < clientMgrArray.length(); i++) {
                        final JSONObject obj = clientMgrArray.getJSONObject(i);
                        String path = obj.getString(KEY_PATH);
                        // strip of the context path as resourceResolver.map
                        // will prepend it
                        if (this.mHasContextPath && path.startsWith(this.mContextPath)) {
                            path = path.substring(this.mContextPath.length());
                        }

                        obj.put(KEY_PATH, this.mLinkRewriter.mapPath(this.mRequest, path));
                    }
                    final StringBuilder rewrittenBuilder = new StringBuilder();
                    rewrittenBuilder.append(NL).append(START_CLIENT_MANAGER_JS).append(clientMgrArray.toString());
                    rewrittenBuilder.append(END_CLIENT_MANAGER_JS).append(NL);
                    scriptString = rewrittenBuilder.toString();
                } catch (JSONException e) {
                    LOGGER.warn("Unable to parse client library object", e);
                }

            }
            this.mNextHandler.characters(scriptString.toCharArray(), 0, scriptString.length());
            this.mScriptStringBuilder = null;
        }

        this.mNextHandler.endElement(pUri, pLocalName, pQualifiedName);

    }

    /** No-op; pass through to next handler. */
    public void endPrefixMapping(final String mPrefix) throws SAXException {
        this.mNextHandler.endPrefixMapping(mPrefix);
    }

    /** No-op; pass through to next handler. */
    public void ignorableWhitespace(final char[] mCharacters, final int mStart, final int mLength) throws SAXException {
        this.mNextHandler.ignorableWhitespace(mCharacters, mStart, mLength);
    }

    /**
     * Initialize this transformer by setting up the context path and pre-calcuating the presence of the context path.
     * 
     * @param mContext
     *            the Processing Context
     * @param mConfig
     *            the configuration for this processing component (currently none)
     */
    public void init(final ProcessingContext mContext, final ProcessingComponentConfiguration mConfig)
            throws IOException {
        this.mRequest = mContext.getRequest();
        this.mContextPath = this.mRequest.getContextPath();
        this.mHasContextPath = !(this.mContextPath == null || BLANK.equals(this.mContextPath));

    }

    /** No-op; pass through to next handler. */
    public void processingInstruction(final String mTarget, final String mData) throws SAXException {
        this.mNextHandler.processingInstruction(mTarget, mData);
    }

    /**
     * Interface method by which the Rewriter framework sets the next handler
     * 
     * @param pHandler
     *            Another transformer or a serializer.
     */
    public void setContentHandler(final ContentHandler pHandler) {
        this.mNextHandler = pHandler;

    }

    /** No-op; pass through to next handler. */
    public void setDocumentLocator(final Locator mLocator) {
        this.mNextHandler.setDocumentLocator(mLocator);
    }

    /** No-op; pass through to next handler. */
    public void skippedEntity(final String mName) throws SAXException {
        this.mNextHandler.skippedEntity(mName);
    }

    /** No-op; pass through to next handler. */
    public void startDocument() throws SAXException {
        this.mNextHandler.startDocument();
    }

    /**
     * startElement event handler. If the tag is a script tag, create a StringBuilder to hold the contents of the script
     * tag.
     * 
     * @param pUri
     *            the namespace URI of the element
     * @param pLocalName
     *            the localName of the element
     * @param pQualifiedName
     *            the qualified name of the element
     * @param attrs
     *            the attributes of the element
     */
    public void startElement(final String pUri, final String pLocalName, final String pQualifiedName,
            final Attributes pAtts) throws SAXException {
        this.mNextHandler.startElement(pUri, pLocalName, pQualifiedName, pAtts);
        if (SCRIPT_TAG.equals(pLocalName)) {
            this.mScriptStringBuilder = new StringBuilder();
        }

    }

    /** No-op; pass through to next handler. */
    public void startPrefixMapping(final String mPrefix, final String mUri) throws SAXException {
        this.mNextHandler.startPrefixMapping(mPrefix, mUri);

    }

}