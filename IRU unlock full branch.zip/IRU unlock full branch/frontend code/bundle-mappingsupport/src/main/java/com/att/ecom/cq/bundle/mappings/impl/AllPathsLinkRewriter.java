/* <AT&T Knowledge Ventures Copyright>
 * Copyright (C) 2005 AT&T Knowledge Ventures
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from AT&T Knowledge Ventures.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AT&T KNOWLEDGE VENTURES MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AT&T KNOWLEDGE VENTURES
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </AT&T Knowledge Ventures Copyright>
 */
package com.att.ecom.cq.bundle.mappings.impl;

import java.io.IOException;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Services;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;

import com.day.cq.rewriter.linkchecker.Link;
import com.day.cq.rewriter.linkchecker.LinkCheckerSettings;
import com.day.cq.rewriter.pipeline.RequestRewriter;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.util.concurrent.UncheckedExecutionException;

/**
 * Component which overwrites the default behavior to only map links for html pages to map links for all requests
 * regardless of extension.
 * 
 * This component will build a cache of mapped paths. A unique cache will be created for each host/scheme/port
 * combination. It will log cache statistics every five minutes (by default).
 */
@Component(metatype = true, label = "All Paths Link Rewriter", description = "Component which handles the rewriting of all paths.")
@Services({ @Service(RequestRewriter.class), @Service(Runnable.class), @Service(AllPathsLinkRewriter.class) })
@Properties({
        @Property(name = "scheduler.period", label = "Period for stats logging", longValue = 300, description = "Period (in seconds) at which time cache statistics will be logged."),
        @Property(name = "scheduler.name", value = "LinkRewriter Cache Stats", propertyPrivate = true),
        @Property(name = "scheduler.concurrent", boolValue = false, propertyPrivate = true) })
public class AllPathsLinkRewriter implements RequestRewriter, Runnable {

    /**
     * Servlet which enables flushing of the internal caches used by this component.
     */
    @SuppressWarnings("serial")
    private class FlusherServlet extends SlingAllMethodsServlet {

        /**
         * If this is the admin user, go through each cache and invalidate the contents.
         */
        @Override
        protected void doPost(final SlingHttpServletRequest mRequest, final SlingHttpServletResponse mResponse)
                throws ServletException, IOException {
            final String userId = mRequest.getResourceResolver().getUserID();
            if (USERNAME_ADMIN.equals(userId)) {
                if (AllPathsLinkRewriter.this.mCaches != null) {
                    for (final Cache<String, String> cache : AllPathsLinkRewriter.this.mCaches.values()) {
                        cache.invalidateAll();
                    }
                }
                mResponse.getWriter().println(MSG_CACHE_FLUSHED);
            } else {
                mResponse.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE);
            }
        }

    }

    /** The default value for the initial capacity of internal caches. */
    private static final int DEFAULT_INITIAL_CAPACITY = 1000;

    /** The default value for the maximum size of internal caches. */
    private static final int DEFAULT_MAX_CACHE_SIZE = 10000;

    /** The default value for the TTL of internal caches. */
    private static final int DEFAULT_TTL = 3600;

    /** The path at which the cache flusher servlet will be mounted. */
    private static final String FLUSH_PATH = "/bin/cacheflush/allpathslinkrewriter";

    /** The fragment delimiter value. */
    private static final String HASH_MARK = "#";

    /** List of path prefixes which are always ignored for link rewriting. */
    private static final List<String> IGNORED_PREFIXES = Arrays.asList("libs/cq/core", "libs/cq/ui");

    private static final String INDEX_HTML_POSTFIX = "/index.html";

    /** The message to output upon a successful cache flush. */
    private static final String MSG_CACHE_FLUSHED = "cache flushed";

    /** The error message to log when a cache retrieval fails. */
    private static final String MSG_CACHE_LOAD_FAILED = "Unable to map path via cache loader. Falling back to non-cached mapping";

    /** The log message which contains the cache statistics. */
    private static final String MSG_CACHE_STATS = "Cache Stats for {}: {}";

    /** The OSGi Service Property which contains the initial capacity value for internal caches. */
    @Property(label = "Initial Cache Capacity", description = "The intial capacity for newly created caches.", intValue = DEFAULT_INITIAL_CAPACITY)
    private static final String PROP_INITIAL_CAPACITY = "initial.cache.capacity";

    /** The OSGi Service Property which contains the maximum size value for internal caches. */
    @Property(label = "Maximum Cache Size", description = "The maximum number of cached mappings per scheme/host/port combination.", intValue = DEFAULT_MAX_CACHE_SIZE)
    private static final String PROP_MAX_CACHE_SIZE = "max.cache.size";

    /** The OSGi Service Property which contains the initial capacity value for internal caches. */
    @Property(label = "Cache TTL", description = "The TTL, in seconds, for entries in the mapping cache.", intValue = DEFAULT_TTL)
    private static final String PROP_TTL = "cache.ttl";

    /** The query string delimiter value. */
    private static final String QUESTION_MARK = "?";

    /** The slash character. */
    private static final String SLASH = "/";

    /** The name of the admin user. */
    private static final String USERNAME_ADMIN = "admin";

    /** The internal caches, keyed by the scheme/host/port of the request. */
    private ConcurrentMap<MappingRequest, Cache<String, String>> mCaches;

    /** The TTL for internal caches. */
    private int mCacheTimeToLive;

    /** The initial capacity for internal caches. */
    private int mInitialCacheCapacity;

    /** The logger instance used by this component. */
    private Logger mLogger = LoggerFactory.getLogger(AllPathsLinkRewriter.class);

    /** The maximum size for internal caches. */
    private int mMaxCacheSize;

    /** The resource resolver used for cached mappings. */
    private ResourceResolver mResolver;

    /** The resource resolver factory used to create a ResourceResolver for cached mappings. */
    @Reference
    private ResourceResolverFactory mResourceResolverFactory;

    /** The registration object for the flusher servlet. */
    private ServiceRegistration mServletReference;

    /**
     * Activate this component by reading configuration properties, creating an administrative ResourceResolver for use
     * in the cache loader, and registering the flusher servlet.
     * 
     * @param pCtx
     *            the DS ComponentContext
     */
    @SuppressWarnings("rawtypes")
    protected void activate(final ComponentContext pCtx) throws Exception {
        this.mResolver = mResourceResolverFactory.getAdministrativeResourceResolver(null);
        Dictionary properties = pCtx.getProperties();
        this.mMaxCacheSize = OsgiUtil.toInteger(properties.get(PROP_MAX_CACHE_SIZE), DEFAULT_MAX_CACHE_SIZE);
        this.mCacheTimeToLive = OsgiUtil.toInteger(properties.get(PROP_TTL), DEFAULT_TTL);
        this.mInitialCacheCapacity = OsgiUtil
                .toInteger(properties.get(PROP_INITIAL_CAPACITY), DEFAULT_INITIAL_CAPACITY);
        this.mCaches = new ConcurrentHashMap<MappingRequest, Cache<String, String>>(3);

        java.util.Properties servletProps = new java.util.Properties();
        servletProps.put("sling.servlet.paths", FLUSH_PATH);
        this.mServletReference = pCtx.getBundleContext().registerService(Servlet.class.getName(), new FlusherServlet(),
                servletProps);

    }

    /**
     * Create a new Cache for a particular host/name/port combination.
     * 
     * @param pRequestForMapping
     *            a representation of the scheme/host/port used to generate mappings
     */
    private Cache<String, String> createCache(final MappingRequest pRequestForMapping) {
        return CacheBuilder.newBuilder().initialCapacity(this.mInitialCacheCapacity).maximumSize(this.mMaxCacheSize)
                .expireAfterAccess(this.mCacheTimeToLive, TimeUnit.SECONDS).build(new CacheLoader<String, String>() {
                    @Override
                    public String load(String key) throws Exception {
                        return mResolver.map(pRequestForMapping, key);
                    }
                });

    }

    /**
     * Deactivate this component by closing the resource resolver, unregistering the flusher servlet, and releasing the
     * caches for garbage collection.
     * 
     * @param pCtx
     *            the DS ComponentContext
     */
    protected void deactivate(final ComponentContext pCtx) {
        this.mServletReference.unregister();
        this.mCaches = null;
        this.mResolver.close();
    }

    /**
     * Have the resource resolver actually do the mapping. This should only be used as a backup to the cache.
     * 
     * @param pRequest the request
     * @param pRelPath the path to map
     * @return the mapped path
     */
    private String mapByResolver(final SlingHttpServletRequest pRequest, final String pRelPath) {
        return pRequest.getResourceResolver().map(pRequest, pRelPath);
    }

    /**
     * Map a path, either through the cache or using the request-scoped resource resolved if the cache fails.
     * 
     * @param pSettings
     *            the Settings object corresponding to the current request.
     * @param pRelPath
     *            the relative path to be mapped
     * @return the mapped path
     * 
     */
    String mapPath(final SlingHttpServletRequest pRequest, final String pRelPath) {
        final MappingRequest mappingRequest = new MappingRequest(pRequest);

        Cache<String, String> cache = null;
        if (this.mCaches != null) {
            cache = this.mCaches.get(mappingRequest);
            if (cache == null) {
                final Cache<String, String> newCache = createCache(mappingRequest);
                cache = this.mCaches.putIfAbsent(mappingRequest, newCache);
                if (cache == null) {
                    cache = newCache;
                }

            }
        }

        String dst = null;

        if (cache != null) {
            try {
                dst = cache.get(pRelPath);
            } catch (ExecutionException e) {
                this.mLogger.warn(MSG_CACHE_LOAD_FAILED, e);
                dst = mapByResolver(pRequest, pRelPath);
            } catch (UncheckedExecutionException e) {
                this.mLogger.warn(MSG_CACHE_LOAD_FAILED, e);
                dst = mapByResolver(pRequest, pRelPath);
            }
        } else {
            dst = mapByResolver(pRequest, pRelPath);
        }
        return dst;
    }

    /**
     * Method from RequestRewriter interface which we don't implement.
     */
    public Attributes rewrite(final String pElementName, final Attributes pAttributes,
            final LinkCheckerSettings pSettings) {
        return null;
    }

    /**
     * 
     * @param pLink
     *            the link to be rewritten
     * @param pSettings
     *            the link checker settings for this request
     */
    public String rewriteLink(final Link pLink, final LinkCheckerSettings pSettings) {
        if (!pSettings.isIgnoreInternals() && pLink.isContextRelative()) {
            final String relPath = pLink.getRelUri().getPath();
            // special cases
            for (final String prefix : IGNORED_PREFIXES) {
                if (relPath.startsWith(prefix)) {
                    return new StringBuilder(pSettings.getContextPath()).append(SLASH).append(relPath).toString();
                }
            }

            final String originalPath = new StringBuilder(SLASH).append(relPath).toString();
            final String dst = mapPath(pSettings.getRequest(), originalPath);
            if (!dst.equals(originalPath)) {

                final StringBuilder dstBuilder;
                // Strip off /index.html if it is the last path segment
                if (dst.endsWith(INDEX_HTML_POSTFIX)) {
                    int idx = dst.lastIndexOf(SLASH);
                    dstBuilder = new StringBuilder(dst.substring(0, idx + 1));
                } else {
                    dstBuilder = new StringBuilder(dst);
                }

                // append possible query and fragment to dst
                if (pLink.getRelUri().getRawQuery() != null) {
                    dstBuilder.append(QUESTION_MARK).append(pLink.getRelUri().getRawQuery());
                }
                if (pLink.getRelUri().getRawFragment() != null) {
                    dstBuilder.append(HASH_MARK).append(pLink.getRelUri().getRawFragment());
                }
                return dstBuilder.toString();
            }
        }
        return null;
    }

    /**
     * Scheduled task which outputs cache statistics.
     */
    @Override
    public void run() {
        if (this.mCaches != null) {
            for (Entry<MappingRequest, Cache<String, String>> entry : this.mCaches.entrySet()) {
                this.mLogger.info(MSG_CACHE_STATS, entry.getKey(), entry.getValue().stats());
            }
        }

    }
}
