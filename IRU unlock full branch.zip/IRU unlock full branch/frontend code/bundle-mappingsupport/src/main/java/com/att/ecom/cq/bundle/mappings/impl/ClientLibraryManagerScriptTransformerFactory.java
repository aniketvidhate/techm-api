package com.att.ecom.cq.bundle.mappings.impl;


import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.rewriter.Transformer;
import org.apache.sling.rewriter.TransformerFactory;

/**
 * Rewrite pipeline component factory which rewrites the JSON object used by the JavaScript implementation of the
 * CQClientLibraryManager.
 */
@Component
@Service
@Properties({ @Property(name = "pipeline.type", value = "client-library-script-rewriter", propertyPrivate = true) })
public class ClientLibraryManagerScriptTransformerFactory implements TransformerFactory {

    /** Reference to the LinkRewriter component which is performing caching. */
    @Reference AllPathsLinkRewriter mLinkRewriter;

    /** Instantiate a new instance of the Transformer. */
    public Transformer createTransformer() {
        return new ClientLibraryManagerScriptTransformer(mLinkRewriter);
    }

}
