package com.att.ecom.cq.bundle.mappings.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.google.common.base.Objects;

/**
 * Vastly simplified implementation of HttpServletRequest for use as a cache key to cache path mappings. The Sling
 * ResourceResolver only uses the scheme, serverName, and port when mapping, so this class uses only those values and
 * implements hashCode() and equals() appropriately. This class is generally unusable in any other context.
 */
class MappingRequest implements HttpServletRequest {

    /** Format for a URL. */
    private static final String FMT_URL = "%s://%s:%s";

    /** Protocol name for HTTP 1.1 */
    private static final String HTTP_1_1 = "HTTP/1.1";

    /** The URL scheme for this request. */
    private final String mScheme;

    /** The host name for this request. */
    private final String mServerName;

    /** The port for this request. */
    private final int mServerPort;

    /**
     * Construct a new MappingRequest object based on the provided request.
     * 
     * @param pRequest
     *            the request
     */
    public MappingRequest(final HttpServletRequest pRequest) {
        this.mScheme = pRequest.getScheme();
        this.mServerName = pRequest.getServerName();
        this.mServerPort = pRequest.getServerPort();
    }

    /** Build the hash code for this instance using the scheme, host, and port values. */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + mServerPort;
        result = prime * result + ((mScheme == null) ? 0 : mScheme.hashCode());
        result = prime * result + ((mServerName == null) ? 0 : mServerName.hashCode());
        return result;
    }

    /**
     * Determine object equivalence by comparing the scheme, host, and port values.
     * 
     * @param pObj
     *            the other object
     */
    @Override
    public boolean equals(Object pObj) {
        if (this == pObj)
            return true;
        if (pObj == null)
            return false;
        if (getClass() != pObj.getClass())
            return false;
        MappingRequest other = (MappingRequest) pObj;
        if (mServerPort != other.mServerPort)
            return false;
        if (mScheme == null) {
            if (other.mScheme != null)
                return false;
        } else if (!mScheme.equals(other.mScheme))
            return false;
        if (mServerName == null) {
            if (other.mServerName != null)
                return false;
        } else if (!mServerName.equals(other.mServerName))
            return false;
        return true;
    }

    /** 
     * Produce string representation by regenerating the URL.
     */
    @Override
    public String toString() {
        return Objects.toStringHelper(this).addValue(String.format(FMT_URL, mScheme, mServerName, mServerPort))
                .toString();
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public Object getAttribute(String pName) {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @SuppressWarnings("rawtypes")
    @Override
    public Enumeration getAttributeNames() {
        return Collections.enumeration(Collections.emptySet());
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getCharacterEncoding() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public void setCharacterEncoding(String pEnv) throws UnsupportedEncodingException {
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public int getContentLength() {
        return -1;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getContentType() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public ServletInputStream getInputStream() throws IOException {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getParameter(String pName) {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @SuppressWarnings("rawtypes")
    @Override
    public Enumeration getParameterNames() {
        return Collections.enumeration(Collections.emptySet());
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String[] getParameterValues(String pName) {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @SuppressWarnings("rawtypes")
    @Override
    public Map getParameterMap() {
        return Collections.EMPTY_MAP;
    }

    /** Return a static protocol for HTTP 1.1. */
    @Override
    public String getProtocol() {
        return HTTP_1_1;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getScheme() {
        return mScheme;
    }
    
    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getServerName() {
        return mServerName;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public int getServerPort() {
        return mServerPort;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public BufferedReader getReader() throws IOException {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getRemoteAddr() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getRemoteHost() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public void setAttribute(String pName, Object pObject) {
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public void removeAttribute(String name) {
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public Locale getLocale() {
        return Locale.getDefault();
    }

    /** No-op method from HttpServletRequest interface. */
    @SuppressWarnings("rawtypes")
    @Override
    public Enumeration getLocales() {
        return Collections.enumeration(Collections.singleton(Locale.getDefault()));
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public boolean isSecure() {
        return false;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public RequestDispatcher getRequestDispatcher(String pPath) {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getRealPath(String pPath) {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public int getRemotePort() {
        return -1;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getLocalName() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getLocalAddr() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public int getLocalPort() {
        return -1;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getAuthType() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public Cookie[] getCookies() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public long getDateHeader(String pName) {
        return -1;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getHeader(String pName) {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Enumeration getHeaders(String pName) {
        return Collections.enumeration(Collections.EMPTY_SET);
    }

    /** No-op method from HttpServletRequest interface. */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public Enumeration getHeaderNames() {
        return Collections.enumeration(Collections.EMPTY_SET);
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public int getIntHeader(String pName) {
        return -1;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getMethod() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getPathInfo() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getPathTranslated() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getContextPath() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getQueryString() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getRemoteUser() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public boolean isUserInRole(String pRole) {
        return false;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public Principal getUserPrincipal() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getRequestedSessionId() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getRequestURI() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public StringBuffer getRequestURL() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public String getServletPath() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public HttpSession getSession(boolean pCreate) {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public HttpSession getSession() {
        return null;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public boolean isRequestedSessionIdValid() {
        return false;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public boolean isRequestedSessionIdFromCookie() {
        return false;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public boolean isRequestedSessionIdFromURL() {
        return false;
    }

    /** No-op method from HttpServletRequest interface. */
    @Override
    public boolean isRequestedSessionIdFromUrl() {
        return false;
    }

}
