package com.att.ecom.cq.bundle.mappings.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.jcr.Node;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.SimpleCredentials;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.io.IOUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Modified;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.commons.osgi.OsgiUtil;

import com.day.cq.replication.AgentConfig;
import com.day.cq.replication.ContentBuilder;
import com.day.cq.replication.ReplicationAction;
import com.day.cq.replication.ReplicationActionType;
import com.day.cq.replication.ReplicationContent;
import com.day.cq.replication.ReplicationContentFactory;
import com.day.cq.replication.ReplicationException;
import com.day.cq.replication.ReplicationLog;
import com.day.text.GlobPattern;
import com.day.text.Text;

/**
 * Static content builder producing content that will be delivered by the <code>StaticTransportHandler</code> which will
 * used the mapped path when building the ZIP file required by the <code>StaticTransportHandler</code>.
 */
@Component(metatype = true, label = "Mapped Static Content Builder", description = "Static content builder which uses the mapped path.")
@Service()
public class MappedStaticContentBuilder implements ContentBuilder {

    /**
     * Defines a rule when and what to process for an activated node.
     */
    private static class Rule {

        /**
         * The pattern to be replaced.
         */
        private final GlobPattern mPattern;

        /**
         * The replacement text.
         */
        private final String mReplacement;

        private Rule(final String pPattern, final String pReplacement) {
            this.mPattern = new GlobPattern(pPattern);
            this.mReplacement = pReplacement;
        }

        /**
         * Replace the input with the replacement defined. If the input matches the pattern, replacement will be
         * returned with variables replaced.
         *
         * @param pInput
         *            input
         * @return replacement or <code>null</code> if the input does not match
         */
        public String replace(final String pInput) {
            if (this.mPattern.matches(pInput)) {
                Properties p = new Properties();
                p.setProperty(PROP_PATH, pInput);
                return Text.replaceVariables(p, this.mReplacement, false);
            }
            return null;
        }

        /** toString method to output a more informative message. */
        @Override
        public String toString() {
            return this.mPattern.toString() + " -> " + this.mReplacement;
        }
    }

    /** The Credentials attribute which contains the login token. */
    private static final String ATTR_TOKEN = ".token";

    /** The authentication info property used to create a ResourceResovler wrapping a pre-existing Sesssion. */
    private static final String AUTHENTICATION_INFO_SESSION = "user.jcr.session";

    /** The blank string. */
    private static final String BLANK = "";

    /** The colon character. */
    private static final String COLON = ":";

    /** Default context path. */
    private static final String DEFAULT_CONTEXT_PATH = BLANK;

    /** Default host. */
    private static final String DEFAULT_HOST = "localhost";

    /** Default port number. */
    private static final int DEFAULT_PORT = 4502;

    /** Zip file extension. */
    private static final String EXTENSION_ZIP = ".zip";

    /** Formatted error message when content fetch failed. */
    private static final String FMT_FETCH_CONTENT_ERROR = "Unable to fetch content from %s :  %s";

    /** Formatted error message when a rule is invalid. */
    private static final String FMT_INVALID_RULE = "Rule invalid: %s, should consist of two elements separated by spaces.";

    /** Formatted error message when content serialization failed. */
    private static final String FMT_IO_ERROR_DURING_SERIALIZATION = "I/O error occurred during serialization of page %s";

    /** Format for setting the login token cookie. */
    private static final String FMT_LOGIN_TOKEN_COOKIE = "login-token=%s";

    /** Format for the login cookie value. */
    private static final String FMT_LOGIN_TOKEN_COOKIE_VALUE = "%s:%s:%s";

    /** Formatted log message when no rule matched a path. */
    private static final String FMT_NO_RULE_MATCH = "No rule did match for node path %s.";

    /** Formatted log message for when no rules were found in the agent configuration. */
    private static final String FMT_NO_RULES = "No rules definition found in agent %s";

    /** Formatted log message when there are no valid rules. */
    private static final String FMT_NO_VALID_RULE = "Rules definition in agent %s did not contain a valid rule";

    /** Formatted error message if a repository exception occurs during serialization. */
    private static final String FMT_REPOSITORY_ERROR_DURING_SERIALIZATION = "Repository exception occurred during serialization of page %s.";

    /** Formatted message when checking a rule. */
    private static final String FMT_RULE_CHECK = "Checking rule (%s) against node path %s";

    /** Formatted message when a rule doesn't match. */
    private static final String FMT_RULE_DIDNT_MATCH = "Rule (%s) did not match.";

    /** Formatted error message when the retrieval fails. */
    private static final String FMT_UNABLE_TO_RETRIEVE_CONTENT = "Unable to retrieve content: %s";

    /** Cookie header name. */
    private static final String HEADER_COOKIE = "Cookie";

    /** HTTP URL Prefix. */
    private static final String HTTP_URL_PREFIX = "http://";

    /** Error message when the impersonated session can't be created. */
    private static final String MSG_CANT_IMPERSONATE = "Unable to impersonate user";

    /** Error message when the resource resolver is unable to be created. */
    private static final String MSG_ERROR_CREATING_RESOURCE_RESOLVER = "Unable to create resource resolver for session";

    /** Error message when an IO Exception occurs during serialization. */
    private static final String MSG_IO_ERROR_DURING_SERIALIZATION = "I/O error during serialization";

    /** Error message when the agent configuration isn't available. */
    private static final String MSG_NO_AGENT_CONFIG = "No agent configuration found.";

    /** Error message when the replication log isn't available. */
    private static final String MSG_NO_REPLICATION_LOG = "No replication log found.";

    /** Error message when the repository ID can't be found. */
    private static final String MSG_NO_REPOSITORY_ID = "Unable to obtain repository id.";

    /** Error message when the serialization fails due to a repository exception. */
    private static final String MSG_REPOSITORY_ERROR_DURING_SERIALIZATION = "RepositoryException during serialization";

    /** The log message when a page is being requested */
    private static final String MSG_REQUESTING = "Requesting %s";

    /** Mime type: application/zip */
    private static final String MT_ZIP = "application/zip";

    /**
     * Name of this content builder.
     */
    @Property(name = "name", propertyPrivate = true)
    private static final String NAME = "mapped-static";

    /** Context Path */
    @Property(value = DEFAULT_CONTEXT_PATH, label = "Context Path", description = "Context Path used to retrieve content")
    private static final String PROP_CONTEXT_PATH = "contextPath";

    /** The configuration definition property name. */
    private static final String PROP_DEFINITION = "definition";

    /** Host */
    @Property(value = DEFAULT_HOST, label = "Host", description = "Host name used to retrieve content.")
    private static final String PROP_HOST = "host";

    private static final String PROP_PATH = "path";

    /** Port number */
    @Property(intValue = DEFAULT_PORT, label = "Port", description = "Port number used to retrieve content.")
    private static final String PROP_PORT = "port";

    /** The delimiter to append a query string to an URL. */
    private static final String QUERY_STRING_DELIMITER = "?";

    /** The primary type property. */
    private static final String PROPERTY_PRIMARY_TYPE = "jcr:primaryType";

    /** The sling ordered folder type */
    private static final String NODE_TYPE_SLING_ORDEREDFOLDER = "sling:OrderedFolder";

    /** The PAGE NODE type */
    private static final String NODE_TYPE_CQ_PAGE = "cq:Page";

    /** The DAM ASSET NODE type */
    private static final String NODE_TYPE_DAM_ASSET = "dam:Asset";


    /**
     * The name of the repository descriptor providing the repository cluster ID of the cluster the bound repository is
     * a node of.
     */
    private static final String REPO_DESC_CLUSTER_ID = "crx.cluster.id";

    /**
     * The name of the repository descriptor providing the ID of the repository instance.
     */
    private static final String REPO_DESC_ID = "crx.repository.systemid";

    /** The prefix for temporary files. */
    private static final String TEMP_FILE_PREFIX = "cq5";

    /** Descriptive title of this content builder */
    private static final String TITLE = "Static Content Builder";

    /** The context path to use for the http request. */
    private String mContextPath;

    /** The http client. */
    private HttpClient mHttpClient;

    /** The repository instance. */
    @Reference
    private Repository mRepository;

    /** Repository ID. */
    private String mRepositoryId;

    /** The resource resolver factory instance. */
    @Reference
    private ResourceResolverFactory mResourceResolverFactory;

    /** The server to use for the http request. */
    private String mServerHost;

    /** The port to use for the http request. */
    private int mServerPort;

    /** Default user. */
    private static final String DEFAULT_USERID = "";

    /** Default password. */
    private static final String DEFAULT_PASSWORD = "";

    /** Map of login tokens, indexed by user id */
    private final Map<String, String> mTokenMap = new HashMap<String, String>();

    /** User Id */
    @Property(value = DEFAULT_USERID, label = "User ID", description = "User ID")
    private static final String PROP_USER_ID = "userid";

    /** Password */
    @Property(value = DEFAULT_PASSWORD, label = "Password", description = "Password")
    private static final String PROP_PASSWORD = "_";

    /** The userid for the http request. */
    private String mUserId;

    /** The password for the http request. */
    private String mPassword;

    /**
     * Activate this component by creating an HTTP Client and reading configuration data.
     *
     * @param pConfiguration the component configuration
     */
    @Activate
    private void activate(final Map<String, Object> pConfiguration) {
        MultiThreadedHttpConnectionManager conMgr = new MultiThreadedHttpConnectionManager();
        this.mHttpClient = new HttpClient(conMgr);

        this.mServerHost = OsgiUtil.toString(pConfiguration.get(PROP_HOST), DEFAULT_HOST);
        this.mServerPort = OsgiUtil.toInteger(pConfiguration.get(PROP_PORT), DEFAULT_PORT);
        this.mContextPath = OsgiUtil.toString(pConfiguration.get(PROP_CONTEXT_PATH), DEFAULT_CONTEXT_PATH);

        this.mUserId = OsgiUtil.toString(pConfiguration.get(PROP_USER_ID), DEFAULT_USERID);
        this.mPassword = OsgiUtil.toString(pConfiguration.get(PROP_PASSWORD), DEFAULT_PASSWORD);

        this.mRepositoryId = this.mRepository.getDescriptor(REPO_DESC_CLUSTER_ID);
        if (this.mRepositoryId == null) {
            this.mRepositoryId = this.mRepository.getDescriptor(REPO_DESC_ID);
        }
    }


    /**
     * Create replication content for a given node.
     *
     * @param pRules
     *            rules to apply
     * @param pFactory
     *            factory used to create content
     * @param pNode
     *            replicated node
     *
     * @return replication content
     *
     * @throws ReplicationException
     *             if a replication failure occurs
     * @throws RepositoryException
     *             if a repository failure occurs
     * @throws IOException
     *             if an I/O error occurs
     */
    private ReplicationContent create(final Rule[] pRules, final ReplicationContentFactory pFactory, final Node pNode, final ReplicationLog pLog)
            throws ReplicationException, RepositoryException, IOException {

        Map<String, Object> authInfo = Collections.singletonMap(AUTHENTICATION_INFO_SESSION, (Object) pNode.getSession());
        ResourceResolver resourceResolver = null;
        try {
            resourceResolver = this.mResourceResolverFactory.getResourceResolver(authInfo);
        } catch (LoginException e) {
            pLog.warn(MSG_ERROR_CREATING_RESOURCE_RESOLVER, e);
        }

        HashMap<String, byte[]> binaries = new HashMap<String, byte[]>();
        String path = pNode.getPath();

        for (Rule rule : pRules) {
            pLog.debug(String.format(FMT_RULE_CHECK, rule, path));
            String urlPath = rule.replace(path);
            if (urlPath == null) {
                pLog.debug(String.format(FMT_RULE_DIDNT_MATCH, rule));
                continue;
            }

            if (resourceResolver != null) {
                urlPath = resourceResolver.map(urlPath);
            }
            byte[] data;

            try {
                data = getContent(urlPath, pNode.getSession(), pLog);
            } catch (ReplicationException e) {
                pLog.warn(String.format(FMT_UNABLE_TO_RETRIEVE_CONTENT, e.getMessage()));
                continue;
            }
            int query = urlPath.indexOf('?');
            if (query != -1) {
                urlPath = urlPath.substring(0, query);
            }
            binaries.put(urlPath, data);
        }

        if (binaries.size() == 0) {
            pLog.debug(String.format(FMT_NO_RULE_MATCH, path));
            return ReplicationContent.VOID;
        }


        File file = createZip(binaries);

        try {

            return pFactory.create(MT_ZIP, file, true);

        } catch (IOException e) {
            file.delete();
            throw new ReplicationException(e);
        }
    }

    /**
     * Create the ReplicationContent.
     *
     * @param pSession the JCR Session used to access the node
     * @param pAction the replication action requested
     * @param pFactory the factory used to create content
     */
    public ReplicationContent create(final Session pSession, final ReplicationAction pAction, final ReplicationContentFactory pFactory)
            throws ReplicationException {

        if (pAction.getType() != ReplicationActionType.ACTIVATE) {
            return ReplicationContent.VOID;
        }

        AgentConfig config = pAction.getConfig();
        if (config == null) {
            throw new ReplicationException(MSG_NO_AGENT_CONFIG);
        }
        ReplicationLog log = pAction.getLog();
        if (log == null) {
            throw new ReplicationException(MSG_NO_REPLICATION_LOG);
        }
        String s = config.getProperties().get(PROP_DEFINITION, String.class);
        if (s == null || s.length() == 0) {
            log.info(String.format(FMT_NO_RULES, config.getName()));
            return ReplicationContent.VOID;
        }
        Rule[] rules = parseRules(s, log);
        if (rules.length == 0) {
            log.info(String.format(FMT_NO_VALID_RULE, config.getName()));
            return ReplicationContent.VOID;
        }

        try {
            Node node = pSession.getNode(pAction.getPath());
            String nodePrimaryType = node.getProperty(PROPERTY_PRIMARY_TYPE).getString();
            if(!nodePrimaryType.equals(NODE_TYPE_CQ_PAGE) && !nodePrimaryType.equals(NODE_TYPE_DAM_ASSET)) {
                return ReplicationContent.VOID;
            }
            return create(rules, pFactory, node, log);
        } catch (RepositoryException e) {
            log.error(String.format(FMT_REPOSITORY_ERROR_DURING_SERIALIZATION, pAction.getPath()));
            throw new ReplicationException(MSG_REPOSITORY_ERROR_DURING_SERIALIZATION, e);
        } catch (IOException e) {
            log.error(String.format(FMT_IO_ERROR_DURING_SERIALIZATION, pAction.getPath()));
            throw new ReplicationException(MSG_IO_ERROR_DURING_SERIALIZATION, e);
        }
    }

    /**
     * Create a token cookie for the session given.
     *
     * @param pSession
     *            session
     * @return token cookie, in the format
     *         <tt>login-token=<i>repository-id</i>:<i>token-id</i>:<i>workspace name</i></tt>
     * @throws ReplicationException
     *             if the repository id can not be determined or if accessing the repository fails
     */
    private String createTokenCookie(final Session pSession) throws ReplicationException {
        if (this.mRepositoryId == null) {
            throw new ReplicationException(MSG_NO_REPOSITORY_ID);
        }

        Session s1 = null;

        try {
            SimpleCredentials c = new SimpleCredentials(pSession.getUserID(), new char[0]);
            c.setAttribute(ATTR_TOKEN, BLANK);

            s1 = pSession.impersonate(c);

            String value = Text.escape(String.format(FMT_LOGIN_TOKEN_COOKIE_VALUE, this.mRepositoryId, c.getAttribute(ATTR_TOKEN), pSession
                    .getWorkspace().getName()));
            return String.format(FMT_LOGIN_TOKEN_COOKIE, value);
        } catch (RepositoryException e) {
            throw new ReplicationException(MSG_CANT_IMPERSONATE, e);
        } finally {
            if (s1 != null)
                s1.logout();
        }
    }

    /**
     * Create a zip consisting of all files given in a map, where the map's keys will be used as zip entry names.
     *
     * @param pFiles
     *            map of files
     * @return a zip
     * @throws IOException
     *             if an I/O error occurs
     */
    private File createZip(final Map<String, byte[]> pFiles) throws IOException {
        File tmpFile = File.createTempFile(TEMP_FILE_PREFIX, EXTENSION_ZIP);
        ZipOutputStream out = null;
        boolean successful = false;

        try {
            out = new ZipOutputStream(new FileOutputStream(tmpFile));
            for (Map.Entry<String, byte[]> entry : pFiles.entrySet()) {
                out.putNextEntry(new ZipEntry(entry.getKey()));
                out.write(entry.getValue());
            }
            successful = true;
            return tmpFile;
        } finally {
            IOUtils.closeQuietly(out);
            if (!successful) {
                tmpFile.delete();
            }
        }
    }

    /**
     * Deactivate this component by clearing out the token map and the HTTP client.
     *
     * @param pConfiguration the component configuration
     */
    @Deactivate
    private void deactivate(final Map<String, Object> pConfiguration) {
        if (this.mHttpClient != null) {
            ((MultiThreadedHttpConnectionManager) this.mHttpClient.getHttpConnectionManager()).shutdown();
            this.mHttpClient = null;
        }
        this.mTokenMap.clear();
    }

    /**
     * Return the target of a HTTP request as a byte array
     *
     * @param pPath
     *            path to request; this may contain a query string
     * @param pLog
     *            replication log
     * @return page content as byte array
     *
     * @throws RepositoryException
     *             if a repository error occurs
     * @throws ReplicationException
     *             if a replication error occurs
     */
    private byte[] getContent(final String pPath, final Session pSession, final ReplicationLog pLog) throws RepositoryException,
            ReplicationException {

        StringBuilder sb = new StringBuilder(HTTP_URL_PREFIX);
        sb.append(this.mServerHost);
        if (this.mServerPort != 80) {
            sb.append(COLON).append(this.mServerPort);
        }
        sb.append(this.mContextPath);

        /* escape illegal characters in path, but spare query string from escaping */
        int query = pPath.indexOf('?');
        if (query != -1) {
            sb.append(Text.escapePath(pPath.substring(0, query)));
            sb.append(QUERY_STRING_DELIMITER);
            sb.append(pPath.substring(query + 1));
        } else {
            sb.append(Text.escapePath(pPath));
        }

        String url = sb.toString();
        pLog.info("The url being replicated is:"+String.format(MSG_REQUESTING, url));
        pLog.debug(String.format(MSG_REQUESTING, url));

        boolean create = false;

        for (;;) {
            GetMethod getReq = new GetMethod(url);
            getReq.setFollowRedirects(true);
            getReq.setRequestHeader(HEADER_COOKIE, getOrCreateTokenCookie(pSession, create));

            //Pass Authentication headers in the Request
            String userPassword = this.mUserId+":"+this.mPassword;
            String basicAuth = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(userPassword.getBytes());
            getReq.setRequestHeader("Authorization", basicAuth);

            try {
                int status = mHttpClient.executeMethod(getReq);
                if (status == 200) {
                    return getReq.getResponseBody();
                } else if (status == 404) {
                    if (!create) {
                        /* retry with a freshly created token cookie */
                        create = true;
                        continue;
                    }
                }
                throw new ReplicationException(String.format(FMT_FETCH_CONTENT_ERROR, url, status));
            } catch (HttpException e) {
                throw new ReplicationException(e);
            } catch (IOException e) {
                throw new ReplicationException(e);
            }
        }
    }

    /**
     * Return the name of this content builder.
     *
     * @return name
     */
    public String getName() {
        return NAME;
    }

    /**
     * Return a token cookie for the session given, creating one if necessary or requested.
     *
     * @param pSession
     *            session
     * @param pCreate
     *            <code>true</code> to create and store a token cookie regardless of whether a stored one is available
     * @return token cookie
     * @throws ReplicationException
     *             if an error occurs
     */
    private String getOrCreateTokenCookie(final Session pSession, final boolean pCreate) throws ReplicationException {

        String tokenCookie;

        if (!pCreate) {
            synchronized (this.mTokenMap) {
                tokenCookie = this.mTokenMap.get(pSession.getUserID());
                if (tokenCookie != null) {
                    return tokenCookie;
                }

            }
        }
        tokenCookie = createTokenCookie(pSession);

        synchronized (this.mTokenMap) {
            this.mTokenMap.put(pSession.getUserID(), tokenCookie);
        }
        return tokenCookie;
    }

    /**
     * Return the title of this content builder.
     *
     * @return title
     */
    public String getTitle() {
        return TITLE;
    }

    /**
     * Notification method for when this component's configuration has been modified.
     *
     * @param pConfiguration the component configuration
     */
    @SuppressWarnings("unused")
    @Modified
    private void modified(final Map<String, Object> pConfiguration) {
        deactivate(pConfiguration);
        activate(pConfiguration);
    }

    /**
     * Parse rules. Every line in the input contains a pattern and a replacement, which are again separated by one or
     * more spaces.
     *
     * @param pInput
     *            input string
     * @return array of rules
     */
    private Rule[] parseRules(final String pInput, final ReplicationLog pLog) {
        final ArrayList<Rule> rules = new ArrayList<Rule>();

        final String[] lines = Text.explode(pInput, '\n');
        for (String line : lines) {
            String[] rule = Text.explode(line, ' ');
            if (rule.length != 2) {
                /* skip invalid rule */
                pLog.warn(String.format(FMT_INVALID_RULE, line));
                continue;
            }
            rules.add(new Rule(rule[0], rule[1]));
        }
        final Rule[] result = new Rule[rules.size()];
        rules.toArray(result);
        return result;
    }
}