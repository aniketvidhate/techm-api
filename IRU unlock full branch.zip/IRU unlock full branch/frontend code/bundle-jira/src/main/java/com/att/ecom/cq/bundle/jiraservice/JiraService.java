package com.att.ecom.cq.bundle.jiraservice;

import com.att.ecom.cq.jirasoapservicev2.JiraSoapService;
import com.att.ecom.cq.jirasoapservicev2.JiraSoapServiceServiceLocator;
import com.att.ecom.cq.jirasoapservicev2.RemoteComponent;
import com.att.ecom.cq.jirasoapservicev2.RemoteIssue;
import com.att.ecom.cq.jirasoapservicev2.RemoteVersion;

import com.att.ecom.cq.jirasoapservicev2.RemoteCustomFieldValue;
import java.util.Arrays;
import java.util.Calendar;

/**
 * @author bt7519
 * @date 5/18/11 3:21 PM
 */

public class JiraService {
// ------------------------------ FIELDS ------------------------------

    private JiraSoapService jiraSoapService;
    private String token;

// -------------------------- OTHER METHODS --------------------------

    public RemoteIssue createIssue(String projectKey, String issueTypeId, String summaryName, String priorityId, String componentId, String versionId) throws JiraServiceException {
        // Create the issue
        final RemoteIssue issue = new RemoteIssue();
        
        issue.setProject(projectKey);
        issue.setType(issueTypeId);

        issue.setSummary(summaryName);
        issue.setPriority(priorityId);
        issue.setDuedate(Calendar.getInstance());
        issue.setAssignee("rc8891");
        

        // Add remote compoments
        RemoteComponent component = new RemoteComponent();
        component.setId(componentId);
        issue.setComponents(new RemoteComponent[]{component});
        System.out.println("Setting the desc");
        issue.setDescription("Setting the Test Description");
        
        // Add remote versions
        RemoteVersion version = new RemoteVersion();
        version.setId(versionId);

        RemoteVersion[] remoteVersions = new RemoteVersion[]{version};
        issue.setFixVersions(remoteVersions);

        // Add custom fields
        RemoteCustomFieldValue customFieldValue = new RemoteCustomFieldValue("customfield_10014", "", new String[]{"Severe"});
        RemoteCustomFieldValue customFieldValue2 = new RemoteCustomFieldValue("customfield_10015", "", new String[]{"CQ "});
        RemoteCustomFieldValue customFieldValue3 = new RemoteCustomFieldValue("customfield_10100", "", new String[]{"TeamSite"});        
        RemoteCustomFieldValue customFieldValue4 = new RemoteCustomFieldValue("customfield_10062", "", new String[]{"IE 6.0"});
        
        
//        RemoteCustomFieldValue customFieldValue = new RemoteCustomFieldValue(CUSTOM_FIELD_KEY_1, "", new String[]{CUSTOM_FIELD_VALUE_1});
//
//        RemoteCustomFieldValue customFieldValue2 = new RemoteCustomFieldValue(CUSTOM_FIELD_KEY_2, "", new String[]{CUSTOM_FIELD_VALUE_2});
//
        RemoteCustomFieldValue[] customFieldValues = new RemoteCustomFieldValue[]{customFieldValue, customFieldValue2,customFieldValue3,customFieldValue4};
        issue.setCustomFieldValues(customFieldValues);

        // Run the create issue code
        RemoteIssue returnedIssue = null;
        try {
            returnedIssue = doWithTCCL(new Command<RemoteIssue>() {
            	public RemoteIssue execute() throws Exception {
            		return jiraSoapService.createIssue(token, issue);
            	}
			});
        } catch (Exception e) {
            throw new JiraServiceException(e);
        }
        final String issueKey = returnedIssue.getKey();

        System.out.println("\n #######################  Successfully created issue " + issueKey+"#####################################################################\n");

        return returnedIssue;
    }

// --------------------------- main() method ---------------------------

    public static void main(String[] args) throws JiraServiceException {
        JiraService service = new JiraService();
        service.setupService(args[0], args[1]);

        RemoteIssue issue = service.lookupIssue("CMS-78");
        System.out.println(service.formatIssue(issue));
    }

    public void setupService(final String username, final String password) throws JiraServiceException {
    	if (jiraSoapService == null || token == null) {
            final JiraSoapServiceServiceLocator serviceLocator = new JiraSoapServiceServiceLocator();
            try {
            	doWithTCCL(new Command<Void>() {
					public Void execute() throws Exception {
		                jiraSoapService = serviceLocator.getJirasoapserviceV2();
		                token =  jiraSoapService.login(username, password);
		                return null;
					}
				});
            } catch (Exception e) {
                throw new JiraServiceException(e);
            }
        }
    }

    public RemoteIssue lookupIssue(final String issueKey) throws JiraServiceException {
    	try {
    		return doWithTCCL(new Command<RemoteIssue>() {
    			public RemoteIssue execute() throws Exception {
    				return jiraSoapService.getIssue(token, issueKey);
    			}
			});
        } catch (Exception e) {
            throw new JiraServiceException(e);
        }
    }
    
    private <T> T doWithTCCL(Command<T> cmd) throws Exception {
    	ClassLoader currentTCCL = Thread.currentThread().getContextClassLoader();
    	Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());
    	try {
    		return cmd.execute();
    	} finally {
    		Thread.currentThread().setContextClassLoader(currentTCCL);
    	}
    }
    
    private interface Command<T> {
    	T execute() throws Exception;
    }

    public String formatIssue(RemoteIssue issue) {
        return "RemoteIssue{" +
                "\t affectsVersions=" + (issue.getAffectsVersions() == null ? null : Arrays.asList(issue.getAffectsVersions())) + ",\n" +
                "\t assignee='" + issue.getAssignee() + '\'' + ",\n" +
                "\t attachmentNames=" + (issue.getAttachmentNames() == null ? null : Arrays.asList(issue.getAttachmentNames())) + ",\n" +
                "\t components=" + (issue.getComponents() == null ? null : Arrays.asList(issue.getComponents())) + ",\n" +
                "\t created=" + issue.getCreated() + ",\n" +
                "\t customFieldValues=" + (issue.getCustomFieldValues() == null ? null : Arrays.asList(issue.getCustomFieldValues())) + ",\n" +
                "\t description='" + issue.getDescription() + '\'' + ",\n" +
                "\t duedate=" + issue.getDuedate() + ",\n" +
                "\t environment='" + issue.getEnvironment() + '\'' + ",\n" +
                "\t fixVersions=" + (issue.getFixVersions() == null ? null : Arrays.asList(issue.getFixVersions())) + ",\n" +
                "\t key='" + issue.getKey() + '\'' + ",\n" +
                "\t priority='" + issue.getPriority() + '\'' + ",\n" +
                "\t project='" + issue.getProject() + '\'' + ",\n" +
                "\t reporter='" + issue.getReporter() + '\'' + ",\n" +
                "\t resolution='" + issue.getResolution() + '\'' + ",\n" +
                "\t status='" + issue.getStatus() + '\'' + ",\n" +
                "\t summary='" + issue.getSummary() + '\'' + ",\n" +
                "\t type='" + issue.getType() + '\'' + ",\n" +
                "\t updated=" + issue.getUpdated() + ",\n" +
                "\t votes=" + issue.getVotes() + ",\n" +
                '}';
    }
}
