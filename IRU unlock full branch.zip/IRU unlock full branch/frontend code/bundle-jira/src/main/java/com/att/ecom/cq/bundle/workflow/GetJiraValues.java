package com.att.ecom.cq.bundle.workflow;

import java.util.Dictionary;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.HistoryItem;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.exec.filter.WorkItemFilter;
import com.day.cq.workflow.metadata.MetaDataMap;
import com.day.cq.workflow.model.WorkflowModel;
import com.day.cq.workflow.model.WorkflowNode;

/**
 * Sample workflow process that logs arguments into the logfile.
 */
@Component
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "Logger process implementation."),
        @Property(name = Constants.SERVICE_VENDOR, value = "Adobe"),
        @Property(name = "process.label", value = "Get Jira Values")})
public class GetJiraValues implements WorkflowProcess {

   private static final Logger log = LoggerFactory.getLogger(GetJiraValues.class);

    public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) throws WorkflowException {
    	
    	String workflowid = item.getId();
    	WorkflowData wfdata = item.getWorkflowData();
    	String payloadtype = wfdata.getPayloadType();   	
    	 
    	 Workflow workflow = item.getWorkflow();
    	 String wfid = workflow.getId();
    	 String workflowinitiator  = workflow.getInitiator();
    	 WorkflowModel workflowmodel  = workflow.getWorkflowModel();
    	 String workflowmodeltitle  = workflowmodel.getTitle();    	 
    	 List<WorkflowNode> workflownodes = workflowmodel.getNodes();
    	 
    	 
    	 log.info("################################   ***********   ---> wfid: {}", wfid);
    	 log.info("################################   ***********   ---> workflowinitiator: {}", workflowinitiator);
    	 log.info("################################   ***********   ---> workflowmodel: {}", workflowmodel);
    	 log.info("################################   ***********   ---> workflowmodeltitle: {}", workflowmodeltitle);

    	 
    	 
//    	 List<WorkItem> historyitems = item.getWorkflow().getWorkItems() ;
    	 List<HistoryItem> historyitems = session.getHistory(item.getWorkflow()) ;
    	 
    	HistoryItem lastHistoryItem = historyitems.get(historyitems.size() -1);
    	 
    	 
//    	 for (Iterator<HistoryItem> historyItr = historyitems.iterator(); historyItr.hasNext();) {
//			HistoryItem historyItem = (HistoryItem) historyItr.next();
//			if(historyItem.getNextHistryItem() != null) continue ;
//			else{
//				HistoryItem lastHistoryItem = historyItem.getNextHistryItem();
				WorkItem workItem = lastHistoryItem.getWorkItem();
				MetaDataMap workItemMetaDataMap = workItem.getMetaDataMap();
				Set<String> keySet = workItemMetaDataMap.keySet();
				for (Iterator<String> keySetItr = keySet.iterator(); keySetItr.hasNext();) {
					String key = (String) keySetItr.next();
					log.info("Key:"+key+" ------------------------------->>>   "+workItemMetaDataMap.get(key,""));
//				}
//			
//		}
//    	 while(it.hasNext())
//         {
//    		 HistoryItem historyitem =(HistoryItem)it.next();
//    		 historyitem.
//    		 WorkItem  eachworkitem = historyitem.getWorkItem();
//    		 String eachworkitemid = eachworkitem.getId();
//    		 log.info("################################   ***********   ---> eachworkitemid: {}", eachworkitemid);
//    		 MetaDataMap eachargs = eachworkitem.getMetaDataMap();
//    		 String archieved = eachargs.get("archived", "not find");
//    		 log.info("################################   ***********   ---> archieved: {}", archieved);
//    		 String jiraid = eachargs.get("jiraid", "");
//    		 if(jiraid.length() > 0){
//    			 log.info("################################   ***********   ---> jiraid: {}", jiraid);
//    		 }    		 
//    		 String jiraauthor = eachargs.get("jiraAuthor", "");
//    		 if(jiraauthor.length() > 0){
//    			 log.info("################################   ***********   ---> jiraauthor: {}", jiraauthor);
//    		 }
//    		 String jiraasignee = eachargs.get("jiraasignee", "");
//    		 if(jiraauthor.length() > 0){
//    			 log.info("################################   ***********   ---> jiraasignee: {}", jiraasignee);
//    		 }
//
//    		 String jiracomment = eachargs.get("jiracomment", "");
//    		 if(jiracomment.length() > 0){
//    			 log.info("################################   ***********   ---> jiracomment: {}", jiracomment);
//    		 }

    		 
         }
    	 
        //String jiraId = args.get("jiraId", "not set");
        //String jiraAuthor  = args.get("jiraAuthor", "not set");

       // log.info("---> jiraId: {}", jiraId);
       // log.info("---> jiraAuthor: {}", jiraAuthor);
        log.info("################################   ***********   ---> workflowid: {}", workflowid);
        log.info("################################   ***********   ---> payloadtype: {}", payloadtype);
    }
}