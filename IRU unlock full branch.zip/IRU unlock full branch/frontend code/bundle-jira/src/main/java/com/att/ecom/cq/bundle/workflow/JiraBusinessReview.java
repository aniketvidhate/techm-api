package com.att.ecom.cq.bundle.workflow;


import com.att.ecom.cq.bundle.jiraservice.JiraProgress;
import com.att.ecom.cq.jirasoapservicev2.RemoteIssue;
import com.att.ecom.cq.bundle.jiraservice.JiraServiceException;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import com.day.cq.workflow.exec.HistoryItem;
import com.day.cq.workflow.model.WorkflowModel;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.day.cq.workflow.model.WorkflowNode;
import com.day.cq.workflow.model.WorkflowTransition;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import java.util.Arrays;
import java.util.List;
import java.util.Iterator;

/**
 * Sample workflow process that logs arguments into the logfile.
 */
@Component
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "Jira Status to Business Review"),
        @Property(name = Constants.SERVICE_VENDOR, value = "Adobe"),
        @Property(name = "process.label", value = "Jira Status to Business Review")})
public class JiraBusinessReview implements WorkflowProcess {

   private static final Logger log = LoggerFactory.getLogger(JiraBusinessReview.class);

    public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) throws WorkflowException {
    	String jiraAction="411";
    	String jiraId="";
    	String comments="Changing Status to Business Review from CQ workflow";
    	String assignee ="rx1755";
    	log.info("########################################################### item: {}", item);
    	WorkflowNode currentWorkflowNode = item.getNode();
    	String currentWorkItemId = item.getId();
    	log.info("########################################################### currentWorkItemId: {}", currentWorkItemId);
    	String currentNodeWorkItemNodeId = currentWorkflowNode.getId();
    	List<WorkflowTransition> currntItemWorkflowTransitions = currentWorkflowNode.getTransitions();
    	Iterator transitions = currntItemWorkflowTransitions.iterator();
    	while (transitions.hasNext()){
    		WorkflowTransition currntItemWorkflowTransition = (WorkflowTransition)transitions.next();
    		WorkflowNode fromWorkflowNode = currntItemWorkflowTransition.getFrom();
    		log.info("########################################################### fromWorkflowNode: {}", fromWorkflowNode);
    		String fromWorkflowNodeId = fromWorkflowNode.getId();
    		String fromWorkflowNodeType = fromWorkflowNode.getType();
    		log.info("########################################################### fromWorkflowNodeId: {}", fromWorkflowNodeId);
    		log.info("########################################################### fromWorkflowNodeType: {}", fromWorkflowNodeType);
    	}
    	
    	
    	log.info("########################################################### currentNodeWorkItemNodeId: {}", currentNodeWorkItemNodeId);
    	
    	List<HistoryItem> historyitems = session.getHistory(item.getWorkflow()) ;
    	Iterator it=historyitems.iterator();
   	 while(it.hasNext())
        {
			 HistoryItem historyitem =(HistoryItem)it.next();
			 WorkItem  eachworkitem = historyitem.getWorkItem();
			 String eachworkitemid = eachworkitem.getId();
			 WorkflowNode workflownode = eachworkitem.getNode();
			 
			log.info("########################################################### workflownode.getId: {}", workflownode.getId());
			log.info("########################################################### workflownode.getDescription: {}", workflownode.getDescription());
			log.info("########################################################### workflownode.getTitle: {}", workflownode.getTitle());
			log.info("########################################################### workflownode.getType: {}", workflownode.getType());
			log.info("########################################################### eachworkitemid: {}", eachworkitemid);
			 MetaDataMap eachargs = eachworkitem.getMetaDataMap();
			 String archieved = eachargs.get("archived", "not find");
			//log.info("########################################################### archieved: {}", archieved);
			 String jiraid = eachargs.get("jiraId", "");
			 if(jiraid.length() > 0){
				 jiraId=jiraid;
				log.info("########################################################### jiraid: {}", jiraid);
			 }    		 
			 String jiraauthor = eachargs.get("jiraAuthor", "");
			 if(jiraauthor.length() > 0){
				log.info("########################################################### jiraauthor: {}", jiraauthor);
			 }

		
			 List<WorkflowTransition> currentItemWorkflowTransitions = workflownode.getTransitions();
		    	Iterator currentNodeTransitions = currentItemWorkflowTransitions.iterator();
		    	while (currentNodeTransitions.hasNext()){
		    		WorkflowTransition currentItemWorkflowTransition = (WorkflowTransition)currentNodeTransitions.next();
		    		WorkflowNode cfromWorkflowNode = currentItemWorkflowTransition.getFrom();
		    		log.info("########################################################### cfromWorkflowNode: {}", cfromWorkflowNode);
		    		String cfromWorkflowNodeId = cfromWorkflowNode.getId();
		    		String cfromWorkflowNodeType = cfromWorkflowNode.getType();
		    		log.info("########################################################### cfromWorkflowNodeId: {}", cfromWorkflowNodeId);
		    		log.info("########################################################### cfromWorkflowNodeType: {}", cfromWorkflowNodeType);
		    	}
        }
   	    /**
   	     * Jira code here
   	     */
		try {
			JiraProgress service = new JiraProgress();
			service.setupService("cms", "password");
			log.info("########################################################### jiraId: {}", jiraId);
			log.info("############################################################ jiraAction: {}", jiraAction);
			RemoteIssue issue = service.changeStatus(jiraId,jiraAction,comments);
			issue= service.updateAssignee(jiraId,assignee);
			
		} 
		catch (JiraServiceException e) {            	
			log.info("The JiraServiceException is:"+e);
		}
    	
    	boolean argument = readArgument(args);       
        log.info("###################### argument ######################: {}", argument);
    }
    private boolean readArgument(MetaDataMap args) {
        String argument = args.get("PROCESS_ARGS", "false");        
        return argument.equalsIgnoreCase("true");
    }
}