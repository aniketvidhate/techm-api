package com.att.ecom.cq.bundle.workflow;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.NonExistingResource;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.jiraservice.JiraServiceComponent;
import com.att.ecom.cq.bundle.jiraservice.JiraServiceException;
import com.att.ecom.cq.jirasoapservicev2.RemoteComponent;
import com.att.ecom.cq.jirasoapservicev2.RemoteIssue;
import com.day.cq.security.UserManagerFactory;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.collection.ResourceCollection;
import com.day.cq.workflow.collection.ResourceCollectionManager;
import com.day.cq.workflow.exec.HistoryItem;
import com.day.cq.workflow.exec.Route;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;

/**
 * Sample workflow process that logs arguments into the logfile.
 */
@Component
@Service
@Properties({
	@Property(name = Constants.SERVICE_DESCRIPTION, value = "Jira 'Create New and comment' or 'Comment on existing JIRA ticket'."),
	@Property(name = Constants.SERVICE_VENDOR, value = "Adobe"),
	@Property(name = "process.label", value = "Create New JIRA and Comment Or Comment on existing JIRA ticket")})

public class JiraCreateNewOrUpdateAndComment implements WorkflowProcess{ 

	/** @scr.reference */
	protected ResourceCollectionManager rcManager;

	/** @scr.reference policy="static" */
	private WorkflowService workflowService;

	/** @scr.reference policy="static" */
	private SlingRepository repository;

	/** @scr.reference policy="static"*/
	private UserManagerFactory userManagerFactory;

	//	private static boolean alreadyRolledback = false;

	@Reference
	private ResourceResolverFactory resourceResolverFactory; 
	
	@Reference
	private JiraServiceComponent jiraService;

	private static final String WORKFLOW_TITLE = "workflowTitle";	

	/** Logger  */
	private static final Logger LOG = LoggerFactory.getLogger(JiraCreateNewOrUpdateAndComment.class);
	//private static JiraServiceComponent jiraService = new JiraServiceComponent();

	@SuppressWarnings("static-access")
	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) throws WorkflowException {

		try {
			String path = item.getWorkflowData().getPayload().toString();
			Node jcrContentNode = (Node) session.getSession().getItem(path+ "/jcr:content");
			if(jiraService != null){
				String isJIRAEnabled = jiraService.isJIRAEnabled();
				if(StringUtils.isNotEmpty(isJIRAEnabled) && isJIRAEnabled.equalsIgnoreCase("true")){
					String username = jiraService.getJiraUsr();
					String password = jiraService.getJiraPwd();
					String soapURL = jiraService.getJiraSOAPURL();
					LOG.info("JIRA SERVICE IS " + jiraService);
					LOG.info("username: " + username + "***** soapURL: "+soapURL);				
					if(StringUtils.isNotEmpty(username) && StringUtils.isNotEmpty(password) && StringUtils.isNotEmpty(soapURL)){
						Workflow workflow = item.getWorkflow();					
						List<HistoryItem> historyItems = session.getHistory(workflow);						
						String jiraId="",jiraComment="",workflowTransNodeId="";
						for (Iterator<HistoryItem> iterator = historyItems.iterator(); iterator.hasNext();) {
							HistoryItem historyItem = (HistoryItem) iterator.next();
							workflowTransNodeId=historyItem.getWorkItem().getNode().getId();
						}
						
						if(jcrContentNode.hasProperty("jiraid") && !("".equals(jcrContentNode.getProperty("jiraid").getValue().getString().trim()))){
							LOG.info("Jira-Id :"+jcrContentNode.getProperty("jiraid").getValue().getString().trim()+". Will continue to add comments.");	
							if(jiraService.doesJiraExist(jcrContentNode.getProperty("jiraid").getValue().getString().trim())){
								jiraComment = generateJiraComment(item,session, jcrContentNode, jcrContentNode.getProperty("userId").getValue().getString().trim(), jcrContentNode.getProperty("jiracomment").getValue().getString().trim(), workflowTransNodeId);
								jiraService.addAComment(jcrContentNode.getProperty("jiraid").getValue().getString().trim(), jiraComment);
							}					
						} else {
							LOG.info("JiraCreateNewOrUpdateAndComment: execute: No Jira Id on payload. Will continue to create a new JIRA Creation");
							jiraComment = generateJiraComment(item,session, jcrContentNode, item.getWorkflow().getInitiator(), jiraComment, workflowTransNodeId);						
							RemoteIssue remoteJiraIssue = new RemoteIssue();
							remoteJiraIssue.setProject(jiraService.getJiraproject()); // Project: CMS
							remoteJiraIssue.setType(jiraService.getJiraissueType()); //IssueType: Other
							remoteJiraIssue.setSummary(item.getWorkflow().getInitiator()+"@CQ: Creating JIRA to report publishing of content to Production.");
							remoteJiraIssue.setPriority(jiraService.getJirapriority()); // Unprioritized.
							remoteJiraIssue.setAssignee(jiraService.getJiraUsr());
							remoteJiraIssue.setDescription(jiraComment);
							RemoteComponent b2cComponent = new RemoteComponent();
							b2cComponent.setId(jiraService.getJiracomponentId()); // Components=B2C
							jiraComment+="\n"+path;
							remoteJiraIssue.setComponents(new RemoteComponent[] {b2cComponent});							
							jiraId = jiraService.createIssue(remoteJiraIssue);							
							if(StringUtils.isNotEmpty(jiraId)){
								LOG.info("Succesfully Created JIRA ticket:"+jiraId+" and Initiator is:"+item.getWorkflow().getInitiator());
								jiraService.assignAndAddComment(jiraId, jiraComment,item.getWorkflow().getInitiator());		
								LOG.info("JIRA ID is not empty, saving in the jcr:content node of the payload path: "+ path);
								jcrContentNode.setProperty("jiraid", jiraId);
							}else{
								LOG.info("JIRA ID is empty, not saving in the jcr:content node of the payload path: "+ path);
							}							
						}

						String wftitlejiraId = jcrContentNode.getProperty("jiraid")!=null?jcrContentNode.getProperty("jiraid").getValue().getString().trim():jiraId;

						WorkflowData itemData = item.getWorkflowData();
						String userTitle = itemData.getMetaDataMap().get(WORKFLOW_TITLE, "No User Title");
						if (!userTitle.startsWith(wftitlejiraId)){
							updateWorkflowMetaData(session,item,WORKFLOW_TITLE, wftitlejiraId+" : " +userTitle);
						}

					}else{					
						LOG.info("JiraCreateNewOrUpdateAndComment: execute: assignAndAddComment: Configuration read is empty: Verify username, password, soap url from the JIRA service filter.");
					}
				}else{
					LOG.info("Jira is disabled in the Felix console Configuration of Jira Service Filter ");	
				}
			}else{
				LOG.info("JiraCreateNewOrUpdateAndComment: execute: JIRA Service must be down, not able to connect");				
			}
		} catch (JiraServiceException e) {
			LOG.error("Suspending Current workflow instance ");
			suspendCurrentWorkflow(session,item,e.getMessage());
			LOG.error("PathNotFoundException: "+ e);
		} catch (PathNotFoundException e1) {
			LOG.error("PathNotFoundException: "+ e1);
		} catch (RepositoryException e1) {
			LOG.error("RepositoryException: "+ e1);
		}
	}



	private String generateJiraComment(WorkItem item,WorkflowSession workflowSession,Node jcrContentNode, String userId, String jiraComment,  String workflowTransNodeId){
		String payloadpaths = "";		
		String payLoadpath = item.getWorkflowData().getPayload().toString();
		ResourceResolver resolver = null;

		try {
			if(workflowSession.getSession().itemExists(payLoadpath+"/jcr:content/vlt:definition")){
				resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
				payloadpaths+="Workflow Package Path:"+payLoadpath+" \n - Payload Path(s):";
				Node filterNode = (Node)workflowSession.getSession().getItem(payLoadpath+"/jcr:content/vlt:definition/filter");
				if(filterNode.hasNodes()){
					for (NodeIterator resourceNodeIt = filterNode.getNodes(); resourceNodeIt.hasNext(); ) {
						Node resourceNode = resourceNodeIt.nextNode();
						String currResPath = resourceNode.getProperty("root").getValue().getString();
						Resource currRes = resolver.resolve(currResPath);
						if(!currResPath.startsWith("/") || (currRes == null || currRes instanceof NonExistingResource)) {
							payloadpaths += "\n\t***WARNING*** {Invalid Resource} ==>" + currResPath + "<==";
						}
						else {
							payloadpaths += "\n\t* " + currResPath;
						}
					}
				}
			}
			else {
				payloadpaths =  "- Payload Path : "+payLoadpath;
			}
		}catch(Exception e){
			LOG.error("Error while generating jira comment",e);
		} finally {
			if(resolver != null) {
				resolver.close();
			}
		}


		// Workflow Timer info
		String productionDeploymentTimeFlag = null;
		Date productionDeploymentTime = null;
		String timerMsg = null;

		try {
			if(jcrContentNode.hasProperty("productionDeploymentTimeFlag")) {
				productionDeploymentTimeFlag = jcrContentNode.getProperty("productionDeploymentTimeFlag").getString();
				LOG.info("JiraCreateNewOrUpdateAndComment.generateJiraComment: productionDeploymentTimeFlag=" + productionDeploymentTimeFlag);

				if("Later".equals(productionDeploymentTimeFlag)) {
					productionDeploymentTime = jcrContentNode.getProperty("productionDeploymentTime").getDate().getTime();
					LOG.info("JiraCreateNewOrUpdateAndComment.generateJiraComment: productionDeploymentTime=" + productionDeploymentTime);

					SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss z");

					timerMsg = "- Deploy to production: Later (Details per timezone are as follow)\n";

					sdf.setTimeZone(TimeZone.getTimeZone("US/Pacific"));
					timerMsg = timerMsg + "-- " + sdf.format(productionDeploymentTime) + "\n";

					sdf.setTimeZone(TimeZone.getTimeZone("US/Central"));
					timerMsg = timerMsg + "-- " + sdf.format(productionDeploymentTime) + "\n";

					sdf.setTimeZone(TimeZone.getTimeZone("US/Eastern"));
					timerMsg = timerMsg + "-- " + sdf.format(productionDeploymentTime) + "";
				}
				else {
					// Do nothing
				}
			}
		} catch (Exception e) {
			LOG.error("JiraCreateNewOrUpdateAndComment.generateJiraComment ", e);
			timerMsg = null;
		}


		String finalJiraComment ="----------------------------------------------------------------------------------------------\n";
		finalJiraComment += "- Workflow Name:"+item.getWorkflow().getWorkflowModel().getTitle()+"\n"; 
		finalJiraComment += "- Workflow Initiator:"+item.getWorkflow().getInitiator()+"\n";
		finalJiraComment += "\n";
		if(timerMsg != null) {
			finalJiraComment += timerMsg + "\n\n";
		}
		finalJiraComment += "- Current Workflow Step:"+item.getWorkflow().getWorkflowModel().getNode(workflowTransNodeId).getTitle()+"\n";
		finalJiraComment += "- Workflow Step triggered By:"+userId+"\n";
		finalJiraComment += "- "+ payloadpaths+"\n"; 
		finalJiraComment += "----------------------------------------------------------------------------------------------\n";
		finalJiraComment += jiraComment!=""?jiraComment+"\n":"No Jira Id option was choosen while starting the workflow.\n This jira id is automatically created and assigned to, "+userId+"\n";
		finalJiraComment += "=== NOTE: INVALID RESOURCE WILL BE INGORED WHILE REPLICATING ===\n";
		if(timerMsg != null) {
			finalJiraComment += "Workflow will be pushed to production on a set date/time.\n";
		}
		finalJiraComment += "----------------------------------------------------------------------------------------------\n";

		return finalJiraComment;
	}


	private void delegateToCurrentUser(WorkflowSession session, WorkItem item, String errorMsg) throws WorkflowException, RepositoryException{
		LOG.error("---------------------------------------------------------------");
		LOG.error("DELEGATING WORK-FLOW, "+item.getId()+" to "+session.getUser().getName()+" due to error "+errorMsg);
		LOG.error("---------------------------------------------------------------");
		session.delegateWorkItem(item,session.getUser() );
		session.getSession().save();

	}

	//method to update Workflow MetaData
	private void updateWorkflowMetaData(WorkflowSession session, WorkItem item , String property , String value) {

		if(item.getMetaDataMap().get(property)==null){	
			WorkflowData itemData = item.getWorkflowData();			
			itemData.getMetaDataMap().put(property,value);
			LOG.info("After setting the value:"+itemData.getMetaDataMap().get(property));

			session.updateWorkflowData(item.getWorkflow(), itemData);			
		}
	}


	private void suspendCurrentWorkflow(WorkflowSession session, WorkItem item, String errorMsg){
		try {
			if("RUNNING".equals(item.getWorkflow().getState()) ){
				LOG.error("---------------------------------------------------------------");
				LOG.error("ROLLING BACK WORK-FLOW, "+item.getId()+" due to error "+errorMsg);
				LOG.error("---------------------------------------------------------------");
				List<Route> backRoutes;

				backRoutes = session.getBackRoutes(item,true);

				for (Iterator<Route> iterator = backRoutes.iterator(); iterator.hasNext();) {
					Route backRoute = (Route) iterator.next();
					if(backRoute.isBackRoute()) {
						session.complete(item, backRoute);

						break;
					}
				}
				//			session.terminateWorkflow(item.getWorkflow());
				//			session.suspendWorkflow(item.getWorkflow());
				//			session.getSession().save();
				return;
			}else{
				LOG.error("WORKFLOW, '"+item.getWorkflow().getId()+"' IS ALREADY IS SUSPENDED STATE");
			}
		}catch (WorkflowException e) {
			LOG.error("Workflow Exception:suspendCurrentWorkflow method: "+e);
		}
	}



	/**
	 * Collect all the paths being attempted here for deployment.
	 * @param path
	 * @param rcCollection
	 * @return
	 */
	private List<String> getPaths(String path, ResourceCollection rcCollection) {
		List<String> paths = new ArrayList<String>();	
		if (rcCollection == null) {
			LOG.info("########################################################### path :"+ path);
			paths.add(path);
		} else {
			LOG.info("########################################################### ResourceCollection detected: {}", rcCollection.getPath());
			try {
				List<Node> members = rcCollection.list(new String[] { "cq:Page", "dam:Asset" });
				for (Node member : members) {
					String mPath = member.getPath();
					paths.add(mPath);
				}
			} catch (RepositoryException re) {
				LOG.error("Cannot build path list out of the resource collection " + rcCollection.getPath());
			}
		}
		return paths;
	}


	// ----------< helper >-----------------------------------------------------
	private WorkflowSession getWorkflowSession() {
		Session adminSession = null;
		try {
			adminSession = repository.loginAdministrative(null);
			return workflowService.getWorkflowSession(adminSession);
		} catch (RepositoryException re) {
			LOG.error("RepositoryException: " + re);
		}finally {
			if (adminSession != null && adminSession.isLive()) {
				adminSession.logout();
			}
		}
		return null;
	}

}
