package com.att.ecom.cq.bundle.jiraservice;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Dictionary;

import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.xml.rpc.ServiceException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.jirasoapservicev2.JiraSoapService;
import com.att.ecom.cq.jirasoapservicev2.JiraSoapServiceServiceLocator;
import com.att.ecom.cq.jirasoapservicev2.RemoteAuthenticationException;
import com.att.ecom.cq.jirasoapservicev2.RemoteComment;
import com.att.ecom.cq.jirasoapservicev2.RemoteException;
import com.att.ecom.cq.jirasoapservicev2.RemoteFieldValue;
import com.att.ecom.cq.jirasoapservicev2.RemoteIssue;
import com.att.ecom.cq.jirasoapservicev2.RemotePermissionException;
import com.att.ecom.cq.jirasoapservicev2.RemoteValidationException;
/**
 * Filter which redirects static asset requests to an alternate domain for
 * situations where the static assets are not available locally.
 */
@Component(immediate = true, metatype = true, label = "JIRA Service Filter", description = "JIRA Service to preload Jira specific information", enabled = true)
@Service(value = com.att.ecom.cq.bundle.jiraservice.JiraServiceComponent.class)
public class JiraServiceComponent {
	
	// Constants for ASYNC Jira Handling
	public static final String JIRA_CONTAINER_NODE_PATH	= "/etc/att/jira";
	public static final String JIRA_NODE_PREFIX				= "JIRA-";
	public static final String JIRA_NODE_ID					= "jira-id";
	public static final String JIRA_NODE_SUMMARY			= "jira-summary";
	public static final String JIRA_NODE_DESCRIPTION		= "jira-description";
	public static final String JIRA_NODE_PATH				= "jira-path";
	public static final String JIRA_NODE_ASSIGNEE			= "jira-assignee";
	public static final String JIRA_NODE_COMMENT			= "jira-comment";
	public static final String JIRA_NODE_TIMESTAMP			= "jira-timestamp";
	public static final String JIRA_TCKT_CREATION_MODE		= "jira-tckt-creation-mode";	// Collection | Individual
	public static final String JIRA_TCKT_CREATION_MODE_INDIVIDUAL = "Individual";
	public static final String JIRA_TCKT_CREATION_MODE_Collection = "Collection";
	public static final String JIRA_ID_CREATE_DATE 			= "jira-id-create-date";

	/**
	 * A logger.
	 */
	private static final Logger mLogger = LoggerFactory.getLogger(JiraServiceComponent.class);
	
	private static final String TRUE = "true";
	private static final String FALSE = "false";
	
	/**
	 * Default JIRA user
	 */
	private static String JIRA_USER="";
	@Property(label = "JIRA USER", description = "JIRA Service is pointed to this location.", value = "")
	private static final String JIRA_USR = "jira.user";
	
	private static String JIRA_PASSWORD="";
	@Property(label = "JIRA PWD", description = "JIRA Service is pointed to this location.", value = "")
	private static final String JIRA_PWD = "jira.password";
	
	private static final String JIRA_PROJECT="B2C";
	@Property(label = "JIRA Project", description = "JIRA Project.", value = JIRA_PROJECT)
	private static final String JIRAPROJECT = "jira.project";

	private static final String JIRA_ISSUE_TYPE="53";
	@Property(label = "JIRA ISSUE_TYPE", description = "JIRA Issue Type.", value = JIRA_ISSUE_TYPE)
	private static final String JIRAISSUE_TYPE = "jira.issueType";

	private static final String JIRA_PRIORITY="6";
	@Property(label = "JIRA PRIORITY", description = "JIRA Priority.", value = JIRA_PRIORITY)
	private static final String JIRAPRIORITY = "jira.priority";
	
	private static final String JIRA_COMPONENT_ID="14460";
	@Property(label = "JIRA COMPONENT_ID", description = "JIRA Component Id.", value = JIRA_COMPONENT_ID)
	private static final String JIRACOMPONENT_ID = "jira.componentId";
	
	private static final String JIRA_SCHEDULAR_CRON_EXPRESSION = "0 0/5 * * * ?";
	@Property(label = "Jira Schedular Cron Expression", description = "Enter cron expression for jira schedular", value = JIRA_SCHEDULAR_CRON_EXPRESSION)
	private static final String JIRASCHEDULARCRONEXPRESSION = "jira.schedularcronexpression";
	
	private static final String JIRA_SCHEDULAR_DEFAULT = "Off";
	@Property(label = "Jira Schedular Status", description = "Enter Jira Schedular Status On/Off", value = JIRA_SCHEDULAR_DEFAULT)
	private static final String JIRASCHEDULARONOFF = "jira.schedularonoff";	
	
	private static String JIRA_ENABLED="";
	@Property(label = "Jira Enabled Status", description = "Enter Jira Enabled Status true/false", value = "false")
	private static String JIRA_ENABLED_KEY = "jira.enabled";
	
	@Reference
	private SlingRepository repository;
	
	private Session adminSession;
	/**
	 * Jira Runtime Url
	 */
	 private static URL jiraRuntimeUrl ;
	 

	private  JiraSoapService jiraSoapService = null;

	private static String JIRA_SOAP_URL ="";
	@Property(label = "JIRA SOAP URL", description = "JIRA Service is pointed to this location.", value = "")
	private static String JIRA_PROD_BASE_URL = "jira.base";
	
	@SuppressWarnings("rawtypes")
	private static Dictionary props ;
	
	public JiraServiceComponent() {
		mLogger.info("New JiraServiceComponent got created. HashId#" + this.hashCode());
	}
	
	public String formatDate(Date dt) {
		SimpleDateFormat dateFormatter		= new SimpleDateFormat("E-dd-MMM-yyyy HH:mm:ss Z");
		return dateFormatter.format(dt);
	}
	
	public Date parseDate(String str) {
		SimpleDateFormat dateFormatter		= new SimpleDateFormat("E-dd-MMM-yyyy HH:mm:ss Z");
		try {
			return dateFormatter.parse(str);
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}
	
	public boolean isDateToday(String date) {
		SimpleDateFormat dateFormatter		= new SimpleDateFormat("E-dd-MMM-yyyy HH:mm:ss Z");
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(dateFormatter.parse(date));
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			
			Calendar now = Calendar.getInstance();
			now.set(Calendar.HOUR_OF_DAY, 0);
			now.set(Calendar.MINUTE, 0);
			now.set(Calendar.SECOND, 0);
			now.set(Calendar.MILLISECOND, 0);
			
			if(cal.compareTo(now) != 0) {
				return false;
			}
			else {
				return true;
			}
			
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}
	
	/** 
	 * Jira Authorized token
	 */
	private  String aurhorizedJiraToken = "";
	

	public static String getJiraproject() {
		
		return OsgiUtil.toString(props.get(JIRAPROJECT),JIRA_PROJECT);
	}

	public static String getJiraUsr() {
		return JIRA_USER;
	}
	
	public static String getJiraPwd() {
		return JIRA_PASSWORD;
	}
	
	public static String getJiraSOAPURL() {
		return JIRA_SOAP_URL;
	}
	
	public static String isJIRAEnabled() {
		return JIRA_ENABLED;
	}


	public static String getJiraissueType() {
		return OsgiUtil.toString(props.get(JIRAISSUE_TYPE),JIRA_ISSUE_TYPE);
	}

	public static String getJirapriority() {
		return OsgiUtil.toString(props.get(JIRAPRIORITY),JIRA_PRIORITY);
	}

	public static String getJiracomponentId() {
		return OsgiUtil.toString(props.get(JIRACOMPONENT_ID),JIRA_COMPONENT_ID) ;
	}
	
	public static String getJiraScheudlarCronExpression() {
		return OsgiUtil.toString(props.get(JIRASCHEDULARCRONEXPRESSION), JIRA_SCHEDULAR_CRON_EXPRESSION);
	}
	
	public static boolean isJiraSchedularOn() {
		String value = OsgiUtil.toString(props.get(JIRASCHEDULARONOFF), JIRA_SCHEDULAR_DEFAULT);
		if("on".equalsIgnoreCase(value)) {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * Establishing Jira Connection once from activate method. This would be reused.
	 * @param JiraUrl
	 */
	private  void setJiraServiceConnection() {
		// Logic here is to assign assign the current thread classloader to a currentTCCL
		// Set the contextClassLoader to the bundle Classloader or current classloader of this class which is via OSGI.
		// If you dont do this, you will get a class cast exception as the current context classloader would be set to weblogic and there are 
		// conflicting versions of attachmentsImpl class ( one from axis1.3.jar in shop.ear and other axis1.4.jar from the jira bundle itself).
		// do your stuff
		// finally assign the context classloader to the currentTCCL.
		try {
			if(StringUtils.isNotEmpty(isJIRAEnabled()) && isJIRAEnabled().equalsIgnoreCase(TRUE)){
				if(StringUtils.isNotEmpty(getJiraUsr()) && StringUtils.isNotEmpty(getJiraPwd()) && StringUtils.isNotEmpty(getJiraSOAPURL())){
					ClassLoader currentTCCL = Thread.currentThread().getContextClassLoader();
			    	Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());
					try {
							JiraSoapServiceServiceLocator jiraSoapServiceServiceLocator = new JiraSoapServiceServiceLocator();
							jiraSoapService = jiraSoapServiceServiceLocator.getJirasoapserviceV2(jiraRuntimeUrl);
							aurhorizedJiraToken = jiraSoapService.login(getJiraUsr(), getJiraPwd());
							mLogger.info("Succesfully connected to :"+ jiraRuntimeUrl.toString() + " and authenticated as CQ");
					} finally {
						Thread.currentThread().setContextClassLoader(currentTCCL);
					}
				}else{
					mLogger.info("setJiraServiceConnection: Configuration read is empty: Verify username, password, soap url from the JIRA service filter.");
				}
			}else{
				mLogger.info("setJiraServiceConnection: JIRA is not enabled in the JIRA servie filter configuration: JIRA Status: JIRA Enabled Status value:"+isJIRAEnabled());
			}				    	
		}catch (ServiceException e) {
			jiraSoapService = null;
			mLogger.error("Error in setJiraSerivceConnection()", e);
			e.printStackTrace();
		} catch (RemoteAuthenticationException e) {
			jiraSoapService = null;
			mLogger.error("Error in setJiraSerivceConnection()", e);
			e.printStackTrace();
		} catch (RemoteException e) {
			jiraSoapService = null;
			mLogger.error("Error in setJiraSerivceConnection()", e);
			e.printStackTrace();
		} catch (java.rmi.RemoteException e) {
			jiraSoapService = null;
			mLogger.error("Error in setJiraSerivceConnection()", e);
			e.printStackTrace();
		}
	}
	
	public boolean isConnectionAlive() {
		try {
			getJiraSoapService().getPriorities(getAuthorizedJiraToken());
			return true;
		} catch (RemotePermissionException e) {
			mLogger.error("1. Error while checking jira connection status.", e);
			return false;
		} catch (RemoteAuthenticationException e) {
			mLogger.error("2. Error while checking jira connection status.", e);
			return false;
		} catch (java.rmi.RemoteException e) {
			mLogger.error("3. Error while checking jira connection status.", e);
			return false;
		} catch (NullPointerException e) {
			mLogger.error("4. Error while checking jira connection status.", e);
			return false;
		}
	}
	
	
	protected void activate(ComponentContext ctx) {
		try {
			this.adminSession = repository.loginAdministrative(null);
			props = ctx.getProperties();
			JIRA_ENABLED = OsgiUtil.toString(props.get(JIRA_ENABLED_KEY),FALSE);
			JIRA_USER = OsgiUtil.toString(props.get(JIRA_USR),"");
			JIRA_PASSWORD = OsgiUtil.toString(props.get(JIRA_PWD),"");
			mLogger.info("JIRA_USER:"+JIRA_USER);
			mLogger.info("JIRA_ENABLED:"+JIRA_ENABLED);
			JIRA_SOAP_URL = OsgiUtil.toString(props.get(JIRA_PROD_BASE_URL),"");
			if(StringUtils.isNotEmpty(JIRA_SOAP_URL)){
				setJiraRuntimeUrl(new URL(JIRA_SOAP_URL));
				mLogger.info("JiraServiceComponent Connected to :"+ getJiraRuntimeUrl());
				setJiraServiceConnection();
			}else{
				mLogger.info("JiraServiceComponent: JIRA SOAP URL from the configration is null or empty");
			}		
			this.adminSession.save();
		} catch (MalformedURLException e) {
			mLogger.error("Error during activation of JiraServiceComponent: "+e);
		} catch (RepositoryException e) {
			mLogger.error("Error during getting the admin session of JiraServiceComponent: "+e);
		} 
	}
	
	protected void deactivate(ComponentContext ctx) {
		try{
			if(this.adminSession != null && this.adminSession.isLive() && this.adminSession.hasPendingChanges()){
				mLogger.debug("Saving pending changes and logging out");
				this.adminSession.save();
				this.adminSession.logout();
			}
		}catch(RepositoryException e){
			mLogger.error("JiraServiceComponent: deactivate : exception while saving the session and logging out", e);
		}		
		mLogger.debug("JiraServiceComponent: deactivate: STOPPED");
	}
	

	private String getAuthorizedJiraToken() {
		return aurhorizedJiraToken;
	}
	
	public  JiraSoapService getJiraSoapService() {
			//setJiraServiceConnection();
			return jiraSoapService;
	}
	
	
	/**
	 * Create new JIRA issues. 
	 * @param projectKey
	 * 
	 * @throws JiraServiceException
	 * @throws java.rmi.RemoteException 
	 */
	public String createIssue(RemoteIssue remoteJiraIssue) throws JiraServiceException {
		String issueKey = "";
		RemoteIssue returnedIssue = null;
		try {
			if(StringUtils.isNotEmpty(isJIRAEnabled()) && isJIRAEnabled().equalsIgnoreCase(TRUE)){
				if(StringUtils.isNotEmpty(getJiraUsr()) && StringUtils.isNotEmpty(getJiraPwd()) && StringUtils.isNotEmpty(getJiraSOAPURL())){
					if(remoteJiraIssue.getAssignee() == null) {
						remoteJiraIssue.setAssignee(JIRA_USER); 
					}
					if(isConnectionAlive() == false) {
						setJiraServiceConnection();
					}
					returnedIssue = getJiraSoapService().createIssue(getAuthorizedJiraToken(), remoteJiraIssue);
				}else{
					mLogger.info("addAComment: Configuration read is empty: Verify username, password, soap url from the JIRA service filter.");
					throw new JiraServiceException("Configuration Exception Occured, Configuration read is empty: Verify username, password, soap url from the JIRA service filter. ");
				}				
			}else{
				mLogger.info("createIssue: JIRA is not enabled in the JIRA servie filter configuration: JIRA Enabled Status value:"+isJIRAEnabled());
				throw new JiraServiceException("Configuration Exception Occured, JIRA is not enabled in the JIRA servie filter configuration ");
			}			
		} catch (RemotePermissionException e) {
			throw new JiraServiceException("Remote Permission Exception Occured, User not authorized to create a new Jira : "+e.getMessage());
		} catch (RemoteAuthenticationException e) {
			throw new JiraServiceException("Remote Authenticated Exception Occured, User id/password is wrong: "+e.getMessage());
		} catch (java.rmi.RemoteException e) {
			throw new JiraServiceException("Remote  Exception Occured, Jira might be down or Not able to contact jira system: "+e.getMessage());
		}
		issueKey = returnedIssue.getKey();
		mLogger.info("createIssue() : Issue: " + issueKey);
		return issueKey;
	}
	
	/**
	 * Add a comment on Existing Jira Issue.
	 * @return
	 */
	public void addAComment(String jiraId, String userComment) throws JiraServiceException {
		try {
			mLogger.debug(("########################## Jira ID: ##########################: "+jiraId));
			if(StringUtils.isNotEmpty(isJIRAEnabled()) && isJIRAEnabled().equalsIgnoreCase(TRUE)){
				if(StringUtils.isNotEmpty(getJiraUsr()) && StringUtils.isNotEmpty(getJiraPwd()) && StringUtils.isNotEmpty(getJiraSOAPURL())){	
					RemoteComment comment = new RemoteComment();
					comment.setBody(userComment);
					if(isConnectionAlive() == false) {
						setJiraServiceConnection();
					}
					getJiraSoapService().addComment(getAuthorizedJiraToken(), jiraId, comment);
				}else{
					mLogger.info("addAComment: Configuration read is empty: Verify username, password, soap url from the JIRA service filter.");
				}				
			}else{
				mLogger.info("addAComment: JIRA is not enabled in the JIRA servie filter configuration: JIRA Enabled Status value:"+isJIRAEnabled());
			}
		} catch (RemotePermissionException e) {
			mLogger.error("Error while adding comment to jiraid#" + jiraId, e);
			throw new JiraServiceException("Remote Permission Exception Occured, User might not have the permission to update "+jiraId+": "+e.getMessage());
		} catch (RemoteAuthenticationException e) {
			mLogger.error("Error while adding comment to jiraid#" + jiraId, e);
			throw new JiraServiceException("Remote Authenticated Exception Occured, User id or password is wrong:  "+jiraId+": "+e.getMessage());
		} catch (java.rmi.RemoteException e) {
			mLogger.error("Error while adding comment to jiraid#" + jiraId, e);
			throw new JiraServiceException("Remote Authenticated Exception Occured, Jira might be down or Not able to contact jira system: "+e.getMessage());
		}
	}
	
	/**
	 * Assign and add a comment on Existing Jira Issue.
	 * @return 
	 */
    public void assignAndAddComment(String jiraId, String userComment,String assignee) throws JiraServiceException {
		mLogger.debug(("assignAndAddComment: ########################## Jira ID: ##########################: "+jiraId));
		try{
			if(StringUtils.isNotEmpty(isJIRAEnabled()) && isJIRAEnabled().equalsIgnoreCase(TRUE)){
				if(StringUtils.isNotEmpty(getJiraUsr()) && StringUtils.isNotEmpty(getJiraPwd()) && StringUtils.isNotEmpty(getJiraSOAPURL())){				 
					RemoteComment comment = new RemoteComment();
					comment.setBody(userComment);
					if(isConnectionAlive() == false) {
						setJiraServiceConnection();
					}
					getJiraSoapService().addComment(getAuthorizedJiraToken(), jiraId, comment);
					getJiraSoapService().getIssue(aurhorizedJiraToken, jiraId);
					final RemoteFieldValue newAssignee = new RemoteFieldValue("assignee", new String[] {assignee});
					getJiraSoapService().updateIssue(aurhorizedJiraToken, jiraId, new RemoteFieldValue[] {newAssignee});
				}else{
					mLogger.info("assignAndAddComment: Configuration read is empty: Verify username, password, soap url from the JIRA service filter.");
				}
			}else{
				mLogger.info("assignAndAddComment: JIRA is not enabled in the JIRA servie filter configuration: JIRA Enabled Status value:"+isJIRAEnabled());
			}			
		}		
		catch (Exception e) {
			mLogger.error("Error in assignAndAddComment() jiraid#" + jiraId, e);
			throw new JiraServiceException(e);	    
		}
    }
	
	public static URL getJiraRuntimeUrl() {
		return jiraRuntimeUrl;
	}

	public static void setJiraRuntimeUrl(URL jiraRuntimeUrl) {
		JiraServiceComponent.jiraRuntimeUrl = jiraRuntimeUrl;
	}

	/**
	 * Check if JIRA exists.
	 * @param jiraId
	 * @return
	 * @throws JiraServiceException
	 */
	public boolean doesJiraExist(String jiraId) throws JiraServiceException{
		boolean jiraExists = false;		
		try {
			if(StringUtils.isNotEmpty(isJIRAEnabled()) && isJIRAEnabled().equalsIgnoreCase(TRUE)){
				if(StringUtils.isNotEmpty(getJiraUsr()) && StringUtils.isNotEmpty(getJiraPwd()) && StringUtils.isNotEmpty(getJiraSOAPURL())){
					RemoteIssue remoteIssue = null;
					
					if(isConnectionAlive() == false) {
						setJiraServiceConnection();
					}
					
					remoteIssue = getJiraSoapService().getIssue(getAuthorizedJiraToken(), jiraId);
					
					
					if(remoteIssue!=null){
						jiraExists=true;
					}
				}else{
					mLogger.info("doesJiraExist: Configuration read is empty: Verify username, password, soap url from the JIRA service filter.");
				}
			}else{
				mLogger.info("doesJiraExist: JIRA is not enabled in the JIRA servie filter configuration: JIRA Enabled Status value:"+isJIRAEnabled());
			}			
			return jiraExists;
		} catch (RemotePermissionException e) {
			mLogger.error("Error in doesJiraExist() jiraid#" + jiraId, e);
			throw new JiraServiceException("'"+jiraId+"' does not exist.");
		} catch (RemoteAuthenticationException e) {
			// TODO Auto-generated catch block
			
			mLogger.error("Error in doesJiraExist() jiraid#" + jiraId, e);
			throw new JiraServiceException("User id or password is wrong: "+e.getMessage());
		} catch (java.rmi.RemoteException e) {
			// TODO Auto-generated catch block
			mLogger.error("Error in doesJiraExist() jiraid#" + jiraId, e);
			throw new JiraServiceException(" Jira system might be down");
			
		} catch (java.lang.NullPointerException e) {
			// TODO Auto-generated catch block
			mLogger.error("Error in doesJiraExist() jiraid#" + jiraId, e);
			throw new JiraServiceException(" Jira soap service might be down");
			
		}
	}
	
}
