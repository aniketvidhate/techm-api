package com.att.ecom.cq.bundle.workflow;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.jcr.ItemExistsException;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.version.VersionException;
import javax.management.Descriptor;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.NonExistingResource;
import org.apache.sling.api.resource.PersistableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.jiraservice.JiraServiceComponent;
import com.att.ecom.cq.bundle.jiraservice.JiraServiceException;
import com.att.ecom.cq.jirasoapservicev2.RemoteComponent;
import com.att.ecom.cq.jirasoapservicev2.RemoteIssue;
import com.day.cq.security.UserManagerFactory;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.collection.ResourceCollection;
import com.day.cq.workflow.collection.ResourceCollectionManager;
import com.day.cq.workflow.collection.ResourceCollectionUtil;
import com.day.cq.workflow.exec.HistoryItem;
import com.day.cq.workflow.exec.Route;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;

/**
 * Sample workflow process that logs arguments into the logfile.
 */
@Component
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "Create/Update JIRA ticket Asynchronously."),
        @Property(name = Constants.SERVICE_VENDOR, value = "Adobe"),
        @Property(name = "process.label", value = "Create/Update JIRA ticket Asynchronously.")})

public class JiraAsyncCreateNewOrUpdateAndComment implements WorkflowProcess{ //,ParticipantStepChooser {
    /** @scr.reference */
    protected ResourceCollectionManager rcManager;
	
    /** admin jcr session */
    private Session admin;
    
	/** @scr.reference policy="static" */
	private WorkflowService workflowService;

    /** @scr.reference policy="static" */
    private SlingRepository repository;
    
    /** @scr.reference policy="static"*/
	private UserManagerFactory userManagerFactory;
	
//	private static boolean alreadyRolledback = false;

	@Reference
	private ResourceResolverFactory resourceResolverFactory; 
	private ResourceResolver adminResolver = null;
	
	@Reference
	private JiraServiceComponent jiraService;


	private static final String WORKFLOW_TITLE = "workflowTitle";
    
	/** Logger  */
	   private static final Logger log = LoggerFactory.getLogger(JiraAsyncCreateNewOrUpdateAndComment.class);
	   //private static JiraServiceComponent jiraService = new JiraServiceComponent();
	   
	@SuppressWarnings("static-access")
	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) throws WorkflowException {
		log.debug("JIRA SERVICE IS " + jiraService);
		
		Workflow workflow = item.getWorkflow();
		String path = item.getWorkflowData().getPayload().toString();
		List<HistoryItem> historyItems = session.getHistory(workflow);

		MetaDataMap metaDataMap = null;
		String jiraId="",jiraComment="",userId="",workflowTransNodeId="";
	   for (Iterator<HistoryItem> iterator = historyItems.iterator(); iterator.hasNext();) {
			HistoryItem historyItem = (HistoryItem) iterator.next();
			metaDataMap = historyItem.getWorkItem().getMetaDataMap();
			workflowTransNodeId=historyItem.getWorkItem().getNode().getId();
		}
		
	   
	   
		try {
			Node jcrContentNode = (Node) session.getSession().getItem(path+ "/jcr:content");
			
			if(jcrContentNode.hasProperty("jiraid") && !("".equals(jcrContentNode.getProperty("jiraid").getValue().getString().trim()))) {
				jiraId = jcrContentNode.getProperty("jiraid").getValue().getString().trim();
				log.info("Jira-Id :"+jcrContentNode.getProperty("jiraid").getValue().getString().trim()+". Will continue to add comments.");
			}
			
			if(jcrContentNode.hasProperty("jiracomment") && !("".equals(jcrContentNode.getProperty("jiracomment").getValue().getString().trim()))) {
				jiraComment = jcrContentNode.getProperty("jiracomment").getValue().getString().trim();
			}
			
			if(jcrContentNode.hasProperty("userId") && !("".equals(jcrContentNode.getProperty("userId").getValue().getString().trim()))) {
				userId = jcrContentNode.getProperty("userId").getValue().getString().trim();
			}
			
			HashMap<String, String> jiraData = new HashMap<String,String>();
			jiraData.put(JiraServiceComponent.JIRA_NODE_ID, jiraId);
			jiraData.put(JiraServiceComponent.JIRA_NODE_SUMMARY, "CQ: Creating JIRA to report publishing of content to Production.");
			jiraData.put(JiraServiceComponent.JIRA_NODE_PATH, path);
			
			if(userId == null || "".equals(userId)) {
				jiraComment = generateJiraComment(item,session, jcrContentNode, item.getWorkflow().getInitiator(), jiraComment, workflowTransNodeId);
				jiraData.put(JiraServiceComponent.JIRA_NODE_ASSIGNEE, item.getWorkflow().getInitiator());
			}
			else {
				jiraComment = generateJiraComment(item,session, jcrContentNode, userId, jiraComment, workflowTransNodeId);
				jiraData.put(JiraServiceComponent.JIRA_NODE_ASSIGNEE, userId);
			}
			
			jiraData.put(JiraServiceComponent.JIRA_NODE_DESCRIPTION, jiraComment);
			String dt = jiraService.formatDate(new Date());
			jiraData.put(JiraServiceComponent.JIRA_NODE_TIMESTAMP, dt);
			
			String prefix = "------------------------------------------------------\n";
			prefix = prefix + "This JIRA got created/updated asynchronously.\n";
			prefix = prefix + "Acutal change in system happend at: " + dt + "\n";
			prefix = prefix + "------------------------------------------------------\n";
			jiraComment = prefix + jiraComment;
			
			jiraData.put(JiraServiceComponent.JIRA_NODE_COMMENT, jiraComment);
			
			if(jcrContentNode.hasProperty("jira-tckt-creation-mode") && !("".equals(jcrContentNode.getProperty("jira-tckt-creation-mode").getString()))) {
				jiraData.put(JiraServiceComponent.JIRA_TCKT_CREATION_MODE, jcrContentNode.getProperty("jira-tckt-creation-mode").getString());
			}
			
			queueUpJira(jiraData);
			
			if(jiraId != null || "".equals(jiraId)) {
				jcrContentNode.setProperty("jiraid", jiraId);
			}
			
			
			
					
//			  String wftitlejiraId = jiraId !=null?jcrContentNode.getProperty("jiraid").getValue().getString().trim():jiraId;
//			 
//			  WorkflowData itemData = item.getWorkflowData();
//			  String userTitle = itemData.getMetaDataMap().get(WORKFLOW_TITLE, "No User Title");
//			  if (!userTitle.startsWith(wftitlejiraId)){
//				  updateWorkflowMetaData(session,item,WORKFLOW_TITLE, wftitlejiraId+" : " +userTitle);
//			  }
			  
		} catch (PathNotFoundException e1) {
			e1.printStackTrace();
		} catch (RepositoryException e1) {
			e1.printStackTrace();
		}
		}
		

	
	private String generateJiraComment(WorkItem item,WorkflowSession workflowSession,Node jcrContentNode, String userId, String jiraComment,  String workflowTransNodeId){
		String payloadpaths = "";		
		String payLoadpath = item.getWorkflowData().getPayload().toString();
		ResourceResolver resolver = null;
		
    	try {
			if(workflowSession.getSession().itemExists(payLoadpath+"/jcr:content/vlt:definition")){
				resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
				payloadpaths+="Workflow Package Path:"+payLoadpath+" \n - Payload Path(s):";
				Node filterNode = (Node)workflowSession.getSession().getItem(payLoadpath+"/jcr:content/vlt:definition/filter");
				if(filterNode.hasNodes()){
					for (NodeIterator resourceNodeIt = filterNode.getNodes(); resourceNodeIt.hasNext(); ) {
						Node resourceNode = resourceNodeIt.nextNode();
						String currResPath = resourceNode.getProperty("root").getValue().getString();
						Resource currRes = resolver.resolve(currResPath);
						
						if(!currResPath.startsWith("/") || (currRes == null || currRes instanceof NonExistingResource)) {
							payloadpaths += "\n\t***WARNING*** {Invalid Resource} ==>"+currResPath + "<==";
						}
						else {
							payloadpaths += "\n\t* "+currResPath;
						}
					}
				}
			}
			else{
				payloadpaths =  "Payload Path : "+payLoadpath;
			}
		}catch(Exception e){
			log.error("Error while generating jira comment",e);
		} finally {
			if(resolver != null) {
				resolver.close();
			}
		}
		
		String finalJiraComment ="----------------------------------------------------------------------------------------------\n";
		finalJiraComment += "- Workflow Name:"+item.getWorkflow().getWorkflowModel().getTitle()+"\n"; 
		finalJiraComment += "- Workflow Initiator:"+item.getWorkflow().getInitiator()+"\n";
		finalJiraComment += "\n";
		finalJiraComment += "- Current Workflow Step:"+item.getWorkflow().getWorkflowModel().getNode(workflowTransNodeId).getTitle()+"\n";
		finalJiraComment += "- Workflow Step triggered By:"+userId+"\n";
		finalJiraComment += "- "+ payloadpaths+"\n"; 
		finalJiraComment += "----------------------------------------------------------------------------------------------\n";
		finalJiraComment += jiraComment!=""?jiraComment+"\n":"No Jira Id option was choosen while starting the workflow.\n This jira id is automatically created and assigned to, "+userId+"\n";
		finalJiraComment += "=== NOTE: INVALID RESOURCE WILL BE INGORED WHILE REPLICATING ===\n";
		finalJiraComment += "----------------------------------------------------------------------------------------------\n";

		return finalJiraComment;
	}
	

	private void delegateToCurrentUser(WorkflowSession session, WorkItem item, String errorMsg) throws WorkflowException, RepositoryException{
		log.error("---------------------------------------------------------------");
		log.error("DELEGATING WORK-FLOW, "+item.getId()+" to "+session.getUser().getName()+" due to error "+errorMsg);
		log.error("---------------------------------------------------------------");
		session.delegateWorkItem(item,session.getUser() );
		session.getSession().save();
		
	}
	
	//method to update Workflow MetaData
	private void updateWorkflowMetaData(WorkflowSession session, WorkItem item , String property , String value) {
		
		if(item.getMetaDataMap().get(property)==null){	
			WorkflowData itemData = item.getWorkflowData();			
			itemData.getMetaDataMap().put(property,value);
			log.info("After setting the value:"+itemData.getMetaDataMap().get(property));
			
			session.updateWorkflowData(item.getWorkflow(), itemData);			
		}
	}
	
	
	private void suspendCurrentWorkflow(WorkflowSession session, WorkItem item, String errorMsg) throws RepositoryException,WorkflowException{
		if("RUNNING".equals(item.getWorkflow().getState()) ){
			log.error("---------------------------------------------------------------");
			log.error("ROLLING BACK WORK-FLOW, "+item.getId()+" due to error "+errorMsg);
			log.error("---------------------------------------------------------------");
			
			
//			WorkflowUtil
			
			
			
			List<Route> backRoutes = session.getBackRoutes(item,true);
			for (Iterator<Route> iterator = backRoutes.iterator(); iterator.hasNext();) {
				Route backRoute = (Route) iterator.next();
				if(backRoute.isBackRoute()) {
					session.complete(item, backRoute);
					
					break;
				}
			}
			
			
			
//			session.terminateWorkflow(item.getWorkflow());
//			session.suspendWorkflow(item.getWorkflow());
//			session.getSession().save();
			
			return;
		}else{
			log.error("WORKFLOW, '"+item.getWorkflow().getId()+"' IS ALREADY IS SUSPENDED STATE");
		}
	}



	/**
	 * Collect all the paths being attempted here for deployment.
	 * @param path
	 * @param rcCollection
	 * @return
	 */
    private List<String> getPaths(String path, ResourceCollection rcCollection) {
        List<String> paths = new ArrayList<String>();	
        if (rcCollection == null) {
        	log.info("########################################################### path :"+ path);
            paths.add(path);
        } else {
            log.info("########################################################### ResourceCollection detected: {}", rcCollection.getPath());
            try {
                List<Node> members = rcCollection.list(new String[] { "cq:Page", "dam:Asset" });
                for (Node member : members) {
                    String mPath = member.getPath();
                    paths.add(mPath);
                }
            } catch (RepositoryException re) {
                log.error("Cannot build path list out of the resource collection " + rcCollection.getPath());
            }
        }
        return paths;
    }
    
    
	// ----------< helper >-----------------------------------------------------
	private WorkflowSession getWorkflowSession() {
		try {
			Session adminSession = repository.loginAdministrative(null);
			return workflowService.getWorkflowSession(adminSession);
		} catch (RepositoryException re) {
			log.error("RepositoryException: " + re);
		}
		return null;
	}
	
	private void createJiraContainer() {
		log.info("Creating: " + JiraServiceComponent.JIRA_CONTAINER_NODE_PATH);
		try {
			ResourceResolver resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			String parentPath = JiraServiceComponent.JIRA_CONTAINER_NODE_PATH.substring(0, JiraServiceComponent.JIRA_CONTAINER_NODE_PATH.lastIndexOf("/"));
			String childName = JiraServiceComponent.JIRA_CONTAINER_NODE_PATH.substring(JiraServiceComponent.JIRA_CONTAINER_NODE_PATH.lastIndexOf("/") + 1);
			
			Resource p = resolver.getResource(parentPath);
			Node n = p.adaptTo(Node.class);
			
			n.addNode(childName, "sling:OrderedFolder");
			n.save();
		} catch (Exception e) {
			log.error("Failed to create " + JiraServiceComponent.JIRA_CONTAINER_NODE_PATH, e);
		}
	}
	
	private void queueUpJira(HashMap<String,String> jiraData) {
		try {
			ResourceResolver resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			Resource resource = resolver.getResource(JiraServiceComponent.JIRA_CONTAINER_NODE_PATH);
			if(resource == null) {
				createJiraContainer();
				resource = resolver.getResource(JiraServiceComponent.JIRA_CONTAINER_NODE_PATH);
			}
			
			Node queue = resource.adaptTo(Node.class);
			
			long time = System.nanoTime();
			log.info("Creating: " + JiraServiceComponent.JIRA_CONTAINER_NODE_PATH + JiraServiceComponent.JIRA_NODE_PREFIX + time);
			Node jiraLog = queue.addNode(JiraServiceComponent.JIRA_NODE_PREFIX + time);
			
			for(String key : jiraData.keySet()) {
				jiraLog.setProperty(key, String.valueOf(jiraData.get(key)));
			}
			queue.save();
		} catch (Exception e) {
			log.error("Failed to persist Jira Info :" + jiraData, e);
		}
	}
}
