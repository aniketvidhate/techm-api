package com.att.ecom.cq.bundle.jiraservice;

import java.io.IOException;

import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.jiraservice.JiraServiceComponent;
import com.att.ecom.cq.bundle.jiraservice.JiraServiceException;

@SlingServlet(paths = "/system/jira/ajax")
public class JiraAjaxCallHandlerServlet extends SlingSafeMethodsServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger LOG = LoggerFactory.getLogger(JiraAjaxCallHandlerServlet.class);

	

	private static final String TRUE = "true";
	private static final String JIRAID = "jiraid";
	private static final String FALSE = "false";
	private static final String CMD = "cmd";
	private static final String VALID = "valid";
	private static final String INVALID = "invalid";
	
	@Reference
	private JiraServiceComponent jiraService;

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,	IOException {

		try {
			if(jiraService != null){
				if("1".equals(request.getParameter(CMD))){
					LOG.debug("Ajax call to verify if the JIRA ID entered exists in the JIRA system");
					String jiraId = request.getParameter(JIRAID);
					if (jiraService.doesJiraExist(jiraId)) {
						response.getWriter().println(VALID);
					}else{
						response.getWriter().println(INVALID);
					}	
				}else if("2".equals(request.getParameter(CMD))){			
					String workflowInstanceNode = request.getParameter("workflowInstanceNode");
					log("workflowInstanceNode: "+workflowInstanceNode);			
				}else if("3".equals(request.getParameter(CMD))){		
					LOG.debug("Ajax call to verify if the indicator in the OSGI Config JIRA service filter is enabled or disabled");
					if(JiraServiceComponent.isJIRAEnabled().equalsIgnoreCase(TRUE)){
						response.getWriter().println(TRUE);
					}else{
						response.getWriter().println(FALSE);
					}			
				}
			}else{
				LOG.debug("JIRA service is down!!!");
				response.getWriter().println(INVALID);
			}
			
		} catch (JiraServiceException e) {
			response.getWriter().println(e.getMessage());
		}	
	}	
}
