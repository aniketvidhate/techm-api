package com.att.ecom.cq.bundle.jiraservice;

/**
 * @author <a href="mailto:topping@codehaus.org">Brian Topping</a>
 * @version $Id$
 * @date 5/18/11 3:38 PM
 */

public class JiraServiceException extends Throwable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JiraServiceException() {
    }

    public JiraServiceException(Throwable cause) {
        super(cause);
    }

    public JiraServiceException(String message) {
        super(message);
    }

    public JiraServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
