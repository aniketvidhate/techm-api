package com.att.ecom.cq.bundle.workflow;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.PropertyIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.security.UserManagerFactory;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.collection.ResourceCollectionManager;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
/**
 * Sample workflow process that logs arguments into the logfile.
 */
@Component
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "ATT Clean up Process. Removes the node properties like validateonAuthor, validateonPrestg etc." ),
        @Property(name = Constants.SERVICE_VENDOR, value = "CMS - ATT"),
        @Property(name = "process.label", value = "ATT Cleanup Process")})
public class ATTCleanupProcess implements WorkflowProcess{

    /** @scr.reference */
    protected ResourceCollectionManager rcManager;
    
	/** Logger  */
	private static final Logger LOG = LoggerFactory.getLogger(ATTCleanupProcess.class);
	
	
	@Override
	public void execute(WorkItem item, WorkflowSession session, MetaDataMap metaDataMap) throws WorkflowException {		
		
		try {
			String path = item.getWorkflow().getWorkflowData().getPayload().toString();
			LOG.info("ATTCleanupProcess.execute: start");
			LOG.info("ATTCleanupProcess.execute: workflow-instance=" + item.getWorkflow().getId());			
			LOG.info("ATTCleanupProcess.execute: workflow-payload-type=" + item.getWorkflow().getWorkflowData().getPayloadType());			
			String arg = metaDataMap.get("PROCESS_ARGS", String.class);
	    	LOG.info("PROCESS_ARGS=", arg);
	    	if("workflow.init".equals(arg)) {	    		
	    		Session s = session.getSession();	    		
				Node payloadNode = s.getNode(path);
				LOG.info("ATTCleanupProcess.execute: workflow-payload=" + path);
				if(payloadNode.hasProperty("jcr:content/jiraid")) {
					payloadNode.getProperty("jcr:content/jiraid").setValue((String)null);
				}else{
					LOG.info("jcr:content/jiraid does not exist");
				}
				if(payloadNode.hasProperty("jcr:content/doyouhaveJira"))  {
					payloadNode.getProperty("jcr:content/doyouhaveJira").setValue((String)null);
				}else{
					LOG.info("jcr:content/doyouhaveJira does not exist");
				}
				if(payloadNode.hasProperty("jcr:content/jiracomment"))  {
					payloadNode.getProperty("jcr:content/jiracomment").setValue((String)null);
				}else{
					LOG.info("jcr:content/jiracomment does not exist");
				}
				if(payloadNode.hasProperty("jcr:content/userId"))  {
					payloadNode.getProperty("jcr:content/userId").setValue((String)null);
				}else{
					LOG.info("jcr:content/userId does not exist");
				}
				if(payloadNode.hasProperty("jcr:content/validateOnAuthor"))  {
					payloadNode.getProperty("jcr:content/validateOnAuthor").setValue((String)null);
				}else{
					LOG.info("jcr:content/validateOnAuthor does not exist");
				}
				if(payloadNode.hasProperty("jcr:content/validateOnPreStg"))  {
					payloadNode.getProperty("jcr:content/validateOnPreStg").setValue((String)null);
				}else{
					LOG.info("jcr:content/validateOnPreStg does not exist");
				}
				if(payloadNode.hasProperty("jcr:content/validateOnFinalStage"))  {
					payloadNode.getProperty("jcr:content/validateOnFinalStage").setValue((String)null);
				}else{
					LOG.info("jcr:content/validateOnFinalStage does not exist");
				}
				if(payloadNode.hasProperty("jcr:content/assignPreStgValidatorGroup"))  {
					payloadNode.getProperty("jcr:content/assignPreStgValidatorGroup").setValue((String)null);
				}else{
					LOG.info("jcr:content/assignPreStgValidatorGroup does not exist");
				}
				if(payloadNode.hasProperty("jcr:content/assignFinalStgValidatorGroup"))  {
					payloadNode.getProperty("jcr:content/assignFinalStgValidatorGroup").setValue((String)null);
				}else{
					LOG.info("jcr:content/assignFinalStgValidatorGroup does not exist");
				}
				if(payloadNode.hasProperty("jcr:content/workflowInitiator")) {
					payloadNode.getProperty("jcr:content/workflowInitiator").setValue((String)null);
				}else{
					LOG.info("jcr:content/workflowInitiator does not exist");
				}
				
				if(payloadNode.hasProperty("jcr:content/workflowcurrentstep")) {
					payloadNode.getProperty("jcr:content/workflowcurrentstep").setValue((String)null);
				}else{
					LOG.info("jcr:content/workflowcurrentstep does not exist");
				}
		        if(payloadNode.hasProperty("jcr:content/initiateactoruserid")) {
		        	payloadNode.getProperty("jcr:content/initiateactoruserid").setValue((String)null);
		        }else{
					LOG.info("jcr:content/initiateactoruserid does not exist");
				}
		        if(payloadNode.hasProperty("jcr:content/authoractoruserid")) {
		        	payloadNode.getProperty("jcr:content/authoractoruserid").setValue((String)null);
		        }else{
					LOG.info("jcr:content/authoractoruserid does not exist");
				}
		        if(payloadNode.hasProperty("jcr:content/prestageactoruserid")) {
		        	payloadNode.getProperty("jcr:content/prestageactoruserid").setValue((String)null);
		        }else{
					LOG.info("jcr:content/prestageactoruserid does not exist");
				}
		        if(payloadNode.hasProperty("jcr:content/finalstageactoruserid")) {
		        	payloadNode.getProperty("jcr:content/finalstageactoruserid").setValue((String)null);
		        }else{
					LOG.info("jcr:content/finalstageactoruserid does not exist");
				}
		        
		        if(payloadNode.hasProperty("jcr:content/productionDeploymentTimeFlag")) {
		        	payloadNode.getProperty("jcr:content/productionDeploymentTimeFlag").setValue((String)null);
		        }else{
					LOG.info("jcr:content/productionDeploymentTimeFlag does not exist");
				}
		        if(payloadNode.hasProperty("jcr:content/productionDeploymentTime")){
		        	payloadNode.getProperty("jcr:content/productionDeploymentTime").setValue((String)null);
		        }else{
					LOG.info("jcr:content/productionDeploymentTime does not exist");
				}			        
		        s.save();
	    	}
		} catch (Exception e) {
			LOG.error("ATTCleanupProcess.execute: Error while clean up.", e);
		}    	
    	LOG.info("ATTCleanupProcess.execute: end");
		
// TODO 
// This is commented as part of work done for sending customizable emails from workflow.
// as this is moved to part where emails are sent from.
// In next release workflow model needs to be changed to remove step, which uses this process. 		
		
//		String path = item.getWorkflowData().getPayload().toString();		
//		try {
//			Node jcrContentNode = (Node) session.getSession().getItem(path+ "/jcr:content");
//			log.info("Cleaning up properties jiraid,workflowInitiator, jiracomment, userId, validateOnAuthor, validateOnPreStg, validateOnFinalStage");
//			if(jcrContentNode.hasProperty("jiraid"))  jcrContentNode.getProperty("jiraid").setValue((String)null);
//			if(jcrContentNode.hasProperty("doyouhaveJira"))  jcrContentNode.getProperty("doyouhaveJira").setValue((String)null);
//			if(jcrContentNode.hasProperty("jiracomment"))  jcrContentNode.getProperty("jiracomment").setValue((String)null);
//			if(jcrContentNode.hasProperty("userId"))  jcrContentNode.getProperty("userId").setValue((String)null);
//			if(jcrContentNode.hasProperty("validateOnAuthor"))  jcrContentNode.getProperty("validateOnAuthor").setValue((String)null);
//			if(jcrContentNode.hasProperty("validateOnPreStg"))  jcrContentNode.getProperty("validateOnPreStg").setValue((String)null);
//			if(jcrContentNode.hasProperty("validateOnFinalStage"))  jcrContentNode.getProperty("validateOnFinalStage").setValue((String)null);
//			if(jcrContentNode.hasProperty("assignPreStgValidatorGroup"))  jcrContentNode.getProperty("assignPreStgValidatorGroup").setValue((String)null);
//			if(jcrContentNode.hasProperty("assignFinalStgValidatorGroup"))  jcrContentNode.getProperty("assignFinalStgValidatorGroup").setValue((String)null);
//			if(jcrContentNode.hasProperty("workflowInitiator"))  jcrContentNode.getProperty("workflowInitiator").setValue((String)null);
//			
//			if(jcrContentNode.hasProperty("workflowcurrentstep")) jcrContentNode.getProperty("workflowcurrentstep").setValue((String)null);
//	        if(jcrContentNode.hasProperty("initiatoractionuserid")) jcrContentNode.getProperty("initiatoractionuserid").setValue((String)null);
//	        if(jcrContentNode.hasProperty("authoractoruserid")) jcrContentNode.getProperty("authoractoruserid").setValue((String)null);
//	        if(jcrContentNode.hasProperty("prestageactoruserid")) jcrContentNode.getProperty("prestageactoruserid").setValue((String)null);
//	        if(jcrContentNode.hasProperty("finalstageactoruserid")) jcrContentNode.getProperty("finalstageactoruserid").setValue((String)null);
//			
//			session.getSession().save();
//			
//		} catch (PathNotFoundException e) {
//			e.printStackTrace();
//		} catch (RepositoryException e) {
		// e.printStackTrace();
		// }
	}

}
