/**
 * 
 */
package com.att.ecom.cq.bundle.workflow;

import com.att.ecom.cq.bundle.jiraservice.JiraGetIssue;
import com.att.ecom.cq.jirasoapservicev2.RemoteIssue;
import com.att.ecom.cq.bundle.jiraservice.JiraServiceException;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.Constants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

/**
 * @author rx1755
 * <code>JiraManager</code> creates or updated jira issue
 */
@Component
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "Jira Close Issue."),
        @Property(name = Constants.SERVICE_VENDOR, value = "ATT"),
        @Property(name = "process.label", value = "Jira Close Issue")})
public class JiraCloseIssue implements WorkflowProcess {
	
	private Logger logger = LoggerFactory.getLogger(JiraIssueManager.class);
    private static final String TYPE_JCR_PATH = "JCR_PATH";

    public void execute(WorkItem item, WorkflowSession session, MetaDataMap args) throws WorkflowException {
    	
    	System.out.println("Testing custom workflow");
        WorkflowData workflowData = item.getWorkflowData();
        if (workflowData.getPayloadType().equals(TYPE_JCR_PATH)) {
            String path = workflowData.getPayload().toString() + "/jcr:content";
            try {
                Node node = (Node) session.getSession().getItem(path);
                JiraGetIssue service = new JiraGetIssue();
                
    	    	service.setupService("teamsite", "password");
     	    		
                if (node != null) {
                    node.setProperty("approved", readArgument(args));
                    session.getSession().save();
                }
                     	    	
//    	    	RemoteIssue issue = service.lookupIssue("CMS-325");
//    	    	System.out.println("Issue:"+issue);
    	    	
//    	    	if(issue != null ){
//    	    		System.out.println("Issue Exists:"+issue.getDescription());
//    	    	} else {
    	    		//RemoteIssue issue = service.createIssue("CMS","6","Test jira creation ","13","10071","1");
                	RemoteIssue issue = service.changeStatusToCloseIssue("CMS-343");    	    		 	    		
//    	    	}
            	            	
            } catch (RepositoryException e) {
                throw new WorkflowException(e.getMessage(), e);
            } 
            catch (JiraServiceException e) {            	
            	logger.info("The JiraServiceException is:"+e);
            }
        }
    }

    private boolean readArgument(MetaDataMap args) {
        String argument = args.get("PROCESS_ARGS", "false");        
        return argument.equalsIgnoreCase("true");
    }

}
