var dynamicSocialMedia = (function ($) { 
    'use strict'; 
    return function (meteorCampaignKey, size, socialmediatext, orientation) { 
        $.cachedScript = function (url) { 
			 return $.ajax({
	                        url: url,
	                        cache: true,
	                        crossDomain: true,
	                        dataType: 'script'
	                    });
        }; 

        $.cachedScript('//cdnt.meteorsolutions.com/metsol.js') 
            .done(function () { 
 				 $.cachedScript('//cdnt.meteorsolutions.com/metshare.js')
	                       .done(function() {
								meteor.tracking.track(meteorCampaignKey, { 'url_storage_source': 'hash', 'query_string_tag_key': ['mtag', 'source', 'src'] });
								meteor.orion.init();

	                           var ShareToolConfig = {
	                              'id': '1',
	                            'parentID': 'socialMedia',
                                  'size': size,
                                 'sites': socialmediatext,
                                'orientation': orientation 
	                           };
	                           meteor.sharing.superbar.init(ShareToolConfig);
	                       });
            }); 
    }; 
}(jQuery));
