
// Date: 2-13-2015
// Version: 3.0
// Notes: This is modify version of the original reportingManager module. You should not have to add or modify this file.
// ATT.wtReportingFW.capture(); You don't have to pass anything. It will send to webtrend for only the tag included in this framework.
// ATT.wtReportingFW.capture({wtParam:'wtSuccessFlag=1,wtEvent=submit_success'); 
// ATT.wtReportingFW.capture({wtParamObj:{wtSuccessFlag:1, wtEvent:'submit_success'}, wtCapture:false, wtCallBack:$rootScope.myCallBack}); 
// ATT.wtReportingFW.loadCommonTags('DCSext.wtSuccessFlag','-2','DCSext.wtNoHit','1','DCSext.wtCustType','consumer','DCSext.wtCartType','eCommerce');
//   wtParam = Additional webtrend tag you need to add to it. A string that have key value pair separate by comma.
//   wtParamObj = Additional webtrend tag you need to add to it. A Obj that have key value pair.
//   wtExclude = A webtrend tag in the framework that you don't want to send to webtrend. A string that have the key.
//   wtCapture = Pass a true or false value. The default is true. False value will not submit the webtrend tag for this event.
//   func = Pass in the $rootScope function name. It runs your function.
//   wtActionSave = This will save the tag for later use.
//   wtActionUse = This will use the save tag to send to webtrend.
//	 wtCallBack = This is for call back function on the next page.
// 
//********************

(function(){
    'use strict';
	angular.module('reportingManager', ['ngCookies'])

	
	.run(function($rootScope, reporting, $window) {
		if (typeof $window.ddo === "undefined") {
			reporting.init();
		}
	})

	.factory("reporting", function($rootScope, $cookies, $window, $log, $q, Env) {
		var services = {}, v_dcsua = ((navigator) ? navigator.userAgent : ''),
			wtArgsDefault = {}, wtDataInfo = {wtParamObj:{}, wtAction:{}, urlPath:window.location.pathname, wtCallBackName: null, wtCapture:null},
			vs_wtStorageName = 'wtShopData', vs_onStorageName = 'wtOnStatus', vs_wtDCSext='DCSext.', vs_funcInfo = 'reporting service in reportingManger module v2.0',
			v_wtSuccss=1, v_wtFail=0, v_wtUserCancel=-1, v_wtUnknown=1, v_wtSuccessFlag='DCSext.wtSuccessFlag',v_wtZipCode='', v_wtBrowserid='',
			initialPageLoad=true;
		
		if (typeof $window.ddo === "undefined") {
			if (sessionStorage.profile != undefined) {
				if (angular.fromJson(sessionStorage.profile).profile) v_wtZipCode = angular.fromJson(sessionStorage.profile).profile.zipCode;
			}
			if ($cookies.browserid) v_wtBrowserid = $cookies.browserid;

			wtArgsDefault["DCS.dcsref"] = window.location.href;
			wtArgsDefault["DCS.dcsua"] = v_dcsua;
			wtArgsDefault["DCSext.WT.es"] = 'www.wireless.att.com';
			if (v_wtBrowserid != '') {
				wtArgsDefault["DCSext.browserid"] = v_wtBrowserid;
			}
			if (v_wtZipCode != '') {
				wtArgsDefault["DCSext.wtZipCode"] = v_wtZipCode;
			}
		}
		
		if (!String.prototype.trim) {
			String.prototype.trim = function () {
				return this.replace(/^\s+|\s+$/g, '');
			};
		}		
		
		function stringToBoolean(pStr) {
			var vStr = pStr.toLowerCase();
			return ((vStr == 'false') ? false : ((vStr == 'true') ? true : null));
		}
		
		function getReportingData (pObj) {
			var wtargsLocal = JSON.parse(JSON.stringify(wtArgsDefault)), v_obj=pObj;

			for (var key1 in wtDataInfo.wtParamObj) {
				if (wtDataInfo.wtParamObj.hasOwnProperty(key1)) {
					wtargsLocal[key1] = wtDataInfo.wtParamObj[key1];
				}
			}
			
			if (typeof v_obj != "undefined") {
				var vKeyValuePair = null, v_WTstr = '', v_wtParamObj = {}; 

				if (v_obj.wtParam != undefined) {
					v_WTstr += ((v_WTstr == '') ? '' : ',') + v_obj.wtParam;
				}
				
				if (v_obj.wtParamObj != undefined) {
					v_wtParamObj = v_obj.wtParamObj;
				}				

				if (typeof pObj.func == 'function') {
					var vDataObj = pObj.func();
					for (var key2 in vDataObj.wtParamObj) {
						if (vDataObj.wtParamObj.hasOwnProperty(key2)) {
							v_wtParamObj[key2] = vDataObj.wtParamObj[key2];
						}
					}
					if (vDataObj.wtParam != undefined) {
						v_WTstr += vDataObj.wtParam;
					}
				}
				
				if (v_obj.wtCallBack != undefined) {
					wtDataInfo.wtCallBackName = v_obj.wtCallBack;
				}
				
				if (v_obj.wtActionUse != undefined) {
					if (wtDataInfo.wtAction[v_obj.wtActionUse] != undefined) { 
						wtargsLocal = wtDataInfo.wtAction[v_obj.wtActionUse];
					}
				}
				
				if (v_wtParamObj != undefined) {
					for (var key in v_wtParamObj) {
						if (v_wtParamObj.hasOwnProperty(key)) {
							wtargsLocal[vs_wtDCSext + key] = v_wtParamObj[key];
						}
					}
				}

				if (v_WTstr != '' && v_WTstr != null) {
					vKeyValuePair = v_WTstr.split(',');
					for (var i=0; i<vKeyValuePair.length; i++) {
						var pTempArray1 = vKeyValuePair[i].split('=');
						wtargsLocal[vs_wtDCSext + pTempArray1[0]] = pTempArray1[1];
					}
				}

				if (v_obj.wtExclude != undefined) {
					var tempData = v_obj.wtExclude.split(',');
					for (var i=0; i<tempData.length; i++) {
						delete wtargsLocal[tempData[i]];
					}
				}

				if (v_obj.wtActionSave != undefined) {
					wtDataInfo.wtAction[v_obj.wtActionSave] = wtargsLocal
				}
				
				if (wtDataInfo.wtCapture == false) {
					wtDataInfo.wtParamObj = wtargsLocal;
				}
				saveToStorage(vs_wtStorageName, wtDataInfo);
			}
			return wtargsLocal;
		} // end getReportingData

		function performCapture (pObj) {
			var ret_value = true;
			if (pObj != undefined) {
				if (pObj.wtCapture != undefined) {
					ret_value = pObj.wtCapture;
				} else if (pObj.htmlElement != undefined) {
					if (pObj.htmlElement.getAttribute('data-wtCapture') != null) {
						ret_value = pObj.htmlElement.getAttribute('data-wtCapture');
					}
				}
				if (typeof ret_value == 'string') {
					ret_value = stringToBoolean(ret_value);
					if (ret_value == null) ret_value = true;
				}
			}
			return ret_value;
		}

		function getCookie(name) {
				var nameEQ = name + '=', i, c, 
					cookies = document.cookie.split(';');
				for(i=0; i < cookies.length; i+=1) {
					c = cookies[i];
					while (c.charAt(0)===' '){
						c = c.substring(1,c.length);
					}
					if (c.indexOf(nameEQ) === 0){
						return c.substring(nameEQ.length, c.length);
					}
				}
				return null;
		};

		function setCookie(name, value, days) {
				var expires, nameEQ = name + '=';
				if (days) {
					var date = new Date();
					date.setTime(date.getTime() + (days*24*60*60*1000));
					expires = '; expires=' + date.toGMTString();
				} else { 
					expires = '';
				}
				document.cookie = nameEQ + value + expires + '; path=/';
		}
		
		function saveToStorage (pName, pParam) {
			if (typeof(sessionStorage)!="undefined")	{
				sessionStorage[pName] = JSON.stringify(pParam);
			} else {
				setCookie(pName, JSON.stringify(pParam));
			}
		}

		function showStorage (pStr) {
			var v_sessionData, vStr = ((pStr == undefined) ? vs_wtStorageName : pStr);
			if (typeof(sessionStorage)!="undefined") {
				v_sessionData = sessionStorage[vStr];
			} else {
				v_sessionData = getCookie(vStr);				
			}
			if (v_sessionData != undefined) {
				v_sessionData = JSON.parse(v_sessionData);
			}
			return v_sessionData;
		}

		function removeFromStorage (pStr) {
			if (typeof(sessionStorage)!="undefined")	{
				sessionStorage.removeItem(pStr);
			} else {
				setCookie(pStr, '', -1);
			}
		}
		
		function isFunctionEmpty(f) {
			if (typeof f === "function") {
				var ret_value=false, v_str = '';
				v_str = f.toString().match(/\{([\s\S]*)\}/m)[1]; // get body of function
				v_str = v_str.replace(/(\/\*([\s\S]*?)\*\/)|(\/\/(.*)$)/gm, ''); // remove comment
				v_str = v_str.trim();
				if (v_str == '') ret_value = true;
				return ret_value;
			}
		}
		
		function objToArray(pObj) {
			var wtParamObj = pObj, wtArgArray = [];
			for (var key in wtParamObj) {
				if (wtParamObj.hasOwnProperty(key)) {
					wtArgArray.push(key);
					wtArgArray.push(wtParamObj[key]);
				}
			}
			return wtArgArray;
		}

		function onLoadCapture (pParam) {
			var t = services;
			if (t.isReportingOn()) {
				if (wtDataInfo.wtCapture == false) {
					wtDataInfo.wtCapture = true;
					if (wtDataInfo.wtCallBackName != null) {
						if (window[wtDataInfo.wtCallBackName]) {
							var v_callbackData = window[wtDataInfo.wtCallBackName]();
							var dataObj = {wtParam:v_callbackData, wtParamObj:{wtSuccessFlag:(pParam==false?v_wtFail:v_wtSuccss)}}
							if (v_callbackData) {
								t.capture(dataObj);
							}
							wtDataInfo.wtCallBackName = null;
							wtDataInfo.wtParamObj = {};
							saveToStorage(vs_wtStorageName, wtDataInfo);
						}
					}
				}
			}
		} //end of onLoadCapture
		
		services.getCookie = getCookie;
		services.setCookie = setCookie;
		services.info = vs_funcInfo;

		services.isReportingOn = function (pParam) {
			var ret_value=true;
			if (pParam == undefined) {
				ret_value = showStorage(vs_onStorageName);
				ret_value = (ret_value == undefined)? true : ((ret_value.toLowerCase() == 'false') ? false : true);
			} else {
				if (typeof pParam == 'boolean') {
					saveToStorage(vs_onStorageName, pParam);
					ret_value = pParam;
				}
			}
			return ret_value;
		} // end of isReportingOn

		services.showCommonTag = function () {
			return wtArgsDefault;
		}

		services.loadCommonTags = function () {
			var v_wtDCSext;
			if ((arguments.length == 1) && (typeof arguments[0] == "object")) {
				var wtParamObj = arguments[0];
				for (var key in wtParamObj) {
					if (wtParamObj.hasOwnProperty(key)) {
						v_wtDCSext = '';
						if (key.indexOf('DCS.') == -1) {
							v_wtDCSext = vs_wtDCSext;
						}
						wtArgsDefault[v_wtDCSext + key] = wtParamObj[key];
					}
				}
			} else {
				for (var i=0; i<arguments.length; i=i+2) {
					v_wtDCSext = '';
					if (arguments[i].indexOf('DCS.') == -1) {
						v_wtDCSext = vs_wtDCSext;
					}
					wtArgsDefault[v_wtDCSext + arguments[i]] = arguments[i+1];
				}
			}
		} // end of loadCommonTags

		services.capture = function (pObj) {
			var wtargs;
			if (this.isReportingOn()) {
				wtDataInfo.wtCapture = performCapture(pObj);
				wtargs = getReportingData(pObj);
				if (wtDataInfo.wtCapture) {
					if (typeof dcsMultiTrack == 'function') {
						if (! isFunctionEmpty(dcsMultiTrack)) {				
							dcsMultiTrack.apply(this, objToArray(wtargs));
						}
					}
				}
			}
		} // end of capture

		services.init = function init () {
			var v_sessionData = showStorage(), vBoolean = true; 
			if (v_sessionData != undefined) {
				wtDataInfo = v_sessionData;
				if (wtDataInfo.urlPath == window.location.pathname) {
					var vBoolean = false;
				}
			} 			
			onLoadCapture(vBoolean);
		} // end of init
		

		services.reportData = {};
		services.reportData.reports = {};
		services.reportData.reportItems = {};
		services.reportData.reportGroups = {};
		services.reportData.deferred =  {};
		services.reportData.respUrlReportMap = {};
		services.reportData.respUrlReportUpdateMap = {};
		
		services.reportItem = function (reportItemName /* string */, value /* string, function, object {name:string,value:string,function}*/) {
			/*
			A reportItem is a bit of logic that knows how to return a webtrends tag and it's value.
			reportItem value argument can take 4 forms. They can be a string, or a function that returns a string value.
			reportItem values can also be an object that has this form: {name:"someName",value:"someValue"} or
			{name:"someName",value:someValueFunction}.  The object forms allow for different reports in the $rootScope
			to return the same webtrends tag with different values.  For instance, wtPN will need many different
			value functions or strings to return the same tag to webtrends, so reportItem "SaveCartPgView" can still return "wtPN=HRUverse SaveCart Modal Page" 
			on the dcsMultiTrack. Or reportItem "saveCartSubmit" will return "wtEvent=HRUVerse_Cart_SaveCart_Submit" 
			in the dcsMultiTrack from the reportItem value object. If the object is not used then the reportItemName will be used as 
			the tag name for dcsMultitrack.
			
			When valueFunctions are reported they will be called with two parameters: interaction and contextObj.
			interaction is "user" or "system", this allows the reportItem to know if the report is getting triggered from DOM event or REST API
			contextObject for "user" interaction has
				{"event":event,"scope":scope,"element":element,"attr":attr} where event is the browser event.
			contextObject for "system" interaction returns the full REST response object.
			This allows reportItem to be created with more reuse between reports.
			*/
			services.reportData.reportItems[reportItemName] = value;
		}
		
		services.report = function (reportName, reportItems) {
			/*
			A report is simply an array of reportItems that will fire when the att-report or ATT_REPORT_RESP is received. 
			This is not to be confused with the wtEvent tag, which will be returned by a reportItem associated to the report.
			*/
			services.reportData.reports[reportName] = reportItems;
		}
		
		services.reportGroup = function (groupName, reportItems) {
			/*
			A report group is an array of reportItems that can be set or retrieved for convenience.
			*/
			if (reportItems === undefined) {
				return services.reportData.reportGroups[groupName];
			} else {
				services.reportData.reportGroups[groupName] = reportItems;
			}
		}
		
		services.reportSystemResp = function (reportName, url) {
			services.reportData.respUrlReportMap[url] = reportName;
		}
		
		services.updateSystemResp = function (reportName, url) {
			services.reportData.respUrlReportUpdateMap[url] = reportName;
		}
		
		services.reportDefer = function(reportName) {
			var dfd = $q.defer();
			if (services.reportData.deferred[reportName] === undefined) {
				services.reportData.deferred[reportName] = [];
			}
			services.reportData.deferred[reportName].push(dfd.promise);
			return dfd;
		};
		
		services.cache = function(key, val) {
			key = key.replace(".", "_");
			if (val === undefined) {
				return angular.fromJson($window.sessionStorage['sales_rpt_'+key]);
			} else {
				$window.sessionStorage['sales_rpt_'+key] = angular.toJson(val);
				return val;
			}
		}
		
		services.sendReport = function(reportName, interaction, contextObj, updateOnly) {
			var i, eventAction = "unknown", eventCode, fire = {}, reportItems = services.reportData.reports[reportName], reportItem, rptResp = "not set by ddo.pushEvent()", forceBeacon = false, forceBeaconAction, forceBeaconEventCode;
			fire.wtParamObj = {};
			
			if (reportItems !== undefined) {
				services.reportDefer(reportName).resolve();
				for (i=0; i < reportItems.length; i++) {
					reportItem = services.reportData.reportItems[reportItems[i]];
					if (typeof reportItem === "string") {
						fire.wtParamObj[reportItems[i]] = reportItem;
					} else if (typeof reportItem === "function") {
						fire.wtParamObj[reportItems[i]] = reportItem(interaction, contextObj);
						if (fire.wtParamObj[reportItems[i]] !== undefined && typeof fire.wtParamObj[reportItems[i]].then === "function") {
							fire.wtParamObj[reportItems[i]].then(function(x) {fire.wtParamObj[x.name]=x.value;});
							services.reportData.deferred[reportName].push(fire.wtParamObj[reportItems[i]]);
						}
					} else if (typeof reportItem === "object") {
						if (typeof reportItem.value === "string") {
							fire.wtParamObj[reportItem.name] = reportItem.value;
						} else if (typeof reportItem.value === "function") {
							fire.wtParamObj[reportItem.name] = reportItem.value(interaction, contextObj);
							if (fire.wtParamObj[reportItems[i]] !== undefined && typeof fire.wtParamObj[reportItem.name].then === "function") {
								fire.wtParamObj[reportItem.name].then(function(x) {fire.wtParamObj[x.name]=x.value;});
								services.reportData.deferred[reportName].push(fire.wtParamObj[reportItem.name]);
							}
						}
					} 
				}
				
				$q.all(services.reportData.deferred[reportName]).then(function() {
					if (updateOnly) {
						return;
					} else if (services.isReportingOn() && typeof $window.ddo !== "undefined") {
						if (fire.wtParamObj.eventAction !== undefined) {
							eventAction = fire.wtParamObj.eventAction;
							delete fire.wtParamObj.eventAction;
						}
						if (fire.wtParamObj.eventCode !== undefined) {
							eventCode = fire.wtParamObj.eventCode;
							delete fire.wtParamObj.eventCode;
						} else {
							eventCode = reportName;
						}
						forceBeaconEventCode = "page loaded manually";
						if (eventAction === "pageLoad") {
							forceBeacon = true;
							eventAction = "systemEvent";
							forceBeaconAction = (initialPageLoad) ? "pageLoad" : "virtualPageLoad";
						} else if (eventAction === "virtualPageLoad") {
							forceBeacon = true;
							eventAction = "systemEvent";
							forceBeaconAction = "virtualPageLoad";
						} else if (eventAction === "modalLoad") {
							forceBeacon = true;
							eventAction = "systemEvent";
							forceBeaconAction = "modalLoad";
							forceBeaconEventCode = "Modal Window";
						} else if (eventAction === "formResponse") {
							forceBeacon = true;
							forceBeaconAction = (initialPageLoad) ? "pageLoad" : "virtualPageLoad";
						} else {
							forceBeaconAction = (initialPageLoad) ? "pageLoad" : "virtualPageLoad";
						}
						rptResp = $window.ddo.pushEvent(eventAction, eventCode, fire.wtParamObj);
						$log.debug("Reporting pushEvent for reportName " + reportName + ":");
						$log.debug(rptResp);
						// force beacon by using "pageLoad" eventAction / "page loaded manually" eventCode
						if (initialPageLoad) {
							initialPageLoad = false;
						}
						if (forceBeacon) { // wait for formResponse to send beacon
							$window.ddo.pushEvent(forceBeaconAction, forceBeaconEventCode);
						}
					} else {
						services.capture(fire); //wt fallback
					}
				});
			}
		}
		
		$rootScope.$on("ATT_REPORT_RESP", function(scope, resp) {
			var mapUrl = resp[0].config.url;
			angular.forEach(services.reportData.respUrlReportUpdateMap, function(val, key) {
				if (mapUrl.indexOf(key) > -1) {
					services.sendReport(val, "system", resp[0], true);
				}
			});
			angular.forEach(services.reportData.respUrlReportMap, function(val, key) {
				if (mapUrl.indexOf(key) > -1) {
					services.sendReport(val, "system", resp[0], false);
				}
			});
		});
		
		return services;
	})
	
	.directive("attReport", function($document, $rootScope, reporting, $log, $timeout, $window) {
		/* 
		att-report can be in two forms (e.g.): att-report="HR_UVerse_Cart_Submit" or att-report="keydown->HR_UVerse_Cart_Submit" 
		the first form is a convenience form for "click|enter->reportName".  att-report="view->reportName|{#,*}"
		with views the reportName can followed by a pipe ("|") and a positive integer or *. This is how far up the DOM the view
		will check that it is showing.  So for a base page, that should be set to "|0". If you have a popover that that has
		different views that also hide and show, then you might set it at "|5", if the depth is unknown or will likely change 
		then the pipe can be omitted or can be "|*" and the recursion will check all the way to the html tag.
		*/
		return function(scope, element, attr) {
			var reportName,
				eventTriggers = [],
				splitArr = [],
				depth = "*",
				updateOnly=false;
			function elementDisplaying(el) {
				el = angular.element(el);
				return (el.css("display") !== "none" && el.css("visibility") !== "hidden");
			}
			function ancestorsAllDisplaying(el, depth) {
				var parent = angular.element(el.parentElement);
				if (depth === 0 || parent[0].parentElement === null) {
					return true;
				} else if (!elementDisplaying(parent)) {
					return false;
				} else {
					if (depth !== "*") {
						depth-=1;
					}
					return ancestorsAllDisplaying(parent[0], depth);
				}
			}
			splitArr = attr["attReport"].split("->");
			if (splitArr.length === 2) {
				reportName = splitArr[1];
				eventTriggers = splitArr[0];
			} else {
				reportName = attr["attReport"];
				eventTriggers = "click|enter";
			}
			if (eventTriggers.indexOf("view") > -1) {
				splitArr = reportName.split("|");
				if (splitArr.length === 2) {
					reportName = splitArr[0];
					depth = splitArr[1];
					if (depth !== "*") {
						depth = $window.Math.abs(parseInt(depth, 0));
					}
				}
			}
			if (reportName.indexOf("|update") > -1) {
				reportName = reportName.split("|")[0];
				updateOnly = true;
			}
			angular.forEach(eventTriggers.split("|"), function(eventTrigger) {
				if (eventTrigger !== "view") {
					// set up listener on element
					// "enter" pseudo event for enter key being pressed
					if (eventTrigger==="enter") {
						element.on("keyup", function(event) {
							$log.debug(eventTrigger + " on element with reporting event: " + reportName);
							if (event.keyCode === 13) {
								reporting.sendReport(reportName, "user", {"event":event,"scope":scope,"element":element,"attr":attr}, updateOnly);
							}
						});
					} else {
						element.on(eventTrigger, function(event) {
							$log.debug(eventTrigger + " on element with reporting event: " + reportName);
							reporting.sendReport(reportName, "user", {"event":event,"scope":scope,"element":element,"attr":attr}, updateOnly);
						});
					}	
				} else {
					// "view" pseudo event fires when an element becomes visible (like a modal)
					// "view": need to watch element is showing (display != "none" && visibility != "hidden") ..
					$document.ready(function() {
						if (elementDisplaying(element[0]) && ancestorsAllDisplaying(element[0], depth)) {
							// its showing now, report it
							reporting.sendReport(reportName, "view", {"scope":scope,"element":element,"attr":attr});
						}
						// watch element for state change from not showing to showing
						$rootScope.$watch(function() {
							return (elementDisplaying(element[0]) && ancestorsAllDisplaying(element[0], depth));
						}, function(newValue, oldValue) {
							//check for not showing to showing
							if (oldValue == false && newValue === true) {
								reporting.sendReport(reportName, "view", {"scope":scope,"element":element,"attr":attr});
							}
						});
					});
				}
			});
			
		}
	})

	.directive("attLinkClick", function($document, $rootScope, reporting, $log, $timeout, $window) {
		/* 
		att-link-click is a directive on the body tag that enables capturing event bubbling of anchor clicks on the page in order to 
		send the default linkClick pushEvent. It will not fire on an anchor with att-report directive on it already.
		*/
		
		
		return function(scope, element, attr) {
			function isAnchor(el) {
				return ((el.tagName === "A" && angular.element(el).attr("att-report") === undefined) || angular.element(el).attr("att-report") === "linkClick");
			}
			function isInsideAnchor(el) {
				var parent = angular.element(el.parentElement);
				if (parent[0] == null || parent[0].tagName === "DIV" || parent[0].tagName === "LI" || parent[0].tagName === "BODY" || parent[0].tagName === "HTML" || angular.element(parent[0]).attr("att-report") === "linkClick") {
					return false;
				} else if (isAnchor(parent[0])) {
					return true;
				} else {
					return isInsideAnchor(parent[0]);
				}
			}
			if ($window.ddo !== undefined) {
				element.on("click", function(event) {
					var tgt = event.target;
					if (isAnchor(tgt) || isInsideAnchor(tgt)) {
						reporting.sendReport("linkClick", "user", {"element": tgt});
					}
				});
				/*
				element.on("keyup", function(event) {
					var tgt = event.target;
					if (event.keyCode === 13) {
						if (isAnchor(tgt) || isInsideAnchor(tgt)) {
							reporting.sendReport("linkClick", "user", {"element": tgt});
						}
					}
				});
				*/
			}
		}
	})
	
	// include att-link-click directive works only on ddo-enabled pages
	.config(function() {
		var body = angular.element("body")[0];
		angular.element(body).attr("att-link-click", "");
	})
	
	.run(function(reporting, $window, Profile) {
		// default linkClick and pushEvent reportItems
		reporting.report("linkClick", ["linkName", "linkPosition", "linkClick-eventAction"]);
		
		reporting.reportItem("linkName", function(interaction, contextObj) {
			function checkChildren(el) {
				// TODO: check inner element for IMG and return ALT text or return false
				return false;
			}
			return angular.element(contextObj.element).attr("data-linkName") || contextObj.element.innerText || checkChildren(contextObj.element);
		});
		
		reporting.reportItem("linkPosition", function(interaction, contextObj) {
			function checkPosition(el) {
				if (el === undefined) {
					return "";
				}
				if (el.parentElement === null) {
					return "Body";
				}
				var parent = angular.element(el.parentElement);
				if (parent.attr('id') === 'main-container') {
					return "Body";
				} else if (parent.attr('id') === 'ge5p_z1' || parent.attr('id') === 'ge5p_z2') {
					return "GLBN";
				} else if (parent.hasClass('undernav')) {
					return "SubNav";
				} else if (parent.attr('id') === 'right-rail') {
					if (parent.hasClass('primary-content')) {
						return "Body";
					}
					return "RightNav";
				} else if (parent.attr('id') === 'left-rail') {
					if (parent.hasClass('primary-content')) {
						return "Body";
					}
					return "LeftNav";
				} else if (parent.hasClass('linkFarm')) {
					return "LinkFarm";
				} else if (parent.hasClass('footer-container')) {
					return "Footer";
				} else {
					return checkPosition(parent[0]);
				}
			}
			return checkPosition(contextObj.element);
		});
		
		reporting.reportItem("linkClick-eventAction", {
			name: "eventAction",
			value: "linkClick"
		});
		
		// default action event params
		reporting.reportItem("successFlag", function(interaction, contextObj) {
			if (interaction === "user") {
				if (contextObj.element[0].innerText.toLowerCase() === "cancel" || contextObj.element[0].innerText.toLowerCase() === "back" || contextObj.element[0].innerText.toLowerCase() === "exit") {
					return "-1"; // user cancel
				} else {
					return "-2"; // unknown
				}
			}
			if (interaction === "system") {
				if (contextObj.data.wbfcResponse !== undefined) {
					if (contextObj.data.wbfcResponse.statusCode == 600) {
						return "1"; // success
					} else {
						return "0"; // failure
					}
				} else {
					return "-2"; //unknown
				}
			}
			if (interaction === "view") {
				return "1";
			}
		});
		reporting.reportItem("successFlag1", {name:"successFlag", value:"1"});
		reporting.reportItem("successFlag0", {name:"successFlag", value:"0"});
		reporting.reportItem("successFlag-1", {name:"successFlag", value:"-1"});
		reporting.reportItem("successFlag-2", {name:"successFlag", value:"-2"});
		reporting.reportItem("statusCode", function(interaction, contextObj) {
			var errorCodes = [], elmTxt;
			if (interaction === "user") {
				elmTxt = angular.element(contextObj.element[0]).text().toLowerCase();
				if (elmTxt === "cancel" || elmTxt === "back" || elmTxt === "exit") {
					return "-1"; // user cancel
				} else {
					return "-2"; // unknown
				}
			} 
			if (interaction === "system") {
				if (contextObj.data.wbfcResponse !== undefined) {
					if (contextObj.data.wbfcResponse.statusCode == 600) {
						return "0"; // success
					} else {
						angular.forEach(contextObj.data.wbfcResponse.serviceErrors, function(error) {
							errorCodes.push(error.errorCode);
						});
						angular.forEach(contextObj.data.wbfcResponse.inputErrors, function(error) {
							errorCodes.push(error.errorCode);
						});
						return errorCodes;
					}
				} else {
					return "-2"; // unknown
				}
			}
			if (interaction === "view") {
				return "0";
			}
		});
		reporting.reportItem("statusCode0", {name:"statusCode", value:"0"});
		reporting.reportItem("statusCode-1", {name:"statusCode", value:"-1"});
		reporting.reportItem("statusCode-2", {name:"statusCode", value:"-2"});
	});

		
})();