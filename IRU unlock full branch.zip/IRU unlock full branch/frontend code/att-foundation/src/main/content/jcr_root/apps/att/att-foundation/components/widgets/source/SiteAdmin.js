CQ.Ext.namespace("ATT", "ATT.wcm");

ATT.wcm.SiteAdmin = {
	selectCurrentProject : function() {
		var nwindowobj=CQ.Ext.getCmp("idselectCurrentProject");
		if(nwindowobj !=null){
    		nwindowobj.close();
    	}
    	var path="";
    	var type="";
    	var tagthispage=false;
    	var admin = CQ.Ext.getCmp(window.CQ_SiteAdmin_id);
	 
	    if (admin) {	
		   var selections = admin.getSelectedPages();
			// TODO currently only works for 1 selected page
			for (var i=0; i<selections.length; i++) {
				var isAsset = selections[i].get && selections[i].get("type") == "dam:Asset";
				var isPage = selections[i].get && selections[i].get("type") == "cq:Page";
				if((isAsset)||(isPage)){
					path=selections[i].id;
					type=(isPage) ? "Page" : "Asset";
					if(selections.length == 1){
						tagthispage=true;
					}
					else{
						CQ.Ext.Msg.alert('Warning', 'You have seleted more than 1 ' + type + 's.' + '<br/>Currently Tag This ' + type + ' only works for 1 selected ' + type + '.');
						return;
					}	
				}	
				break;	
			}
	    }	
		
		var currentValue = ATT.wcm.CurrentProject.getCookie();
		if(tagthispage){
			 new ATT.wcm.CurrentProject.changeProjectTagDialog({
		            "value" : ATT.wcm.CurrentProject.getCookie(),
		            "id":"idselectCurrentProject",
					"path":path,
					"type":type,
					"project":ATT.wcm.Sidekick.projectTagInPage(path),
		            "projectSelected" : function(projectName) {
		                if(projectName==""){	
		                	ATT.wcm.CurrentProject.deleteCookie();
		                }
		                else{
		                	ATT.wcm.CurrentProject.setCookie(projectName);
		                }
		            	ATT.wcm.SiteAdmin.updateCurrentProjectSelectorMenuItem(projectName);
		                CQ.Notification.notify(CQ.I18n.getMessage("Project Selected"), CQ.I18n.getMessage("Current project selection changed."));
		                admin.reloadPages();
		            }
		        }).show();
		}
		else{
			new ATT.wcm.CurrentProject.SelectProjectDialog({
				"value" : ATT.wcm.CurrentProject.getCookie(),
				"id":"idselectCurrentProject",
				"projectSelected" : function(projectName) {
					if(projectName==""){	
	                	ATT.wcm.CurrentProject.deleteCookie();
	                }
	                else{
	                	ATT.wcm.CurrentProject.setCookie(projectName);
	                }	
					ATT.wcm.SiteAdmin.updateCurrentProjectSelectorMenuItem(projectName);
					CQ.Notification.notify(CQ.I18n.getMessage("Project Selected"), CQ.I18n.getMessage("Current project selection changed."));
				}
			}).show();
			
		}
	},
	
	updateCurrentProjectSelectorMenuItem : function(projectName) {
		var admin = CQ.Ext.getCmp(window.CQ_SiteAdmin_id);
		var cmp = CQ.Ext.getCmp("cq-siteadmin-att-currentproject");
		if (cmp) {
			cmp.setText(ATT.wcm.CurrentProject.getCurrentProjectActionLabel(projectName,admin.id));
		}
	}
		
}

CQ.utils.WCM.addEvents("siteadminready");

CQ.WCM.on("siteadminready", function(siteadmin) {
	var currentValue = ATT.wcm.CurrentProject.getCookie();
	if (currentValue) {
		ATT.wcm.SiteAdmin.updateCurrentProjectSelectorMenuItem(currentValue);
	}
	else{
		ATT.wcm.SiteAdmin.updateCurrentProjectSelectorMenuItem("");
	}
	
});
