/*global angular */

/**
 * @fileOverview provides jQuery uniform related functionality so it is not necessary in the controller
 */
(function () {
	'use strict';
	
	angular.module('attUniform', [])
	
		.directive('attEnableUniform', ['$timeout', function ($timeout) {
			return {
				restrict: 'A',
				require: 'ngModel',
				link: function (scope, element, attr, model) {
					element.uniform({useId: false});
					scope.$watch(
						function () { return model.$modelValue; },
						function () { $timeout(function () { element.uniform.update(element); }, 0); }
					);
				}
			};
		}]);
}());