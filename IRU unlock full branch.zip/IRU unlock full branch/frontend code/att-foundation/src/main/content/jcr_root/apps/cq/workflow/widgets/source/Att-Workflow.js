
var checkboxEditable=false;
var usrGrpSelectable=false;
var isUsrMerchLead=false;

// Make an Ajax call here to get the response json
$CQ.getJSON("/system/checkusergroup",function(respJson){
	if(respJson.overwriteCheckbox == "true") checkboxEditable=true;
	if(respJson.overwriteGroup == "true") usrGrpSelectable=true;
	if(respJson.isMerchLeadUser == "true") isUsrMerchLead=true;
	
});


// PAGE ACTIVATE WORKFLOW INITIATOR DIALOG
// Render General Tab
function renderGeneralTabPanel(panel){
	
 // SET HERE THE WIDTH AND HEIGHT OF THE WORKFLOW DIALOG.
	
}

function validateJiraIdForWorkflowInitiatorDialog (value) {
               	 jiraComment = CQ.Ext.ComponentMgr.get('jiraComment');
                 jiraId = CQ.Ext.ComponentMgr.get('jiraid');
                 if ( $CQ.trim(jiraId.getValue()) != ''){
                 	var data = CQ.HTTP.get('/system/jira/ajax?jiraid='+value+'&cmd=1');
                 	if($CQ.trim(data.body) == 'valid') {
                 		jiraId.clearInvalid();
                 		CQ.Ext.ComponentMgr.get('userid').setValue(CQ.User.getUserID());
                 		return true;
                 	}
                 	else {
                 		return CQ.I18n.getMessage('ERROR:'+$CQ.trim(data.body));
                 	}
                 }
                 else{
                 	return CQ.I18n.getMessage('jiraid can not be empty');
              }
             }


// state validateOnPreStg listener state change 


function overwriteSelection(comp,selection,checked,compName,notif,env) {
	var envName = '';
	var defaultGroupSelection = '';
	switch (env){
	case 1:
		envName = 'Pre-Stage';
		defaultGroupSelection = CQ.Ext.ComponentMgr.get(compName).getValue()!='' ? CQ.Ext.ComponentMgr.get(compName).getValue() : 'att-business-validation-group';
		break;
	case 2:
		envName = 'Final-Stage';
		defaultGroupSelection = defaultGroupSelection = CQ.Ext.ComponentMgr.get(compName).getValue()!='' ? CQ.Ext.ComponentMgr.get(compName).getValue() : 'att-release-management';
		break;
	}
	
	if((CQ.User.getUserID() != '')){
		if(!checkboxEditable){
			comp.addClass(' x-item-disabled');
			comp.setValue('true');
			comp.checked;
			}
		}
		if((comp.getValue() == 'true')) {
			CQ.Ext.ComponentMgr.get(compName).enable();
			if(usrGrpSelectable){
				CQ.Ext.ComponentMgr.get(compName).setReadOnly(false);
				CQ.Ext.ComponentMgr.get(compName).clearValue();
				color = 'green';
				CQ.Ext.ComponentMgr.get(compName).setValue(defaultGroupSelection);
				//CQ.Ext.ComponentMgr.get(notif).setValue(envName+' validation will be performed by '+CQ.Ext.ComponentMgr.get(compName).getValue().toUpperCase());
				CQ.Ext.ComponentMgr.get(notif).setValue('<font color=\''+color+'\'>'+envName+' validation will be performed by '+CQ.Ext.ComponentMgr.get(compName).getValue().toUpperCase()+'</font>');
			}
		}else {
			CQ.Ext.ComponentMgr.get(compName).clearInvalid();
			CQ.Ext.ComponentMgr.get(compName).disable();
			CQ.Ext.ComponentMgr.get(notif).setValue('<font color=\'red\'>Skip '+envName+' Validation</font>');
		}
}


// listener for group selection choice
function groupSelection(combo,notif,env){
		CQ.Ext.ComponentMgr.get(notif).setValue('<font color=\''+color+'\'>'+env+' validation will be performed by '+combo.getValue().toUpperCase()+'</font>');
}

function setWorkflowCurrentStep() {
	// Set user selected action to hidden element.
	var payLoadDivElem = CQ.Ext.query('.x-form-item-label');	
	var actionFieldId = payLoadDivElem[0].htmlFor;
	var userSelection = CQ.Ext.ComponentMgr.get(actionFieldId).getRawValue();
	
	CQ.Ext.ComponentMgr.get('workflowcurrentstep').setValue(userSelection);
	
	if(undefined != CQ.Ext.ComponentMgr.get('initiateactoruserid')) {
		CQ.Ext.ComponentMgr.get('initiateactoruserid').setValue(CQ.User.getUserID());
	}
	
	if(undefined != CQ.Ext.ComponentMgr.get('authoractoruserid')) {
		CQ.Ext.ComponentMgr.get('authoractoruserid').setValue(CQ.User.getUserID());
	}
	
	if(undefined != CQ.Ext.ComponentMgr.get('prestageactoruserid')) {
		CQ.Ext.ComponentMgr.get('prestageactoruserid').setValue(CQ.User.getUserID());
	}
	
	if(undefined != CQ.Ext.ComponentMgr.get('finalstageuserid')) {
		CQ.Ext.ComponentMgr.get('finalstageuserid').setValue(CQ.User.getUserID());
	}
}


// Activate/deactivate jiraId and Jira comment sections according to the options choosen for 'Do you have jira'
function enableOrDisableJiraIdAndJiraCommentFields(combo,record,index){
	setWorkflowCurrentStep();
	
	jiraComment = CQ.Ext.ComponentMgr.get('jiraComment');
    jiraId = CQ.Ext.ComponentMgr.get('jiraid');
    if(combo.getValue() == 'Yes'){              jiraId.enable();
     jiraId.setVisible(true);
     jiraId.getEl().up('.x-form-item').setDisplayed(true);
     jiraComment.enable();
     jiraComment.setVisible(true);
     jiraComment.getEl().up('.x-form-item').setDisplayed(true);
    }else if(combo.getValue() == 'No'){                      jiraId.setVisible(false);
     jiraId.getEl().up('.x-form-item').setDisplayed(false);
     jiraId.disable();
     jiraComment.disable();
     jiraComment.setVisible(false);
     jiraComment.getEl().up('.x-form-item').setDisplayed(false);
    }
}

function showHideDeploymentDateTime(combo, record, index) {
	datetimefield = CQ.Ext.ComponentMgr.get('productionDeploymentTime');
	if(combo.getValue() == 'Immediately') {
		datetimefield.disable();
	}
	else if(combo.getValue() == 'Later'){
		datetimefield.enable();
	}
}

// APPROVER DIALOG JAVA SCRIPT FUNCTIONS.
function validateJiraIdForWorkflowApproverDialog(value){	
	setWorkflowCurrentStep();
	
	
	  var payLoadDivElem = CQ.Ext.query('.x-form-item-label');	
	  var labelVal = payLoadDivElem[0];	
	  var output = '';	
	  var forAttrVal = labelVal.htmlFor;	
	  var workflowNode = forAttrVal.split('combo-')[1].split('/workItems')[0];	
	  var wfjsonObj = CQ.HTTP.get(workflowNode+'.json').body;	
	  var payloadPath = CQ.Ext.util.JSON.decode(wfjsonObj).payload;	
	  var jcrContentNode = CQ.HTTP.get(payloadPath+'/jcr:content.json').body;	
	  var jiraId = CQ.Ext.util.JSON.decode(jcrContentNode).jiraid;	
	  var workflowInitiator = CQ.Ext.util.JSON.decode(jcrContentNode).initiateactoruserid;	
	  	
	    if( !(jiraId === undefined) && !(jiraId == '')){	
	    	    $CQ('#jiraid').val(jiraId);	
	    	     	
	    	    CQ.Ext.ComponentMgr.get('jiraid').setReadOnly(new Boolean(1));	
	    	    CQ.Ext.ComponentMgr.get('userid').setValue(CQ.User.getUserID());	
	    	    CQ.Ext.ComponentMgr.get('jiraid').clearInvalid();	
	    	    CQ.Ext.ComponentMgr.get('jiralink').setValue('<a href=\'http://jira.cingular.net/jira/browse/'+jiraId+' target=\'_blank\' style=\'cursor: hand\'><font color=\'blue\'><u>View in JIRA</u></font></a>');	
	    	    	
	            if(workflowInitiator == CQ.User.getUserID()){	
	               	CQ.Ext.Msg.alert('ALERT', 'Workflow Initiator('+workflowInitiator+') is same as current user('+CQ.User.getUserID()+').Workflow Initiator can not approve their changes.');	
	               	return CQ.I18n.getMessage('Workflow Initiator('+workflowInitiator+') is same as current user('+CQ.User.getUserID()+').Workflow Initiator can not approve their changes.');	
	            }	
	            return true;	
	  }else{	
		      if(workflowInitiator == CQ.User.getUserID()){	
			 CQ.Ext.Msg.alert('ALERT', 'Workflow Initiator('+workflowInitiator+') is same as current user('+CQ.User.getUserID()+').Workflow Initiator can not approve their changes.');	
			 return CQ.I18n.getMessage('Workflow Initiator('+workflowInitiator+') is same as current user('+CQ.User.getUserID()+').Workflow Initiator can not approve their changes.');	
		     }	
	  	  	
	  	      jiraComment = CQ.Ext.ComponentMgr.get('jiraComment');	
	              jiraId = CQ.Ext.ComponentMgr.get('jiraid');	
	              if ( $CQ.trim(jiraId.getValue()) != ''){   	
	              	   var data = CQ.HTTP.get('/system/jira/ajax?jiraid='+value+'&cmd=1');	
	              	   if($CQ.trim(data.body) == 'valid')               {	
	              	     jiraId.clearInvalid();	
	              	     CQ.Ext.ComponentMgr.get('userid').setValue(CQ.User.getUserID());	
	              	     return true;	
	                }	
	                else {	
	                	return CQ.I18n.getMessage('ERROR:'+$CQ.trim(data.body));	
	                }	
	              }else{	
	              	      return CQ.I18n.getMessage('jiraid can not be empty');	
	               }	
	  }	
	}   

// Workflow Pre-Stage Approver dialog group.
function displayFieldBeforeRenderEventSelection(validateOn){

	var payLoadDivElem = CQ.Ext.query('.x-form-item-label');
	var labelVal = payLoadDivElem[0];
	var output = '';
	var doOverwriteMessage = ' Select Options below to overwrite';
	
	var forAttrVal = labelVal.htmlFor;
	var workflowNode = forAttrVal.split('combo-')[1].split('/workItems')[0];
	var wfjsonObj = CQ.HTTP.get(workflowNode+'.json').body;
	var payloadPath = CQ.Ext.util.JSON.decode(wfjsonObj).payload;
	var jcrContentNode = CQ.HTTP.get(payloadPath+'/jcr:content.json').body;
	var validateOnFinalStg = CQ.Ext.util.JSON.decode(jcrContentNode).validateOnFinalStage;
	var finalStgValidatorGrp = CQ.Ext.util.JSON.decode(jcrContentNode).assignFinalStgValidatorGroup;
	var validateOnPreStg = CQ.Ext.util.JSON.decode(jcrContentNode).validateOnPreStg;
	var preStgValidatorGrp = CQ.Ext.util.JSON.decode(jcrContentNode).assignPreStgValidatorGroup;
	
	var displayText = '';
	
	if(validateOn == 'onAuthor'){
		if((validateOnPreStg === undefined) || (validateOnPreStg == '')){
			displayText = 'Workflow Initiator did not choose Pre Stage Validation.';
//			CQ.Ext.ComponentMgr.get('wfInitFSOpts').setValue('Workflow Initiator did not choose Pre Stage Validation.');
		}else{
			CQ.Ext.ComponentMgr.get('valOnPreStg').setValue(validateOnPreStg);
			CQ.Ext.ComponentMgr.get('assignPreStgValidatorGroup').setValue(preStgValidatorGrp);
			displayText = 'Workflow Initiator has selected '+preStgValidatorGrp+' for Pre-Stage validation.';
//			CQ.Ext.ComponentMgr.get('wfInitFSOpts').setValue('Workflow Initiator has selected '+preStgValidatorGrp+' as Pre Stage validator group.');
		}
		
		if((validateOnFinalStg === undefined) || (validateOnFinalStg == '')){
			displayText += 'Workflow Initiator did not choose Final Stage Validation';
//			CQ.Ext.ComponentMgr.get('wfInitFSOpts').setValue('Workflow Initiator did not choose Final Stage Validation');
		}else{
			CQ.Ext.ComponentMgr.get('valOnFinalStg').setValue(validateOnFinalStg);
			CQ.Ext.ComponentMgr.get('assignFinalStgValidatorGroup').setValue(finalStgValidatorGrp);
			displayText += '\nWorkflow Initiator has selected '+finalStgValidatorGrp+' for Final-Stage validation.';
//			CQ.Ext.ComponentMgr.get('wfInitFSOpts').setValue('Workflow Initiator has selected '+finalStgValidatorGrp+' as Final Stage validator group.'+(isUsrMerchLead ? doOverwriteMessage : ''));
		}
		if(!isUsrMerchLead){
			CQ.Ext.ComponentMgr.get('assignPreStgValidatorGroup').disable();
			CQ.Ext.ComponentMgr.get('valOnPreStg').disable();

			CQ.Ext.ComponentMgr.get('assignFinalStgValidatorGroup').disable();
			CQ.Ext.ComponentMgr.get('valOnFinalStg').disable();
		}

	}else if(validateOn == 'onPreStg'){
		if((validateOnFinalStg === undefined) || (validateOnFinalStg == '')){
			displayText += 'Workflow Initiator did not choose Final Stage Validation';
//			CQ.Ext.ComponentMgr.get('wfInitFSOpts').setValue('Workflow Initiator did not choose Final Stage Validation');
		}else{
			CQ.Ext.ComponentMgr.get('valOnFinalStg').setValue(validateOnFinalStg);
			CQ.Ext.ComponentMgr.get('assignFinalStgValidatorGroup').setValue(finalStgValidatorGrp);
			displayText += 'Workflow Initiator has selected '+finalStgValidatorGrp+' for Final-Stage validation.';
//			CQ.Ext.ComponentMgr.get('wfInitFSOpts').setValue('Workflow Initiator has selected '+finalStgValidatorGrp+' as Final Stage validator group.'+(isUsrMerchLead ? doOverwriteMessage : ''));
		}
		if(!isUsrMerchLead){
			CQ.Ext.ComponentMgr.get('assignFinalStgValidatorGroup').disable();
//			CQ.Ext.ComponentMgr.get('valOnFinalStg').disable();
		}

	}
	CQ.Ext.ComponentMgr.get('wfInitFSOpts').setValue(displayText);
}


function overWriteFinalStageValidatorGroup(thisComp,selection,checked){

	if(isUsrMerchLead){
		if((thisComp.getValue() == 'true')) { 
			CQ.Ext.ComponentMgr.get('assignFinalStgValidatorGroup').enable(); 
		}else {
			CQ.Ext.ComponentMgr.get('assignFinalStgValidatorGroup').clearInvalid();
			CQ.Ext.ComponentMgr.get('assignFinalStgValidatorGroup').disable();
		}	
		
	}
}





