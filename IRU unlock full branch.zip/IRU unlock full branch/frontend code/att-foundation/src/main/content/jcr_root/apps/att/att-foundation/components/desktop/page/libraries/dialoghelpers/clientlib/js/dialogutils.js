/*jshint strict: false, evil: true */
/*global CQ, console */

/**
 * @fileOverview Functions for externalizing JavaScript functionality for updates to translator label entry panels
 */
var DialogHelp = {};

(function () {
    var translatorKeyMap = {};

    /**
     * Listener function for primary path selection option
     */
    DialogHelp.transPathListener = function (sel, value) {
        var i, response, selectionList, jsontxt;

        if (!translatorKeyMap.hasOwnProperty(value)) {
            response = CQ.HTTP.get('/apps/att/utilities/translator.labels.json?path=' + value);
            if (response.status == '200') {
                translatorKeyMap[value] = response.body;
            }
        }

        selectionList = this.findParentByType('panel').findByType('selection');

        for (i = 0; i < selectionList.length; i++) {
            console.log(selectionList[i].getValue());

            if (selectionList[i].getValue() === value) { continue; }

            jsontxt = translatorKeyMap[value];
            selectionList[i].setOptions(eval(jsontxt));
            selectionList[i].setValue('');
        }
    };


    /**
     * Listener function for individual label selection inputs
     */
    DialogHelp.transLabelListener = function (cmp, args) {
        var selectionList = this.findParentByType('panel').findByType('selection'),
            value = selectionList[0].getValue(),
            response, jsontxt;

        console.log("args" + args);

        if (!translatorKeyMap.hasOwnProperty(value)) {
            response = CQ.HTTP.get('/apps/att/utilities/translator.labels.json?path=' + value);
            if (response.status == '200') {
                translatorKeyMap[value] = response.body;
            }
        }
        jsontxt = translatorKeyMap[value];
        cmp.setOptions(eval(jsontxt));
        cmp.setVisible(true);
    };

}());