/*
The purpose of this file is to provide helper services for common programming constructs. 
These services should only have Angular dependencies, no application dependencies at all.
This module is a dependency for attManager, so there is probably no need to include it as a direct dependency.
*/
(function(){
	'use strict';
	
	angular.module('util', ['ngCookies'])
	
	.factory("getQueryParam", function($window) {
		return function (parameter) {
			var i = 0,
			searchParam,
			paramArray,
			keyValuePair;
			searchParam = $window.location.search.substring(1);
			paramArray = searchParam.split('&');
			for (i = 0; i < paramArray.length; i++) {
				keyValuePair = paramArray[i].split('=');
				if (keyValuePair[0] === parameter) {
					return keyValuePair[1];
				}
			}
		};	
	})
	
	//transmogrify is like a filter, map and reduce but for objects; it can map found results to an array of new objects
	//this is useful for taking large json responses and making them useful in other contexts, for instance reporting and chat
	.factory("transmogrify", function() {
		return function() {
				return {
				items : [], 
				data : null,
				searchMap : {}, 
				transformPropsMap : false, 
				transformValsMap : {}, 
				source : function (obj) {
					if (obj !== undefined) {
						this.items = [];
						this.data = obj;
						return this;
					} else {
						return this.data;
					}
				},
				search : function (criteria) {
					if (criteria !== undefined) {
						this.searchMap = criteria;
						return this;
					} else {
						return this.searchMap;
					}
				},
				propsMap : function (map) {
					if (map !== undefined) {
						this.transformPropsMap = map;
						return this;
					} else {
						return this.transformPropsMap;
					}
				},
				valsMap : function (map) {
					if (map !== undefined) {
						this.transformValsMap = map;
						return this;
					} else {
						return this.transformValsMap;
					}
				},
				results : function (arr) {
					if (arr !== undefined) {
						this.items = arr;
						return this;
					} else {
						return this.items;
					}
				}, 
				add : function (map) {
					var thisItem, prop, i;
					for (prop in map) {
						if (map.hasOwnProperty(prop)) {
							for (i=0; i < this.items.length; i++) {
								thisItem = this.items[i];
								if (typeof map[prop] === "function") {
									thisItem[prop] = map[prop](thisItem);
								} else {
									thisItem[prop] = map[prop];
								}
							}
						}
					}
					return this;
				},
				remove : function (map) {
					var prop, i;
					for (prop in map) {
						if (map.hasOwnProperty(prop)) {
							if (typeof map[prop] === "function") {
								for (i=0; i < this.items.length; i++) {
									if (typeof this.items[i][prop] !== "undefined" && map[prop](this.items[i])) {
										delete this.items[i][prop];
									}
								}
							} else if (map[prop] === true) {
								for (i=0; i < this.items.length; i++) {
									if (typeof this.items[i][prop] !== "undefined") {
										delete this.items[i][prop];
									}
								}
							}
						}
					}
					return this;
				},
				// combineFn takes 3 arguments: currentResult, item, last
				// combineFn returns new currentResult
				// combineFn should test if currentResult is undefined and set to appropriate type 
				// (e.g. currentResult = currentResult || ""; or currentResult = currentResult || 0;)
				reduce: function(combineFn) {
					var result;
					for (var i = 0; i < this.items.length; i++) {
						result = combineFn(result, this.items[i], (i+1 === this.items.length), i, this.items.length);
					}
					return result;
				},
				searchMatch : function (obj) {
					var result = true, prop;
					if (obj == null || (obj != null && typeof obj !== "object")) {
						result = false;
					} else for (prop in this.searchMap) {
						if (this.searchMap.hasOwnProperty(prop)) {
							if (obj[prop] == null && this.searchMap[prop] === true) {
								result = false;
								break;
							} else {
								if (obj[prop] != null && this.searchMap[prop] === false) {
									result = false;
									break;
								} else {
									if (obj[prop] != null && typeof this.searchMap[prop] === "function" && !this.searchMap[prop](obj[prop])) {
										result = false;
										break;
									}
								}
							}
						}
					}
					return result;
				},
				go : function () {
					var tmog = this;
					function process(processData) {
						var prop, mapProp, transformedItem;
						for(prop in processData) {
							if (processData.hasOwnProperty(prop)) {
								if (typeof processData[prop] === "object") {
									if (processData[prop] != null && typeof processData[prop].length === "number") {
										if (processData[prop].length > 0) {
											tmog.items.push.apply(tmog.items, process(processData[prop]));
										}
									} else if (tmog.searchMatch(processData[prop])) {
										transformedItem = {};
										if (tmog.transformPropsMap) {
											for (mapProp in tmog.transformPropsMap) {
												if (tmog.transformPropsMap.hasOwnProperty(mapProp)) {
													if (typeof tmog.transformValsMap[tmog.transformPropsMap[mapProp]] !== "undefined") {
														transformedItem[tmog.transformPropsMap[mapProp]] = tmog.transformValsMap[tmog.transformPropsMap[mapProp]](processData[prop][mapProp]);
													} else {
														transformedItem[tmog.transformPropsMap[mapProp]] = processData[prop][mapProp];
													}
												}
											}
										} else {
											transformedItem = processData[prop];
										}
										tmog.items.push(transformedItem);
									} else {
										tmog.items.push.apply(tmog.items, process(processData[prop]));
									}
								} 
							}
						}
					}
					process(this.data);
					return this;
				}
			};
		};
	})
	.factory("salesStorage", ['$cookies', function( $cookies ){

			// Sales re-implementation of Greg Archer's nice shopStorage wrapper
			// localStorage wrapper which ignores & removes items saved during previous sessions
			// with sugar functions for storing/retrieving objects.
			
			var salesUserId = $cookies["SALES_USER_ID"];
			
			return {
				"clear": function(){
					var shopKeys = [];
					for( var i =0; i < localStorage.length; i++ ){
						var item = localStorage.getItem(localStorage.key(i));
						if(item.split(":")[0] == salesUserId){ sessionKeys.push(localStorage.key(i)); }
					}
					for( var x in shopKeys ){ localStorage.removeItem(shopKeys[x])}
				},
				"removeItem": function(key){
					var item = localStorage.getItem(key) || "";
					if(item.split(":")[0] == salesUserId){ return localStorage.removeItem(key); }
				},
				"setItem": function(key, item){
					return localStorage.setItem(key, salesUserId + ":" + item);
				},
				"getItem": function(key){
					var item = localStorage.getItem(key) || "";
					if(item.split(":")[0] !== salesUserId){ return localStorage.removeItem(key); }
					return item.split(":").slice(1).join(":");
				},
				"getObject": function(key){
					var item = localStorage.getItem(key) || "";
					if(item.split(":")[0] !== salesUserId){ return localStorage.removeItem(key); }
					return angular.fromJson(item.split(":").slice(1).join(":"));
				},
				"setObject": function(key, obj){
					return localStorage.setItem(key, salesUserId + ":" + angular.toJson(obj));
				},
				"setSalesUserId": function(val) {
					salesUserId = val;
				}
			}
		}]);
})();
