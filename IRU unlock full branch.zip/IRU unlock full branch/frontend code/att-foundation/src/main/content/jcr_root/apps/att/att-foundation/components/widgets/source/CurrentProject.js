CQ.Ext.namespace("ATT", "ATT.wcm");

var idradiogroupchangeprojectin=CQ.Ext.id();
var idcurrprojinbrowser=CQ.Ext.id();
var idcurrprojinpage=CQ.Ext.id();
var idcurrprojselection=CQ.Ext.id();

var projectstore =new CQ.Ext.data.JsonStore({
    // load using HTTP
	"url": "/etc/projectlist/_jcr_content.options.json",
    //url: '<%= url_for(:action => "setting_data.json" ) %>',
    "fields" : [{"name" : "text","type":"string"}],
    "listeners": {
    	load: function (oStore, ayRecords, oOptions ){
            //alert('loaded successfully: ' + ayRecords.length + '\ndata' + ayRecords );
        }
    }

});

CQ.Ext.onReady(function() {
	projectstore.load();
});	


ATT.wcm.CurrentProject = {
	CURRENT_PROJECT_COOKIE_NAME: "attcq.currentproject",

	getCookie : function() {
		var projookie=CQ.Ext.util.Cookies.get(ATT.wcm.CurrentProject.CURRENT_PROJECT_COOKIE_NAME);
		if(projookie ==null){
			projookie="";
		}
		return projookie;
	},
	
	setCookie : function(value) {
		CQ.Ext.util.Cookies.set(ATT.wcm.CurrentProject.CURRENT_PROJECT_COOKIE_NAME, value);
	},

	showmessage : function(status,type) {
		 var errormessage="There was an error while trying to Tag This " +  type + ". Please try again.";
		 var successmessage="Tag This " + type + " is completed successfully.";
		 if(type=="Key(s)"){
			 errormessage="There was an error while trying to Tag These Keys . Please try again.";
			 successmessage="Tag These Keys is completed successfully.";
		 }
         
		 if (status=="success"){
             CQ.Notification.notify(CQ.I18n.getMessage(successmessage), CQ.I18n.getMessage(""));
         }
		 else{
				CQ.Notification.notify(CQ.I18n.getMessage(errormessage), CQ.I18n.getMessage(""));
				CQ.Ext.Msg.alert('Error', errormessage);
		}
         
	},
	
	getCurrentProjectActionLabel : function(currentProject,id) {
		var label="";
		if (id == "cq-damadmin") {
			label="  |  Tag This Asset";
		}
		else if (id == "cq-siteadmin") {
			label="  |  Tag This Page";
		}
		else if (id == "cq-translator") {
			label="  |  Tag These Keys";
		}
		if(currentProject==""){
			return CQ.I18n.getMessage("Select Current Project" + label);
		}
		else{
			return CQ.I18n.getMessage("Current Project: {0}" + label, currentProject);
		}
		
	},
	deleteCookie : function() {
		CQ.Ext.util.Cookies.clear(ATT.wcm.CurrentProject.CURRENT_PROJECT_COOKIE_NAME);
	}
		
}
/*
ATT.wcm.ProjectTagging = {		
	SHOW_PROJECT_TAG_COOKIE_NAME: "attcq.ShowProjecttag",
	
	getCookie : function() {
		return CQ.Ext.util.Cookies.get(ATT.wcm.ProjectTagging.SHOW_PROJECT_TAG_COOKIE_NAME);
	},
	
	setCookie : function(value) {
		CQ.Ext.util.Cookies.set(ATT.wcm.ProjectTagging.SHOW_PROJECT_TAG_COOKIE_NAME, value);
	},
	
	deleteCookie : function() {
		CQ.Ext.util.Cookies.clear(ATT.wcm.ProjectTagging.SHOW_PROJECT_TAG_COOKIE_NAME);
	}
}
*/
ATT.wcm.CurrentProject.SelectProjectDialog = CQ.Ext.extend(CQ.Dialog, {

    constructor: function(config) {
        if (!config) {
            config = new Object();
        }

        // overwrite config
        config = CQ.Util.applyDefaults(config, {
            "xtype": "dialog",
            "layout" : "form",
            "title":CQ.I18n.getMessage("Select Current Project"),
            "items" : [{
                "xtype": "static",
                "labelStyle": 'width:170px;font-size:13px',
                "height": 50,
                "cls": "x-form-item-description",
                "text": CQ.I18n.getMessage('Select the project you are currently working on. If your project isn\'t listed, please request it be added.')
            },{
            	"xtype" : "combo",
                "name" : "currentProject",
                "fieldLabel" : "Select Available Project:",
                "labelStyle": "width:170px;font-size:13px",
                "height": 50,
            	"displayField": "text",
                "allowBlank" : true,
                 "loadingText" : "getting data...",
                 "store":projectstore,
                 "mode": "local",
                 "queryMode": "local",
                 "typeAhead": true,
                 "emptyText":"Clear Project",
                 "hideTrigger":false,  
                 "triggerAction": "all"
            },{
            	"name": "currprojinbrowser",
                "id": idcurrprojinbrowser,
                "xtype": "displayfield",
                "fieldLabel": "Current Project in Browser:",
                "labelStyle": 'width:170px;font-size:13px',
                "value":config.value
            }],
            "buttons" : CQ.Dialog.OKCANCEL,
            "height" : 200
        });
        //commented to fix a bug
        /*if (config.value) { //to set cookie value as selected
            config.items[1].value = config.value;
        }*/
        ATT.wcm.CurrentProject.SelectProjectDialog.superclass.constructor.call(this, config);
    },
    
    /**
     * Submits the dialog.
     * @param {CQ.Ext.Button} button The button that has been hit
     * @param {Function} success The function to call if the dialog submission was successful.
     *                           Overwrites {@link #success}.
     * @param {Function} failure The function to call if the dialog submission has failed.
     *                           Overwrites {@link #failure}.
     */
    ok: function(button, success, failure) {
        if (this.form.isValid()) {
            if (this.fireEvent("beforesubmit", this) === false){
                return false;
            }
            this.form.items.each(function(field) {
                // clear fields with emptyText so emptyText is not submitted
                if (field.emptyText && field.el && field.el.dom && field.el.dom.value == field.emptyText) {
                    field.setRawValue("");
                }
            });
            
            var selectedProjectField = this.form.findField("currentProject");
            var selectedProject = selectedProjectField.getRawValue();

            this.projectSelected(selectedProject);
            
            this[this.closeAction]();
        } else {
            CQ.Ext.Msg.show({
                title:CQ.I18n.getMessage('Validation Failed'),
                msg: CQ.I18n.getMessage('Verify the values of the marked fields.'),
                buttons: CQ.Ext.Msg.OK,
                icon: CQ.Ext.Msg.ERROR
            });
        }
    }
});

/* Start Tag this page Code*/

ATT.wcm.CurrentProject.changeProjectTagDialog = CQ.Ext.extend(CQ.Dialog, {

    constructor: function(config) {
    	  	
        if (!config) {
            config = new Object();
        }
        // overwrite config
        config = CQ.Util.applyDefaults(config, {
            "xtype": "dialog",
            "layout" : "form",
            "title":CQ.I18n.getMessage("Select Current Project"),
            "items" : [{
                "xtype": "static",
                "height": 30,
                "cls": "x-form-item-description",
                "text": CQ.I18n.getMessage('Select the project you are currently working on. If your project isn\'t listed, please request it be added.')
            },{
                "xtype" : "combo",
                "name" : "currentProject",
                "fieldLabel" : "Select Available Project:",
                "labelStyle": "width:170px;font-size:13px",
                "height": 50,
                "id":idcurrprojselection,
            	"displayField": "text",
                "allowBlank" : true,
                 "loadingText" : "getting data...",
                 "store":projectstore,
                 "mode": "local",
                 "queryMode": "local",
                 "typeAhead": true,
                 "emptyText":"Clear Project",
                 "hideTrigger":false,  
                 "triggerAction": "all"
            },{
				"xtype": "radiogroup",
				"fieldLabel": 'Change Project in:',
				"labelStyle": "width:170px;font-size:13px",
				"width":400,
				"name": "radiogroupchangeprojectin",
	            "id": idradiogroupchangeprojectin,
	            "columns": [100, 120, 150],
				"items": [
					{
						"boxLabel": "Browser",
						"inputValue": "changeprojectinbrowser", 
						"name":"radiochangeprojectin"
					},{					   
						"boxLabel": "Browser & " + config.type,
						"inputValue": "changeprojectinbrowserpage",
						"checked": true,
						"name":"radiochangeprojectin"
					},{	   
						"boxLabel": config.type + " with Existing",
						"inputValue": "changeprojectinpagewithexisting",
						"name":"radiochangeprojectin"
					}
				],
				listeners: {
			        change: function( radiogroup, newradio, oldradio, eOpts ) {
			        	var itemradiogroup=CQ.Ext.getCmp(idcurrprojselection);
			            if(newradio.inputValue=="changeprojectinpagewithexisting"){
			            	itemradiogroup.getEl().hide();
			            	itemradiogroup.disable(); // for validation
			            	if (!CQ.Ext.isEmpty(itemradiogroup.getEl())) {
			            		itemradiogroup.getEl().up('.x-form-item').setDisplayed(false); // hide container and children (including label if applicable)
			                }
			            }
			            else{
			            	itemradiogroup.getEl().show();
			            	itemradiogroup.enable();
			            	if (!CQ.Ext.isEmpty(itemradiogroup.getEl())) {
			            		itemradiogroup.getEl().up('.x-form-item').setDisplayed(true); // show entire container and children (including label if applicable)
			                }
			            }
			        }
			    }
				
            },{
            	"name": "currprojinbrowser",
                "id": idcurrprojinbrowser,
                "xtype": "displayfield",
                "fieldLabel": "Current Project in Browser:",
                "labelStyle": 'width:170px;font-size:13px',
                "value":config.value
            },{
            	"name": "currprojinpage",
                "id": idcurrprojinpage,
                "xtype": "displayfield",
                "fieldLabel": "Current Project in " + config.type + ":",
                "labelStyle": 'width:170px;font-size:13px',
                "value":config.project
            }],
            
            "buttons" : CQ.Dialog.OKCANCEL,
            "height" : 250,
            "width" : 600
        });
        //commented to fix a bug
        /*if (config.value) { //to set cookie value as selected
            config.items[1].value = config.value;
        }*/
        ATT.wcm.CurrentProject.changeProjectTagDialog.superclass.constructor.call(this, config);
       
        if(config.type=="Key(s)"){
        	var itemprojectintype=CQ.Ext.getCmp(idcurrprojinpage);
        	itemprojectintype.getEl().hide();
        	itemprojectintype.disable(); // for validation
        	if (!CQ.Ext.isEmpty(itemprojectintype.getEl())) {
        		itemprojectintype.getEl().up('.x-form-item').setDisplayed(false); // hide container and children (including label if applicable)
            }
        }
    },
    
     ///
     // * Submits the dialog.
     //* @param {CQ.Ext.Button} button The button that has been hit
     //* @param {Function} success The function to call if the dialog submission was successful.
     //*                           Overwrites {@link #success}.
     //* @param {Function} failure The function to call if the dialog submission has failed.
     //*                           Overwrites {@link #failure}.
     //
    ok: function(button, success, failure) {
        if (this.form.isValid()) {
            if (this.fireEvent("beforesubmit", this) === false){
                return false;
            }
            this.form.items.each(function(field) {
                // clear fields with emptyText so emptyText is not submitted
                if (field.emptyText && field.el && field.el.dom && field.el.dom.value == field.emptyText) {
                    field.setRawValue("");
                }
            });
			var tagthis=this;
			var radiogroupchangeprojectinval=CQ.Ext.getCmp(idradiogroupchangeprojectin).getValue().inputValue;
            var selectedProjectField = this.form.findField("currentProject");
            var selectedProject;
            if(radiogroupchangeprojectinval =="changeprojectinpagewithexisting"){ 
            	selectedProject=tagthis.value;
            }
            else{
            	selectedProject = selectedProjectField.getRawValue();	
            }
            //var sidekick = CQ.WCM.getSidekick();
            var pagepath = tagthis.path;
            var type = tagthis.type;
            var jsonData;
            var i=0;
            var status="";
            if (type=="Key(s)"){
            	tagthis.projectSelected(selectedProject,radiogroupchangeprojectinval);
            }
            else if(radiogroupchangeprojectinval !="changeprojectinbrowser"){
	            CQ.Ext.Ajax.request({
	                    "url":CQ.HTTP.externalize("/system/att/cms/tools/tagthispageservlet"),
	                    "method":"POST",
	                    "callback":function(options, success, xhr) {
	                        if(success==true){
	                            if(xhr.status==200){
	                                jsonData = CQ.Ext.util.JSON.decode(xhr.responseText);
	                                if (jsonData.status == "success"){
	                                	status="success";
	                                	tagthis.projectSelected(selectedProject);
										ATT.wcm.CurrentProject.showmessage("success",type)
	                                }
	                                else if(jsonData.status == "conflict"){
	                                    var jdata = jsonData.data;
	                                    var data="";
	                                    if (jdata.length !=0){
											//
	                                        //for (i = 0; i < jdata.length; i++) {
	                                        //    var j=i+1;
											//	var nodepath=jdata[i]["path"].replace(pagepath,""); 
	                                        //    data += j + ".\tNode Path: " + nodepath + "\n\tProject ID: " + jdata[i]["attcms:currentProject"]  + "\n" ;
	                                        //} 
	                                        //var warningmsg="The below node\(s\) already have different Project ID as property.\nAll Node Paths below have the following prefix that is not repeated for brevity: " + pagepath + "/jcr:content"  + "\nDo you want to overwrite with Project ID " + selectedProject + "?\n\n" + data;
											//
											var warningmsg="This page has different Project ID: " + jdata[0]["attcms:currentProject"]  + "<br><br>Do you want to overwrite with Project ID: " + selectedProject + "?<br><br>" + data;
											CQ.Ext.MessageBox.confirm('Warning', warningmsg, function(btn){
	                                           if(btn == 'yes'){
												 CQ.Ext.Ajax.request({
													"url":CQ.HTTP.externalize("/system/att/cms/tools/tagthispageservlet"),
													"method":"POST",
													"callback":function(options, success2, xhr2) {
														if(success2==true){
															if(xhr2.status==200){
																jsonData = CQ.Ext.util.JSON.decode(xhr2.responseText);
																if (jsonData.status == "success"){
																	tagthis.projectSelected(selectedProject);
																	 ATT.wcm.CurrentProject.showmessage("success",type)
																}
																else{
																	 ATT.wcm.CurrentProject.showmessage("error",type);
																}
															}
															else{
																 ATT.wcm.CurrentProject.showmessage("error",type);
															}
														}
														else{
															 ATT.wcm.CurrentProject.showmessage("error",type);
														}
													},
													"params":{
														 "pagepath":pagepath,
														 "overwrite":"true",
														 "projectid":selectedProject
													},
													"scope":this
												 });
												
	                                           }
	                                           else{
											  	  CQ.Notification.notify(CQ.I18n.getMessage("Tag This Page is canceled."), CQ.I18n.getMessage(""));
	                                           }
	                                        });
	                                     } 
	                                }
	                                else{
	                                	 ATT.wcm.CurrentProject.showmessage("error",type);
	                                }
	                            }
	                            else{
	                            	 ATT.wcm.CurrentProject.showmessage("error",type);
	                            }
	                        }
	                        else{
	                        	 ATT.wcm.CurrentProject.showmessage("error",type);
	                        }	
	                    },
	                    "params":{
	                         "pagepath":pagepath,
	                         "projectid":selectedProject
	                    },
	                    "scope":this
	             });
	            
        	}
        	else
        	{
        		tagthis.projectSelected(selectedProject);
        	}	
            this[this.closeAction]();
        } else {
            CQ.Ext.Msg.show({
                title:CQ.I18n.getMessage('Validation Failed'),
                msg: CQ.I18n.getMessage('Verify the values of the marked fields.'),
                buttons: CQ.Ext.Msg.OK,
                icon: CQ.Ext.Msg.ERROR
            });
        }
    }
});

/* End Tag this page Code*/
ATT.wcm.CurrentProject.CreateContentPackageDialog = CQ.Ext.extend(CQ.Dialog, {  
	
	
    constructor: function(config) {
        if (!config) {
            config = new Object();
        }

        // overwrite config
        config = CQ.Util.applyDefaults(config, {
            "xtype": "dialog",
            "layout" : "form",
            "title":CQ.I18n.getMessage("Create Content Package"),
            "items" : [{
                "xtype": "static",
                "height": 30,
                "cls": "x-form-item-description",
                "text": CQ.I18n.getMessage('Enter the group name and package name for the content package.')
            },{
            	"xtype" : "textfield",
            	"allowBlank" : false,
            	"name" : "groupName",
            	"fieldLabel" : "Group Name"
            },{
            	"xtype" : "textfield",
            	"allowBlank" : false,
            	"name" : "packageName",
            	"fieldLabel" : "Package Name"
            },{
            	"xtype" : "pathfield",
            	"allowBlank" : true,
            	"name" : "contentPath",
            	"fieldLabel" : "Content Path"
            }],
            "buttons" : CQ.Dialog.OKCANCEL,
            "height" : 200
        });
        ATT.wcm.CurrentProject.CreateContentPackageDialog.superclass.constructor.call(this, config);
    },
    
    /**
     * Submits the dialog.
     * @param {CQ.Ext.Button} button The button that has been hit
     * @param {Function} success The function to call if the dialog submission was successful.
     *                           Overwrites {@link #success}.
     * @param {Function} failure The function to call if the dialog submission has failed.
     *                           Overwrites {@link #failure}.
     */
    ok: function(button, success, failure) {
        if (this.form.isValid()) {
            if (this.fireEvent("beforesubmit", this) === false){
                return false;
            }
            this.form.items.each(function(field) {
                // clear fields with emptyText so emptyText is not submitted
                if (field.emptyText && field.el && field.el.dom && field.el.dom.value == field.emptyText) {
                    field.setRawValue("");
                }
            });
            
            var groupName = this.form.findField("groupName").getRawValue();
            var packageName = this.form.findField("packageName").getRawValue();
            var contentPath = this.form.findField("contentPath").getRawValue();

            this.createContentPackage(groupName, packageName,contentPath);
            
            this[this.closeAction]();
        } else {
            CQ.Ext.Msg.show({
                title:CQ.I18n.getMessage('Validation Failed'),
                msg: CQ.I18n.getMessage('Verify the values of the marked fields.'),
                buttons: CQ.Ext.Msg.OK,
                icon: CQ.Ext.Msg.ERROR
            });
        }
    }
});