CQ.Ext.namespace("ATT", "ATT.wcm");

ATT.wcm.Sidekick = {

	deactivatePageHandler: function() {	
		var sidekick = this;
		var pagepath = sidekick.getPath();
		var msg = CQ.I18n.getMessage("You are going to deactivate the following page: ") + "<br/>" + pagepath;
		msg += "<br/>" + CQ.I18n.getMessage("Are you sure?");
		var title =  CQ.I18n.getMessage("Deactivate Page");
		CQ.Ext.Msg.show({
				"title":title,
				"msg":msg,
				"buttons":CQ.Ext.Msg.YESNO,
				"icon":CQ.Ext.MessageBox.QUESTION,
				"fn":function(btnId) {
					if (btnId == "yes") {
						var paths = [];
						paths.push(pagepath);
						CQ.HTTP.post(
							CQ.shared.HTTP.externalize("/bin/replicate.json"),
							function(options, success, response) {
								 if (success) {
									CQ.Notification.notify("Deactivate",
											CQ.I18n.getMessage("Page successfully Deactivated."));
								} else {
									CQ.Notification.notifyFromResponse(response);
								}
							},
							{ "_charset_":"utf-8", "path":paths, "cmd":"Deactivate" }
						);											
					}
				},
				"scope":this
			});
    },	
	   
    /* Start Project Tag  Code*/
    
    projectTagInPage: function(path) {	
		
		var projecttag_property="attcms:currentProject";
		var strproject="";
		//var path= CQ.WCM.getPagePath() + ".json";
		//var url = CQ.HTTP.noCaching(path );
		try{
			var url = CQ.HTTP.noCaching("/system/att/cms/tools/tagthispageservlet?projectinfo=true&pagepath=" + path);
	   		var projinfo = CQ.HTTP.get(CQ.shared.HTTP.externalize(url));
	    	var jsonData = CQ.Ext.util.JSON.decode(projinfo.responseText);
	    	//strproject=jsonData[projecttag_property];
	    	var jdata = jsonData.data;
	        if (jdata.length !=0){
				strproject=jdata[0][projecttag_property];
	        }
		   	if (strproject ==undefined){
		        strproject="";
		    }
		}
		catch(err){
		}
        return strproject;    
	},	
    
    changeProjectTagHandler: function() {
    	var nwindowobj=CQ.Ext.getCmp("idchangeProjectTagDialog");
    	if(nwindowobj !=null){
    		nwindowobj.close();
    	}		
        var sidekick = this;
        var path=sidekick.getPath();
        new ATT.wcm.CurrentProject.changeProjectTagDialog({
            "value" : ATT.wcm.CurrentProject.getCookie(),
            "id":"idchangeProjectTagDialog",
            "path":path,
            "type":"Page",
            "project":ATT.wcm.Sidekick.projectTagInPage(path),
            "projectSelected" : function(projectName) {
            	if(projectName==""){	
                	ATT.wcm.CurrentProject.deleteCookie();
                }
                else{
                	ATT.wcm.CurrentProject.setCookie(projectName);
                }	
				ATT.wcm.Sidekick.showProjectTag(sidekick);
                CQ.Notification.notify(CQ.I18n.getMessage("Project Selected"), CQ.I18n.getMessage("Current project selection changed."));
				ATT.wcm.Sidekick.relaodCurrentPage(sidekick.getPath() + ".html");
            }
        }).show(); 
    },

    
	relaodCurrentPage: function(url) {
		url = CQ.HTTP.externalize(url);
		url = CQ.HTTP.noCaching(url);
		CQ.Util.reload(CQ.WCM.getContentWindow(), url);
	},
	showProjectTag: function(sidekick) {	
			if (!CQ.WCM.isEditMode()) {
                CQ.WCM.setMode(CQ.WCM.MODE_EDIT);                                   
            }
			var strprojecttag= ATT.wcm.Sidekick.projectTagInPage(sidekick.getPath());
			if (strprojecttag ==""){
		         strprojecttag="Project Tag does not exist.";
		    }
		    else{
		         strprojecttag ="Project: <b>" + strprojecttag + "</b>" ;
		    }
            ATT.wcm.Sidekick.updateshowProjectTagSelectorAction(sidekick, strprojecttag);
			//alert( "'" + JSON.stringify(jsonData) + "'");
	},

	showProjectTagHandler: function() {	
        var sidekick = this;
        ATT.wcm.Sidekick.showProjectTag(sidekick);
		
    },

	updateshowProjectTagSelectorAction: function(sidekick, actionLabel) {
		var actns = sidekick.actns;
		ATT.wcm.Sidekick.SHOWPROJECTTAG.text=CQ.I18n.getMessage(actionLabel); // to fix issue on page onload
		try
		{
			if( actns !=null)
			{
			   for (var i = 0; i < actns.length; i++) {
				if (actns[i].handler == ATT.wcm.Sidekick.showProjectTagHandler) {
					actns[i].setText(CQ.I18n.getMessage(actionLabel));
					break;
				}
			   }
			 }
		}catch(e){/* alert("Error SHOWPROJECTTAG"); */}	
	},
		
};

ATT.wcm.Sidekick.SHOWPROJECTTAG = {
    text: CQ.I18n.getMessage("Project Tag:"),
    handler: ATT.wcm.Sidekick.showProjectTagHandler,
    context: [ CQ.wcm.Sidekick.PAGE ]
};

ATT.wcm.Sidekick.CHANGEPROJECTTAG = {
	    text: CQ.I18n.getMessage("Tag This Page"),
	    handler: ATT.wcm.Sidekick.changeProjectTagHandler,
	    context: [ CQ.wcm.Sidekick.PAGE ]
};
/* End Project Tag Code */

ATT.wcm.Sidekick.DEACTIVATE = {
    text: CQ.I18n.getMessage("Deactivate"),
    handler: ATT.wcm.Sidekick.deactivatePageHandler,
    context: [ CQ.wcm.Sidekick.PAGE ]
};
/**
 * When the sidekick is loaded, we want to change the value of the "Project" button to contain
 * the name of the Tagged project.
 */
CQ.Ext.onReady(function() {
	CQ.WCM.on("sidekickready", function(sidekick) {
		ATT.wcm.Sidekick.showProjectTag(sidekick);
	});	
});

CQ.wcm.Sidekick.DEFAULT_ACTIONS = CQ.Ext.flatten([ATT.wcm.Sidekick.DEACTIVATE, CQ.wcm.Sidekick.DEFAULT_ACTIONS]);
/* Start  Project Tag Code*/
CQ.wcm.Sidekick.DEFAULT_ACTIONS = CQ.Ext.flatten([ATT.wcm.Sidekick.CHANGEPROJECTTAG, CQ.wcm.Sidekick.DEFAULT_ACTIONS]);
CQ.wcm.Sidekick.DEFAULT_ACTIONS = CQ.Ext.flatten([ATT.wcm.Sidekick.SHOWPROJECTTAG, CQ.wcm.Sidekick.DEFAULT_ACTIONS]);
/* End Project Tag Code */


CQ.wcm.ComponentList.MAX_GROUPS = 6;