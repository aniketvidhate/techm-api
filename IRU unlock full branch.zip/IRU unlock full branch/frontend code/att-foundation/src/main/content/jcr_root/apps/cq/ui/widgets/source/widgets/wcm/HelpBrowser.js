/*
 * Copyright 1997-2011 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */

CQ.wcm.HelpBrowser = {};

/**
 * The path of the CQ5 User Guide displayed by the help browser.
 * @static
 * @final
 * @type String
 */
CQ.wcm.HelpBrowser.path = "en/cq/current.html";

/**
 * Returns a definition for a button that, when clicked, displays
 * the help browser.
 * @param {String} path (Optional) the help content path to open
 *        (defaults to {@link CQ.wcm.HelpBrowser.path}).
 * @static
 */
CQ.wcm.HelpBrowser.createHelpButton = function(path) {
    path = CQ.wcm.HelpBrowser.preparePath(path);
    return {
        "text":    CQ.I18n.getMessage("Help"),
        "tooltip": {
            "title":    CQ.I18n.getMessage("CQ5 User Guide Test"),
            "text":     CQ.I18n.getMessage("Browse the online help"),
            "autoHide": true
        },
        "handler":function() {
            CQ.wcm.HelpBrowser.show(path);
        }
    };
};

CQ.wcm.HelpBrowser.preparePath = function(path) {
    path = typeof path == "string" ? path : CQ.wcm.HelpBrowser.path;
    path = CQ.I18n.getVarMessage(path);
    if (path.charAt(0) != "/") {
        path =  "/libs/day-docs/content/" + path;
    }
    return CQ.HTTP.externalize(path);
};

CQ.wcm.HelpBrowser.show = function(path) {
    path = CQ.wcm.HelpBrowser.preparePath(path);
    if (!path.indexOf(CQ.HTTP.externalize('/libs/day-docs/content/')) ) {
        CQ.wcm.HelpBrowser.offerDocs(path);
        return;
    }
    CQ.shared.Util.open(path).focus();
};

CQ.wcm.HelpBrowser.offerDocs = function(path) {
   // var packageSharePath = CQ.I18n.getVarMessage("/crx/packageshare/index.html/packageshare/packages/public.html");
   // Always displaying Online Help
    var pathTail = path.split("/libs/day-docs/content/")[1];
    pathTail = pathTail.slice(pathTail.indexOf('/')); 
    
    var onlinePath = CQ.I18n.getVarMessage("http://dev.day.com/docs/en")+ pathTail;
   // onlinePath = onlinePath.replace("/current/","/5-5/");

 /* var title = CQ.I18n.getMessage("Documentation not installed");
    var msg = CQ.I18n.getMessage("Package Share offers CQ5 documentation in several languages for local installation. Would you like to proceed to Package Share?");

    CQ.wcm.HelpBrowser.instance = null;
    CQ.Ext.Msg.show({
       title: title,
       msg: msg,
       buttons: CQ.Ext.Msg.YESNO,
       fn: function(btn){
           if (btn == "yes")
               CQ.shared.Util.open(CQ.HTTP.externalize(packageSharePath)).focus();
           else
               CQ.shared.Util.open(onlinePath).focus();
       },
       icon: CQ.Ext.MessageBox.QUESTION
    });*/
    CQ.shared.Util.open(onlinePath).focus();
};

CQ.wcm.HelpBrowser.nodocs = function() {
    CQ.wcm.HelpBrowser.instance = null;
    CQ.Ext.Msg.alert(
        CQ.I18n.getMessage("Documentation not available"),
        CQ.I18n.getMessage("Unable to load CQ5 documentation."));
};
