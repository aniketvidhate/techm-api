
/**
 * @class CQ.form.rte.plugins.ATTLinkDialog
 * Overwriting the LinkDialog - adding dropdown to add styles for modal js
 * @extends CQ.form.rte.ui.BaseWindow
 * @private
 * The LinkDialog is a dialog for creating a link.
 * @constructor
 * Creates a new LinkDialog.
 * @param {Object} config The config object
 */
CQ.form.rte.plugins.ATTLinkDialog = CQ.Ext.extend(CQ.form.rte.ui.BaseWindow, {

    constructor: function(config) {
        config = config || { };
        var defaults = {
            "title": CQ.I18n.getMessage("Hyperlink"),
            "modal": true,
            "width": 400,
            "height": 270,
            "dialogItems": [ {
                    "itemId": "href",
                    "name": "href",
                    "parBrowse": true,
                    "anchor": CQ.themes.Dialog.ANCHOR,
                    "fieldLabel": CQ.I18n.getMessage("Link to"),
                    "xtype": "pathfield",
                    "ddGroups": [
                        CQ.wcm.EditBase.DD_GROUP_PAGE,
                        CQ.wcm.EditBase.DD_GROUP_ASSET
                    ],
                    "fieldDescription": CQ.I18n.getMessage("Drop files or pages from the Content Finder"),
                    "listeners": {
                        "dialogselect": {
                            "fn": this.selectAnchor,
                            "scope": this
                        },
                        "render": this.initHrefDragAndDrop
                    },
                    "validator": this.validateLink.createDelegate(this),
                    "validationEvent": "keyup"
                }, {
                    "itemId": "targetBlank",
                    "name": "targetBlank",
                    "xtype": "checkbox",
                    "boxLabel": CQ.I18n.getMessage("Open in new window"),
                    "value": "targetBlank"
                }, {
                    "itemId": "modalStyle",
                    "name": "modalStyle",
                    "xtype": "selection",
                    "type": "select",
                    "fieldLabel": CQ.I18n.getMessage("Modal style"),
                    "options": [
                        {"itemId":"modal1","text":"None","value":""},
                        {"itemId":"modal2","text":"Modal 505", "value":"modal505"},
                        {"itemId":"modal3","text":"Modal 705", "value":"modal705"},
                        {"itemId":"modal4","text":"Modal 705x400", "value":"modal705x400"},
                        {"itemId":"modal5","text":"Channel", "value":"channelModal"},
                        {"itemId":"modal6","text":"Local Modal", "value":"localModal"},
                        {"itemId":"modal7","text":"Auto Width Modal", "value":"modalXXX"}
                    ]
                }, {
                    "itemId": "linkTag",
                    "name": "linkTag",
                    "xtype": "textfield",                    
                    "fieldLabel": CQ.I18n.getMessage("Link Tag")                
                }
            ]
        };
        CQ.Util.applyDefaults(config, defaults);
        CQ.form.rte.plugins.ATTLinkDialog.superclass.constructor.call(this, config);
    },

    /**
     * @private
     */
    selectAnchor: function(pathfield, path, anchor) {
        // custom path + anchor handling
        path = CQ.HTTP.encodePath(path);
        if (anchor && (anchor.length > 0)) {
            path += ".html#" + anchor;
        }
        pathfield.setValue(path);
    },

    /**
     * <p>Note that this method is executed in the scope of the pathfield.</p>
     * @private
     */
    initHrefDragAndDrop: function() {
        if (this.ddGroups) {
            if (typeof(this.ddGroups) == "string") {
                this.ddGroups = [ this.ddGroups ];
            }
            var field = this;
            var target = new CQ.wcm.EditBase.DropTarget(this.el, {
                "notifyDrop": function(dragObject, evt, data) {
                    if (dragObject && dragObject.clearAnimations) {
                        dragObject.clearAnimations(this);
                    }
                    if (dragObject.isDropAllowed(this)) {
                        if (data.records && data.single) {
                            var record = data.records[0];
                            var path = record.get("path");
                            field.setValue(CQ.HTTP.encodePath(path));
                            evt.stopEvent();
                            return true;
                        }
                        return false;
                    }
                }
            });

            var dialog = this.findParentByType(CQ.form.rte.plugins.ATTLinkDialog);
            dialog.on("activate", function(dialog) {
                if (dialog && dialog.el && this.highlight) {
                    var dialogZIndex = parseInt(dialog.el.getStyle("z-index"), 10);
                    if (!isNaN(dialogZIndex)) {
                        this.highlight.zIndex = dialogZIndex + 1;
                    }
                }
            }, target);
            dialog.on("deactivate", function(dialog) {
                if (dialog && dialog.el && this.highlight) {
                    var dialogZIndex = parseInt(dialog.el.getStyle("z-index"), 10);
                    if (!isNaN(dialogZIndex)) {
                        this.highlight.zIndex = dialogZIndex + 1;
                    }
                }
            }, target);
            var editorKernel = dialog.getParameter("editorKernel");
            dialog.on("show", function() {
                editorKernel.fireUIEvent("preventdrop");
                CQ.WCM.registerDropTargetComponent(field);
            }, target);
            dialog.on("hide", function() {
                CQ.WCM.unregisterDropTargetComponent(field);
                editorKernel.fireUIEvent("reactivatedrop");
            }, target);

            for (var i = 0; i < this.ddGroups.length; i++) {
                target.addToGroup(this.ddGroups[i]);
            }
            target.removeFromGroup(CQ.wcm.EditBase.DD_GROUP_DEFAULT);
            this.dropTargets = [ target ];
        }
    },

    preprocessModel: function() {
        if (this.objToEdit && this.objToEdit.dom) {
            this.objToEdit.href = CQ.form.rte.HtmlRules.Links.getLinkHref(
                    this.objToEdit.dom);
        }
    },

    dlgFromModel: function() {
        var hrefField = this.getFieldByName("href");
        if (hrefField) {
            var value = "";
            if (this.objToEdit) {
                var href = this.objToEdit.href;
                if (href) {
                    value = href;
                }
            }
            hrefField.setValue(value);
        }
        var targetBlankField = this.getFieldByName("targetBlank");
        if (targetBlankField) {
            var target = (this.objToEdit && this.objToEdit.target
                    ? this.objToEdit.target.toLowerCase() : null);
            targetBlankField.setValue(target == "_blank");
        }
        var styleField = this.getFieldByName("modalStyle");
        if (styleField) {
            var value = "";
            if (this.objToEdit) {
                var cssClass = this.objToEdit.cssClass;
                if (cssClass) {
                    value = cssClass.substring(10);
                }
            }
            styleField.setValue(value);
        }      
        var tagField = this.getFieldByName("linkTag");
        if (tagField) {
        	var value = "";
        	if (this.objToEdit) {
        		var tag = this.objToEdit.tag;
        		if (tag) {
        			value = tag;
        		}
        	}
        	tagField.setValue(value);
        }
    },

    dlgToModel: function() {
        var hrefField = this.getFieldByName("href");
        if (hrefField) {
            if (this.objToEdit) {
                var href = hrefField.getValue();
                if (href) {
                    this.objToEdit.href = href;
                }
            }
        }
        var targetBlankField = this.getFieldByName("targetBlank");
        if (targetBlankField) {
            if (targetBlankField.getValue()) {
                this.objToEdit.target = "_blank";
            } else {
                this.objToEdit.target = null;
            }
        }
        var modalStyleField = this.getFieldByName("modalStyle");
        if (modalStyleField) {
            if (modalStyleField.getValue()) {
                this.objToEdit.cssClass = "openModal " + modalStyleField.getValue();
            } else {
                this.objToEdit.cssClass = null;
            }
        }
        var tagField = this.getFieldByName("linkTag");
        if (tagField) {
        	if (tagField.getValue()) {
        		this.objToEdit.tag = tagField.getValue();
        	} else {
        		this.objToEdit.tag = null; 
        	}
        }
    },

    postprocessModel: function() {
        var linkRules = this.parameters.linkRules;
        if (linkRules) {
            linkRules.applyToObject(this.objToEdit);
        }
    },

    validateLink: function() {
        var href = this.getFieldByName("href");
        if (!href) {
            return false;
        }
        href = href.getValue();
        var linkRules = this.getParameter("linkRules");
        if (!linkRules) {
            return (href.length > 0);
        }
        return linkRules.validateHref(href);
    }

});

// register LinkDialog component as xtype
CQ.Ext.reg("rtelinkdialog", CQ.form.rte.plugins.ATTLinkDialog);