package com.att.ecom.cq.bundle.admanager.impl;

import static org.apache.commons.lang.StringUtils.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;
import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

import com.att.ecom.cq.bundle.admanager.AdManagerElement;

public class AdManagerElementImpl implements AdManagerElement {

    public AdManagerElementImpl(final String name, ResourceResolver resourceResolver) {
        this.name = name;
        this.resourceResolver = resourceResolver;
    }

    private final DateFormat outputFormat = new SimpleDateFormat(
            "MM/dd/yyyy kk:mm");

    // tag name
    private final String name;

    protected final ResourceResolver resourceResolver;

    // potential cdata value
    private String cdata;

    // attributes
    private Map<String, String> attrs = new TreeMap<String, String>();

    // potential children
    private ArrayList<AdManagerElement> children = new ArrayList<AdManagerElement>();

    // has content
    protected boolean hasContent() {
        int x = this.attrs.size() + this.children.size();
        if (this.cdata != null && StringUtils.trimToNull(this.cdata) != null) {
            x++;
        }
        return x > 0;
    }

    /* format AdManager uses in XML output; e.g., "08/08/2011 00:00:00 GMT-0800" */

    // -------------------------------------------------------------------------
    // ADD CHILD ELEMENTS
    // -------------------------------------------------------------------------

    // add child <cta> tags
    protected void addChildCtas(Resource r) {
        if (r == null) {
            return;
        }
        Iterator<Resource> iR = r.listChildren();
        while (iR.hasNext()) {
            AdManagerElementImpl x = new AdManagerElementImpl("cta", resourceResolver);
            x.addCtaAttrs(iR.next());
            if (x.hasContent()) {
                this.children.add(x);
            }
        }
    }

    // add child <event> tags
    protected void addChildEvents(Resource r) {
        if (r == null) {
            return;
        }
        Iterator<Resource> children = r.listChildren();
        while (children.hasNext()) {
            AdManagerElementImpl e = new AdManagerElementImpl("event", resourceResolver);
            e.addEventAttrs(children.next());
            if (e.hasContent()) {
                this.children.add(e);
            }
        }
    }

    // add child <schedule> tag from day-of-week schedule
    protected void addChildDowSchedule(Resource r) {
        if (r == null) {
            return;
        }
        AdManagerElementImpl s = new AdManagerElementImpl("schedule", resourceResolver);
        s.addAttrs(r, "monday", "tuesday", "wednesday", "thursday", "friday",
                "saturday", "sunday");
        if (s.hasContent()) {
            s.attrs.put("daysOfWeek", "1");
            this.children.add(s);
        }
    }

    // add child <geo> tag
    protected void addChildGeo(Resource r) {
        if (r == null) {
            return;
        }
        AdManagerElementImpl g = new AdManagerElementImpl("geo", resourceResolver);
        g.addAttrs(r, "include", "exclude");
        if (g.hasContent()) {
            this.children.add(g);
        }
    }

    // add child <lib> tags
    protected void addChildElements(Resource r, String childName,
            String... attrNames) {
        if (r == null) {
            return;
        }
        Iterator<Resource> iR = r.listChildren();
        while (iR.hasNext()) {
            AdManagerElementImpl l = new AdManagerElementImpl(childName, resourceResolver);
            l.addAttrs(iR.next(), attrNames);
            this.children.add(l);
        }
    }

    // add child <schedule> tag from on/off times
    protected void addChildOnOffTimes(Resource resource) {
        if (resource == null) {
            return;
        }
        String timeZone = "GMT-0800";
        ValueMap parentMap = resource.getParent().adaptTo(ValueMap.class);
        if (parentMap.containsKey("timeZone")) {
            timeZone = parentMap.get("timeZone", String.class).trim();
        }
        Iterator<Resource> iR = resource.listChildren();
        while (iR.hasNext()) {
            Resource r = iR.next();
            ValueMap m = r.adaptTo(ValueMap.class);
            String on = this.outputFormat.format(m.get("onTime", Date.class))
                    + ":00 " + timeZone;
            String off = this.outputFormat.format(m.get("offTime", Date.class)) + ":59 "
                    + timeZone;
            AdManagerElementImpl s = new AdManagerElementImpl("schedule", resourceResolver);
            s.attrs.put("startDate", on);
            s.attrs.put("endDate", off);
            this.children.add(s);
        }
    }

    protected void addChildTransitions(Resource r) {
        if (r == null) {
            return;
        }
        Iterator<Resource> children = r.listChildren();
        while (children.hasNext()) {
            AdManagerElementImpl t = new AdManagerElementImpl("transition", resourceResolver);
            t.addTransitionAttrs(children.next());
            // add <transition> tag as child to <asset> tag
            if (t.hasContent()) {
                this.children.add(t);
            }
        }
    }

    protected void addChildVersions(Resource r) {
        if (r == null) {
            return;
        }
        Iterator<Resource> iR = r.listChildren();
        while (iR.hasNext()) {
            AdManagerElementImpl v = new AdManagerElementImpl("version", resourceResolver);
            v.addVersionAttrs(iR.next());
            // add <version> tag as child to <asset> tag
            if (v.hasContent()) {
                this.children.add(v);
            }
        }
    }
    
    protected void addChildDropdwnBtn(Resource r) {
        if (r == null) {
            return;
        }
        AdManagerElementImpl t=null;
        if(r.getResourceType().equalsIgnoreCase("att/marketing/admanager/components/assets/dropdownbutton")){
            t = new AdManagerElementImpl("button", resourceResolver);
        }else{
            t = new AdManagerElementImpl("failure", resourceResolver);
        }
            t.addDropdwnBtnAttrs(r);
            if (t.hasContent()) {
                this.children.add(t);
            }
       
    }
    
    protected void addChildDropdwnOption(Resource r) {
        if (r == null) {
            return;
        }
        if(r!=null && r.getResourceType().equalsIgnoreCase("att/marketing/admanager/components/assets/dropdownoption")){
            AdManagerElementImpl t = new AdManagerElementImpl("option", resourceResolver);
            t.addDropdwnOptionAttrs(r);
            if (t.hasContent()) {
                this.children.add(t);
            }
        }
       
    }
    // -------------------------------------------------------------------------
    // ADD ATTRIBUTES
    // -------------------------------------------------------------------------

    protected void addAttrs(Resource r, String... attributes) {
        if (attributes != null && attributes.length > 0 && r != null) {
            ValueMap properties = r.adaptTo(ValueMap.class);
            for (String attribute : attributes) {
                String value = StringEscapeUtils.escapeXml(properties.get(attribute, String.class));
                if (isNotBlank(value)) {
                    this.attrs.put(attribute, value.trim());
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // ASSETS
    // -------------------------------------------------------------------------

    protected void addAssetAttrs(Resource resource) {
        if (resource == null) {
            return;
        }
        this.addChildOnOffTimes(resource.getChild("onOffTimes"));
        this.addChildDowSchedule(resource.getChild("schedule"));
        this.addChildGeo(resource.getChild("geo"));
        if (resource.getChild("transitionHolder")!=null) {
            this.addChildTransitions(resource.getChild("transitionHolder").getChild("transitions"));
        }
        if (resource.getChild("ctaHolder")!=null) {
            this.addChildCtas(resource.getChild("ctaHolder").getChild("callsToAction"));
        }
        if (resource.getChild("versionHolder")!=null) {
            this.addChildVersions(resource.getChild("versionHolder").getChild("versions"));
        }
        // Unique to different asset types
        String assetResourceType = resource.getResourceType();
        if (assetResourceType
                .equals("att/marketing/admanager/components/assets/button")) {
            this.addButtonAssetAttrs(resource);
        } else if (assetResourceType
                .equals("att/marketing/admanager/components/assets/link")) {
            this.addLinkAssetAttrs(resource);
        } else if (assetResourceType
                .equals("att/marketing/admanager/components/assets/media")) {
            this.addMediaAssetAttrs(resource);
        } else if (assetResourceType
                .equals("att/marketing/admanager/components/assets/text")) {
            this.addTextAssetAttrs(resource);
        }else if (assetResourceType
                .equals("att/marketing/admanager/components/assets/legaltext")) {
            this.addLegalTextAssetAttrs(resource);  
        }else if (assetResourceType
                .equals("att/marketing/admanager/components/assets/dropdown")) {
            this.addDropdownAssetAttrs(resource);
        }else if (assetResourceType
                .equals("att/marketing/admanager/components/assets/irudiscounts")) {
            this.addIRUDiscountAssetAttrs(resource);
        }
        
        if (resource.getChild("failuretext")!=null) {
            this.addChildDropdwnBtn(resource.getChild("failuretext"));
        }
        if (resource.getChild("dropdownbutton")!=null) {
            this.addChildDropdwnBtn(resource.getChild("dropdownbutton"));
        }
        if (resource.getChild("optionpar")!=null) {
            Iterator<Resource> optionIterator=resource.getChild("optionpar").listChildren();
            while(optionIterator.hasNext()){
                this.addChildDropdwnOption(optionIterator.next());
                }
        }
    }

    // asset types
    protected void addButtonAssetAttrs(Resource asset) {
        if (asset == null) {
            return;
        }
        this.attrs.put("type", "Button");
        this.addAttrs(asset, "align", "alignTo", "alpha", "height",
                "horizontalPlacement", "html", "name", "styleLib", "rotation",
                "verticalPlacement", "width", "x", "y");
        // Label element
        ValueMap map = asset.adaptTo(ValueMap.class);
        if (map.containsKey("label")) {
            AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
            l.cdata = map.get("label", String.class).trim();
            this.children.add(l);
        }
    }

    protected void addLinkAssetAttrs(Resource asset) {
        if (asset == null) {
            return;
        }
        this.attrs.put("type", "Link");
        this.addAttrs(asset, "align", "alignTo", "alpha", "antiAlias",
                "height", "horizontalPlacement",
                "hoverUnderline", "leading", "letterSpacing", "multiline",
                "name", "rotation", "verticalPlacement", "width", "wordWrap",
                "x", "y");
                
        
        ValueMap map = asset.adaptTo(ValueMap.class);
        // Map URLs
        if (map.containsKey("bulletIcon")) {
            this.attrs.put( "bulletIcon",resourceResolver.map( map.get("bulletIcon", String.class).trim()) );
        }
        // Combine style properties into cssClass property.
        if (map.containsKey("size") || map.containsKey("color")
                || map.containsKey("styleName") || map.containsKey("other")) {
            String s = "";
            String size = map.get("size", String.class);
            if (isNotBlank(size)) {
                s += "size" + size.trim() + ",";
            }
            String color = map.get("color", String.class);
            if (isNotBlank(color)) {
                s += color.trim() + ",";
            }
            String styleName = map.get("styleName", String.class);
            if (isNotBlank(styleName)) {
                s += styleName.trim() + ",";
            }
            String other = map.get("other", String.class);
            if (isNotBlank(other)) {
                s += other.trim();
            }
            s = StringUtils.strip(s, ",").trim();
            this.attrs.put("cssClass", s);
        }
        // Label element
        if (map.containsKey("label")) {
            AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
            l.cdata = map.get("label", String.class).trim();
            this.children.add(l);
        }
    }

    protected void addMediaAssetAttrs(Resource resource) {
        if (resource == null) {
            return;
        }
        this.attrs.put("type", "Media");
        this.addAttrs(resource, "alignTo", "alpha", "alt", "height",
                "horizontalPlacement", "isVideo", "loop", "mouseEnabled",
                "name", "preload", "rotation", "verticalPlacement",
                "width", "x", "y");
        // Map URLs
        ValueMap map = resource.adaptTo(ValueMap.class);
        if (map.containsKey("source")) {
            this.attrs.put( "source",resourceResolver.map( map.get("source", String.class).trim()) );
        }
        
        Resource parmeters = resource.getChild("parameters");
        if (parmeters != null) {
            Iterator<Resource> iR = parmeters.listChildren();
            String paramsValue = "";
            while (iR.hasNext()) {
                ValueMap m = iR.next().adaptTo(ValueMap.class);

                paramsValue += m.get("name", String.class).trim() + "=";
                paramsValue += m.get("value", String.class).trim();
                if (iR.hasNext()) {
                    paramsValue += "&amp;";
                }
            }
            this.attrs.put("params", paramsValue);
        }
    }
    
    protected void addIRUDiscountAssetAttrs(Resource resource) {
        if (resource == null) {
            return;
        }
        this.attrs.put("type", "Text");
        this.addAttrs(resource, "align", "alignTo", "alpha", "antiAlias",
                "height", "horizontalPlacement", "html", "leading",
                "letterSpacing", "multiline", "name", "rotation",
                "verticalPlacement", "width", "wordWrap", "x", "y");
        // Combine style properties into cssClass property.

        ValueMap map = resource.adaptTo(ValueMap.class);
        if (map.containsKey("size") || map.containsKey("color")
                || map.containsKey("styleName") || map.containsKey("other")) {
            String s = "";
            String size = map.get("size", String.class);
            if (isNotBlank(size)) {
                s += "size" + size.trim() + ",";
            }
            String color = map.get("color", String.class);
            if (isNotBlank(color)) {
                s += color.trim() + ",";
            }
            String styleName = map.get("styleName", String.class);
            if (isNotBlank(styleName)) {
                s += styleName.trim() + ",";
            }
            String other = map.get("other", String.class);
            if (isNotBlank(other)) {
                s += other.trim();
            }
            s = StringUtils.strip(s, ",").trim();
            this.attrs.put("cssClass", s);
        }
        if (map.containsKey("showCompany")) {
            String showCompany = map.get("showCompany", String.class);
            showCompany = showCompany!=null ? showCompany.trim():"";
            if(showCompany.equalsIgnoreCase("yes")){
                AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
                l.cdata = "{IRU_COMPANY_NAME}";
                this.children.add(l);
            }
        }
        if (map.containsKey("discountType") && map.containsKey("displayText")) {
            AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
            String discountType = map.get("discountType", String.class);
            discountType = discountType!=null ? discountType.trim():"";
            if(discountType.length()>0 && !discountType.trim().equalsIgnoreCase("None")){
                String displayText = map.get("displayText", String.class);
                displayText = displayText!=null ? displayText.trim():"";
                if(discountType.equals("accessory"))
                    displayText = displayText.replace("IRU_DISCOUNT_VALUE","IRU_DISCOUNT_VALUE_ACCESSORY");
                if(discountType.equals("service"))
                    displayText = displayText.replace("IRU_DISCOUNT_VALUE","IRU_DISCOUNT_VALUE_SERVICE");
                if(discountType.equals("equipment"))
                    displayText = displayText.replace("IRU_DISCOUNT_VALUE","IRU_DISCOUNT_VALUE_DEVICE");
                l.cdata = displayText;
                this.children.add(l);
            }
        }
    }

    protected void addTextAssetAttrs(Resource resource) {
        if (resource == null) {
            return;
        }
        this.attrs.put("type", "Text");
        this.addAttrs(resource, "align", "alignTo", "alpha", "antiAlias",
                "height", "horizontalPlacement", "html", "leading",
                "letterSpacing", "multiline", "name", "rotation",
                "verticalPlacement", "width", "wordWrap", "x", "y");
        // Combine style properties into cssClass property.

        ValueMap map = resource.adaptTo(ValueMap.class);
        if (map.containsKey("size") || map.containsKey("color")
                || map.containsKey("styleName") || map.containsKey("other")) {
            String s = "";
            String size = map.get("size", String.class);
            if (isNotBlank(size)) {
                s += "size" + size.trim() + ",";
            }
            String color = map.get("color", String.class);
            if (isNotBlank(color)) {
                s += color.trim() + ",";
            }
            String styleName = map.get("styleName", String.class);
            if (isNotBlank(styleName)) {
                s += styleName.trim() + ",";
            }
            String other = map.get("other", String.class);
            if (isNotBlank(other)) {
                s += other.trim();
            }
            s = StringUtils.strip(s, ",").trim();
            this.attrs.put("cssClass", s);
        }
        // Label element
        if (map.containsKey("label")) {
            AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
            l.cdata = map.get("label", String.class).trim();
            this.children.add(l);
        }
    }
    
    protected void addLegalTextAssetAttrs(Resource resource) {
        if (resource == null) {
            return;
        }
        this.attrs.put("type", "Text");
        this.addAttrs(resource, "align", "alignTo", "alpha", "antiAlias",
                "height", "horizontalPlacement", "html", "leading",
                "letterSpacing", "multiline", "name", "rotation",
                "verticalPlacement", "width", "wordWrap", "x", "y");
        // Combine style properties into cssClass property.

        ValueMap map = resource.adaptTo(ValueMap.class);
        if (map.containsKey("size") || map.containsKey("color")
                || map.containsKey("styleName") || map.containsKey("other")) {
            String s = "";
            String size = map.get("size", String.class);
            if (isNotBlank(size)) {
                s += "size" + size.trim() + ",";
            }
            String color = map.get("color", String.class);
            if (isNotBlank(color)) {
                s += color.trim() + ",";
            }
            String styleName = map.get("styleName", String.class);
            if (isNotBlank(styleName)) {
                s += styleName.trim() + ",";
            }
            String other = map.get("other", String.class);
            if (isNotBlank(other)) {
                s += other.trim();
            }
            s = StringUtils.strip(s, ",").trim();
            this.attrs.put("cssClass", s);
        }
        // Label element
        AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
        javax.jcr.Node textNode=null;
                if (map.containsKey("textlocation")) {
                AdManagerElementImpl tl = new AdManagerElementImpl("textlocation", resourceResolver);
                AdManagerElementImpl dt = new AdManagerElementImpl("descType", resourceResolver);
                String descType=map.get("descType", String.class).trim();
                String htmlPath=map.get("textlocation", String.class).trim();
                try {
                if(resourceResolver.getResource(htmlPath)!=null){
                    textNode=resourceResolver.getResource(htmlPath).adaptTo(Node.class);
                        if(textNode.hasProperty(descType) && textNode.getProperty(descType).getString()!=""){
                            l.cdata=textNode.getProperty(descType).getString().trim();  
                            
                        if(textNode.hasProperty("shortdesclinktext") && textNode.hasProperty("action")
                                            && !textNode.getProperty("shortdesclinktext").getString().equals("") && !textNode.getProperty("action").getString().equals("") && textNode.hasProperty("modalSize")){  
                                                                    
                                    String sAction=textNode.getProperty("action").getString();
                                    String shortDescTargetURL= sAction.trim();
                                    String targetURL=resourceResolver.map(shortDescTargetURL);
                                    String sModal = textNode.getProperty("modalSize").getString();                                              
                                    boolean lineBreak=false;
                                    
                                    if((sAction.lastIndexOf(".")<=0) && (sAction.startsWith("/")) && (sAction.substring(sAction.lastIndexOf("/")).length() > 1 )){
                                        
                                        if(sModal.trim().equals("NA")){                
                                            targetURL+=".html";      
                                            }
                                            else {
                                            if(sAction.trim().contains("jcr:content"))
                                                            targetURL+=".modal.html";
                                            else
                                                            targetURL+=".html";
                                                }                                       
                                    
                          
                                    }
                                    if(textNode.hasProperty("lineBreak")){              
                                    lineBreak = textNode.getProperty("lineBreak").getBoolean();
                                    }
                                    
                                    if(textNode.hasProperty("modalSize") && textNode.getProperty("modalSize").getString().equals("NA") && textNode.hasProperty("targetWindow") && textNode.getProperty("targetWindow").getString()!=""){
                                        if(lineBreak)
                                          l.cdata+="<a href='"+targetURL+"' target='"+textNode.getProperty("targetWindow").getString()+"'><br>"+textNode.getProperty("shortdesclinktext").getString()+"</a>";
                                          else
                                          l.cdata+="<a href='"+targetURL+"' target='"+textNode.getProperty("targetWindow").getString()+"'>"+textNode.getProperty("shortdesclinktext").getString()+"</a>";
                                        
                                    }else if(textNode.hasProperty("modalSize") && (!textNode.getProperty("modalSize").getString().equals("NA"))){
                                        if(lineBreak)
                                          l.cdata+="<a href='"+targetURL+"' class='openModal "+textNode.getProperty("modalSize").getString()+"'><br>"+textNode.getProperty("shortdesclinktext").getString()+"</a>";
                                           else
                                           l.cdata+="<a href='"+targetURL+"' class='openModal "+textNode.getProperty("modalSize").getString()+"'>"+textNode.getProperty("shortdesclinktext").getString()+"</a>";
                                    }
                                }
                        this.children.add(l);   
                        }
                    } 
                    }catch (ValueFormatException e) {
                        e.printStackTrace();
                    } catch (PathNotFoundException e) {
                        e.printStackTrace();
                    } catch (RepositoryException e) {
                        e.printStackTrace();
                    }
            }else{
                if (map.containsKey("label")) {
                // reverted added code for B2C-197803  start            
                l.cdata = map.get("label", String.class).trim();    
                this.children.add(l);
                }
        }   
    }
    
    
    protected void addDropdownAssetAttrs(Resource resource) {
        if (resource == null) {
            return;
        }
        String s="";
        this.attrs.put("type", "Dropdown");
        this.addAttrs(resource, "name","styleLib","width","height", "x", "y");
      
        ValueMap map = resource.adaptTo(ValueMap.class);
        if(map!=null)
        s=cssStyles(map);
        if(null!=s && !s.equals("")){
            this.attrs.put("styleLib", s);  
        }
        if (map.containsKey("label")) {
            AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
            l.cdata = map.get("label", String.class).trim();
            this.children.add(l);
        }
        
        
    }

    // -------------------------------------------------------------------------
    // CTAs & Tracking
    // -------------------------------------------------------------------------

    protected void addCtaAttrs(Resource r) {
        if (r == null) {
            return;
        }
        String ctaResourceType = r.getResourceType();
        // Properties common to all call-to-action types
        this.addAttrs(r, "linkid", "target", "trigger", "webtrendsType");
        // Properties unique to each call-to-action type
        if (ctaResourceType
                .equals("att/marketing/admanager/components/assets/callsToAction/actionScript")) {
            this.attrs.put("action", "AS");
            this.addAttrs(r, "method", "objectPath");
        } else if (ctaResourceType
                .equals("att/marketing/admanager/components/assets/callsToAction/browse")) {
            this.attrs.put("action", "Browse");
            this.addAttrs(r, "method", "url", "window", "modalClass");
        } else if (ctaResourceType
                .equals("att/marketing/admanager/components/assets/callsToAction/javaScript")) {
            this.attrs.put("action", "JS");
            this.addAttrs(r, "method");
        } else if (ctaResourceType
                .equals("att/marketing/admanager/components/assets/callsToAction/trackOnly")) {
            this.attrs.put("action", "TrackOnly");
        }
        // Add child Param tags from "parameters"
        this.addChildElements(r.getChild("parameters"), "param", "name",
                "value");

        // Add child Meta tags from "tracking parameters"
        this.addChildElements(r.getChild("trackingParameters"), "meta", "name",
                "content");

    }

    protected void addEventAttrs(Resource r) {
        if (r == null) {
            return;
        }
        String ctaResourceType = r.getResourceType();
        // Properties common to all call-to-action types
        this.addAttrs(r, "linkid", "target", "trigger", "webtrendsType");
        // Properties unique to each call-to-action type
        if (ctaResourceType
                .equals("att/marketing/admanager/components/marqueeCTAs/actionScript")) {
            this.attrs.put("action", "AS");
            this.addAttrs(r, "method", "objectPath");
        } else if (ctaResourceType
                .equals("att/marketing/admanager/components/marqueeCTAs/browse")) {
            this.attrs.put("action", "Browse");
            this.addAttrs(r, "method", "url", "window", "modalClass");
        } else if (ctaResourceType
                .equals("att/marketing/admanager/components/marqueeCTAs/javaScript")) {
            this.attrs.put("action", "JS");
            this.addAttrs(r, "method");
        } else if (ctaResourceType
                .equals("att/marketing/admanager/components/marqueeCTAs/trackOnly")) {
            this.attrs.put("action", "TrackOnly");
        }

        // Add params
        Resource parameters = r.getChild("parameters");
        if (parameters != null) {
            Iterator<Resource> iR = parameters.listChildren();
            String p = "";
            while (iR.hasNext()) {
                ValueMap m = iR.next().adaptTo(ValueMap.class);

                p += m.get("name", String.class) + "="
                        + m.get("value", String.class);
                if (iR.hasNext()) {
                    p += "&amp;";
                }
            }
            if (p.length() > 0) {
                this.attrs.put("params", p);
            }
        }

        // Add child <tracking> element
        Resource trackingParameters = r.getChild("trackingParameters");
        Resource trackingResource = r.getChild("tracking");
        if (trackingParameters != null || trackingResource != null) {
            AdManagerElementImpl tracking = new AdManagerElementImpl("tracking", resourceResolver);
            if (trackingResource != null) {
                tracking.addAttrs(trackingResource, "dcsMultiTrack", "type");
            }
            if (trackingParameters != null) {
                Iterator<Resource> iR = trackingParameters.listChildren();
                String p = "";
                while (iR.hasNext()) {
                    ValueMap m = iR.next().adaptTo(ValueMap.class);
                    p += m.get("name", String.class) + "="
                            + m.get("content", String.class);
                    if (iR.hasNext()) {
                        p += "&amp;";
                    }
                }
                if (p.length() > 0) {
                    tracking.attrs.put("params", p);
                }
            }
            if (tracking.hasContent()) {
                this.children.add(tracking);
            }
        }
    }

    // -------------------------------------------------------------------------
    // TRANSITIONS
    // -------------------------------------------------------------------------
    protected void addTransitionAttrs(Resource transition) {
        if (transition == null) {
            return;
        }
        String resourceType = transition.getResourceType();
        Resource settings = transition.getChild("settings");
        // Properties common to all transition types
        this.addAttrs(transition, "direction", "duration", "initialDelay",
                "rate");
        // Properties unique to each transition type
        if (resourceType
                .equals("att/marketing/admanager/components/assets/transitions/blur")) {
            this.attrs.put("type", "Blur");
            this.addBlurTransitionAttrs(transition, settings);
        } else if (resourceType
                .equals("att/marketing/admanager/components/assets/transitions/fade")) {
            this.attrs.put("type", "Fade");
            this.addFadeTransitionAttrs(transition, settings);
        } else if (resourceType
                .equals("att/marketing/admanager/components/assets/transitions/slide")) {
            this.attrs.put("type", "Slide");
            this.addSlideTransitionAttrs(transition, settings);
        } else if (resourceType
                .equals("att/marketing/admanager/components/assets/transitions/zoom")) {
            this.attrs.put("type", "Zoom");
            this.addZoomTransitionAttrs(transition, settings);
        }
    }
    
    // -------------------------------------------------------------------------
    // DROPDOWNBUTTON
    // -------------------------------------------------------------------------
    protected void addDropdwnBtnAttrs(Resource dropdwnbtn) {
        if (dropdwnbtn == null) {
            return;
        }
        String s="";
        if(dropdwnbtn!=null && dropdwnbtn.getResourceType().equalsIgnoreCase("att/marketing/admanager/components/assets/dropdownbutton")){
            this.putAttribute("type", "Button");
            this.addAttrs(dropdwnbtn, "name","styleLib","align","alpha", "x", "y","width","height");
            ValueMap map = dropdwnbtn.adaptTo(ValueMap.class);
                if(map!=null)
                    s=cssStyles(map);
                    if(null!=s && !s.equals("")){
                        this.attrs.put("styleLib", s);  
                    }
                if (map.containsKey("label")) {
                    AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
                    l.cdata = map.get("label", String.class).trim();
                    this.children.add(l);
                }
         }else{
                    this.putAttribute("type", "Text");
                    this.addAttrs(dropdwnbtn, "align","alpha","antiAlias","cssClass","leading","name","width","height", "x", "y");
                    ValueMap map = dropdwnbtn.adaptTo(ValueMap.class);
                    if(map!=null)
                        s=cssStyles(map);
                        if(null!=s && !s.equals("")){
                            this.attrs.put("cssClass", s);  
                        }
                    if (map.containsKey("label")) {
                        AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
                        // reverted added code for B2C-197803  start
                        l.cdata = map.get("label", String.class).trim();
                        this.children.add(l);
                    }
              
             }

    }

 // -------------------------------------------------------------------------
    // DROPDOWN Option
    // -------------------------------------------------------------------------
    protected void addDropdwnOptionAttrs(Resource dropdwnoption) {
        if (dropdwnoption == null) {
            return;
        }
        String s="";
        this.putAttribute("type", "Link");
        this.addAttrs(dropdwnoption, "align","alpha","antiAlias","cssClass","hoverUnderline", "leading","name");
        ValueMap map = dropdwnoption.adaptTo(ValueMap.class);
        if(map!=null)
            s=cssStyles(map);
            if(null!=s && !s.equals("")){
                this.attrs.put("cssClass", s);  
            }
        if (map.containsKey("label")) {
            AdManagerElementImpl l = new AdManagerElementImpl("label", resourceResolver);
            l.cdata = map.get("label", String.class).trim();
            this.children.add(l);
        }
        if (dropdwnoption.getChild("ctaHolder")!=null) {
            this.addChildCtas(dropdwnoption.getChild("ctaHolder").getChild("callsToAction"));
        }

    }
    // transition types
    protected void addBlurTransitionAttrs(Resource transition, Resource settings) {
        if (settings == null) {
            return;
        }
        AdManagerElementImpl s = new AdManagerElementImpl("settings", resourceResolver);
        s.addAttrs(settings, "blurX", "blurY", "ease", "quality");
        if (s.hasContent()) {
            this.children.add(s);
        }
    }

    protected void addFadeTransitionAttrs(Resource transition, Resource settings) {
        if (settings == null) {
            return;
        }
        AdManagerElementImpl s = new AdManagerElementImpl("settings", resourceResolver);
        s.addAttrs(settings, "brightness", "ease");
        if (s.hasContent()) {
            this.children.add(s);
        }
    }

    protected void addSlideTransitionAttrs(Resource transition,
            Resource settings) {
        if (settings == null) {
            return;
        }
        AdManagerElementImpl s = new AdManagerElementImpl("settings", resourceResolver);
        s.addAttrs(settings, "blurX", "blurY", "ease");
        if (s.hasContent()) {
            this.children.add(s);
        }
    }

    protected void addZoomTransitionAttrs(Resource transition, Resource settings) {
        if (settings == null) {
            return;
        }
        AdManagerElementImpl s = new AdManagerElementImpl("settings", resourceResolver);
        s.addAttrs(settings, "blurX", "blurY", "ease");
        if (s.hasContent()) {
            this.children.add(s);
        }
    }

    // -------------------------------------------------------------------------
    // VERSIONS
    // -------------------------------------------------------------------------

    protected void addVersionAttrs(Resource r) {
        if (r == null) {
            return;
        }
        this.addAttrs(r, "note");
        this.addChildOnOffTimes(r.getChild("onOffTimes"));
        this.addChildDowSchedule(r.getChild("schedule"));
        this.addChildGeo(r.getChild("geo"));
        this.addChildCtas(r.getChild("callsToAction"));

        // unique to each asset/version type
        String versionResourceType = r.getResourceType();
        if (versionResourceType
                .equals("att/marketing/admanager/components/assets/versions/button")) {
            this.addButtonAssetAttrs(r);
        } else if (versionResourceType
                .equals("att/marketing/admanager/components/assets/versions/link")) {
            this.addLinkAssetAttrs(r);
        } else if (versionResourceType
                .equals("att/marketing/admanager/components/assets/versions/media")) {
            this.addMediaAssetAttrs(r);
        } else if (versionResourceType
                .equals("att/marketing/admanager/components/assets/versions/text")) {
            this.addTextAssetAttrs(r);
        }else if (versionResourceType
                .equals("att/marketing/admanager/components/assets/versions/legaltext")) {
            this.addLegalTextAssetAttrs(r);
            
        }
        
    }
    
    public String cssStyles(ValueMap map){
        String s = "";
        if (map.containsKey("size") || map.containsKey("color")
                || map.containsKey("styleName") || map.containsKey("other")) {
           
            String size = map.get("size", String.class);
            if (isNotBlank(size)) {
                s += "size" + size.trim() + ",";
            }
            String color = map.get("color", String.class);
            if (isNotBlank(color)) {
                s += color.trim() + ",";
            }
            String styleName = map.get("styleName", String.class);
            if (isNotBlank(styleName)) {
                s += styleName.trim() + ",";
            }
            String other = map.get("other", String.class);
            if (isNotBlank(other)) {
                s += other.trim();
            }
            s = StringUtils.strip(s, ",").trim();
            //this.attrs.put("cssClass", s);
        }
        return s;
    }

    // -------------------------------------------------------------------------
    // BUILD XML
    // -------------------------------------------------------------------------
    public String xml() {
        // build this element's attributes string
        String attributes = "";
        for (Map.Entry<String, String> e : this.attrs.entrySet()) {
            attributes += e.getKey() + "=\"" + e.getValue() + "\" ";
        }
        // trim cdata
        this.cdata = StringUtils.trimToNull(this.cdata);
        attributes = StringUtils.trimToNull(attributes);
        // build this element's string
        String xml = "<" + this.name;
        if (attributes != null) {
            xml += " " + attributes.trim();
        }
        // Close tag if no children
        if (!this.hasContent()) {
            xml += " />";
        } else {
            xml += ">";
            if (this.cdata != null) {
                xml += "<![CDATA[" + this.cdata + "]]>";
            }
            if (this.children.size() > 0) {
                Iterator<AdManagerElement> i = this.children.iterator();
                while (i.hasNext()) {
                    xml += i.next().xml();
                }
            }
            xml += "</" + this.name + ">";
        }
        return xml;
    }

    protected boolean containsAttribute(String key) {
        return this.attrs.containsKey(key);
    }

    protected String getAttribute(String key) {
        return this.attrs.get(key);
    }
    
    protected void putAttribute(String key, String value) {
        this.attrs.put(key, value);
    }

    protected void addChild(AdManagerElement child) {
        this.children.add(child);
    }

    protected void setCData(String string) {
        this.cdata = string;
    }
}
