package com.att.ecom.cq.bundle.admanager.impl;

import java.util.Iterator;

import javax.jcr.Node;

import java.text.Format;
import java.util.Date;

import org.apache.commons.lang.time.FastDateFormat;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.helpers.HashGenHelper;

public class Panel extends AdManagerElementImpl {
	
	private static final Logger log = LoggerFactory.getLogger(Panel.class);
	private static final String FMT_PATH_AND_DATE = ";%tY%<tj";

	public Panel(final String name, final Resource resource, final String slotId) {
		super(name, resource.getResourceResolver());
		
		// Add node UUID into the json
		Node rn = resource.adaptTo(Node.class);
		String nodeUUID = null; 
		String jDate=null;
		try { 
				nodeUUID = HashGenHelper.getMd5ForResource(rn.getPath());
				if (rn != null) { 
					if (rn.hasProperty("jcr:lastModified")) {  
						Date pdate = rn.getProperty("jcr:lastModified").getDate().getTime(); 
						jDate = String.format(FMT_PATH_AND_DATE, pdate);
					} else if (rn.hasProperty("cq:lastModified")) { 
						Date pdate = rn.getProperty("cq:lastModified").getDate().getTime(); 
						jDate = String.format(FMT_PATH_AND_DATE, pdate); 
					} else { 
						jDate = ""; 
					} 
				} nodeUUID += jDate;
			
 
		}
		catch (Exception e) {
			log.error(e.getMessage());
		}
		
		Resource info = resource.getChild("info");
		ValueMap infoMap = info.adaptTo(ValueMap.class);
		Resource par = resource.getChild("par");
		// Add properties from Panel Info dialog
		this.addAttrs(info, "alt", 
				"backgroundHorizontalPlacement", "backgroundVerticalPlacement", "contentID",
				"description", "name", "overlayHorizontalPlacement",
				"overlayVerticalPlacement", "rotationDelay", 
				"useJSAM","hoverWidth","imageText");
		// T-Data
		if (!slotId.equals("")) {
			putAttribute("slotId", slotId);
		} 
		
		putAttribute("cmsId", "CQ");
				
		if (nodeUUID != null) {
			putAttribute("cNodeUUID", nodeUUID);
		} 
		// Map URLs
		if (infoMap.containsKey("background")) {
			putAttribute("background", resourceResolver.map( infoMap.get("background", String.class).trim()));
		}
		if (infoMap.containsKey("thumbnail")) {
			putAttribute("thumbnail", resourceResolver.map( infoMap.get("thumbnail", String.class).trim()));
		}
		if (infoMap.containsKey("overlay")) {
			putAttribute("overlay", resourceResolver.map( infoMap.get("overlay", String.class).trim()));
		}
		//added code for B2C-197803  start 
        if (infoMap.containsKey("backgroundColor")) {
            
            String bgcolor=resourceResolver.map( infoMap.get("backgroundColor", String.class).trim());
            if (bgcolor.contains("/"))
                bgcolor= bgcolor.replace("/", "");
               putAttribute("backgroundColor",bgcolor);
        }
        //added code for B2C-197803  end
		// Add days of week to daysOfWeekSchedule object.
		this.addChildDowSchedule(info.getChild("schedule"));
		// Get on/off times for panel and create new <schedule> tag for
		// each.
		this.addChildOnOffTimes(info.getChild("onOffTimes"));
		// Get geo targeting properties and create new <geo> tag.
		this.addChildGeo(info.getChild("geo"));
		// Get external libraries for panel and create new <lib> tag for
		// each.
		this.addChildElements(info.getChild("externalLibraries"), "lib", "baseclass", "baseClass", "id", "path");
		// Create Style object if Style Libraries or Append CSS are defined.
		Resource styleNode = info.getChild("style");
		Resource styleLibraries = info.getChild("styleLibraries");
		if (styleLibraries != null && styleNode != null) {
			AdManagerElementImpl s = new AdManagerElementImpl("style", resourceResolver);
			s.addChildElements(styleLibraries, "lib", "baseclass", "baseClass", "id", "path");

			if (styleNode != null) {
				ValueMap styleMap = styleNode.adaptTo(ValueMap.class);
				if (styleMap.containsKey("appendCSS")) {
					AdManagerElementImpl a = new AdManagerElementImpl("appendCSS", resourceResolver);
					a.setCData(styleMap.get("appendCSS", String.class).trim());
					s.addChild(a);
				}
			}
			if (s.hasContent()) {
				this.addChild(s);
			}
		}
		// Add assets
		if(par != null) {
			Iterator<Resource> childNodes = par.listChildren();
			while (childNodes.hasNext()) {
				AdManagerElementImpl a = new AdManagerElementImpl("asset", resourceResolver);
				a.addAssetAttrs(childNodes.next());
				this.addChild(a);
			}
		}

	}

}
