package com.att.ecom.cq.bundle.admanager.impl;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;

import com.att.ecom.cq.bundle.admanager.AdManagerElement;
import com.att.ecom.cq.bundle.admanager.AdManagerElementBuilder;
import com.day.cq.wcm.api.Page;

@Component
@Service
public class AdManagerElementBuilderImpl implements AdManagerElementBuilder {

	// MARQUEES
	public AdManagerElement buildMarquee(String name, Page page) {
		return new Marquee(name, page.getContentResource());
	}

	// PANELS
	public AdManagerElement buildPanel(String name, Page page) {
		return new Panel(name, page.getContentResource(), "");
	}

}
