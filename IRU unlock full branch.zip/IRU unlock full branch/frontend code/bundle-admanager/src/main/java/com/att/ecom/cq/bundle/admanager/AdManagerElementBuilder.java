package com.att.ecom.cq.bundle.admanager;

import com.day.cq.wcm.api.Page;

public interface AdManagerElementBuilder {

	public AdManagerElement buildMarquee(String name, Page page);
	public AdManagerElement buildPanel(String name, Page page);
}
