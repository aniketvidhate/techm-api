package com.att.ecom.cq.bundle.admanager.impl;

import java.util.Iterator;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.PathNotFoundException;
import javax.jcr.ValueFormatException;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Marquee extends AdManagerElementImpl {

	
	private static final Logger log = LoggerFactory.getLogger(Marquee.class);

	public Marquee(final String name, final Resource resource) {
		super(name, resource.getResourceResolver());
		Resource info = resource.getChild("info");
		ValueMap infoMap = info.adaptTo(ValueMap.class);
		// Add properties from Panel Info dialog
		this.addAttrs(info, "applyBitmapCaching", "applyMask",
				"backgroundHorizontalPlacement", "backgroundVerticalPlacement",
				"blendAfterChildren", "blendTransitions", "border",
				"borderColor", "borderWidth", "contentID", "installDefaultMenu",
				"installDefaultStyleLib", "installDefaultStyleSheet",
				"installDefaultTooltip", "installWebTrends",
				"maintainAspectRatioBackground", "maintainAspectRatioOverlay",
				"overlayHorizontalPlacement", "overlayVerticalPlacement",
				"preload", "rotationDelay", "scaleBackground", "scaleOverlay",
				"trackRotation", "transitionDuration", "transitionRate");

		// Map URLs
		if (infoMap.containsKey("onErrorImage")) {
			putAttribute( "onErrorImage",resourceResolver.map( infoMap.get("onErrorImage", String.class).trim()));
		}
		if (infoMap.containsKey("onErrorURL")) {
			putAttribute( "onErrorURL",resourceResolver.map( infoMap.get("onErrorURL", String.class).trim()));
		}
		if (infoMap.containsKey("background")) {
			putAttribute( "background",resourceResolver.map( infoMap.get("background", String.class).trim()));
		}
		if (infoMap.containsKey("overlay")) {
			putAttribute( "overlay",resourceResolver.map( infoMap.get("overlay", String.class).trim()));
		}
		// Add child transitions
		if (info.getChild("transitionHolder")!=null) {
			this.addChildTransitions(info.getChild("transitionHolder").getChild("transitions"));
		}

		// Add child CTAs
		if (info.getChild("ctaHolder")!=null) {
			this.addChildEvents(info.getChild("ctaHolder").getChild("callsToAction"));
		}

		// Add custom menu
		if (this.containsAttribute("installDefaultMenu")
				&& this.getAttribute("installDefaultMenu").equals("0")) {
			Resource menuNode = info.getChild("menu");
			if (menuNode != null) {
				AdManagerElementImpl menu = new AdManagerElementImpl("menu", resourceResolver);
				ValueMap menuMap = menuNode.adaptTo(ValueMap.class);
				menu.addAttrs(menuNode, "baseClass", "horizontalPlacement",
						"path", "verticalPlacement", "x", "y");
				// Map URLs
				if (menuMap.containsKey("path")) {
					putAttribute( "path",resourceResolver.map( menuMap.get("path", String.class).trim()));
				}		
				// Add settings element to menu
				Resource settingsNode = menuNode.getChild("settings");
				if (settingsNode != null) {
					AdManagerElementImpl settings = new AdManagerElementImpl(
							"settings", resourceResolver);
					settings.addAttrs(settingsNode,
							"backgroundHorizontalPadding",
							"backgroundVerticalPadding", "buttonSize",
							"controlPlacement", "dividerPadding",
							"horizontalPlacement", "verticalPlacement");
					if (settings.hasContent()) {
						menu.addChild(settings);
					}
				}
				if (menu.hasContent()) {
					this.addChild(menu);
				}
			}
		}
		// Add custom tooltip
		if (this.containsAttribute("installDefaultTooltip")
				&& this.getAttribute("installDefaultTooltip").equals("0")) {
			Resource tooltipNode = info.getChild("tooltip");
			ValueMap tooltipMap = tooltipNode.adaptTo(ValueMap.class);
			AdManagerElementImpl tooltip = new AdManagerElementImpl("tooltip", resourceResolver);
			// Map URLs
			if (infoMap.containsKey("path")) {
				putAttribute( "path",resourceResolver.map( tooltipMap.get("path", String.class).trim()));
			}
			// Add settings element to tooltip
			Resource settingsNode = tooltipNode.getChild("settings");
			if (settingsNode != null) {
				AdManagerElementImpl settings = new AdManagerElementImpl(
						"settings", resourceResolver);
				settings.addAttrs(settingsNode, "horizontalPadding",
						"horizontalPlacement", "iconPadding", "iconSize",
						"minHeight", "minWidth", "verticalPadding",
						"verticalPlacement");
				if (settings.hasContent()) {
					tooltip.addChild(settings);
				}
			}
			if (tooltip.hasContent()) {
				this.addChild(tooltip);
			}
		}
		// Add stylesheets & style libraries
		Resource stylesheets = info.getChild("stylesheets");
		Resource styleLibraries = info.getChild("styleLibraries");
		if (stylesheets != null && styleLibraries != null) {
			AdManagerElementImpl style = new AdManagerElementImpl("style", resourceResolver);
			style.addChildElements(stylesheets, "stylesheet", "path");
			style.addChildElements(styleLibraries, "lib", "baseclass", "baseClass", "id", "path");
			if (style.hasContent()) {
				this.addChild(style);
			}
		}
		// Add external libraries
		this.addChildElements(info.getChild("externalLibraries"), "lib", "baseclass", "baseClass", "id", "path");

		// Add child panels
		Resource panels = info.getChild("panels");
		if (panels != null) {
			Iterator<Resource> iN = panels.listChildren();
			while (iN.hasNext()) {
				Resource r = iN.next();
				Node n = r.adaptTo(Node.class);
				String path = r.adaptTo(ValueMap.class)
						.get("path", String.class)
						+ "/jcr:content";
				String slotId = "";
				try {
					slotId = n.hasProperty("slotId") ? n.getProperty("slotId").getString() : "";
				} catch(RepositoryException e) {
				}
				
				Resource panelResource = panels.getResourceResolver().getResource(path);
				
				//add panel to marquee only if its a valid panel
				if(panelResource != null){
					this.addChild(new Panel("panel", panels.getResourceResolver()
						.getResource(path), slotId));
				} else {
					log.error("The Panel resource:" + path + ": not found for Marquee:"+info.getParent().getPath());
				}
			}
		}
	}

}
