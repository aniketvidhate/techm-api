package com.att.ecom.cq.bundle.admanager;

public interface AdManagerElement {

	String xml();

}
