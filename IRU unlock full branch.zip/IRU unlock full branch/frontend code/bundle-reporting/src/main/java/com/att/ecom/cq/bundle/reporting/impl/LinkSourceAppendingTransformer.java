package com.att.ecom.cq.bundle.reporting.impl;

import java.io.IOException;
import java.util.Stack;

import org.apache.sling.rewriter.ProcessingComponentConfiguration;
import org.apache.sling.rewriter.ProcessingContext;
import org.apache.sling.rewriter.Transformer;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

/**
 * The actual transformer class for attaching the link source as an attribute to link tags.
 */
public class LinkSourceAppendingTransformer implements Transformer {

    /**
     * The attribute types for text
     */
    private static final String TYPE_CDATA = "CDATA";

    /**
     * The blank string.
     */
    private static final String BLANK = "";
    
    /**
     * The semicolon string.
     */
    private static final String SEMI_COLON = ";";
    
    
    /**
     * The back slash string.
     */
    private static final String BACK_SLASH = "/";

    /**
     * The element name for anchor tags.
     */
    private static final String TAG_A = "a";

    /**
     * The attribute name for class.
     */
    private static final String ATTR_CLASS = "class";

    /**
     *  The attribute name for id.
     */
    private static final String ATTR_ID = "id";

    /**
     * The element name for span tags.
     */
    private static final String TAG_SPAN = "span";
    
    /**
     * The attribute name for cqpath.
     */
    private static final String CQPATH = "cqpath";

    /**
     * A SAX Document Locator object.
     */
    @SuppressWarnings("unused")
    private Locator mDocumentLocator;

    /**
     * The next content handler to invoke.
     */
    private ContentHandler mNextHandler;

    /**
     * A stack containing the component paths.
     */
    private final Stack<String> mComponentPaths;

    /**
     * A stack containing a flag as to whether or not the current element is a component.
     */
    private final Stack<Boolean> mComponentTriggers;

    /**
     * The class name for wrapper span tags.
     */
    private final String mWrapperClassName;

    /**
     * The attribute name in which the component path should be stored.
     */
    private final String mSourceAttributeName;

    /**
     * Construct a new transformer instance.
     * 
     * @param pWrapperClassName
     *            the wrapper class name
     * @param pSourceAttributeName
     *            the attribute name to add on output
     */
    public LinkSourceAppendingTransformer(final String pWrapperClassName, final String pSourceAttributeName) {
        this.mWrapperClassName = pWrapperClassName;
        this.mSourceAttributeName = pSourceAttributeName;
        this.mComponentPaths = new Stack<String>();
        this.mComponentTriggers = new Stack<Boolean>();
    }

    /**
     * No-op. Hand off to next handler.
     */
    public void characters(final char[] pCh, final int pStart, final int pLength) throws SAXException {
        this.mNextHandler.characters(pCh, pStart, pLength);
    }

    /**
     * No-op.
     */
    @Override
    public void dispose() {
    }

    /**
     * No-op. Hand off to next handler.
     */
    public void endDocument() throws SAXException {
        this.mNextHandler.endDocument();
    }

    /**
     * When the element ends, if this is a triggered element, remove the top item from the paths queue.
     * 
     * @param pUri
     *            the namespace URI for the element
     * @param pLocalName
     *            the localName of the element
     * @param pQName
     *            the qname of the element
     */
    public void endElement(final String pUri, final String pLocalName, final String pQName) throws SAXException {
        if (TAG_SPAN.equals(pLocalName)) {
            if (this.mComponentTriggers.isEmpty()) {
                this.mNextHandler.endElement(pUri, pLocalName, pQName);
            } else {
                final boolean trigger = this.mComponentTriggers.pop();
                if (trigger) {
                    this.mComponentPaths.pop();
                } else {
                    this.mNextHandler.endElement(pUri, pLocalName, pQName);
                }
            }
        } else {
            this.mNextHandler.endElement(pUri, pLocalName, pQName);
        }
    }

    /**
     * No-op. Hand off to next handler.
     */
    public void endPrefixMapping(final String pPrefix) throws SAXException {
        this.mNextHandler.endPrefixMapping(pPrefix);
    }

    /**
     * No-op. Hand off to next handler.
     */
    public void ignorableWhitespace(final char[] pCh, final int pStart, final int pLength) throws SAXException {
        this.mNextHandler.ignorableWhitespace(pCh, pStart, pLength);
    }

    /**
     * No-op. Hand off to next handler.
     */
    @Override
    public void init(final ProcessingContext pContext, final ProcessingComponentConfiguration pConfig)
            throws IOException {
    }

    /**
     * No-op. Hand off to next handler.
     */
    public void processingInstruction(final String pTarget, final String pData) throws SAXException {
        this.mNextHandler.processingInstruction(pTarget, pData);
    }

    /**
     * Rebuild the attributes for an element. If the source attribute is already there, do not overwrite it. If it is
     * not found, add a new attribute with the containing component path.
     * 
     * @param pLocalName
     *            the local name of the element
     * @param pAttrs
     *            the original attributes
     * 
     * @return the rebuilt attributes
     */
    private Attributes rebuildAttributes(final String pLocalName, final Attributes pAttrs) {
        String componentPath = this.mComponentPaths.peek();
        AttributesImpl newAttrs = new AttributesImpl(pAttrs);
        int length = newAttrs.getLength();

        boolean found = false;
        String cqpath = null;

        for (int i = 0; i < length; i++) {
            String attrName = newAttrs.getLocalName(i);
            if(attrName.equals(CQPATH)){
            	cqpath = newAttrs.getValue(i);          	
            }
            if (this.mSourceAttributeName.equals(attrName)) {
                found = true;
                break;
            }
        }

        if (!found) {        	
        	if(componentPath.contains(SEMI_COLON)){
        		String[] splits = componentPath.split(SEMI_COLON);
        		componentPath = cqpath!=null?splits[0]+BACK_SLASH+cqpath+SEMI_COLON+splits[1]:componentPath;
        	} else {
        		componentPath = cqpath!=null?componentPath+BACK_SLASH+cqpath:componentPath;
        	}
            newAttrs.addAttribute(BLANK, this.mSourceAttributeName, BLANK, TYPE_CDATA, componentPath);
        }

        return newAttrs;
    }

    /**
     * Save the next handler.
     * 
     * @param pHandler
     *            the next handler
     */
    @Override
    public void setContentHandler(final ContentHandler pHandler) {
        this.mNextHandler = pHandler;
    }

    /**
     * Save a document locator.
     * 
     * @param pLocator
     *            the SAX document locator
     */
    @Override
    public void setDocumentLocator(final Locator pLocator) {
        this.mDocumentLocator = pLocator;

    }

    /**
     * No-op. Hand off to next handler.
     */
    public void skippedEntity(String pName) throws SAXException {
        this.mNextHandler.skippedEntity(pName);
    }

    /**
     * No-op. Hand off to next handler.
     */
    public void startDocument() throws SAXException {
        this.mNextHandler.startDocument();
    }

    /**
     * Upon the start of element, store the component's path in the component paths stack.
     * 
     * @param pUri
     *            the namespace URI for the element
     * @param pLocalName
     *            the localName of the element
     * @param pQName
     *            the qname of the element
     * @param pAttrs
     *            the attributes of the element
     */
    public void startElement(final String pUri, final String pLocalName, final String pQName, final Attributes pAttrs)
            throws SAXException {
        if (TAG_SPAN.equals(pLocalName)) {
            final String id = pAttrs.getValue(ATTR_ID);
            final String clazz = pAttrs.getValue(ATTR_CLASS);
            if (this.mWrapperClassName.equals(clazz) && (id != null)) {
                this.mComponentPaths.push(id);
                this.mComponentTriggers.push(true);
            } else {
                this.mComponentTriggers.push(false);
                this.mNextHandler.startElement(pUri, pLocalName, pQName, pAttrs);
            }
        } else if (TAG_A.equals(pLocalName) && !this.mComponentPaths.isEmpty()) {
            this.mNextHandler.startElement(pUri, pLocalName, pQName, rebuildAttributes(pLocalName, pAttrs));
        } else {
            this.mNextHandler.startElement(pUri, pLocalName, pQName, pAttrs);
        }
    }

    /**
     * No-op. Hand off to next handler.
     */
    public void startPrefixMapping(final String pPrefix, final String pUri) throws SAXException {
        this.mNextHandler.startPrefixMapping(pPrefix, pUri);
    }

}