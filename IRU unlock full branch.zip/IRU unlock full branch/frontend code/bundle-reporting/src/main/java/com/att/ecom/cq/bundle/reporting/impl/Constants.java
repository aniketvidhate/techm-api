package com.att.ecom.cq.bundle.reporting.impl;


/**
 * General constants used in reporting implementation.
 *
 */
public class Constants {

    /** prevent construction */
    private Constants() {
    }

    /** The possible properties which can contain the last modified date. */
    static String[] DATE_PROPERTIES = { "cq:lastModified", "jcr:lastModified" };
    
    /** The format used to produce the component path value. */
    static final String FMT_PATH_AND_DATE = "%s;%tY%<tj";
}
