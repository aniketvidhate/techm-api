package com.att.ecom.cq.bundle.reporting.impl;

import java.io.IOException;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

/**
 * Servlet which produces a recursive XML dump of a page and all pages underneath it. By default <page>.xml will only
 * output the jcr:content node.
 */
@SuppressWarnings("serial")
@SlingServlet(resourceTypes = "cq/Page", selectors = "dump", extensions = "xml")
public class XMLDumpServlet extends SlingSafeMethodsServlet {

    /**
     * Error message when the XML dump fails.
     */
    private static final String MSG_UNABLE_TO_DUMP = "Unable to dump XML";

    /**
     * The mime type for XML documents.
     */
    private static final String MIME_XML = "text/xml";

    /**
     * Servlet method to produce the XML dump.
     * 
     * @param pRequest
     *            the request
     * @param pResponse
     *            the response
     */
    @Override
    protected void doGet(final SlingHttpServletRequest pRequest, final SlingHttpServletResponse pResponse)
            throws ServletException, IOException {
        pResponse.setContentType(MIME_XML);
        try {
            pRequest.getResource().adaptTo(Node.class).getSession()
                    .exportDocumentView(pRequest.getResource().getPath(), pResponse.getOutputStream(), true, false);
        } catch (RepositoryException e) {
            throw new ServletException(MSG_UNABLE_TO_DUMP, e);
        }
    }

}
