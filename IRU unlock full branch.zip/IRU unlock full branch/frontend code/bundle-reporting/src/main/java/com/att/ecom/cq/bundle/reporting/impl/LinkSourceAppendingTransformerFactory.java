package com.att.ecom.cq.bundle.reporting.impl;


import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.apache.sling.rewriter.Transformer;
import org.apache.sling.rewriter.TransformerFactory;
import org.osgi.service.component.ComponentContext;

/**
 * Sling rewriter component which looks for <code>span</code> tags with a class name of
 * <code>componentWrapper</code> and the path provided in the span's id as an appended query string parameter
 * for any links within that component.
 */
@Component(immediate = true, metatype = true, enabled = true)
@Service
@Properties({ @Property(name = "pipeline.type", value = "att-reporting-links", propertyPrivate = true) })
public class LinkSourceAppendingTransformerFactory implements
		TransformerFactory {

    /**
     * The default wrapper class name.
     */
	public static final String DEFAULT_WRAPPER_CLASS = "componentWrapper";

	/**
	 * The OSGi configuration property storing the wrapper class name.
	 */
	@Property(value = DEFAULT_WRAPPER_CLASS)
	private static final String PROP_WRAPPER_CLASS = "wrapper.class";

	/**
	 * The default value for the attribute which will contain the path from the wrapper class.
	 */
	public static final String DEFAULT_SOURCE_ATTRIBUTE = "data-cqpath";

	/**
	 * The OSGi configuration property storing the source attribute name.
	 */
	@Property(value = DEFAULT_SOURCE_ATTRIBUTE)
	private static final String PROP_SOURCE_ATTRIBUTE = "source.attribute";

	/**
	 * The wrapper class name.
	 */
	private String mWrapperClassName;

	/**
	 * The output attribute name.
	 */
	private String mSourceAttributeName;

	/**
	 * Activate this component by extracting configuration properties.
	 * 
	 * @param pCtx the OSGi component context
	 */
	protected void activate(final ComponentContext pCtx) {
		this.mWrapperClassName = OsgiUtil.toString(
				pCtx.getProperties().get(PROP_WRAPPER_CLASS),
				DEFAULT_WRAPPER_CLASS);
		this.mSourceAttributeName = OsgiUtil.toString(
				pCtx.getProperties().get(PROP_SOURCE_ATTRIBUTE),
				DEFAULT_SOURCE_ATTRIBUTE);
	}

	/**
	 * Create a new Transfomer instance.
	 */
	@Override
	public Transformer createTransformer() {
		return new LinkSourceAppendingTransformer(this.mWrapperClassName, this.mSourceAttributeName);
	}

}
