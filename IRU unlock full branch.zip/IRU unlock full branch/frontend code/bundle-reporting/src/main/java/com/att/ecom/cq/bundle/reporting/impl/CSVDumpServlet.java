package com.att.ecom.cq.bundle.reporting.impl;

import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.util.TraversingItemVisitor;
import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import au.com.bytecode.opencsv.CSVWriter;

@SuppressWarnings("serial")
@SlingServlet(resourceTypes = "sling/servlet/default", selectors = "reporting", extensions = "csv")
public class CSVDumpServlet extends SlingSafeMethodsServlet {

	private static final Logger LOGGER = LoggerFactory.getLogger(CSVDumpServlet.class);
    /** The header row for the CSV file. */
    private static final String[] HEADER_ROW = new String[] { "cq_path", "cq_component_name", "cq_title", "cq_purpose",
            "cq_language", "cq_product", "cq_component_type", "cq_domain", "cq_page", "cq_page_section",
            "sling_resource_type", "mapped_path" , "image_title" , "image_filename" , "image_size" , "parent_path" ,"link_title", "target_url", "reportingName" };

    /** The mime type of CSV files. */
    private static final String MIME_CSV = "text/csv";

    /** The title to use when the resource type is missing. */
    private static final String MISSING = "MISSING";

    /** The node name of jcr:content nodes. */
    private static final String NN_CONTENT = "jcr:content";

    /** The title to use when no title can be found. */
    private static final String NO_TITLE = "NO TITLE";

    /** The node type of page nodes. */
    private static final String NT_PAGE = "cq:Page";

    /** The node type of page content nodes. */
    private static final String NT_PAGE_CONTENT = "cq:PageContent";

    /** The path delimiter. */
    private static final String PATH_DELIM = "/";

    /** The standard JCR title property name. */
    private static final String PN_JCR_TITLE = "jcr:title";

    /** The Sling resource type property name. */
    private static final String PN_RESOURCE_TYPE = "sling:resourceType";
    
    /** The fileReference Property. */
    private static final String PROPERTY_FILEREFERENCE = "fileReference";
	
    /** The reportingName Property. */
    private static final String PROPERTY_REPORTING_NAME = "reportingName";


    /** The column position for the component name field. */
    private static final int POS_COMPONENT_NAME = 1;

    /** The column position for the component type field. */
    private static final int POS_COMPONENT_TYPE = 6;

    /** The column position for the domain field. */
    private static final int POS_DOMAIN = 7;

    /** The column position for the language field. */
    private static final int POS_LANGUAGE = 4;

    /** The column position for the mapped path. */
    private static final int POS_MAPPED_PATH = 11;
    
    /** The column position for the image title. */
    private static final int POS_IMAGE_TITLE = 12;
    
    /** The column position for the image file name. */
    private static final int POS_IMAGE_FILE_NAME = 13;
    
    /** The column position for the image size. */
    private static final int POS_IMAGE_SIZE = 14;
    
    /** The column position for the parent path. */
    private static final int POS_PARENT_PATH = 15;
    
    /** The column position for the link title. */
    private static final int POS_LINK_TITLE = 16;
    
    /** The column position for the target url. */
    private static final int POS_TARGET_URL = 17;
	
	/** The column position for the reportingName. */
    private static final int POS_REPORTING_NAME = 18;

    /** The column position for the page field. */
    private static final int POS_PAGE = 8;

    /** The column position for the page section field. */
    private static final int POS_PAGE_SECTION = 9;

    /** The column position for the path field. */
    private static final int POS_PATH = 0;

    /** The column position for the product field. */
    private static final int POS_PRODUCT = 5;

    /** The column position for the purpose field. */
    private static final int POS_PURPOSE = 3;

    /** The column position for the resource type field. */
    private static final int POS_RES_TYPE = 10;

    /** The column position for the title field. */
    private static final int POS_TITLE = 2;
    
    /** The Resource type of a Image */
    private static final String IMAGE_RESOURCE_TYPE = "foundation/components/image";
    
    /** The default set of possible title properties. */
    private static final String[] DEFAULT_POSSIBLE_TITLE_PROPERTIES = new String[] { PN_JCR_TITLE, "title",
            "displayText" };

    /** The OSGi configuration property name to store the possible title properties. */
    @org.apache.felix.scr.annotations.Property(label = "Possible Title Properties", value = { PN_JCR_TITLE, "title",
            "displayText" })
    private static final String PROP_POSSIBLE_TITLE_PROPERTIES = "possible.title.properties";

    /**
     * The list of properties which will be checked for the title.
     */
    private String[] mPossibleTitleProperties;
    
    
    /**
     * The array of all the properties used for link url
     */
    private static final String[] LINK_PROPERTIES = new String[] {"url", "linkUrl", "linkurl", "imagelink", "buttonUrl"};   

    
    /**
     * The array of all the properties used for link url
     */
    private static final String[] LINKTEXT_PROPERTIES = new String[] {"linkText", "linktext","buttonText"};
    
    /**
     * The array of all the properties used for link url
     */
    private static final String[] IMAGE_LINK_PROPERTIES = new String[] {"Action","imagelink"};
    
    
    /**
     * Activate this component by setting the possible titles properties.
     * 
     * @param pCtx
     *            the OSGi component context
     */
    @Activate
    protected void activate(final ComponentContext pCtx) {
        this.mPossibleTitleProperties = OsgiUtil.toStringArray(
                pCtx.getProperties().get(PROP_POSSIBLE_TITLE_PROPERTIES), DEFAULT_POSSIBLE_TITLE_PROPERTIES);
    }

    /**
     * Produce the CSV report.
     * 
     * @param pRequest
     *            the request
     * @param pResponse
     *            the response
     * 
     * @throws ServletException
     *             if something goes wrong
     * @throws IOException
     *             if something goes wrong
     */
    @Override
    protected void doGet(final SlingHttpServletRequest pRequest, final SlingHttpServletResponse pResponse)
            throws ServletException, IOException {    	
    	LOGGER.warn("-----------CSV Dump Servlet ----------");
        pResponse.setContentType(MIME_CSV);
        final CSVWriter csv = new CSVWriter(pResponse.getWriter());
        csv.writeNext(HEADER_ROW);

        final Node currentNode = pRequest.getResource().adaptTo(Node.class);
        if (currentNode == null) {
            return;
        }

        final Map<String, String> resourceTypeTitles = new HashMap<String, String>();

        try {
            currentNode.accept(new TraversingItemVisitor.Default() {
                @Override
                protected void entering(Node pNode, int pLevel) throws RepositoryException {
                    String[] line = new String[20];
                    final String path = pNode.getPath();
                    
                    //line[POS_PRODUCT] = " ";
                    
                    line[POS_PATH] = null;
                    for (final String dateProperty : Constants.DATE_PROPERTIES) {
                        if (pNode.hasProperty(dateProperty)) {
                            Calendar cal = pNode.getProperty(dateProperty).getDate();
                            line[POS_PATH] = String.format(Constants.FMT_PATH_AND_DATE, path, cal);
                            break;
                        }
                    }

                    if (line[POS_PATH] == null) {
                        line[POS_PATH] = path;
                    }

                    String[] parts = path.split(PATH_DELIM);
                    if (parts.length > 2) {
                    	line[POS_PURPOSE] = parts[2];
                    }
                    if (parts.length > 3) {
                        line[POS_DOMAIN] = parts[3];
                    }
                    if (parts.length > 4) {
                        line[POS_LANGUAGE] = parts[4];
                    }
                    if (parts.length > 5) {
                        line[POS_PAGE] = parts[5];
                    }

                    line[POS_MAPPED_PATH] = pRequest.getResourceResolver().map(pRequest, pNode.getPath()) + ".html";

                    final ValueMap valueMap = pRequest.getResourceResolver().getResource(pNode.getPath()).adaptTo(ValueMap.class);
                 
                    // add link text and link urls 
                    for (final String eachlinkproperty : LINK_PROPERTIES) {
                    	if(valueMap.containsKey(eachlinkproperty)){    
                    		 for (final String eachlinktextproperty : LINKTEXT_PROPERTIES) {
                             	if(valueMap.containsKey(eachlinktextproperty)){                   	                  
         	                    	line[POS_LINK_TITLE] = valueMap.get(eachlinktextproperty).toString();
                             	} 
                             }
	                       	String url = valueMap.get(eachlinkproperty).toString();
	                    	if(url!=null){	                    		
	                    		 if( (url.lastIndexOf(".")<=0) && (url.startsWith("/content/att/shop/")) && ( url.substring(url.lastIndexOf("/")).length() > 1 ) ){
	                                 url=pRequest.getResourceResolver().map(pRequest,url)+".html";                   
	                             }
	                    		
	                    	}
	                    	line[POS_TARGET_URL] = url;
                    	} 
                    }
                
				
					//adding reporting Name 
					if(valueMap.containsKey(PROPERTY_REPORTING_NAME)){    
                    	line[POS_REPORTING_NAME] = valueMap.get(PROPERTY_REPORTING_NAME).toString();
                    }
                    // adding parent path
                    line[POS_PARENT_PATH] = pNode.getParent().getPath();
                    final String type = pNode.getPrimaryNodeType().getName();
                    line[POS_COMPONENT_TYPE] = type;                
                    if (NT_PAGE.equals(type)) {
                        if (pNode.hasNode(NN_CONTENT)) {
                            Node contentNode = pNode.getNode(NN_CONTENT);
                            if (contentNode.hasProperty(PN_JCR_TITLE)) {
                                line[POS_TITLE] = contentNode.getProperty(PN_JCR_TITLE).getString();
                                line[POS_PAGE_SECTION] = contentNode.getProperty(PN_JCR_TITLE).getString();
                            }
                        }
                    } else if (NT_PAGE_CONTENT.equals(type)) {
                        if (pNode.hasProperty(PN_JCR_TITLE)) {
                            line[POS_TITLE] = pNode.getProperty(PN_JCR_TITLE).getString();
                            line[POS_PAGE_SECTION] = pNode.getProperty(PN_JCR_TITLE).getString();
                        }
                        if (pNode.hasProperty(PN_RESOURCE_TYPE)) {
                            String resourceType = pNode.getProperty(PN_RESOURCE_TYPE).getString();
                            line[POS_RES_TYPE] = resourceType;
                          
                            String resourceTypeShortName = StringUtils.substringAfterLast(resourceType, PATH_DELIM);
                            line[POS_COMPONENT_NAME] = resourceTypeShortName;
                        }
                    } else {
                        final Node containingPage = findContainingPageContent(pNode);
                        if (containingPage != null && containingPage.hasProperty(PN_JCR_TITLE)) {
                            line[POS_PAGE_SECTION] = containingPage.getProperty(PN_JCR_TITLE).getString();
                        }

                        if (pNode.hasProperty(PN_RESOURCE_TYPE)) {
                            String resourceType = pNode.getProperty(PN_RESOURCE_TYPE).getString();
                            line[POS_RES_TYPE] = resourceType;
                            String resourceTypeShortName = StringUtils.substringAfterLast(resourceType, PATH_DELIM);
                            line[POS_COMPONENT_NAME] = resourceTypeShortName;

                            // Adding image property 
                            if(resourceType.equals(IMAGE_RESOURCE_TYPE)){                            	
                            	if(pNode.hasProperty(PROPERTY_FILEREFERENCE)) {
                            				Property fileReferenceProp = pNode.getProperty(PROPERTY_FILEREFERENCE);
                            				String fileReference = null;
                            				if (fileReferenceProp.isMultiple()) {
                            					 Value [] values = fileReferenceProp.getValues();
                            					 if (values.length > 0) {
                            						 fileReference = values[0].getString();
                            					 } else {
                            						 fileReference = "";
                            					 }
                            				} else {
                            					fileReference = fileReferenceProp.getString();
                            				}
		                            		Resource imgResource = pRequest.getResourceResolver().getResource(fileReference);
		                            		if(imgResource != null){
				                            	Asset imgAsset =  imgResource.adaptTo(Asset.class);				                            	
				                            	line[POS_IMAGE_FILE_NAME] = imgAsset.getName();
				                            	
				                            	if(StringUtils.isNotEmpty(imgAsset.getMetadataValue(DamConstants.TIFF_IMAGEWIDTH)) && StringUtils.isNotEmpty(imgAsset.getMetadataValue(DamConstants.TIFF_IMAGELENGTH))){
					                            	long width = Long.valueOf(imgAsset.getMetadataValue(DamConstants.TIFF_IMAGEWIDTH));
					                            	long length = Long.valueOf(imgAsset.getMetadataValue(DamConstants.TIFF_IMAGELENGTH));
					                            	long imgDimension = width * length;
					                            	line[POS_IMAGE_SIZE] = Long.toString(imgDimension);
				                            	}
				                            	Node imgResourceNode = imgResource.adaptTo(Node.class);
				                                ValueMap imgParentValueMap = pRequest.getResourceResolver().getResource(pNode.getParent().getPath()).adaptTo(ValueMap.class);
				                               	
				                                //iterating over image level link properties
				                                for (final String eachlinkproperty : IMAGE_LINK_PROPERTIES) {
				                                	if(imgParentValueMap.containsKey(eachlinkproperty)){				            	                    	
				            	                    	String url = imgParentValueMap.get(eachlinkproperty).toString();
				            	                    	if(url!=null){	                    		
				            	                    		 if( (url.lastIndexOf(".")<=0) && (url.startsWith("/content/att/shop/")) && ( url.substring(url.lastIndexOf("/")).length() > 1 ) ){
				            	                                 url=pRequest.getResourceResolver().map(pRequest,url)+".html";                   
				            	                             }
				            	                    	}
				            	                    	line[POS_TARGET_URL] = url;
				                                	} 
				                                }
				                            	
		                            		} // end of imgResource check		                          
                            		}// end of fileReference property check                            	
                            	} // has image resourceType 
                            
                           
                            // first try setting the title using the resource
                            // type's jcr:title property
                            if (resourceTypeTitles.containsKey(resourceType)) {
                                line[POS_TITLE] = resourceTypeTitles.get(resourceType);
                            } else {
                                resourceTypeTitles.put(resourceType, null);
                                final Resource typeResource = pRequest.getResourceResolver().getResource(resourceType);
                                if (typeResource != null) {
                                    final ValueMap typeMap = typeResource.adaptTo(ValueMap.class);
                                    if (typeMap != null) {
                                        final String typeTitle = typeMap.get(PN_JCR_TITLE, String.class);
                                        if (typeTitle != null) {
                                            line[POS_TITLE] = typeTitle;
                                            resourceTypeTitles.put(resourceType, typeTitle);
                                        } else {
                                            line[POS_TITLE] = NO_TITLE;
                                            resourceTypeTitles.put(resourceType, NO_TITLE);
                                        }
                                    }
                                } else {
                                    line[POS_TITLE] = MISSING;
                                    resourceTypeTitles.put(resourceType, MISSING);
                                }
                            }
                        }

                        // then look for one of the pre-set properties on
                        // this node
                        for (final String titleProperty : CSVDumpServlet.this.mPossibleTitleProperties) {
                            if (pNode.hasProperty(titleProperty)) {
                                final Property prop = pNode.getProperty(titleProperty);
                                if (prop.isMultiple()) {
                                    final Value[] values = prop.getValues();
                                    if (values.length > 0) {
                                        line[POS_TITLE] = values[0].getString();
                                        break;
                                    }
                                } else {
                                    line[POS_TITLE] = prop.getString();
                                    break;
                                }
                            }
                        }

                        final Node topLevelContentNode = findContainingNodeDirectlyUnderPageContent(pNode);
                        if (topLevelContentNode != null) {
                            //line[POS_PAGE_SECTION] = topLevelContentNode.getName();
                        }

                    }
                    
                    
                    line[POS_PRODUCT] = null;
                    csv.writeNext(line);
                }
            });
        } catch (RepositoryException e) {
            throw new ServletException("unable to produce csv", e);
        }
    }

    /**
     * Find the node that contains this node directly under the jcr:content node.
     * 
     * @param pNode
     *            the node to start searching with
     * @return the containing node
     * @throws RepositoryException
     *             if something goes wrong
     */
    private Node findContainingNodeDirectlyUnderPageContent(final Node pNode) throws RepositoryException {
        if (pNode.getPath().equals(PATH_DELIM)) {
            return null;
        }

        if (pNode.getPrimaryNodeType().getName().equals(NT_PAGE_CONTENT)) {
            return null;
        }

        final Node parent = pNode.getParent();
        if (parent.getPrimaryNodeType().getName().equals(NT_PAGE_CONTENT)) {
            return pNode;
        } else {
            return findContainingNodeDirectlyUnderPageContent(parent);
        }
    }

    /**
     * Find the jcr:content node which contains this node.
     * 
     * @param pNodethe
     *            node to start searching with
     * @return the containing node
     * @throws RepositoryException
     *             if something goes wrong
     */
    private Node findContainingPageContent(final Node pNode) throws RepositoryException {
        if (pNode.getPath().equals(PATH_DELIM)) {
            return null;
        }
        final Node parent = pNode.getParent();
        if (parent.getPrimaryNodeType().getName().equals(NT_PAGE_CONTENT)) {
            return parent;
        } else {
            return findContainingPageContent(parent);
        }
    }

}
