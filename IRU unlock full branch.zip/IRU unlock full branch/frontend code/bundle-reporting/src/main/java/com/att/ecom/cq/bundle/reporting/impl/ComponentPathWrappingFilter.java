package com.att.ecom.cq.bundle.reporting.impl;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.Format;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.commons.lang.time.FastDateFormat;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.sling.SlingFilter;
import org.apache.felix.scr.annotations.sling.SlingFilterScope;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;

/**
 * Component-level filter which wraps each component in a span tag with the class <code>componentWrapper</code> and an
 * id of the component's path.
 */
@Component(enabled = true)
@SlingFilter(order = 1, scope = SlingFilterScope.COMPONENT, metatype = true, generateComponent = false)
public class ComponentPathWrappingFilter implements Filter {

    /**
     * The default class name added to wrapper spans.
     */
    public static final String DEFAULT_WRAPPER_CLASS = "componentWrapper";

    /** The extension of HTML requests. */
    private static final String EXTENSION_HTML = "html";

    /** The root path of content in CQ. */
    private static final String PATH_CONTENT = "/content";

    /**
     * The root path of content in CQ. * private static final String PATH_CONTENT = "/content/";
     * 
     * /** The OSGi configuration property containing the wrapper class name.
     */
    @Property(value = DEFAULT_WRAPPER_CLASS)
    private static final String PROP_WRAPPER_CLASS = "wrapper.class";

    /**
     * The text to output for the end of a span.
     */
    private static final String WRAPPER_SPAN_END = "</span>";

    /**
     * The text format to output at the start of the span.
     */
    private static final String WRAPPER_SPAN_START = "<span class=\"%s\" id=\"%s\">";

    /**
     * The wrapper class name.
     */
    private String mWrapperClassName;

    /**
     * Activate this component by configuring the wrapper class name.
     * 
     * @param pCtx
     *            the OSGi component context
     */
    protected void activate(final ComponentContext pCtx) {
        this.mWrapperClassName = OsgiUtil.toString(pCtx.getProperties().get(PROP_WRAPPER_CLASS), DEFAULT_WRAPPER_CLASS);
    }

    /**
     * No-op method.
     */
    @Override
    public void destroy() {
    }

    /**
     * Wrap the result of the filter chain in an HTML span tag with the appropriate attributes.
     * 
     * @param pRequest
     *            the request
     * @param pResponse
     *            the response
     * @param pChain
     *            the filter chain
     * @throws IOException
     *             if something goes wrong
     * @throws ServletException
     *             if something goes wrong
     */
    @Override
    public void doFilter(final ServletRequest pRequest, final ServletResponse pResponse, final FilterChain pChain)
            throws IOException, ServletException {
        final SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) pRequest;
        final String extension = slingRequest.getRequestPathInfo().getExtension();

        final Resource resource = slingRequest.getResource();
        String componentPath = resource.getPath();

        // Only wrap requests with /content and with an html extension
        if (componentPath.startsWith(PATH_CONTENT) && EXTENSION_HTML.equals(extension)) {

            // append the last modified value to the path if it is available.
            final ValueMap properties = resource.adaptTo(ValueMap.class);
            if (properties != null) {
                Date lastMod = null;
                for (final String property : Constants.DATE_PROPERTIES) {
                    Long lastModLong = properties.get(property, Long.class);
                    if (lastModLong != null) {
                        lastMod = new Date(lastModLong);
                        if (lastMod != null) {
                            break;
                        }
                    }
                }
                if (lastMod != null) {
                    componentPath = String.format(Constants.FMT_PATH_AND_DATE, componentPath, lastMod);
                }
            }

            getWriter(pResponse).write(String.format(WRAPPER_SPAN_START, this.mWrapperClassName, componentPath));

            pChain.doFilter(pRequest, pResponse);

            getWriter(pResponse).write(WRAPPER_SPAN_END);
        } else {
            pChain.doFilter(pRequest, pResponse);
        }
    }

    /**
     * Utility method to get the response's writer, either directly or by wrapping the response's output stream.
     * 
     * @param pResponse
     *            the response
     * @return a Writer for the response
     * 
     * @throws IOException
     *             if the Writer can't be retrieved
     */
    private PrintWriter getWriter(final ServletResponse pResponse) throws IOException {
        try {
            return pResponse.getWriter();
        } catch (IllegalStateException e) {
            return new PrintWriter(pResponse.getOutputStream());
        }
    }

    /**
     * No-op method as there's no normal filter configuration.
     */
    @Override
    public void init(final FilterConfig pFilterConfig) throws ServletException {
    }

}
