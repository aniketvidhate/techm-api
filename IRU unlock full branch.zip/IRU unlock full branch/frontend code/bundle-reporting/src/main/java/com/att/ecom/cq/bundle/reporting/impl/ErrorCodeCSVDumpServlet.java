package com.att.ecom.cq.bundle.reporting.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.util.TraversingItemVisitor;
import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;

import au.com.bytecode.opencsv.CSVWriter;

@SuppressWarnings("serial")
@SlingServlet(resourceTypes = "sling/servlet/default", selectors = "reporting-codes", extensions = "csv")
public class ErrorCodeCSVDumpServlet extends SlingSafeMethodsServlet {

    /** The header row for the CSV file. */
    private static final String[] HEADER_ROW = new String[] { "String", "Comment", "EN", "Customer Error", "Mobile EN Message",
    			"Error Class", "Source System" };
    
    private static final String CUSTOMER_ERROR_CODE = "customerErrorCode";
    private static final String POSTFIX_CUSTOMER_ERROR_CODE = "." + CUSTOMER_ERROR_CODE;
    private static final String EN_MOBILE = "enMobile";
    private static final String ES_MOBILE = "esMobile";
    private static final String POSTFIX_MOBILE = ".mobile";
    private static final String SHORT_DESCRIPTION = "shortDescription";
    private static final String POSTFIX_SHORT_DESCRIPTION = "." + SHORT_DESCRIPTION;
    
    /** The mime type of CSV files. */
    private static final String MIME_CSV = "text/csv";

    private static final String ATTR_FILTER = "filter";

    /** The standard JCR title property name. */
    private static final String PN_JCR_TITLE = "jcr:title";

    /** The column position for the component name field. */
    private static final int POS_STRING = 0;

    /** The column position for the component type field. */
    private static final int POS_COMMENT = 1;

    /** The column position for the domain field. */
    private static final int POS_EN = 2;

    /** The column position for the language field. */
    private static final int POS_CUST_ERROR_CODE = 3;

    /** The column position for the mapped path. */
    private static final int POS_MOBILE_EN_MESSAGE = 4;

    /** The column position for the page field. */
    private static final int POS_ERROR_CLASS = 5;

    /** The column position for the page section field. */
    private static final int POS_SOURCESYSTEM = 6;


    /** The default set of possible title properties. */
    private static final String[] DEFAULT_POSSIBLE_TITLE_PROPERTIES = new String[] { PN_JCR_TITLE, "title",
            "displayText" };

    /** The OSGi configuration property name to store the possible title properties. */
    @org.apache.felix.scr.annotations.Property(label = "Possible Title Properties", value = { PN_JCR_TITLE, "title",
            "displayText" })
    private static final String PROP_POSSIBLE_TITLE_PROPERTIES = "possible.title.properties";

    /**
     * The list of properties which will be checked for the title.
     */
    private String[] mPossibleTitleProperties;

    /**
     * Activate this component by setting the possible titles properties.
     * 
     * @param pCtx
     *            the OSGi component context
     */
    @Activate
    protected void activate(final ComponentContext pCtx) {
        this.mPossibleTitleProperties = OsgiUtil.toStringArray(
                pCtx.getProperties().get(PROP_POSSIBLE_TITLE_PROPERTIES), DEFAULT_POSSIBLE_TITLE_PROPERTIES);
    }

    /**
     * Produce the CSV report.
     * 
     * @param pRequest
     *            the request
     * @param pResponse
     *            the response
     * 
     * @throws ServletException
     *             if something goes wrong
     * @throws IOException
     *             if something goes wrong
     */
    @Override
    protected void doGet(final SlingHttpServletRequest pRequest, final SlingHttpServletResponse pResponse)
            throws ServletException, IOException {
    	
    	String filter = (String) pRequest.getParameter(ATTR_FILTER);
    	
        pResponse.setContentType(MIME_CSV);
        final CSVWriter csv = new CSVWriter(pResponse.getWriter());
        csv.writeNext(HEADER_ROW);
        
        ResourceResolver resourceResolver = pRequest.getResourceResolver();
        Resource attHeadNode = resourceResolver.getResource("/etc/i18n/att/label");
        if (attHeadNode == null) {
            return;
        }
        
        Map<String, Translation> translations = new TreeMap<String, Translation>();
        
        
        List<Resource> languageNodes = new ArrayList<Resource>();
        // need to keep a list of the (few) language nodes, iter is so one-time only...
        Iterator<Resource> iter = resourceResolver.listChildren(attHeadNode);
        while (iter.hasNext()) {
            Resource languageNode = iter.next();
            if (getLanguage(languageNode) != null) {
                languageNodes.add(languageNode);
            }
        }
        // keep simple list of languages
        List<String> languages = new ArrayList<String>(languageNodes.size());
        for (int i=0; i < languageNodes.size(); i++) {
            languages.add(getLanguage(languageNodes.get(i)));
        }
        
        
        for (int i=0; i < languageNodes.size(); i++) {
            Resource languageNode = languageNodes.get(i);
            String language = getLanguage(languageNode);
            iter = resourceResolver.listChildren(languageNode);
            while (iter.hasNext()) {
                Resource translationNode = iter.next();
                ValueMap transProps = translationNode.adaptTo(ValueMap.class);
                if (transProps != null) {
                    Translation t = new Translation();
                    t.key = transProps.get("sling:key", String.class);
                    if (t.key == null) {
                        t.key = ResourceUtil.getName(translationNode);
                    }
                    String string = t.key;
                    String comment = "";
		    String message = transProps.get("sling:message", String.class);
                    if (t.key.endsWith("))")) {
                        int commentStart = t.key.indexOf(" ((");
                        string = t.key.substring(0, commentStart);
                        comment = t.key.substring(commentStart + 3, t.key.length() - 2);
                    }
                    
                    if (t.key != null) {
                        if (string.endsWith(POSTFIX_CUSTOMER_ERROR_CODE)) {
                            t.key = string.substring(0, string.length() - POSTFIX_CUSTOMER_ERROR_CODE.length());
                            string = t.key;
                            if (!"".equals(comment)) {
                                t.key = t.key + " ((" + comment + "))";
                            }
                            
                            if (translations.containsKey(t.key)) {
                                t = translations.get(t.key);
                            } else {
                                t.string = string;
                                t.comment = comment;
                                t.translations = new String[languageNodes.size()];
                                for (int j=0; j < t.translations.length; j++) {
                                    t.translations[j] = "";
                                }
                                translations.put(t.key, t);
                            }
                            t.customerErrorCode = message!=null?message.replaceAll("\n", " "):message;
                            t.customerErrorCodeCreated = transProps.get("jcr:lastModified", Date.class);                        
                            if (t.customerErrorCodeCreated == null) {
                                t.customerErrorCodeCreated = transProps.get("jcr:created", Date.class);    
                            }
                            t.customerErrorCodeCreatedBy = transProps.get("jcr:lastModifiedBy", String.class);
                            if (t.customerErrorCodeCreatedBy == null) {
                                t.customerErrorCodeCreatedBy = transProps.get("jcr:createdBy", String.class);
                            }
                        } else if (string.endsWith(POSTFIX_SHORT_DESCRIPTION)) {
                            t.key = string.substring(0, string.length() - POSTFIX_SHORT_DESCRIPTION.length());
                            string = t.key;
                            if (!"".equals(comment)) {
                                t.key = t.key + " ((" + comment + "))";
                            }
                            
                            if (translations.containsKey(t.key)) {
                                t = translations.get(t.key);
                            } else {
                                t.string = string;
                                t.comment = comment;
                                t.translations = new String[languageNodes.size()];
                                for (int j=0; j < t.translations.length; j++) {
                                    t.translations[j] = "";
                                }
                                translations.put(t.key, t);
                            }
                            t.shortDescription = message!=null?message.replaceAll("\n", " "):message;
                            t.shortDescriptionCreated = transProps.get("jcr:lastModified", Date.class);                        
                            if (t.shortDescriptionCreated == null) {
                                t.shortDescriptionCreated = transProps.get("jcr:created", Date.class);    
                            }
                            t.shortDescriptionCreatedBy = transProps.get("jcr:lastModifiedBy", String.class);
                            if (t.shortDescriptionCreatedBy == null) {
                                t.shortDescriptionCreatedBy = transProps.get("jcr:createdBy", String.class);
                            }                        
                        } else if (string.endsWith(POSTFIX_MOBILE)) {
                            t.key = string.substring(0, string.length() - POSTFIX_MOBILE.length());
                            string = t.key;
                            if (!"".equals(comment)) {
                                t.key = t.key + " ((" + comment + "))";
                            }
                            if (translations.containsKey(t.key)) {
                                t = translations.get(t.key);
                            } else {
                                t.string = string;
                                t.comment = comment;
                                t.translations = new String[languageNodes.size()];
                                for (int j=0; j < t.translations.length; j++) {
                                    t.translations[j] = "";
                                }                            
                                translations.put(t.key, t);
                            }
                            if (language.equals("en")) {
                                t.enMobile = message!=null?message.replaceAll("\n", " "):message;
                                t.enMobileCreated = transProps.get("jcr:lastModified", Date.class);
                                if (t.enMobileCreated == null) {
                                    t.enMobileCreated = transProps.get("jcr:created", Date.class);    
                                }
                                t.enMobileCreatedBy = transProps.get("jcr:lastModifiedBy", String.class);
                                if (t.enMobileCreatedBy == null) {
                                    t.enMobileCreatedBy = transProps.get("jcr:createdBy", String.class);
                                }
                                
                                
                            } else if (language.equals("es")) {
                                t.esMobile = message!=null?message.replaceAll("\n", " "):message;
                                t.esMobileCreated = transProps.get("jcr:lastModified", Date.class);
                                if (t.esMobileCreated == null) {
                                    t.esMobileCreated = transProps.get("jcr:created", Date.class);    
                                }
                                t.esMobileCreatedBy = transProps.get("jcr:lastModifiedBy", String.class);
                                if (t.esMobileCreatedBy == null) {
                                    t.esMobileCreatedBy = transProps.get("jcr:createdBy", String.class);
                                }
                            }
                        } else {
                        
                            if (translations.containsKey(t.key)) {
                                t = translations.get(t.key);
                                if (t.users == null) {
                                    t.users = new String[languageNodes.size()];
                                    for (int j=0; j < t.translations.length; j++) {
                                        t.users[j] = "";
                                    }    
                                }
                                if (t.dates == null) {
                                    t.dates = new Date[languageNodes.size()];                                
                                    for (int k=0; k < t.translations.length; k++) {
                                        t.dates[k] = null;
                                    }
                                }
                            } else {
                                t.string = string;
                                t.comment = comment;
                                t.translations = new String[languageNodes.size()];
                                t.users = new String[languageNodes.size()];
                                t.dates = new Date[languageNodes.size()];
                                for (int j=0; j < t.translations.length; j++) {
                                    t.translations[j] = "";
                                    t.users[j] = "";
                                    t.dates[j] = new Date();
                                }
                                translations.put(t.key, t);
                            }
                            t.translations[i] = message!=null?message.replaceAll("\n", " "):message;
                            if (transProps.get("jcr:lastModified", Date.class) == null) {
                                Date date = transProps.get("jcr:created", Date.class);
                                if (date != null) {
                                    t.dates[i] = date; 
                                }   
                            } else {
                                t.dates[i] = transProps.get("jcr:lastModified", Date.class);    
                            }
                            t.users[i] = transProps.get("jcr:lastModifiedBy", String.class);
                            if (t.users[i] == null) {
                                t.users[i] = transProps.get("jcr:createdBy", String.class);
                            }
                        }
                    }
                }
            }
        }
        
        for (Translation t: translations.values()) {
        	String [] transLine = new String [7];
        	transLine[POS_STRING] = t.string;
        	transLine[POS_COMMENT] = t.comment;
        	
        	for (int i=0; i < t.translations.length; i++) {
        		String lang = languages.get(i);
        		String value = t.translations[i];
        		if (lang.equalsIgnoreCase("en")) {
        			transLine[POS_EN] = value;
        			break;
        		}
        	}
        	transLine[POS_CUST_ERROR_CODE] = t.customerErrorCode;
        	transLine[POS_MOBILE_EN_MESSAGE] = t.enMobile;
        	transLine[POS_ERROR_CLASS] = "";
        	transLine[POS_SOURCESYSTEM] = "";
        	
        	if (filter == null || (filter != null && !transLine[POS_STRING].toLowerCase().startsWith(filter.toLowerCase()) ) ) {
        		csv.writeNext(transLine);
        	}
        }
        
        
    }
    
    private String getLanguage(Resource languageNode) {
        ValueMap props = languageNode.adaptTo(ValueMap.class);
        if (props == null) {
            return null;
        }
        return props.get("jcr:language", String.class);
    }
    
    
    private static class Translation {
        String key;
        String string;
        String comment;
        String[] translations;
        String[] users;
        Date[] dates;
        String customerErrorCode;
        Date customerErrorCodeCreated;
        String customerErrorCodeCreatedBy;
        String enMobile;
        Date enMobileCreated;
        String enMobileCreatedBy;
        String esMobile;
        Date esMobileCreated;
        String esMobileCreatedBy;
        String shortDescription;
        Date shortDescriptionCreated;
        String shortDescriptionCreatedBy;
    }
}
