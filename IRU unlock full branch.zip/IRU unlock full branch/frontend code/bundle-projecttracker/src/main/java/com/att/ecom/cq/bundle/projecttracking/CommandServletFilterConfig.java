package com.att.ecom.cq.bundle.projecttracking;

public interface CommandServletFilterConfig {
	
	public String[] getCommands();
	public void setCommands(String[] commands);
}
