package com.att.ecom.cq.bundle.projecttracking.impl.filters;


import java.io.IOException;
import java.net.URLDecoder;
import java.util.Dictionary;
import javax.jcr.Session;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.felix.scr.annotations.Reference;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.apache.sling.api.SlingHttpServletRequest;
import com.att.ecom.cq.bundle.projecttracking.impl.filters.StatusExposingServletResponse;
import com.att.ecom.cq.bundle.projecttracking.ProjectTagConfig;
import com.att.ecom.cq.bundle.projecttracking.ProjectTrackingHelper;
import com.att.ecom.cq.bundle.projecttracking.TagThisPageHelper;

/**
 * Filter to Add Project Tag for the Assets
 * @author Shovon Zaman (sz1004)
 * @created on April 02 2013
 */
@Component(immediate = true, metatype = true, label = "Project Tag Filter Regex", description = "Filter Regex to add Project Tag")
@Service
@Properties({ 
@Property(name = "sling.filter.scope", label = "sling.filter.scope", value = "REQUEST"),
@Property(name = "service.ranking", label = "order", value = "0")
 })


public class ProjectTagFilter implements Filter {
    
    @Reference
    private ProjectTrackingHelper projectTrackingHelper;
    
    @Reference
  	private ProjectTagConfig mProjectTagConfig;
    /**
     * A logger.
     */
    //private final Logger mLogger = LoggerFactory.getLogger(this.getClass());
    /**
     * Activate this component.
     * 
     * @param pCtx
     *            the OSGi component context
     */
    protected void activate(final ComponentContext pCtx) {
        final Dictionary<?, ?> props = pCtx.getProperties();
    }

    /**
     * No-op. Normal filter livecycle ignored.
     */
    @Override
    public void destroy() {
    }

    /**
     * If enabled, construct a redirect path and send a redirect.
     * 
     * @param pRequest
     *            the request
     * @param pResponse
     *            the response
     * @param pChain
     *            the filter chain
     */
    @Override
    public void doFilter(final ServletRequest pRequest, final ServletResponse pResponse, final FilterChain pChain)
            throws IOException, ServletException {
    	
    	   if (pRequest instanceof SlingHttpServletRequest && pResponse instanceof SlingHttpServletResponse) {
	               SlingHttpServletRequest httpServletRequest = (SlingHttpServletRequest) pRequest;
	               SlingHttpServletResponse httpServletResponse = (SlingHttpServletResponse) pResponse;
	               final String url = httpServletRequest.getPathInfo();
	               final String urlpattern=mProjectTagConfig.getDamAssetImportURLPattern();
	               if(url.matches(urlpattern))
	               {
	            	   try {
		            	   final Cookie cookie = httpServletRequest.getCookie(ProjectTrackingHelper.COOKIE_NAME);
		            	   //this.mLogger.debug("\n currentProject Cookie : {} {}", new Object[] { currentProject,"" });
		            	   if (cookie != null) {
		    	            	   final String currentProject = URLDecoder.decode(cookie.getValue(), "UTF-8");
		                		   if (pResponse.getCharacterEncoding() == null) {
		                  	    	   pResponse.setCharacterEncoding("UTF-8"); 
		                  	       }
		                		   StatusExposingServletResponse response = new StatusExposingServletResponse((HttpServletResponse)pResponse);
		    	            	   pChain.doFilter(pRequest, response);
		    	            	   response.flushBuffer();
		    	                   byte[] copy = response.getCopy();
		    	                   int responsestatus = response.getStatus();
		    		               if(responsestatus==200){
		    		            	   String responsstatuscontent=new String(copy, response.getCharacterEncoding());
		    		            	   responsstatuscontent=responsstatuscontent.replaceAll("\\s+","");
		    		            	   String assetpath=responsstatuscontent.replaceAll(".*id=\"Path\">(.*?)</div>.*", "$1");
		    		                   assetpath +="/jcr:content";
		    		                   ResourceResolver resourceResolver = httpServletRequest.getResourceResolver();	
		    		       			   Session session = resourceResolver.adaptTo(Session.class);
		    		       			   Node  topNode =(Node) session.getItem(assetpath);
		    		       			   if (topNode != null) {
		    			       			   projectTrackingHelper.setCurrentProjectProperty(topNode, currentProject);
		    				       		   if (session.hasPendingChanges()) 
		    							   {
		    				       			   session.save();
		    								
		    							   }
		    		       			   }
		    		               }   	   
			             }
		            	 else{
		                	   pChain.doFilter(pRequest, pResponse);
		                 }  
		            	   
	            	   }catch (Exception e) {
		            	  //this.mLogger.error("error",e);
		            	   e.printStackTrace(); 
		               }
	               }
	               else{
	            	   pChain.doFilter(pRequest, pResponse);
	               }
    	   }
           else{
        	   pChain.doFilter(pRequest, pResponse);
           }
        		     	
      }   
    	   
    /**
     * No-op. Normal filter livecycle ignored.
     */
    @Override
    public void init(final FilterConfig pFilterConfig) throws ServletException {
    }

}
