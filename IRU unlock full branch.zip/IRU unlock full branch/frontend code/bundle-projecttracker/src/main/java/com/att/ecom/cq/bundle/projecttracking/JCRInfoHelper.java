/*
 *  Miscellanous helper methods for "Current Project Mouse Enter" and  the Servlet for "Tag This Page" SideKick.
 * @author Shovon Zaman (sz1004)
 * @created on March 02 2013
 */
package com.att.ecom.cq.bundle.projecttracking;

import java.util.ArrayList;
import java.util.List;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;

@Component(metatype = true, immediate = true)
@Service(value=JCRInfoHelper.class)

public class JCRInfoHelper {

    /*
	public static List<JSONObject> getJCRContentpaths(ResourceResolver resourceResolver,final String resourcePath,Node topNode,final String propertyname) {
		final String strPATH="path"; 
	    List<JSONObject> jsonObjectsList = new ArrayList<JSONObject>();  
	    try {
	    	if(topNode==null)
	    	{	
		       Resource topResource = resourceResolver.getResource(resourcePath);
		       topNode = topResource.adaptTo(Node.class);
	    	}   
			if (topNode.hasProperty(propertyname)) 
			{	
				String strpropertyvalue = topNode.getProperty(propertyname).getString() == null ? "" : topNode.getProperty(propertyname).getString();
				JSONObject pathWithPropertyJSON = new JSONObject();
				pathWithPropertyJSON.put(strPATH, topNode.getPath().toString());
				pathWithPropertyJSON.put(propertyname, strpropertyvalue);	
				jsonObjectsList.add(pathWithPropertyJSON);
			}
	        if (topNode.hasNodes()) {
	            NodeIterator childNodes = topNode.getNodes();
	            while (childNodes.hasNext()) 
				{
	                Node childNode = childNodes.nextNode();
	                jsonObjectsList.addAll(getJCRContentpaths(resourceResolver,childNode.getPath(),childNode,propertyname));
	            }
	        }   
	    } 
	    catch (RepositoryException e) {
            e.printStackTrace();
	    }
	    catch (JSONException e) {
            e.printStackTrace();
        }
	    
	    return jsonObjectsList;
	}
	*/
	/*
	 * 
	 */
	public static List<JSONObject> getJCRContentpathPropertyinfo(ResourceResolver resourceResolver,final String resourcePath,Node topNode,final String propertyname) {
		final String strPATH="path"; 
	    List<JSONObject> jsonObjectsList = new ArrayList<JSONObject>();  
	    try {
	    	if(topNode==null)
	    	{	
		       Resource topResource = resourceResolver.getResource(resourcePath);
		       topNode = topResource.adaptTo(Node.class);
	    	}
			if(topNode !=null)
	    	{	
				if (topNode.hasProperty(propertyname)) 
				{	
					String strpropertyvalue = topNode.getProperty(propertyname).getString() == null ? "" : topNode.getProperty(propertyname).getString();
					//if(!(strpropertyvalue.equals(""))){
					JSONObject pathWithPropertyJSON = new JSONObject();
					pathWithPropertyJSON.put(strPATH, topNode.getPath().toString());
					pathWithPropertyJSON.put(propertyname, strpropertyvalue);	
					jsonObjectsList.add(pathWithPropertyJSON);
					//}	
				}
			}	
	    } 
	    catch (RepositoryException e) {
            e.printStackTrace();
	    }
	    catch (JSONException e) {
            e.printStackTrace();
        }
	    return jsonObjectsList;
	}
	
	
}
