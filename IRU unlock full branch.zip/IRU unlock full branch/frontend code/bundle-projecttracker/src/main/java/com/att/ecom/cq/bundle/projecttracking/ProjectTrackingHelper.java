package com.att.ecom.cq.bundle.projecttracking;

import java.util.List;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;

/**
 * Service interface for working with the Project Tracking feature.
 * 
 */
public interface ProjectTrackingHelper {

    /** The name of the cookie in which the current project is stored. */
    public static final String COOKIE_NAME = "attcq.currentproject";

    /** The name of the JCR node property in which the tagged project id is stored. */
    public static final String PROPERTY_NAME = "attcms:currentProject";

    /**
     * The mixin which can be used to add the JCR node property if necessary, i.e. when the node type would otherwise
     * prevent that property from being added.
     */
    public static final String MIXIN_NAME = "attcms:ProjectTaggable";

    /**
     * Query the repository for a list of paths which are tagged with the specified project.
     * 
     * @param pSession the JCR session
     * @param pProjectId the project identifier
     * @return the list of tagged paths
     */
    List<String> getProjectPaths(Session pSession, String pProjectId);
	
	 /**
     * Query the repository for a list of paths which are tagged with the specified project only for Resource Bundles.
     * 
     * @param pSession the JCR session
     * @param pProjectId the project identifier
     * @return the list of tagged paths
     */
    List<String> getResourceBundlePaths(Session pSession, String pProjectId);

    /**
     * Create or update a content package with paths tagged with the specified project id.
     * 
     * @param pResourceResolver the resource resolver
     * @param pProjectId the project id
     * @param pGroupName the group name for the content package
     * @param pPackageName the name of the generated package
     * @return the path to the created content package
     * @throws Exception if something goes wrong
     */
    String createOrUpdateContentPackage(ResourceResolver pResourceResolver, String pProjectId, String pGroupName,
            String pPackageName, String pContentPath) throws Exception;
    /**
     * Determine if a node can be  tag or not
     * 
     * @param pNode
     *            the node to check
     * @return true if the node can be  tag
     * 
     * @throws RepositoryException
     *             if the test is unable to be done
     */
    boolean isNodetaggable(final Node pNode) throws RepositoryException;
    /**
     * Set the project property on the specified node. 
     * 
     * @param pNode the node on which to set the property
     * @param pProjectId the project id to set 
     * 
     * @throws RepositoryException if the property is unable to be set
     */
    void setCurrentProjectProperty(Node pNode, String pProjectId) throws RepositoryException;

    /**
     * Set the project property on the specified node to the value of the cookie. If the cookie
     * is not set, don't do anything.
     * 
     * @param pNode the node on which to set the property
     * @param pRequest the request 
     * 
     * @throws RepositoryException if the property is unable to be set
     */
    void setCurrentProjectProperty(Node pNode, SlingHttpServletRequest pRequest) throws RepositoryException;

}

