/*
 *  Miscellanous helper methods for Project column in the siteadmin.
 * @author Shovon Zaman (sz1004)
 * @created on Jan 20 2014
 */
package com.att.ecom.cq.bundle.projecttracking;
 
import com.day.cq.commons.ListInfoProvider;
import com.day.cq.i18n.I18n;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

 
@Component(metatype = false)
@Service(value = ListInfoProvider.class)
public class ProjectTagInfoProvider implements ListInfoProvider {


    public void updateListGlobalInfo(SlingHttpServletRequest request, JSONObject info, Resource resource) throws JSONException {
        //info.put("project", pProjectId);
       // pProjectId = ""; // reset for next execution
    }
 
 	
    public void updateListItemInfo(SlingHttpServletRequest request, JSONObject info, Resource resource) throws JSONException {
    	try 
		{
    		final String PROPERTY_NAME = "attcms:currentProject"; 
    		String pProjectId = "";
			Node topNode = resource.adaptTo(Node.class);
			if(topNode.hasNode("jcr:content"))
			{
				Node jcrContentNode = topNode.getNode("jcr:content");
				 if (jcrContentNode != null) {
		            if (jcrContentNode.hasProperty(PROPERTY_NAME)) {
						I18n obji18n = new I18n(request.getResourceBundle(null));
						pProjectId=jcrContentNode.getProperty(PROPERTY_NAME).getString();
						if(!(pProjectId.equals(""))){
						    info.put("project", obji18n.get(pProjectId));
						}    
					}
		        }
			}
		}
    	catch (RepositoryException e) 
		{
			 e.printStackTrace();
		}
    	
    }
}