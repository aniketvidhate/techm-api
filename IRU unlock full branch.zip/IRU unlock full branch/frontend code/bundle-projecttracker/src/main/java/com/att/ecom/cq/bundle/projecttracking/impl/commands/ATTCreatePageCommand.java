package com.att.ecom.cq.bundle.projecttracking.impl.commands;

import javax.jcr.Node;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HtmlResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.projecttracking.ProjectTrackingHelper;
import com.day.cq.commons.servlets.HtmlStatusResponseHelper;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.commands.WCMCommand;
import com.day.cq.wcm.api.commands.WCMCommandContext;
import javax.jcr.Session;

@Component
@Service
public class ATTCreatePageCommand implements WCMCommand {

	private static final Logger log = LoggerFactory.getLogger(ATTCreatePageCommand.class);
	
	/**
     * The project tracking helper service.
     */
    @Reference
    private ProjectTrackingHelper projectTrackingHelper;
	
	@Override
	public String getCommandName() {
		return "createPageATT";
	}

	@Override
	public HtmlResponse performCommand(WCMCommandContext context, SlingHttpServletRequest request, 
			SlingHttpServletResponse response, PageManager pageManager) {
		
		try{
			String parentPath = request.getParameter("parentPath");
			String pageLabel = request.getParameter("label");
			String template = request.getParameter("template");
			String pageTitle = request.getParameter("title");
			Page page = pageManager.create(parentPath, pageLabel, template, pageTitle);
			projectTrackingHelper.setCurrentProjectProperty(page.getContentResource().adaptTo(Node.class), request);
			Session session = request.getResourceResolver().adaptTo(javax.jcr.Session.class);
			if (session.hasPendingChanges()) 
			{
					session.save();
			}
			return HtmlStatusResponseHelper.createStatusResponse(true, "Page Created", page.getPath());
		}
		catch (Exception e){
			log.error("Error during page creation.", e);
		}
		return HtmlStatusResponseHelper.createStatusResponse(false, "Error during page creation.");
	}
}