package com.att.ecom.cq.bundle.projecttracking;

import java.util.Arrays;
import java.util.Dictionary;
import java.util.List;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.osgi.framework.Constants;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.commons.osgi.OsgiUtil;

@Component(immediate = true, metatype = true, label = "Project Tag Configuration")
@Service(value = com.att.ecom.cq.bundle.projecttracking.ProjectTagConfig.class)
@Properties({ @Property(name = Constants.SERVICE_DESCRIPTION, value = "Configuration for Project Tag"),
        @Property(name = Constants.SERVICE_VENDOR, value = "CMS@ATT")})
/**
 * It contains the Project Tag global configuration.
 * 
 * @author Shovon Zaman (attuid: sz1004)
 * @Created on March 19, 2014
 */
public class ProjectTagConfig {

    @SuppressWarnings("rawtypes")
    private static Dictionary props = null;
    
    //private static final Logger log = LoggerFactory.getLogger(ProjectTagConfig.class);

    @Property(label = "Path[Type]Action", unbounded=PropertyUnbounded.ARRAY, description = "Add Node Path, Type(regex) and Action(include/exclude) to enable/disable project Tagging ", value = {"/etc/i18n[nt:folder]include" ,"/etc/i18n[sling:OrderedFolder]include","/etc/i18n[sling:Folder]include","/content[nt:folder]exclude" ,"/content[sling:OrderedFolder]exclude","/content[sling:Folder]exclude","/content[^(?!(nt:folder|sling:OrderedFolder|sling:Folder)).*$]include"} )
    private static final String PATH_TYPE_ACTION = "path_type_action";       
    @Property(label = "Page's sling:resourceType Path(s)", unbounded=PropertyUnbounded.ARRAY, description = "to set referencedByModified property as true", value = {"att/common/components/page/sharedcontent/tabbed"} )
    private static final String PAGE_RESOURCE_TYPES = "page_resources_types";
    
    @Property(label = "Filter Component's sling:resourceType Path(s)", unbounded=PropertyUnbounded.ARRAY, description = "to set referencedByModified property as true", value = {"att/wireless/components/listpages/filterparsys/filtergroup","att/wireless/components/listpages/filterparsys/filter","att/wireless/components/listpages/filterparsys/filterranged"} )
    private static final String FILTER_RESOURCE_TYPES = "filter_resources_types";
    
    @Property(label = "Filter Reference Component's sling:resourceType Path(s)", unbounded=PropertyUnbounded.ARRAY, description = "to set referencedByModified property as true", value = {"att/wireless/components/listpages/filterparsys/filterreference"})
    private static final String FILTER_REFERENCE_RESOURCE_TYPES = "filter_reference_resources_types";
    
    @Property(label = "DAM Asset Import URL Pattern", unbounded=PropertyUnbounded.DEFAULT, description = "", value = ".*createasset.html$" )
    private static final String DAM_ASSET_IMPORT_URL_PATTERN = "dam_asset_import_url_pattern";
    

    /**
     * It activates the component.
     * @param ctx ComponentContext object.
     */
    protected void activate(ComponentContext ctx) {
        props = ctx.getProperties();
    }
	 
    public void destroy() {
    }

    public String[] getPathTypeAction() {
		return OsgiUtil.toStringArray(props.get(PATH_TYPE_ACTION), new String[] {});
    }
   
    public String[] getPageResourceTypes() {
        return OsgiUtil.toStringArray(props.get(PAGE_RESOURCE_TYPES), new String[] {});
    }
    public String[] getFilterResourceTypes() {
        return OsgiUtil.toStringArray(props.get(FILTER_RESOURCE_TYPES), new String[] {});
    }
    public String[] getFilterReferenceTypes() {
    	return OsgiUtil.toStringArray(props.get(FILTER_REFERENCE_RESOURCE_TYPES), new String[] {});
    }   
    public String getDamAssetImportURLPattern() {
    	return (String) props.get(DAM_ASSET_IMPORT_URL_PATTERN); 
    }
    
    public Boolean isnodetaggable(String nodepath,String nodetype){
    	String ptaPattern="(.+)\\[(.+)\\](.+)";
    	String[] ptaArray=getPathTypeAction();
    	HashSet<String> ptaset = new HashSet<String> (Arrays.asList(ptaArray));
    	Iterator<String> ptasetIterator = ptaset.iterator();  
        while(ptasetIterator.hasNext()){  
    		String pathactiontype=ptasetIterator.next();
    		if(pathactiontype.matches(ptaPattern)){
    			String path=pathactiontype.replaceAll(ptaPattern, "$1").toString();
    			String type=pathactiontype.replaceAll(ptaPattern, "$2").toString();
    			String action=pathactiontype.replaceAll(ptaPattern, "$3").toString().toUpperCase();
    			String nodepathpattern="^" +  path + ".*$"; 
        		if((nodepath.matches(nodepathpattern))&&(nodetype.matches(type))){
                    //log.debug("path: {} type: {} action: {} nodepathpattern: {}" ,  new Object[] {path,type,action,nodepathpattern});
        			if(action.equals("INCLUDE")){
        				return true;
        			}
        			else if(action.equals("EXCLUDE")){
        				return false;
        			}
    			}
    		}
        }
    	return false;
    }
    public Boolean isPageRestype(String type){
    	return getListArray(getPageResourceTypes()).contains(type);
    }
    public Boolean isFilterComptype(String type){
    	return getListArray(getFilterResourceTypes()).contains(type);
    }
    public Boolean isFilterRefComptype(String type){
    	return getListArray(getFilterReferenceTypes()).contains(type);
    }
    
    public List <String> getListArray(String[] sArray) {
        List <String> sList = Arrays.asList(sArray);
        return sList;
    }     
}
