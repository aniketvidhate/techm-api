package com.att.ecom.cq.bundle.projecttracking.impl;

import static com.att.ecom.cq.bundle.projecttracking.ProjectTrackingHelper.*;

import java.net.URLDecoder;
import java.util.Comparator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.jcr.Item;
import javax.jcr.Node;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.http.Cookie;



import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.servlets.post.Modification;
import org.apache.sling.servlets.post.SlingPostProcessor;

import com.att.ecom.cq.bundle.projecttracking.ProjectTrackingHelper;
import com.att.ecom.cq.bundle.projecttracking.ProjectTagConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * SlingPostProcessor component which sets the project id property if applicable.
 */
@Component
@Service
public class ProjectTrackingSlingPostProcessor implements SlingPostProcessor {

    /**
     * The project tracking helper service.
     */
    @Reference
    private ProjectTrackingHelper mProjectTrackingHelper;
    
    @Reference
    private ProjectTagConfig mProjectTagConfig;
    


    private static final Logger log = LoggerFactory.getLogger(ProjectTrackingSlingPostProcessor.class);

    /**
     * Post process the POST request by setting the project id property on any modified, created, copied, or moved
     * nodes.
     * 
     * @param pRequest
     *            the request
     * @param pChanges
     *            the list of changes
     * @throws Exception
     *             if something goes wrong
     */
    @Override
    public void process(final SlingHttpServletRequest pRequest, final List<Modification> pChanges) throws Exception {
        final Session session = pRequest.getResourceResolver().adaptTo(Session.class);
        final Cookie cookie = pRequest.getCookie(COOKIE_NAME);
        if (cookie != null) {
            final String currentProject = URLDecoder
                    .decode(cookie.getValue(), ProjectTrackingHelperImpl.ENCODING_UTF_8);

            SortedSet<Node> nodesToTagWithProject = new TreeSet<Node>(new Comparator<Node>() {

                @Override
                public int compare(Node o1, Node o2) {
                    try {
                        return o1.getPath().compareTo(o2.getPath());
                    } catch (RepositoryException e) {
                        return 0;
                    }
                }
            });

            for (final Modification change : pChanges) {
                switch (change.getType()) {
                case MODIFY:
                	if(!change.getSource().startsWith("/tmp")) {
		               	 final Node modnode = getNodeOrContainingNode(change.getSource(), session);		               	 
		               	 if (modnode != null) {
		               		nodesToTagWithProject=getNodesToTagWithProject(nodesToTagWithProject,modnode,session);
		               		setReferencedByModifiedtrue(modnode,change,session);
		                 }
                	 }
	               	 break;

                case CREATE:
                	
                	if(!change.getSource().startsWith("/tmp")) {
	                    final Node node = getNodeOrContainingNode(change.getSource(), session);
	                    if (node != null) {
	                    	nodesToTagWithProject=getNodesToTagWithProject(nodesToTagWithProject,node,session);
	                    	setReferencedByModifiedtrue(node,change,session);	
	                    }
                	}
                    break;

                case DELETE:
                    final Node parentNode = getParent(change.getSource(), session);
                    if (parentNode != null) {
                    	nodesToTagWithProject=getNodesToTagWithProject(nodesToTagWithProject,parentNode,session);
                    }
                    break;

                case MOVE:
                case COPY:
                    final Node destNode = getNodeOrContainingNode(change.getDestination(), session);
                    if (destNode != null) {
                    	nodesToTagWithProject=getNodesToTagWithProject(nodesToTagWithProject,destNode,session);
                    }
                    break;
                }

            }
            for (final Node node : nodesToTagWithProject) {
                this.mProjectTrackingHelper.setCurrentProjectProperty(node, currentProject);
            }
        }

    }

    /**
     * If the path is a Node, return the Node; if it is a Property, return the Node on which the Property is set.
     * 
     * @param pPath the item path
     * @param pSession the JCR session
     * 
     * @return the node
     * 
     * @throws RepositoryException if something goes wrong
     */
    private Node getNodeOrContainingNode(final String pPath, final Session pSession) throws RepositoryException {
    	
        if (pSession.itemExists(pPath)) {
            final Item item = pSession.getItem(pPath);            
            if (item instanceof Node) {
                return (Node) item;
            } else if (item instanceof Property) {
                return ((Property) item).getParent();
            } else {
                return null;
            }
        } else {
            return null;
        }
    }
    
    /**
     * get containing Page of a Node
     */
    private Node getContainingPage(final String pPath, final Session pSession) throws RepositoryException {
    	Item item = pSession.getItem(pPath.substring(0,pPath.lastIndexOf("jcr:content"))+"jcr:content");
		return (Node) item;
    }

    /**
     * Return the parent node of the path provided.
     * 
     * @param pPath the path
     * @param pSession the session
     * 
     * @return the parent node
     * 
     * @throws RepositoryException if something goes wrong
     */
    private Node getParent(final String pPath, final Session pSession) throws RepositoryException {
        final String parentPath = StringUtils.substringBeforeLast(pPath, ProjectTrackingHelperImpl.PATH_DELIM);
        if (pSession.nodeExists(parentPath)) {
            return pSession.getNode(parentPath);
        } else {
            return null;
        }
    }
    
    /**
     * getNodesToTagWithProjectt
     */
    private SortedSet<Node> getNodesToTagWithProject(final SortedSet<Node> nodesToTag, Node cnode, final Session pSession ) throws RepositoryException {
    	String nodepath=cnode.getPath().toString();
    	if(nodepath.matches("^.*/jcr:content.*$")){
    		Item item = pSession.getItem(nodepath.substring(0,nodepath.lastIndexOf("jcr:content"))+"jcr:content");
    		cnode=(Node) item;
    	}
    	nodesToTag.add(cnode);
    	return nodesToTag;
    }
    /**
     * setReferencedByModifiedtrue
     */
    public void setReferencedByModifiedtrue(Node node,Modification change,Session session) throws Exception{
   		    final String nodepath=node.getPath().toString();
   		    if(nodepath.matches("^.*/jcr:content.*$")){
	            Node pageNode =  getContainingPage(change.getSource(),session);
	            if(pageNode.hasProperty("sling:resourceType")){
		                String template =pageNode.getProperty("sling:resourceType").getString();
		                if(mProjectTagConfig.isPageRestype(template)){
		            		if(node.hasProperty("sling:resourceType")){
			            			String resourceType = node.getProperty("sling:resourceType").getString();
			            			if (mProjectTagConfig.isFilterComptype(resourceType)) {
			                			node.setProperty("referencedByModified",true);
			                		} else if(mProjectTagConfig.isFilterRefComptype(resourceType)){
			                			node.getParent().getParent().setProperty("referencedByModified",true);
			                		}
		            		} else{
		            				node.getParent().getParent().setProperty("referencedByModified",true);
		            		}
		            		
		                }
	            }    
   		 	
   		}
    	
    }
    
}
