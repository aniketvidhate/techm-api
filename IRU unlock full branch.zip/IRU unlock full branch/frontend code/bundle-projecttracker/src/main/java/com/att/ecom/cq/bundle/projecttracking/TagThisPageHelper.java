/*
 *  Miscellanous helper methods for Tag This Page.
 * @author Shovon Zaman (sz1004)
 * @created on March 02 2013
 */


package com.att.ecom.cq.bundle.projecttracking;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.nodetype.NodeType;
import javax.jcr.Value;
import javax.jcr.RepositoryException;
import javax.jcr.util.TraversingItemVisitor;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.att.ecom.cq.bundle.projecttracking.ProjectTrackingHelper;

@Component(metatype = true, immediate = true)
@Service(value=TagThisPageHelper.class)



public class TagThisPageHelper 
{
	
	private Logger mLogger = LoggerFactory.getLogger(TagThisPageHelper.class);
    @Reference
	private ProjectTagConfig mProjectTagConfig;
    
    @Reference
    private ProjectTrackingHelper projectTrackingHelper;
    
    /*
	public void addCurrentProjectToAllNode(Node topNode,String currentProject) {
		try {
		    projectTrackingHelper.setCurrentProjectProperty(topNode, currentProject);
			if (topNode.hasNodes()) {
				NodeIterator childNodes = topNode.getNodes();
				while (childNodes.hasNext()) 
				{
					Node childNode = childNodes.nextNode();
					addCurrentProjectToAllNode(childNode,currentProject);
				}
			}   
		} 
		catch (RepositoryException e) {
			e.printStackTrace();
		}
	}
	*/
	/*
	 * 
	 */
	public void addCurrentProjectTojcrContentNode(Node topNode,String currentProject) {
		try {
			projectTrackingHelper.setCurrentProjectProperty(topNode, currentProject);
			if(topNode.hasProperty("sling:resourceType")){
				String template =topNode.getProperty("sling:resourceType").getString();
				if(this.mProjectTagConfig.isPageRestype(template)){
					if (topNode.hasNodes()) {
						topNode.accept( new TraversingItemVisitor.Default() {
							@Override
							protected void entering(Node pNode, int pLevel) {
							   try {		
									if(pLevel > 1){
										if(pNode.hasProperty("sling:resourceType")){
											String resourceType = pNode.getProperty("sling:resourceType").getString();
											if (mProjectTagConfig.isFilterComptype(resourceType)) {
												pNode.setProperty("referencedByModified",true);
											} else if(mProjectTagConfig.isFilterRefComptype(resourceType)){
												pNode.getParent().getParent().setProperty("referencedByModified",true);
											}
										} else{
											pNode.getParent().getParent().setProperty("referencedByModified",true);
										}
									}
							   }		
							   catch (RepositoryException e) {
									e.printStackTrace();
							   }	
							}
						});
					}   
				}
			}	
		} 
		catch (RepositoryException e) {
			e.printStackTrace();
		}
	}
}
