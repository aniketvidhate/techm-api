package com.att.ecom.cq.bundle.projecttracking.impl;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;

import com.att.ecom.cq.bundle.projecttracking.CommandServletFilterConfig;

@Component
@Service
public class WCMCommandServletFilterConfig implements CommandServletFilterConfig {
	
	private String[] wcmCommands = new String[]{"createPage=createPageATT","copyPage=copyPageATT"};

	public String[] getCommands(){
		return wcmCommands;
	}
	
	public void setCommands(String[] wcmCommands){
		this.wcmCommands = wcmCommands;
	}
}
