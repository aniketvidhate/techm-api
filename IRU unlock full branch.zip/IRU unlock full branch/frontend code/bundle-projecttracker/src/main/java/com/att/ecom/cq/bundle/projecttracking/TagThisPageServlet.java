package com.att.ecom.cq.bundle.projecttracking;

import java.io.IOException;
import javax.jcr.Node;
import javax.servlet.ServletException; 
import javax.jcr.RepositoryException;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.commons.json.JSONException;
import javax.jcr.Session;
import org.apache.sling.api.resource.ResourceResolver;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.att.ecom.cq.bundle.projecttracking.ProjectTrackingHelper;


/*
 * Servlet for "Tag This Page" SideKick .
 * @author Shovon Zaman (sz1004)
 * @created on March 02 2013
 * Notes:
 */
 

@SlingServlet(methods = { "GET", "POST" },paths = {"/system/att/cms/tools/tagthispageservlet"})

public class TagThisPageServlet extends SlingAllMethodsServlet{
	@Reference
	private TagThisPageHelper mTagThisPageHelper;
	@Reference
	private JCRInfoHelper mJCRInfoHelper;
	
    @Reference
    private ProjectTrackingHelper projectTrackingHelper;
    
    private static final Logger log = LoggerFactory.getLogger(TagThisPageServlet.class);
	
	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException,	IOException {
		String pagepath = request.getParameter("pagepath");
		String projectid = request.getParameter("projectid");
		String overwrite = request.getParameter("overwrite");
		String projectinfo = request.getParameter("projectinfo");
	    String status="";
		overwrite = overwrite!=null?overwrite.toLowerCase():"false";
		projectinfo = projectinfo!=null?projectinfo.toLowerCase():"false";
		String output = "";
		List<JSONObject> objjsonpathlist = null;  
		List<JSONObject> objjsonpathprojectlist = new ArrayList<JSONObject>();  
		ResourceResolver resourceResolver = null;
		Node topNode =null;
		Session session =null;
		int i=0;			
		try {
			pagepath +="/jcr:content";
			resourceResolver = request.getResourceResolver();	
			session = resourceResolver.adaptTo(Session.class);
			topNode =(Node) session.getItem(pagepath);
			//Resource currentResource = pRequest.getResource();
	
			if(!(overwrite.equals("true"))){
				objjsonpathlist = this.mJCRInfoHelper.getJCRContentpathPropertyinfo(resourceResolver,pagepath,topNode,projectTrackingHelper.PROPERTY_NAME);
				if(objjsonpathlist.size() > 0){
					for ( i=0;i<objjsonpathlist.size();i++ ) {
						JSONObject obj=objjsonpathlist.get(i);
						if(!(obj.getString(projectTrackingHelper.PROPERTY_NAME).equals(projectid))){	
							objjsonpathprojectlist.add(obj);
							status="conflict";
						}
					} 
				}
			}	
			if((objjsonpathprojectlist.size() == 0)&&(!projectinfo.equals("true"))){
				this.mTagThisPageHelper.addCurrentProjectTojcrContentNode(topNode,projectid);
				if (session.hasPendingChanges()) {
						session.save();
						status="success";
				}
				else{
						status="nochanges";
				}
			}	
		}
		catch (Exception e){
			status="error";
			e.printStackTrace();
			log.error("Error during set CurrentProject.", e);
		}
		try {
			response.setContentType("application/json");
			response.setStatus(response.SC_OK);	
			JSONObject jsonresponseobject=new JSONObject();
			if(status.equals("success")){
				jsonresponseobject.put("status","success");
			}
			else if(projectinfo.equals("true")){
			    jsonresponseobject.put("data",objjsonpathprojectlist);//existing Project Tag
            }
			else{
				jsonresponseobject.put("status",status);
				jsonresponseobject.put("data",objjsonpathprojectlist);//existing Project Tag
			}
			PrintWriter out = response.getWriter();
			out.print(jsonresponseobject);
			out.flush();
		} 
		catch (JSONException e) {
			 e.printStackTrace();
		}
	}
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}