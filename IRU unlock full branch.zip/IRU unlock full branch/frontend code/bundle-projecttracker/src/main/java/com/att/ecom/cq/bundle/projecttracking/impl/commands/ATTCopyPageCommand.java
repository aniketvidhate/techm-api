package com.att.ecom.cq.bundle.projecttracking.impl.commands;

import javax.jcr.Node;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HtmlResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.projecttracking.ProjectTrackingHelper;
import com.day.cq.commons.servlets.HtmlStatusResponseHelper;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.commands.WCMCommand;
import com.day.cq.wcm.api.commands.WCMCommandContext;
import javax.jcr.Session;
import java.util.Iterator;


/*
 * CopyATTCopyPageCommand.java
 * @author Shovon Zaman (sz1004)
 * @created on Feb 24 2014
 * Functionalities: "Project tag" need to be added 
 * for the copied files in the CQ siteadmin
 */
 


@Component
@Service
public class ATTCopyPageCommand implements WCMCommand {
	
	private static final String NT_PAGE_CONTENT = "cq:PageContent";

	private static final Logger log = LoggerFactory.getLogger(ATTCopyPageCommand.class);
	
	/**
     * The project tracking helper service.
     */
    @Reference
    private ProjectTrackingHelper projectTrackingHelper;
	
	@Override
	public String getCommandName() {
		return "copyPageATT";
	}

	@Override
	public HtmlResponse performCommand(WCMCommandContext context, SlingHttpServletRequest request, 
			SlingHttpServletResponse response, PageManager pageManager) {
		
		try{
			String beforeName = request.getParameter("before");
			String destParentPath = request.getParameter("destParentPath");
			String srcPath = request.getParameter("srcPath");
			boolean boolshallow = false;
			boolean boolresolveConflict = true;
			ResourceResolver resourceResolver = request.getResourceResolver();
			Resource srcResource = resourceResolver.getResource(srcPath);
			String destName = request.getParameter("destName")!=null?request.getParameter("destName"):srcResource.getName();
			String destination = destParentPath + "/" + destName;
			Resource copyResource=pageManager.copy(srcResource,destination,beforeName,boolshallow,boolresolveConflict );
			Node copyNode=copyResource.adaptTo(Node.class);
			final String primaryNodeType = copyNode.getPrimaryNodeType().getName();
			if (NT_PAGE_CONTENT.equals(primaryNodeType))
			{
				projectTrackingHelper.setCurrentProjectProperty(copyNode, request);
			}
			Session session = request.getResourceResolver().adaptTo(javax.jcr.Session.class);
			if (session.hasPendingChanges()) 
			{
				session.save();
			}
			setCurrentProjectintoChildPages(copyResource,request,session);
			return HtmlStatusResponseHelper.createStatusResponse(true, copyResource.getPath(), copyResource.getPath());
		}
		catch (Exception e){
			e.printStackTrace();
			log.error("Error during copy.", e);
		}
		return HtmlStatusResponseHelper.createStatusResponse(false, "Error during copy.");
	}
	
	public void setCurrentProjectintoChildPages(Resource pResource,SlingHttpServletRequest request, Session session) {	
		try{
			for (Iterator<Resource> childResources = pResource.listChildren(); childResources.hasNext();) {             
				  Resource chResource = childResources.next();
				  Node chNode=chResource.adaptTo(Node.class);
				  final String primaryNodeType = chNode.getPrimaryNodeType().getName();
				  if (NT_PAGE_CONTENT.equals(primaryNodeType))
				  {
					  projectTrackingHelper.setCurrentProjectProperty(chNode, request);
				  }	  
				  if (session.hasPendingChanges()) 
				  {
						session.save();
				  }	
				  setCurrentProjectintoChildPages(chResource,request,session);
			}
		}
		catch (Exception e){
			e.printStackTrace();
			log.error("Error during set CurrentProject into Child Pages.", e);
		}
	}	
}