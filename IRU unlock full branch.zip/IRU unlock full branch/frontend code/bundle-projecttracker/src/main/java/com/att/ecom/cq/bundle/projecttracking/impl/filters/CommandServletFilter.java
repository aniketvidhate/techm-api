package com.att.ecom.cq.bundle.projecttracking.impl.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.sling.SlingFilter;
import org.apache.felix.scr.annotations.sling.SlingFilterScope;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.projecttracking.CommandServletFilterConfig;

@SlingFilter(scope = SlingFilterScope.REQUEST, order = 0)
public class CommandServletFilter implements Filter {

	private static final Logger log = LoggerFactory.getLogger(CommandServletFilter.class);
	
	@Reference
	private CommandServletFilterConfig filterConfig;
	
	@Override
	public void destroy() {
		// Do nothing.
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		String[] configCommands = filterConfig.getCommands();
		String commandId = request.getParameter("cmd");
		
		if (commandId != null){
			for (String configCommand : configCommands){
				if (commandId.equals(configCommand.split("=")[0])){
					String newCommand = configCommand.split("=")[1];
					log.info("Intercepted '" + commandId + "' command.  Converting to '" + newCommand + "'.");
					request = new FilteredCommandHttpRequest((HttpServletRequest) request, newCommand);
				}
			}
		}
		
		chain.doFilter(request,  response);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// Do nothing.
	}
	
	private class FilteredCommandHttpRequest extends HttpServletRequestWrapper{
		
		private static final String PARAM = "cmd";
		private String newCommand;
		
		public FilteredCommandHttpRequest(HttpServletRequest request, String newCommand){
			super(request);
			this.newCommand = newCommand;
		}
		
		@Override
		public String getParameter(String name){
			if (name.equals(PARAM)){
				return newCommand;
			}
			
			return super.getParameter(name);
		}
	}
}
