package com.att.ecom.cq.bundle.projecttracking.impl;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;  
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.nodetype.NodeType;
import javax.servlet.http.Cookie;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.projecttracking.ProjectTrackingHelper;
import com.att.ecom.cq.bundle.projecttracking.ProjectTagConfig;
import com.day.cq.commons.jcr.JcrConstants;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;
import com.day.jcr.vault.fs.api.PathFilterSet;
import com.day.jcr.vault.fs.api.ProgressTrackerListener;
import com.day.jcr.vault.fs.config.DefaultWorkspaceFilter;
import com.day.jcr.vault.packaging.JcrPackage;
import com.day.jcr.vault.packaging.JcrPackageManager;
import com.day.jcr.vault.packaging.PackageId;
import com.day.jcr.vault.packaging.PackageManager;
import com.day.jcr.vault.packaging.Packaging;
import com.day.jcr.vault.packaging.PackagingService;

/**
 * Implementation of the ProjectTrackingHelper service interface.  This implementation handles all
 * requests made via the SlingPostServlet.
 */
@Component(metatype = true, immediate = true)
@Service
public class ProjectTrackingHelperImpl implements ProjectTrackingHelper {

    /**
     * ProgressTrackerListener which captures errors and logs paths.
     */
    private class InternalProgressTrackerListener implements ProgressTrackerListener {

        /**
         * A captured exception
         */
        private Exception mException;

        /**
         * Capture a error encountered during the package build process.
         * 
         * @param pMode
         *            the message mode
         * @param pPath
         *            the path
         * @param pException
         *            the exception
         */
        @Override
        public void onError(final Mode pMode, final String pPath, final Exception pException) {
            this.mException = pException;
        }

        /**
         * Log a message from the package manager.
         * 
         * @param pMode
         *            the message mode
         * @param pAction
         *            the action
         * @param pPath
         *            path on which the action was performed
         */
        @Override
        public void onMessage(final Mode pMode, final String pAction, final String pPath) {
            if (pMode == Mode.PATHS) {
                ProjectTrackingHelperImpl.this.mLogger.info("{} {}", new String[] { pAction, pPath });
            }

        }

    }

    /**
     * The component path of the project component.
     */
    private static final String CMP_PROJECT = "/apps/att/utilities/components/projectlist/project";

    /**
     * The name of UTF-8 encoding.
     */
    static final String ENCODING_UTF_8 = "UTF-8";

    /**
     * The error message to log when the property can't be set.
     */
    private static final String ERROR_CANT_SET_PROPERTY = "Node Type of {} ({}) does not allow the {} property to be set.";

    /**
     * The error message to log when the cookie can't be decoded.
     */
    private static final String ERROR_UNABLE_TO_DECODE = "Unable to decode current project cookie using UTF-8";

    /**
     * Error message to log when the path of a search hit can't be retrieved.
     */
    private static final String ERROR_UNABLE_TO_GET_PATH = "Unable to get path for search hit";

    /**
     * The key for the property name in a QueryBuilder map.
     */
    private static final String KEY_PROPERTY = "property";

    /**
     * The key for the property value in a QueryBuilder map.
     */
    private static final String KEY_PROPERTY_VALUE = "property.value";

    /**
     * The node name for the list node.
     */
    private static final String NN_LIST = "list";

    /**
     * The node name for the project list node.
     */
    private static final String NN_PROJECTLIST = "projectlist";

    /**
     * The node type of a CQ Page
     */
    private static final String NT_CQ_PAGE = "cq:Page";

    /**
     * The node type for CQ Page Content nodes
     */
    private static final String NT_CQ_PAGE_CONTENT = "cq:PageContent";

    /**
     * The default design path.
     */
    private static final String PATH_DEFAULT_DESIGN = "/etc/designs/default/jcr:content";

    /**
     * The path delimiter character;
     */
    static final String PATH_DELIM = "/";

    /**
     * The design path for project list pages.
     */
    private static final String PATH_DESIGN_PROJECT_LIST = PATH_DEFAULT_DESIGN + PATH_DELIM + NN_PROJECTLIST;

    /**
     * The design path for the list paragraph on project list pages
     */
    private static final String PATH_DESIGN_PROJECT_LIST_LIST = PATH_DESIGN_PROJECT_LIST + PATH_DELIM + NN_LIST;

    /**
     * The path to /etc
     */
    private static final String PATH_ETC = "/etc";

    /**
     * The path to the project list.
     */
    private static final String PATH_PROJECT_LIST = "/etc/projectlist";

    /**
     * The path of temporary nodes.
     */
    private static final String PATH_TMP = "/tmp";

    /**
     * The components property name
     */
    private static final String PN_COMPONENTS = "components";

    /**
     * The property name for the CQ template path
     */
    private static final String PN_CQ_TEMPLATE = "cq:template";

    /**
     * The property name for the Sling resource type
     */
    private static final String PN_RESOURCE_TYPE = "sling:resourceType";

    /**
     * The OSGi configuration property which defines which path prefixes should be excluded when listing the paths
     * tagged with a project id.
     */
    @Property(unbounded = PropertyUnbounded.ARRAY, value = { PATH_TMP, PATH_PROJECT_LIST })
    private static final String PROP_EXCLUDED_PREFIXES = "excludedPrefixes";

    /**
     * The resource type of a parsys
     */
    private static final String RT_PARSYS = "foundation/components/parsys";

    /**
     * The resource type of a project list page
     */
    private static final String RT_PROJECT_LIST = "att/utilities/components/projectlist";

    /**
     * The title of the project list page
     */
    private static final String TITLE_PROJECT_LIST = "Project List";

    /**
     * The template name for the project list page.
     */
    private static final String TMPL_PROJECT_LIST = "/apps/att/utilities/template/projectlist";

    /**
     * Utility method to determine if a path starts with any of the defined prefixes.
     * 
     * @param pStr
     *            the string
     * @param pPrefixes
     *            the prefixes
     * @return true if the string starts with any of the prefixes
     */
    private static boolean startsWithAny(final String pStr, final String[] pPrefixes) {
        for (final String prefix : pPrefixes) {        	
            if (StringUtils.startsWith(pStr, prefix)) {
                return true;
            }
        }
        return false;
    }

    /**
     * The CQ Package Manager.
     */
    @Reference
    private Packaging packaging;
    
//    private  mJcrPackageManager;

    @Reference
    private ProjectTagConfig mProjectTagConfig;
    
    /**
     * The list of prefixes of paths to exclude from a list of tagged nodes.
     */
    private String[] mExcludedPrefixes;

    /**
     * The logger.
     */
    private final Logger mLogger = LoggerFactory.getLogger(ProjectTrackingHelperImpl.class);

    /**
     * The CQ Query Builder utility.
     */
    @Reference
    private QueryBuilder mQueryBuilder;

    /**
     * A reference to the repository; used only during activation.
     */
    @Reference
    private SlingRepository mRepository;

    /**
     * Activate this component by loading configuration and ensuring that the expected node structures exist.
     * 
     * @param pCtx
     *            the OSGi component context
     * @throws RepositoryException
     *             if the project list nodes are unable to be created
     */
    @SuppressWarnings("rawtypes")
    protected void activate(final ComponentContext pCtx) throws RepositoryException {
        final Dictionary props = pCtx.getProperties();
        mExcludedPrefixes = OsgiUtil.toStringArray(props.get(PROP_EXCLUDED_PREFIXES), new String[] { PATH_TMP,
                PATH_PROJECT_LIST });
        ensureProjectListNodeStructure();
    }

    /**
     * {@inheritDoc}
     */
    public String createOrUpdateContentPackage(final ResourceResolver pResourceResolver, final String pProjectId,
            final String pGroupName, final String pPackageName, final String pContentPath ) throws Exception {
        final Session session = pResourceResolver.adaptTo(Session.class);
        final DefaultWorkspaceFilter filter = new DefaultWorkspaceFilter();
        for (final String path : getProjectPaths(session, pProjectId)) {
        	if(pContentPath.trim() != null && !pContentPath.trim().isEmpty()){
        		this.mLogger.debug("selected pContentPath: "+pContentPath);
        		 if(path.startsWith(pContentPath.trim()) ){
        			 this.mLogger.debug("Adding to filter: "+pContentPath);
        			 filter.add(new PathFilterSet(path));
        		 }
        		
        	}else{
        		filter.add(new PathFilterSet(path));
        	}
        }

        //JcrPackage pkg = this.mJcrPackageManager.open(new PackageId(pGroupName, pPackageName,(String) null));
        JcrPackageManager mJcrPackageManager = packaging.getPackageManager(pResourceResolver.adaptTo(Session.class));
        
        JcrPackage pkg = mJcrPackageManager.open(new PackageId(pGroupName, pPackageName,(String) null));
        if (pkg == null) {
            pkg = mJcrPackageManager.create(pGroupName, pPackageName);
        }
        pkg.getDefinition().setFilter(filter, true);

        final JcrPackageManager packMgr = PackagingService.getPackageManager(session);
        final InternalProgressTrackerListener listener = new InternalProgressTrackerListener();

        packMgr.assemble(pkg, listener);

        if (listener.mException != null) {
            throw listener.mException;
        }

        return pkg.getDefNode().getParent().getParent().getPath();
    }

    /**
     * Ensure that both the /etc/projectlist node and the design setting for this node exist.
     * 
     * @throws RepositoryException
     *             if the node structure are not able to be created
     */
    private void ensureProjectListNodeStructure() throws RepositoryException {
        final Session session = this.mRepository.loginAdministrative(null);
        try {
            if (!session.nodeExists(PATH_PROJECT_LIST)) {
                final Node projectListPage = session.getNode(PATH_ETC).addNode(NN_PROJECTLIST, NT_CQ_PAGE);
                final Node projectListPageContent = projectListPage.addNode(JcrConstants.JCR_CONTENT,
                        NT_CQ_PAGE_CONTENT);
                projectListPageContent.setProperty(JcrConstants.JCR_TITLE, TITLE_PROJECT_LIST);
                projectListPageContent.setProperty(PN_RESOURCE_TYPE, RT_PROJECT_LIST);
                projectListPageContent.setProperty(PN_CQ_TEMPLATE, TMPL_PROJECT_LIST);
            }
            if (!session.nodeExists(PATH_DESIGN_PROJECT_LIST_LIST)) {
                final Node designNode;
                if (!session.nodeExists(PATH_DESIGN_PROJECT_LIST)) {
                    designNode = session.getNode(PATH_DEFAULT_DESIGN).addNode(NN_PROJECTLIST,
                            JcrConstants.NT_UNSTRUCTURED);
                } else {
                    designNode = session.getNode(PATH_DESIGN_PROJECT_LIST);
                }
                final Node listDesignNode = designNode.addNode(NN_LIST, JcrConstants.NT_UNSTRUCTURED);
                listDesignNode.setProperty(PN_RESOURCE_TYPE, RT_PARSYS);
                listDesignNode.setProperty(PN_COMPONENTS, CMP_PROJECT);
            }
            if (session.hasPendingChanges()) {
                session.save();
            }
        } finally {
            session.logout();
        }
    }

    /**
     * {@inheritDoc}
     */
    public List<String> getProjectPaths(final Session pSession, final String pProjectId) {
        final List<String> list = new ArrayList<String>();
        
        final Map<String, String> pagemap = new HashMap<String, String>();
        pagemap.put("path","/content/");
        pagemap.put(KEY_PROPERTY, PROPERTY_NAME);
        pagemap.put(KEY_PROPERTY_VALUE, pProjectId);       
     
        final Query pageQuery = this.mQueryBuilder.createQuery(PredicateGroup.create(pagemap), pSession);             
        pageQuery.setHitsPerPage(0);		
		//pageQuery.setHitsPerPage(5000);		
		//pageQuery.setHitsPerPage(5000);		
        final SearchResult pageResult = pageQuery.getResult();
      
        for (final Hit hit : pageResult.getHits()) {
            try {
                final String path = hit.getPath();                
               
                if (!startsWithAny(path, this.mExcludedPrefixes)) {
                	list.add(path);	              
                }
            } catch (RepositoryException e) {
                this.mLogger.error(ERROR_UNABLE_TO_GET_PATH, e);
            }
        }
        

        final Map<String, String> translatormap = new HashMap<String, String>();       
        translatormap.put("path","/etc/");
        translatormap.put(KEY_PROPERTY, PROPERTY_NAME);
        translatormap.put(KEY_PROPERTY_VALUE, pProjectId);
        
        final Query translatorQuery = this.mQueryBuilder.createQuery(PredicateGroup.create(translatormap), pSession);
        translatorQuery.setHitsPerPage(0);
        final SearchResult translatorResult = translatorQuery.getResult();
      
        for (final Hit hit : translatorResult.getHits()) {
            try {
                final String path = hit.getPath();                
               
                if (!startsWithAny(path, this.mExcludedPrefixes)) {
                    list.add(path);
                }
            } catch (RepositoryException e) {
                this.mLogger.error(ERROR_UNABLE_TO_GET_PATH, e);
            }
        }
        this.mLogger.debug("Total tag package size is:"+list.size());
        return list;
    }
	
	
	/**
     * {@inheritDoc}
     */
    public List<String> getResourceBundlePaths(final Session pSession, final String pProjectId) {
    	
        final List<String> list = new ArrayList<String>();
        this.mLogger.debug("getResourceBundlePaths is called");
        final Map<String, String> translatormap = new HashMap<String, String>();       
        translatormap.put("path","/etc/");
        translatormap.put(KEY_PROPERTY, PROPERTY_NAME);
        translatormap.put(KEY_PROPERTY_VALUE, pProjectId);
        
        final Query translatorQuery = this.mQueryBuilder.createQuery(PredicateGroup.create(translatormap), pSession);
        translatorQuery.setHitsPerPage(0);
        final SearchResult translatorResult = translatorQuery.getResult();
        
        this.mLogger.debug("translatorResult size is:"+translatorResult.getHits().size());
        
        for (final Hit hit : translatorResult.getHits()) {
            try {
                final String path = hit.getPath();                
               
                if (!startsWithAny(path, this.mExcludedPrefixes)) {
                    list.add(path);
                }
            } catch (RepositoryException e) {
                this.mLogger.error(ERROR_UNABLE_TO_GET_PATH, e);
            }
        }      

		final Map<String, String> taggingmap = new HashMap<String, String>();       
        taggingmap.put("path","/etc/tags/");
        taggingmap.put(KEY_PROPERTY, PROPERTY_NAME);
        taggingmap.put(KEY_PROPERTY_VALUE, pProjectId);
        
        final Query taggingQuery = this.mQueryBuilder.createQuery(PredicateGroup.create(taggingmap), pSession);
        taggingQuery.setHitsPerPage(0);
        final SearchResult taggingResult = taggingQuery.getResult();
      
        for (final Hit hit : taggingResult.getHits()) {
            try {
                final String path = hit.getPath();                
               
                if (!startsWithAny(path, this.mExcludedPrefixes)) {
                    list.add(path);
                }
            } catch (RepositoryException e) {
                this.mLogger.error(ERROR_UNABLE_TO_GET_PATH, e);
            }
        }        
		
		this.mLogger.debug("Total TransTag package size is:"+list.size());
        return list;
    }


    /**
     * Determine if a node has the project taggable mixin.
     * 
     * @param pNode
     *            the node to check
     * @return true if the node has the mixin
     * 
     * @throws RepositoryException
     *             if the test is unable to be done
     */
    private boolean hasMixin(final Node pNode) throws RepositoryException {
        final NodeType[] mixins = pNode.getMixinNodeTypes();
        if (mixins != null) {
            for (final NodeType mixin : mixins) {
                if (mixin.getName().equals(MIXIN_NAME)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Determine if a node can be  tag or not
     * 
     * @param pNode
     *            the node to check
     * @return true if the node can be  tag
     * 
     * @throws RepositoryException
     *             if the test is unable to be done
     */
    public boolean isNodetaggable(final Node pNode) throws RepositoryException {
    	String nodepath=pNode.getPath().toString();
        Boolean booladdtag=false;
        Boolean booljcrcontnode=false;
        if(nodepath.matches("^.*/jcr:content.*$")){
            booljcrcontnode=true;
        }
        if(mProjectTagConfig.isnodetaggable(pNode.getPath().toString(),pNode.getPrimaryNodeType().getName())){
            booladdtag=true;
        }
        else if( (booljcrcontnode)&&(mProjectTagConfig.isnodetaggable(pNode.getParent().getPath().toString(),pNode.getParent().getPrimaryNodeType().getName()))){
            booladdtag=true;       
        }
        return booladdtag;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setCurrentProjectProperty(final Node pNode, final SlingHttpServletRequest pRequest)
            throws RepositoryException {
    	
        final Cookie cookie = pRequest.getCookie(COOKIE_NAME);
        if (cookie != null) {
            try {
                final String projectId = URLDecoder.decode(cookie.getValue(), ENCODING_UTF_8);
                setCurrentProjectProperty(pNode, projectId);
                
                //Don't save session here because of possible transient node problem
                //Session session = pRequest.getResourceResolver().adaptTo(javax.jcr.Session.class);
                //session.save();
            } catch (UnsupportedEncodingException e) {
                this.mLogger.error(ERROR_UNABLE_TO_DECODE, e);
            }
        }
        else{
        	this.mLogger.warn("*** Cookie value is empty. ***");
        } 
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setCurrentProjectProperty(final Node pNode, final String pProjectId) throws RepositoryException {
    	Boolean booladdtag=isNodetaggable(pNode);
        if (booladdtag){
                final Value projectIdValue = pNode.getSession().getValueFactory().createValue(pProjectId);
                
                if (pNode.getPrimaryNodeType().canSetProperty(PROPERTY_NAME, projectIdValue) || hasMixin(pNode)) {        	
                    pNode.setProperty(PROPERTY_NAME, projectIdValue);
                } else if (pNode.canAddMixin(MIXIN_NAME)) {        	
                    pNode.addMixin(MIXIN_NAME);
                    pNode.setProperty(PROPERTY_NAME, projectIdValue);
                } else {
                    this.mLogger.warn(ERROR_CANT_SET_PROPERTY, new Object[] { pNode.getPath(),
                            pNode.getPrimaryNodeType().getName(), PROPERTY_NAME });
                }
        }
    }
}
