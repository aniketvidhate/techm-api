package com.att.ecom.cq.bundle.workflows;



import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.Workspace;
import javax.jcr.lock.LockManager;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.PersistableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.LoginException;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.Template;
import org.apache.sling.api.resource.NonExistingResource;
import org.apache.sling.api.resource.PersistableValueMap;


import com.day.cq.wcm.commons.ReferenceSearch;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Route;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import com.day.cq.workflow.model.WorkflowNode;
import com.day.cq.workflow.model.WorkflowTransition;
import com.att.ecom.cq.bundle.workflows.internal.CaheInvalidatorFilePath;
import com.att.ecom.cq.bundle.workflows.internal.AkamaiCacheInvalidationConfig;

/**
 * This java writes a text file at the end of workflow after publishing to Production which would be consumed by
 * Akami cache invalidation utility from TAPS team to invalidate the targetted pages.
 */
@Component
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "Standalone Workflow Process"),
        @Property(name = Constants.SERVICE_VENDOR, value = "CMS - ATT"),
        @Property(name = "process.label", value = "Standalone Workflow Process")})

public class StandaloneWorkflowProcess implements WorkflowProcess{
	@Reference
	private ResourceResolverFactory resourceResolverFactory; 
	
	@Reference
    private AkamaiCacheInvalidationConfig akamaiCacheInvalidationConfig;
	
	/** Logger  */
	private static final Logger log = LoggerFactory.getLogger(StandaloneWorkflowProcess.class);
	
	private static final String ES = "es";	
	private static final String EN = "en";
	public static final String RTI_CUSTOMER_SKU_PAGE_PARENT_PATH = "/etc/att/rti/customerskus/";
	
	private static final String PARENT_PATH = "/etc/att";
	private static final String WF_FOLDER = "/content/WorkflowPackages/";
	//private static final String NODE_NAME = "cache-invalidation";
	private static final String PROPERTY = "futureAkamaiCacheInvalidation";
	public static final String DATE_FORMAT = "EEEdd-MMM-yyyy'T'HH:mm:ssZ";
	//public static final String SERVER_PATH = "/home/atgview/cq/workflow";
	public static  String SERVER_PATH = "";
	
	
	private SimpleDateFormat fmt = new SimpleDateFormat(DATE_FORMAT);
	
	private String TOS_PATH_PREFIX_EN = "/content/tos/en/";
	private String TOS_PATH_PREFIX_ES = "/content/tos/es/";
	private String TOS_PATH_FOR_AKAMAI_CACHE_PREFIX_EN = "/shop/legalterms.html?toskey=";
	private String TOS_PATH_FOR_AKAMAI_CACHE_PREFIX_ES = "/shop/es/legalterms.html?toskey=";

	private String MARQUEE_TEMPLATE = "/apps/att/marketing/admanager/templates/marquee";
	private String PANEL_TEMPLATE = "/apps/att/marketing/admanager/templates/panel";
	
	
	private Boolean IS_DEACTIVATE_WF = false;
	
	private String[] validateArgs(String value) {
		String[] out = new String[2];
		
		if(value == null) {
			log.info("No arguments are defined in Workflow model for Akamai Cache Invalidation Step. Argument received: " + value);
		}else {
			String[] tmp = value.split(",");
			if(tmp.length == 2) {
				out[0] = tmp[0].trim();
				out[1] = tmp[1].trim();
			}
			else {
				log.info("No. of required argument mismatched. Arguments required two. Argument received: " + value);
			}
		}
		
		return out;
	}
	
	
	@Override
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)throws WorkflowException {				
		if(workItem.getWorkflow().getWorkflowModel().getTitle().toLowerCase().contains("deactivate")){
			IS_DEACTIVATE_WF = true;
		}
		else{
			IS_DEACTIVATE_WF = false;			
		}
		ResourceResolver adminResolver = null;
		String projectFolder = "";
		String payLoadpath = workItem.getWorkflowData().getPayload().toString();		
		if(payLoadpath.contains(WF_FOLDER) && CaheInvalidatorFilePath.IsCreateFolderEnabled()){
			String remainingPath = payLoadpath.substring(WF_FOLDER.length(),payLoadpath.length());
			projectFolder = remainingPath.substring(0, remainingPath.indexOf("/")+1);
			log.info("Project folder is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + projectFolder);
		}
		String path = "";
		ArrayList<String> futureAkamai = new ArrayList<String>();
		
		String[] args = validateArgs(metaDataMap.get("PROCESS_ARGS", String.class));
		String cacheNode = args[0];
		String cacheDir = projectFolder+args[1];
		
		// Get the resource type and add the file extension to it.
		// For Pages add .html at the end. 
		// For assets of type DAM, check the meta info and then add the extension.
		
    	try {
			Node jcrContentNode = (Node) workflowSession.getSession().getItem(payLoadpath);
			adminResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			if(workflowSession.getSession().itemExists(payLoadpath+"/jcr:content/vlt:definition")){
			//if(null != (Node) workflowSession.getSession().getItem(payLoadpath+"/jcr:content/vlt:definition")){
					// This is a workflow package;
				Node filterNode = (Node)workflowSession.getSession().getItem(payLoadpath+"/jcr:content/vlt:definition/filter");
				if(filterNode.hasNodes()){
					for (NodeIterator resourceNodeIt = filterNode.getNodes(); resourceNodeIt.hasNext(); ) {
						Node resourceNode = resourceNodeIt.nextNode();
						String resourceNodePath = resourceNode.getProperty("root").getValue().getString().trim();
						if(workflowSession.getSession().itemExists(resourceNodePath)){
							Node jcrReourceContentNode = (Node)workflowSession.getSession().getItem(resourceNodePath);
							if(jcrReourceContentNode.isNodeType("cq:Page")){								
								if(resourceNodePath.contains("/content/campaigns")){
									path += adminResolver.map(resourceNodePath)+"/_jcr_content/par.html\n";
									// The above path looks like being used in the standalone applications, might be econtactus.
                                    // But the wbfc, my sales needs a path ending with _jcr_content.content.html.
                                    // So Adding both paths below here. Also making an assumption here that
                                    // changing a campaign would modify the segmentation.segment.js as well.
                                    path += adminResolver.map("/etc/segmentation.segment.js")+"\n";
                                    path += adminResolver.map(resourceNodePath)+"/_jcr_content.content.html\n";
								}else{								
								
									Node jcrContentcontentNode = (Node) workflowSession.getSession().getItem(resourceNodePath+"/jcr:content");
									
									if(jcrContentcontentNode.hasProperty("onTime")) {
										Calendar cal = jcrContentcontentNode.getProperty("onTime").getDate();
										futureAkamai.add(jcrReourceContentNode.getPath() + "," + fmt.format(cal.getTime()));
									}
									
									if(jcrContentcontentNode.hasProperty("offTime")) {
										Calendar cal = jcrContentcontentNode.getProperty("offTime").getDate();
										futureAkamai.add(jcrReourceContentNode.getPath()+ "," + fmt.format(cal.getTime()));
									}
									
									if(isTOS(resourceNodePath)) {
										String tmpPath = constructTosUrlForAkamaiCacheInvalidation(resourceNodePath);
										if(tmpPath != null) {
											log.debug("Adding TOS path " + tmpPath);
											path += tmpPath +"\n";
										}
									}
									String checkForMarqueeOrPanel = isMarqueeOrPanel(jcrContentcontentNode);
									
									if(checkForMarqueeOrPanel != ""){
										path+=includeReferences(jcrContentcontentNode.getParent(),adminResolver,checkForMarqueeOrPanel);
									}
									
									
									// if the page is of type tabbed template
									if(jcrContentcontentNode.hasProperty("cq:template") && jcrContentcontentNode.getProperty("cq:template").getValue().getString().trim().equals("/apps/att/common/templates/sharedcontent/tabbed")){
										path+=resolveFilterReferencesForAkamai(jcrContentcontentNode,workflowSession,adminResolver);
									}
									
									
									// The resource is of type Page.
									path+=adminResolver.map(resourceNodePath)+".html\n";
									
									// if this page is a campaign page add an additional path jcr_content.content.html along with campaignPath.html
								}																
							}else{
								// The resource is of type DAM Asset.	
								path+=adminResolver.map(resourceNodePath)+"\n";
							}
							
						}else {
							log.info("The resource Path "+ resourceNodePath +" does not exist");
						}
					}
				}
				}else{
					// this is a workflow package or an image.
					if(jcrContentNode.isNodeType("cq:Page")){
						// if this page is a campaign page add an additional path jcr_content.par.html 
						if(payLoadpath.contains("/content/campaigns")){
							path += adminResolver.map(payLoadpath)+"/_jcr_content/par.html\n";
                            // The above path looks like being used in the standalone applications, might be econtactus.
                            // But the wbfc, my sales needs a path ending with _jcr_content.content.html.
                            // So Adding both paths below here. Also making an assumption here that
                            // changing a campaign would modify the segmentation.segment.js as well.
                            path += adminResolver.map("/etc/segmentation.segment.js")+"\n";
                            path += adminResolver.map(payLoadpath)+"/_jcr_content.content.html\n";
							
						}else{
							Node jcrContentcontentNode = (Node) workflowSession.getSession().getItem(payLoadpath+"/jcr:content");
							
							if(jcrContentcontentNode.hasProperty("onTime")) {
								Calendar cal = jcrContentcontentNode.getProperty("onTime").getDate();
								futureAkamai.add(jcrContentNode.getPath() + "," + fmt.format(cal.getTime()));
							}
							
							if(jcrContentcontentNode.hasProperty("offTime")) {
								Calendar cal = jcrContentcontentNode.getProperty("offTime").getDate();
								futureAkamai.add(jcrContentNode.getPath() + "," + fmt.format(cal.getTime()));
							}
							
							if(isTOS(jcrContentNode.getPath())) {
								String tmpPath = constructTosUrlForAkamaiCacheInvalidation(jcrContentNode.getPath());
								if(tmpPath != null) {
									log.debug("Adding TOS path " + tmpPath);
									path += tmpPath + "\n";
								}
							}
							
							// if the page is of type tabbed template
							if(jcrContentcontentNode.hasProperty("cq:template") && jcrContentcontentNode.getProperty("cq:template").getValue().getString().trim().equals("/apps/att/common/templates/sharedcontent/tabbed")){
								path+=resolveFilterReferencesForAkamai(jcrContentcontentNode,workflowSession,adminResolver);
							}						
							path += adminResolver.map(payLoadpath)+".html\n";
							
													
							//if marquee or Panel is put through a workflow inclue the campain references as well.
							String checkForMarqueeOrPanel = isMarqueeOrPanel(jcrContentcontentNode);
							
							if(checkForMarqueeOrPanel != ""){
								path+=includeReferences(jcrContentcontentNode.getParent(),adminResolver,checkForMarqueeOrPanel);
							}							
						}
						
				}else{
					path += adminResolver.map(payLoadpath)+"\n";									
				}
			}
    	}catch (Exception e) {
			log.error(e.getMessage(), e);
			if (adminResolver != null) {
				adminResolver.close();
			}

		}finally{
			if (adminResolver != null) {
				adminResolver.close();
			}
		}
    	
		log.debug("Path Before modify: "+ path);
		
		if(cacheDir != null) {
			String[] allPaths = asArray(path, "\n");
			if(allPaths != null) {
				for(String currPath : allPaths) {
					path += asDelimiatedString(addSelectorsAndExtensions(currPath), "\n");
					log.info("PATH IS >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + path);
				}
			}
			writeCacheFile(cacheDir, payLoadpath.replace("/", "_"), path);
		}
		else {
			log.info("No cache directory name passed as step argument. Skipped writting cache file.");
		}
		
//		if(cacheNode != null) {
//			updateFutureAkamaiCacheNode(cacheNode, futureAkamai);
//		}
//		else {
//			log.info("No cache node name passed as step argument. Skipped writting future akami cache on " + PARENT_PATH);
//		}
	}
	
	private String resolveFilterReferencesForAkamai(Node tabbedNode, WorkflowSession wfSession,ResourceResolver adminResolver){
	    	List<String> listOfPathsToConsider = new ArrayList<String>();
	    	try {
				Node individualNode = tabbedNode.getNode("individual");
				Node groupNode = tabbedNode.getNode("group");
				
				if(null != individualNode){
					for (NodeIterator individualFilterNodeItr = individualNode.getNodes("filter*"); individualFilterNodeItr.hasNext();) {
						Node individualFilterNode = (Node) individualFilterNodeItr.next();
					    if(individualFilterNode.hasProperty("referencedByModified") && individualFilterNode.getProperty("referencedByModified").getValue().getBoolean()&& individualFilterNode.hasProperty("referencedBy")){
					    	Value[] filterReferencedByValues = individualFilterNode.getProperty("referencedBy").getValues();
					    	for (int i = 0; i < filterReferencedByValues.length; i++) {
								listOfPathsToConsider.add(filterReferencedByValues[i].getString().trim());
							}
					    	individualFilterNode.setProperty("referencedByModified", false);
					    	individualFilterNode.save();
					    }
					}
					
				}
				// group filter nodes
				if(null != groupNode){
					for (NodeIterator groupFilterNodeItr = groupNode.getNodes("filtergroup*"); groupFilterNodeItr.hasNext();) {
						Node groupFilterNode = (Node) groupFilterNodeItr.next();
					    if(groupFilterNode.hasProperty("referencedByModified") && groupFilterNode.getProperty("referencedByModified").getValue().getBoolean() && groupFilterNode.hasProperty("referencedBy")){
					    	Value[] filterReferencedByValues = groupFilterNode.getProperty("referencedBy").getValues();
					    	for (int i = 0; i < filterReferencedByValues.length; i++) {
								listOfPathsToConsider.add(filterReferencedByValues[i].getString().trim());
							}
					    	groupFilterNode.setProperty("referencedByModified", false);
					    	groupFilterNode.save();
					    	
					    }
					}					
				}

				
				
				// loop through the list of paths to concider.
			    return calculatePathsForAkamai(listOfPathsToConsider,wfSession,adminResolver);
				
				
				
				
			} catch (PathNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RepositoryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
	    	
	}
	
	private boolean isTOS(String path) {
		if(path != null && (path.startsWith(TOS_PATH_PREFIX_EN) || path.startsWith(TOS_PATH_PREFIX_ES))) {
			return true;
		}
		
		return false;
	}
	
	private String constructTosUrlForAkamaiCacheInvalidation(String path) {
		if(path != null) {
			String tmp = null;
			String url = null;
			
			if(path.startsWith(TOS_PATH_PREFIX_EN)) {
				tmp = path.replace(TOS_PATH_PREFIX_EN, "");
				url = TOS_PATH_FOR_AKAMAI_CACHE_PREFIX_EN;
			}
			else if(path.startsWith(TOS_PATH_PREFIX_ES)) {
				tmp = path.replace(TOS_PATH_PREFIX_ES, "");
				url = TOS_PATH_FOR_AKAMAI_CACHE_PREFIX_ES;
			}
			
			
			if(tmp != null) {
				int endIndex = tmp.indexOf("/");
				if(endIndex != -1) {
					tmp = tmp.substring(0, endIndex);
					return url + tmp;
				}
				else {
					return url + tmp;
				}
			}
		}
		
		return null;
	}
	
	private String calculatePathsForAkamai(List<String> listOfPathsToConcider,WorkflowSession wfSession, ResourceResolver adminResolver){
		String pathsForAkamaiCacheRefresh = "";
		
		for (Iterator pathsItr = listOfPathsToConcider.iterator(); pathsItr.hasNext();) {
			String pathToProcess = (String) pathsItr.next();
			try {
				Node pathToProcessNode = wfSession.getSession().getNode(pathToProcess);
				if(pathToProcessNode.hasProperty("referencedBy")){
					pathsForAkamaiCacheRefresh+=adminResolver.map(pathToProcessNode.getParent().getParent().getParent().getPath())+".html\n";
					List<String> pathsToReConcider = new ArrayList<String>();
					Value[] values = pathToProcessNode.getProperty("referencedBy").getValues();
					for (int i = 0; i < values.length; i++) {
					    pathsToReConcider.add(values[i].getString().trim());	
					}
					
					pathsForAkamaiCacheRefresh+=calculatePathsForAkamai(pathsToReConcider, wfSession,adminResolver);
				}else{
					// treat this as a list page.
					pathsForAkamaiCacheRefresh+=adminResolver.map(pathToProcessNode.getPath())+".html\n";
				}
			} catch (PathNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RepositoryException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		return pathsForAkamaiCacheRefresh;
	}

	private void updateFutureAkamaiCacheNode(String nodeName, List<String> additionalPropertyValue) {
		if(additionalPropertyValue != null && additionalPropertyValue.size() > 0) {
			// Check if desired node exist, if not create one.
			checkOrCreateNode(nodeName);
	
			// Read node property and segregate data need to be written for cache and 
			// data needs to rewritten back.
			ResourceResolver resourceResolver = null;
			Session session = null;
			LockManager lockManager = null;
			try {
				resourceResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
				Resource resource = resourceResolver.resolve(PARENT_PATH + "/" + nodeName + "/jcr:content");
				
				if(resource != null) {
					session = resourceResolver.adaptTo(Session.class);
					Workspace workspace = session.getWorkspace();
					lockManager = workspace.getLockManager();
					
					int retryCount = 0;
					
					while(true) {
						retryCount++;
						if(retryCount > 4)
						{
							log.info("Could not get lock on node "+ PARENT_PATH + "/" + nodeName + " after " + (retryCount -1) + " retry. Will try run task in next job run.");
							break; // Go out of loop.
						}
						else {
							if(lockManager.isLocked(PARENT_PATH + "/" + nodeName)) {
								Thread.sleep(5 * 1000);
							}
							else {
								lockManager.lock(PARENT_PATH + "/" + nodeName, true, true, 15, session.getUserID());
								
								PersistableValueMap properties = resource.adaptTo(PersistableValueMap.class);
	
								if(properties!= null && properties.containsKey(PROPERTY)) {
									String[] oldPropertyValue = properties.get(PROPERTY, String[].class);
									if(oldPropertyValue != null && oldPropertyValue.length > 0) {
										List<String> lstOldValues = Arrays.asList(oldPropertyValue);
										additionalPropertyValue.addAll(lstOldValues);
										String[] newPropertyValue = additionalPropertyValue.toArray(new String[]{});
	
										// Write new property value
										properties.put(PROPERTY, newPropertyValue);
										properties.save();
									}
									else {
										String[] newPropertyValue = additionalPropertyValue.toArray(new String[]{});
										properties.put(PROPERTY, newPropertyValue);
										properties.save();
									}
								}
								else {
									log.info("Property " + PROPERTY + " not found at " + PARENT_PATH + "/" + nodeName);
								}
								
								break; // Go out of loop
							}
						}
						
					}
						
					
				}
				else {
					log.error("Node Path " + PARENT_PATH + "/" + nodeName + " not found.");
				}
				
			} catch (Exception e) {
				log.error("Error while running CacheInvalidationJob.", e);
			} finally {
				if(lockManager != null) {
					try {
						lockManager.unlock(PARENT_PATH + "/" + nodeName);
					} catch (Exception e) {
						log.error("Error while unlocking node " + PARENT_PATH + "/" + nodeName, e);
					}
				}
				if(resourceResolver != null) {
					resourceResolver.close();
				}
			}
		}
	}
	
	private void checkOrCreateNode(String nodeName) {
		ResourceResolver resourceResolver = null;
		Session session = null;
		
		try {
			resourceResolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			if(resourceResolver != null) {
				session = resourceResolver.adaptTo(Session.class);
				
				Resource resource = resourceResolver.getResource(PARENT_PATH);
				if(resource != null) {
					Node parentNode = resource.adaptTo(Node.class);
					if(parentNode.hasNode(nodeName) == false) {
						log.info("Creating node " + PARENT_PATH + "/" + nodeName);
						
						Node childNode = parentNode.addNode(nodeName, "sling:OrderedFolder");
						childNode.addMixin("mix:lockable");
						Node content = childNode.addNode("jcr:content", "nt:unstructured");
						content.setProperty(PROPERTY, new String[]{});
						session.save();
					}
					else {
						// Do nothing
					}
				}
				else {
					log.error("Parent node path " + PARENT_PATH + " not found.");
				}
			}
			else {
				log.error("Could not get resource resolver.");
			}
		} catch (Exception e) {
			log.error("Error while checking/creating node for Akamai Cache. Node: " + PARENT_PATH + "/" + nodeName);
		} finally {
			if(resourceResolver != null) {
				resourceResolver.close();
			}
		}
	}
	
	private void writeCacheFile(String folderName, String fileName, String data) {
				
		SERVER_PATH = CaheInvalidatorFilePath.getakamiCacheInvalidatorFilePath();
		if(SERVER_PATH.contains("{INSTANCE}")){
			SERVER_PATH = SERVER_PATH.replace("{INSTANCE}", System.getProperty("weblogic.Name"));			
		}
		log.info("##################Server_Path####################"+SERVER_PATH);
		String writeToThisFolder = SERVER_PATH+File.separator+ folderName;
		log.info("##################Path####################"+writeToThisFolder);
		writeToFile(writeToThisFolder, fileName, data);
	}
	
	
	
	private String isMarqueeOrPanel(Node marqueeOrPanelNode){
		String isMarqueeOrPanel = "";
		
		try{
			
		
			if(marqueeOrPanelNode.hasProperty("cq:template")){
			    if(marqueeOrPanelNode.getProperty("cq:template").getValue().getString().equals(MARQUEE_TEMPLATE)){
			    	isMarqueeOrPanel = "IS_MARQUEE";
			    }else if (marqueeOrPanelNode.getProperty("cq:template").getValue().getString().equals(PANEL_TEMPLATE)){
			    	isMarqueeOrPanel = "IS_PANEL";
				}
			}		
		}catch(RepositoryException e){
			log.error("EXCEPTION CAUGHT:"+e.getMessage());
		}
		return isMarqueeOrPanel;
		
	}
	
	
	
	private String includeReferences(Node marqueeOrPanelNode,ResourceResolver adminResolver,String isPanelOrMarquee) throws RepositoryException{
		
		String path = "";
		
		if(adminResolver.isLive()){
			try{
				Map<String,ReferenceSearch.Info> referenceMap=null,referencePanelMap = null;
				ReferenceSearch referenceSearch = new ReferenceSearch();
//				referenceSearch.setSearchRoot("/content");
				if("IS_MARQUEE".equals(isPanelOrMarquee)){
					referenceMap = referenceSearch.search(adminResolver, marqueeOrPanelNode.getPath());
					if(null != referenceMap && referenceMap.size() > 0){
						for (Iterator<String> iterator = referenceMap.keySet().iterator(); iterator.hasNext();) {
							String key = iterator.next();
							log.info("references found:"+key);
							ReferenceSearch.Info info = referenceMap.get(key);
							log.info(info.getPage().getPath());
							if(info.getPage().getPath().startsWith("/content") && !info.getPage().getPath().startsWith("/content/WorkflowPackages") && !info.getPage().getPath().equals(marqueeOrPanelNode.getPath())){
								if(info.getPage().getPath().contains("/content/campaigns")){
									log.info("Adding Path:"+adminResolver.map(info.getPage().getPath())+"/_jcr_content/par.html\n");
									path += adminResolver.map(info.getPage().getPath())+"/_jcr_content/par.html\n";
                                    // The above path looks like being used in the standalone applications, might be econtactus.
                                    // But the wbfc, my sales needs a path ending with _jcr_content.content.html.
                                    // So Adding both paths below here. Also making an assumption here that
                                    // changing a campaign would modify the segmentation.segment.js as well.
                                    path += adminResolver.map("/etc/segmentation.segment.js")+"\n";
                                    path += adminResolver.map(info.getPage().getPath())+"/_jcr_content.content.html\n";

								}else{
									log.info("Adding Path:"+adminResolver.map(info.getPage().getPath())+".html\n");
									path+=adminResolver.map(info.getPage().getPath())+".html\n";
								}
							}
						}						
					}
				}else if("IS_PANEL".equals(isPanelOrMarquee)){
					referenceMap = referenceSearch.search(adminResolver, marqueeOrPanelNode.getPath());
					if(null != referenceMap && referenceMap.size() > 0){
						for (Iterator<String> campaignRefItr = referenceMap.keySet().iterator(); campaignRefItr.hasNext();) {
							String key = campaignRefItr.next();
							log.info("references found:"+key);
							ReferenceSearch.Info info = referenceMap.get(key);
							log.info(info.getPage().getPath());
							if(info.getPage().getPath().startsWith("/content") && !info.getPage().getPath().startsWith("/content/WorkflowPackages") && !info.getPage().getPath().equals(marqueeOrPanelNode.getPath())){
								
								if(info.getPage().getPath().contains("/content/campaigns")){
									log.info("Adding Path:"+adminResolver.map(info.getPage().getPath())+"/_jcr_content/par.html\n");
									path += adminResolver.map(info.getPage().getPath())+"/_jcr_content/par.html\n";
                                    // The above path looks like being used in the standalone applications, might be econtactus.
                                    // But the wbfc, my sales needs a path ending with _jcr_content.content.html.
                                    // So Adding both paths below here. Also making an assumption here that
                                    // changing a campaign would modify the segmentation.segment.js as well.
                                    path += adminResolver.map("/etc/segmentation.segment.js")+"\n";
                                    path += adminResolver.map(info.getPage().getPath())+"/_jcr_content.content.html\n";
                                }else{
									log.info("Adding Path:"+adminResolver.map(info.getPage().getPath())+".html\n");
									path+=adminResolver.map(info.getPage().getPath())+".html\n";
								}
								
								referencePanelMap = referenceSearch.search(adminResolver, info.getPage().getPath());
								if(null != referencePanelMap && referencePanelMap.size()>0){
									for (Iterator<String> panelRefItr = referencePanelMap.keySet().iterator(); panelRefItr.hasNext();) {
										String panelKey = panelRefItr.next();
										ReferenceSearch.Info panelInfo = referencePanelMap.get(panelKey);
										if(panelInfo.getPage().getPath().startsWith("/content") && !panelInfo.getPage().getPath().startsWith("/content/WorkflowPackages") && !panelInfo.getPage().getPath().equals(info.getPage().getPath())){
											log.info("Adding Path:"+panelInfo.getPage().getPath());
											if(panelInfo.getPage().getPath().contains("/content/campaigns")){
												log.info("Adding Path:"+adminResolver.map(panelInfo.getPage().getPath())+"/_jcr_content/par.html\n");
												path += adminResolver.map(panelInfo.getPage().getPath())+"/_jcr_content/par.html\n";
                                                path += adminResolver.map(info.getPage().getPath())+"/_jcr_content/par.html\n";
                                                // The above path looks like being used in the standalone applications, might be econtactus.
                                                // But the wbfc, my sales needs a path ending with _jcr_content.content.html.-
                                                // So Adding both paths below here. Also making an assumption here that
                                                // changing a campaign would modify the segmentation.segment.js as well.
                                                path += adminResolver.map("/etc/segmentation.segment.js")+"\n";
                                                path += adminResolver.map(panelInfo.getPage().getPath())+"/_jcr_content.content.html\n";
                                            }else{
												log.info("Adding Path:"+adminResolver.map(panelInfo.getPage().getPath())+".html\n");
												path+=adminResolver.map(panelInfo.getPage().getPath())+".html\n";
											}
										}
									}									
								}
							}
						}
					}
				}			
			}catch(Exception e){
				log.error("Exception Occured:"+e.getMessage());
				e.printStackTrace();
				return "";
			}
		}else{
			log.error("Admin Resolver is either 'Null' or not 'live': Could not calculate the references");
		}
		
		return path;
	}
	
	private void writeToFile(String dirPath, String fileName, String data) {
		try{
		    File dir = new File(dirPath);
		    String filename;
		    if(!dir.exists()){
		    	dir.mkdirs();
		    }
		    
		    log.info("Writing temp file in folder "+dirPath+": ."+fileName+"__"+System.currentTimeMillis()+".tmp");
			
			File tempFile = File.createTempFile("."+fileName+"__"+System.currentTimeMillis()+"", ".tmp", new File(dirPath));
			BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile));
			bw.write(data);			 
			bw.flush();
			bw.close();
			
		    if(IS_DEACTIVATE_WF){
		    	filename=dirPath+"/"+fileName+"__"+System.currentTimeMillis()+"__DELETE";
		    	tempFile.renameTo(new File(dirPath,fileName+"__"+System.currentTimeMillis()+"__DELETE"));
		    }
		    else{
		    	filename=dirPath+"/"+fileName+"__"+System.currentTimeMillis();
		    	tempFile.renameTo(new File(dirPath,fileName+"__"+System.currentTimeMillis()));
		    }
		    log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> File name:"+fileName+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> \n");
			//tempFile.renameTo(new File(dirPath,fileName+"__"+System.currentTimeMillis()));
			changePermissions(); 
		}catch (Exception e) {
			log.error("Error while wirting to file " + fileName ,e);
		}
	}
	private void changePermissions() {
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> SERVER_PATH:"+SERVER_PATH+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> \n");
		if(SERVER_PATH.length() > 0){
			String command = "chmod -R 777 "+SERVER_PATH;
			try{
				Process process = Runtime.getRuntime().exec(command);				
			} // end of try
			catch(Exception e){
				log.error("Error change Permissions " +e);
			} //end of catch
		} //end of if
	} //end of method changePermissions
	public ArrayList<String> addSelectorsAndExtensions(String resolvedPath) {
		ResourceResolver resolver = null;
		ArrayList<String> out = new ArrayList<String>();
		
		try {
			resolver = resourceResolverFactory.getAdministrativeResourceResolver(null);
			Resource resource = resolver.resolve(resolvedPath);
			log.info("Resolved to " + resource.getPath() + "resource from " + resolvedPath);
			if(resource == null || resource instanceof NonExistingResource) {
				log.warn("Invalid resolved path " + resolvedPath);
			}
			else {
				Page pg = resource.adaptTo(Page.class);
				if(pg != null && pg.getTemplate() != null) {
					String tmplt = pg.getTemplate().getPath();
					log.info("Looking up akamai configuration for template " + tmplt);
					ArrayList<String> configForTmplt = akamaiCacheInvalidationConfig.getConfigurationForTemplate(tmplt);
					log.info("Akamai configuration returned template is " + configForTmplt);
					for(String token : configForTmplt) {
						String tmpResolvePath = resolver.map(pg.getPath());
						out.add(tmpResolvePath + token);
						log.info("Adding akamai path " + tmpResolvePath + token);
					}
				}
				else {
					log.info("Path " + resource.getPath() + " is not a page or does not have cq:template property.");
				}
			}
		} catch (LoginException e) {
			log.error("Error while adding selectors and extensions for path. " + resolvedPath ,e);
		}
		finally {
			if(resolver != null) {
				resolver.close();
			}
		}
		
		return out;
	}
	
	private String asDelimiatedString(ArrayList<String> list, String delim) {
		
		StringBuilder bldr = new StringBuilder();
		for(String str: list) {
			bldr.append(str);
			bldr.append(delim);
		}
		
		return bldr.toString();
	}
	
	private String[] asArray(String str, String delim) {
		if(str != null && str.length() != 0) {
			String[] arr = str.split(delim); 
			if(arr == null) {
				return new String[] {};
			}
			else {
				return arr;
			}
		}
		else {
			return new String[] {};
		}
	}
}
