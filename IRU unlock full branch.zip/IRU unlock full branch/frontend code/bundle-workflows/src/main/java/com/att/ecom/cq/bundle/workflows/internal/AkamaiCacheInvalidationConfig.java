package com.att.ecom.cq.bundle.workflows.internal;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashMap;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, metatype = true, label = "Akamai Cache Invalidation", description = "Akamai Cache Invalidation from JIRA bundle.")
@Service(value = com.att.ecom.cq.bundle.workflows.internal.AkamaiCacheInvalidationConfig.class)

public class AkamaiCacheInvalidationConfig {
	
	@SuppressWarnings("rawtypes")
	private static Dictionary props = null;
	
	
	
	@Property(label = "Template Selector Mapping", value = {"/apps/att/common/templates/devicebuyback#.all.json",
			"/apps/att/common/templates/globalsearch/synonyms#.txt",
			"/apps/att/common/templates/globalsearch/autosuggest#.xml",
			"/apps/att/common/templates/globalsearch/relatedqueries#.xml"})

	private static final String TEMPLATES_MAPPING = "templates.mapping";
	
	private HashMap<String,ArrayList<String>> mapTemplateMapping = new HashMap<String, ArrayList<String>>();
	
	protected void activate(ComponentContext ctx) {
		mapTemplateMapping.clear();
		props = ctx.getProperties();
	}
	
	public String[] getTemplateMapping() {
		return OsgiUtil.toStringArray(props.get(TEMPLATES_MAPPING), new String[] {});
	}
	
	
	public ArrayList<String> getConfigurationForTemplate(String queryTemplate) {
		if(mapTemplateMapping.size() == 0) {
			for(String str : getTemplateMapping()) {
				String[] currMap = str.split("#");
				if(currMap.length == 2) {
					if(currMap[0] != null && currMap[0].length() != 0 && currMap[1] != null && currMap[1].length() != 0) {
						ArrayList<String> alExtns = new ArrayList<String>();
						mapTemplateMapping.put(currMap[0], alExtns);
						
						String[] extns = currMap[1].split("\\|");
						for(String extn : extns) {
							alExtns.add(extn);
						}
					}
					else {
						System.out.println("Failed to parse mapping " + str );
					}
				}
				else {
					System.out.println("Failed to parse mapping " + str);
				}
			}
		}
		
		if(mapTemplateMapping.containsKey(queryTemplate)) {
			return mapTemplateMapping.get(queryTemplate);
		}
		else {
			return new ArrayList<String>();
		}
	}
}
