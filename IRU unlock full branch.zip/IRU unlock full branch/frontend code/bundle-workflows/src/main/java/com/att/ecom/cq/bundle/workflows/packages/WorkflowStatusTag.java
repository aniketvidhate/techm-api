package com.att.ecom.cq.bundle.workflows.packages;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.Tag;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.scripting.jsp.util.TagUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.workflow.status.WorkflowStatus;

public class WorkflowStatusTag extends BodyTagSupport {

    private static final String IN_A_WORKFLOW = "In A Workflow";

    private static final String NOT_IN_A_WORKFLOW = "Not In A Workflow";

    private static final String JCR_CONTENT = "/jcr:content";

    private static final long serialVersionUID = 1L;

    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowStatusTag.class);

    private String path = null;

    @Override
    public int doAfterBody() throws JspException {

        try {
            BodyContent bc = getBodyContent();
            JspWriter out = bc.getEnclosingWriter();
            path = bc.getString();
            String status = getPageStatus(path);
            out.println(status);
        } catch (IOException ioExp) {
            LOGGER.warn(ioExp.getMessage(), ioExp);
        }
        return Tag.SKIP_BODY;
    }

    /*
     * This method takes path of page and returns workflow status of the page,
     * if the page is in workflow or not.
     */
    private String getPageStatus(String pagePath) {

        String pageStatus = NOT_IN_A_WORKFLOW;
        SlingHttpServletRequest request = TagUtil.getRequest(this.pageContext);
        if (StringUtils.contains(pagePath, JCR_CONTENT)) {
            pagePath = StringUtils.substringBefore(pagePath, JCR_CONTENT);
        }
        if (StringUtils.isNotEmpty(pagePath)) {
            Resource resource = request.getResourceResolver().getResource(pagePath);
            WorkflowStatus wfState = (WorkflowStatus) resource.adaptTo(WorkflowStatus.class);
            if (wfState.isInRunningWorkflow(true)) {
                pageStatus = IN_A_WORKFLOW;
            }
        }
        return pageStatus;
    }

    public String getPath() {
        return path;
    }

    /**
     * Sets the path
     * 
     * @param path
     *            the path for the page
     */
    public void setPath(String path) {
        if (path != null) {
            this.path = String.valueOf(path);
            LOGGER.debug("Path Set as  ", path);
        }
    }

}
