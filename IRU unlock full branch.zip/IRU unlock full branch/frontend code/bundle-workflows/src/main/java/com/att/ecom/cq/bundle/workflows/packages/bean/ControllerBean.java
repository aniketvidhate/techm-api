package com.att.ecom.cq.bundle.workflows.packages.bean; 

import com.adobe.granite.xss.XSSAPI;
import com.day.cq.commons.inherit.InheritanceValueMap;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.WCMMode;
import com.day.cq.wcm.api.designer.Style;
import com.day.cq.wcm.tags.DefineObjectsTag;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.scripting.SlingScriptHelper;
import org.slf4j.Logger; 
import javax.jcr.Node;
import javax.jcr.Session;
import javax.servlet.jsp.JspContext;
import java.util.*; 

public abstract class ControllerBean { 

    protected static final String TAGS_PARAM_NAME = "tag[]"; 

    private static final String SLING_SCRIPT_HELPER_ATTR = "sling";

    private static final String SLING_REQUEST_ATTR = "slingRequest";

    private static final String PROPERTIES_ATTR = "properties";

    private static final String PAGE_PROPERTIES_ATTR = "pageProperties";

    private static final String LOG_ATTR = "log"; 

    private JspContext jspContext;

    private SlingHttpServletRequest slingRequest;

    private ValueMap properties;

    private InheritanceValueMap pageProperties; 

    private XSSAPI xssAPI;
 

    public final void init(JspContext jspContext) {

        this.jspContext = jspContext;

        this.slingRequest = (SlingHttpServletRequest) jspContext.getAttribute(SLING_REQUEST_ATTR);

        this.properties = (ValueMap) jspContext.getAttribute(PROPERTIES_ATTR);

        this.pageProperties = (InheritanceValueMap) jspContext.getAttribute(PAGE_PROPERTIES_ATTR);

        populate();

    } 

    public abstract void populate(); 

    public abstract String getAttributeName(); 

    protected SlingScriptHelper getSling() {

        return (SlingScriptHelper) jspContext.getAttribute(SLING_SCRIPT_HELPER_ATTR);

    } 

    protected String getParameter(String paramName, String defaultValue) {

        String value = getParameter(paramName);

        if (value == null) {

            value = defaultValue;

        }

        return value;

    } 

    protected String getParameter(String parameterName) { 

        String parameter = slingRequest.getParameter(parameterName);

        if (StringUtils.isNotBlank(parameter)) {

            parameter = getXssFilter().filterHTML(parameter);

        }

        return parameter;

    } 

    protected String[] getParameterValues(String parameterName) {

        String[] parameterValues = slingRequest.getParameterValues(parameterName);

        HashSet<String> paramValuesSet = new HashSet<String>();

        if (parameterValues != null) {

            for (String parameterValue : parameterValues) {

                paramValuesSet.add(getXssFilter().filterHTML(parameterValue));

            }

        } 

        return paramValuesSet.toArray(new String[paramValuesSet.size()]);
    } 

    protected Set<String> getTagIDs() {

        Set<String> tagIDs = new HashSet<String>();

        String[] tagParams = getParameterValues(TAGS_PARAM_NAME);

        if (tagParams != null) {

            for (String tagID : tagParams) {

                tagIDs.add(tagID);

            }

        }

        return tagIDs;
    } 

    protected JspContext getJspContext() {

        return jspContext;

    }

    protected SlingHttpServletRequest getSlingRequest() {

        return slingRequest;
    } 

    protected ValueMap getProperties() {

        return properties;

    } 

    protected InheritanceValueMap getPageProperties() {

        return pageProperties;

    } 

    protected XSSAPI getXssFilter() {

        if (xssAPI == null) {

            xssAPI = getSling().getService(XSSAPI.class).getRequestSpecificAPI(getSlingRequest());

        }

        return xssAPI;

    } 

    protected Session getJcrSession() {

        return getResourceResolver().adaptTo(Session.class);

    } 

    protected ResourceResolver getResourceResolver() {

        return getSlingRequest().getResourceResolver();

    } 

    protected Page getCurrentPage() {

        return (Page) getJspContext().getAttribute(DefineObjectsTag.DEFAULT_CURRENT_PAGE_NAME);

    } 

    protected Style getCurrentStyle() {

        return (Style) getJspContext().getAttribute(DefineObjectsTag.DEFAULT_CURRENT_STYLE_NAME);

    } 

    protected Logger getLogger() {

        return (Logger) getSlingRequest().getAttribute(LOG_ATTR);

    } 

    protected Resource getResource() {

        return getSlingRequest().getResource();

    } 

    protected Node getCurrentNode() {

        Resource resource = getResource(); 

        if (!ResourceUtil.isNonExistingResource(resource)) {

            return resource.adaptTo(Node.class);

        }

        return null;

    } 

    protected String getParameter(int index) {

        String selector = null;

        List<String> selectors = getAllSelectors();

        if (selectors.size() > index) {

            selector = getXssFilter().filterHTML(selectors.get(index));

        }

        return selector;
    } 

    protected List<String> getAllSelectors() {

        return new ArrayList<String>(Arrays.asList(getSlingRequest().getRequestPathInfo().getSelectors()));

    } 

    public boolean isEditMode() {

        return WCMMode.fromRequest(getSlingRequest()) == WCMMode.EDIT;

    }

}
 