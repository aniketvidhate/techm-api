package com.att.ecom.cq.bundle.workflows;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.jcr.Workspace;
import javax.jcr.lock.LockManager;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.PersistableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.osgi.framework.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.day.cq.wcm.commons.ReferenceSearch;
import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.exec.Route;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;
import com.day.cq.workflow.model.WorkflowNode;
import com.day.cq.workflow.model.WorkflowTransition;
import com.att.ecom.cq.bundle.workflows.internal.CaheInvalidatorFilePath;

/**
 * this java code runs a shell script which s given as a first argument in the dialog
 */
@Component
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "Call a script"),
        @Property(name = Constants.SERVICE_VENDOR, value = "CMS - ATT"),
        @Property(name = "process.label", value = "Call a script")})

public class callScriptProcess implements WorkflowProcess{	
	
	/** Logger  */
	private static final Logger log = LoggerFactory.getLogger(StandaloneWorkflowProcess.class);
		
	private ArrayList<String> validateArgs(String value) {
		ArrayList<String> out = new ArrayList<String>();		
		if(value == null) {
			log.info("No arguments are defined in Workflow model for Akamai Cache Invalidation Step. Argument received: " + value);
		}else {
			String[] tmp = value.split(",");
			if(tmp.length != 0) {
				for(int cnt=0;cnt<tmp.length;cnt++){						
					out.add(tmp[cnt]);
				}				
			}
			else {
				log.info("No. of required argument mismatched. Arguments required two. Argument received: " + value);
			}
		}		
		return out;
	}
	
	
	@Override
	public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaDataMap)throws WorkflowException {		
    	try {
    		ArrayList<String> args = validateArgs(metaDataMap.get("PROCESS_ARGS", String.class));
    		String scriptName = "";
    		String scriptArguments = "";
    		if(args.size() != 0){
    			scriptName = args.get(0);
    			if(args.size() > 1){
    				for(int cnt = 1;cnt<args.size();cnt++){
    					scriptArguments += args.get(cnt) + " ";
    				}
    			}
    		}else{
    			log.info("Number of arguments mismatched. At least one argument is required.");
    		}
    		log.info("script: "+ scriptName + " " + scriptArguments);
    		 Process proc = Runtime.getRuntime().exec(scriptName + " " + scriptArguments); 
             BufferedReader read = new BufferedReader(new InputStreamReader(
                     proc.getInputStream()));
             try {
                 proc.waitFor();
             } catch (InterruptedException e) {
            	 log.info(e.getMessage());
             }
             while (read.ready()) {
            	 log.info(read.readLine());
             }
    		
    	}catch (Exception e) {
			log.error(e.getMessage(), e);			
		} 	
		
	}	
	
}
