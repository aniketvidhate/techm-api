/**
 * 
 */
package com.att.ecom.cq.bundle.workflows.packages.bean;

import java.util.ArrayList;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryResult;
import javax.jcr.query.Row;
import javax.jcr.query.RowIterator;

import org.apache.commons.lang.StringUtils;
import org.apache.jackrabbit.commons.query.GQL;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.commons.ReferenceSearch;

/**
 * @author aa949r
 * 
 */
public class WorkflowUtilityBean extends ControllerBean {

    private static final String CQ_PAGE = "cq:Page";

    private static final String CONTENT = "/content";

    public static final String COMPONENT = "Component";

    public static final String TRANSLATOR = "Translator";

    private ResourceResolver resourceResolver;

    private String userName;

    private String jiraId;

    private List<String> pagePathList = new ArrayList<String>();

    private static final String ATTRIBUTE_NAME = "utilityBean";

    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowUtilityBean.class);

    @Override
    public String getAttributeName() {
        return ATTRIBUTE_NAME;
    }

    @Override
    public void populate() {
        LOGGER.warn("entering the populate method - WorkflowUtilityBean");
        resourceResolver = getSlingRequest().getResourceResolver();
        String referenceType = getSlingRequest().getParameter("referenceType");
        String referenceKey = getSlingRequest().getParameter("referenceKey");
        userName = getSlingRequest().getParameter("userName");
        jiraId = getSlingRequest().getParameter("jiraId");
        Query query = null;
        QueryResult result = null;
        NodeIterator nodes = null;
        try {
            if (TRANSLATOR.equals(referenceType)) {
                pagePathList = doTranslatorSearch(referenceKey);
            } else if (COMPONENT.equals(referenceType)) {
                query = doComponentSearch(referenceKey);
                result = query.execute();
                nodes = result.getNodes();
                pagePathList = createPathList(nodes);
            } else {
                pagePathList = doReferenceSearch(referenceKey);

            }
        } catch (RepositoryException e) {
            e.printStackTrace();
        }

    }

    /*
     * This method searches for a given translator label in content repository And returns list of pages contaning the
     * label.
     */
    private List<String> doTranslatorSearch(String referenceKey) throws RepositoryException {
        List<String> pathList = new ArrayList<String>();
        RowIterator rows = GQL.execute(referenceKey, resourceResolver.adaptTo(Session.class));
        while (rows.hasNext()) {
            Row row = rows.nextRow();
            Node node = row.getNode();
            String pagePath = node.getPath();
            if (StringUtils.startsWith(pagePath, CONTENT) && (node.isNodeType(CQ_PAGE))) {
                pathList.add(pagePath);
            }
        }
        return pathList;
    }

    /*
     * This method searches for a given component in content repository And returns list of pages using the component.
     */
    private Query doComponentSearch(String referenceKey) throws RepositoryException {
        String queryString = "";
        referenceKey = referenceKey.replaceAll("/apps", "");
        queryString = "SELECT * FROM [nt:base] AS t WHERE ISDESCENDANTNODE([/content]) AND contains (t.[sling:resourceType],'"
                + referenceKey + "')";
        Query query = resourceResolver.adaptTo(Session.class).getWorkspace().getQueryManager()
                .createQuery(queryString, Query.JCR_SQL2);
        return query;
    }

    /*
     * This method searches for a given shared-content path in content repository And returns list of pages referring to
     * given content.
     */
    private List<String> doReferenceSearch(String referenceKey) throws RepositoryException {

        List<String> pathList = new ArrayList<String>();
        for (ReferenceSearch.Info info : new ReferenceSearch().search(resourceResolver, referenceKey).values()) {
            pathList.add(info.getPage().getPath());
        }
        return pathList;
    }

    /*
     * This method takes a number of nodes and returns a list containing the paths of given nodes.
     */
    private List<String> createPathList(NodeIterator nodes) throws RepositoryException {
        List<String> pathList = new ArrayList<String>();
        while (nodes.hasNext()) {
            try {
                pathList.add(nodes.nextNode().getPath());
            } catch (RepositoryException e) {
                e.printStackTrace();
            }
        }

        return pathList;
    }

    public String getUserName() {
        return userName;
    }

    public List<String> getPagePathList() {
        return pagePathList;
    }

    public String getJiraId() {
        return jiraId;
    }
}
