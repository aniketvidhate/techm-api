package com.att.ecom.cq.bundle.workflows.internal;

import java.io.IOException;
import java.util.Dictionary;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.osgi.OsgiUtil;
import org.osgi.service.component.ComponentContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Cache invalidator file for 
 * available locally.
 */
@Component(immediate = true, metatype = true, label = "Cache Invalidator File Path", description = "Folder path for the Akami cache invalidator files")
@Service(value = com.att.ecom.cq.bundle.workflows.internal.CaheInvalidatorFilePath.class)

public class CaheInvalidatorFilePath {
	
	@SuppressWarnings("rawtypes")
	private static Dictionary props = null;

	// Default values for all properties
	private static final String DEFAULT_CACHE_INVALIDATOR_FILE_PATH  = "/sites/cq/workflow";
	
    /**
     * The default enabled state.
     */
    private static final boolean CREATE_FOLDER_ENABLED = false;
    
    /**
     * OSGi configuration property for enable state.
     */
    @Property(label = "create project folder?", boolValue = CREATE_FOLDER_ENABLED)
    private static final String PROP_ENABLED = "invalidator.createfolder";
	
	@Property(label = "Cahe Invalidator File Path", value = DEFAULT_CACHE_INVALIDATOR_FILE_PATH)
	private static final String CACHE_INVALIDATOR_FILE_PATH = "invalidator.path";
	 
			 
    /**
     * The current enabled state.
     */
    private boolean mEnabled;
    
 
     /**
     * Activate this component.
     * 
     * @param pCtx
     *            the OSGi component context
     */
    protected void activate(final ComponentContext pCtx) {
        props = pCtx.getProperties();       
    }

    public static String getakamiCacheInvalidatorFilePath() {		
		return OsgiUtil.toString(props.get(CACHE_INVALIDATOR_FILE_PATH),
				DEFAULT_CACHE_INVALIDATOR_FILE_PATH);
	}
    
    public static Boolean IsCreateFolderEnabled() {		
    	return OsgiUtil.toBoolean(props.get(PROP_ENABLED), CREATE_FOLDER_ENABLED);		
	}
 
}
