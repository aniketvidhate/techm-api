package com.att.ecom.cq.bundle.workflows.packages;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.att.ecom.cq.bundle.workflows.packages.bean.ControllerBean;
import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class ControllerBeanTag extends SimpleTagSupport {

    private static final Logger LOGGER = LoggerFactory.getLogger(ControllerBeanTag.class);

    private String controllerBeanClass;

    @Override
    public void doTag() throws JspException {
        try {
            JspContext jspContext = getJspContext();
            Class c = Thread.currentThread().getContextClassLoader().loadClass(controllerBeanClass);
            ControllerBean controllerBean = (ControllerBean) c.newInstance();
            controllerBean.init(jspContext);
            jspContext.setAttribute(controllerBean.getAttributeName(), controllerBean);
        } catch (ClassNotFoundException e) {
            LOGGER.error("Could not instantiate class. The class is not found : " + controllerBeanClass, e);
        } catch (IllegalAccessException e) {
            LOGGER.error("Could not instantiate class. Illegal access : " + controllerBeanClass, e);
        } catch (InstantiationException e) {
            LOGGER.error("Could not instantiate class.: " + controllerBeanClass, e);
        }
    }

    public void setControllerBeanClass(String controllerBeanClass) {
        this.controllerBeanClass = controllerBeanClass;
    }

}

