package com.att.ecom.cq.bundle.workflows.packages.factory;

import java.util.Collection;
import java.util.Iterator;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.nodetype.NodeType;

import org.apache.commons.collections.IteratorUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.apache.sling.jcr.resource.JcrResourceUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.workflows.packages.WorkflowPackage;
import com.att.ecom.cq.bundle.workflows.packages.impl.WorkflowPackageImpl;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.wcm.api.NameConstants;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.jcr.vault.packaging.JcrPackage;
import com.day.jcr.vault.packaging.JcrPackageDefinition;

public class WorkflowPackageFactory {

    private static final String SLING_ORDERED_FOLDER = "sling:OrderedFolder";

    private static final String CONTENT_ROOT_WORKFLOW_PACKAGES = "/content/WorkflowPackages/";
    
    private PageManager pageManager;

    private ResourceResolver resourceResolver;    
    

    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowPackageFactory.class);

    public WorkflowPackageFactory(ResourceResolver resourceResolver) {
        this.resourceResolver = resourceResolver;
        this.pageManager = resourceResolver.adaptTo(PageManager.class);
    }

    // TODO: This logic could be a little bit more broken down. For the time being, it's encapsulated fine in the
    // create() function...
    public WorkflowPackage create(Collection<Resource> resources, String path, String name, String title)
            throws Exception {
        LOGGER.debug("entering the create method in factory for creating workflow-package");

        // Build the workflow package (it's actually just a page).
        Node folderNode = getFolderNode(path);
        String pageName = title;
        Page wfPackagePage = pageManager.create(folderNode.getPath(), pageName,
                "/apps/att/att-foundation/templates/collectionpage", title);
        try {
            // Update the content resource.
            Node contentNode = wfPackagePage.getContentResource().adaptTo(Node.class);
            if (contentNode != null) {
                // contentNode.addMixin(JcrPackage.NT_VLT_PACKAGE);
                JcrResourceUtil.setProperty(contentNode, JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY,
                        "att/att-foundation/components/collection/page");
                JcrResourceUtil.setProperty(contentNode, NameConstants.PN_DESIGN_PATH, "/etc/designs/default");
                JcrResourceUtil.setProperty(contentNode, NameConstants.NN_TEMPLATE,
                        "/apps/att/att-foundation/templates/collectionpage");

                Node vltDef = contentNode.addNode(JcrPackage.NN_VLT_DEFINITION);
                vltDef.setPrimaryType(JcrConstants.NT_UNSTRUCTURED);
                Node filter = vltDef.addNode(JcrPackageDefinition.NN_FILTER);
                filter.setProperty(JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY,
                        "att/att-foundation/components/collection/definition/resourcelist");
                WorkflowPackage wfPackage = new WorkflowPackageImpl(wfPackagePage.adaptTo(Resource.class));

                // Add each path as a filter option.
                if (null != resources) {
                    for (Resource res : resources) {
                        wfPackage.addResourceToPackage(res);
                    }
                }
                contentNode.getSession().save();
                return wfPackage;
            } else {
                // Something bad happened. Completely delete the page.
                pageManager.delete(wfPackagePage, true);
            }
        } catch (RepositoryException e) {
            LOGGER.warn("EXCEPTION====" + e.getMessage());
        }

        return null;
    }
    
    /*
     * This method creates the folder for workflow package.
     */
    private Node getFolderNode(String path) throws RepositoryException {
        Node folderNode = null;
        String relNodePath = StringUtils.substringAfter(path, CONTENT_ROOT_WORKFLOW_PACKAGES);
       
        Node rootNode = resourceResolver.getResource(CONTENT_ROOT_WORKFLOW_PACKAGES).adaptTo(Node.class);
        try {
            if (!rootNode.hasNode(relNodePath)) {
                folderNode = rootNode.addNode(relNodePath, SLING_ORDERED_FOLDER);
                Node jcrNode = folderNode.addNode(JcrConstants.JCR_CONTENT, JcrConstants.NT_UNSTRUCTURED);
                JcrResourceUtil.setProperty(jcrNode, JcrConstants.JCR_TITLE, relNodePath);
                rootNode.getSession().save();
            } else {
                folderNode = rootNode.getNode(relNodePath);
            }
        } catch (RepositoryException e) {
            LOGGER.error("Error while searching for repository" + e.getMessage());
        }
        return folderNode;
    }

    public WorkflowPackage create(Resource resource) throws Exception {

        // Check if the resource exists.
        if (resource == null) {
            return null;
        }

        // Check if there is a content node.
        if (!resource.adaptTo(Page.class).hasContent()) {
            return null;
        }

        // Check if the content node has a mixin type of "vlt:Package".
        if (!hasPackageMixin(resource)) {
            return null;
        }

        // Check if there is a filter node.
        if (resource.getChild("jcr:content/vlt:definition/filter") == null) {
            return null;
        }

        // Check if that filter node has a valid resource type.
        if (!resource.getChild("jcr:content/vlt:definition/filter").getResourceType()
                .equalsIgnoreCase("att/att-foundation/components/collection/definition/resourcelist")) {
            return null;
        }

        return new WorkflowPackageImpl(resource);
    }

    public WorkflowPackage create(String path) throws Exception {
        return create(resourceResolver.getResource(path));
    }

    @SuppressWarnings("unchecked")
    private boolean hasPackageMixin(Resource resource) throws Exception {

        Node contentNode = resource.adaptTo(Page.class).getContentResource().adaptTo(Node.class);
        if (contentNode != null) {
            NodeType[] nodeTypes = contentNode.getMixinNodeTypes();
            Iterator<NodeType> i = IteratorUtils.arrayIterator(nodeTypes);
            while (i.hasNext()) {
                NodeType nodeType = i.next();
                if (nodeType.getName().equalsIgnoreCase("vlt:Package")) {
                    return true;
                }
            }
        }

        return false;
    }

}
