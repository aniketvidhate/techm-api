/**
 * 
 */
package com.att.ecom.cq.bundle.workflows.servlet;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.jcr.Session;
import javax.servlet.ServletException;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.workflows.packages.WorkflowPackage;
import com.att.ecom.cq.bundle.workflows.packages.factory.WorkflowPackageFactory;

/**
 * @author aa949r This Servlet creates workflow-package when invoked
 */

@SlingServlet(paths = { "/bin/createPackage" }, methods = { "GET" })
public class WorkflowPackageCreatorServlet extends SlingAllMethodsServlet {

    private static final String CONTENT_WORKFLOW_PACKAGES = "/content/WorkflowPackages/";

    private static final long serialVersionUID = 1407810417762837950L;

    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowPackageCreatorServlet.class);

    @Override
    protected void doGet(final SlingHttpServletRequest request, final SlingHttpServletResponse response)
            throws ServletException, IOException {
        LOGGER.debug("entering the servlet for creating workflow-package");

        response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");

        ResourceResolver resourceResolver = request.getResourceResolver();
        String referer = request.getHeader("Referer");
        Session session = resourceResolver.adaptTo(Session.class);
        Collection<Resource> updatedItems = new ArrayList<Resource>();
        Set<String> pathSet = new HashSet<String>();
        String[] selectedNodes = request.getParameterValues("selectedNodes");
        String userName = (String) request.getParameter("userName");
        String jiraId = (String) request.getParameter("jiraId");
        String wfPackageTitle = (String) request.getParameter("packageName");
        String workflowpackagePath = (String) request.getParameter("packagePath");    
       
     
        if(StringUtils.isEmpty(workflowpackagePath)) {
            workflowpackagePath = CONTENT_WORKFLOW_PACKAGES + userName;
        }
        
        if(StringUtils.isEmpty(wfPackageTitle)) {
            wfPackageTitle = userName + "_" + "Workflow-Package";
        }
        
        if (selectedNodes != null) {
            pathSet = getUniquePathSet(selectedNodes);
        }
        Iterator<String> itr = pathSet.iterator();
        while (itr.hasNext()) {
            updatedItems.add(resourceResolver.getResource(itr.next()));
        }

        if (StringUtils.isNotEmpty(jiraId))
            wfPackageTitle = jiraId + "_" + wfPackageTitle;

        try {
            if (updatedItems.size() > 0) {
                WorkflowPackageFactory factory = new WorkflowPackageFactory(resourceResolver);
                WorkflowPackage wfPackage = factory.create(updatedItems, workflowpackagePath, userName, wfPackageTitle);
            }

            session.save();
        } catch (Exception e) {
            LOGGER.error("Could not create Package : " + e.getMessage());
            response.sendRedirect(referer + "?message='"
                    + URLEncoder.encode("An error occured while creating the package.", "UTF-8") + "'");
        } finally {
            response.sendRedirect(referer + "?message='" + URLEncoder.encode("Success!", "UTF-8") + "'");
        }
    }

    /*
     * This method removes duplicate node paths And returns set of unique node paths.
     */

    private Set<String> getUniquePathSet(String[] selectedNodes) {
        Set<String> paths = new HashSet<String>();
        for (int i = 0; i < selectedNodes.length; i++) {
            LOGGER.debug("node for pacakage are:" + selectedNodes[i]);
            String resourcePath = getExactResourcePath(selectedNodes[i]);
            paths.add(resourcePath);
        }
        return paths;
    }

    /*
     * This method removes 'jcr:content' part from node path And returns exact node path.
     */
    private String getExactResourcePath(String selectedNodePath) {

        String resourcePath = selectedNodePath;
        String jcrSeperator = "/jcr:content";
        if (StringUtils.contains(resourcePath, jcrSeperator)) {
            resourcePath = StringUtils.substringBefore(selectedNodePath, jcrSeperator);
        }
        return resourcePath;
    }
}
