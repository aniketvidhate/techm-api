package com.att.ecom.cq.bundle.workflows.packages;

import org.apache.sling.api.resource.Resource;

import java.util.List;

public interface WorkflowPackage{
	
	public Resource getResource();
	public List<Resource> addResourceToPackage(Resource resource) throws Exception;
	public boolean removeResourceFromPackage(Resource resource) throws Exception;
	public List<Resource> getPackagedResources();
	public void destroy() throws Exception;
}
