package com.att.ecom.cq.bundle.workflows;

import javax.jcr.Node;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.framework.Constants;
import org.osgi.service.event.EventAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.replication.Replicator;

import com.day.cq.workflow.WorkflowException;
import com.day.cq.workflow.WorkflowService;
import com.day.cq.workflow.WorkflowSession;
import com.day.cq.workflow.collection.ResourceCollectionManager;
import com.day.cq.workflow.exec.WorkItem;
import com.day.cq.workflow.exec.Workflow;
import com.day.cq.workflow.exec.WorkflowData;
import com.day.cq.workflow.exec.WorkflowProcess;
import com.day.cq.workflow.metadata.MetaDataMap;


/**
 * This class is for rejecting a work flow step.
 */
@Component
@Service
@Properties({
        @Property(name = Constants.SERVICE_DESCRIPTION, value = "Reject the current workflow step"),
        @Property(name = Constants.SERVICE_VENDOR, value = "ATT"),
        @Property(name = "process.label", value = "Reject the current workflow step")})


public class RejectDeploymentOnEnvironment implements WorkflowProcess {

    /** the logger */
	private static final Logger log = LoggerFactory.getLogger(RejectDeploymentOnEnvironment.class);
	

    public static final String TYPE_JCR_PATH = "JCR_PATH";
    public static final String TYPE_JCR_UUID = "JCR_UUID";	

    /** @scr.reference */
    protected Replicator replicator;


    /** @scr.reference */
    protected WorkflowService wfService;

    /** @scr.reference policy="static" */
    protected EventAdmin eventAdmin;

    /** @scr.reference */
    protected ResourceCollectionManager rcManager;

    /** @scr.reference policy="static" */
    private SlingRepository repository;
	
    /** admin jcr session */
    private Session admin;
    
	@Override
	public void execute(WorkItem workItem, WorkflowSession wfSession, MetaDataMap metaDataMap) 		throws WorkflowException{
		
		WorkflowData wfData =  workItem.getWorkflowData();
		String instanceId = workItem.getWorkflow().getId();
		try {
			Workflow workflow = wfSession.getWorkflow(instanceId);
			// TO-DO Revert content step needs to worked on.
			if (null != workflow && workflow.getWorkflowData().getPayloadType().equals(TYPE_JCR_PATH)) {
				String path = workflow.getWorkflowData().getPayload().toString()+ "/jcr:content";
				Node contentNode = (Node) wfSession.getSession().getItem(path);
				if (null != contentNode) {
					//if (contentNode.hasProperty("jiraid") && contentNode.getProperty("jiraid").getValue().getString() != "") contentNode.setProperty("jiraid", "");
					// Remove the wfId property on the content node
					//if (contentNode.hasProperty("wfId")&& contentNode.getProperty("wfId").getValue().getString() != "") contentNode.setProperty("wfId", "");
					wfSession.getSession().save();
				}
			}
		} catch (RepositoryException e) {
			// throw new WorkflowException(e.getMessage(),
			// e);
			// TODO :- Send an email to the admin saying
			// error occured while processing the event.
			e.printStackTrace();

		} catch (WorkflowException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        if (wfData.getPayloadType().equals(TYPE_JCR_PATH) && wfData.getPayload() != null) {
            String payloadData = (String) wfData.getPayload();
            log.info("---------------------------------------------------------------------------------");
			log.info("TERMINATING WORK-FLOW :"+ instanceId);
			log.info("PATH :"+ payloadData.toString());
			wfSession.terminateWorkflow(workItem.getWorkflow());
			log.info("---------------------------------------------------------------------------------");
        } 
	}

}
