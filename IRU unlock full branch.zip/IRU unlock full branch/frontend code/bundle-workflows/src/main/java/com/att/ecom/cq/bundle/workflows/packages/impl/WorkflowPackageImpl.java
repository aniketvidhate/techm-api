package com.att.ecom.cq.bundle.workflows.packages.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.commons.collections.IteratorUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.jcr.resource.JcrResourceConstants;
import org.apache.sling.jcr.resource.JcrResourceUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.ecom.cq.bundle.workflows.packages.WorkflowPackage;
import com.day.cq.commons.jcr.JcrConstants;

public class WorkflowPackageImpl implements WorkflowPackage {
    
    private static final String RESOURCE = "resource";
	private Resource resource;
    private Resource filterList;
    /** Logger */
	private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowPackageImpl.class);
    
    public WorkflowPackageImpl(Resource resource){
        this.resource = resource;
        resetFilterList();
    }
    
    private void resetFilterList(){
        this.filterList = resource.getChild("jcr:content/vlt:definition/filter");
    }
    
    @SuppressWarnings("unchecked")
    public List<Resource> addResourceToPackage(Resource resource) throws RepositoryException {
    	LOGGER.debug("entering the addResourceToPackage method for adding resource to workflow-package");
        List<Resource> resources = IteratorUtils.toList(filterList.listChildren());
        
        if (filterList != null){
            String name = RESOURCE;
            
            int i = 0;
            loop: while(true){
                if (i > 0){
                    name = RESOURCE + "_" + i;
                }
                    
                if (filterList.getChild(name) == null){
                    break loop;
                }
                i++;
            }
            
            Node filterNode = filterList.adaptTo(Node.class).addNode((i > 0) ? "resource_" + i : RESOURCE);
            JcrResourceUtil.setProperty(filterNode, "root", resource.getPath());
            JcrResourceUtil.setProperty(filterNode, JcrResourceConstants.SLING_RESOURCE_TYPE_PROPERTY, "att/att-foundation/components/collection/definition/resource");
            JcrResourceUtil.setProperty(filterNode, JcrConstants.JCR_CREATED_BY, filterNode.getSession().getUserID());
            JcrResourceUtil.setProperty(filterNode, JcrConstants.JCR_LAST_MODIFIED_BY, filterNode.getSession().getUserID());
            
            Calendar cal = new GregorianCalendar();
            JcrResourceUtil.setProperty(filterNode, JcrConstants.JCR_CREATED, cal);
            JcrResourceUtil.setProperty(filterNode, JcrConstants.JCR_LASTMODIFIED, cal);
            filterNode.getSession().save();
            
            resources.add(filterList.adaptTo(Resource.class));
        }
        
        return resources;
    }

    public void destroy() throws Exception {
        
        resource.adaptTo(Node.class).remove();
        resource.getParent().adaptTo(Node.class).getSession().save();
        this.filterList = null;

    }

    public List<Resource> getPackagedResources() {
        List<Resource> resources = new ArrayList<Resource>();
        if (filterList != null){
            Iterator<Resource> filters = filterList.listChildren();
            while (filters.hasNext()){
                resources.add(filters.next());
            }
        }
        
        resetFilterList();
        return resources;
    }

    public Resource getResource() {
        return resource;
    }

    public boolean removeResourceFromPackage(Resource resource) throws Exception {
        if (filterList != null){
            Iterator<Resource> filters = filterList.listChildren();
            while (filters.hasNext()){
                Resource filter = filters.next();
                String root = filter.adaptTo(ValueMap.class).get("root", String.class);
                if (root.equalsIgnoreCase(resource.getPath())){
                    filter.adaptTo(Node.class).remove();
                    filter.getParent().adaptTo(Node.class).getSession().save();
                    resetFilterList();
                    return true;
                }
            }
        }
        return false;
    }
}
