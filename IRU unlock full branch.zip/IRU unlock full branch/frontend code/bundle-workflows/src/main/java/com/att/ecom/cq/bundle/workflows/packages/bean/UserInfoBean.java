package com.att.ecom.cq.bundle.workflows.packages.bean;

import java.util.Iterator;
import javax.jcr.RepositoryException;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.jackrabbit.api.security.user.Authorizable;
import org.apache.jackrabbit.api.security.user.Group;

public class UserInfoBean extends ControllerBean {

    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(UserInfoBean.class);

    private static final String ATTRIBUTE_NAME = "userInfoBean";

    private static final String ATT_CMS_TEAM = "att-cms-team";

    private static final String ATT_CONTENTIMPLEMENTATION_TEAM = "att-contentimplementation-team";

    private static final String ATT_MYSALES_DEV = "att-mysales-dev";

    private ResourceResolver resourceResolver;

    private String userName = null;

    private String userRole = "";

    private boolean allowModification = false;

    private boolean allowComponentSearch = false;

    private boolean allowcontentImpl = false;

    @Override
    public String getAttributeName() {
        return ATTRIBUTE_NAME;
    }

    @Override
    public void populate() {
        LOGGER.warn("entering the populate method - UserInfoBean ");
        resourceResolver = getSlingRequest().getResourceResolver();
        Authorizable authorizable = resourceResolver.adaptTo(Authorizable.class);
        try {
            if (authorizable != null) {
                userName = authorizable.getID();
            }

            Iterator<Group> groupiter = authorizable.memberOf();
            while (groupiter.hasNext()) {
                Group eachgrp = groupiter.next();
                String groupId = eachgrp.getID();
                if (ATT_CMS_TEAM.equals(groupId)) {
                    userRole = eachgrp.toString();
                    allowModification = true;
                }

                if (ATT_MYSALES_DEV.equals(groupId)) {
                    allowComponentSearch = true;
                }

                if (ATT_CONTENTIMPLEMENTATION_TEAM.equals(groupId)) {
                    allowComponentSearch = true;
                    allowcontentImpl = true;
                    allowModification = true;
                }
            }
        } catch (RepositoryException re) {
            LOGGER.error("Error while accesing the repository" + re.getMessage());
        }
    }

    public String getUserName() {
        return userName;
    }

    public String getUserRole() {
        return userRole;
    }

    public boolean isAllowModification() {
        return allowModification;
    }

    public boolean isAllowComponentSearch() {
        return allowComponentSearch;
    }

    public boolean isAllowcontentImpl() {
        return allowcontentImpl;
    }
}
