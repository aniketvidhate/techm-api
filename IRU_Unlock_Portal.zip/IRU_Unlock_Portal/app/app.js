var unlockPortal = angular.module('unlockPortal',['ngRoute']);

unlockPortal.config(function($routeProvider){
	$routeProvider.
	when('/unlock',{
		templateUrl:'tpl/unlock_step1.jsp',
		controller:'step1Ctrl'
	}).
	when('/unlockstep2',{
		templateUrl:'tpl/unlock_step2.jsp',
		controller:'step2Ctrl'
	}).
	when('/unlockstep3',{
		templateUrl:'tpl/unlock_step3.jsp',
		controller:'step3Ctrl'
	}).
	when('/nonattunlock',{
		templateUrl:'tpl/non_ATT_submit.jsp',
		controller:'nonAttCtrl'
	}).
	otherwise({
		redirectTo:'/unlock'
	});
});

