
//Unlock Step 3 Controller - S
unlockPortal.controller('step3Ctrl', ['$scope', '$rootScope', 'services','$sce', function($scope, $rootScope, services,$sce){
	console.log("in step3 controller");

	if($rootScope.imei_usr != undefined){
		$rootScope.imei_usr = $scope.imei;
	}
	
	//On focus event -S
	$scope.onFocusImei = function(){
		$scope.imeiErrorMsg = "";
		$scope.imeiError = false;
		$scope.imeiReqErr = false;
		$scope.imeiLengthErr = false;
	};
	
	//On Blur Events -S
	$scope.getImei = function(){
		console.log("getImei function called"+$scope.imei);
		
		if($scope.imei == undefined || $scope.imei == "" || $scope.imei.length < 15){
			validationImeiNo();
		}else{
			$rootScope.imei_usr = $scope.imei;
		
			var imeiReq = 	{
								imei : $scope.imei
							}
			
			services.IMEICheckService(imeiReq).
					success(function(data, status, headers, config) {
						console.log("data IMEI"+data.IMEI);
						$scope.imeiRes = data.IMEI;
						$scope.imeiError = false;
						
						if($scope.imei == "444444444444444"){
							if($scope.imeiRes[0].imeiSearchResponse.serviceStatus.code == 1){
								$scope.imeiError = true;
								$scope.imeiErrorMsg = $sce.trustAsHtml($scope.imeiRes[0].imeiSearchResponse.imeiDetail.errorDescription);
								console.log("error msg : ",$scope.imeiErrorMsg);
								
							}
						}else if($scope.imei == "555555555555555"){
							$scope.make = $scope.imeiRes[1].imeiSearchResponse.imeiDetail.make;
							$scope.model = $scope.imeiRes[1].imeiSearchResponse.imeiDetail.model;
						}
						
						console.log("$scope.imeiErrorMsg=>"+$scope.imeiErrorMsg);
						
					  
					}).
					error(function(data, status, headers, config) {
						$scope.imeiErrorMsg = "Something went wrong with the system, please try again later!!"
						$scope.imeiError = true;
					});
		}
		
		
	};
	
	//Back button logic - S
	$scope.unlockStep3_back = function()
	{
		console.log("step3 back button called => ");
		window.location = "#/unlockstep2/";
	}
	//Back button logic - S
	
	//Submit button logic -S
	$scope.unlockStep3 = function()
	{
		console.log("step3 submit button called => ");
		if($scope.imei == undefined || $scope.imei == ""){
			validationImeiNo();
		}
		
	}	
	//Submit button logic -E
	
	//check validation for IMEI no
	function validationImeiNo(){
		if($scope.imei == undefined || $scope.imei == ""){
			$scope.imeiReqErr = true;
		}else if($scope.imei.length < 15){
			$scope.imeiLengthErr = true;
		}
		
	}
	
}]);
//Unlock Step 3 Controller - E

