//Unlock Step 1 Controller - S
unlockPortal.controller('step1Ctrl', ['$scope','$rootScope', '$http','services', '$sce', function($scope,$rootScope, $http, services, $sce){
	
	console.log("in step1 controller");
	console.log("Att wireless no => "+$rootScope.attwrlsno_usr);
	console.log("first name => "+$rootScope.fname_usr);
	console.log("last name => "+$rootScope.lname_usr);
	
	//To show the values on back button
	if($rootScope.custType == "yes"){
		$scope.selectedCustomer = "yes";
		$("#att_custRadioImg").addClass("radioBtnClickedImg");
		$("#attDiv").removeClass("divHide").addClass("divShow");
		$("#nonAttDiv").removeClass("divShow").addClass("divHide");
	}else if($rootScope.custType == "no"){
		$scope.selectedCustomer = "no";
		$("#notatt_custRadioImg").addClass("radioBtnClickedImg");
		$("#nonAttDiv").removeClass("divHide").addClass("divShow");
		$("#attDiv").removeClass("divShow").addClass("divHide");
	}
	
	
	if($rootScope.attwrlsno_usr != undefined && $rootScope.fname_usr != undefined && $rootScope.lname_usr != undefined){
		$scope.attwrlsno = $rootScope.attwrlsno_usr;
		$scope.fname = $rootScope.fname_usr;
		$scope.lname = $rootScope.lname_usr;
	}
	
	//Non-ATT flow -S
	if($rootScope.imei_nonatt_usr != undefined){
		$scope.nonAttImei = $rootScope.imei_nonatt_usr;
		$scope.nonAttMake = $rootScope.nonAttMake_usr;
		$scope.nonAttModel = $rootScope.nonAttModel_usr;
		 					
	}
	
	//On focus event
	$scope.onFocusImei = function(){
		$scope.nonAttImeiErrorMsgs = "";
		$scope.nonAttImeiError = false;
		$scope.nonAttImeiReqErr = false;
		$scope.nonAttImeiLengthErr = false;
	};
	
	//On Blur Events 
	$scope.getImei = function(){
		console.log("getImei function called"+$scope.imei);

		$scope.IMEIReqValidaion();
		
		
	};
	//Non-ATT flow - E
	
	//Next button Logic goes here-S
	$scope.unlockStep1 = function()
	{
		if($scope.selectedCustomer == undefined){
			$scope.selectedCustomerErr = true;
			$("#att_custRadioImg,#notatt_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg");
			$("#att_custRadioImg,#notatt_custRadioImg").addClass("radioBtnErrorImg");
			 
		}
		
		if($scope.attwrlsno == undefined || $scope.attwrlsno < 10){
			validationAttWrlsNo();
		}
		if($scope.fname == undefined){
			validationFirstName();
		}
		if($scope.lname == undefined){
			validationLastName();
		}
					
		if($scope.selectedCustomer == "yes"){
			
			
			if($scope.attwrlsno != undefined && $scope.fname != undefined && $scope.lname != undefined && $scope.selectedCustomer != undefined){
				console.log("Att wireless no => "+$scope.attwrlsno);
				console.log("first name => "+$scope.fname);
				console.log("last name => "+$scope.lname);
				
				$scope.fradulentError = "";
				$rootScope.attwrlsno_usr = $scope.attwrlsno;
				$rootScope.fname_usr = $scope.fname;
				$rootScope.lname_usr = $scope.lname;
				
				services.FraudulentCheckService($scope.attwrlsno).
						success(function(data, status, headers, config) {
							console.log("data"+data.FraudulentCustomers);
							var fraudCustRes = data.FraudulentCustomers;
												
							$.each(fraudCustRes,function(i, fraudCustRes) {
								console.log("fraudCustRes.AttWirelessNo =>"+fraudCustRes.AttWirelessNo);
								console.log("$scope.attwrlsno =>"+$scope.attwrlsno);
								console.log("if(fraudCustRes.AttWirelessNo == $scope.attwrlsno) =>"+fraudCustRes.AttWirelessNo == $scope.attwrlsno);
						  
								if(fraudCustRes.AttWirelessNo == $scope.attwrlsno){
									if(fraudCustRes.Fraudulent == "yes"){
										$scope.fradulentError = "This AT&T Wireless Number is appeared in Fraudulent list";
									}
								}
							})
							
							console.log("$scope.fradulentError=>"+$scope.fradulentError);
							if($scope.fradulentError == "" || $scope.fradulentError == undefined){
								window.location = "#/unlockstep2/";
							}
						  
						}).
						error(function(data, status, headers, config) {
						  $scope.fradulentError = "Something went wrong with the system, please try again later!!"
						});
			}
		}else if($scope.selectedCustomer == "no"){
			if($scope.nonAttImei == undefined || $scope.nonAttImei == "" || $scope.nonAttImei.length < 15){
				validationImeiNo();
			}else{
				$rootScope.imei_nonatt_usr = $scope.nonAttImei;
				$rootScope.nonAttMake_usr = "Apple";
				$rootScope.nonAttModel_usr = "IPhone 6S";
				window.location = "#/nonattunlock/";
			}
		
		}
		
	};
	//Next button Logic goes here-E
	
	//IMEI request validation check -S
	$scope.IMEIReqValidaion = function(){
		if($scope.nonAttImei == undefined || $scope.nonAttImei == "" || $scope.nonAttImei.length < 15){
				validationImeiNo();
				$scope.nonAttMake = "";
				$scope.nonAttModel = "";
		}else{
			$rootScope.imei_nonatt_usr = $scope.nonAttImei;
			
			var imeiReq = 	{
								imei : $scope.nonAttImei
							}
			
			services.IMEICheckService(imeiReq).
					success(function(data, status, headers, config) {
						console.log("data IMEI"+data.IMEI);
						$scope.imeiRes = data.IMEI;
						$scope.nonAttImeiError = false;
						
						if($scope.nonAttImei == "444444444444444"){
							if($scope.imeiRes[0].imeiSearchResponse.serviceStatus.code == 1){
								$scope.nonAttImeiError = true;
								$scope.nonAttImeiErrorMsgs = $sce.trustAsHtml($scope.imeiRes[0].imeiSearchResponse.imeiDetail.errorDescription);
								console.log("error msg : ",$scope.nonAttImeiErrorMsgs);
								
							}
						}else if($scope.nonAttImei == "555555555555555"){
							$scope.nonAttMake = $scope.imeiRes[1].imeiSearchResponse.imeiDetail.make;
							$scope.nonAttModel = $scope.imeiRes[1].imeiSearchResponse.imeiDetail.model;
						}
						$rootScope.nonAttMake_usr = "Apple";
						$rootScope.nonAttModel_usr = "IPhone 6S";
						console.log("$scope.imeiErrorMsg=>"+$scope.nonAttImeiErrorMsgs);
						
						
					  
					}).
					error(function(data, status, headers, config) {
						$scope.nonAttImeiErrorMsgs = "Something went wrong with the system, please try again later!!"
						$scope.nonAttImeiError = true;
					});
		}
	};
	
	$scope.customerType = function(){
	
		console.log("customerType function called"+$scope.selectedCustomer);
		$rootScope.custType = $scope.selectedCustomer;
		$scope.selectedCustomerErr = false;
	};
	
	//On focus event -S
	$scope.onFocusAttWrlsNo = function(){
		$scope.attWrlsNoReqErr = false;
		$scope.attWrlsLengthWErr = false;
		$scope.fradulentError = "";
		$("p").addClass("textboxFocusColor");
	};
	
	$scope.onFocusFirstName = function(){
		$scope.firstNameReqErr = false;
	};
	
	$scope.onFocusLastName = function(){
		$scope.lastNameReqErr = false;
	};
	//On focus event -E
	
	//On Blur Events -S
	$scope.getAttWrlsNo = function(){
		console.log("$scope.attwrlsno  "+$scope.attwrlsno + "  "+$rootScope.attwrlsno_usr);
		
		validationAttWrlsNo();
		/*if($scope.attwrlsno != undefined){
			console.log("getAttWrlsNo function called"+$rootScope.attwrlsno_usr);
			$rootScope.attwrlsno_usr = $scope.attwrlsno;
							
		}*/
	};
	
	$scope.getFirstName = function(){
		console.log("getFirstName function called"+ $scope.fname + "  "+ $rootScope.fname_usr);
		//$rootScope.fname_usr = $scope.fname;
		
		validationFirstName();
	};
	
	$scope.getLastName = function(){
		console.log("getLastName function called"+ $scope.lname + "   "+$rootScope.lname_usr);
		//$rootScope.lname_usr = $scope.lname;
		
		validationLastName();
	};
	//On Blur Events -E
	
	//check validation for att wireless no
	function validationAttWrlsNo(){
		if($scope.attwrlsno == undefined || $scope.attwrlsno == ""){
			$scope.attWrlsNoReqErr = true;
		}else if($scope.attwrlsno.length < 10){
			$scope.attWrlsLengthWErr = true;
		}
		
	}
	
	//check validation for first name
	function validationFirstName(){
		if($scope.fname == undefined || $scope.fname == ""){
			$scope.firstNameReqErr = true;
		}
	}
	
	//check validation for last name
	function validationLastName(){
		if($scope.lname == undefined || $scope.lname == ""){
			$scope.lastNameReqErr = true;
		}
	}
	
	
	
	//Captcha Code -S
	 imageCaptchaJson = {
        "imageCaptchaRequest": {
            "captchaType": "image"
        }
    };


    // function to call the Image Captcha API
    $scope.callImageCaptcha = function() {
		/*$scope.capDisable= true;
		$scope.rePlay=false;
        $scope.CaptchaType = "image";
		
        $http({
            method: 'POST',
            url: unlockApiUrl.imageCaptchaUrl,
            data: imageCaptchaJson
        }).success(function(jsonCapImgData) {
            if (jsonCapImgData.imageCaptchaResponse.serviceStatus.code == 0) {
                $scope.capImg = 'data:image/jpeg;base64,' + jsonCapImgData.imageCaptchaResponse.captchaDetail.captchaChallenge;
                $scope.challenge = jsonCapImgData.imageCaptchaResponse.captchaDetail.captchaID;
                $scope.capRequired = true;
            } else {
               $scope.capRequired = false ;
            }
			$scope.capDisable= false;
			if($scope.capToggleClicked) {
				$scope.capToggleClicked=false;
				jQuery(document.getElementById("recaptcha_reload_btn")).focus();
			}
        }).error(function(data, status, headers, config) {
			 $scope.capDisable  = false;
			 $scope.capRequired = false;
        });*/
    }


    audioCaptchaJson = {
        "audioCaptchaRequest": {
            "captchaType": "audio"
        }
    };


   // function to call the Audio Captcha API
    $scope.callAudioCaptcha = function() {
		/*$scope.capDisable= true;
		$scope.rePlay=true;
        $scope.CaptchaType = "audio";
		$scope.tokenVal = document.getElementById("tokenID").value ;
				
        $http({
            method: 'POST',
            url: unlockApiUrl.audioCaptchaUrl,
            data: audioCaptchaJson
        }).success(function(jsonCapAudData) {

			$scope.capImg = "";
			if (jsonCapAudData.audioCaptchaResponse.serviceStatus.code == 0) {
                $scope.challenge = jsonCapAudData.audioCaptchaResponse.captchaDetail.captchaID;

                // GET CALL for AudioCaptcha

				if (testIE!=undefined && testIE){
           			//$scope.audio.src = "";
					//$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal; 
					
					var audioUrl = "http:" + "//" + window.location.hostname + unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal;
					window.location.assign(audioUrl);
					//$scope.audio.src = "https://tst31.stage.att.com/apis/deviceunlock/unlockCaptcha/sound" + "/" + $scope.challenge;
					//$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge+"?OWASP_CSRFTOKEN="+$scope.tokenVal;
            		//$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + '?random=' + new Date().getTime();
           			//document.all.sound.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge;
					
                } else { 
         			$scope.audio.src = "data:audio/wav;base64," + jsonCapAudData.audioCaptchaResponse.captchaDetail.captchaChallenge;
					$scope.audio.play();
         		}

                $scope.apiError = false;
                $scope.capRequired = true;
			}
			else {
                $scope.capRequired = false ;
            }
			$scope.capDisable= false;
			if($scope.capToggleClicked) {
				$scope.capToggleClicked=false;
				jQuery(document.getElementById("recaptcha_reload_btn")).focus();
			}
        }).error(function(data, status, headers, config) {
			$scope.capDisable  = false;
			$scope.capRequired = false ;
        }); */
    }

     $scope.rePlayFunc = function() {
        /* if (testIE!=undefined && testIE){
            //$scope.audio.src = $sce.trustAsResourceUrl(unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge);
			//$scope.audio.src = unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal;
        	 var audioUrl = "http:" + "//" + window.location.hostname + unlockApiUrl.audioCaptchaUrl + "/" + $scope.challenge + "?OWASP-CSRFTOKEN="+$scope.tokenVal;
				window.location.assign(audioUrl);
         } else {
			$scope.audio.play();
         }*/
	 }


    // toggle between audio and image captcha on clik of button
    $scope.capToggle = function(capToggleVar) {
    	/*$scope.capToggleClicked=true;
		if (! $scope.capDisable)   //to disable toggling untill response for first call has not been received
        {
			$scope.recaptcha_response_field="";
			if (capToggleVar == "audio") {
				$scope.capToggleAudio = true;
				$scope.capToggleVisual = false;
				$scope.callAudioCaptcha();
			} else {
				if (testIE!=undefined && testIE){
					//$scope.audio.src = "";
				} else {
					$scope.audio.pause();
				}
				$scope.capToggleAudio = false;
				$scope.capToggleVisual = true;
				$scope.callImageCaptcha();
			}
		}	*/
	}
	

    // refresh audio or image captcha on click of refresh button based on the user's current choice 
    $scope.capRefresh = function() {
		/*if (! $scope.capDisable)  //to disable toggling untill response for first call has not been received
        {
			$scope.recaptcha_response_field="";
			if ($scope.capToggleAudio) {
				//if (navigator.appName == "Microsoft Internet Explorer") {
				if (testIE!=undefined && testIE){
					//$scope.audio.src = "";
				} else {
					$scope.audio.pause();
				}
				$scope.callAudioCaptcha();
			} else { 
				$scope.callImageCaptcha();
			}
		}*/
    }

    // fetch the captcha image onLoad of page
   // $scope.callImageCaptcha();
	
  /* if (testIE!=undefined && testIE){
    	//$scope.audio = document.getElementById("bgSoundFrame");
    }else{
        $scope.audio = document.createElement('audio');
        $scope.audio.src = '';
    }*/
	// function to set required property of textfields dynamically on the basis of radiobutton selected
    $scope.req = function(fld) {

        if ($scope.radio == null || $scope.radio == "") {
            return false;
        }
    }
//Captcha code -E

//Radio button image toggle on hover in and hover out -S
	$("#att_custRadioImg,#notatt_custRadioImg").hover(function(){
        if($scope.selectedCustomerErr != true){
			var id = this.id;
			var classes = $("#"+id).attr("class").split(' ');
			$.each(classes, function(i, c) {
				if (c.indexOf("radioBtnImg") == 0) {
					$("#"+id).addClass("radioBtnHoverImg");
				}else if(c.indexOf("radioBtnClickedImg") == 0){
					$("#"+id).addClass("radioBtnClickedHoverImg");
				}
			});
			
			
		}
	}, function(){
			//MouseOut event
		if($scope.selectedCustomerErr != true){
			var id = this.id;
			var classes = $("#"+id).attr("class").split(' ');
			$.each(classes, function(i, c) {
				if (c.indexOf("radioBtnImg") == 0) {
					$("#"+id).removeClass("radioBtnHoverImg");
				}else if(c.indexOf("radioBtnClickedImg") == 0){
					$("#"+id).removeClass("radioBtnClickedHoverImg");
				}
			});
			
			
		}
	})
	//Radio button image toggle on hover in and hover out -E
	
	//check validation for IMEI no -S
	function validationImeiNo(){
		if($scope.nonAttImei == undefined || $scope.nonAttImei == ""){
			$scope.nonAttImeiReqErr = true;
		}else if($scope.nonAttImei.length < 15){
			$scope.nonAttImeiLengthErr = true;
		}
		
	}
	//check validation for IMEI no -E
}]);
//Unlock Step 1 Controller - E

//Radio button image toggle on clicked -S
function custRadioClicked(obj){
	
	$("#"+obj.id+"RadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
	$("#"+obj.id+"RadioImg").addClass("radioBtnClickedImg");	
	
	if(obj.id == "att_cust"){
		$("#notatt_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
		$("#notatt_custRadioImg").addClass("radioBtnImg");
		$("#attDiv").removeClass("divHide").addClass("divShow");
		$("#nonAttDiv").removeClass("divShow").addClass("divHide");
	}else if(obj.id == "notatt_cust"){
		$("#att_custRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
		$("#att_custRadioImg").addClass("radioBtnImg");
		$("#nonAttDiv").removeClass("divHide").addClass("divShow");
		$("#attDiv").removeClass("divShow").addClass("divHide");
	}
};
//Radio button image toggle on clicked -E
	


//Valid Number will always ensure that input field can only accepts numeric (integer) values
unlockPortal.directive('validNumber', function() {
  return {
    require: '?ngModel',
    link: function(scope, element, attrs, ngModelCtrl) {
      if(!ngModelCtrl) {
        return; 
      }
      
      ngModelCtrl.$parsers.push(function(val) {
        var clean = val.replace( /[^0-9]+/g, '');
        if (val !== clean) {
          ngModelCtrl.$setViewValue(clean);
          ngModelCtrl.$render();
        }
        return clean;
      });
      
      element.bind('keypress', function(event) {
        if(event.keyCode === 32) {
          event.preventDefault();
        }
      });
    }
  };
});
//Unlock Step 1 Controller - E

//Preventing cut, copy and paste the values from the input textboxes
unlockPortal.directive('stopccp', function(){
    return {
        scope: {},
        link:function(scope,element){
            element.on('cut copy paste', function (event) {
              event.preventDefault();
            });
        }
    };
});

//Validations
//For Wireless Number textbox to block O and 1 at index 0
function checkFirstChar(ev, key, txt) {
	//var len=txt.value.slice(0, txt.selectionStart).length;
	if (getCursorPos(txt) == 0) {
		return (ev.ctrlKey || ev.altKey || (49 < key && key < 58 && ev.shiftKey == false) || (97 < key && key < 106) || (key == 8) || (key == 9) || (key > 34 && key < 40) || (key == 46));
	} else {
		return (ev.ctrlKey || ev.altKey || (47 < key && key < 58 && ev.shiftKey == false) || (95 < key && key < 106) || (key == 8) || (key == 9) || (key > 34 && key < 40) || (key == 46));
	}

}

// To get the Cursor position in Wireless Number Field
function getCursorPos(txt) {

	// IE Support
	if (document.selection) {

		// Set focus on the element
		txt.focus();

		// To get cursor position, get empty selection range
		var sel = document.selection.createRange();

		// Move selection start to 0 position
		sel.moveStart('character', -txt.value.length);

		// The caret position is selection length
		return sel.text.length;

	} else {

		var len = txt.value.slice(0, txt.selectionStart).length
		return len;
	}

}
