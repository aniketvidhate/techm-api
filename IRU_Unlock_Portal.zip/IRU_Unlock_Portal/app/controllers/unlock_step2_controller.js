
//Unlock Step 2 Controller - S
unlockPortal.controller('step2Ctrl', ['$scope','$rootScope', function($scope,$rootScope){
	console.log("in step2 controller"+$rootScope);

	console.log("Email no => "+$rootScope.emailAddress_usr);
	console.log("last ssn => "+$rootScope.ssn_usr);
	console.log("att passcode => "+$rootScope.attPass_usr);

	$scope.isValidEmail = true;
	
	//To show the values on back button
	if($rootScope.militaryPersnl == "yes"){
		$scope.militaryPersonnel = "yes";
		$("#military_persnlRadioImg").addClass("radioBtnClickedImg");
	}else if($rootScope.militaryPersnl == "no"){
		$scope.militaryPersonnel = "no";
		$("#non_military_persnlRadioImg").addClass("radioBtnClickedImg");
	}else{
		$scope.militaryPersonnel = "no";
		$("#non_military_persnlRadioImg").addClass("radioBtnClickedImg");
	}
	
	
	if($rootScope.attwrlsno_usr != undefined && $rootScope.fname_usr != undefined && $rootScope.lname_usr != undefined){
		$scope.attwrlsno = $rootScope.attwrlsno_usr;
		$scope.fname = $rootScope.fname_usr;
		$scope.lname = $rootScope.lname_usr;
	}
	
	if($rootScope.emailAddress_usr != undefined){
		$scope.emailAddress = $rootScope.emailAddress_usr;
	}
	if($rootScope.ssn_usr != undefined){
		$scope.ssn = $rootScope.ssn_usr;
	}
	if($rootScope.attPass_usr != undefined){
		$scope.attPass = $rootScope.attPass_usr;
	}
	

	$scope.getMilitaryPers = function(){
	
		console.log("getMilitaryPers function called"+$scope.militaryPersonnel);
		$rootScope.militaryPersnl = $scope.militaryPersonnel;
		
	};
	
	//On focus Events -S
	$scope.onFocusSSNNo = function(){
		console.log("onFocusSSNNo function called"+$scope.ssn);
		$scope.ssnReqErr = false; 
		$scope.ssnLengthErr = false;
	};
	
	$scope.onFocusEmail = function(){
		console.log("onFocusSSNNo function called"+$scope.emailAddress);
		$scope.isValidEmail = true; 
	};
	//On focus Events -E
	
	//On Blur Events -S
	$scope.getEmailAddr = function(){
		console.log("getEmailAddr function called"+$scope.emailAddress);
		$rootScope.emailAddress_usr = $scope.emailAddress;
		
		$scope.isValidEmail = IsEmail($scope.emailAddress);
		
	};
	
	$scope.getLastSSN = function(){
		console.log("getLastSSN function called"+ $scope.ssn);
		if($scope.ssn == undefined || $scope.ssn.length < 4){
			validationSSNNo();
		}
		$rootScope.ssn_usr = $scope.ssn;
	};
	
	$scope.getATTPass = function(){
		console.log("getATTPass function called"+$scope.attPass);
		$rootScope.attPass_usr = $scope.attPass;
	};
	//On Blur Events -E

	//Back button logic
	$scope.unlockStep2_back = function()
	{
		console.log("step2 back button called => ");
		window.location = "#/unlock/";
	}		
	
	//Next button logic
	$scope.unlockStep2 = function()
	{
		console.log("step2 next button called => ");
		
		if($scope.ssn == undefined || $scope.ssn.length < 4){
			validationSSNNo();
		}
		
		$scope.isValidEmail = IsEmail($scope.emailAddress);
		
		if($scope.ssn != undefined && IsEmail($scope.emailAddress)){
			$rootScope.emailAddress_usr = $scope.emailAddress;
			$rootScope.ssn_usr = $scope.ssn;
			$rootScope.militaryPersnl =	$scope.militaryPersonnel;
			$rootScope.attPass_usr = $scope.attPass;
			
			window.location = "#/unlockstep3/";
		}
		
	}	
	
	//check validation for ssn no
	function validationSSNNo(){
		if($scope.ssn == undefined || $scope.ssn == ""){
			$scope.ssnReqErr = true; 
		}else if($scope.ssn.length < 4){
			$scope.ssnLengthErr = true;
		}
		
	}
	
	function IsEmail(email) {
	  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	  return regex.test(email);
	}
	
//Radio button image toggle on hover in and hover out -S
	$("#military_persnlRadioImg,#non_military_persnlRadioImg").hover(function(){
        if($scope.selectedCustomerErr != true){
			var id = this.id;
			var classes = $("#"+id).attr("class").split(' ');
			$.each(classes, function(i, c) {
				if (c.indexOf("radioBtnImg") == 0) {
					$("#"+id).addClass("radioBtnHoverImg");
				}else if(c.indexOf("radioBtnClickedImg") == 0){
					$("#"+id).addClass("radioBtnClickedHoverImg");
				}
			});
			
			
		}
	}, function(){
			//MouseOut event
		if($scope.selectedCustomerErr != true){
			var id = this.id;
			var classes = $("#"+id).attr("class").split(' ');
			$.each(classes, function(i, c) {
				if (c.indexOf("radioBtnImg") == 0) {
					$("#"+id).removeClass("radioBtnHoverImg");
				}else if(c.indexOf("radioBtnClickedImg") == 0){
					$("#"+id).removeClass("radioBtnClickedHoverImg");
				}
			});
			
			
		}
	})
	//Radio button image toggle on hover in and hover out -E	
}]);
//Unlock Step 2 Controller - E

//Radio button image toggle on clicked -S
function militaryRadioClicked(obj){
	
	$("#"+obj.id+"RadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
	$("#"+obj.id+"RadioImg").addClass("radioBtnClickedImg");	
	
	if(obj.id == "military_persnl"){
		$("#non_military_persnlRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
		$("#non_military_persnlRadioImg").addClass("radioBtnImg");
	}else if(obj.id == "non_military_persnl"){
		$("#military_persnlRadioImg").removeClass("radioBtnImg radioBtnClickedImg radioBtnErrorImg radioBtnClickedHoverImg radioBtnHoverImg");
		$("#military_persnlRadioImg").addClass("radioBtnImg");
	}
};
//Radio button image toggle on clicked -E
