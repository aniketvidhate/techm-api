
//Unlock Step 3 Controller - S
unlockPortal.controller('nonAttCtrl', ['$scope', '$rootScope', 'services','$sce', function($scope, $rootScope, services,$sce){
	console.log("in non att submit controller");

	
	
	//Back button logic - S
	$scope.nonAttUnlockBack = function()
	{
		console.log("non att back button called => ");
		window.location = "#/unlock/";
	}
	//Back button logic - S
	
	//Submit button logic -S
	$scope.nonAttunlockSubmit = function()
	{
		
		
	}	
	//Submit button logic -E
	
	
}]);
//Unlock Step 3 Controller - E

