//unlockPortal.service('UnlockStep1Service', function() {
	//function FraudulentCheckService(attWirelessNo){
		//return $http.get('data/FraudulentCustomer.json', attWirelessNo);
	//}
//});

unlockPortal.factory('services', function($http) {

    var respAPI = {};

	//To check the ATT wireless no. for fraud activity
    respAPI.FraudulentCheckService = function(attWirelessNo) {
		console.log("attWirelessNo ** ==>"+attWirelessNo);
      return $http.get('data/FraudulentCustomer.json');
    }

	//To check the IMEI no. for exists in the list
	respAPI.IMEICheckService = function(imeiReq) {
		console.log("imeiReq ** ==>"+imeiReq);
      return $http.post('data/IMEILookup.json', imeiReq);
    }
	
	
    return respAPI;
  });